﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

//整个内存数据库的所有临界区管理
class CCriticalManage
{
	//
protected:
	CRITICAL_SECTION					m_CritSystemLock;//系统锁临界区，用于管理系统内部的块修改等事务
	CRITICAL_SECTION					m_CritSequence;//序列临界区，用于管理和生产系统唯一的序列值
	CRITICAL_SECTION					m_CritUserLock;//用户锁临界区，用于管理数据库内，用户需要获得的唯一操作需要设定的锁

public:
	CCriticalManage(void);
	~CCriticalManage(void);
public:
};
