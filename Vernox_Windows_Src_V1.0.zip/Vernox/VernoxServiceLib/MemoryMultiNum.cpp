﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryMultiNum.h"
#include "Check.h"
#include <float.h>
CMemoryMultiNum::CMemoryMultiNum()
{

}

CMemoryMultiNum::~CMemoryMultiNum()
{

}

/************************************************************************
		功能说明：
			获取数据长度
		参数说明：
			lpIndexField：索引字段
************************************************************************/
int CMemoryMultiNum::GetKeySize(LPMULTIINDEX lpMultiIndex)
{
	return  lpMultiIndex->m_nIndexNum*sizeof(KEY) + sizeof(BYTE);
}

/************************************************************************
		功能说明：
			获取结点头大小
		参数说明：
			lpMultiIndex：符合索引
************************************************************************/
int CMemoryMultiNum::GetHeadSize(LPMULTIINDEX lpMultiIndex)
{
	return GetKeySize(lpMultiIndex) + sizeof(MULTINODEHEAD);
}

/************************************************************************
		功能说明：
			获取叶子大小
		参数说明：
			lpMultiIndex：符合索引
************************************************************************/
int CMemoryMultiNum::GetLeaveSize(LPMULTIINDEX lpMultiIndex)
{
	return GetKeySize(lpMultiIndex) + sizeof(long long);
}

/************************************************************************
	功能说明：
		获取树干大小
	参数说明：
		lpMultiIndex：符合索引
************************************************************************/
int CMemoryMultiNum::GetTrunkSize(LPMULTIINDEX lpMultiIndex)
{	
	return GetKeySize(lpMultiIndex) + sizeof(int);
}

/************************************************************************
		功能说明：
			获取关键字值
		参数说明：
			lpKey：关键字指针
			nLevel：值位置
			varKey：关键字值
************************************************************************/
void CMemoryMultiNum::GetKeyValue(LPVOID lpKey, int nLevel, VARDATA& varKey)
{
	LPMULTIKEY lpMultiKey;

	lpMultiKey = (LPMULTIKEY)lpKey;
	
	if(m_bKeyType[nLevel] == MF_SYS_FIELDTYPE_INT || m_bKeyType[nLevel] == MF_SYS_FIELDTYPE_BIGINT)
	{
		varKey.SetData(lpMultiKey->m_pKey[nLevel].m_llData);
	}
	else if(m_bKeyType[nLevel] == MF_SYS_FIELDTYPE_DOUBLE || m_bKeyType[nLevel] == MF_SYS_FIELDTYPE_DATE)
	{
		varKey.SetData(lpMultiKey->m_pKey[nLevel].m_dblData, MF_VARDATA_DOUBLE);
	}
}

/************************************************************************
		功能说明：
			设置关键字值
		参数说明：
			lpKey：关键字指针
			lpKeyValue：关键字值
			bInsert：是否做插入
-************************************************************************/
void CMemoryMultiNum::SetKeyValue(LPVOID lpKey, LPVOID lpKeyValue, BOOL bInsert)
{
	int nKeySize;
	LPMULTIKEY lpMultiKey;
	lpMultiKey = (LPMULTIKEY)lpKey;

	if(!bInsert)
	{
		if(m_bKeyType[0] == MF_SYS_FIELDTYPE_INT || m_bKeyType[0] == MF_SYS_FIELDTYPE_BIGINT)
		{
			if(lpMultiKey->m_pKey[0].m_llData == MAXLONGLONG)
			{
				return;
			}
		}
		else
		{
			if(lpMultiKey->m_pKey[0].m_dblData == DBL_MAX)
			{
				return;
			}
		}
	}

	nKeySize   = m_bKeyNum*sizeof(KEY) + sizeof(BYTE);
	memcpy(lpKey, lpKeyValue, nKeySize);
}

/************************************************************************
	功能说明：
		获取Key的指针
	参数说明：
		lpData：数据结构体指针
		bNodeType：结点类型
************************************************************************/
LPVOID CMemoryMultiNum::GetKeyPtr(LPVOID lpData, NODETYPE bNodeType)
{
	if(bNodeType == LEAVENODE)
	{
		return &((LPLEAVESTRUCT)lpData)->m_stuKey;
	}
	else
	{
		return &((LPTRUNKSTRUCT)lpData)->m_stuMaxKey;
	}
}

/************************************************************************
	功能说明：
		获取MaxKey的指针
	参数说明：
		lpData：结点指针
************************************************************************/
LPVOID CMemoryMultiNum::GetMaxKeyPtr(LPBYTE lpNode)
{
	return &((LPMULTINODEHEAD)lpNode)->m_stuMaxKey;
}

/************************************************************************
		功能说明：
			判断是否为最大关键字
		参数说明：
			最大关键字指针
************************************************************************/
BOOL CMemoryMultiNum::CheckMaxKey(LPVOID lpKeyPtr)
{
	LPMULTIKEY lpMultiKey;
	lpMultiKey = (LPMULTIKEY)lpKeyPtr;

	if(m_bKeyType[0] == MF_SYS_FIELDTYPE_INT || m_bKeyType[0] == MF_SYS_FIELDTYPE_BIGINT)
	{
		if(lpMultiKey->m_pKey[0].m_llData == MAXLONGLONG)
		{
			return TRUE;
		}
	}
	else if(m_bKeyType[0] == MF_SYS_FIELDTYPE_DOUBLE || m_bKeyType[0] == MF_SYS_FIELDTYPE_DATE)
	{
		if(lpMultiKey->m_pKey[0].m_dblData == DBL_MAX)
		{
			return TRUE;
		}
	}

	return FALSE;
}
/************************************************************************
		功能说明：
			从叶子结构体中获取值，即DataID
		参数说明：
			lpLeaveData：叶子结点数据
************************************************************************/
long long CMemoryMultiNum::GetDataIDFromLeavePtr(LPVOID lpLeaveData)
{
	LPLEAVESTRUCT lpLeaveElement;

	lpLeaveElement = (LPLEAVESTRUCT)lpLeaveData;
	return lpLeaveElement->m_stuKey.m_pKey[m_bKeyNum - 1].m_llData;
}

/************************************************************************
		功能说明：
			从关键字指针中获取关键字值
		参数说明：
			lpKeyPtr：关键字指针
			nIndex：获取第几个关键字(用于复合索引)
			varData：关键字值
************************************************************************/
int CMemoryMultiNum::GetValueFromKeyPtr(LPVOID lpKeyPtr, int nIndex, VARDATA& varData)
{
	LPMULTIKEY lpMultiKey;
	lpMultiKey = (LPMULTIKEY)lpKeyPtr;

	if(nIndex > m_bKeyNum)
	{
		return MF_FAILED;
	}
	else
	{
		if(m_bKeyType[nIndex] == MF_SYS_FIELDTYPE_INT || m_bKeyType[nIndex] == MF_SYS_FIELDTYPE_BIGINT)
		{
			varData.SetData(lpMultiKey->m_pKey[nIndex].m_llData);
		}
		else if(m_bKeyType[nIndex] == MF_SYS_FIELDTYPE_DOUBLE || m_bKeyType[nIndex] == MF_SYS_FIELDTYPE_DATE)
		{
			varData.SetData(lpMultiKey->m_pKey[nIndex].m_dblData, MF_VARDATA_DOUBLE);
		}
		else
		{
			return MF_FAILED;
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			设置叶子结点数据
		参数说明：
			lpLeaveData：叶子结点数据
			lpMultiIndex：复合索引
			nDataID：数据ID
************************************************************************/
void CMemoryMultiNum::SetLeaveData(LPVOID lpLeaveData, LPMULTIINDEX lpMultiIndex, long long nDataID)
{
	int n;
	LPMULTIKEY lpMultiKey;
	LPINDEXCONDITION lpIndexField;

	lpMultiKey = &((LPLEAVESTRUCT)lpLeaveData)->m_stuKey;
	for(n = 0; n < (int)lpMultiIndex->m_nIndexNum; n++)
	{
		lpIndexField = &lpMultiIndex->m_lpIndexCondition[n];
		switch(lpIndexField->m_varCondition2.m_vt)
		{
		case MF_SYS_FIELDTYPE_INT:
		case MF_SYS_FIELDTYPE_BIGINT:
			lpMultiKey->m_pKey[n].m_llData	= lpIndexField->m_varCondition2.m_llValue;
			break;
		case MF_SYS_FIELDTYPE_DOUBLE:
		case MF_SYS_FIELDTYPE_DATE:  
			lpMultiKey->m_pKey[n].m_dblData	= lpIndexField->m_varCondition2.m_dblValue;
			break;
		}
	}
}

/************************************************************************
		功能说明：
			从树干结构体中获取值，即结点编号
		参数说明：
			lpTrunkData：树干结点数据
************************************************************************/
int CMemoryMultiNum::GetNodeNoFromTrunk(LPVOID lpTrunkData)
{
	return ((LPTRUNKSTRUCT)lpTrunkData)->m_nNodeNo;
}
	
/************************************************************************
		功能说明：
			在树干树干中设置节点编号
		参数说明：
			lpTrunkData：树干结点数据
			nNodeNo：结点编号
************************************************************************/
void CMemoryMultiNum::SetNodeNoToTrunk(LPVOID lpTrunkData, int nNodeNo) 
{
	((LPTRUNKSTRUCT)lpTrunkData)->m_nNodeNo = nNodeNo;
}

/************************************************************************
		功能说明：
			设置树干结点数据
		参数说明：
			lpTrunkData：树干结点数据
			lpMultiIndex：复合索引
			nDataID：数据ID
************************************************************************/
void CMemoryMultiNum::SetTrunkData(LPVOID lpTrunkData, LPMULTIINDEX lpMultiIndex, int nNodeNo)
{
	int n;
	LPMULTIKEY lpMultiKey;
	LPINDEXCONDITION lpIndexField;

	lpMultiKey = &((LPTRUNKSTRUCT)lpTrunkData)->m_stuMaxKey;
	for(n = 0; n < (int)lpMultiIndex->m_nIndexNum; n++)
	{
		lpIndexField = &lpMultiIndex->m_lpIndexCondition[n];
		switch(lpIndexField->m_varCondition2.m_vt)
		{
		case MF_SYS_FIELDTYPE_INT:
		case MF_SYS_FIELDTYPE_BIGINT:
			lpMultiKey->m_pKey[n].m_llData = lpIndexField->m_varCondition2.m_llValue;
			break;
		case MF_SYS_FIELDTYPE_DOUBLE:
		case MF_SYS_FIELDTYPE_DATE:  
			lpMultiKey->m_pKey[n].m_dblData  = lpIndexField->m_varCondition2.m_dblValue;
			break;
		}
	}
	((LPTRUNKSTRUCT)lpTrunkData)->m_nNodeNo = nNodeNo;
}

/************************************************************************
		功能说明：
			设置索引字段数据
		参数说明：
			lpMultiIndex：复合索引
			lpKey：关键字
************************************************************************/
void CMemoryMultiNum::SetIndexField(LPMULTIINDEX lpMultiIndex, LPVOID lpKey)
{
	int n;
	LPMULTIKEY lpMultiKey;
	LPINDEXCONDITION lpIndexField;
	lpMultiKey = (LPMULTIKEY)lpKey;
	for(n = 0; n < (int)lpMultiIndex->m_nIndexNum; n++)
	{
		lpIndexField = &lpMultiIndex->m_lpIndexCondition[n];
		switch(m_bKeyType[n])
		{
		case MF_SYS_FIELDTYPE_INT:
		case MF_SYS_FIELDTYPE_BIGINT:
			lpIndexField->m_varCondition2.SetData(lpMultiKey->m_pKey[n].m_llData);
			break;
		case MF_SYS_FIELDTYPE_DOUBLE:
		case MF_SYS_FIELDTYPE_DATE:
			lpIndexField->m_varCondition2.SetData(lpMultiKey->m_pKey[n].m_dblData, MF_VARDATA_DOUBLE);
			break;

		}
	}
}
	
/************************************************************************
		功能说明：
			比较函数
		参数说明：
			lpMultiIndex：复合索引
			lpKey：关键字
			bOperator：操作类型
			bFindKey：是否有相同关键字
************************************************************************/
int CMemoryMultiNum::Compare(LPMULTIINDEX lpMultiIndex, LPVOID lpKey, BYTE bOperator, BOOL& bFindKey)
{
	int i;
	VARDATA varData;
	LPMULTIKEY lpMultiKey;
	LPINDEXCONDITION lpIndexCondition;

	lpMultiKey = (LPMULTIKEY)lpKey;
	for(i = 0; i < (int)lpMultiIndex->m_nIndexNum; i++)
	{
		if(bOperator == OPERATOR_INSERT && i + 1 >= lpMultiIndex->m_nIndexNum)
		{
			bFindKey = TRUE;		//对于Insert情况，最后一个字段(DataID)不参与关键字的比较
		}
		lpIndexCondition = &lpMultiIndex->m_lpIndexCondition[i];
		if(bOperator == OPERATOR_INSERT)
		{
			varData.SetData(lpIndexCondition->m_varCondition2);
		}
		else
		{
			varData.SetData(lpIndexCondition->m_varCondition1);
		}

		switch(lpIndexCondition->m_bFieldType)
		{
		case MF_SYS_FIELDTYPE_INT:
			if(varData.m_nValue > lpMultiKey->m_pKey[i].m_llData)
			{
				return 1;
			}
			if(varData.m_nValue < lpMultiKey->m_pKey[i].m_llData)
			{
				return -1;
			}
			break;
		case MF_SYS_FIELDTYPE_BIGINT:
			if(varData.m_llValue > lpMultiKey->m_pKey[i].m_llData)
			{
				return 1;
			}
			if(varData.m_llValue < lpMultiKey->m_pKey[i].m_llData)
			{
				return -1;
			}
			break;
		case MF_SYS_FIELDTYPE_DOUBLE:
		case MF_SYS_FIELDTYPE_DATE:
			if(varData.m_dblValue > lpMultiKey->m_pKey[i].m_dblData)
			{
				return 1;
			}
			if(varData.m_dblValue < lpMultiKey->m_pKey[i].m_dblData)
			{
				return -1;
			}
			break;
		}

		if(lpIndexCondition->m_bOperator != MF_EXECUTEPLAN_OPERATOR_EQUAL)
		{
			break;
		}
	}

	bFindKey = TRUE;
	return 0;
}
	
/************************************************************************
		功能说明：
			判断值是否合法
		参数说明：
			lpIndexInfo：索引信息
			lpKey：关键字
			nLevel：递归层数
			bContinue：是否可以继续循环
			bPush：是否可以Push数据ID
************************************************************************/
void CMemoryMultiNum::CheckDataValid(LPINDEXINFO lpIndexInfo, LPVOID lpKey, int nLevel, BOOL& bContinue, BOOL& bPush)
{
	int n;
	BOOL bCheck;
	VARDATA varKey;
	LPINDEXCONDITION lpIndexField;
	MF_EXECUTEPLAN_OPERATOR bOperator;
     
	bCheck			= TRUE;
	bContinue		= TRUE;
	bPush			= FALSE;
	for(n = 0; n < (int)lpIndexInfo->m_stMultiIndex.m_nIndexNum; n++)
	{
		GetKeyValue(lpKey, n, varKey);
		lpIndexField = &lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[n];
		bOperator	 = lpIndexField->m_bOperator;
		switch(bOperator)
		{
		case MF_EXECUTEPLAN_OPERATOR_EQUAL:
			if(varKey != lpIndexField->m_varCondition1)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_NOTEQUAL:
			if(varKey == lpIndexField->m_varCondition1)
			{
				bCheck	  = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_GREATER:
			if(varKey <= lpIndexField->m_varCondition1)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
			if(varKey < lpIndexField->m_varCondition1)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_LESS:
			if(varKey >= lpIndexField->m_varCondition1)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
			if(varKey > lpIndexField->m_varCondition1)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEEN:
			if(varKey > lpIndexField->m_varCondition2)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			else if(varKey < lpIndexField->m_varCondition1)
			{
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
			if(varKey > lpIndexField->m_varCondition2)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			else if(varKey <= lpIndexField->m_varCondition1)
			{
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENE:
			if(varKey >= lpIndexField->m_varCondition2)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			else if(varKey < lpIndexField->m_varCondition1)
			{
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENBE:
			if(varKey >= lpIndexField->m_varCondition2)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			else if(varKey <= lpIndexField->m_varCondition1)
			{
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_IN:
			{
				int *lpHashTable, nHashTableOffset;
				nHashTableOffset = lpIndexField->m_varCondition2.m_nValue;
				lpHashTable		 = (int*)lpIndexInfo->m_pBson->ConvertOffset2Addr(nHashTableOffset);
				if(!varKey.In(lpIndexInfo->m_pBson, lpHashTable, lpIndexField->m_varCondition1.m_nValue))
				{
					bCheck = FALSE;
				}
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_NOTIN:
			{
				int *lpHashTable, nHashTableOffset;
				nHashTableOffset = lpIndexField->m_varCondition2.m_nValue;
				lpHashTable		 = (int*)lpIndexInfo->m_pBson->ConvertOffset2Addr(nHashTableOffset);
				if(varKey.In(lpIndexInfo->m_pBson, lpHashTable, lpIndexField->m_varCondition1.m_nValue))
				{
					bCheck = FALSE;
				}
			}
			break;
		}

		if(!bContinue || !bCheck)
		{
			break;
		}
	}
	
	if(bCheck)
	{
		if(!lpIndexInfo->m_pCheck || lpIndexInfo->m_pCheck->CheckRecordValid(lpIndexInfo->m_nDataID))
		{
			if(lpIndexInfo->m_bPagingType == MF_PAGING_FIRST)
			{
				if(lpIndexInfo->m_nCount >= lpIndexInfo->m_nPagePos)
				{
					bPush = TRUE;
				}
				lpIndexInfo->m_nCount++;
			}
			else
			{
				bPush = TRUE;
			}
		}
	}
}
/************************************************************************
		功能说明:
			初始化块头
			判断值是否合法
		参数说明：
			lpNodeHead：结点头
			nDataSize：数据大小
			nHeadSize：结点头大小
			nNodeTypeFlag：结点类型
************************************************************************/
void CMemoryMultiNum::InitialBlock(LPVOID lpNodeHead, int nDataSize, int nHeadSize, BYTE nNodeTypeFlag)
{
	int nKeySize, i;
	LPMULTINODEHEAD lpMultiNodeHead;

	if(nNodeTypeFlag == LEAVENODE)
	{
		nKeySize = nDataSize - sizeof(long long);
	}
	else
	{
		nKeySize = nDataSize - sizeof(int);
	}
	lpMultiNodeHead = (LPMULTINODEHEAD)lpNodeHead;
	
	lpMultiNodeHead->m_nBlockHeadSize	= nHeadSize;
	lpMultiNodeHead->m_bNodeType		= nNodeTypeFlag;
	lpMultiNodeHead->m_nDataSize		= nDataSize;
	lpMultiNodeHead->m_nTotalDataNum	= (lpMultiNodeHead->m_nBlockSize - nHeadSize) / nDataSize;
	lpMultiNodeHead->m_nTotalDataNum	= lpMultiNodeHead->m_nTotalDataNum / 2 * 2;			//变为2的整数倍
	lpMultiNodeHead->m_nDataNum			= 0;	
	lpMultiNodeHead->m_nNextNodeNo		= 0;
	lpMultiNodeHead->m_nPreNodeNo		= 0;
	for(i = 0; i < m_bKeyNum; i++)
	{
		if(m_bKeyType[i] == MF_SYS_FIELDTYPE_INT || m_bKeyType[i] == MF_SYS_FIELDTYPE_BIGINT)
		{
			lpMultiNodeHead->m_stuMaxKey.m_pKey[i].m_llData  = MAXLONGLONG;
		}
		else if(m_bKeyType[i] == MF_SYS_FIELDTYPE_DOUBLE || m_bKeyType[i] == MF_SYS_FIELDTYPE_DATE)
		{
			lpMultiNodeHead->m_stuMaxKey.m_pKey[i].m_dblData = DBL_MAX;
		}
	}
}
