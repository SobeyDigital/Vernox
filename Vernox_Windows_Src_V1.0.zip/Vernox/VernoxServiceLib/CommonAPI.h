﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
//获取系统时间戳，此方式主要用于查询使用，它的作用就是让查询能够获取到正确的数据，未完成的时间戳是不可见的
long long GetSystemTimestamp();
void SetSystemTimestamp(long long nTimestamp);

//设置锁定状态，内部采用临界区实现，保证只有一个线程修改数据的可能性
//内部自动管理锁状态的释放，但需要手动调Lock
class CSystemLockStateManage
{
public:
	CSystemLockStateManage();
	~CSystemLockStateManage(void);
private:
	MF_LOCK_TYPE		m_bLockType;				//锁类型
	LPEXECUTEPLANBSON	m_lpExecutePlan;			//执行计划
	LPVOID				m_lpLockObject;				//锁定对象
public:
	//初始化
	inline void Inital(MF_LOCK_TYPE bLockType, LPEXECUTEPLANBSON lpExecutePlan, LPVOID lpLockObject)
	{
		m_bLockType		 = bLockType;
		m_lpExecutePlan	 = lpExecutePlan;
		m_lpLockObject   = lpLockObject;
	}
	//bStatus表示需要设置的锁状态，目前推荐使用MF_LOCK_STATUS_MUTEX；
	//dwMilliseconds表示等待的微秒数，目前推荐使用MF_LOCK_OUTOFTIME，如果为0表示直接返回锁结果，否则如果锁失败就会在规定时间内尝试锁正确，超时的情况下锁失败也返回
	BOOL Lock(MF_LOCK_STATUS_TYPE bStatus, DWORD dwMilliseconds, long long nTimestamp);
};

//获取事务性时间戳，此方法主要用于申请有数据修改的时间戳，内部自带一个开始和结束时间戳
class CSystemTimestampTransactionManage
{
public:
	CSystemTimestampTransactionManage();
	virtual ~CSystemTimestampTransactionManage(void);
	void StartTransaction(long long nTimestamp);
	void CommitTransaction(long long nTimestamp);
};



//写日志通用函数，理论上日志内容不超过2MB为宜，如果需要写大日志，请调其他函数
void Trace0(LPCSTR szFuncationName, LONG  lLogLevel, LONG lLogErrorCode, LPCSTR szLog);
//写日志的同时，把传入数据按照规则进行格式化，这里的格式化是为了方便大家写日志，所申请的空间也很小，建议所有格式化的内容不超过20KB，否则可能引起崩溃
void Trace(LPCSTR szFuncationName, LONG  lLogLevel, LONG lLogErrorCode, const char *fmt, ... );
//获取系统参数
int  GetSystemParameterValue(MF_PARAMETER_TYPE nParameterName);
//释放临时内存
void FreeSystemTemporaryMemory(LPBYTE lpBuf);

//从LPMATHEXPFIELDBSON中获取字段值
int GetDataValue(LPMATHEXPELEMENTBSON lpFieldBson, VARDATA& stuVarData);

//去掉百分号
void RemovePercent(char* pStr, int nLen, VARDATA& varData);

//设置临界资源值
void SetCriticalValue(LPVOID pSrc, LPVOID pDest, int nSize, LPCRITICAL_SECTION cs);

//获取临界资源值
void GetCriticalValue(LPVOID pSrc, long long& nValue, int nSize, LPCRITICAL_SECTION cs);