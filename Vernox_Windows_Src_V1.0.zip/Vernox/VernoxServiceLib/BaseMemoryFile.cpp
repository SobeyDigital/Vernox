﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "BaseMemoryFile.h"

//////////////////////////////////////////////////////////////////////////////////////////////
//								日志定义													//
//																							//
//     日志等级请参见MF_TRACE_LEVEL系列的宏定义，日志错误码建议每条日志都独立一个编码，按此 //
//思路，对于每个函数都会有一个错误码的范围。文件占3位，函数占3位，函数内编码占3位			//
//     此文件的日志错误码定义为101000000～101999000，请按照函数的先后顺序合理申请错误码，当 //
//前使用最大的错误码为：																	//
//																							//
//																				  吴春中	//
//																				  2014-9-5  //
//////////////////////////////////////////////////////////////////////////////////////////////

CBaseMemoryFile::CBaseMemoryFile(void)
{
	m_lpFileAddr     = NULL;
	m_nMemoryFileID = NULL;
	m_pSystemManage = NULL;
}

CBaseMemoryFile::~CBaseMemoryFile(void)
{
}

int CBaseMemoryFile::Open(LPMEMDBFILEDEF lpMemDBFileDef)
{
	LPBYTE pFileAddr;
	LPBASEFILEHEAD lpFileHead;
	if(CShareMemory::ShareMemoryExsist(m_nMemoryFileID))
	{
		Trace("CBaseMemoryFile::Open", MF_TRACE_LEVEL_FAILED, 101000000, "内存文件已经打开，是否重复打开呢？内存文件名：%s", lpMemDBFileDef->m_lpszMemFileName);
		return MF_OK;
	}

	//打开共享内存
	m_nMemoryFileID = CShareMemory::OpenShareMemory((key_t)(lpMemDBFileDef->m_bFileNo + MF_MEMFILE_BASEKEY), lpMemDBFileDef->m_lpszMemFileName);
	if(!CShareMemory::GetShareMemorySuccess(m_nMemoryFileID))
	{
		//内存指针为空，打开失败！
		Trace("CBaseMemoryFile::Open", MF_TRACE_LEVEL_FAILED, 101000001, "打开内存文件失败，错误码：%d，内存文件名：%s", GetLastError(), lpMemDBFileDef->m_lpszMemFileName);
		return MF_INNER_OPENMEMFILE_FAILED;
	}
	pFileAddr = (LPBYTE)CShareMemory::ShMemAttach(m_nMemoryFileID);
	if (pFileAddr == NULL)
	{
		//映射内存失败
		Trace("CBaseMemoryFile::Open", MF_TRACE_LEVEL_FAILED, 101000002, "打开内存文件，然后映射操作内存地址失败，错误码：%d，内存文件名：%s", GetLastError(), lpMemDBFileDef->m_lpszMemFileName);
		CShareMemory::CloseShareMemory(m_nMemoryFileID);
		return MF_INNER_MAPMEMFILE_FAILED;
	}
	m_lpFileAddr = pFileAddr;
	lpFileHead = (LPBASEFILEHEAD)pFileAddr;
	if(lpMemDBFileDef->m_bFileType == MF_SYS_FILETYPE_DATAFILE)
	{
		if(lpFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'D', 'F'))
		{
			Trace("CBaseMemoryFile::Open", MF_TRACE_LEVEL_FAILED, 101000003, "打开内存文件，读取到的数据文件头不正确，数据可能已经损坏！文件路径：%s", lpMemDBFileDef->m_lpszFilePath);
			CShareMemory::ShMemDetach(pFileAddr);
			CShareMemory::CloseShareMemory(m_nMemoryFileID);
			return MF_INNER_MAPMEMFILE_FAILED;
		}
	}
	else if(lpMemDBFileDef->m_bFileType == MF_SYS_FILETYPE_TREEINDEXFILE)
	{
		if(lpFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'B', 'F'))
		{
			Trace("CBaseMemoryFile::Open", MF_TRACE_LEVEL_FAILED, 101000004, "打开内存文件，读取到的B树索引文件头不正确，数据可能已经损坏！文件路径：%s", lpMemDBFileDef->m_lpszFilePath);
			CShareMemory::ShMemDetach(pFileAddr);
			CShareMemory::CloseShareMemory(m_nMemoryFileID);
			return MF_INNER_MAPMEMFILE_FAILED;
		}
	}
	else if(lpMemDBFileDef->m_bFileType == MF_SYS_FILETYPE_KVINDEXFILE)
	{
		if(lpFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'H', 'F'))
		{
			Trace("CBaseMemoryFile::Open", MF_TRACE_LEVEL_FAILED, 101000005, "打开内存文件，读取到的KV索引文件头不正确，数据可能已经损坏！文件路径：%s", lpMemDBFileDef->m_lpszFilePath);
			CShareMemory::ShMemDetach(pFileAddr);
			CShareMemory::CloseShareMemory(m_nMemoryFileID);
			return MF_INNER_MAPMEMFILE_FAILED;
		}
	}
	return SetFileAddr(pFileAddr);	//调SetFileAddr函数进行内部初始化
}

int CBaseMemoryFile::Close()
{
	if(m_lpFileAddr != NULL)
	{
		CShareMemory::ShMemDetach(m_lpFileAddr);
	}
	if(CShareMemory::ShareMemoryExsist(m_nMemoryFileID))
	{
		CShareMemory::CloseShareMemory(m_nMemoryFileID);
	}
	delete this;
	return MF_OK;
}

int CBaseMemoryFile::MergeMemory()
{
	return MF_OK;
}

int CBaseMemoryFile::CreateObject(int nID, int nBlockSize, MF_SYS_INDEXTYPE bType, int nDataNum)
{
	return MF_OK;
}


