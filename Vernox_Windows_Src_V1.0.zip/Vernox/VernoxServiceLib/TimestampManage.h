﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#define MF_TIMESTAMP_TRANSACTION_STATE_START                            1   //时间戳事务开始状态
#define MF_TIMESTAMP_TRANSACTION_STATE_FINISH                           2   //时间戳事务结束状态
class CTimestampManage
{
private:
	//修改事务
	typedef struct st_Timestamp_Transaction
	{
		long long					m_nCurTimestampVal;		//时间戳
		int							m_nState;				//事务状态，1：事务进行中，2：事务结束可以写入磁盘保存了
		st_Timestamp_Transaction*   m_pNext;				//下一个
	}TIMESTAMP_TRANSACTION, *LPTIMESTAMP_TRANSACTION;

private:
	CTimestampManage();
	CTimestampManage(const CTimestampManage &);
	CTimestampManage & operator = (const CTimestampManage &);
	virtual ~CTimestampManage(void);
	static CTimestampManage * m_pSinstance;
	static CTimestampManage & instance();
	friend class CSystemManage;
	friend class CSystemTimestampTransactionManage;
	friend class CSystemLockStateManage;
	friend long long GetSystemTimestamp();
	friend void SetSystemTimestamp(long long nTimestamp);
	friend BOOL CheckSystemTimestampFinishFlag(long long nTimestamp);

private:
	CRITICAL_SECTION		m_critTimestamp;				//时间戳临界区，由于时间戳使用最频繁
	CRITICAL_SECTION		m_critTranaction;				//事务资源临界区

	long long				m_nCurTimestampVal;				//当前时间戳，在系统初始化时会设置此值，我们必须保证时间戳的先后顺序，即使系统时间做调整
	
	//系统文件头，此类中主要维护时间戳的当前可保存的值
	LPSYSTEMFILEHEAD		m_lpMemoryFileHead;

	//管理时间戳，主要是修改时间戳的管理
	LPTIMESTAMP_TRANSACTION m_lpTimestampTransactionHead; //指针头
	LPTIMESTAMP_TRANSACTION m_lpTimestampTransactionTail; //指针尾

	TIMESTAMP_TRANSACTION	m_arTimestampTransaction[256];	//TIMESTAMP_TRANSACTION数组

private:
	//设置系统文件头指针给此实例
	void SetSystemFileHead(LPSYSTEMFILEHEAD lpFileHead);

	//获取一个时间戳，保证每次能够给应用程序返回一个和时间相关的一个数值
	//时间戳的原理使用Windows下最精确也是最快的函数（GetSystemTimeAsFileTime）获取基于1970年到现在的时间差，数量级为100ns，但限制于Windows的任务分片机制导致在15～16毫秒以内取出来的数据不会变（据有人实验每次变化的量为156250），
	//我这里采取的办法就是先记录一个最后一次获取时间戳，如果没有跳变的话，我们就手动去增加1的方式来实现每一次请求的数据都不一样，由于考虑到设计业务量和此数本身值的原因，目前设计为取出来的数据直接乘以4（移2位），这样就相当于每15.6毫秒可以容纳625000个数，这个数量级完全达到系统设计的最大吞出量。
	long long GetTimestamp();
	
	//设置时间戳
	void SetTimestamp(long long llTimestamp);

	//开启事务
	void StartTransaction(long long nTimestamp);

	//事务时间戳完成函数，事务结束后，相关的修改就可以写入硬盘进行持久化保存
	void TimestampTransactionFinish(long long nCurTimestampVal);

	//检查时间戳是否还正在处理状态
	BOOL CheckFinishFlag(long long nTimestamp);

	//判断是否还有活动事务
	BOOL CheckTransactionActive();
	
	//备份事务链表
	int SetTransactionLine(CServiceBson& stBson, long long nTimestamp, UINT& nTransactionOffset, int& nTransactionNum);

	//获取事务资源
	void GetTractionStruct(LPTIMESTAMP_TRANSACTION& lpTransaction);

	//释放事务资源
	void ReleaseTractionStruct(LPTIMESTAMP_TRANSACTION lpTransaction);

public:
	static void DestoryInstance();
};
