﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "DataIDContainer.h"

CDataIDContainer::CDataIDContainer()
{
	m_bUnique		  			= FALSE; 
	m_nReocrdNum			    = 0;
	m_nCurrentBufferNo			= 0;
	m_lpCurrentBuffer			= NULL;
	m_nDefaultSectionSize	    = MF_BUFFERSECTION_SIZE;
}
CDataIDContainer::~CDataIDContainer()
{
}

//查找
BOOL CDataIDContainer::find(long long nDataID)
{
	int nRet;
	BOOL bFind;

	nRet = m_stMapDataID.Set(nDataID, bFind);
	if(nRet != MF_OK)
	{
		return FALSE;
	}
	else
	{
		return bFind;
	}
}

//清空DataID
void CDataIDContainer::clear()
{
	m_nCurrentBufferNo = 0;
	m_lpCurrentBuffer  = NULL;
}

CSysRecordContainer::CSysRecordContainer(CServiceBson* pBson)
{
	m_lpSingleRecord	 = NULL;
	m_nFirstRecordAddrID = 0;
	m_nReocrdNum		 = 0;
	m_nFirstRecordAddrID = 0;
	m_nCurrentBufferNo	 = 0;
	m_lpCurrentBuffer	 = NULL;
	m_pServiceBson		 = pBson;
}

CSysRecordContainer::~CSysRecordContainer()
{

}

int CSysRecordContainer::AllocSingleRecord(LPSINGLERECORD& lpSingleRecord, int nFieldNum)
{
	LPBYTE lpAddr;
	int nRet, nSize;
	UINT nAddrID, nCurrentBufferNo;

	nCurrentBufferNo = m_nCurrentBufferNo;
	
	nSize	= sizeof(SINGLERECORD) + (nFieldNum - 1)*sizeof(VARDATA);
	lpAddr  = NULL;
	nRet = m_pServiceBson->AllocFromBufferSection(nSize, nAddrID, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpSingleRecord = (LPSINGLERECORD)lpAddr;
	lpSingleRecord->m_nFieldNum	  = nFieldNum;
	lpSingleRecord->m_nSize		  = nSize;
	lpSingleRecord->m_bValid	  = 0;
	lpSingleRecord->m_bEnd		  = 0;
	
	m_nCurrentBufferNo			  = (USHORT)(nAddrID >> 16);
	//判断是否切换到了下一个块
	if(nCurrentBufferNo != m_nCurrentBufferNo && m_lpSingleRecord != NULL)
	{
		m_lpSingleRecord->m_bEnd = 1;
	}

	if(m_nFirstRecordAddrID == 0)
	{
		m_nFirstRecordAddrID = nAddrID;
	}
	m_nReocrdNum++;
	m_lpSingleRecord = lpSingleRecord;	 //用于记录上一条记录
	return MF_OK;
}

//移动到DataID的起始位置
void CSysRecordContainer::MoveFirst()
{
	if(m_nReocrdNum != 0 && m_nFirstRecordAddrID != 0)
	{
		m_nCurrentBufferNo = (USHORT)(m_nFirstRecordAddrID >> 16);
		m_lpCurrentBuffer  = m_pServiceBson->GetBufferSection(m_nCurrentBufferNo);
		m_lpSingleRecord   = (LPSINGLERECORD)(m_lpCurrentBuffer + (USHORT)m_nFirstRecordAddrID);
	}
}

int CSysRecordContainer::NextRecord(LPSINGLERECORD& lpSingleRecord)
{
	lpSingleRecord = m_lpSingleRecord;
	if(lpSingleRecord == NULL)
	{
		return MF_OK;
	}
	if(lpSingleRecord->m_bEnd)
	{
		//切换到下一个缓存片段
		m_nCurrentBufferNo++;
		m_pServiceBson->GetSectionDataAddr(m_nCurrentBufferNo, m_lpCurrentBuffer);
		if(m_lpCurrentBuffer != NULL)
		{
			m_lpSingleRecord = (LPSINGLERECORD)m_lpCurrentBuffer;
		}
		else
		{
			m_lpSingleRecord = NULL;
		}
	}
	else
	{
		m_lpSingleRecord = (LPSINGLERECORD)((LPBYTE)m_lpSingleRecord + m_lpSingleRecord->m_nSize);
	}
	return MF_OK;
}