﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "ExecuteDataID.h"

CExecuteDataID::CExecuteDataID(CServiceBson* pServiceBson)
{
	m_nDataIDAddrID		= 0;
	m_nDataIDNum		= 0;
	m_nCurrentDataIDNo	= 0;
	m_pServiceBson		= pServiceBson;
	m_lpRecordHead		= NULL;
}

CExecuteDataID::~CExecuteDataID(void)
{
}

int CExecuteDataID::push_back(long long nDataID)
{
	int nRet;
	BOOL bFind;
	UINT nAddrID;
	LPRECORDHEAD lpRecordHead;
	
	if(m_bUnique)
	{
		nRet = m_stMapDataID.Set(nDataID, bFind);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		else if(bFind)
		{
			return MF_OK;	
		}
	}

	nRet = m_pServiceBson->AllocRecord(lpRecordHead, nAddrID);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(m_nDataIDAddrID == 0)
	{
		m_nDataIDAddrID = nAddrID;
	}
	
	lpRecordHead->m_nDataID = nDataID;
	
	m_nDataIDNum++;
	return MF_OK;
}

void CExecuteDataID::clear()
{
	CDataIDContainer::clear();
	
	m_nDataIDNum		= 0;
	m_nDataIDAddrID		= 0;
	m_nCurrentDataIDNo	= 0;
}

//移动到DataID的起始位置
void CExecuteDataID::MoveFirst()
{
	if(m_nDataIDNum != 0 && m_nDataIDAddrID != 0)
	{
		m_nCurrentBufferNo = (USHORT)(m_nDataIDAddrID >> 16);
		m_lpCurrentBuffer  = m_pServiceBson->GetBufferSection(m_nCurrentBufferNo);
		m_lpRecordHead     = (LPRECORDHEAD)(m_lpCurrentBuffer + (USHORT)m_nDataIDAddrID);
	}
	else
	{
		m_lpCurrentBuffer  = NULL;
		m_lpRecordHead	   = NULL;
	}
	m_nCurrentDataIDNo = 0;
}

//下一条DataID
int CExecuteDataID::NextDataID(long long& nDataID)
{
	if(m_nDataIDNum == 0 || m_nCurrentDataIDNo > m_nDataIDNum)
	{
		nDataID = 0;
	}
	else
	{
		nDataID = m_lpRecordHead->m_nDataID;
		if(m_lpRecordHead->m_bLast)
		{
			//切换到下一个缓存片段
			m_nCurrentBufferNo++;
			m_pServiceBson->GetSectionDataAddr(m_nCurrentBufferNo, m_lpCurrentBuffer);
			if(m_lpCurrentBuffer != NULL)
			{
				m_lpRecordHead = (LPRECORDHEAD)m_lpCurrentBuffer;
			}
			else
			{
				m_lpRecordHead = NULL;
			}
		}
		else
		{
			m_lpRecordHead++;
		}
		m_nCurrentDataIDNo++;
	}
	return MF_OK;
}

//弹出DataID
long long CExecuteDataID::PopDataID()
{
	long long nDataID;
	LPRECORDHEAD lpRecordHead;
	USHORT nSectionNo, nOffset;
	
	MoveFirst();
	NextRecordHead(lpRecordHead);
	
	if(lpRecordHead == NULL)
	{
		return 0;
	}
	nDataID	   = lpRecordHead->m_nDataID;
	
	nSectionNo = (USHORT)(m_nDataIDAddrID >> 16);
	nOffset	   = (USHORT)m_nDataIDAddrID;
	if(lpRecordHead->m_bLast)
	{
		nSectionNo++;

	}
	else
	{
		nOffset+=sizeof(RECORDHEAD);
	}
	m_nDataIDAddrID	= nSectionNo;
	m_nDataIDAddrID = (m_nDataIDAddrID << 16) + nOffset;

	m_nDataIDNum--;
	return nDataID;
}
int CExecuteDataID::NextRecordHead(LPRECORDHEAD& lpRecordHead)
{
	if(m_nDataIDNum == 0 || m_nCurrentBufferNo > m_nDataIDNum)
	{
		lpRecordHead = NULL;
	}
	else
	{
		lpRecordHead = m_lpRecordHead;
		if(lpRecordHead->m_bLast)
		{
			//切换到下一个缓存片段
			m_nCurrentBufferNo++;
			m_pServiceBson->GetSectionDataAddr(m_nCurrentBufferNo, m_lpCurrentBuffer);
			if(m_lpCurrentBuffer != NULL)
			{
				m_lpRecordHead = (LPRECORDHEAD)m_lpCurrentBuffer;
			}
			else
			{
				m_lpRecordHead = NULL;
			}
		}
		else
		{
			m_lpRecordHead++;
		}
	}
	return MF_OK;
}