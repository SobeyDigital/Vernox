﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "Expression.h"
#include "IndexSelector.h"
#include "MemoryBTreeFile.h"
#include "MemoryFile.h"
CIndexSelector::CIndexSelector(CServiceBson* pServiceBson)
{
	m_nIndexPlanOffset	= 0;
	m_pServiceBson		= pServiceBson;
	m_lpObjectInfo		= NULL;
	m_lpCondition		= NULL;
	m_lpQueryField		= NULL;
	m_nTotalDataNum	    = 0;
	m_nScanRowNum		= 0;	
	m_bQueryPlanType	= 0;
	m_nLogicAndNum		= 0;
	m_nLogicORNum		= 0;
	m_nLogicBeforNotNum	= 0;
}
CIndexSelector::~CIndexSelector(void)
{
}

/************************************************************************
	功能说明：
		反转运算符
	参数说明：
		bOpSrc：原始运算符
		bOpDest：结果运算符
	特别说明：
		由于索引条件统一为Field > Value这样的形式，所以如果原始查询条件是Value =< Field这样的形式，那么需要将其修改为Field > Value，
		这个就意味着需要将原始的>符号反转为<符号
************************************************************************/
void CIndexSelector::ReverseOp(MF_EXECUTEPLAN_OPERATOR bOpSrc, MF_EXECUTEPLAN_OPERATOR& bOpDest)
{
	switch(bOpSrc)
	{
	case MF_EXECUTEPLAN_OPERATOR_GREATER:
		bOpDest = MF_EXECUTEPLAN_OPERATOR_LESSEQUAL;
		break;
	case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
		bOpDest = MF_EXECUTEPLAN_OPERATOR_LESS;
		break;
	case MF_EXECUTEPLAN_OPERATOR_LESS:
		bOpDest = MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL;
		break;
	case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
		bOpDest = MF_EXECUTEPLAN_OPERATOR_GREATER;
		break;
	default:
		bOpDest = bOpSrc;
	}
}

BOOL CIndexSelector::ReverseOp(MF_EXECUTEPLAN_OPERATOR bOpSrc, MF_EXECUTEPLAN_OPERATOR& bOpDest, BYTE bLogicNot)
{
	if(!bLogicNot)
	{
		bOpDest = bOpSrc;
	}
	else
	{
		switch(bOpSrc)
		{
		case MF_EXECUTEPLAN_OPERATOR_EQUAL:
			bOpDest = MF_EXECUTEPLAN_OPERATOR_NOTEQUAL;
			break;
		case MF_EXECUTEPLAN_OPERATOR_NOTEQUAL:
			bOpDest = MF_EXECUTEPLAN_OPERATOR_EQUAL;
			break;
		case MF_EXECUTEPLAN_OPERATOR_GREATER:
			bOpDest = MF_EXECUTEPLAN_OPERATOR_LESSEQUAL;
			break;
		case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
			bOpDest = MF_EXECUTEPLAN_OPERATOR_LESS;
			break;
		case MF_EXECUTEPLAN_OPERATOR_LESS:
			bOpDest = MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL;
			break;
		case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
			bOpDest = MF_EXECUTEPLAN_OPERATOR_GREATER;
			break;

		default:
			return FALSE;
		}
	}
	return TRUE;
}

/************************************************************************
	功能说明：
		结合OR运算符的索引条件
	参数说明
		lpSubIndexPlan1：子索引条件1
		lpSubIndexPlan2：子索引条件2
		bInvalidPlan：无效条件（如果条件1和条件2存在包含关系，则其中一个条件无效）
************************************************************************/
int CIndexSelector::CombineORSubPlan(LPSUBINDEXPLAN lpSubIndexPlan1, LPSUBINDEXPLAN lpSubIndexPlan2, BYTE& bInvalidPlan)
{
	int i;
	BYTE bTemp;
	LPINDEXCONDITION lpIndexCond1, lpIndexCond2;

	bInvalidPlan = 0;
	//判断子索引计划的字段是否相等
	if(lpSubIndexPlan1->m_bFieldNo[0] != lpSubIndexPlan2->m_bFieldNo[0] || lpSubIndexPlan1->m_bFieldNo[1] != lpSubIndexPlan2->m_bFieldNo[1] || lpSubIndexPlan1->m_bFieldNo[2] != lpSubIndexPlan2->m_bFieldNo[2] || lpSubIndexPlan1->m_bFieldNo[3] != lpSubIndexPlan2->m_bFieldNo[3])
	{
		return MF_OK;
	}
		
	//合并子索引计划
	for(i = 0; i < 4; i++)
	{
		if(lpSubIndexPlan1->m_ppCondition[i] == NULL || lpSubIndexPlan2->m_ppCondition[i] == NULL)
		{
			break;
		}
		lpIndexCond1 = &lpSubIndexPlan1->m_ppCondition[i]->m_stIndexCondition;
		lpIndexCond2 = &lpSubIndexPlan2->m_ppCondition[i]->m_stIndexCondition;

		if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_GREATER)
		{
			if(lpIndexCond2->m_bOperator == MF_EXECUTEPLAN_OPERATOR_GREATER || lpIndexCond2->m_bOperator == MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL)
			{
				if(lpIndexCond1->m_varCondition1 > lpIndexCond2->m_varCondition1)
				{
					//条件2无效
					bTemp = 2;
				}
				else
				{
					//条件1无效
					bTemp = 1;
				}
			}
			else
			{
				bTemp = 0;
			}
		}
		else if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL)
		{
			if(lpIndexCond2->m_bOperator == MF_EXECUTEPLAN_OPERATOR_GREATER || lpIndexCond2->m_bOperator == MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL)
			{
				if(lpIndexCond1->m_varCondition1 >= lpIndexCond2->m_varCondition1)
				{
					//条件2无效
					bTemp = 2;
				}
				else
				{
					//条件1无效
					bTemp = 1;
				}
			}
			else
			{
				bTemp = 0;
			}
		}
		else if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESS)
		{
			if(lpIndexCond2->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESS || lpIndexCond2->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESSEQUAL)
			{
				if(lpIndexCond1->m_varCondition1 < lpIndexCond2->m_varCondition1)
				{
					//条件2无效
					bTemp = 2;
				}
				else
				{
					//条件1无效
					bTemp = 1;
				}
			}
			else
			{
				bTemp = 0;
			}
		}
		else if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESSEQUAL)
		{
			if(lpIndexCond2->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESS || lpIndexCond2->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESSEQUAL)
			{
				if(lpIndexCond1->m_varCondition1 <= lpIndexCond2->m_varCondition1)
				{
					//条件2无效
					bTemp = 2;
				}
				else
				{
					//条件1无效
					bTemp = 1;
				}
			}
			else
			{
				bTemp = 0;
			}
		}
		
		if(bInvalidPlan == 0)
		{
			bInvalidPlan = bTemp;
		}
		else if(bInvalidPlan != bTemp)
		{
			//条件之间不存在包含关系
			bInvalidPlan = 0;
			break;
		}
	}
	return MF_OK;
}


/************************************************************************
	功能说明：
		结合AND运算符的索引条件
	参数说明：
		lpSubIndexPlan1：子索引条件1
		lpSubIndexPlan2：子索引条件2
		bInvalidPlan：无效条件（如果条件1和条件2存在包含关系，则其中一个条件无效）
************************************************************************/
int CIndexSelector::CombineANDSubPlan(LPSUBINDEXPLAN lpSubIndexPlan1, LPSUBINDEXPLAN lpSubIndexPlan2, BYTE& bInvalidPlan)
{
	int i;
	BYTE bIndexType;
	VARDATA stVarData;
	LPINDEXCONDITION lpIndexCond1, lpIndexCond2;

	bInvalidPlan = 0;
	//判断子索引计划的字段是否相等
	if(lpSubIndexPlan1->m_bFieldNo[0] != lpSubIndexPlan2->m_bFieldNo[0] || lpSubIndexPlan1->m_bFieldNo[1] != lpSubIndexPlan2->m_bFieldNo[1] || lpSubIndexPlan1->m_bFieldNo[2] != lpSubIndexPlan2->m_bFieldNo[2] || lpSubIndexPlan1->m_bFieldNo[3] != lpSubIndexPlan2->m_bFieldNo[3])
	{
		return MF_OK;
	}
	bIndexType = lpSubIndexPlan1->m_bIndexType;
	for(i = 0; i < 4; i++)
	{	
		if(lpSubIndexPlan1->m_ppCondition[i] == NULL && lpSubIndexPlan2->m_ppCondition[i] == NULL)
		{
			//两个索引的条件都为空，则直接continue
			continue;
		}
		else if(lpSubIndexPlan1->m_ppCondition[i] == NULL || lpSubIndexPlan2->m_ppCondition[i] == NULL)
		{
			//其中一个索引的条件为空，只有复合索引才可能出现这样的情况，统一将lpSubIndexPlan2向lpSubIndexPlan1结合
			if(bIndexType != MF_SYS_INDEXTYPE_TREE_MULTINUM && bIndexType != MF_SYS_INDEXTYPE_TREE_MULTISTR)
			{
				return MF_INDEXOPTIMIZER_INDEXCONDITION_ERROR;	
			}
			else if(lpSubIndexPlan1->m_ppCondition[i] == NULL)
			{
				lpSubIndexPlan1->m_ppCondition[i] = lpSubIndexPlan2->m_ppCondition[i];
			}
		}	
		else
		{
			//两个索引的条件都不为空，则判断是否具有包含关系，如果有则统一将lpSubIndexPlan2向lpSubIndexPlan1结合
			lpIndexCond1 = &lpSubIndexPlan1->m_ppCondition[i]->m_stIndexCondition;
			lpIndexCond2 = &lpSubIndexPlan2->m_ppCondition[i]->m_stIndexCondition;
			if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_GREATER)
			{
				switch(lpIndexCond2->m_bOperator)
				{
				case MF_EXECUTEPLAN_OPERATOR_GREATER:
				case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESS:
					lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENBE;		 //范围，相当于SQL的>和<运算
					lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
					lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENB;		 //范围，相当于SQL的>和<=运算
					lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
				case MF_EXECUTEPLAN_OPERATOR_BETWEENBE:
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}
					lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEEN: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					else
					{
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENB;
					}
					lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEENE: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					else
					{
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENBE;
					}
					lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					break;
				}
			}
			else if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL)
			{
				switch(lpIndexCond2->m_bOperator)
				{
				case MF_EXECUTEPLAN_OPERATOR_GREATER:
				case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
					if(lpIndexCond2->m_varCondition1 >= lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESS:
					lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENE;			//范围，相当于SQL的>=和<运算
					lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
					lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEEN;			//范围，相当于SQL的>=和<=运算
					lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEEN: 
				case MF_EXECUTEPLAN_OPERATOR_BETWEENE: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}
					lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
					if(lpIndexCond2->m_varCondition1 >= lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					else
					{
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEEN;
					}
					lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEENBE:  
					if(lpIndexCond2->m_varCondition1 >= lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					else
					{
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENE;
					}
					lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					break;
				}
			}
			else if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESS)
			{
				switch(lpIndexCond2->m_bOperator)
				{
				case MF_EXECUTEPLAN_OPERATOR_GREATER:
					lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENBE;			//范围，相当于SQL的>和<运算
					stVarData = lpIndexCond1->m_varCondition1;
					lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					lpIndexCond1->m_varCondition2.SetData(stVarData);
					break;
				case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
					lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENE;			//范围，相当于SQL的>=和<运算
					stVarData = lpIndexCond1->m_varCondition1;
					lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					lpIndexCond1->m_varCondition2.SetData(stVarData);
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESS:
				case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
					if(lpIndexCond2->m_varCondition1 < lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEENE: 
				case MF_EXECUTEPLAN_OPERATOR_BETWEENBE: 
					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition1)
					{
						stVarData.SetData(lpIndexCond2->m_varCondition2);
					}
					else
					{
						stVarData.SetData(lpIndexCond1->m_varCondition1);
					}
					lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					lpIndexCond1->m_varCondition2.SetData(stVarData);
					lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEEN:
					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition1)
					{
						stVarData.SetData(lpIndexCond2->m_varCondition2);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					else
					{
						stVarData.SetData(lpIndexCond1->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENE;
					}
					lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					lpIndexCond1->m_varCondition2.SetData(stVarData);
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition1)
					{
						stVarData.SetData(lpIndexCond2->m_varCondition2);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					else
					{
						stVarData.SetData(lpIndexCond1->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENBE;
					}
					lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					lpIndexCond1->m_varCondition2.SetData(stVarData);
					break;
				}
			}
			else if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESSEQUAL)
			{
				switch(lpIndexCond2->m_bOperator)
				{
				case MF_EXECUTEPLAN_OPERATOR_GREATER:
					lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENB;				//范围，相当于SQL的>和=<运算
					stVarData = lpIndexCond1->m_varCondition1;
					lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					lpIndexCond1->m_varCondition2.SetData(stVarData);
					break;
				case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
					lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEEN;				//范围，相当于SQL的>=和=<运算
					stVarData = lpIndexCond1->m_varCondition1;
					lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					lpIndexCond1->m_varCondition2.SetData(stVarData);
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESS:
				case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
					if(lpIndexCond1->m_varCondition1 <= lpIndexCond2->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEEN: 
				case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition1)
					{
						stVarData.SetData(lpIndexCond2->m_varCondition2);
					}
					else
					{
						stVarData.SetData(lpIndexCond1->m_varCondition1);
					}
					lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					lpIndexCond1->m_varCondition2.SetData(stVarData);
					lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEENE:
					if(lpIndexCond2->m_varCondition2 <= lpIndexCond1->m_varCondition1)
					{
						stVarData.SetData(lpIndexCond2->m_varCondition2);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					else
					{
						stVarData.SetData(lpIndexCond1->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEEN;
					}
					lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					lpIndexCond1->m_varCondition2.SetData(stVarData);
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEENBE: 
					if(lpIndexCond2->m_varCondition2 <= lpIndexCond1->m_varCondition1)
					{
						stVarData.SetData(lpIndexCond2->m_varCondition2);
						lpIndexCond1->m_bOperator = lpIndexCond2->m_bOperator;
					}
					else
					{
						stVarData.SetData(lpIndexCond1->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENB;
					}
					lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					lpIndexCond1->m_varCondition2.SetData(stVarData);
					break;
				}
			}
			else if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEEN)				// >=和<=
			{
				switch(lpIndexCond2->m_bOperator)
				{
				case MF_EXECUTEPLAN_OPERATOR_GREATER:
					if(lpIndexCond2->m_varCondition1 >= lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENB;
					}		
					break;
				case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESS:
					if(lpIndexCond2->m_varCondition1 <= lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENE;
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
					if(lpIndexCond2->m_varCondition1 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEEN: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
					if(lpIndexCond2->m_varCondition1 >= lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENB;
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENE: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}	

					if(lpIndexCond2->m_varCondition2 <= lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENE;
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENBE: 
					if(lpIndexCond2->m_varCondition1 >= lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENB;
					}	

					if(lpIndexCond2->m_varCondition2 <= lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
						if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENB)
						{
							lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENBE;
						}
						else
						{
							lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENE;
						}
					}	
					break;
				}
			}
			else if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENB)				//  >和<=
			{
				switch(lpIndexCond2->m_bOperator)
				{
				case MF_EXECUTEPLAN_OPERATOR_GREATER:
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}		
					break;
				case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEEN;
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESS:
					if(lpIndexCond2->m_varCondition1 <= lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENBE;
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
					if(lpIndexCond2->m_varCondition1 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEEN: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEEN;
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENE: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEEN;
					}	

					if(lpIndexCond2->m_varCondition2 <= lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
						if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEEN)
						{
							lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENE;
						}
						else
						{
							lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENBE;
						}
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENBE: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}	

					if(lpIndexCond2->m_varCondition2 <= lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENBE;
					}	
					break;
				}
			}
			else if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENE)				//  >=和<
			{
				switch(lpIndexCond2->m_bOperator)
				{
				case MF_EXECUTEPLAN_OPERATOR_GREATER:
					if(lpIndexCond2->m_varCondition1 >= lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENBE;
					}		
					break;
				case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESS:
					if(lpIndexCond2->m_varCondition1 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
					if(lpIndexCond2->m_varCondition1 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEEN;
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEEN: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEEN;
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
					if(lpIndexCond2->m_varCondition1 >= lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENBE;
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
						if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENBE)
						{
							lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENB;
						}
						else
						{
							lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEEN;
						}
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENE: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENBE: 
					if(lpIndexCond2->m_varCondition1 >= lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENBE;
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					}	
					break;
				}
			}
			else if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENBE)				//  >和<
			{
				switch(lpIndexCond2->m_bOperator)
				{
				case MF_EXECUTEPLAN_OPERATOR_GREATER:
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}		
					break;
				case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENE;
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESS:
					if(lpIndexCond2->m_varCondition1 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
					if(lpIndexCond2->m_varCondition1 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENB;
					}	
					break;
				case MF_EXECUTEPLAN_OPERATOR_BETWEEN: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENE;
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
						if(lpIndexCond1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENE)
						{
							lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEEN;
						}
						else
						{	
							lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENB;
						}
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENB;
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENE: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
						lpIndexCond1->m_bOperator = MF_EXECUTEPLAN_OPERATOR_BETWEENE;
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					}	

				case MF_EXECUTEPLAN_OPERATOR_BETWEENBE: 
					if(lpIndexCond2->m_varCondition1 > lpIndexCond1->m_varCondition1)
					{
						lpIndexCond1->m_varCondition1.SetData(lpIndexCond2->m_varCondition1);
					}	

					if(lpIndexCond2->m_varCondition2 < lpIndexCond1->m_varCondition2)
					{
						lpIndexCond1->m_varCondition2.SetData(lpIndexCond2->m_varCondition2);
					}	
					break;
				}
			}
			else
			{
				return MF_INDEXOPTIMIZER_COMPAREOPERATOR_ERROR;
			}

			lpSubIndexPlan1->SetCondition2(i, lpSubIndexPlan2->m_ppCondition[i]);
			if(lpSubIndexPlan1->m_ppCondition[i]->m_stIndexCondition.m_bOperator >= MF_EXECUTEPLAN_OPERATOR_BETWEEN && lpSubIndexPlan1->m_ppCondition[i]->m_stIndexCondition.m_bOperator <= MF_EXECUTEPLAN_OPERATOR_BETWEENBE)
			{
				if(lpSubIndexPlan1->m_ppCondition[i]->m_stIndexCondition.m_varCondition1 > lpSubIndexPlan1->m_ppCondition[i]->m_stIndexCondition.m_varCondition2)
				{
					lpSubIndexPlan1->m_ppCondition[i]->m_stIndexCondition.m_bInequality = 1;
				}
			}
		}
		lpSubIndexPlan1->SetCondition2(i, lpSubIndexPlan2->m_ppCondition[i]);
	}
	bInvalidPlan = 2;
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取子索引成本系数
	参数说明：
		lpSubIndexPlan：子索引指针
************************************************************************/
int CIndexSelector::GetCostFactor(LPSUBINDEXPLAN lpSubIndexPlan)
{
	int nRet;
	BYTE bOperator;

	if(lpSubIndexPlan->m_ppCondition[0] == NULL)
	{
		lpSubIndexPlan->m_dblCostFactor = 0;
		return MF_OK;
	}
	if(lpSubIndexPlan->m_bIndexType <= MF_SYS_INDEXTYPE_KV_CHAR)
	{
		lpSubIndexPlan->m_dblCostFactor = 0;
	}
	else if(lpSubIndexPlan->m_bIndexType == MF_SYS_INDEXTYPE_HB_INT || lpSubIndexPlan->m_bIndexType == MF_SYS_INDEXTYPE_HB_CHAR)
	{

	}
	else if(lpSubIndexPlan->m_bIndexType <= MF_SYS_INDEXTYPE_FUZZY_CHAR)
	{
		if(lpSubIndexPlan->m_bIndexType == MF_SYS_INDEXTYPE_TREE_MULTISTR || lpSubIndexPlan->m_bIndexType == MF_SYS_INDEXTYPE_FUZZY_CHAR)
		{
			//字符串型
			lpSubIndexPlan->m_dblCostFactor = (double)100.0 / lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1.m_nStrLen;
		}
		else
		{
			//数字型
			CMemoryBTreeFile* pFile;
			VARDATA varMaxKey, varMinKey;
			IVirtualMemoryFile* pVirtualFile;
			nRet = CSystemManage::instance().GetMemoryFileInstance(lpSubIndexPlan->m_bFileNo, pVirtualFile);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pFile = (CMemoryBTreeFile*)pVirtualFile;

			nRet = pFile->GetIndexRange(lpSubIndexPlan, varMaxKey, varMinKey);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			bOperator = lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_bOperator;
			if(bOperator == MF_EXECUTEPLAN_OPERATOR_GREATER || bOperator == MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL)
			{
				if(lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1.m_vt == MF_VARDATA_DOUBLE || lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1.m_vt == MF_VARDATA_DATE)
				{
					lpSubIndexPlan->m_dblCostFactor = (double)(varMaxKey.m_dblValue - lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1.m_dblValue) / (varMaxKey.m_llValue - varMinKey.m_dblValue);
				}
				else
				{
					lpSubIndexPlan->m_dblCostFactor = (double)(varMaxKey.m_llValue - lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1.m_llValue) / (varMaxKey.m_llValue - varMinKey.m_llValue);
				}
			}
			else 
			{
				if(bOperator == MF_EXECUTEPLAN_OPERATOR_GREATER || bOperator == MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL)
				{
					if(lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1.m_vt == MF_VARDATA_DOUBLE || lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1.m_vt == MF_VARDATA_DATE)
					{
						lpSubIndexPlan->m_dblCostFactor = (double)(lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1.m_dblValue - varMinKey.m_dblValue) / (varMaxKey.m_llValue - varMinKey.m_dblValue);
					}
					else
					{
						lpSubIndexPlan->m_dblCostFactor = (double)(lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1.m_llValue - varMinKey.m_llValue) / (varMaxKey.m_llValue - varMinKey.m_llValue);
					}
				}
			}
		}
	}
	else
	{
		return MF_INDEXOPTIMIZER_INDEXTYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取子索引查找范围
	参数说明：
		lpSubIndexPlan：子索引指针
************************************************************************/
int CIndexSelector::GetScanScope(LPSUBINDEXPLAN lpSubIndexPlan)
{
	int nRet; 
	if(lpSubIndexPlan->m_bIndexType <= MF_SYS_INDEXTYPE_HB_CHAR)
	{
		lpSubIndexPlan->m_nScanScope = 1;
	}
	else if(lpSubIndexPlan->m_bIndexType <= MF_SYS_INDEXTYPE_FUZZY_CHAR)
	{
		//B树索引范围
		CMemoryBTreeFile* pFile;
		IVirtualMemoryFile* pVirtualFile;
		nRet = CSystemManage::instance().GetMemoryFileInstance(lpSubIndexPlan->m_bFileNo, pVirtualFile);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pFile = (CMemoryBTreeFile*)pVirtualFile;

		nRet = pFile->GetIndexScanScope(lpSubIndexPlan);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(lpSubIndexPlan->m_bIndexType == MF_SYS_INDEXTYPE_FULL_OBJECT)
	{
		lpSubIndexPlan->m_nScanScope = m_nTotalDataNum;
	}
	else
	{
		return MF_INDEXOPTIMIZER_INDEXTYPE_ERROR;
	}
	return MF_OK;
}	
/************************************************************************
	功能说明：
		结合索引执行计划栈中的索引计划
************************************************************************/
int CIndexSelector::CombineIndexPlan()
{
	BYTE bInvalidPlan;
	int i, j, nCount, nStackNum, nRet;
	LPSUBINDEXPLAN arrIndexPlanArray[32], lpSubIndexPlan, lpSubIndexPlan2;
	
	memset(arrIndexPlanArray, 0, 32*sizeof(LPSUBINDEXPLAN));

	nStackNum = m_nLogicORNum + 1;
	m_nLogicORNum = 0;

	if(m_skIndexPlan.GetSize() < nStackNum)
	{
		return MF_INDEXOPTIMIZER_SUBINDEXPLANSTACK_ERROR;
	}
	
	//遍历索引执行计划栈，判断索引返回是否有包含情况
	for(i = 0, nCount = 0; i < nStackNum; i++)
	{
		lpSubIndexPlan = (LPSUBINDEXPLAN)m_skIndexPlan.GetElement(i);
		if(lpSubIndexPlan == NULL)
		{
			return MF_INDEXOPTIMIZER_SUBINDEXPLANSTACK_ERROR;
		}
		else
		{
			if(nCount > 32)
			{
				return MF_INDEXOPTIMIZER_INDEXNUM_ERROR;			//如果索引数量错误，则直接使用全表遍历
			}
			else
			{
				arrIndexPlanArray[nCount] = lpSubIndexPlan;
				nCount++;
			}
			
			lpSubIndexPlan = lpSubIndexPlan->m_lpNextPlan;
			while(lpSubIndexPlan)
			{
				if(nCount > 32)
				{
					return MF_INDEXOPTIMIZER_INDEXNUM_ERROR;		//如果索引数量错误，则直接使用全表遍历
				}
				else
				{
					arrIndexPlanArray[nCount] = lpSubIndexPlan;
					nCount++;
					lpSubIndexPlan = lpSubIndexPlan->m_lpNextPlan;
				}
			}

		}	
	}

	for(i = 0; i < nCount; i++)
	{
		lpSubIndexPlan = arrIndexPlanArray[i];
		if(lpSubIndexPlan == NULL)
		{
			continue;
		}
		for(j = i + 1; j < nCount; j++)
		{
			lpSubIndexPlan2 = arrIndexPlanArray[j];
			CombineORSubPlan(lpSubIndexPlan, lpSubIndexPlan2, bInvalidPlan);
			if(bInvalidPlan == 1)
			{
				arrIndexPlanArray[i] = NULL;
				break;
			}
			else if(bInvalidPlan == 2)
			{
				arrIndexPlanArray[j] = NULL;
			}
		}
	}

	//将子索引计划数组中的索引进行结合，得到一个新的子索引计划，并压入索引执行计划栈
	lpSubIndexPlan = NULL;
	for(i = 0; i < nCount; i++)
	{
		if(arrIndexPlanArray[i] != NULL)
		{
			if(arrIndexPlanArray[i]->m_dblCostFactor == 0)
			{
				//统计索引成本
				nRet = GetCostFactor(arrIndexPlanArray[i]);
				if(nRet != MF_OK)
				{
					return  nRet;
				}

				//获取检索范围
				nRet = GetScanScope(arrIndexPlanArray[i]);
				if(nRet != MF_OK)
				{
					return  nRet;
				}
			}

			if(lpSubIndexPlan == NULL)
			{
				lpSubIndexPlan  = arrIndexPlanArray[i];
				lpSubIndexPlan2 = arrIndexPlanArray[i];
			}
			else
			{
				//将所有OR连接的子索引条件串联成一个条件
				lpSubIndexPlan->m_dblCostFactor += arrIndexPlanArray[i]->m_dblCostFactor;
				lpSubIndexPlan->m_nScanScope    += arrIndexPlanArray[i]->m_nScanScope;

				lpSubIndexPlan2->m_lpNextPlan = arrIndexPlanArray[i];
				lpSubIndexPlan2 = arrIndexPlanArray[i];
			}
		}
	}
	for(i = 0; i < nStackNum; i++)
	{
		m_skIndexPlan.Pop();
	}
	m_skIndexPlan.Push(lpSubIndexPlan);
	return MF_OK;
}

/************************************************************************
	功能说明：
		从索引执行计划栈中选取最优执行计划
************************************************************************/
int CIndexSelector::GetOptimalIndexPlan()
{
	BYTE bInvalidPlan;
	int i, j, n, nRet, nCount;
	LPSUBINDEXPLAN arrIndexPlanArray[32], lpSubIndexPlan, lpSubIndexPlan2;
	memset(arrIndexPlanArray, 0, 32*sizeof(LPSUBINDEXPLAN));

	nCount = m_nLogicAndNum + 1;
	if(nCount > 32)
	{
		return MF_INDEXOPTIMIZER_INDEXNUM_ERROR;	
	}
	else if(nCount > m_skIndexPlan.GetSize())
	{
		return MF_INDEXOPTIMIZER_SUBINDEXPLANSTACK_ERROR;
	}
	m_nLogicAndNum = 0;

	//1.遍历索引执行计划栈，获取子索引计划，并预估其成本系数，然后按照成本系数从小到大排序
	for(i = 0; i < nCount; i++)
	{
		lpSubIndexPlan = (LPSUBINDEXPLAN)m_skIndexPlan.GetElement(i);
		if(lpSubIndexPlan == NULL)
		{
			return MF_INDEXOPTIMIZER_SUBINDEXPLANSTACK_ERROR;
		}
		else if(lpSubIndexPlan->m_dblCostFactor == 0)
		{
			nRet = GetCostFactor(lpSubIndexPlan);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}

		//KV索引直接选取
		if(lpSubIndexPlan->m_bIndexType <= MF_SYS_INDEXTYPE_KV_CHAR)
		{
			if(lpSubIndexPlan->m_nScanScope == 0)
			{
				nRet = GetScanScope(lpSubIndexPlan);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}

			for(n = 0; n < nCount; n++)
			{
				m_skIndexPlan.Pop();
			}
			m_skIndexPlan.Push(lpSubIndexPlan);
			return MF_OK;
		}

		//预估成本系数，并排序
		for(j = 0; j < i; j++)
		{
			if(lpSubIndexPlan->m_dblCostFactor < arrIndexPlanArray[j]->m_dblCostFactor)
			{
				memmove(&arrIndexPlanArray[j+1], &arrIndexPlanArray[j], (i - j)*sizeof(LPSUBINDEXPLAN));
				arrIndexPlanArray[j] = lpSubIndexPlan;
				break;
			}
		}
		if(j == i)
		{
			arrIndexPlanArray[j] = lpSubIndexPlan;
		}
	}

	//2.遍历索引执行计划数组，判断索引返回是否有包含情况
	for(i = 0; i < nCount; i++)
	{
		lpSubIndexPlan = arrIndexPlanArray[i];
		if(lpSubIndexPlan == NULL)
		{
			continue;
		}
		for(j = i + 1; j < nCount; j++)
		{
			lpSubIndexPlan2 = arrIndexPlanArray[j];
			CombineANDSubPlan(lpSubIndexPlan, lpSubIndexPlan2, bInvalidPlan);
			if(bInvalidPlan == 1)
			{
				//CombineANDSubPlan中bInvalidPlan的值只能为0或2
				return MF_INDEXOPTIMIZER_GETOPTIMALINDEX_ERROR;
				
			}
			else if(bInvalidPlan == 2)
			{
				arrIndexPlanArray[j] = NULL;
			}	
		}
	}

	//3.从子索引计划数组中选择一个最优索引，并压入索引执行计划栈
	lpSubIndexPlan = NULL;
	for(i = 0; i < nCount; i++)
	{
		if(arrIndexPlanArray[i] != NULL)
		{
			if(arrIndexPlanArray[i]->m_nScanScope == 0)
			{
				nRet = GetScanScope(arrIndexPlanArray[i]);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}

			if(lpSubIndexPlan == NULL)
			{
				lpSubIndexPlan = arrIndexPlanArray[i];
			}
			else if(arrIndexPlanArray[i]->m_nScanScope < lpSubIndexPlan->m_nScanScope)
			{
				lpSubIndexPlan = arrIndexPlanArray[i];
			}

			//如果查询范围小于全数据的百分之1，且小于128条，则直接选定
			if((double)lpSubIndexPlan->m_nScanScope < m_nTotalDataNum * 0.01 && lpSubIndexPlan->m_nScanScope <= 128)
			{
				for(n = 0; n < nCount; n++)
				{
					m_skIndexPlan.Pop();
				}
				m_skIndexPlan.Push(lpSubIndexPlan);
				return MF_OK;
			}
		}
	}
	
	for(n = 0; n < nCount; n++)
	{
		m_skIndexPlan.Pop();
	}
	m_skIndexPlan.Push(lpSubIndexPlan);
	return MF_OK;
}

/************************************************************************
	功能说明：
		选择同一字段上的最佳索引
************************************************************************/
int CIndexSelector::GetOptimalIndexPlanFromSameField()
{
	int i, j, nRet, nCount;
	LPSUBINDEXPLAN arrIndexPlanArray[32], lpSubIndexPlan;
	memset(arrIndexPlanArray, 0, 32*sizeof(LPSUBINDEXPLAN));

	nCount = m_skTemPlan.GetSize();
	//1.遍历索引执行计划栈，获取子索引计划，并预估其成本系数，然后按照成本系数从小到大排序
	for(i = 0; i < nCount; i++)
	{
		lpSubIndexPlan = (LPSUBINDEXPLAN)m_skTemPlan.GetElement(i);
		if(lpSubIndexPlan == NULL)
		{
			return MF_INDEXOPTIMIZER_SUBINDEXPLANSTACK_ERROR;
		}
		else if(lpSubIndexPlan->m_dblCostFactor == 0)
		{
			nRet = GetCostFactor(lpSubIndexPlan);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}

		//KV索引直接选取
		if(lpSubIndexPlan->m_bIndexType <= MF_SYS_INDEXTYPE_KV_CHAR)
		{
			if(lpSubIndexPlan->m_nScanScope == 0)
			{
				nRet = GetScanScope(lpSubIndexPlan);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}

			m_skTemPlan.Clear();
			m_skTemPlan.Push(lpSubIndexPlan);
			return MF_OK;
		}

		//预估成本系数，并排序
		for(j = 0; j < i; j++)
		{
			if(lpSubIndexPlan->m_dblCostFactor < arrIndexPlanArray[j]->m_dblCostFactor)
			{
				memmove(&arrIndexPlanArray[j+1], &arrIndexPlanArray[j], (i - j)*sizeof(LPSUBINDEXPLAN));
				arrIndexPlanArray[j] = lpSubIndexPlan;
				break;
			}
		}
		if(j == i)
		{
			arrIndexPlanArray[j] = lpSubIndexPlan;
		}
	}

	//2.从子索引计划数组中选择一个最优索引，并压入索引执行计划栈
	lpSubIndexPlan = NULL;
	for(i = 0; i < nCount; i++)
	{
		if(arrIndexPlanArray[i] != NULL)
		{
			if(lpSubIndexPlan == NULL)
			{
				lpSubIndexPlan = arrIndexPlanArray[i];
				if(lpSubIndexPlan->m_nScanScope == 0)
				{
					nRet = GetScanScope(lpSubIndexPlan);
					if(nRet != MF_OK)
					{
						return nRet;
					}
				}
			}
			else
			{
				if(arrIndexPlanArray[i]->m_nScanScope == 0)
				{
					nRet = GetScanScope(arrIndexPlanArray[i]);
					if(nRet != MF_OK)
					{
						return nRet;
					}
				}
				if(arrIndexPlanArray[i]->m_nScanScope < lpSubIndexPlan->m_nScanScope)
				{
					lpSubIndexPlan = arrIndexPlanArray[i];
				}
			}

			//如果查询范围小于全数据的百分之1，且小于128条，则直接选定
			if((double)lpSubIndexPlan->m_nScanScope < m_nTotalDataNum * 0.01 && lpSubIndexPlan->m_nScanScope <= 128)
			{
				m_skTemPlan.Clear();
				m_skTemPlan.Push(lpSubIndexPlan);
				return MF_OK;
			}
		}
	}

	m_skTemPlan.Clear();
	m_skTemPlan.Push(lpSubIndexPlan);
	return MF_OK;
}

/************************************************************************
	功能说明：
		从比较表达式中获取索引
	参数说明：
		lpCompareExpression：比较表达式
		pCompareTypePtr：比较表达式在查询条件中的类型指针
		pCompareOffsetPtr：比较表达式在查询条件中的偏移指针
		(pCompareTypePtr和pCompareOffsetPtr主要用于当该表达式最终被作为索引条件时，将其从原来的查询条件中删除，以避免重复过滤)
************************************************************************/
int CIndexSelector::GetIndexFromCompareExpression(LPCOMPAREEXPBSON lpCompareExpression, BYTE* pCompareTypePtr, int* pCompareOffsetPtr)
{
	BYTE bFieldNo;
	int nRet, i, j;
	BOOL bIndexField;
	LPINDEXDEF lpIndex;
	CExpression stExpression;
	LPMATHEXPBSON lpFieldExp;
	VARDATA varData1, varData2;
	MF_EXECUTEPLAN_OPERATOR bOperator;
	LPMATHEXPELEMENTBSON lpIndexField;				//建立索引的字段			
	BYTE bMathExpType1, bMathExpType2;				//算数表达式类型
	LPINDEXINQUERYCONDITION lpIndexCondition;
	LPSUBINDEXPLAN lpSubIndexPlan, lpSubIndexPlan2;
	UINT nMathExpOffset1, nMathExpOffset2, nOffset;

	if(lpCompareExpression->m_bExpressionType1 == MF_EXPRESSION_FIELD)
	{
		//获取创建了索引的字段
		if(lpCompareExpression->m_nMathExpOffset1 == 0)
		{
			return MF_INDEXOPTIMIZER_EXPRESSIONOFFSET_ERROR;
		}
		lpFieldExp		= (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompareExpression->m_nMathExpOffset1);
		lpIndexField	= (LPMATHEXPELEMENTBSON)m_pServiceBson->ConvertOffset2Addr(lpFieldExp->m_nExpOffset1);
		bFieldNo		= lpIndexField->m_bFieldNo;

		//获取索引字段的另外两个条件的类型和偏移
		bMathExpType1   = lpCompareExpression->m_bExpressionType2;
		bMathExpType2   = lpCompareExpression->m_bExpressionType3;
		nMathExpOffset1	= lpCompareExpression->m_nMathExpOffset2;
		nMathExpOffset2	= lpCompareExpression->m_nMathExpOffset3;

		//根据bLogicNot反转运算符
		if(!ReverseOp(lpCompareExpression->m_bOperator, bOperator, lpCompareExpression->m_bLogicNot))
		{
			//运算符不支持NOT
			return MF_OK;
		}	
	}
	else if(lpCompareExpression->m_bExpressionType2 == MF_EXPRESSION_FIELD)
	{
		if(lpCompareExpression->m_nMathExpOffset2 == 0)
		{
			return MF_INDEXOPTIMIZER_EXPRESSIONOFFSET_ERROR;
		}
		lpFieldExp		= (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompareExpression->m_nMathExpOffset2);
		lpIndexField	= (LPMATHEXPELEMENTBSON)m_pServiceBson->ConvertOffset2Addr(lpFieldExp->m_nExpOffset1);
		bFieldNo		= lpIndexField->m_bFieldNo;

		//获取索引字段的另外两个条件的类型和偏移
		bMathExpType1   = lpCompareExpression->m_bExpressionType1;
		bMathExpType2   = lpCompareExpression->m_bExpressionType3;
		nMathExpOffset1	= lpCompareExpression->m_nMathExpOffset1;
		nMathExpOffset2	= lpCompareExpression->m_nMathExpOffset3;

		//A > SNO这样的形式，要将其转换为SNO <= A这样的形式
		ReverseOp(lpCompareExpression->m_bOperator, bOperator);

		//根据bLogicNot反转运算符
		if(!ReverseOp(lpCompareExpression->m_bOperator, bOperator, lpCompareExpression->m_bLogicNot))
		{
			//运算符不支持NOT
			return MF_OK;
		}
	}

	//提取索引
	stExpression.Initial(m_pServiceBson, m_lpObjectInfo);

	if(bFieldNo == 255)
	{
		//ROWID字段，将 ROWID = A作为一种最快的特殊索引
		if(lpCompareExpression->m_bOperator == MF_EXECUTEPLAN_OPERATOR_EQUAL)
		{
			if(bMathExpType1 == MF_EXPRESSION_CONSTMATH)
			{
				//获取比较条件1的值
				LPMATHEXPBSON lpMathExp;
				lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(nMathExpOffset1);
				nRet = stExpression.GetExpressionResult(lpMathExp, varData1);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
			else
			{
				return MF_INDEXOPTIMIZER_MATHEXPTYPE_ERROR;
			}
			
			//建立索引子计划，并压入索引计划栈
			nRet = m_pServiceBson->AllocFromTempBuffer(lpSubIndexPlan, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpSubIndexPlan->m_bIndexType		= MF_SYS_INDEXTYPE_ROWID;
			lpSubIndexPlan->m_bFieldNo[0]		= 255;
			nRet = m_pServiceBson->AllocFromTempBuffer(lpIndexCondition, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpIndexCondition->m_stIndexCondition.m_bFieldNo		= bFieldNo;
			lpIndexCondition->m_stIndexCondition.m_bOperator	= bOperator;
			lpIndexCondition->m_stIndexCondition.m_varCondition1.SetData(varData1);
			lpIndexCondition->m_stIndexCondition.m_varCondition2.SetData(varData2);

			lpIndexCondition->m_pCompareType    = pCompareTypePtr;
			lpIndexCondition->m_pCompareOffset  = pCompareOffsetPtr;

			lpSubIndexPlan->SetCondition(0, lpIndexCondition);
			nRet = m_skTemPlan.Push(lpSubIndexPlan);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else if(lpCompareExpression->m_bOperator == MF_EXECUTEPLAN_OPERATOR_IN || lpCompareExpression->m_bOperator == MF_EXECUTEPLAN_OPERATOR_NOTIN)
		{
			UINT nDataNodeOffset;
			LPDATANODE lpDataNode;
			LPINCONDITIONBSON lpInExp;
			int nHashTableLen, *lpHashTable;
			if(bMathExpType1 == MF_EXPRESSION_AGGREMATH)
			{
				lpInExp = (LPINCONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(nMathExpOffset1);
				//将IN条件拆分为多个等于条件，条件之间用OR连接
				nHashTableLen	 = lpInExp->m_nDataNum;	
				lpHashTable		 = (int*)m_pServiceBson->ConvertOffset2Addr(lpInExp->m_nHashTableOffset);
				for(j = 0; j < nHashTableLen; j++)
				{
					nDataNodeOffset  = lpHashTable[j];
					lpSubIndexPlan2  = NULL;
					while(nDataNodeOffset)
					{
						//遍历IN链表，取出条件值，然后建立子索引条件
						lpDataNode = (LPDATANODE)m_pServiceBson->ConvertOffset2Addr(nDataNodeOffset);
						if(lpDataNode->m_bDataType == MF_SYS_FIELDTYPE_INT || lpDataNode->m_bDataType == MF_SYS_FIELDTYPE_BIGINT)
						{
							varData1.SetData(*(int*)lpDataNode->m_pDataBuffer);
						}
						else if(lpDataNode->m_bDataType == MF_SYS_FIELDTYPE_CHAR || lpDataNode->m_bDataType == MF_SYS_FIELDTYPE_VARCHAR)
						{
							return MF_COMMON_INVALID_FIELDTYPE;
						}

						//建立索引子计划
						nRet = m_pServiceBson->AllocFromTempBuffer(lpSubIndexPlan, nOffset);
						if(nRet != MF_OK)
						{
							return nRet;
						}
						//插头
						if(lpSubIndexPlan2 != NULL)
						{
							lpSubIndexPlan->m_lpNextPlan = lpSubIndexPlan2;
						}
						lpSubIndexPlan2 = lpSubIndexPlan;
						
						//给子索引条件赋值
						lpSubIndexPlan->m_bIndexType	= MF_SYS_INDEXTYPE_ROWID;
						lpSubIndexPlan->m_bFieldNo[0]	= 255;
						nRet = m_pServiceBson->AllocFromTempBuffer(lpIndexCondition, nOffset);
						if(nRet != MF_OK)
						{
							return nRet;
						}
						lpIndexCondition->m_stIndexCondition.m_bFieldType	= MF_SYS_FIELDTYPE_BIGINT;
						lpIndexCondition->m_stIndexCondition.m_bFieldNo		= bFieldNo;
						lpIndexCondition->m_stIndexCondition.m_varCondition1.SetData(varData1);
						lpIndexCondition->m_stIndexCondition.m_varCondition2.SetData(varData2);
						lpIndexCondition->m_pCompareType    = pCompareTypePtr;
						lpIndexCondition->m_pCompareOffset  = pCompareOffsetPtr;
						if(lpCompareExpression->m_bOperator == MF_EXECUTEPLAN_OPERATOR_IN)
						{
							lpIndexCondition->m_stIndexCondition.m_bOperator = MF_EXECUTEPLAN_OPERATOR_EQUAL;
						}
						else
						{
							lpIndexCondition->m_stIndexCondition.m_bOperator = MF_EXECUTEPLAN_OPERATOR_NOTEQUAL;
						}

						lpSubIndexPlan->SetCondition(0, lpIndexCondition);
					}
					
					//将条件Push到子索引计划栈中
					nRet = m_skTemPlan.Push(lpSubIndexPlan);
					if(nRet != MF_OK)
					{
						return nRet;
					}
				}
			}
			else
			{
				return MF_INDEXOPTIMIZER_MATHEXPTYPE_ERROR;
			}
		}
		else
		{
			//如果当前字段不存在索引，则需要为当前字段创建一个全表遍历的子索引计划
			nRet = m_pServiceBson->AllocFromTempBuffer(lpSubIndexPlan, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpSubIndexPlan->m_bIndexType		= MF_SYS_INDEXTYPE_FULL_OBJECT;
			lpSubIndexPlan->m_nScanScope		= m_nTotalDataNum;
			lpSubIndexPlan->m_dblCostFactor		= 100;

			nRet = m_skTemPlan.Push(lpSubIndexPlan);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}
	else
	{
		bIndexField = FALSE;
		//MF_EXECUTEPLAN_OPERATOR_NOTEQUAL和MF_EXECUTEPLAN_OPERATOR_NOTIN不使用索引
		if(lpCompareExpression->m_bOperator != MF_EXECUTEPLAN_OPERATOR_NOTEQUAL && lpCompareExpression->m_bOperator != MF_EXECUTEPLAN_OPERATOR_NOTIN)
		{
			for(lpIndex = m_lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
			{
				//遍历对象的所有索引，判断该字段上是否创建了索引
				for(i = 0; i < 4; i++)
				{
					if(lpIndex->m_bFieldNo[i] == 0)
					{
						break;
					}
					if(bFieldNo == lpIndex->m_bFieldNo[i])
					{
						if(lpIndex->m_bIndexType <= 6 && lpCompareExpression->m_bOperator != MF_EXECUTEPLAN_OPERATOR_EQUAL && lpCompareExpression->m_bOperator != MF_EXECUTEPLAN_OPERATOR_IN)
						{
							//如果是KV索引则只支持等于或OR操作
							break;
						}
						if(lpCompareExpression->m_bOperator == MF_EXECUTEPLAN_OPERATOR_IN)
						{
							UINT nDataNodeOffset;
							LPDATANODE lpDataNode;
							LPINCONDITIONBSON lpInExp;
							int nHashTableLen, *lpHashTable;
							if(bMathExpType1 == MF_EXPRESSION_AGGREMATH)
							{
								lpInExp = (LPINCONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(nMathExpOffset1);
								//将IN条件拆分为多个等于条件，条件之间用OR连接
								nHashTableLen	 = lpInExp->m_nDataNum;
								lpHashTable		 = (int*)m_pServiceBson->ConvertOffset2Addr(lpInExp->m_nHashTableOffset);
								lpSubIndexPlan2  = NULL;
								for(j = 0; j < nHashTableLen; j++)
								{
									nDataNodeOffset = lpHashTable[j];
									while(nDataNodeOffset)
									{
										//遍历IN链表，取出条件值，然后建立子索引条件
										lpDataNode = (LPDATANODE)m_pServiceBson->ConvertOffset2Addr(nDataNodeOffset);
										if(lpDataNode->m_bDataType == MF_SYS_FIELDTYPE_INT || lpDataNode->m_bDataType == MF_SYS_FIELDTYPE_BIGINT)
										{
											varData1.SetData(*(int*)lpDataNode->m_pDataBuffer);
										}
										else if(lpDataNode->m_bDataType == MF_SYS_FIELDTYPE_CHAR || lpDataNode->m_bDataType == MF_SYS_FIELDTYPE_VARCHAR)
										{
											varData1.SetData(lpDataNode->m_pDataBuffer, lpDataNode->m_nDataLen);
										}

										//建立索引子计划
										nRet = m_pServiceBson->AllocFromTempBuffer(lpSubIndexPlan, nOffset);
										if(nRet != MF_OK)
										{
											return nRet;
										}
										//插头
										if(lpSubIndexPlan2 != NULL)
										{
											lpSubIndexPlan->m_lpNextPlan = lpSubIndexPlan2;
										}
										lpSubIndexPlan2 = lpSubIndexPlan;

										//给子索引条件赋值
										lpSubIndexPlan->m_nIndexID			= lpIndex->m_nIndexID;
										lpSubIndexPlan->m_bIndexType		= lpIndex->m_bIndexType;
										lpSubIndexPlan->m_bFileNo			= lpIndex->m_bFileNo;
										lpSubIndexPlan->m_bConstraintType	= lpIndex->m_bConstraintType;
										lpSubIndexPlan->m_bFieldNo[0]		= lpIndex->m_bFieldNo[0];			
										lpSubIndexPlan->m_bFieldNo[1]		= lpIndex->m_bFieldNo[1];
										lpSubIndexPlan->m_bFieldNo[2]		= lpIndex->m_bFieldNo[2];
										lpSubIndexPlan->m_bFieldNo[3]		= lpIndex->m_bFieldNo[3];

										nRet = m_pServiceBson->AllocFromTempBuffer(lpIndexCondition, nOffset);
										if(nRet != MF_OK)
										{
											return nRet;
										}

										lpIndexCondition->m_stIndexCondition.m_bFieldNo		= bFieldNo;
										lpIndexCondition->m_stIndexCondition.m_bFieldType	= m_lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;;
										lpIndexCondition->m_stIndexCondition.m_varCondition1.SetData(varData1);
										lpIndexCondition->m_stIndexCondition.m_varCondition2.SetData(varData2);
										lpIndexCondition->m_stIndexCondition.m_bOperator = MF_EXECUTEPLAN_OPERATOR_EQUAL;

										lpIndexCondition->m_pCompareType    = pCompareTypePtr;
										lpIndexCondition->m_pCompareOffset  = pCompareOffsetPtr;

										lpSubIndexPlan->SetCondition(0, lpIndexCondition);

										nDataNodeOffset = lpDataNode->m_nNextOffset;
									}
								}

								//将条件Push到子索引计划栈中
								nRet = m_skTemPlan.Push(lpSubIndexPlan);
								if(nRet != MF_OK)
								{
									return nRet;
								}
								bIndexField = TRUE;
							}
							else
							{
								return MF_INDEXOPTIMIZER_MATHEXPTYPE_ERROR;
							}
						}	
						else
						{
							if(bMathExpType1 == MF_EXPRESSION_CONSTMATH || bMathExpType1 == MF_EXPRESSION_COMMFUN)
							{
								//获取比较条件1的值
								LPMATHEXPBSON lpMathExp;
								lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(nMathExpOffset1);
								nRet = stExpression.GetExpressionResult(lpMathExp, varData1);
								if(nRet != MF_OK)
								{
									return nRet;
								}

								if(nMathExpOffset2 != 0)
								{
									//BETWEEN AND形式
									LPMATHEXPBSON lpMathExp;
									lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(nMathExpOffset2);
									if(bMathExpType2 == MF_EXPRESSION_CONSTMATH || bMathExpType2 == MF_EXPRESSION_COMMFUN)
									{
										nRet = stExpression.GetExpressionResult(lpMathExp, varData2);
										if(nRet != MF_OK)
										{
											return nRet;
										}
									}
									else
									{
										return MF_INDEXOPTIMIZER_MATHEXPTYPE_ERROR;
									}
								}

								//建立索引子计划，并压入索引计划栈
								nRet = m_pServiceBson->AllocFromTempBuffer(lpSubIndexPlan, nOffset);
								if(nRet != MF_OK)
								{
									return nRet;
								}
								lpSubIndexPlan->m_nIndexID			= lpIndex->m_nIndexID;
								lpSubIndexPlan->m_bIndexType		= lpIndex->m_bIndexType;
								lpSubIndexPlan->m_bFileNo			= lpIndex->m_bFileNo;
								lpSubIndexPlan->m_bConstraintType	= lpIndex->m_bConstraintType;
								lpSubIndexPlan->m_bFieldNo[0]		= lpIndex->m_bFieldNo[0];			
								lpSubIndexPlan->m_bFieldNo[1]		= lpIndex->m_bFieldNo[1];
								lpSubIndexPlan->m_bFieldNo[2]		= lpIndex->m_bFieldNo[2];
								lpSubIndexPlan->m_bFieldNo[3]		= lpIndex->m_bFieldNo[3];

								nRet = m_pServiceBson->AllocFromTempBuffer(lpIndexCondition, nOffset);
								if(nRet != MF_OK)
								{
									return nRet;
								}
								lpIndexCondition->m_stIndexCondition.m_bFieldNo		= bFieldNo;
								lpIndexCondition->m_stIndexCondition.m_bFieldType	= m_lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;;
								lpIndexCondition->m_stIndexCondition.m_bOperator	= bOperator;
								lpIndexCondition->m_stIndexCondition.m_varCondition1.SetData(varData1);
								lpIndexCondition->m_stIndexCondition.m_varCondition2.SetData(varData2);

								lpIndexCondition->m_pCompareType    = pCompareTypePtr;
								lpIndexCondition->m_pCompareOffset  = pCompareOffsetPtr;

								lpSubIndexPlan->SetCondition(i, lpIndexCondition);

								nRet = m_skTemPlan.Push(lpSubIndexPlan);
								if(nRet != MF_OK)
								{
									return nRet;
								}
								bIndexField = TRUE;
							}
							else
							{
								return MF_INDEXOPTIMIZER_MATHEXPTYPE_ERROR;
							}
						}
						break;
					}
				}
				//由于可能存在一个字段上面创建了不同索引的情况(比如：ID字段创建了B树索引和符合索引)所以外层循环应该遍历所有的索引
			}
		}
		
		if(!bIndexField)
		{
			//如果当前字段不存在索引，则需要为当前字段创建一个全表遍历的子索引计划
			nRet = m_pServiceBson->AllocFromTempBuffer(lpSubIndexPlan, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			
			lpSubIndexPlan->m_bIndexType		= MF_SYS_INDEXTYPE_FULL_OBJECT;
			lpSubIndexPlan->m_nScanScope		= m_nTotalDataNum;
			lpSubIndexPlan->m_dblCostFactor		= 100;

			nRet = m_skTemPlan.Push(lpSubIndexPlan);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}

	if(m_skTemPlan.GetSize() > 1)
	{
		nRet = GetOptimalIndexPlanFromSameField();
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	lpSubIndexPlan = (LPSUBINDEXPLAN)m_skTemPlan.Pop();
	m_skIndexPlan.Push(lpSubIndexPlan);
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取条件索引
	参数说明：
		lpCondition：子查询条件，作为递归参数
************************************************************************/
int CIndexSelector::GetConditionIndex(LPBASECONDITIONBSON lpCondition)
{	 
	int i, nRet;
	UINT nOffset;
	LPSUBINDEXPLAN lpSubIndexPlan;
	LOGIC_OPERATOR bLogicOperator;
	LPCOMPAREEXPBSON lpCompareExpression;
	LPBASECONDITIONBSON lpSubCondition1, lpSubCondition2;

	if(lpCondition->m_bLogicOperator == MF_EXECUTEPLAN_OPERATOR_OR)
	{
		//将运算符OR压入逻辑运算符栈
		bLogicOperator = LOGIC_OR;
		nRet = m_skLogicOperator.Push(&bLogicOperator);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(lpCondition->m_bLogicOperator == MF_EXECUTEPLAN_OPERATOR_AND)
	{
		//将运算符AND压入逻辑运算符栈
		bLogicOperator = LOGIC_AND;
		nRet = m_skLogicOperator.Push(&bLogicOperator);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(lpCondition->m_bLogicOperator == MF_EXECUTEPLAN_OPERATOR_NOT)
	{
		bLogicOperator = LOGIC_NOT;
		nRet = m_skLogicOperator.Push(&bLogicOperator);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(lpCondition->m_bLogicOperator != 0)
	{
		return MF_COMMON_INVALID_OPERATOR;
	}

	if(MF_CONDITION_LOGIC == lpCondition->m_bConditionType1)
	{	
		//如果条件为逻辑表达式，则继续递归
		if(lpCondition->m_nConditionOffset1 == 0)
		{
			return MF_INDEXOPTIMIZER_CONDITIONOFFSET_ERROR;
		}

		lpSubCondition1 = (LPBASECONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset1);
		GetConditionIndex(lpSubCondition1);
	}
	else if(MF_CONDITION_COMPARE == lpCondition->m_bConditionType1)
	{
		//如果条件为比较表达式，则从比较表达式中获取索引条件
		if(lpCondition->m_nConditionOffset1 == 0)
		{
			return MF_INDEXOPTIMIZER_CONDITIONOFFSET_ERROR;
		}

		lpCompareExpression = (LPCOMPAREEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset1);
		nRet = GetIndexFromCompareExpression(lpCompareExpression, &lpCondition->m_bConditionType1, &lpCondition->m_nConditionOffset1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(MF_CONDITION_ROWNUM == lpCondition->m_bConditionType1)
	{
		//创建一个全表遍历的子索引计划
		nRet = m_pServiceBson->AllocFromTempBuffer(lpSubIndexPlan, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		lpSubIndexPlan->m_bIndexType		= MF_SYS_INDEXTYPE_FULL_OBJECT;
		lpSubIndexPlan->m_nScanScope		= m_nTotalDataNum;
		lpSubIndexPlan->m_dblCostFactor		= 100;

		nRet = m_skIndexPlan.Push(lpSubIndexPlan);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	if(MF_CONDITION_LOGIC == lpCondition->m_bConditionType2)
	{	
		//如果条件为逻辑表达式，则继续递归
		if(lpCondition->m_nConditionOffset2 == 0)
		{
			return MF_INDEXOPTIMIZER_CONDITIONOFFSET_ERROR;
		}

		lpSubCondition2 = (LPBASECONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset2);
		GetConditionIndex(lpSubCondition2);
	}
	else if(MF_CONDITION_COMPARE == lpCondition->m_bConditionType2)
	{
		if(lpCondition->m_nConditionOffset2 == 0)
		{
			return MF_INDEXOPTIMIZER_CONDITIONOFFSET_ERROR;
		}
		
		lpCompareExpression = (LPCOMPAREEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset2);
		nRet = GetIndexFromCompareExpression(lpCompareExpression, &lpCondition->m_bConditionType2, &lpCondition->m_nConditionOffset2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(MF_CONDITION_ROWNUM == lpCondition->m_bConditionType2)
	{
		//创建一个全表遍历的子索引计划
		nRet = m_pServiceBson->AllocFromTempBuffer(lpSubIndexPlan, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		lpSubIndexPlan->m_bIndexType		= MF_SYS_INDEXTYPE_FULL_OBJECT;
		lpSubIndexPlan->m_nScanScope		= m_nTotalDataNum;
		lpSubIndexPlan->m_dblCostFactor		= 100;

		nRet = m_skIndexPlan.Push(lpSubIndexPlan);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//将逻辑运算符栈中的栈顶元素弹栈
	if(m_skLogicOperator.GetSize() != 0)
	{
		//递增OR的数量，OR运算符的个数表示调用CombineIndexPlan函数时，子索引计划的个数
		bLogicOperator = *(BYTE*)m_skLogicOperator.Pop();
		if(bLogicOperator == LOGIC_OR)
		{
			//如果逻辑运算符OR弹栈，则将索引计划栈中的所有索引计划组成一系列由OR连接的新索引计划，并压入索引计划栈
			m_nLogicORNum++;
			m_nLogicBeforNotNum++;
			if(m_skLogicOperator.GetSize() == 0 || *(BYTE*)m_skLogicOperator.Top() == LOGIC_AND)
			{
				nRet = CombineIndexPlan();
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_nLogicBeforNotNum = 1;
			}
		}
		else if(bLogicOperator == LOGIC_AND)
		{
			//递增AND的数量，AND运算符的个数表示调用GetOptimalIndexPlan函数时，子索引计划的个数
			m_nLogicAndNum++;
			m_nLogicBeforNotNum++;
			if(m_skLogicOperator.GetSize() == 0 || *(BYTE*)m_skLogicOperator.Top() == LOGIC_OR)
			{
				//如果栈为空，或者栈顶逻辑运算符为OR，则从索引计划栈中选择一个最优索引，并压入索引计划栈中
				nRet = GetOptimalIndexPlan();
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_nLogicBeforNotNum = 1;
			}
		}
		else if(bLogicOperator == LOGIC_NOT)
		{	
			//有逻辑非的条件都只能使用全表遍历，所以需要NOT之前的子索引条件都弹栈，然后将创建一个全表遍历的索引条件Push到栈中
			//NOT弹栈之前，子索引栈中的元素数量等于m_nLogicBeforNotNum + 1
			for(i = 0; i < m_nLogicBeforNotNum + 1; i++)
			{
				m_skIndexPlan.Pop();
			}
			
			//创建一个全表遍历的子索引计划
			nRet = m_pServiceBson->AllocFromTempBuffer(lpSubIndexPlan, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpSubIndexPlan->m_bIndexType		= MF_SYS_INDEXTYPE_FULL_OBJECT;
			lpSubIndexPlan->m_nScanScope		= m_nTotalDataNum;
			lpSubIndexPlan->m_dblCostFactor		= 100;

			nRet = m_skIndexPlan.Push(lpSubIndexPlan);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else
		{
			return MF_INDEXOPTIMIZER_LOGICOPERATOR_ERROR;
		}
	}	
	return MF_OK;
}

/************************************************************************
	功能说明：
		将索引执行计划栈中的索引计划组织成最终的索引执行计划
************************************************************************/
int CIndexSelector::CreateConditonIndex()
{
	int i, nRet;
	UINT nOffset;
	LPSUBINDEXPLAN lpSubIndexPlan;
	LPINDEXEXECUTEPLAN lpIndexPlan, lpPreIndexPlan;
	
	for(lpSubIndexPlan = (LPSUBINDEXPLAN)m_skIndexPlan.Pop(); lpSubIndexPlan != NULL; lpSubIndexPlan = lpSubIndexPlan->m_lpNextPlan)
	{
		if(lpSubIndexPlan->m_ppCondition[0] == NULL)
		{
			//索引的第一个条件不能为空
			continue;
		}
		nRet = m_pServiceBson->AllocFromBsonBuffer(lpIndexPlan, nOffset);
		if(nRet != MF_OK)
		{
			return MF_OK;
		}
		if(m_nIndexPlanOffset == 0)
		{
			m_nIndexPlanOffset = nOffset;
		}
		else
		{
			lpPreIndexPlan->m_nNextOffset = nOffset;
		}
		lpPreIndexPlan = lpIndexPlan;

		lpIndexPlan->m_nIndexID			= lpSubIndexPlan->m_nIndexID;
		lpIndexPlan->m_bIndexType		= lpSubIndexPlan->m_bIndexType;
		lpIndexPlan->m_bFieldNo[0]		= lpSubIndexPlan->m_bFieldNo[0];
		lpIndexPlan->m_bFieldNo[1]		= lpSubIndexPlan->m_bFieldNo[1];
		lpIndexPlan->m_bFieldNo[2]		= lpSubIndexPlan->m_bFieldNo[2];
		lpIndexPlan->m_bFieldNo[3]		= lpSubIndexPlan->m_bFieldNo[3];
		lpIndexPlan->m_bFileNo			= lpSubIndexPlan->m_bFileNo;
		lpIndexPlan->m_bConstraintType	= lpSubIndexPlan->m_bConstraintType;

		for(i = 0; i < 4; i++)
		{
			if(lpSubIndexPlan->m_ppCondition[i] == NULL)
			{
				break;
			}

			lpIndexPlan->m_stMultiIndex.m_lpIndexCondition[i].m_bFieldNo	= lpSubIndexPlan->m_ppCondition[i]->m_stIndexCondition.m_bFieldNo;
			lpIndexPlan->m_stMultiIndex.m_lpIndexCondition[i].m_bFieldType	= lpSubIndexPlan->m_ppCondition[i]->m_stIndexCondition.m_bFieldType;
			lpIndexPlan->m_stMultiIndex.m_lpIndexCondition[i].m_bOperator	= lpSubIndexPlan->m_ppCondition[i]->m_stIndexCondition.m_bOperator;
			lpIndexPlan->m_stMultiIndex.m_lpIndexCondition[i].m_bInequality	= lpSubIndexPlan->m_ppCondition[i]->m_stIndexCondition.m_bInequality;
			lpIndexPlan->m_stMultiIndex.m_lpIndexCondition[i].m_varCondition1.SetData(lpSubIndexPlan->m_ppCondition[i]->m_stIndexCondition.m_varCondition1);
			lpIndexPlan->m_stMultiIndex.m_lpIndexCondition[i].m_varCondition2.SetData(lpSubIndexPlan->m_ppCondition[i]->m_stIndexCondition.m_varCondition2);

			lpIndexPlan->m_lpParamPtr1	= lpSubIndexPlan->m_lpParamPtr1;
			lpIndexPlan->m_lpParamPtr2	= lpSubIndexPlan->m_lpParamPtr2;
			lpIndexPlan->m_lpParamPtr3	= lpSubIndexPlan->m_lpParamPtr3;
			lpIndexPlan->m_nParam4		= lpSubIndexPlan->m_nParam4;
			lpIndexPlan->m_nParam5		= lpSubIndexPlan->m_nParam5;
		}
		lpSubIndexPlan->DeleteCond();
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		初始化
	参数说明：
		lpObjectInfo：	对象信息
		lpCondition：	查询条件
		lpExecuteField：查询字段
************************************************************************/
int CIndexSelector::Initial(LPOBJECTDEF lpObjectInfo, LPBASECONDITIONBSON lpCondition, LPEXECUTEFIELDBSON lpExecuteField)
{
	UINT nOffset;
	LPBYTE lpAddr;
	int nRet, nLen;

	m_lpObjectInfo		= lpObjectInfo;
	m_lpCondition		= lpCondition;
	m_lpQueryField		= lpExecuteField;
	if(lpObjectInfo->m_pDataNum != NULL)
	{
		m_nTotalDataNum	= *lpObjectInfo->m_pDataNum;
	}
	else
	{
		m_nTotalDataNum = 0;
	}

	//给逻辑符号栈分配空间
	nLen = sizeof(BYTE)*32;
	nRet = m_pServiceBson->AllocFromTempBuffer(nLen, lpAddr, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	m_skLogicOperator.Initial(lpAddr, nLen, sizeof(BYTE), FALSE);

	//给索引执行计划栈分配空间
	nLen = sizeof(LPSUBINDEXPLAN)*32;
	nRet = m_pServiceBson->AllocFromTempBuffer(nLen, lpAddr, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	m_skIndexPlan.Initial(lpAddr, nLen, sizeof(LPSUBINDEXPLAN), TRUE);

	//给临时索引执行计划栈分配空间
	nRet = m_pServiceBson->AllocFromTempBuffer(nLen, lpAddr, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	m_skTemPlan.Initial(lpAddr, nLen, sizeof(LPSUBINDEXPLAN), TRUE);
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取查询索引
************************************************************************/
int CIndexSelector::GetQueryIndex()
{
	int nRet;
	LPSUBINDEXPLAN lpSubIndexPlan;
	if(m_lpCondition != NULL && m_lpObjectInfo->m_lpIndex != NULL)
	{
		//根据查询条件，获取条件索引的成本
		nRet = GetConditionIndex(m_lpCondition);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(m_skIndexPlan.GetSize() > 1)
		{
			nRet = GetOptimalIndexPlan();
			if(nRet != MF_OK)
			{
				return nRet;
			}

			if(m_skIndexPlan.GetSize() != 1)
			{
				return MF_INDEXOPTIMIZER_SUBINDEXPLANSTACK_ERROR;
			}
		}
	}
	
	if(m_lpQueryField != NULL)
	{
		//根据查询字段，获取覆盖索引的成本
	}

	//比较三种查询的成本，获取最终的查询执行计划
	if(m_skIndexPlan.GetSize() != 0)
	{
		lpSubIndexPlan = (LPSUBINDEXPLAN)m_skIndexPlan.Top();
		if(lpSubIndexPlan->m_nScanScope == 0)
		{
			//只有一个索引会出现这样情况
			nRet = GetScanScope(lpSubIndexPlan);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		if(lpSubIndexPlan->m_nScanScope < m_nTotalDataNum)
		{
			nRet = CreateConditonIndex();
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpSubIndexPlan->m_bIndexType <= 10)
			{
				m_bQueryPlanType = MF_QUERYPLAN_RANGE_KV;
			}
			else
			{
				m_bQueryPlanType = MF_QUERYPLAN_RANGE_BTREE;
			}
			m_nScanRowNum = lpSubIndexPlan->m_nScanScope;
		}
		else
		{
			m_bQueryPlanType = MF_QUERYPLAN_ALL;
			m_nScanRowNum	 = m_nTotalDataNum;
		}
	}
	else
	{
		m_bQueryPlanType = MF_QUERYPLAN_ALL;
		m_nScanRowNum	 = m_nTotalDataNum;
	}
	return MF_OK;
}