﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "ServiceBson.h"

class CSystemManage;
CServiceBson::CServiceBson(void)
{
	m_lpTempBuffer			= NULL;
	m_nTempBufferSize		= 0;
	m_nTempDataSize			= 0;

	m_lpCircleBuffer		= NULL;
	m_nCircleBufferSize		= 0;
	m_nCircleDataSize		= 0;

	m_lpRecrodBuffer		= NULL;
	m_nRecordBufferSize		= 0;

	m_nTempSectionNum		= 0;

	m_nSectionStartOffset	= 0;

	m_nTotalDataSize		= 0;
	m_nTotalBufferSize		= 0;
	m_bReleaseBuffer		= TRUE;
}

CServiceBson::~CServiceBson(void)
{
	Free();
}

/************************************************************************
		功能说明：
			释放内存
************************************************************************/
void CServiceBson::Free()
{
	short i;
	LPBYTE lpBuffer;

	if(m_bReleaseBuffer)
	{
		for(i = 0; i < m_nBufferSectionNum; i++)
		{
			lpBuffer = m_arrBufferSection[i];
			if(lpBuffer != NULL)
			{
				if(lpBuffer < m_lpBuffer || lpBuffer >= m_lpBuffer + m_nTotalBufferSize)
				{
					CSystemManage::instance().FreeTemporaryMem(lpBuffer);
					m_arrBufferSection[i] = NULL;
				}
			}
		}

		for(i = 0; i < m_nTempSectionNum; i++)
		{
			lpBuffer = m_arrTempSection[i];
			if(lpBuffer != NULL)
			{
				if(lpBuffer < m_lpBuffer || lpBuffer >= m_lpBuffer + m_nTotalBufferSize)
				{
					CSystemManage::instance().FreeTemporaryMem(lpBuffer);
					m_arrBufferSection[i] = NULL;
				}
			}
		}

		if(m_lpTempBuffer != NULL)
		{
			if(m_lpTempBuffer < m_lpBuffer || m_lpTempBuffer >= m_lpBuffer + m_nTotalBufferSize)
			{
				CSystemManage::instance().FreeTemporaryMem(m_lpTempBuffer);
				m_lpTempBuffer = NULL;
			}
		}	

		if(m_lpCircleBuffer != NULL)
		{
			if(m_lpCircleBuffer < m_lpBuffer || m_lpCircleBuffer >= m_lpBuffer + m_nTotalBufferSize)
			{
				CSystemManage::instance().FreeTemporaryMem(m_lpCircleBuffer);
				m_lpCircleBuffer = NULL;
			}
		}

		if(m_lpRecrodBuffer != NULL)
		{
			if(m_lpRecrodBuffer < m_lpBuffer || m_lpRecrodBuffer >= m_lpBuffer + m_nTotalBufferSize)
			{
				CSystemManage::instance().FreeTemporaryMem(m_lpRecrodBuffer);
				m_lpRecrodBuffer = NULL;
			}
		}
	}

	if(m_bAutoRelease)
	{
		if(m_lpBuffer != NULL)
		{
			CSystemManage::instance().FreeTemporaryMem(m_lpBuffer);
			m_lpBuffer = NULL;
		}
	}

	m_lpTempBuffer		   = NULL;
	m_nTempBufferSize	   = 0;
	m_nTempDataSize		   = 0;

	m_lpCircleBuffer	   = NULL;
	m_nCircleBufferSize	   = 0;
	m_nCircleDataSize	   = 0;

	m_lpObjectInfo		   = NULL;

	m_nBufferSectionNum    = 0;
	memset(m_arrTempSection, 0, sizeof(LPBYTE)*MAX_TEMP_SECTION);
}

/************************************************************************
	功能说明：
		分配缓存片段
************************************************************************/
int CServiceBson::AllocBufferSection()
{
	LPBUFFERSECTIONHEAD lpPreSectionHead;
	if(m_lpCurrentSection == NULL)
	{
		lpPreSectionHead  = NULL;
	}
	else
	{
		lpPreSectionHead = (LPBUFFERSECTIONHEAD)m_lpCurrentSection;
	}
	if(m_nFreeBufferSize >= m_nDefaultSectionSize)
	{
		m_lpCurrentSection  =  m_lpBuffer + m_nTotalDataSize;
		m_nFreeBufferSize	-= m_nDefaultSectionSize;
		m_nTotalDataSize	+= m_nDefaultSectionSize;
		m_nCurrentSectionNo++;
		((LPBUFFERSECTIONHEAD)m_lpCurrentSection)->m_nNextSectionOffset = 0;
	}
	else
	{
		m_lpCurrentSection = CSystemManage::instance().AllocTemporaryMem(m_nDefaultSectionSize);
		if(m_lpCurrentSection == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		m_nCurrentSectionNo++;
		((LPBUFFERSECTIONHEAD)m_lpCurrentSection)->m_nNextSectionOffset = 0;
	}
	
	if(lpPreSectionHead != NULL)
	{
		lpPreSectionHead->m_nNextSectionOffset = m_nExecutePlanDataSize;
	}
	if(m_nSectionStartOffset == 0)
	{
		m_nSectionStartOffset = m_nExecutePlanDataSize;
	}

	m_arrBufferSection[m_nBufferSectionNum]  = m_lpCurrentSection;
	m_nBufferSectionNum++;
	if(m_nBufferSectionNum >= 256)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}

	m_nExecutePlanDataSize   += sizeof(BUFFERSECTIONHEAD);
	m_nCurrentDataSize = sizeof(BUFFERSECTIONHEAD);
	m_nCurrentSectionSzie = m_nDefaultSectionSize;
	return MF_OK;
}

/************************************************************************
	功能说明：
		初始化缓存
	参数说明：
		lpBuffer：缓存指针
		nTotalBufferSize：缓存总大小
		bAutoRelease：是否自动释放
************************************************************************/
int CServiceBson::Initial(LPBYTE lpBuffer, UINT nTotalBufferSize, BOOL bAutoRelease)
{
	LPEXECUTEPLANBSON lpExecutePlan;
	
	lpExecutePlan = (LPEXECUTEPLANBSON)lpBuffer;
	Free();

	m_lpBuffer				  = lpBuffer;												//缓存指针
	m_nExecutePlanDataSize	  = lpExecutePlan->m_nTotalDataSize;						//执行计划中，所有数据的总大小(Bson缓存中的数据+缓存片段中的数据)
	m_nDefaultSectionSize	  = MF_BUFFERSECTION_SIZE;									//默认缓存片段大小
	m_nFreeBufferSize		  = nTotalBufferSize - lpExecutePlan->m_nTotalDataSize;		//缓存中现有空闲空间的大小，分配缓存片段时，先从该空间中分配，然后在从公共缓存中分配
	m_nBsonBufferSize		  = nTotalBufferSize;										//服务端完成对执行计划的解析之前BsonBufferSize为缓存总大小
	m_nTotalBufferSize		  = nTotalBufferSize;
	m_nBsonDataSize			  = lpExecutePlan->m_nBsonDataSize;							
	m_nSectionStartOffset	  = lpExecutePlan->m_nSectionStartOffset;																	

	m_lpCurrentSection		  = NULL;													//当前缓存片段指针
	m_nCurrentSectionNo		  = 0;														//当前缓存片段编号
	m_nCurrentDataSize		  = 0;														//当前片段中的数据大小
	m_nCurrentSectionSzie	  = 0;														//当前片段大小
	m_nBufferSectionNum		  = 0;														//片段数量

	m_bAutoRelease            = bAutoRelease;									    	//是否自动释放
	m_bReleaseBuffer		  = TRUE;

	m_nTempBufferSize		  = MF_TEMPBUFFER_SIZE;										//临时缓存大小
	m_nTempDataSize			  = 0;														//临时缓存中的数据大小，预留一半的空间存放临时DataID

	m_nRecordBufferSize		  = MF_RECORDBUFFER_SIZE;

	m_nCircleBufferSize		  = MF_RECYCLESECTION_SIZE;									//分配4K的空间给循环Buffer
	m_nCircleDataSize		  = 0;
	
	m_nTotalDataSize		  = 0;
	
	//分配空间存放临时Buffer
	if(m_nExecutePlanDataSize + MF_TEMPBUFFER_SIZE > m_nTotalBufferSize)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	else
	{
		m_lpTempBuffer		  = m_lpBuffer + (m_nTotalBufferSize - MF_RECORDBUFFER_SIZE - MF_RECYCLESECTION_SIZE - MF_TEMPBUFFER_SIZE);		//临时缓存指针
		m_nBsonBufferSize	  -= MF_TEMPBUFFER_SIZE;
		m_nFreeBufferSize	  -= MF_TEMPBUFFER_SIZE;
	}

	//分配空间存放循环Buffer
	if(m_nExecutePlanDataSize + MF_TEMPBUFFER_SIZE + MF_RECYCLESECTION_SIZE > m_nTotalBufferSize)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	else
	{
		m_lpCircleBuffer	  = m_lpBuffer + (m_nTotalBufferSize - MF_RECORDBUFFER_SIZE - MF_RECYCLESECTION_SIZE);							//循环缓存指针
		m_nBsonBufferSize	  -= MF_RECYCLESECTION_SIZE;
		m_nFreeBufferSize	  -= MF_RECYCLESECTION_SIZE;
	}

	//分配空间存放记录Buffer
	if(m_nExecutePlanDataSize + MF_TEMPBUFFER_SIZE + MF_RECYCLESECTION_SIZE + MF_RECORDBUFFER_SIZE > m_nTotalBufferSize)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	else
	{
		m_lpRecrodBuffer	  = m_lpBuffer + (m_nTotalBufferSize - MF_RECORDBUFFER_SIZE);													//记录缓存指针
		m_nBsonBufferSize	  -= MF_RECORDBUFFER_SIZE;
		m_nFreeBufferSize	  -= MF_RECORDBUFFER_SIZE;
	}

	if(lpExecutePlan->m_nFreeSectionAddrID != 0)
	{
		//UpDateReocrdset情况
		LPBYTE lpBuffer;
		UINT i, nBufferNum;

		lpBuffer   = m_lpBuffer + lpExecutePlan->m_nSectionStartOffset;
		nBufferNum = GetBufferNoFromAddrID(lpExecutePlan->m_nFreeSectionAddrID);
		for(i = 0; i < nBufferNum; i++)
		{
			m_arrBufferSection[m_nBufferSectionNum] = lpBuffer;
			m_nBufferSectionNum++;
			if(m_nBufferSectionNum > 256)
			{
				return MF_INNER_ALLOCMEM_FAILED;
			}
			if(i != nBufferNum - 1)
			{
				//最后一个片段
				lpBuffer		= m_lpBuffer + ((LPBUFFERSECTIONHEAD)lpBuffer)->m_nNextSectionOffset;
			}
		}
		m_nCurrentSectionNo     = nBufferNum;
		m_lpCurrentSection		= m_arrBufferSection[nBufferNum - 1];
		m_nCurrentDataSize		= (USHORT)lpExecutePlan->m_nFreeSectionAddrID;
		m_nCurrentSectionSzie	= m_nCurrentDataSize;										//UpDateReocrdset的数据区大小在客户端就已经固定
	}

	return MF_OK;
}

int CServiceBson::Initial(LPBYTE lpBuffer, UINT nTotalBufferSize, UINT nTempBufferSize, UINT nCircleBufferSize, UINT nRecordBufferSize)
{
	Free();

	m_lpBuffer				  = lpBuffer;												//缓存指针
	m_nFreeBufferSize		  = nTotalBufferSize;
	m_nBsonBufferSize		  = nTotalBufferSize;										//服务端完成对执行计划的解析之前BsonBufferSize为缓存总大小
	m_nTotalBufferSize		  = nTotalBufferSize;
	m_nBsonDataSize			  = 0;
	m_nSectionStartOffset	  = 0;
	m_nDefaultSectionSize	  = MF_BUFFERSECTION_SIZE;									//默认缓存片段大小

	m_lpCurrentSection		  = NULL;													//当前缓存片段指针
	m_nCurrentSectionNo		  = 0;														//当前缓存片段编号
	m_nCurrentDataSize		  = 0;														//当前片段中的数据大小
	m_nCurrentSectionSzie	  = 0;														//当前片段大小
	m_nBufferSectionNum		  = 0;														//片段数量
	m_nExecutePlanDataSize	  = 0;

	m_bAutoRelease            = FALSE;									    			//是否自动释放
	m_bReleaseBuffer		  = TRUE;

	m_nTempBufferSize		  = nTempBufferSize;										//临时缓存大小
	m_nTempDataSize			  = 0;														//临时缓存中的数据大小，预留一半的空间存放临时DataID

	m_nCircleBufferSize		  = nCircleBufferSize;										//分配4K的空间给循环Buffer
	m_nCircleDataSize		  = 0;

	m_nRecordBufferSize		  = nRecordBufferSize;
	
	m_nTotalDataSize		  = 0;
	//分配空间存放临时Buffer
	if(m_nTempBufferSize != 0)
	{
		if(m_nExecutePlanDataSize + m_nTempBufferSize > m_nTotalBufferSize)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		else
		{
			m_lpTempBuffer		  = m_lpBuffer + (m_nTotalBufferSize - m_nRecordBufferSize - m_nCircleBufferSize - m_nTempBufferSize);		//临时缓存指针
			m_nBsonBufferSize	  -= m_nTempBufferSize;
			m_nFreeBufferSize	  -= m_nTempBufferSize;
		}
	}

	//分配空间存放循环Buffer
	if(m_nCircleBufferSize != 0)
	{
		if(m_nExecutePlanDataSize + m_nTempBufferSize + m_nCircleBufferSize > m_nTotalBufferSize)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		else
		{
			m_lpCircleBuffer	  = m_lpBuffer + (m_nTotalBufferSize - m_nRecordBufferSize - m_nCircleBufferSize);							//循环缓存指针
			m_nBsonBufferSize	  -= m_nCircleBufferSize;
			m_nFreeBufferSize	  -= m_nCircleBufferSize;
		}
	}

	if(m_nRecordBufferSize != 0)
	{
		//分配空间存放记录Buffer
		if(m_nExecutePlanDataSize + m_nTempBufferSize + m_nCircleBufferSize + m_nRecordBufferSize > m_nTotalBufferSize)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		else
		{
			m_lpRecrodBuffer	  = m_lpBuffer + (m_nTotalBufferSize - m_nRecordBufferSize);													//记录缓存指针
			m_nBsonBufferSize	  -= m_nRecordBufferSize;
			m_nFreeBufferSize	  -= m_nRecordBufferSize;
		}
	}
	return MF_OK;
}
/************************************************************************
	功能说明：
		分配临时片段
	参数说明：
		nSize：片段大小
		lpBuffer：片段指针
	返回值：
		成功返回TempSection的编号，失败返回0
************************************************************************/
int CServiceBson::AllocTempSection(int& nSize, LPBYTE& lpBuffer)
{
	//按照m_nDefaultSectionSize的整数倍进行分配

	if(m_nFreeBufferSize >= nSize)
	{
		lpBuffer = m_lpBuffer + m_nTotalDataSize;
		m_nFreeBufferSize -= nSize;
		m_nTotalDataSize  += nSize;
	}
	else
	{	
		nSize = (nSize / m_nDefaultSectionSize + 1) * m_nDefaultSectionSize;
		lpBuffer = CSystemManage::instance().AllocTemporaryMem(nSize);
		if(lpBuffer == NULL)
		{
			return 0;
		}
	}

	m_arrTempSection[m_nTempSectionNum]  = lpBuffer;
	m_nTempSectionNum++;
	if(m_nTempSectionNum > MAX_TEMP_SECTION)
	{
		return 0;
	}

	return m_nTempSectionNum;
}
/************************************************************************
	功能说明：
		从临时缓存中分配空间
	参数说明：
		nLen：空间大小
		lpBuffer：需要分配的数据缓存
		nOffset：偏移
************************************************************************/
int CServiceBson::AllocFromTempBuffer(UINT nLen, LPBYTE &lpBuffer, UINT& nOffset)
{
	if(m_nTempDataSize + nLen > m_nTempBufferSize)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	
	nOffset  = m_nTempDataSize;
	m_nTempDataSize += nLen;
	lpBuffer = m_lpTempBuffer + nOffset;
	memset(lpBuffer, 0, nLen);

	return MF_OK;
}

int CServiceBson::AllocFromTempBuffer(UINT nLen, LPBYTE &lpBuffer)
{
	if(nLen > m_nTempBufferSize)
	{
		//释放原来的循环Buffer
		if(m_lpTempBuffer < m_lpBuffer || m_lpTempBuffer >= m_lpBuffer + m_nTotalBufferSize)
		{
			CSystemManage::instance().FreeTemporaryMem(m_lpTempBuffer);
		}

		//分配新的循环Buffer
		nLen = (nLen /2048 + 1)*2048;		//按照2K的整数倍进行分配
		m_lpTempBuffer = CSystemManage::instance().AllocTemporaryMem(nLen);
		if(m_lpTempBuffer == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		m_nTempBufferSize = nLen;
	}

	lpBuffer = m_lpTempBuffer;
	return MF_OK;
}

/************************************************************************
	功能说明：
		从循环缓存中分配空间
	参数说明：
		nLen：空间大小
		lpBuffer：需要分配的数据缓存
************************************************************************/
int CServiceBson::AllocFromCircleBuffer(UINT nLen, LPBYTE &lpBuffer)
{
	UINT nSize;
	USHORT nOffset;

	nSize = nLen;
	if(nSize > m_nCircleBufferSize)
	{
		//释放原来的循环Buffer
		if(m_lpCircleBuffer < m_lpBuffer || m_lpCircleBuffer >= m_lpBuffer + m_nTotalBufferSize)
		{
			CSystemManage::instance().FreeTemporaryMem(m_lpCircleBuffer);
		}

		//分配新的循环Buffer
		nSize = (nSize /2048 + 1)*2048;		//按照2K的整数倍进行分配
		m_lpCircleBuffer = CSystemManage::instance().AllocTemporaryMem(nSize);
		if(m_lpCircleBuffer == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		m_nCircleDataSize		= 0;
		m_nCircleBufferSize		= nSize;
	}

	if(m_nCircleDataSize + nLen > m_nCircleBufferSize)
	{
		m_nCircleDataSize = 0;
	}
	nOffset  = m_nCircleDataSize;
	m_nCircleDataSize += nLen;
	lpBuffer = m_lpCircleBuffer + nOffset;
	memset(lpBuffer, 0, nLen);
	return MF_OK;
}

/************************************************************************
	功能说明：
		从记录缓存中分配空间
	参数说明：
		nLen：记录长度
		lpBuffer：需要分配的数据缓存
************************************************************************/
int CServiceBson::AllocFromRecordBuffer(UINT nLen, LPBYTE &lpBuffer)
{
	if(nLen > m_nRecordBufferSize)
	{
		//释放原来的循环Buffer
		if(m_lpRecrodBuffer < m_lpBuffer || m_lpRecrodBuffer >= m_lpBuffer + m_nTotalBufferSize)
		{
			CSystemManage::instance().FreeTemporaryMem(m_lpRecrodBuffer);
		}

		//分配新的循环Buffer
		nLen = (nLen /2048 + 1)*2048;		//按照2K的整数倍进行分配
		m_lpRecrodBuffer = CSystemManage::instance().AllocTemporaryMem(nLen);
		if(m_lpRecrodBuffer == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		m_nRecordBufferSize	= nLen;
	}

	lpBuffer = m_lpRecrodBuffer;

	return MF_OK;
}
/************************************************************************
	功能说明：
		从临时缓存中获取指针
	参数说明：
		nOffset：偏移
************************************************************************/
LPBYTE CServiceBson::GetPtrFromTempBuffer(UINT nOffset)
{
	return m_lpTempBuffer + nOffset;
}


/************************************************************************
	功能说明：
		将地址ID转换为地址指针
	参数说明：
		nAddrID：地址ID
		lpAddr：地址指针
************************************************************************/
int CServiceBson::ConvertAddrID2Addr(UINT nAddrID, LPBYTE& lpAddr)
{
	LPBYTE lpBuffer;
	USHORT nBufferNo, nOffset;

	if(nAddrID == 0)
	{
		return MF_CREATEPLAN_INVALIDBUFFERNO_FAILED;
	}

	nBufferNo = GetBufferNoFromAddrID(nAddrID);
	nOffset	  = (USHORT)nAddrID;

	if(nBufferNo > m_nBufferSectionNum)
	{
		lpAddr   = NULL;
	}
	else
	{
		lpBuffer = m_arrBufferSection[nBufferNo - 1];
		lpAddr   = lpBuffer + nOffset; 
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取片段起始地址
	参数说明：
		nSectionNo：片段编号
		lpAddr：地址指针
************************************************************************/
void CServiceBson::GetSectionBufferAddr(int nSectionNo, LPBYTE& lpAddr)
{
	if(nSectionNo > m_nBufferSectionNum)
	{
		lpAddr = NULL;
	}
	else
	{
		lpAddr = m_arrBufferSection[nSectionNo - 1];
	}
}

/************************************************************************
	功能说明：
		获取片段中实际数据的起始地址指针（除去片段头）
	参数说明：
		nSectionNo：片段编号
		lpAddr：地址指针
************************************************************************/
void CServiceBson::GetSectionDataAddr(int nSectionNo, LPBYTE& lpAddr)
{
	if(nSectionNo > m_nBufferSectionNum)
	{
		lpAddr = NULL;
	}
	else
	{
		lpAddr = m_arrBufferSection[nSectionNo - 1] + sizeof(BUFFERSECTIONHEAD);
	}
}
/************************************************************************
	功能说明：
		备份BsonBuffer
	参数说明：
		stBson：Bson对象
		lpExecutePlan：执行计划
************************************************************************/
int CServiceBson::BackupBsonBuffer(CServiceBson& stBson)
{
	*this = stBson;
	m_lpBuffer = CSystemManage::instance().AllocTemporaryMem(m_nBsonBufferSize);
	if(NULL == m_lpBuffer)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	memcpy(m_lpBuffer, stBson.GetBuffer(), m_nBsonBufferSize);

	m_bAutoRelease		= TRUE;
	m_bReleaseBuffer	= FALSE;
	return MF_OK;
}

/************************************************************************
	功能说明：
		清理
************************************************************************/
void CServiceBson::ClearBsonBuffer()
{
	m_lpTempBuffer		   = NULL;
	m_nTempBufferSize	   = 0;
	m_nTempDataSize		   = 0;
	m_lpCircleBuffer	   = NULL;
	m_nCircleBufferSize	   = 0;
	m_nCircleDataSize	   = 0;
	m_lpObjectInfo		   = NULL;
	m_nBufferSectionNum    = 0;
	m_nBsonDataSize		   = 0;
	m_nExecutePlanDataSize = 0;
	m_nTotalDataSize       = 0;
	memset(m_lpBuffer, 0, m_nBsonBufferSize);
}
