﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "ServiceCommonDef.h"
#include "Expression.h"
//为RecordSet创建的Bson
class CRecordSetBson
{
public:
	CRecordSetBson(CServiceBson* pServiceBson);
	~CRecordSetBson(void);

private:
	CServiceBson*			m_pServiceBson;
	CExpression				m_stExpression;
	LPOBJECTDEF				m_lpObjectInfo;
	TRANSACTIONARRAY		m_stTransactionArray;
	MF_OBJECT_TYPE			m_bObjectType;					//对象类型：用于区别节点表和关系表
	BOOL					m_bDetials;
private:
	LPBYTE					m_lpBuffer;
	LPBYTE					m_lpFirstBuffer;				//第一个Buffer
	UINT					m_nBsonBufferSize;				//Bson大小
	UINT					m_nBsonDataSize;				//Bson中的数据量
	UINT					m_nTotalDataSize;				//数据总大小
	UINT					m_nRecordsetBufferNo;			//结果集缓存编号
	UINT					m_nRecordsetBsonSize;			//结果集Bson大小
private:
	
	//设置数据的长度(主要用于在Buffer中预留空间)
	inline void SetDataLen(int nLen)
	{
		m_nBsonDataSize = nLen;
	}

private:	
	//分配Bson空间
	int AllocRecordsetBuffer(int nBufferSize);
	
	//从BSON缓存中分配空间
	int AllocFromBsonBuffer(UINT nLen, UINT &nOffset, LPBYTE &lpAddr);

	//创建字段Buffer(系统对象)
	int BuildRecordBuffer(LPSINGLERECORD lpSysDataArray, LPEXECUTEFIELDBSON lpExecuteField, int nFieldCount, int& nRecordLen);

	//创建字段Buffer(系统对象聚合函数)
	int BuildRecordBuffer(CSysRecordContainer* pRecordContainer, LPEXECUTEFIELDBSON lpExecuteField, int& nRecordLen);

	//创建字段Buffer(普通对象)
	int BuildRecordBuffer(LPBYTE lpRecordBuffer, int nBufferLen, LPEXECUTEFIELDBSON lpExecuteField, int nFieldCount, int& nRecordLen);

	//创建字段Buffer(普通对象聚合函数)
	int BuildRecordBuffer(CDataIDContainer* pDataIDContainer, LPEXECUTEFIELDBSON lpExecuteField, int& nRecordLen);

	//字符串转换
	inline void ConvertIntToChar(char * lpszTitle, int nVal);
	
	//填充字段信息
	int SetFieldInfo(LPQUERYEXECUTEPLANBSON lpQueryPlan, LPOBJECTDEF lpObjectInfo, LPRECORDSETHEAD lpRecordsetHead);

	//将字段值写入指定位置
	int WriteFieldData(MF_SYS_FIELDTYPE bFieldType, BYTE bFieldNo, VARDATA &varData, LPBYTE lpAddr = NULL);

public:
	//初始化
	int Initial(MF_OBJECT_TYPE bObjectType, BOOL bDetitals = FALSE);

	//分离Buffer
	LPBYTE DetachBuffer();

	//创建结果集BSON，用于普通表
	int BuildBson(LPQUERYEXECUTEPLANBSON lpQueryPlan, long long nTimestamp, CDataIDContainer* pDataIDContainer, LPBYTE & lpBsonBuffer, int &nBsonSize);
	//创建结果集BSON，用于系统表
	int BuildBson(LPQUERYEXECUTEPLANBSON lpQueryPlan, LPOBJECTDEF lpObjectInfo, CSysRecordContainer* pRecordContainer, LPBYTE & lpBsonBuffer, int &nBsonSize);
};
