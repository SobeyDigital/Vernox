﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "RecordSetBson.h"
#include "MemoryFile.h"
#include "MapSimple.h"
CRecordSetBson::CRecordSetBson(CServiceBson* pServiceBson)
{
	m_pServiceBson			= pServiceBson;
	m_lpBuffer				= NULL;
	m_lpFirstBuffer			= NULL;
	m_nBsonBufferSize		= 0;
	m_nBsonDataSize			= 0;
	m_nTotalDataSize		= 0;
	m_nRecordsetBufferNo	= 0;
	m_nRecordsetBsonSize	= 0;
	m_bObjectType			= 0;
	m_bDetials				= FALSE;
}

CRecordSetBson::~CRecordSetBson(void)
{
}

/************************************************************************
	功能说明：
		分配空间存放数据
	参数说明：
		nBufferSize：Buffer长度
************************************************************************/
int CRecordSetBson::AllocRecordsetBuffer(int nBufferSize)
{
	int nBufferNo;
	nBufferNo = m_pServiceBson->AllocTempSection(nBufferSize, m_lpBuffer);
	if(nBufferNo == 0)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	else if(m_nRecordsetBufferNo == 0)
	{
		m_nRecordsetBufferNo = nBufferNo; 
	}

	if(m_lpFirstBuffer == NULL)
	{
		m_lpFirstBuffer = m_lpBuffer;
	}
	m_nBsonBufferSize = nBufferSize;
	m_nBsonDataSize   = sizeof(int);			//预留一个int长度的空间，存放缓存中数据的实际长度

	return MF_OK;
}

/************************************************************************
		功能说明：
			从BSON缓存中分配空间
		参数说明：
			nLen：空间大小
			nOffset：偏移
			lpAddr：地址指针
************************************************************************/
int CRecordSetBson::AllocFromBsonBuffer(UINT nLen, UINT &nOffset, LPBYTE &lpAddr)
{
	int nRet, nNewDataLen, nOldDataLen;

	nNewDataLen = 0;						
	nOldDataLen = 0;						
											
	if(m_lpBuffer == NULL)
	{
		return MF_INNER_ALLOCMEM_FAILED;	
	}

	nNewDataLen = m_nBsonDataSize;						//在现有数据局末尾插入新数据
	nOldDataLen = nNewDataLen;
	nNewDataLen += nLen;
	if(nNewDataLen > m_nBsonBufferSize)
	{	
		*(int*)m_lpBuffer = nOldDataLen;				//记录当前缓存中实际数据的长度
		nRet = AllocRecordsetBuffer(nNewDataLen * 4);	//分配新的缓存，按照4倍膨胀
		if(nRet != MF_OK)
		{
			return nRet;
		}
		
		nNewDataLen = m_nBsonDataSize;
		nOldDataLen = nNewDataLen;
	}

	m_nBsonDataSize			+= nLen;
	m_nTotalDataSize		+= nLen;
	nOffset					= nOldDataLen;
	lpAddr					= m_lpBuffer + nOldDataLen;
	m_nRecordsetBsonSize	+= nLen;
	return MF_OK;
}

/************************************************************************
	功能说明：
		创建一单条记录的Buffer
	参数说明：
		lpDataArray：记录集数组
		lpExecuteField：执行字段
		nFieldCount：字段数
		nRecordLen：记录长度
a************************************************************************/
int CRecordSetBson::BuildRecordBuffer(LPSINGLERECORD lpSysDataArray, LPEXECUTEFIELDBSON lpExecuteField, int nFieldCount, int& nRecordLen)
{
	int nRet, i;
	VARDATA varData;
	LPMATHEXPBSON lpExpBson;

	nRecordLen = 0;
	for(i = 0; i < nFieldCount; i++)
	{
		lpExpBson = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpExecuteField->m_nExpOffset);
		if(lpExpBson->m_bValType == MF_SYS_FIELDTYPE_NULL)
		{
			if(lpExecuteField->m_nNextOffset != 0)
			{
				lpExecuteField = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpExecuteField->m_nNextOffset);
			}
			continue;
		}
		
		nRet = m_stExpression.GetExpressionResult(lpSysDataArray, lpExpBson, varData);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		nRet = WriteFieldData(varData.m_vt, i, varData, NULL);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRecordLen += varData.m_nBufferLen;

		if(lpExecuteField->m_nNextOffset != 0)
		{
			lpExecuteField = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpExecuteField->m_nNextOffset);
		}
	}
	return MF_OK;
}

//创建字段Buffer
int CRecordSetBson::BuildRecordBuffer(CSysRecordContainer* pRecordContainer, LPEXECUTEFIELDBSON lpExecuteField, int& nRecordLen)
{
	int nRet;
	VARDATA varResult;
	LPMATHEXPBSON lpExpBson;

	lpExpBson = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpExecuteField->m_nExpOffset);
	//1.计算查询字段值
	if(lpExpBson->m_bValType == MF_SYS_FIELDTYPE_NULL)
	{
		//如果表达式为空类型，则不进行序列化
		varResult.m_vt = MF_VARDATA_NULL;			
	}
	else
	{
		nRet = m_stExpression.GetExpressionResult(pRecordContainer, lpExpBson, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	nRet = WriteFieldData(varResult.m_vt, 0, varResult, NULL);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	nRecordLen = varResult.m_nBufferLen;
	return MF_OK;
}

//创建字段Buffer
int CRecordSetBson::BuildRecordBuffer(LPBYTE lpRecordBuffer, int nBufferLen, LPEXECUTEFIELDBSON lpExecuteField, int nFieldCount, int& nRecordLen)
{
	int i, nRet;
	VARDATA varData;
	LPMATHEXPBSON lpExpBson;

	nRecordLen = 0;
	for(i = 0; i < nFieldCount; i++)
	{
		lpExpBson = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpExecuteField->m_nExpOffset);
		//如果表达式为空类型，则不进行序列化
		if(lpExpBson->m_bValType == MF_SYS_FIELDTYPE_NULL)
		{
			if(lpExecuteField->m_nNextOffset != 0)
			{
				lpExecuteField = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpExecuteField->m_nNextOffset);
			}
			continue;				
		}
	
		nRet = m_stExpression.GetExpressionResult(0, lpRecordBuffer, nBufferLen, lpExpBson, varData);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	
		nRet = WriteFieldData(varData.m_vt, i, varData, NULL);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRecordLen += varData.m_nBufferLen;


		if(lpExecuteField->m_nNextOffset != 0)
		{
			lpExecuteField = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpExecuteField->m_nNextOffset);
		}
	}
	return MF_OK;
}

//创建字段Buffer
int CRecordSetBson::BuildRecordBuffer(CDataIDContainer* pDataIDContainer, LPEXECUTEFIELDBSON lpExecuteField, int& nRecordLen)
{
	int nRet;
	VARDATA varResult;
	LPMATHEXPBSON lpExpBson;
	
	lpExpBson = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpExecuteField->m_nExpOffset);
	//1.计算查询字段值
	if(lpExpBson->m_bValType == MF_SYS_FIELDTYPE_NULL)
	{
		//如果表达式为空类型，则不进行序列化
		varResult.m_vt = MF_VARDATA_NULL;			
	}
	else
	{
		nRet = m_stExpression.GetExpressionResult(pDataIDContainer, lpExpBson, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	
	nRet = WriteFieldData(varResult.m_vt, 0, varResult, NULL);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRecordLen += varResult.m_nBufferLen;
	return MF_OK;
}

/************************************************************************
	功能说明：
		填充字段信息
	参数说明：
		lpszTitle：字段Title
		nVal:值
************************************************************************/
void CRecordSetBson::ConvertIntToChar(char * lpszTitle, int nVal)
{
	int arVal[10], m, n, i;
	
	n = nVal;
	i = 0;
	while(TRUE)
	{
		m = n % 10;
		arVal[i++] = m;
		n = n / 10;
		if(n == 0 || i >= 10)
		{
			break;
		}
	}

	m = 1;
	for(n = i - 1;n >= 0;n--,m++)
	{
		lpszTitle[m] = arVal[n] + '0';
	}
}

/************************************************************************
	功能说明：
		填充字段信息
	参数说明：
		lpQueryExecutePlane：查询执行计划
		lpObjectInfo:对象信息
		lpRecordsetHead:结果集头
************************************************************************/
int CRecordSetBson::SetFieldInfo(LPQUERYEXECUTEPLANBSON lpQueryPlan, LPOBJECTDEF lpObjectInfo, LPRECORDSETHEAD lpRecordsetHead)
{
	BYTE bFieldNo;
	LPBYTE lpAddr;
	int i, nRet, nLen;
	LPMATHEXPBSON lpExpBson;
	UINT nOffset, nFieldOffset;
	LPRECORDFIELD lpRecordField;
	LPEXECUTEFIELDBSON lpFieldBson;
	char *pExpName, *pExpTitle, pXMLName[32], *pFieldName, *pFieldTitle, *pRsName, *pObjectName;

	lpAddr = NULL;
	nRet   = AllocFromBsonBuffer((lpQueryPlan->m_nExcuteFieldNum - 1)*sizeof(RECORDFIELD), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	lpRecordField = lpRecordsetHead->m_lpRecordField;
	nFieldOffset  = lpQueryPlan->m_nExcuteFieldOffset;
	for(i = 0; i < lpQueryPlan->m_nExcuteFieldNum; i++)
	{
		lpFieldBson = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(nFieldOffset);
		lpExpBson	= (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpFieldBson->m_nExpOffset);
		
		pExpTitle = NULL;
		if(lpFieldBson->m_nExpTitleOffset != 0)
		{
			pExpTitle = (char*)m_pServiceBson->ConvertOffset2Addr(lpFieldBson->m_nExpTitleOffset);
		}
		pExpName = (char*)m_pServiceBson->ConvertOffset2Addr(lpFieldBson->m_nExpNameOffset);

		sprintf(pXMLName, "c%d", i);
		if(NULL != pExpTitle)
		{
			nLen = strlen(pExpTitle);
		}
		else
		{
			nLen = strlen(pExpName);
		}
		nLen = min(nLen, 31);
		
		//分配空间存放各字段
		lpAddr = NULL;
		nRet = AllocFromBsonBuffer(strlen(lpObjectInfo->m_lpszName) + 1, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pObjectName = (char*)lpAddr;
		lpRecordField[i].m_nObjectNameOffset = (UINT)(lpAddr - (LPBYTE)lpRecordsetHead);
		strcpy(pObjectName,  lpObjectInfo->m_lpszName);

		lpAddr = NULL;
		nRet = AllocFromBsonBuffer(strlen(pXMLName) + 1, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pFieldName = (char*)lpAddr;
		lpRecordField[i].m_nFieldNameOffset = (UINT)(lpAddr - (LPBYTE)lpRecordsetHead);
		strcpy(pFieldName,  pXMLName);

		lpAddr = NULL;
		nRet = AllocFromBsonBuffer(nLen + 1, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pRsName = (char*)lpAddr;
		lpRecordField[i].m_nRsNameOffset = (UINT)(lpAddr - (LPBYTE)lpRecordsetHead);;
		if(NULL != pExpTitle)
		{
			strcpy(pRsName, pExpTitle);
		}
		else
		{
			strcpy(pRsName, pExpName);
		}

		lpAddr = NULL;
		nRet = AllocFromBsonBuffer(strlen(pExpName) + 1, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pFieldTitle = (char*)lpAddr;
		lpRecordField[i].m_nTitleOffset = (UINT)(lpAddr - (LPBYTE)lpRecordsetHead);;
		strcpy(pFieldTitle, pExpName);

		switch(lpFieldBson->m_bExpressionType)
		{
		case MF_EXPRESSION_FIELD:
			bFieldNo = lpFieldBson->m_bFieldNo;
			lpRecordField[i].m_bFieldNameType = MF_PARAMETER_FIELDTYPE_ORIGINAL;
			lpRecordField[i].m_bFieldType	  = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;
			lpRecordField[i].m_bAllowNull	  = lpObjectInfo->m_lpField[bFieldNo - 1].m_bAllowNull;
		
			if(lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_CHAR)
			{
				lpRecordField[i].m_bMaxLen = lpObjectInfo->m_lpField[bFieldNo - 1].m_bCharLen;					//MAXLEN是不包含结束符0的字符串长度
			}
			break;
		case MF_EXPRESSION_COMMFUN:
			lpRecordField[i].m_bFieldType		= lpExpBson->m_bValType;
			lpRecordField[i].m_bFieldNameType	= MF_PARAMETER_FIELDTYPE_COMMFUN;
			lpRecordField[i].m_bAllowNull		= 1;
			break;
		case MF_EXPRESSION_AGGREFUN:
			lpRecordField[i].m_bFieldType		= lpExpBson->m_bValType;
			lpRecordField[i].m_bFieldNameType	= MF_PARAMETER_FIELDTYPE_AGGREFUN;
			lpRecordField[i].m_bAllowNull		= 1;
			break;
		case MF_EXPRESSION_CONSTMATH:
		case MF_EXPRESSION_VARMATH:
			lpRecordField[i].m_bFieldType		= lpExpBson->m_bValType;
			lpRecordField[i].m_bFieldNameType	= MF_PARAMETER_FIELDTYPE_EXPRESSION;
			lpRecordField[i].m_bAllowNull		= 1;
			break;
		}
		if(lpFieldBson->m_nNextOffset != 0)
		{
			nFieldOffset = lpFieldBson->m_nNextOffset;
		}
	}
	lpRecordsetHead->m_nRecordBufferOffset = m_nRecordsetBsonSize;
	return MF_OK;
}

/************************************************************************
		功能说明：
			将字段值写入指定位置
		参数说明：
			pInsertAddr：指定的位置
			bFieldType：字段类型
			bFieldNo：字段编号
			varData：字段值
************************************************************************/
int CRecordSetBson::WriteFieldData(MF_SYS_FIELDTYPE bFieldType, BYTE bFieldNo, VARDATA &varData, LPBYTE lpAddr)
{
	UINT nOffset;
	int nRet, nLen;

	nLen = 0;
	switch(bFieldType)
	{
	case MF_SYS_FIELDTYPE_NULL:
		break;
	case MF_SYS_FIELDTYPE_INT:
		nLen = sizeof(BYTE) + sizeof(int);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((int*)lpAddr) = varData.m_nValue;
		break;
	case MF_SYS_FIELDTYPE_BIGINT:
		nLen = sizeof(BYTE) + sizeof(long long);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((long long*)lpAddr) = varData.m_llValue;
		break;
	case MF_SYS_FIELDTYPE_DATE:
	case MF_SYS_FIELDTYPE_DOUBLE:
		nLen = sizeof(BYTE) + sizeof(double);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((double*)lpAddr) = varData.m_dblValue;
		break;
	case MF_SYS_FIELDTYPE_CHAR:
	case MF_SYS_FIELDTYPE_VARCHAR:
	case MF_SYS_FIELDTYPE_CLOB:
	case MF_SYS_FIELDTYPE_BLOB:
		if(varData.m_nStrLen < 250)
		{
			nLen = sizeof(BYTE) + sizeof(BYTE) + varData.m_nStrLen;
			nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			*((BYTE*)lpAddr) = bFieldNo;
			lpAddr += sizeof(BYTE);
			*((BYTE*)lpAddr) = varData.m_nStrLen;
			lpAddr += sizeof(BYTE);
			memcpy(lpAddr, varData.m_lpszValue, varData.m_nStrLen);
		}
		else
		{	
			nLen = sizeof(BYTE) + sizeof(BYTE) + sizeof(int) + varData.m_nStrLen;
			nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			*((BYTE*)lpAddr) = bFieldNo;
			lpAddr += sizeof(BYTE);
			*((BYTE*)lpAddr) = 255;
			lpAddr += sizeof(BYTE);
			*((int*)lpAddr) = varData.m_nStrLen;
			lpAddr += sizeof(int);
			memcpy(lpAddr, varData.m_lpszValue, varData.m_nStrLen);
		}
		break;
	}

	varData.m_nBufferLen = nLen;
	return MF_OK;
}

/************************************************************************
	功能说明：
		初始化
	参数说明：
		bObjectType：对象类型
		bDetitals：是否显示细节(用于图数据库)
************************************************************************/
int CRecordSetBson::Initial(MF_OBJECT_TYPE bObjectType,  BOOL bDetitals)
{
	int nRet;
	LPEXECUTEPLANBSON lpExecutePlan;
	lpExecutePlan = (LPEXECUTEPLANBSON)m_pServiceBson->GetBuffer();
	
	m_stTransactionArray.m_bNum   = lpExecutePlan->m_nTransactionNum;
	m_stTransactionArray.m_pArray = (long long*)m_pServiceBson->GetPtrFromTempBuffer(lpExecutePlan->m_nTransactionOffset);

	nRet = CSystemManage::instance().GetObjectInfo(lpExecutePlan->m_nObjectID, m_lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	m_bObjectType  = bObjectType;
	m_stExpression.Initial(m_pServiceBson, m_lpObjectInfo);

	m_bDetials = bDetitals;
	return MF_OK;
}

/************************************************************************
		功能说明：
			分离Buffer
************************************************************************/
LPBYTE CRecordSetBson::DetachBuffer()
{
	LPBYTE lpRetBuffer;
	lpRetBuffer			= m_lpFirstBuffer;
	*(int*)m_lpBuffer	= m_nBsonDataSize;

	m_lpBuffer			= NULL;
	m_lpFirstBuffer		= NULL;
	m_nBsonBufferSize	= 0;
	m_nBsonDataSize		= 0;
	return lpRetBuffer;
}

/************************************************************************
	功能说明：
		创建BSON
	参数说明：
		lpQueryPlan：查询执行计划
		nTimestamp：时间戳
		pDataIDContainer：DataID容器
		pBsonBuffer：BSON缓存
		nBsonSize：BSON缓存大小
************************************************************************/
int CRecordSetBson::BuildBson(LPQUERYEXECUTEPLANBSON lpQueryPlan, long long nTimestamp, CDataIDContainer* pDataIDContainer, LPBYTE & lpBsonBuffer, int &nBsonSize)
{
	UINT nOffset;
	LPBYTE lpAddr;
	CMemoryFile* pFile;
	long long nDataID, *pDataID; 
	RECORDDATAINFO stRecordInfo;
	LPRECORDSETHEAD lpRecordsetHead;
	IVirtualMemoryFile* pVirtualFile;
	LPEXECUTEFIELDBSON lpExecuteField;
	int i, nRet, nRecordLen, nRecordNum, nFieldNum, *pRecordLen;
	nRet = CSystemManage::instance().GetMemoryFileInstance(m_lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile			= (CMemoryFile*)pVirtualFile;
	nFieldNum		= lpQueryPlan->m_nExcuteFieldNum;
	lpExecuteField	= (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpQueryPlan->m_nExcuteFieldOffset);
	
	stRecordInfo.m_lpTransactionArray = &m_stTransactionArray;
	stRecordInfo.m_nTimestamp		  = nTimestamp;

	//1.将Bson中的剩余空间全部分配给CRecordSetBson
	nRet = AllocRecordsetBuffer(m_pServiceBson->GetFreeBufferSize());
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//2.分配空间存放记录头
	lpAddr = NULL;
	nRet = AllocFromBsonBuffer(sizeof(RECORDSETHEAD), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpRecordsetHead = (LPRECORDSETHEAD)lpAddr;

	//3.填充字段信息
	nRet = SetFieldInfo(lpQueryPlan, m_lpObjectInfo, lpRecordsetHead);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//4.序列化记录
	if(lpQueryPlan->m_bAggreFun)
	{ 
		//给记录的长度和记录的DataID分配空间
		lpAddr = NULL;
		nRet = AllocFromBsonBuffer(sizeof(int), nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pRecordLen = (int*)lpAddr;

		lpAddr = NULL;
		nRet = AllocFromBsonBuffer(sizeof(long long), nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pDataID = (long long*)lpAddr;

		nRet = BuildRecordBuffer(pDataIDContainer, lpExecuteField, nRecordLen);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		*pRecordLen = nRecordLen+sizeof(long long)+sizeof(int);
		*pDataID	= 1;
		nRecordNum  = 1;
	}
	else
	{
		pDataIDContainer->MoveFirst();
		nRecordNum = 0;
		for(i = 0; i < pDataIDContainer->size(); i++)
		{
			nRet = pDataIDContainer->NextDataID(nDataID);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			stRecordInfo.m_nDataID = nDataID;
			nRet = pFile->GetRecordBuffer(*m_pServiceBson, &stRecordInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(stRecordInfo.m_lpRecordBuffer == NULL)
			{
				continue;
			}

			//给记录的长度和记录的DataID分配空间
			lpAddr = NULL;
			nRet = AllocFromBsonBuffer(sizeof(int), nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pRecordLen = (int*)lpAddr;

			lpAddr = NULL;
			nRet = AllocFromBsonBuffer(sizeof(long long), nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pDataID = (long long*)lpAddr;

			nRet = BuildRecordBuffer(stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, lpExecuteField, nFieldNum, nRecordLen);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			*pRecordLen = nRecordLen+sizeof(long long)+sizeof(int);
			*pDataID	= nDataID;
			nRecordNum++;
		}
	}
	lpRecordsetHead->m_nFieldNum			= nFieldNum;
	lpRecordsetHead->m_nRowNum				= nRecordNum;
	lpRecordsetHead->m_bModify				= 1;
	lpRecordsetHead->m_bDatabaseType		= MF_DATABASE_MEMDB;
	lpRecordsetHead->m_bStartBufferNo		= (BYTE)m_nRecordsetBufferNo;

	nBsonSize    = m_nTotalDataSize;
	lpBsonBuffer = DetachBuffer();
	return MF_OK;
}

int CRecordSetBson::BuildBson(LPQUERYEXECUTEPLANBSON lpQueryPlan, LPOBJECTDEF lpObjectInfo, CSysRecordContainer* pRecordContainer, LPBYTE & lpBsonBuffer, int &nBsonSize)
{
	UINT nOffset;
	LPBYTE lpAddr;
	long long* pDataID;
	LPSINGLERECORD lpSingleRecord;
	LPRECORDSETHEAD lpRecordsetHead;
	LPEXECUTEFIELDBSON lpExecuteField;
	int i, nRet, nFieldNum, nRecordNum, nRecordLen, *pRecordLen;
	
	nFieldNum  = lpQueryPlan->m_nExcuteFieldNum;
	if(nFieldNum == 0)
	{
		return MF_COMMON_INVALID_FIELD;
	}

	lpExecuteField	= (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpQueryPlan->m_nExcuteFieldOffset);
	
	//1.将Bson中的剩余空间全部分配给CRecordSetBson
	nRet = AllocRecordsetBuffer(m_pServiceBson->GetFreeBufferSize());
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//2.分配空间存放记录头
	lpAddr = NULL;
	AllocFromBsonBuffer(sizeof(RECORDSETHEAD), nOffset, lpAddr);
	lpRecordsetHead = (LPRECORDSETHEAD)lpAddr;

	//3.填充字段信息
	nRet = SetFieldInfo(lpQueryPlan, lpObjectInfo, lpRecordsetHead);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	if(lpQueryPlan->m_bAggreFun)
	{
		//给记录的长度和记录的DataID分配空间
		lpAddr = NULL;
		nRet = AllocFromBsonBuffer(sizeof(int), nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pRecordLen = (int*)lpAddr;

		lpAddr = NULL;
		nRet = AllocFromBsonBuffer(sizeof(long long), nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pDataID = (long long*)lpAddr;

		nRet = BuildRecordBuffer(pRecordContainer, lpExecuteField, nRecordLen);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		*pRecordLen = nRecordLen+sizeof(long long)+sizeof(int);
		*pDataID	= 1;
		nRecordNum	= 1;
	}
	else
	{
		pRecordContainer->MoveFirst();
		nRecordNum = 0;
		for(i = 0; i < pRecordContainer->size(); i++)
		{	
			nRet = pRecordContainer->NextRecord(lpSingleRecord);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpSingleRecord != NULL && !lpSingleRecord->m_bValid)
			{
				continue;
			}

			//给记录的长度和记录的DataID分配空间
			lpAddr = NULL;
			nRet = AllocFromBsonBuffer(sizeof(int), nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pRecordLen = (int*)lpAddr;

			lpAddr = NULL;
			nRet = AllocFromBsonBuffer(sizeof(long long), nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pDataID = (long long*)lpAddr;
			
			nRet = BuildRecordBuffer(lpSingleRecord,lpExecuteField, nFieldNum, nRecordLen);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			*pRecordLen = nRecordLen+sizeof(long long)+sizeof(int);
			*pDataID	= i+1;
			nRecordNum++;
		}
	}

	//创建结果集BSON
	lpRecordsetHead->m_nFieldNum			= nFieldNum;
	lpRecordsetHead->m_nRowNum				= nRecordNum;
	lpRecordsetHead->m_bModify				= 0;
	lpRecordsetHead->m_bDatabaseType		= MF_DATABASE_MEMDB;
	lpRecordsetHead->m_bStartBufferNo		= (BYTE)m_nRecordsetBufferNo;

	nBsonSize	 = m_nTotalDataSize;
	lpBsonBuffer = DetachBuffer();

	return MF_OK;
}

