﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "CharCompare.h"

CCharCompare::CCharCompare(void)
{
	m_pKMPNextTable	= NULL;
	m_pCharacterCount = NULL;
	m_nKMPNextSize = 0;
	m_pCharacterPinYinSortTable = new SHORT[MF_CHARACTER_SIZE];
	memset(m_pCharacterPinYinSortTable, 0, MF_CHARACTER_SIZE * sizeof(SHORT));
}

CCharCompare::~CCharCompare(void)
{
	if(m_pCharacterPinYinSortTable != NULL)
	{
		delete [] m_pCharacterPinYinSortTable;
		m_pCharacterPinYinSortTable = NULL;
	}
	if(m_pKMPNextTable != NULL)
	{
		delete [] m_pKMPNextTable;
		m_pKMPNextTable = NULL;
	}
	if (m_pCharacterCount != NULL)
	{
		delete[] m_pCharacterCount;
		m_pCharacterCount = NULL;
	}
}

int CCharCompare::GetUnicode(const char *cSrc)
{
	int nUnicode;
	BYTE bSrc = cSrc[0];
	DWORD dwUnicode = 0;
	if(bSrc>=0 && bSrc<128)
	{
		dwUnicode += bSrc;
	}
	else if(bSrc>=192 && bSrc<224)//2字节
	{
		dwUnicode = cSrc[0] & 0x1F;   //00011111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[1] & 0x3F;//00111111
	}
	else if(bSrc>=224 && bSrc<240)//3字节
	{
		dwUnicode = cSrc[0] & 0x0F; //00001111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[1] & 0x3F;//00111111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[2] & 0x3F;//00111111
	}
	else if(bSrc>=224 && bSrc<248)//4字节
	{
		dwUnicode = cSrc[0] & 0x07; //00000111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[1] & 0x3F;//00111111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[2] & 0x3F;//00111111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[3] & 0x3F;//00111111
	}
	else if(bSrc>=248 && bSrc<252)//5字节
	{
		dwUnicode = cSrc[0] & 0x03; //00000011
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[1] & 0x3F;//00111111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[2] & 0x3F;//00111111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[3] & 0x3F;//00111111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[4] & 0x3F;//00111111
	}
	else if(bSrc>=252 && bSrc<254)//6字节
	{
		dwUnicode = cSrc[0] & 0x01; //00000001
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[1] & 0x3F;//00111111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[2] & 0x3F;//00111111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[3] & 0x3F;//00111111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[4] & 0x3F;//00111111
		dwUnicode = dwUnicode<<6;
		dwUnicode |= cSrc[5] & 0x3F;//00111111
	}
	else
	{
		//原则上不可能出现此情况，但为了兼容性考虑还是加上此代码
		dwUnicode += bSrc;
	}
	nUnicode = dwUnicode;
	return nUnicode;
}

void CCharCompare::InitPinYin(LPBYTE lpBuffer, int nSize)
{
	int i, m, nCount;
	PINYINDATA * lpPingYinData;
	int arPinyinInitialPos[28];
	short nTableSize, nTop, nBottom, nMid, nValue;
	char arPinyinTable[][7] = {
		"a", "ai", "an", "ang", "ao",																	//A开头的读音有5个
		"ba", "bai", "ban", "bang", "bao", "bei", "ben", "beng", "bi", "bian", "biao", "bie", "bin", "bing", "bo", "bu", //B开头的读音有16个
		"ca", "cai", "can", "cang", "cao", "ce", "cen", "ceng", "cha", "chai", "chan", "chang", "chao", "che", "chen", "cheng", "chi", "chong", "chou", "chu", "chua", "chuai", "chuan", "chuang", "chui", "chun", "chuo", "ci", "cong", "cou", "cu", "cuan", "cui", "cun", "cuo", //C开头的读音有35个
		"da", "dai", "dan", "dang", "dao", "de", "den", "deng", "di", "dia", "dian", "diao", "die", "ding", "diu", "dong", "dou", "du", "duan", "dui", "dun", "duo",																							//D开头的读音有22个
		"e", "ei", "en", "eng", "er",																	//E开头的读音有5个
		"fa", "fan", "fang", "fei", "fen", "feng", "fo", "fou","fu",									//F开头的读音有9个
		"ga", "gai", "gan", "gang", "gao", "ge", "gei", "gen", "geng", "gong", "gou", "gu", "gua", "guai", "guan", "guang", "gui", "gun", "guo",//G开头的读音有19个
		"ha", "hai", "han", "hang", "hao", "he", "hei", "hen", "heng", "hong", "hou", "hu", "hua", "huai", "huan", "huang","hui", "hun", "huo",//G开头的读音有19个
		"ji", "jia", "jian", "jiang", "jiao", "jie", "jin", "jing", "jiong", "jiu", "ju", "juan", "jue", "jun", //J开头的读音有14个
		"ka", "kai", "kan",	"kang", "kao", "ke", "ken", "keng", "kong", "kou", "ku", "kua", "kuai",	"kuan", "kuang", "kui", "kun", "kuo", //K开头的读音有18个
		"la", "lai", "lan", "lang", "lao", "le", "lei", "leng", "li", "lia", "lian", "liang", "liao", "lie", "lin",	"ling", "liu", "lo", "long", "lou", "lu", "luan", "lun", "luo", "lv", "lve",  //L开头的读音有26个
		"ma", "mai", "man", "mang", "mao", "me", "mei", "men", "meng", "mi", "mian", "miao", "mie", "min", "ming", "miu", "mo", "mou", "mu", //M开头的读音有19个
		"na", "nai", "nan", "nang", "nao", "ne", "nei", "nen", "neng", "ni", "nian", "niang", "niao", "nie", "nin", "ning", "niu", "nong", "nou", "nu", "nuan", "nun", "nuo", "nv", "nve", //N开头的读音有25个
		"o", "ou",																						 //O开头的读音有2个
		"pa", "pai", "pan", "pang", "pao", "pei", "pen", "peng", "pi", "pian", "piao", "pie", "pin", "ping", "po", "pou", "pu", //P开头的读音有17个
		"qi", "qia", "qian", "qiang", "qiao", "qie", "qin", "qing", "qiong", "qiu", "qu", "quan", "que", "qun",  //Q开头的读音有14个
		"ran", "rang", "rao", "re", "ren", "reng", "ri",  "rong", "rou", "ru", "ruan", "rui", "run", "ruo", //R开头的读音有14个
		"sa", "sai", "san",	"sang", "sao", "se", "sen", "seng", "sha", "shai", "shan", "shang", "shao", "she", "shen", "sheng", "shi", "shou", "shu", "shua", "shuai", "shuan", "shuang", "shui", "shun", "shuo", "si", "song", "sou", "su", "suan", "sui", "sun", "suo", //S开头的读音有34个
		"ta", "tai", "tan", "tang", "tao", "te", "teng", "ti", "tian", "tiao", "tie", "ting", "tong", "tou", "tu", "tuan", "tui", "tun", "tuo", //T开头的读音有19个
		"wa", "wai", "wan", "wang", "wei", "wen", "weng", "wo", "wu", //W开头的读音有9个
		"xi","xia", "xian", "xiang", "xiao", "xie", "xin", "xing", "xiong", "xiu", "xu", "xuan", "xue", "xun", //W开头的读音有14个
		"ya", "yan", "yang","yao","ye", "yi", "yin", "ying", "yo", "yong", "you", "yu", "yuan", "yue", "yun", //Y开头的读音有15个
		"za", "zai", "zan",	"zang", "zao", "ze", "zei", "zen", "zeng", "zha", "zhai", "zhan", "zhang","zhao", "zhe", "zhei", "zhen", "zheng", "zhi", "zhong", "zhou", "zhu", "zhua", "zhuai", "zhuan", "zhuang", "zhui", "zhun", "zhuo", "zi", "zong", "zou", "zu", "zuan", "zui", "zun", "zuo", //37开头的读音有15个
		""
	};

	memset(arPinyinInitialPos, 0, sizeof(arPinyinInitialPos));
	nTableSize = sizeof(arPinyinTable)/7;
	for(i = 0;i < nTableSize;i++)
	{
		m = arPinyinTable[i][0] - 'a';
		if(arPinyinInitialPos[m] == 0)
		{
			arPinyinInitialPos[m] = i + 1;
		}
	}

	arPinyinInitialPos[26] = nTableSize;
	for(i = 26;i >= 0;i--)
	{
		if(arPinyinInitialPos[i] == 0)
		{
			arPinyinInitialPos[i] = m;
		}
		else
		{
			arPinyinInitialPos[i]--;
			m = arPinyinInitialPos[i];
		}
	}

	nCount = nSize/8;
	lpPingYinData = (PINYINDATA*)lpBuffer;

	for(i = 0; i < nCount; i++)
	{
		if(lpPingYinData[i].m_cUniNum > 0X9FAF)
		{
			continue;
		}

		//采用折半查找
		m		 = lpPingYinData[i].m_lpPingyin[0] - 'a';
		nTop	 = arPinyinInitialPos[m];
		nBottom	 = arPinyinInitialPos[m + 1];


		//先检查一下第一个是否就匹配
		for(m = 0;m < 6;m++)
		{
			nValue = arPinyinTable[nTop][m] - lpPingYinData[i].m_lpPingyin[m];
			if(nValue != 0)
			{
				break;
			}
		}

		if(nValue == 0)
		{
			m_pCharacterPinYinSortTable[lpPingYinData[i].m_cUniNum - 0x4E00] = nTop + 1;
		}
		else
		{
			while(TRUE)
			{
				nMid	 = (nTop + nBottom)/2;
				nValue	 = 0;

				for(m = 0;m < 6;m++)
				{
					nValue = arPinyinTable[nMid][m] - lpPingYinData[i].m_lpPingyin[m];
					if(nValue != 0)
					{
						break;
					}
				}

				if(nValue == 0)
				{
					//找到
					m_pCharacterPinYinSortTable[lpPingYinData[i].m_cUniNum - 0x4E00] = nMid + 1;
					break;
				}
				else if(nValue > 0)
				{
					//已经相等了，理论上是找不到数据导致，就可以结束循环了
					if(nBottom == nMid)
					{
						break;
					}
					else
					{
						nBottom = nMid;
					}
				}
				else
				{
					//已经相等了，理论上是找不到数据导致，就可以结束循环了
					if(nTop == nMid)
					{
						break;
					}
					else
					{
						nTop = nMid;
					}
				}
			}
		}
	}
}

//传入的参数为字符的字节长度
int CCharCompare::Compare(const char * pSrc, int nSrcLen, const char * pDes, int nDesLen, int nCaseSensitive, BOOL bMatch)
{
	if(bMatch)
	{
		return CompareMatch(pSrc, nSrcLen, pDes, nDesLen, nCaseSensitive);
	}
	else
	{
		return CompareChar(pSrc, nSrcLen, pDes, nDesLen, nCaseSensitive);
	}
}

//构建KMP算法NEXT表
//对通配符'%'，'_'作特殊处理
int CCharCompare::BuildNext(const char* pPat, SHORT *pNext, int nPatLen, int nCaseSensitive)
{
	if (nPatLen == 0)
	{
		return 0;
	}
	else if (nPatLen < 0)
	{
		return -1;
	}
	int i, k;
	pNext[0] = -1;
	i = 0;
	k = -1;
	while (i < nPatLen-1)
	{
		if (pPat[i] == MF_OPERATOR_PERCENT)		//'%'，对Next表作分段处理
		{
			pNext[i] = -1;
			return BuildNext(pPat+i+1, pNext+i+1, nPatLen-i-1, nCaseSensitive);
		}
		else if (k < 0 || pPat[i] == pPat[k] || pPat[i] == MF_OPERATOR_UNDERLINE || pPat[k] == MF_OPERATOR_UNDERLINE)	//'_'，可以匹配任意单个字符
		{
			i++;
			k++;
			pNext[i] = k;
		}
		else
		{
			if (nCaseSensitive)
			{
				//大小写敏感
				k = pNext[k];
			} 
			else
			{
				//大小写不敏感
				char cPi, cPk;
				cPi = pPat[i];
				cPk = pPat[k];
				if(cPi >= 'A' && cPi <= 'Z')
					cPi += 32;
				if(cPk >= 'A' && cPk <= 'Z')
					cPk += 32;
				if(cPi == cPk)
				{
					i++;
					k++;
					pNext[i] = k;
				}
				else
				{
					k = pNext[k];
				}
			}
		}
	}
	return 0;
}

int CCharCompare::Match(const char *pSrc, int nSrcLen, const char *pPat, SHORT *pNext, int *pCount, int nPatLen, int nCaseSensitive, BOOL bPercent, BOOL bUnderLine)
{
	if (nPatLen == 0)
	{
		return 0;
	}
	else if (nPatLen < 0)
	{
		return -1;
	}
	int i, j, nPos;
	i = 0;
	j = 0;
	nPos = -1;
	while (TRUE)
	{
		if (i<nSrcLen && j<nPatLen)
		{
			if (j < 0)
			{
				i++;
				j++;
			}
			else if (pPat[j] == MF_OPERATOR_PERCENT)
			{
				nPos = Match(pSrc+i, nSrcLen-i, pPat+j+1, pNext+j+1, pCount+j+1, nPatLen-j-1, nCaseSensitive, TRUE, bUnderLine);
				if (nPos < 0)
				{
					//匹配失败，返回-1
					return -1;
				} 
				else
				{
					if (bPercent)
					{
						nPos = i - j;
						if (bUnderLine)
						{
							for (int k = 0; k < j; k++)
							{
								nPos -= pCount[k];
							}
						}
						return max(0, nPos);
					} 
					else
					{
						return nPos+i;
					}			
				}
			}
			else if (pPat[j] == MF_OPERATOR_UNDERLINE)
			{
				pCount[j] = 0;
				//处理UTF8编码字符
				if((BYTE)pSrc[i]<128)
				{
					//ascii码范围（0~127）
					//0000 – 007F 0xxxxxxx
					i++;
				}
				else
				{
					//单个字符占用多个字节
					//所以当是通配符'_'时要跳过当前文字或字符
					//0080 – 07FF 110xxxxx 10xxxxxx
					//0800 – FFFF 1110xxxx 10xxxxxx 10xxxxxx
					i++;	//非ascii码，首个字节，应该在0xC0~0xFF之间（192~255）
					while((BYTE)pSrc[i]>127 && (BYTE)pSrc[i]<192)
					{
						//0b10xxxxxx范围（128~191）
						//后面几个字节均以0b10开头
						pCount[j]++;
						i++;
					}
				}
				j++;
			}
			else if (pSrc[i] == pPat[j])
			{
				i++;
				j++;
			}
			else	//单个字节匹配失败
			{
				if (nCaseSensitive)
				{
					//大小写敏感
					if (bPercent)
					{
						j = pNext[j];
					} 
					else
					{
						//不是通配符'%'，需完全匹配
						return -1;
					}
				}
				else
				{
					//大小写不敏感
					char cSi, cPj;
					cSi = pSrc[i];
					cPj = pPat[j];
					if(cSi >= 'A' && cSi <= 'Z')
						cSi += 32;
					if(cPj >= 'A' && cPj <= 'Z')
						cPj += 32;

					if(cSi == cPj)
					{
						i++;  
						j++;
					}
					else
					{
						if (bPercent)
						{
							j = pNext[j];
						} 
						else
						{
							//不是通配符'%'，需完全匹配
							return -1;
						}
					}
				}
			}
		} 
		else
		{
			//判断跳出条件
			if (i != nSrcLen && j == nPatLen && bPercent)
			{
				//匹配串末尾不为通配符'%'
				//匹配到的字符串不在文本末尾
				//放弃本次匹配结果，继续进行匹配
				i--;
				j--;
				j = pNext[j];
			} 
			else
			{
				break;
			}
		}
		
	}

	if (i == nSrcLen && (j == nPatLen || ( j == nPatLen-1 && pPat[nPatLen-1] == MF_OPERATOR_PERCENT)))	//完全匹配
	{
		nPos = i - j;
		if (bUnderLine)
		{
			for (int k = 0; k < nPatLen; k++)
			{
				nPos -= pCount[k];
			}
		}
		return max(0, nPos);
	} 
	else
	{
		return -1;
	}
}

//字符串匹配
//	pSrc			文本串
//	nSrcLen			文本串长度
//	pPat			匹配串
//	nPatLen			匹配串长度
//	nCaseSensitive	0，大小写不敏感；1，大小写敏感
//
//返回值
//	匹配串首位为'%'		返回匹配串第二位在文本中匹配到的位置
//	匹配串首位不为'%'	返回0（匹配串在文本中的位置为0）
//	匹配失败			返回-1
int CCharCompare::Find(const char *pSrc, int nSrcLen, const char *pPat, int nPatLen, int nCaseSensitive)
{
	int nRet = -1;
	BOOL bUnderLine = FALSE;

	if(pSrc == NULL)
	{
		return nRet;
	}

	if(pSrc[nSrcLen - 1] == 0)
	{
		nSrcLen--;
	}
	if(pPat[nPatLen - 1] == 0)
	{
		nPatLen--;
	}

	if(m_nKMPNextSize < nPatLen)
	{
		if(m_pKMPNextTable != NULL)
		{
			delete [] m_pKMPNextTable;
			m_pKMPNextTable = NULL;
		}
		m_nKMPNextSize  = nPatLen;
		m_pKMPNextTable = new SHORT[m_nKMPNextSize];
		memset(m_pKMPNextTable, 0, m_nKMPNextSize * sizeof(SHORT));

		if (m_pCharacterCount != NULL)
		{
			delete[] m_pCharacterCount;
			m_pCharacterCount = NULL;
		}
		m_pCharacterCount = new int[m_nKMPNextSize];
	}

	nRet = BuildNext(pPat, m_pKMPNextTable, nPatLen, nCaseSensitive);
	if (nRet != MF_OK)
	{
		return -1;
	}

	//记录匹配串中每个字节匹配到的额外字节数
	//'_'匹配到的字符可能包含超过一个字节
	//ascii码，'%'等均为0
	for (int i = 0; i < m_nKMPNextSize; i++)
	{
		if (pPat[i] == MF_OPERATOR_UNDERLINE)
		{
			memset(m_pCharacterCount, 0, m_nKMPNextSize*sizeof(int));
			bUnderLine = TRUE;
			break;
		}
	}

	//匹配查找
	return Match(pSrc, nSrcLen, pPat, m_pKMPNextTable, m_pCharacterCount, nPatLen, nCaseSensitive, FALSE, bUnderLine);
} 

inline int SubStringMatch(const char *pSrc, int nSrcLen, const char *pPat, int nPatLen, int nCount, int nCaseSensitive)
{
	BYTE bData;
	char cSrc, cDes;
	int i, j, n, nPos;
	LPSTR lpSrc, lpDes;
	LPDWORD lpDSrc, lpDDes;

	lpDSrc  = (LPDWORD)pSrc;
	lpDDes  = (LPDWORD)pPat;
	//先做大片数据比较，这样比较的性能会比较高
	for(i = 0;i < nCount;i++)
	{
		if(lpDSrc[i] == lpDDes[i])
		{
			continue;
		}
		else
		{
			lpSrc = (LPSTR)(&lpDSrc[i]);
			lpDes = (LPSTR)(&lpDDes[i]);
			for(j = 0;j < 4;j++)
			{
				if(lpSrc[j] == lpDes[j])
				{
					continue;
				}
				else
				{
					cDes = lpDes[j];
					if(cDes == MF_OPERATOR_UNDERLINE)
					{
						//下划线直接跳过这个比较
						//首先判断如果是英文字母，则跳过一个字符后继续
						cSrc = lpSrc[j];
						if(cSrc > 0 && cSrc < 128)
						{
							continue;
						}
						else
						{
							bData = cSrc & 0XC0;
							if(bData == 0XC0)
							{
								//标准UTF8字符开始
								n = i * 4 + j + 1;
								bData = pSrc[n] & 0XC0;
								while(bData == 0X80)
								{
									n++;
									bData = pSrc[n] & 0XC0;
								}

								nPos = i * 4 + j + 1;
								if(nPatLen - nPos == 1)
								{
									if(pSrc[n] == 0)
									{
										return 0;
									}
									else
									{
										return -1;
									}
								}
								else
								{
									if(pSrc[n] != 0)
									{
										//需要继续看后面是否匹配
										nPos = i * 4 + j + 1;
										return SubStringFind(pSrc + n, nSrcLen - n, pPat + nPos, nPatLen - nPos, nCaseSensitive);
									}
									else
									{
										n = i * 4 + j;
										//判断后面是否全部是百分号
										while(pPat[n + 1] == MF_OPERATOR_PERCENT)
										{
											n++;
										}
										if(nPatLen - n == 1)
										{
											return 0;
										}
										else
										{
											return -1;
										}
									}
								}
							}
							else
							{
								continue;
							}
						}
						continue;
					}
					else if(cDes == MF_OPERATOR_PERCENT)
					{
						//重新开始比较
						nPos = i * 4 + j;
						if(nPatLen - nPos > 1)
						{
							return SubStringFind(pSrc + nPos, nSrcLen - nPos, pPat + nPos, nPatLen - nPos, nCaseSensitive);
						}
						else
						{
							return 0;
						}
					}
					else
					{
						if(nCaseSensitive == 1)
						{
							return -1;
						}

						cSrc = lpSrc[j];
						if(cSrc>='A' && cSrc<='Z')
							cSrc += 32;
						if(cDes>='A' && cDes<='Z')
							cDes += 32;
						//忽略大小写敏感时是匹配的
						if(cSrc == cDes)
						{
							continue;
						}
						else
						{
							return -1;
						}
					}
				}
			}
		}
	}
	//比较剩下的几个字符的位置
	for(i = nCount << 2; i < nPatLen; i++)
	{
		if(pSrc[i] == pPat[i])
		{
			continue;
		}
		else
		{
			cDes = pPat[i];
			if(cDes == MF_OPERATOR_UNDERLINE)
			{
				//下划线直接跳过这个比较
				//首先判断如果是英文字母，则跳过一个字符后继续
				cSrc = pSrc[i];
				if(cSrc > 0 && cSrc < 128)
				{
					continue;
				}
				else
				{
					bData = cSrc & 0XC0;
					if(bData == 0XC0)
					{
						//标准UTF8字符开始
						n = i + 1;
						bData = pSrc[n] & 0XC0;
						while(bData == 0X80)
						{
							n++;
							bData = pSrc[n] & 0XC0;
						}
						if(nPatLen - i == 1)
						{
							if(pSrc[n] == 0)
							{
								return 0;
							}
							else
							{
								return -1;
							}
						}
						else
						{
							if(pSrc[n] != 0)
							{
								nPos = i + 1;
								return SubStringFind(pSrc + n, nSrcLen - n, pPat + nPos, nPatLen - nPos, nCaseSensitive);
							}
							else
							{
								//判断后面是否全部是百分号
								while(pPat[i + 1] == MF_OPERATOR_PERCENT)
								{
									i++;
								}
								if(nPatLen - i == 1)
								{
									return 0;
								}
								else
								{
									return -1;
								}
							}
						}
						if(pSrc[n] != 0)
						{
							//需要继续看后面是否匹配
						}
						else if(nPatLen - i == 1 && pSrc[n] == 0)
						{
							return 0;
						}
						else
						{
							return -1;
						}
					}
					else
					{
						continue;
					}
				}
			}
			else if(cDes == MF_OPERATOR_PERCENT)
			{
				//重新开始比较
				if(nPatLen - i > 1)
				{
					return SubStringFind(pSrc + i, nSrcLen - i, pPat + i, nPatLen - i, nCaseSensitive);
				}
				else
				{
					return 0;
				}
			}
			else
			{
				if(nCaseSensitive == 1)
				{
					return -1;
				}

				cSrc = pSrc[i];
				if(cSrc>='A' && cSrc<='Z')
					cSrc += 32;
				if(cDes>='A' && cDes<='Z')
					cDes += 32;
				//忽略大小写敏感时是匹配的
				if(cSrc == cDes)
				{
					continue;
				}
				else
				{
					return -1;
				}
			}
		}
	}
	//如果仍然相同，按照长度达到的为0，没达到的用实际值进行比较
	if(pSrc[i] == 0)
	{
		return 0;
	}
	return -1;
}


//字符串匹配
//	pSrc			文本串
//	nSrcLen			文本串长度
//	pPat			匹配串
//	nPatLen			匹配串长度
//	nCaseSensitive	0，大小写不敏感；1，大小写敏感
//
//返回值
//	匹配串首位为'%'		返回匹配串第二位在文本中匹配到的位置
//	匹配串首位不为'%'	返回0（匹配串在文本中的位置为0）
//	匹配失败			返回-1
int SubStringFind(const char *pSrc, int nSrcLen, const char *pPat, int nPatLen, int nCaseSensitive)
{
	BYTE bData;
	int nLen, n;
	char ch1, ch2;

	//如果源为空，就肯定不符合子串的标准
	if(pSrc == NULL)
	{
		return -1;
	}

	if(pPat[0] == MF_OPERATOR_UNDERLINE)
	{
		if(pPat[1] == MF_OPERATOR_UNDERLINE || pPat[1] == MF_OPERATOR_PERCENT)
		{
			bData = pSrc[0] & 0XC0;
			if(bData == 0XC0)
			{
				//标准UTF8字符开始
				n = 1;
				bData = pSrc[n] & 0XC0;
				while(bData == 0X80)
				{
					n++;
					bData = pSrc[n] & 0XC0;
				}
				return SubStringFind(pSrc + n, nSrcLen - n, pPat + 1, nPatLen - 1, nCaseSensitive);
			}
			else
			{
				return SubStringFind(pSrc + 1, nSrcLen - 1, pPat + 1, nPatLen - 1, nCaseSensitive);
			}
		}
		else
		{
			bData = pSrc[0] & 0XC0;
			if(bData == 0XC0)
			{
				//标准UTF8字符开始
				n = 1;
				bData = pSrc[n] & 0XC0;
				while(bData == 0X80)
				{
					n++;
					bData = pSrc[n] & 0XC0;
				}
				if(pSrc[n] != 0)
				{
					nLen = nPatLen - 1;
					nLen = nLen>>2;
					return SubStringMatch(&pSrc[n], nSrcLen - n, pPat + 1, nPatLen - 1, nLen, nCaseSensitive);
				}
				else if(nPatLen == 1 && pSrc[n] == 0)
				{
					return 0;
				}
				else
				{
					return -1;
				}
			}
			else
			{
				nLen = nPatLen - 1;
				nLen = nLen>>2;
				return SubStringMatch(&pSrc[1], nSrcLen - 1, pPat + 1, nPatLen - 1, nLen, nCaseSensitive);
			}
		}
	}
	else if(pPat[0] == MF_OPERATOR_PERCENT)
	{
		const char *pHead;
		int nRet, nMaxLen, nCount, nUnderLine, nStartNo, nPatStartNo;
		pHead = pPat + 1;
		if(*pHead == 0)
		{
			return 0;
		}
		ch1 = *pHead;
		nStartNo = 0;
		nPatStartNo = 1;
		if(ch1 == MF_OPERATOR_UNDERLINE || ch1 == MF_OPERATOR_PERCENT)
		{
			nUnderLine = 0;
			while(ch1 == MF_OPERATOR_UNDERLINE || ch1 == MF_OPERATOR_PERCENT)
			{
				if(ch1 == MF_OPERATOR_UNDERLINE)
				{
					nUnderLine++;
				}
				nPatStartNo++;
				pHead++;
				ch1 = *pHead;
			}
			bData = ch1 & 0XC0;
			nMaxLen = nSrcLen - nPatLen + 2 - nPatStartNo;
			if(nUnderLine != 0)
			{
				//计算必须忽略几个字符
				nStartNo = 0;
				for(n = 0;n < nUnderLine;n++)
				{
					bData = pSrc[nStartNo] & 0XC0;
					if(bData == 0XC0)
					{
						//标准UTF8字符开始
						nStartNo++;
						bData = pSrc[nStartNo] & 0XC0;
						while(bData == 0X80)
						{
							nStartNo++;
							bData = pSrc[nStartNo] & 0XC0;
						}
					}
					else
					{
						//ANSCII码字符
						nStartNo++;
					}
				}
			}
		}
		else
		{
			bData = ch1 & 0XC0;
			nMaxLen = nSrcLen - nPatLen + 2;
			if(nMaxLen <= 0)
			{
				return -1;
			}
		}
		for(n = nPatLen - 1;n > 0;n--)
		{
			if(pPat[n] == MF_OPERATOR_PERCENT)
			{
				nMaxLen++;
			}
			else
			{
				break;
			}
		}

		if(bData == 0XC0)
		{
			//UTF8中大于128的文字
			ch2= *(pHead + 1);
			nLen = nPatLen - 1 - nPatStartNo;
			nCount = nLen>>2;
			pHead = pPat + 2 + nPatStartNo;
			for(n = nStartNo;n < nMaxLen;n++)
			{
				if(pSrc[n] == ch1)
				{
					if(pSrc[n + 1] == ch2)
					{
						nRet = SubStringMatch(&pSrc[n + 2], nSrcLen - n - 2, pHead, nLen, nCount, nCaseSensitive);
						if(nRet == 0)
						{
							return 0;
						}
					}
				}
			}
		}
		else
		{
			nLen = nPatLen - 1 - nPatStartNo;
			nCount = nLen>>2;
			pHead = pPat + 1 + nPatStartNo;
			ch2 = 0;
			if(nCaseSensitive == 1)
			{
			}
			else if(ch1 >= 'A' && ch1 <= 'Z')
			{
				ch2 = ch1 + 32;
			}
			else if(ch1 >= 'a' && ch1 <= 'z')
			{
				ch2 = ch1 - 32;
			}
			if(ch2 == 0)
			{
				for(n = nStartNo;n < nMaxLen;n++)
				{
					if(pSrc[n] == ch1)
					{
						nRet = SubStringMatch(&pSrc[n + 1], nSrcLen - n - 1, pHead, nLen, nCount, nCaseSensitive);
						if(nRet == 0)
						{
							return 0;
						}
					}
				}
			}
			else
			{
				for(n = nStartNo;n < nMaxLen;n++)
				{
					if(pSrc[n] == ch1 || pSrc[n] == ch2)
					{
						nRet = SubStringMatch(&pSrc[n + 1], nSrcLen - n - 1, pHead, nLen, nCount, nCaseSensitive);
						if(nRet == 0)
						{
							return 0;
						}
					}
				}
			}
		}
	}
	else
	{
		if(pSrc[0] == pPat[0])
		{
			nLen = nPatLen;
			nLen = nLen>>2;
			return SubStringMatch(pSrc, nSrcLen, pPat, nPatLen, nLen, nCaseSensitive);
		}
		else if(nCaseSensitive == 1)
		{
			return -1;
		}
		else
		{
			ch1 = pSrc[0];
			ch2 = pPat[0];
			if(ch1 >= 'A' && ch1 <= 'Z')
				ch1 += 32;
			if(ch2 >= 'A' && ch2 <= 'Z')
				ch2 += 32;
			if(pSrc[0] == pPat[0])
			{
				nLen = nPatLen;
				nLen = nLen>>2;
				return SubStringMatch(pSrc, nSrcLen, pPat, nPatLen, nLen, nCaseSensitive);
			}
			else
			{
				return -1;
			}
		}
	}
	return -1;
} 

//传入的参数为字符的字节长度
int CCharCompare::CompareChar(const char * pSrc, int nSrcLen, const char * pDes, int nDesLen, int nCaseSensitive)
{
	char cSrc, cDes;
	LPSTR lpSrc, lpDes;
	LPDWORD lpDSrc, lpDDes;
	BYTE bSrcData, bDesData;
	int i, j, nMinLen, nCont, nPos, nSrcUniCode, nDesUniCode, nSortMask;

	nPos	= -1;
	lpDSrc  = (LPDWORD)pSrc;
	lpDDes  = (LPDWORD)pDes;
	while(nSrcLen > 0 && pSrc[nSrcLen - 1] == 0)
	{
		nSrcLen--;
	}

	while(nDesLen > 0 && pDes[nDesLen - 1] == 0)
	{
		nDesLen--;
	}

	if(nSrcLen <= 0 && nDesLen <= 0)
	{
		nDesLen = strlen(pDes);
		nMinLen = nDesLen;
	}
	else if(nSrcLen <= 0)
	{
		nMinLen = nDesLen;
	}
	else if(nDesLen <= 0)
	{
		nMinLen = nSrcLen;
	}
	else
	{
		nMinLen = min(nSrcLen, nDesLen);
	}
	nCont   = nMinLen>>2;

	if(nCaseSensitive == 0)
	{
		//先做大片数据比较，这样比较的性能会比较高
		for(i = 0;i < nCont;i++)
		{
			if(lpDSrc[i] == lpDDes[i])
			{
				continue;
			}
			else
			{
				lpSrc = (LPSTR)(&lpDSrc[i]);
				lpDes = (LPSTR)(&lpDDes[i]);
				for(j = 0;j < 4;j++)
				{
					if(lpSrc[j] == lpDes[j])
					{
						continue;
					}
					else
					{
						cSrc = lpSrc[j];
						cDes = lpDes[j];
						if(cSrc>='A' && cSrc<='Z')
							cSrc += 32;
						if(cDes>='A' && cDes<='Z')
							cDes += 32;
						//忽略大小写敏感时是匹配的
						if(cSrc == cDes)
						{
							continue;
						}
						else
						{
							nPos = i * 4 + j;
							break;
						}
					}
				}
				//找到不同点位置
				if(nPos >= 0)
				{
					break;
				}
			}
		}

		//比较剩下的几个字符的位置
		if(nPos == -1)
		{
			for(i = nCont << 2; i < nMinLen; i++)
			{
				if(pSrc[i] == pDes[i])
				{
					continue;
				}
				else
				{
					cSrc = pSrc[i];
					cDes = pDes[i];
					if(cSrc>='A' && cSrc<='Z')
						cSrc += 32;
					if(cDes>='A' && cDes<='Z')
						cDes += 32;
					//忽略大小写敏感时是匹配的
					if(cSrc == cDes)
					{
						continue;
					}
					else
					{
						nPos = i;
						break;
					}
				}
			}

			//如果仍然相同，按照长度达到的为0，没达到的用实际值进行比较
			if(nPos == -1)
			{
				//这里不存在两个都没有长度的情况，因为一开始就改变了这种局面
				if(nSrcLen <= 0)
				{
					cSrc = pSrc[i];
					cDes = 0;
				}
				else if(nDesLen <= 0)
				{
					cSrc = 0;
					cDes = pDes[i];
				}
				else
				{
					if(i >= nSrcLen)
					{
						cSrc = 0;
						cDes = pDes[i];
					}
					else
					{
						cSrc = pSrc[i];
						cDes = 0;
					}
				}
				return (BYTE)cDes - (BYTE)cSrc;
			}
		}

		//针对找到的不同位置进行具体处理
		if(nPos >= 0)
		{
			//查找UTF8编码的开始字符，由于采取决定位置进行比较，按照UTF8的编码规范，只需要回溯一个字符就可找到汉字的开始位置，我们也假设传入的开始位置一定是真正字符的开始位置
			bSrcData = pSrc[nPos];
			while(bSrcData>=128 && bSrcData < 192)//表明为0x10******开头，这时要向前位移找到这个字符的真正开头
			{ 
				nPos--; 
				if(nPos > 0)
				{
					bSrcData = pSrc[nPos];
				}
				else
				{
					break;
				}
			}

			//分别获取第一个字节
			bSrcData = pSrc[nPos];
			bDesData = pDes[nPos];
			//其中有一个字符是属于标准ANSI字符，这时直接用这两个数据相减返回即可
			if(bSrcData < 128 || bDesData < 128)
			{
				if(bSrcData>='A' && bSrcData<='Z')
					bSrcData += 32;
				if(bDesData>='A' && bDesData<='Z')
					bDesData += 32;
				return bSrcData - bDesData;
			}

			nSrcUniCode = GetUnicode(pSrc + nPos);
			nDesUniCode = GetUnicode(pDes + nPos);
			//只有源和目标都是汉字时才需要获取拼音，按照拼音比较先后顺序
			if(nSrcUniCode >= 0X4E00 && nSrcUniCode <= 0X9FA5 && nDesUniCode >= 0X4E00 && nDesUniCode <= 0X9FA5)
			{
				//拼音先后顺序优先，相同时按照内码排序
				nSortMask = m_pCharacterPinYinSortTable[nSrcUniCode - 0X4E00] - m_pCharacterPinYinSortTable[nDesUniCode - 0X4E00];
				if(nSortMask != 0)
				{
					return nSortMask;
				}

				//如果拼音相同时按照内码排列先后顺序
				return nSrcUniCode - nDesUniCode;
			}

			//直接按照内码排列先后顺序
			return nSrcUniCode - nDesUniCode;
		}
	}
	else
	{
		//先做大片数据比较，这样比较的性能会比较高
		for(i = 0;i < nCont;i++)
		{
			if(lpDSrc[i] == lpDDes[i])
			{
				continue;
			}
			else
			{
				lpSrc = (LPSTR)(&lpDSrc[i]);
				lpDes = (LPSTR)(&lpDDes[i]);
				for(j = 0;j < 4;j++)
				{
					if(lpSrc[j] == lpDes[j])
					{
						continue;
					}
					else
					{
						nPos = i * 4 + j;
						break;
					}
				}
				//找到不同点位置
				if(nPos >= 0)
				{
					break;
				}
			}
		}

		//比较剩下的几个字符的位置
		if(nPos == -1)
		{
			for(i = nCont << 2; i < nMinLen; i++)
			{
				if(pSrc[i] == pDes[i])
				{
					continue;
				}
				else
				{
					nPos = i;
					break;
				}
			}

			//如果仍然相同，按照长度达到的为0，没达到的用实际值进行比较
			if(nPos == -1)
			{
				//这里不存在两个都没有长度的情况，因为一开始就改变了这种局面
				if(nSrcLen <= 0)
				{
					cSrc = pSrc[i];
					cDes = 0;
				}
				else if(nDesLen <= 0)
				{
					cSrc = 0;
					cDes = pDes[i];
				}
				else
				{
					if(i >= nSrcLen)
					{
						cSrc = 0;
						cDes = pDes[i];
					}
					else
					{
						cSrc = pSrc[i];
						cDes = 0;
					}
				}
				return (BYTE)cDes - (BYTE)cSrc;
			}
		}

		//针对找到的不同位置进行具体处理
		if(nPos >= 0)
		{
			//查找UTF8编码的开始字符，由于采取决定位置进行比较，按照UTF8的编码规范，只需要回溯一个字符就可找到汉字的开始位置，我们也假设传入的开始位置一定是真正字符的开始位置
			bSrcData = pSrc[nPos];
			while(bSrcData>=128 && bSrcData < 192)//表明为0x10******开头，这时要向前位移找到这个字符的真正开头
			{ 
				nPos--; 
				if(nPos > 0)
				{
					bSrcData = pSrc[nPos];
				}
				else
				{
					break;
				}
			}

			//分别获取第一个字节
			bSrcData = pSrc[nPos];
			bDesData = pDes[nPos];

			//其中有一个字符是属于标准ANSI字符，这时直接用这两个数据相减返回即可
			if(bSrcData < 128 || bDesData < 128)
			{
				return bSrcData - bDesData;
			}

			nSrcUniCode = GetUnicode(pSrc + nPos);
			nDesUniCode = GetUnicode(pDes + nPos);
			//只有源和目标都是汉字时才需要获取拼音，按照拼音比较先后顺序
			if(nSrcUniCode >= 0X4E00 && nSrcUniCode <= 0X9FA5 && nDesUniCode >= 0X4E00 && nDesUniCode <= 0X9FA5)
			{
				//拼音先后顺序优先，相同时按照内码排序
				nSortMask = m_pCharacterPinYinSortTable[nSrcUniCode - 0X4E00] - m_pCharacterPinYinSortTable[nDesUniCode - 0X4E00];
				if(nSortMask != 0)
				{
					return nSortMask;
				}

				//如果拼音相同时按照内码排列先后顺序
				return nSrcUniCode - nDesUniCode;
			}

			//直接按照内码排列先后顺序
			return nSrcUniCode - nDesUniCode;
		}
	}
	return 0;
}

int CCharCompare::CompareMatch(const char * pSrcData, int nSrcLen, const char * pDes, int nDesLen, int nCaseSensitive)
{
	char cSrc, cDes;
	LPSTR lpSrc, lpDes, pSrc;
	LPDWORD lpDSrc, lpDDes;
	BYTE bSrcData, bDesData;
	int i, j, nMinLen, nCont, nPos, nSrcUniCode, nDesUniCode, nSortMask;

	nPos	= -1;
	pSrc	= (LPSTR)pSrcData;
	while(pSrc[0] == MF_OPERATOR_PERCENT || pSrc[0] == MF_OPERATOR_UNDERLINE)
	{
		pSrc++;
		nSrcLen--;
	}
	lpDSrc  = (LPDWORD)pSrc;
	lpDDes  = (LPDWORD)pDes;
	while(nSrcLen > 0 && (pSrc[nSrcLen - 1] == MF_OPERATOR_PERCENT || pSrc[nSrcLen - 1] == MF_OPERATOR_UNDERLINE || pSrc[nSrcLen - 1] == 0))
	{
		nSrcLen--;
	}

	if(pDes[nDesLen - 1] == 0)
	{
		nDesLen--;
	}

	if(nSrcLen <= 0 && nDesLen <= 0)
	{
		nDesLen = strlen(pDes);
		nMinLen = nDesLen;
	}
	else if(nSrcLen <= 0)
	{
		nMinLen = nDesLen;
	}
	else if(nDesLen <= 0)
	{
		nMinLen = nSrcLen;
	}
	else
	{
		nMinLen = min(nSrcLen, nDesLen);
	}
	nCont   = nMinLen>>2;

	if(nCaseSensitive == 0)
	{
		//先做大片数据比较，这样比较的性能会比较高
		for(i = 0;i < nCont;i++)
		{
			if(lpDSrc[i] == lpDDes[i])
			{
				continue;
			}
			else
			{
				lpSrc = (LPSTR)(&lpDSrc[i]);
				lpDes = (LPSTR)(&lpDDes[i]);
				for(j = 0;j < 4;j++)
				{
					if(lpSrc[j] == lpDes[j])
					{
						continue;
					}
					else
					{
						cSrc = lpSrc[j];
						cDes = lpDes[j];
						if(cSrc>='A' && cSrc<='Z')
							cSrc += 32;
						if(cDes>='A' && cDes<='Z')
							cDes += 32;
						//忽略大小写敏感时是匹配的
						if(cSrc == cDes)
						{
							continue;
						}
						else
						{
							nPos = i * 4 + j;
							break;
						}
					}
				}
				//找到不同点位置
				if(nPos >= 0)
				{
					break;
				}
			}
		}

		//比较剩下的几个字符的位置
		if(nPos == -1)
		{
			for(i = nCont << 2; i < nMinLen; i++)
			{
				if(pSrc[i] == pDes[i])
				{
					continue;
				}
				else
				{
					cSrc = pSrc[i];
					cDes = pDes[i];
					if(cSrc>='A' && cSrc<='Z')
						cSrc += 32;
					if(cDes>='A' && cDes<='Z')
						cDes += 32;
					//忽略大小写敏感时是匹配的
					if(cSrc == cDes)
					{
						continue;
					}
					else
					{
						nPos = i;
						break;
					}
				}
			}

			//如果仍然相同，按照长度达到的为0，没达到的用实际值进行比较
			if(nPos == -1)
			{
				if(nSrcLen <= nDesLen)
				{
					return 0;
				}
				else
				{
					return -1;
				}
			}
		}

		//针对找到的不同位置进行具体处理
		if(nPos >= 0)
		{
			//查找UTF8编码的开始字符，由于采取决定位置进行比较，按照UTF8的编码规范，只需要回溯一个字符就可找到汉字的开始位置，我们也假设传入的开始位置一定是真正字符的开始位置
			bSrcData = pSrc[nPos];
			while(bSrcData>=128 && bSrcData < 192)//表明为0x10******开头，这时要向前位移找到这个字符的真正开头
			{ 
				nPos--; 
				if(nPos > 0)
				{
					bSrcData = pSrc[nPos];
				}
				else
				{
					break;
				}
			}

			//分别获取第一个字节
			bSrcData = pSrc[nPos];
			bDesData = pDes[nPos];
			//其中有一个字符是属于标准ANSI字符，这时直接用这两个数据相减返回即可
			if(bSrcData < 128 || bDesData < 128)
			{
				if(bSrcData>='A' && bSrcData<='Z')
					bSrcData += 32;
				if(bDesData>='A' && bDesData<='Z')
					bDesData += 32;
				return bSrcData - bDesData;
			}

			nSrcUniCode = GetUnicode(pSrc + nPos);
			nDesUniCode = GetUnicode(pDes + nPos);
			//只有源和目标都是汉字时才需要获取拼音，按照拼音比较先后顺序
			if(nSrcUniCode >= 0X4E00 && nSrcUniCode <= 0X9FA5 && nDesUniCode >= 0X4E00 && nDesUniCode <= 0X9FA5)
			{
				//拼音先后顺序优先，相同时按照内码排序
				nSortMask = m_pCharacterPinYinSortTable[nSrcUniCode - 0X4E00] - m_pCharacterPinYinSortTable[nDesUniCode - 0X4E00];
				if(nSortMask != 0)
				{
					return nSortMask;
				}

				//如果拼音相同时按照内码排列先后顺序
				return nSrcUniCode - nDesUniCode;
			}

			//直接按照内码排列先后顺序
			return nSrcUniCode - nDesUniCode;
		}
	}
	else
	{
		//先做大片数据比较，这样比较的性能会比较高
		for(i = 0;i < nCont;i++)
		{
			if(lpDSrc[i] == lpDDes[i])
			{
				continue;
			}
			else
			{
				lpSrc = (LPSTR)(&lpDSrc[i]);
				lpDes = (LPSTR)(&lpDDes[i]);
				for(j = 0;j < 4;j++)
				{
					if(lpSrc[j] == lpDes[j])
					{
						continue;
					}
					else
					{
						nPos = i * 4 + j;
						break;
					}
				}
				//找到不同点位置
				if(nPos >= 0)
				{
					break;
				}
			}
		}

		//比较剩下的几个字符的位置
		if(nPos == -1)
		{
			for(i = nCont << 2; i < nMinLen; i++)
			{
				if(pSrc[i] == pDes[i])
				{
					continue;
				}
				else
				{
					nPos = i;
					break;
				}
			}

			//如果仍然相同，按照长度达到的为0，没达到的用实际值进行比较
			if(nPos == -1)
			{
				if(nSrcLen <= nDesLen)
				{
					return 0;
				}
				else
				{
					return -1;
				}
			}
		}

		//针对找到的不同位置进行具体处理
		if(nPos >= 0)
		{
			//查找UTF8编码的开始字符，由于采取决定位置进行比较，按照UTF8的编码规范，只需要回溯一个字符就可找到汉字的开始位置，我们也假设传入的开始位置一定是真正字符的开始位置
			bSrcData = pSrc[nPos];
			while(bSrcData>=128 && bSrcData < 192)//表明为0x10******开头，这时要向前位移找到这个字符的真正开头
			{ 
				nPos--; 
				if(nPos > 0)
				{
					bSrcData = pSrc[nPos];
				}
				else
				{
					break;
				}
			}

			//分别获取第一个字节
			bSrcData = pSrc[nPos];
			bDesData = pDes[nPos];

			//其中有一个字符是属于标准ANSI字符，这时直接用这两个数据相减返回即可
			if(bSrcData < 128 || bDesData < 128)
			{
				return bSrcData - bDesData;
			}

			nSrcUniCode = GetUnicode(pSrc + nPos);
			nDesUniCode = GetUnicode(pDes + nPos);
			//只有源和目标都是汉字时才需要获取拼音，按照拼音比较先后顺序
			if(nSrcUniCode >= 0X4E00 && nSrcUniCode <= 0X9FA5 && nDesUniCode >= 0X4E00 && nDesUniCode <= 0X9FA5)
			{
				//拼音先后顺序优先，相同时按照内码排序
				nSortMask = m_pCharacterPinYinSortTable[nSrcUniCode - 0X4E00] - m_pCharacterPinYinSortTable[nDesUniCode - 0X4E00];
				if(nSortMask != 0)
				{
					return nSortMask;
				}

				//如果拼音相同时按照内码排列先后顺序
				return nSrcUniCode - nDesUniCode;
			}

			//直接按照内码排列先后顺序
			return nSrcUniCode - nDesUniCode;
		}
	}
	return 0;
}