﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryHashChar.h"
#include "Check.h"
 CMemoryHashChar::CMemoryHashChar(void)
 {
 }
 
 CMemoryHashChar::~CMemoryHashChar(void)
 {
 }

 /************************************************************************
		功能说明：
			获取关键字值
		参数说明：
			lpNodeData：节点数据
			varKey：关键字值
************************************************************************/
void CMemoryHashChar::GetKeyValue(LPVOID lpNodeData, VARDATA& varKey)
{
	LPINDEXSTRUCT lpIndex;

	lpIndex = (LPINDEXSTRUCT)lpNodeData;
	varKey.SetData((char*)lpIndex->m_bKey, lpIndex->m_nKeyLen);
}

/************************************************************************
		功能说明：
			获取关键字值
		参数说明：
			lpNodeData：节点数据
************************************************************************/
long long CMemoryHashChar::GetDataIDFromNodeData(LPVOID lpNodeData)
{
	return ((LPINDEXSTRUCT)lpNodeData)->m_nDataID;
}
/************************************************************************
		功能说明：
			设置节点数据
		参数说明：
			lpNodeData：节点数据
			varKey：关键字值
			nDataID：数据ID
************************************************************************/
void CMemoryHashChar::SetNodeData(LPVOID lpNodeData, VARDATA& varKey, long long nDataID)
{
	LPINDEXSTRUCT lpIndex;

	lpIndex = (LPINDEXSTRUCT)lpNodeData;
	
	lpIndex->m_nKeyLen = varKey.m_nStrLen + 1;
	lpIndex->m_nDataID = nDataID;
	lpIndex->m_nNextOffset = 0;
	memcpy(lpIndex->m_bKey ,varKey.m_lpszValue, varKey.m_nStrLen + 1);
}

/************************************************************************
		功能说明：
			清空节点数据
		参数说明：
			lpNodeData：节点数据
************************************************************************/
void CMemoryHashChar::ClearNodeData(LPVOID lpNodeData)
{
	LPINDEXSTRUCT lpIndex;

	lpIndex = (LPINDEXSTRUCT)lpNodeData;

	memset(lpIndex->m_bKey, 0, lpIndex->m_nKeyLen);
	lpIndex->m_nKeyLen = 0;
	lpIndex->m_nDataID = 0;
	lpIndex->m_nNextOffset = 0;
}
/************************************************************************
		功能说明：
			计算Hash值
		参数说明：
			varKey：关键字值
			nHashSize：Hash表大小
************************************************************************/
DWORD CMemoryHashChar::CalcKeyHash(VARDATA& varKey, int nHashSize)
{
	char* lpKey;
	char * lpData;
	UINT  nHash, i;
	ULONGLONG ullDigitalHash;
	if(nHashSize == 0)
	{
		return 0;
	}
	lpKey			 = varKey.m_lpszValue;
	lpData			 = (char *)lpKey;
	ullDigitalHash	 = 0xd3202b73;
	for(i = 0; lpKey[i] != 0; i++)
	{
		if(lpData[i] >= '0' && lpData[i] <= '9')
		{
			ullDigitalHash = ullDigitalHash * 10 + lpData[i] - '0';
		}
		else if(lpData[i] >= 'A' && lpData[i] <= 'Z')
		{
			ullDigitalHash = ullDigitalHash * 37 + lpData[i] - 'A' + 10;
		}
		else if(lpData[i] >= 'a' && lpData[i] <= 'z')
		{
			ullDigitalHash = ullDigitalHash * 37 + lpData[i] - 'a' + 10;
		}
		else
		{
			ullDigitalHash = ullDigitalHash * 131 + lpKey[i];
		}
	}

	nHash			= (DWORD)(ullDigitalHash % nHashSize);
	return nHash;
}
/************************************************************************
		功能说明：
			判断关键字是否重复
		参数说明：
			pBosn：Bson对象
			varKey：关键字
			bFieldNo：字段编号
			lpHashNode：哈希结点
************************************************************************/
BOOL CMemoryHashChar::CheckKey(CServiceBson* pBson, VARDATA& varKey, BYTE bFieldNo, LPHASHNODE lpHashNode)
{
	int nRet;
	VARDATA varData;
	CMemoryFile* pFile;
	LPINDEXSTRUCT lpIndex;
	long long nIndexOffset;
	LPOBJECTDEF lpObjectInfo;
	CExpression stExpression;
	RECORDDATAINFO stRecordInfo;
	IVirtualMemoryFile* pVirtualFile;

	nIndexOffset = lpHashNode->m_nIndexOffset;
	//遍历冲突链表，判断关键字值是否重复
	while(nIndexOffset)
	{
		lpIndex = (LPINDEXSTRUCT)ConvertOffsettoAddr(nIndexOffset);
		if(strcmp((char*)lpIndex->m_bKey, varKey.m_lpszValue) == 0)
		{
			//校验索引值是否合法
			lpObjectInfo = pBson->GetObjectInfo();
			nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pFile = (CMemoryFile*)pVirtualFile;
			stExpression.Initial(pBson, lpObjectInfo);

			stRecordInfo.m_nDataID = lpIndex->m_nDataID;
			nRet = pFile->GetRecordFieldValue(pBson, &stExpression, &stRecordInfo, bFieldNo, varData);
			if(nRet != MF_OK)
			{
				return FALSE;
			}
			if(varKey == varData)
			{
				return TRUE;
			}
			else
			{
				return FALSE;
			}
		}
		nIndexOffset = lpIndex->m_nNextOffset;
	}
	return FALSE;
}

