﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "stdafx.h"
#include "SystemManage.h"
#include "CommonAPI.h"
class CBaseMemoryFile :public IVirtualMemoryFile
{
protected:
	LPBYTE			m_lpFileAddr;									//内存文件体指针
	MFID	  		m_nMemoryFileID;								//内存文件ID
	CSystemManage * m_pSystemManage;								//系统管理类指针

protected:
	/*int SafeMemmove()*/
public:
	CBaseMemoryFile(void);
	virtual ~CBaseMemoryFile(void);

	//函数名：打开实例，初始化对应数据
	//描  述：打开内存文件，并初始化实例资源
	//参  数：lpFileName，内存文件名，
	//返回值：执行结果
	virtual int Open(LPMEMDBFILEDEF lpMemDBFileDef);


	//函数名：关闭实例，清理释放内存
	//描  述：释放实例对应的资源，一般发生在服务关闭时
	//参  数：无
	//返回值：执行结果
	virtual int Close();

	//函数名：内存整理
	//描  述：对文件及文件中的对象进行内存整理，目的是释放空间提高系统性能
	//参  数：无
	//返回值：执行结果
	virtual int MergeMemory();

	//函数名：创建对象并初始化数据
	//描  述：创建对象时，调此函数分配初始的内存块并初始化数据
	//参  数：nID为对象ID，可能是索引也可能是对象；
	//        nBlockSize为定义的块大小；
	//        bType对象类型，详细定义见索引类型定义
	//        nDataNum为预估的数据量，对于KV索引可根据此初始化HASH块大小
	//返回值：执行结果
	virtual int CreateObject(int nID, int nBlockSize, MF_SYS_INDEXTYPE bType, int nDataNum);

	//函数名：获取文件空间信息
	//描  述：获取文件的总空间、已用空间和剩余空间
	//参  数：
	//返回值：
	virtual int GetFileSpace(LPEXECUTEPLANBSON lpExecutePlan, long long &nFileTotalSize, long long &nFileUseSize, long long &nFileFreeSize) = 0;

	//函数名：对象删除回收内存
	//描  述：删除对象时，调此函数释放对应内存块
	//参  数：nID为对象ID，可能是索引也可能是对象
	//返回值：执行结果
	virtual int DropObject(LPEXECUTEPLANBSON lpExecutePlan, int nID) = 0;

	
	//函数名：初始化内存文件管理类，让整个实例是可执行的
	//描  述：同时还需要把m_pMemoryFileHead成员变量也初始化出来，便于后续的写入和读取操作；同时需要根据文件头记录的FILEBLOCKMAP数据，初始化每一个Block类实例，同时完善m_mapMemoryBlock变量数据。
	//参  数：pFileAddr：内存文件数据块的首地址指针，需要记录在m_pFileAddr变量中
	//返回值：执行结果
	virtual int SetFileAddr(LPBYTE pFileAddr) = 0;

	/************************************************************************
		功能说明:
			获取文件头
	************************************************************************/
	virtual LPBASEFILEHEAD GetFileHead() = 0;

	/************************************************************************
		功能说明:
			修改文件时间戳
	************************************************************************/
	virtual void TimestampUpdate(LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp) = 0;

	/************************************************************************
		功能说明:
			备份文件数据
	************************************************************************/
	virtual int BackUpFileData(LPBYTE lpBuffer, int nBufferSize)  = 0;

	/************************************************************************
		功能说明：
			初始化块头基础信息
	************************************************************************/
	void InitialBlock(LPBYTE lpBlockAddr, int nBlockNo, int nBlockSize, BYTE bFileNo, long long nTimestamp)
	{
		LPBASEBLOCKHEAD lpBaseBlockHead;	
		memset(lpBlockAddr, 0, nBlockSize);
		lpBaseBlockHead					= (LPBASEBLOCKHEAD)lpBlockAddr;
		lpBaseBlockHead->m_nDataFlag	= MAKEHEADFLAG('S','B','D','B');
		lpBaseBlockHead->m_nBlockNo		= nBlockNo;
		lpBaseBlockHead->m_nTimestamp	= nTimestamp;
		lpBaseBlockHead->m_nBlockSize	= nBlockSize;	
		lpBaseBlockHead->m_bStatus		= MF_LOCK_STATUS_NULL;;
		lpBaseBlockHead->m_bFileNo		= bFileNo;
		lpBaseBlockHead->m_bSaveFlag	= 0;
		lpBaseBlockHead->m_bThreadNum	= 0;
		lpBaseBlockHead->m_nBlockHeadSize = sizeof(BASEBLOCKHEAD);

		//Trace(_T("InitialBlock"), 0, 100003011, _T("线程：%d，申请块：%d"), GetCurrentThreadId(), pBaseBlockHead->m_nBlockNo);
	}
};
