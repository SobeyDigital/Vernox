﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#define DEF_MEMORY_SIZE (1024*1024)
class CMemoryPageManager
{
private:
	#pragma pack(1)
	//分页时用于存放DataID的页Buffer
	typedef struct
	{
		int		m_nDataFlag;										//Buffer头，用于校验，暂定为'SBBH'
		long long m_nBufferNo;										//Buffer编号
		int		m_nBufferSize;										//页面Buffer的总大小
		int     m_nPageDataNum;										//单一页面大小(包括页面头)
		int     m_nPageNum;											//页面数量
		int     m_nDataIDNum;										//一页中最多能容纳数据ID的数量
		int     m_arrPgeMap[1];										//页面映射表
	}PAGEBUFFERHEAD,*LPPAGEBUFFERHEAD;

	typedef struct
	{
		int		m_nDataFlag;										//页面头，用于校验，暂定为'SBPH'
		int     m_nPageNo;											//页面编号
		int		m_nDataIDNum;										//当前页中包含的数据ID数量
		long long m_arrDataID[1];									//数据ID的起始位置
	}PAGEHEAD, *LPPAGEHEAD;
	#pragma pack()
private:
	char*						m_pBuffer;							//页面缓存
	int					        m_nBufferSize;						//页面大小	
	int							m_nFreeMemPos;						//空闲空间位置
	map<long long, char*>		m_mapBufferMap;						//缓存映射表
private:
	/************************************************************************
		功能说明：
			分配空间
	************************************************************************/
	int Alloc(long long nBufferNo, int nTotalDataNum, int nPageDataNum, char* &pBuffer);

public:
	CMemoryPageManager(void);
	~CMemoryPageManager(void);

public:
	/************************************************************************
		功能说明：
			初始化Buffer
	************************************************************************/
	int InitialBuffer(int nBufferSize = DEF_MEMORY_SIZE);

	/************************************************************************
		功能说明：
			分页
	************************************************************************/
	int Paging(long long nBufferNo, CDataIDContainer* pDataIDContainer, int nPageDataNum);

	/************************************************************************
		功能说明：
			获取页面
	************************************************************************/
	int GetPage(long long nBufferNo, int nPageNo, int nPageDataNum, CDataIDContainer* pDataIDContainer);
};
