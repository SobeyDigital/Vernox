﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "IndexSelector.h"
/************************************************************************
	索引类说明
	作用：作为基类使用，提供不同类型索引的公共方法

	数据结构说明：
	1.索引项：用于完成关键字向数据ID的映射。
	2.关键字/块映射表项:用于完成关键字向索引块的映射
	3.块：这里所说的块实际是一个物理内存块。每个块的大小相等，这个块会用来存放两类数据
	  (1)索引项：相同类别的索引项在内存中会按照关键字大小顺序存放，
		 但由于索引类中包含的索引项数量很多，对于索引项的排序会非常困难，
		 所以将索引项分配在块中，让索引项在块中有序，并且保持块与块之间有序
		 
	  (2)关键字/块映射表项(用于管理索引块)：由于同类索引项，被分配在了多个块中，所以对索引项的所有操作，
		 首先都需要找到该索引项所属的索引块号。为了实现这个功能，就需要一个关键字到块的映射表。
		 存放各个块中关键字的最大值，然后通过折半查找就可以找到该关键字所属的索引块

		 以上两种数据结构都会用一个物理块存放，所以在物理块的开始位置需要存放一个标志，表示该块内的数据结构

	 不论是对于索引块，还是关键字/块映射表都需要进行插入操作，插入的原则相同，按照关键字的顺序存放，
	 并且如果块写满之后，重新分配一个新的块，然后将块中50%的数据从一个快移动到另外一个块

	索引结构说明:
		 索引才用树形结构，由树干结点(存放TRUNKSTRUCT结构体)和叶子结点(存放LEAVESTRUCT结构体)组成，类中存放一个指向根结点的指针

	索引类的主要功能如下：
	1.完成关键字到结点的映射 
	2.在索引类中需要一个指向文件类的指针，因为在某些情况下，需要调用文件类的一些函数来完成某些操作
	3.形成树形结构
	4.插入索引项
	5.删除索引项
	6.索引项移动(私有)
************************************************************************/

#include "MemoryBTreeFile.h"
#define NODETYPE		BYTE
#define NEWNODE		    0						//新建结点
#define LEAVENODE		1						//大树干结点
#define TRUNKNODE		2						//树干结点
#define BIGTRUNKNODE    3						//叶子结点

#define OPERATOR_SEARCH 1
#define OPERATOR_INSERT 2
#define OPERATOR_DELETE 3

#define FIRST_EQUAL				1
#define FIRST_NOTEQUAL			2
#define FIRST_AND_LAST_EQUAL	3

#define MERGE_THRESHOLD			0.4
class CMemoryBTreeIndex
{
protected:
/************************************************************************
	结点头，内存块中中会存放两种数据结构。
	1.索引结点(叶子结点)
	2.关键字/块映射结点(树干结点)
************************************************************************/
	#pragma pack(1)
	//整型结点头
	typedef struct 
	{
		int					m_nDataFlag;				//数据标志，目前数据块为‘SBDB’
		int                 m_nBlockNo;                 //块号(新插入块的编号 = 最大块号+1)
		long long           m_nTimestamp;               //时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
		int                 m_nBlockSize;               //块大小
		int                 m_nBlockHeadSize;           //块头大小
		BYTE                m_bStatus;                  //数据锁定状态，一般修改单条数据不需要整块锁，但如果整块进行整理时就必须进行锁定，防止其他读取或者修改操作出现错乱
		BYTE                m_bFileNo;                  //文件编号
		BYTE				m_bSaveFlag;				//数据库保存标志，防止单纯按照时间戳判断出现误判
		BYTE                m_bThreadNum;	            //保留数据

		NODETYPE			m_bNodeType;				//结点类型(叶子结点或者树干结点，结点类型决定该结构体的类型)
		BYTE				m_bReserved[3];				//保留字段
		int					m_nDataSize;				//索引项大小
		int					m_nTotalDataNum;			//可以容纳索引项的总条数
		int					m_nDataNum;					//现有索引项条数(剩余空间 = m_nTotalDataNum - m_nDataNum,为0表示块满，需要插入新块)
		int					m_nNextNodeNo;				//下一个结点的编号
		int					m_nPreNodeNo;				//前一个结点的编号
	}TREENODEHEAD,*LPTREENODEHEAD;

	typedef struct
	{
		LPBYTE				m_lpBigTrunkNode;
		LPBYTE				m_lpTrunkNode;
		LPBYTE				m_lpLeaveNode;

		LPVOID				m_lpBigTrunkElement;
		LPVOID				m_lpTrunkElement;
		LPVOID				m_lpLeaveStartElement;
		LPVOID				m_lpLeaveEndElement;
	}TREENODEINFO,*LPTREENODEINFO;

	//结点插入信息
	typedef struct st_NODEINSERTINFO
	{
		LPBYTE				m_lpParentNode;				//父亲结点
		LPBYTE				m_lpNode;					//原始结点
		LPBYTE				m_lpNewNode;				//分裂后的新结点
		LPBYTE				m_lpInsertAddr;				//插入位置指针
		
		int					m_nMoveLen;					//插入时需要移动的数据长度
		st_NODEINSERTINFO()
		{
			m_lpParentNode  = NULL; 
			m_lpNode		= NULL;
			m_lpNewNode		= NULL;
			m_lpInsertAddr	= NULL;
			m_nMoveLen		= 0;
		}
	}NODEINSERTINFO, *LPNODEINSERTINFO;

	//二分法信息结构体
	typedef struct
	{
		LPBYTE				 m_lpNodeLow;				 //进行二分法的结点
		LPBYTE				 m_lpNodeHigh;				 //进行二分法的结点
		BYTE				 m_bOperatorType;			 //操作类型
		BOOL				 m_bFirst;					 //当树中有多个关键字与待查询关键字相同时，
													     //如果bFirst为真则获取第一个相同关键字的
														 //位置否则获取最后一个相同关键字的位置
		long long			 m_nDatID;					 //找到关键字的DataID
		BOOL				 m_bOverBlock;				 //是否跨块
		long long			 m_nSearchScope;			 //查找范围
		int					 m_nLow;					 //折半下限 
		int					 m_nHigh;					 //折半上限 
		int				     m_nLevel;					 //递归层数(兼容复合索引)
		int					 m_nDataPosLow;				 //节点位置下限
		int					 m_nDataPosHigh;			 //结点位置上限
	}BINARYSEARCHINFO, *LPBINARYSEARCHINFO;
	#pragma pack()
protected:
	LPBYTE					 m_lpRootBlock;				  //根结点
	int 					 m_nIndexID;				  //根结点对应的IndexID
	CMemoryBTreeFile*		 m_pIndexFile;				  //在内存索引文件中管理块的分配，块号和内存地址的映射
	BYTE					 m_bKeyNum;					  //字段数量(来源于根节点结构体)
	BYTE					 m_bKeyType[5];				  //字段类型(来源于根节点结构体)

	/************************************************************************
		功能说明：
			将索引节点编号翻译成块实际所在的地址
	************************************************************************/
	LPBYTE ConvertBlockNotoAddr(int nNodeNo)
	{
		return m_pIndexFile->ConvertBlockNotoAddr(nNodeNo);
	}
	
	/************************************************************************
		功能说明：
			根据偏移获取实际地址
	************************************************************************/
	inline char* ConvertOffsettoAddr(long long nOffset)
	{
		if(nOffset == 0)
		{
			return NULL;
		}
		else
		{
			return m_pIndexFile->ConvertOffsettoAddr(nOffset);
		}
	}
	/************************************************************************
		功能说明：
			分配一块新的块
	************************************************************************/
	int AllocBlock(LPEXECUTEPLANBSON lpExecutePlan, int& nBlockNo, long long nBlockMapOffset, int nBlockSize, long long nTimestamp)
	{
		return m_pIndexFile->AllocBlock(lpExecutePlan, nBlockNo, nBlockMapOffset, nBlockSize, nTimestamp);
	}

	/************************************************************************
		功能说明：
			释放内存块(清空),并把块号添加到空块队列中
	************************************************************************/
	void FreeBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo);
	
	/************************************************************************
		功能说明：
			释放内存块(清空),并把块号添加到空块队列中
	************************************************************************/
	void FreeBlockDirect(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo)
	{
		m_pIndexFile->FreeBlock(lpExecutePlan, nBlockNo);
	}

	/************************************************************************
		功能说明：
			修改根结点
	************************************************************************/
	int RootUpdate(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nBlockNo)
	{
		m_lpRootBlock = ConvertBlockNotoAddr(nBlockNo);
		return m_pIndexFile->RootUpdate(lpExecutePlan, nIndexID,nBlockNo);
	}

	/************************************************************************
		功能说明：
			删除根结点
	************************************************************************/
	int RootDelete(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID)
	{
		m_lpRootBlock = NULL;
		return m_pIndexFile->RootDelete(lpExecutePlan, nIndexID);
	}

	/************************************************************************
		功能说明：
			释放跟结点的块
	************************************************************************/
	int FreeRootBlock(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID)
	{
		m_lpRootBlock = NULL;
		return m_pIndexFile->FreeRootBlock(lpExecutePlan, nIndexID);
	}

	/************************************************************************
		功能说明:
			将数据从一个位置移动到另外一个位置
	************************************************************************/
	void MoveIndexData(LPBYTE pSrcAddr, LPBYTE pDestAddr,int nLen);

	/************************************************************************
		功能说明:
			检查数据索引块是否满，如果满了应该调SplitIndexData函数进行拆分
	************************************************************************/
	BOOL CheckNodeFull(LPBYTE lpNodeData);

	/************************************************************************
		功能说明:
			将一块索引数据分裂成两块索引数据
	************************************************************************/
	int SplitIndexData(LPEXECUTEPLANBSON lpExecutePlan, MF_SYS_INDEXTYPE bIndexType, LPBYTE lpNode, BOOL bLast, int& nNewNodeNo, long long nTimestamp);

	/************************************************************************
		功能说明:
			合并两块索引块
	************************************************************************/
	void MergeNode(LPEXECUTEPLANBSON lpExecutePlan, LPBYTE lpSrcNode, LPBYTE lpDestNode, long long nTimestamp);

	/************************************************************************
		功能说明：
			判断是否可以进行合并
	************************************************************************/
	BOOL CanMerge(LPTREENODEHEAD lpSrcHead, LPTREENODEHEAD lpDestHead)
	{
		if(lpSrcHead->m_nDataNum + lpDestHead->m_nDataNum > lpDestHead->m_nTotalDataNum*MERGE_THRESHOLD)
		{	
			return FALSE;
		}
		return TRUE;
	}

	/************************************************************************
		功能说明：
			修改时间戳
	************************************************************************/
	void TimestampUpdate(LPEXECUTEPLANBSON lpExecutePlan, LPBASEBLOCKHEAD lpNodeHead, long long nTimestamp)
	{
		//判断时间戳是否发生变化，如果发生变化则修改时间戳
		if(lpNodeHead->m_nTimestamp != nTimestamp)
		{
			lpNodeHead->m_nTimestamp = nTimestamp;
			lpNodeHead->m_bSaveFlag  = 0;
		}
	}

	/************************************************************************
		功能说明：
			比较值的大小
	************************************************************************/
	int Compare(VARDATA& varData1, VARDATA& varData2, BOOL bMatch);
	
	/************************************************************************
		功能说明：
			判断是否到达结点的末尾
	************************************************************************/
	BOOL IsEnd(LPBYTE lpNode, LPBYTE lpCurrentPos);

	/************************************************************************
		功能说明：
			判断是否为节点开始
	************************************************************************/
	BOOL IsFirst(LPBYTE lpNode, LPBYTE lpCurrentPos);

	/************************************************************************
		功能说明：
			实现折半查找，需要精确查找给定的Key，实现被查询的
	************************************************************************/
	BOOL BinarySearch(LPMULTIINDEX lpMultiIndex, LPBINARYSEARCHINFO lpSearchInfo);
	void BinarySearch2(LPMULTIINDEX lpMultiIndex, LPBINARYSEARCHINFO lpSearchInfo);

	/************************************************************************
		功能说明：
			遍历大树干结点，找到关键字对应的树干结点
	************************************************************************/
	int BigTrunkSearch(LPEXECUTEPLANBSON lpExecutePlan, LPMULTIINDEX lpMultiIndex, LPBINARYSEARCHINFO lpSearchInfo, LPTREENODEINFO lpTreeNodeInfo);

	/************************************************************************
		功能说明：
			遍历树干结点，找到关键字对应的叶子结点
	************************************************************************/
	int TrunkSearch(LPMULTIINDEX lpMultiIndex, LPBINARYSEARCHINFO lpSearchInfo, LPTREENODEINFO lpTreeNodeInfo);

	/************************************************************************
		功能说明：
			遍历叶子结点，找到关键字对应的DataID
	************************************************************************/
	int LeaveNodeSearch(LPMULTIINDEX lpMultiIndex, LPBINARYSEARCHINFO lpSearchInfo, LPTREENODEINFO lpTreeNodeInfo);
	
	/************************************************************************
		功能说明：
			遍历树
	************************************************************************/
	int TreeSearch(LPEXECUTEPLANBSON lpExecutePlan, LPMULTIINDEX lpMultiIndex,  LPBINARYSEARCHINFO lpSearchInfo, LPTREENODEINFO lpTreeNodeInfo);
	
	/************************************************************************
		功能说明：
			在一个结点中查找数据项的插入位置
	************************************************************************/
	int CheckInsertAddr(LPEXECUTEPLANBSON lpExecutePlan, MF_SYS_INDEXTYPE bIndexType, LPMULTIINDEX lpMultiIndex, LPNODEINSERTINFO lpNodeInsertInfo, long long nTimestamp);

	/************************************************************************
		功能说明：
			将索引项插入叶子结点中
	************************************************************************/
	int InsertLeaveStruct(LPEXECUTEPLANBSON lpExecutePlan, MF_SYS_INDEXTYPE bIndexType, LPNODEINSERTINFO lpNodeInsertInfo, LPMULTIINDEX lpMultiIndex, long long nDataID, long long nTimestamp);

	/************************************************************************
		功能说明：
			将树干结点插入内存中
	************************************************************************/
	int InsertTrunkStruct(LPEXECUTEPLANBSON lpExecutePlan, MF_SYS_INDEXTYPE bIndexType, LPNODEINSERTINFO lpNodeInsertInfo, LPMULTIINDEX lpMultiIndex, int nNodeNo, long long nTimestamp);

	/************************************************************************
		功能说明：
			改变最大值
	************************************************************************/
	void ChangeMaxKey(LPEXECUTEPLANBSON lpExecutePlan, TREENODEINFO& stTreeNodeInfo, LPVOID lpKeyPtr, NODETYPE bNodeType, long long nTimestamp);

	/************************************************************************
		功能说明：
			获取前驱节点
	************************************************************************/
	int GetPrecursorNode(LPBYTE lpNode, LPBYTE lpNodeElement, LPBYTE& lpPreNode, LPBYTE& lpPreElement);

	/************************************************************************
		功能说明：
			获取后继节点
	************************************************************************/
	int GetSuccessorNode(LPBYTE lpNode, LPBYTE lpNodeElement, LPBYTE& lpSuccessNode, LPBYTE& lpSuccessElement);

	/************************************************************************
		功能说明：
			获取相邻节点的信息
	************************************************************************/
	int GetNeighborNodeInfo(TREENODEINFO& stSrcTreeNode, TREENODEINFO& stNeighborNode, NODETYPE bNodeType, BOOL bSuccessor);

	/************************************************************************
		功能说明：
			在结点中删除对应的数据
	************************************************************************/
	int DeleteKey(LPEXECUTEPLANBSON lpExecutePlan, TREENODEINFO& stTreeNodeInfo, BYTE bNodeType, long long nTimestamp);

	/************************************************************************
		功能说明:
			移动到下一条数据
	************************************************************************/
	int MoveNext(LPINDEXINFO lpIndexInfo);

	/************************************************************************
		功能说明：
			找到B树第一个叶子结点的第一个元素
	************************************************************************/
	int FirstLeaveElement(LPEXECUTEPLANBSON lpExecutePlan, LPTREENODEINFO lpTreeNodeInfo);

	/************************************************************************
		功能说明：
			找到B树最后一个叶子结点的最后一个元素
	************************************************************************/
	int LastLeaveElement(LPEXECUTEPLANBSON lpExecutePlan, LPTREENODEINFO lpTreeNodeInfo);

	/************************************************************************
		功能说明：
			找到起始大树干结点、树干结点、叶子结点的位置
	************************************************************************/
	int FirstNodeHead(LPTREENODEHEAD& lpLeaveHead, LPTREENODEHEAD& lpTrunkHead, LPTREENODEHEAD& lpBigTrunkHead);

	/************************************************************************
		功能说明：
			获取叶子结点位置
	************************************************************************/
	int GetLeaveNode(LPINDEXINFO lpIndexInfo, LPBINARYSEARCHINFO lpSearchInfo);

	/************************************************************************
		功能说明：
			从指定位置获取DataID
	************************************************************************/
	int GetDataIDFromLeave(LPINDEXINFO lpIndexInfo, LPBINARYSEARCHINFO lpSearchInfo, CDataIDContainer* pDataIDContainer);

	/************************************************************************
		功能说明：
			获取结点头大小
	************************************************************************/
	virtual int GetHeadSize(LPMULTIINDEX lpMultiIndex) = 0;

	/************************************************************************
		功能说明：
			获取叶子大小
	************************************************************************/
	virtual int GetLeaveSize(LPMULTIINDEX lpMultiIndex) = 0;

	/************************************************************************
		功能说明：
			获取树干大小
	************************************************************************/
	virtual int GetTrunkSize(LPMULTIINDEX lpMultiIndex) = 0;

	/************************************************************************
		功能说明：
			获取关键字值
	************************************************************************/
	virtual void GetKeyValue(LPVOID lpKey, int nLevel, VARDATA& varKey) = 0;

	/************************************************************************
		功能说明：
			设置关键字值
	************************************************************************/
	virtual void SetKeyValue(LPVOID lpKey, LPVOID lpKeyValue, BOOL bInsert) = 0;

	/************************************************************************
		功能说明：
			获取Key的指针
	************************************************************************/
	virtual LPVOID GetKeyPtr(LPVOID lpData, NODETYPE bNodeType) = 0;

	/************************************************************************
		功能说明：
			获取MaxKey的指针
	************************************************************************/
	virtual LPVOID GetMaxKeyPtr(LPBYTE lpNode) = 0;

	/************************************************************************
		功能说明：
			判断是否为最大关键字
	************************************************************************/
	virtual BOOL CheckMaxKey(LPVOID lpKeyPtr) = 0;

	/************************************************************************
		功能说明：
			从叶子结构体中获取值，即DataID
	************************************************************************/
	virtual long long GetDataIDFromLeavePtr(LPVOID lpLeaveData) = 0;

	/************************************************************************
		功能说明：
			从关键字指针中获取关键字值
	************************************************************************/
	virtual int GetValueFromKeyPtr(LPVOID lpKeyPtr, int nIndex, VARDATA& varData) = 0;

	/************************************************************************
		功能说明：
			设置叶子结点数据
	************************************************************************/
	virtual void SetLeaveData(LPVOID lpLeaveData, LPMULTIINDEX lpMultiIndex, long long nDataID) = 0;

	/************************************************************************
		功能说明：
			从树干结构体中获取值，即结点编号
	************************************************************************/
	virtual int GetNodeNoFromTrunk(LPVOID lpTrunkData) = 0;
	
	/************************************************************************
		功能说明：
			从树干结构体中获取值，即结点编号
	************************************************************************/
	virtual void SetNodeNoToTrunk(LPVOID lpTrunkData, int nNodeNo) = 0;
	
	/************************************************************************
		功能说明：
			设置叶子结点数据
	************************************************************************/
	virtual void SetTrunkData(LPVOID lpTrunkData, LPMULTIINDEX lpMultiIndex, int nNodeNo) = 0;

	/************************************************************************
		功能说明：
			设置索引字段数据
	************************************************************************/
	virtual void SetIndexField(LPMULTIINDEX lpMultiIndex, LPVOID lpKey) = 0;
	
	/************************************************************************
		功能说明：
			比较函数
	************************************************************************/
	virtual int Compare(LPMULTIINDEX lpMultiIndex, LPVOID lpKey, BYTE bOperator, BOOL& bFindKey) = 0;
	
	/************************************************************************
		功能说明：
			判断值是否合法
	************************************************************************/
	virtual void CheckDataValid(LPINDEXINFO lpIndexInfo, LPVOID lpKey, int nLevel, BOOL& bContinue, BOOL& bPush) = 0;
	
	/************************************************************************
		功能说明:
			初始化块头
	************************************************************************/
	virtual void InitialBlock(LPVOID lpNodeHead, int nDataSize, int nHeadSize, BYTE nNodeTypeFlag) = 0;
private:
	friend class CMemoryBTreeFile;
	//防止此类被非法构造成对象或者复制
	CMemoryBTreeIndex(const CMemoryBTreeIndex&);
	CMemoryBTreeIndex& operator = (const CMemoryBTreeIndex&);

public:
	CMemoryBTreeIndex(void);
	~CMemoryBTreeIndex(void);

public:
	/************************************************************************
		功能说明：
			初始化数据块管理类，让整个实例是可执行的
	************************************************************************/
	void SetNodeAddr(LPBYTE lpRootBlock, int nIndexID, BYTE bFildNum, LPBYTE bFieldType, CMemoryBTreeFile* pIndexFile)
	{
		int i;
		m_lpRootBlock		= lpRootBlock;
		m_nIndexID			= nIndexID;
		m_pIndexFile		= pIndexFile;
		m_bKeyNum			= bFildNum;
		for(i = 0; i < bFildNum; i++)
		{
			m_bKeyType[i] = bFieldType[i];
		}
	}

	/************************************************************************
		功能说明：
			删除索引
	************************************************************************/
	virtual int DropIndex(LPEXECUTEPLANBSON lpExecutePlan);

	/************************************************************************
		功能说明：
			根据key值在索引块中插入一个新的索引项
	************************************************************************/
	virtual int InsertIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);

	/************************************************************************
		功能说明：
			根据key值在索引块中删除一个索引项
	************************************************************************/
	virtual int DeleteIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);

	/************************************************************************
		功能说明：
			获取DataID
	************************************************************************/
	virtual int GetDataID(LPINDEXINFO lpIndexInfo, CDataIDContainer* pDataIDContainer); 

	/************************************************************************
		功能说明：
			获取索引扫描范围
	************************************************************************/
	virtual int GetIndexScanScope(LPSUBINDEXPLAN lpSubIndexPlan);

	/************************************************************************
		功能说明：
			获取索引的最大关键字值和最小关键字值
	************************************************************************/
	virtual int GetIndexRange(int nIndexID, VARDATA& varMaxKey, VARDATA& varMinKey);
};
