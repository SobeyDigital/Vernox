﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
//函数管理类
#pragma once
#include "../VernoxBaseLib/BaseFunManager.h"
class CFunctionManager : public CBaseFunManager
{
private:
	CFunctionManager();
	~CFunctionManager();

	//序列操作函数
	static int NextVal(LPCTSTR lpszName, VARDATA& varResult);
	static int CurrVal(LPCTSTR lpszName, VARDATA& varResult);

	//COUNT函数
	static int Count(CServiceBson& stBson, CDataIDContainer* pDataIDContainer, VARDATA& varResult, LPTRANSACTIONARRAY lpTransactionArray, long long nTimestamp, BYTE bFieldNo = 0);
	static int Count(CServiceBson& stBson, CSysRecordContainer* pRecordContainer, VARDATA& varResult, BYTE bFieldNo = 0);
public:
	//获得普通函数的函数值
	static int GetFunctionVal(CServiceBson& stBson, BYTE bFunType, const VARDATA& varValue1, const VARDATA& varValue2, VARDATA& varResult);
	//重载函数获得聚合函数的函数值
	static int GetFunctionVal(CServiceBson& stBson, BYTE bFunType, CDataIDContainer* pDataIDContainer, const VARDATA& varValue, VARDATA& varResult, LPTRANSACTIONARRAY lpTransactionArray, long long nTimestamp);
	static int GetFunctionVal(CServiceBson& stBson, BYTE bFunType, CSysRecordContainer* pRecordContainer, const VARDATA& varValue, VARDATA& varResult);
	//判断执行字段是否为Count(*)
	static BOOL IsCountAll(CServiceBson& stBson, LPEXECUTEFIELDBSON lpFieldBson);
};