﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#ifndef WIN32
#include <map>
#include "../VernoxBaseLib/LinuxCommonAPI.h"
#include "../Include/SobeyMemBaseExport.h"
#include "../Include/MemDBCommonDef.h"
#endif
#include "../VernoxServiceLib/ServiceCommonDef.h"
#include "../VernoxServiceLib/MapSimple.h"
class CExecutePlanManager;
class CServiceBson;
class IVirtualMemObject;
class CContainerManage
{
private:
	//防止此类被非法构造成对象或者复制
	CContainerManage(const CContainerManage&);
	CContainerManage& operator = (const CContainerManage&);
	CMapSimple	m_mapImplementClass;
	//map<BYTE, IVirtualMemObject *> m_mapImplementClass;

	//针对每分钟做一次性能统计
	long long m_llWorkloadTime;
	long long m_nExecuteTime;
	int		  m_nMinExecuteTime;
	int		  m_nMaxExecuteTime;
	LONG	  m_nQueryCount;
	LONG	  m_nUpdateCount;
public:
	CContainerManage(void);
	virtual ~CContainerManage(void);

private:
	int InitImplementClass();
	int GetMemObject(LPEXECUTEPLANBSON lpExecutePlan, IVirtualMemObject *&pMemObject);
	int GetMemObject(BYTE bImplementClass, IVirtualMemObject *&pMemObject);
public:
	int Initialize();
	void InitCharCompare(LPBYTE lpBuffer, int nSize);
	int Uninitialize();

	//获取记录数
	int GetReocrdNum(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, int& nRecordNum, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	//执行命令
	int ExecuteCommand(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	//检索数据
	int GetRecordset(CServiceBson &stBson,  CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	//执行修改命令
	int UpdateRecordset(CServiceBson &stBson,  CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	//写入执行时间信息
	int SetExecuteStatistics(LPEXECUTEPLANBSON lpExecutePlan, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	
	int StartTransactionLogic(DWORD dwIP, const char * lpszTransactionData, int &lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int StopTransactionLogic(DWORD dwIP, int lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo);

	void SetSessionInfo(LPSESSIONINFO lpSessionInfo, BOOL bSaop);
	void RemoveSessionInfo(LPSESSIONINFO &lpSessionInfo, BOOL bSaop);

	int	ExportObject(CServiceBson& stBson, char* pObjectName, LPEXPORTPARAM lpExportParam, long long nTimestamp);
	int	ImportObject(CServiceBson& stBson, char* pObjectName, LPIMPORTPARAM lpImportParam, long long nTimestamp);
public:
	int Recover(CServiceBson& stBson, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int Preprocess(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int CriticalRelease(CServiceBson& stBson);			
	int ResourceRelease(CServiceBson& stBson, int nRetValue);
};

