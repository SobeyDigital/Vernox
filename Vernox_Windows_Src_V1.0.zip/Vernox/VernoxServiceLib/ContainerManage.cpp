﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "ContainerManage.h"
#include "BaseMemObject.h"
#include "SysMemObject.h"
#include "CommonMemObject.h"

CContainerManage::CContainerManage(void)
{
	m_llWorkloadTime	= 0;
	m_nQueryCount		= 0;
	m_nUpdateCount		= 0;
	m_nExecuteTime		= 0;
	m_nMinExecuteTime	= 0;
	m_nMaxExecuteTime	= 0;

	m_mapImplementClass.Initialize(16);
}

CContainerManage::~CContainerManage(void)
{
	int nID;
	LPVOID lpPos, lpValue;
	IVirtualMemObject* pMemObject;
	
	lpPos = m_mapImplementClass.GetHeadPosition();
	while(lpPos != NULL)
	{
		m_mapImplementClass.GetNext(lpPos, nID, lpValue);
		if(lpValue != NULL)
		{
			pMemObject = (IVirtualMemObject*)lpValue;
			pMemObject->Release();
		}
	}
	m_mapImplementClass.Clear();
}

//插件初始化定义
int CContainerManage::InitImplementClass()
{
	IVirtualMemObject * pVirtualMemObject;
	//初始化系统插件
	pVirtualMemObject = new CSysMemObject;
	m_mapImplementClass.Set(MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM, pVirtualMemObject);
	//初始化通用插件
	pVirtualMemObject = new CCommonMemObject;
	m_mapImplementClass.Set(MF_MEMOBJECT_IMPLEMENTCLASS_COMMON, pVirtualMemObject);
	return MF_OK;
}

int CContainerManage::Initialize()
{
	int nRet;
	nRet = CSystemManage::instance().InitData();
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = InitImplementClass();
	if(nRet != MF_OK)
	{
		return nRet;
	}

	return MF_OK;
}

void CContainerManage::InitCharCompare(LPBYTE lpBuffer, int nSize)
{
	CSystemManage::instance().InitCharCompare(lpBuffer, nSize);
}

int CContainerManage::Uninitialize()
{
	CSystemManage::DestoryInstance();
	return MF_OK;
}

int CContainerManage::GetMemObject(LPEXECUTEPLANBSON lpExecutePlan, IVirtualMemObject *&pMemObject)
{
	//首先获取对象数据
	int nRet;
	BYTE bImplementClass;
	LPOBJECTDEF lpObjectInfo;

	if(lpExecutePlan->m_bDBType == MF_DATABASE_MEMDB)
	{
		nRet = CSystemManage::instance().GetObjectInfo(lpExecutePlan->m_nObjectID, lpObjectInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		bImplementClass			   = lpObjectInfo->m_bImplementClass;
		lpExecutePlan->m_nObjectID = lpObjectInfo->m_nObjectID;
	}
	else
	{
		bImplementClass = lpExecutePlan->m_bDBType;
	}

	
	if (CSystemManage::instance().GetMemFileStatus() == 0 || bImplementClass == MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM)
	{
		pMemObject = (IVirtualMemObject*)m_mapImplementClass.Get(bImplementClass);
		if(pMemObject == NULL)
		{
			return MF_SYS_OBJECT_IMPLEMENTCLASS_ERROR;
		}
	}
	else
	{
		pMemObject = NULL;
		return MF_SYS_OBJECT_IMPLEMENTCLASS_LOAD;
	}

	return MF_OK;
}

int CContainerManage::GetMemObject(BYTE bImplementClass, IVirtualMemObject *&pMemObject)
{
	//获取对象数据
	if (CSystemManage::instance().GetMemFileStatus() == 0 || bImplementClass == MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM)
	{
		pMemObject = (IVirtualMemObject*)m_mapImplementClass.Get(bImplementClass);
		if(pMemObject == NULL)
		{
			return MF_SYS_OBJECT_IMPLEMENTCLASS_ERROR;
		}
	}
	else
	{
		pMemObject = NULL;
		return MF_SYS_OBJECT_IMPLEMENTCLASS_LOAD;
	}

	return MF_OK;
}

int CContainerManage::GetReocrdNum(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, int& nRecordNum, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	IVirtualMemObject *pMemObject;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	//根据执行计划查找对象对应的执行实例
	nRet = GetMemObject(lpExecutePlan, pMemObject);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(pMemObject == NULL)
	{
		return MF_INNER_POINTER_NULL;
	}
	else
	{
		//备份事务链表
		nRet = CSystemManage::instance().SetTransactionLine(stBson, lpExecutePlan->m_nTimestamp, lpExecutePlan->m_nTransactionOffset, lpExecutePlan->m_nTransactionNum);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpExecutePlan->m_stSourceInfo.m_nTimestamp = lpExecutePlan->m_nTimestamp;
		//使用执行实例和执行计划，执行客户端命令
		QueryPerformanceCounter(&lpExecuteInfo->m_liExecuteStart);
		nRet = pMemObject->GetRecordNum(stBson, stExecutePlanManager, nRecordNum, lpExecuteInfo);
		QueryPerformanceCounter(&lpExecuteInfo->m_liExecuteStart);
		//资源释放
		if(MF_OK != pMemObject->ResourceRelease(stBson, nRet, stExecutePlanManager))
		{
			return MF_INNER_SYS_SOURCERELEASE_ERROR;
		}
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//写重做日志
	if(lpExecutePlan->m_bDBType == MF_DATABASE_MEMDB)
	{
		if(lpExecutePlan->m_bWriteLog == 1)
		{
			if(GetSystemParameterValue(MF_SERVER_WRITE_UNDOMODE) == 1)
			{
				lpExecutePlan->m_nDataFlag = MF_LOG_PLANHEAD_MAGIC_FLAG;
				CSystemManage::instance().WriteLog(stBson, stExecutePlanManager);
			}
		}
	}
	return MF_OK;
}
int CContainerManage::ExecuteCommand(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	IVirtualMemObject *pMemObject;
	LPEXECUTEPLANBSON lpExecutePlan;
	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();

	lAffectCount  = 0;	
	//根据执行计划查找对象对应的执行实例
	nRet = GetMemObject(lpExecutePlan, pMemObject);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//使用执行实例和执行计划，执行客户端命令
	if(pMemObject == NULL)
	{
		return MF_INNER_POINTER_NULL;
	}
	else
	{
		//备份事务链表
		nRet = CSystemManage::instance().SetTransactionLine(stBson, lpExecutePlan->m_nTimestamp, lpExecutePlan->m_nTransactionOffset, lpExecutePlan->m_nTransactionNum);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		QueryPerformanceCounter(&lpExecuteInfo->m_liExecuteStart);
		lpExecuteInfo->m_liIndexSearchEnd.QuadPart = lpExecuteInfo->m_liExecuteStart.QuadPart;
		nRet = pMemObject->ExecuteCommand(stBson, stExecutePlanManager, lAffectCount, lpExecuteInfo);
		QueryPerformanceCounter(&lpExecuteInfo->m_liExecuteEnd);
		
		//临界区释放
		pMemObject->CriticalRelease(stBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//写重做日志
	if(lpExecutePlan->m_bDBType == MF_DATABASE_MEMDB)
	{
		if(lpExecutePlan->m_bWriteLog == 1)
		{
			if(GetSystemParameterValue(MF_SERVER_WRITE_UNDOMODE) == 1)
			{
				lpExecutePlan->m_nDataFlag = MF_LOG_PLANHEAD_MAGIC_FLAG;
				CSystemManage::instance().WriteLog(stBson, stExecutePlanManager);
			}
		}
	}
	QueryPerformanceCounter(&lpExecuteInfo->m_liWriteLogEnd);
	return MF_OK;
}

//检索数据
int CContainerManage::GetRecordset(CServiceBson &stBson,  CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	IVirtualMemObject *pMemObject;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	//根据执行计划查找对象对应的执行实例
	nRet = GetMemObject(lpExecutePlan, pMemObject);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(pMemObject == NULL)
	{
		return MF_INNER_POINTER_NULL;
	}
	else
	{
		//备份事务链表
		nRet = CSystemManage::instance().SetTransactionLine(stBson, lpExecutePlan->m_nTimestamp, lpExecutePlan->m_nTransactionOffset, lpExecutePlan->m_nTransactionNum);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpExecutePlan->m_stSourceInfo.m_nTimestamp = lpExecutePlan->m_nTimestamp;
		//使用执行实例和执行计划，执行客户端命令
		QueryPerformanceCounter(&lpExecuteInfo->m_liExecuteStart);
		nRet = pMemObject->GetRecordset(stBson, stExecutePlanManager, lpBsonRs, nBsonRsSize, lpExecuteInfo);
		QueryPerformanceCounter(&lpExecuteInfo->m_liExecuteEnd);
		//资源释放
		if(MF_OK != pMemObject->ResourceRelease(stBson, nRet, stExecutePlanManager))
		{
			return MF_INNER_SYS_SOURCERELEASE_ERROR;
		}
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//写重做日志
	if(lpExecutePlan->m_bDBType == MF_DATABASE_MEMDB)
	{
		if(lpExecutePlan->m_bWriteLog == 1)
		{
			if(GetSystemParameterValue(MF_SERVER_WRITE_UNDOMODE) == 1)
			{
				lpExecutePlan->m_nDataFlag = MF_LOG_PLANHEAD_MAGIC_FLAG;
				CSystemManage::instance().WriteLog(stBson, stExecutePlanManager);
			}
		}
	}
	QueryPerformanceCounter(&lpExecuteInfo->m_liWriteLogEnd);
	return MF_OK;
}

int CContainerManage::UpdateRecordset(CServiceBson &stBson,  CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	IVirtualMemObject *pMemObject;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	nRet = GetMemObject(lpExecutePlan, pMemObject);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(pMemObject == NULL)
	{
		return MF_INNER_POINTER_NULL;
	}
	else
	{
		//备份事务链表
		nRet = CSystemManage::instance().SetTransactionLine(stBson, lpExecutePlan->m_nTimestamp, lpExecutePlan->m_nTransactionOffset, lpExecutePlan->m_nTransactionNum);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		QueryPerformanceCounter(&lpExecuteInfo->m_liExecuteStart);
		lpExecuteInfo->m_liIndexSearchEnd.QuadPart = lpExecuteInfo->m_liExecuteStart.QuadPart;
		nRet = pMemObject->UpdateRecordset(stBson, stExecutePlanManager, lpExecuteInfo);
		QueryPerformanceCounter(&lpExecuteInfo->m_liExecuteEnd);
		
		//临界区释放
		pMemObject->CriticalRelease(stBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//写重做日志
	if(lpExecutePlan->m_bDBType == MF_DATABASE_MEMDB)
	{
		if(lpExecutePlan->m_bWriteLog == 1)
		{
			if(GetSystemParameterValue(MF_SERVER_WRITE_UNDOMODE) == 1)
			{
				lpExecutePlan->m_nDataFlag = MF_LOG_PLANHEAD_MAGIC_FLAG;
				CSystemManage::instance().WriteLog(stBson, stExecutePlanManager);
			}
		}
	}
	QueryPerformanceCounter(&lpExecuteInfo->m_liWriteLogEnd);
	return MF_OK;
}

//写入执行时间信息
int CContainerManage::SetExecuteStatistics(LPEXECUTEPLANBSON lpExecutePlan, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nExecuteTime;
	long long llTime;
	llTime					= *((long long *)&lpExecuteInfo->m_ftEndTime);
	lpExecuteInfo->m_dwTime = (DWORD)(1000000 * (lpExecuteInfo->m_liEnd.QuadPart - lpExecuteInfo->m_liStart.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart ); //换算到微秒数
	nExecuteTime			= lpExecuteInfo->m_dwTime;

	//数据开始不考虑多线程情况，无非不过多次赋值而已，针对统计可接受
	if(m_llWorkloadTime == 0)
	{
		m_llWorkloadTime	= llTime;
		m_nMinExecuteTime	= nExecuteTime;
		m_nMaxExecuteTime	= nExecuteTime;
		m_nExecuteTime		= 0;
		m_nQueryCount		= 0;
		m_nUpdateCount		= 0;
	}


	//100纳秒为单位，一分钟形成一份统计信息
	if(llTime - m_llWorkloadTime > 600000000) //10*1000*1000*60
	{
		//达到一个统计周期，但是本条不属于此统计周期
		long nQueryCount, nUpdateCount;
		long long llWorkloadTime;
		nQueryCount			= m_nQueryCount;
		nUpdateCount		= m_nUpdateCount;
		llWorkloadTime		= m_llWorkloadTime;

		//为了防止多线程情况下出现并行执行情况，这里先拷贝出来然后再判断是否需要处理
		if(llWorkloadTime > 0 && llTime - llWorkloadTime > 600000000)
		{
			if(CSystemManage::instance().SetWorkloadStatistics(llWorkloadTime, llTime, m_nExecuteTime, m_nMinExecuteTime, m_nMaxExecuteTime, nQueryCount, nUpdateCount))
			{
				m_llWorkloadTime	= llTime;
				m_nMinExecuteTime	= nExecuteTime;
				m_nMaxExecuteTime	= nExecuteTime;
				m_nExecuteTime		= 0;
				m_nQueryCount		= 0;
				m_nUpdateCount		= 0;
			}
		}
	}

	//增加操作计数，保证多线程下增加不出现混乱
	if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_QUERY)
	{
		InterlockedIncrement(&m_nQueryCount);
	}
	else
	{
		InterlockedIncrement(&m_nUpdateCount);
	}
	m_nExecuteTime += nExecuteTime;
	if(nExecuteTime < m_nMinExecuteTime)
	{
		m_nMinExecuteTime = nExecuteTime;
	}
	else if(nExecuteTime > m_nMaxExecuteTime)
	{
		m_nMaxExecuteTime = nExecuteTime;
	}

	CSystemManage::instance().SetExecuteStatistics(lpExecuteInfo, lpExecutePlan);
	return MF_OK;
}

void CContainerManage::SetSessionInfo(LPSESSIONINFO lpSessionInfo, BOOL bSaop)
{
	CSystemManage::instance().SetSessionInfo(lpSessionInfo, bSaop);
}

void CContainerManage::RemoveSessionInfo(LPSESSIONINFO &lpSessionInfo, BOOL bSaop)
{
	CSystemManage::instance().RemoveSessionInfo(lpSessionInfo, bSaop);
}

int	CContainerManage::ExportObject(CServiceBson& stBson, char* pObjectName, LPEXPORTPARAM lpExportParam,long long nTimestamp)
{
	int nRet;
	LPOBJECTDEF lpObjectInfo;
	IVirtualMemObject* pMemObject;

	nRet = CSystemManage::instance().GetObjectInfo(pObjectName, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	nRet = GetMemObject(lpObjectInfo->m_bImplementClass, pMemObject);
	if(nRet == MF_OK)
	{
		nRet = pMemObject->ExportObject(stBson, pObjectName, lpExportParam, nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		return nRet;
	}

	return MF_OK;
}

int	CContainerManage::ImportObject(CServiceBson& stBson, char* pObjectName, LPIMPORTPARAM lpImportParam, long long nTimestamp)
{
	int nRet;
	CCommonMemObject* pCommonObject;
	LPOBJECTBUFFERHEAD lpObjectBufferHead;
	MF_MEMOBJECT_IMPLEMENTCLASS_TYPE bImplementClass;

	lpObjectBufferHead	= (LPOBJECTBUFFERHEAD)stBson.GetBuffer();
	if(lpObjectBufferHead->m_bObjectType == MF_OBJECT_COMMON)
	{
		bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_COMMON;
	}
	else
	{
		return MF_SYS_OBJECT_IMPLEMENTCLASS_ERROR;
	}
	pCommonObject = (CCommonMemObject*)m_mapImplementClass.Get(bImplementClass);
	if(pCommonObject == NULL)
	{
		return MF_SYS_OBJECT_IMPLEMENTCLASS_ERROR;
	}
	else
	{
		nRet = pCommonObject->ImportObject(stBson, pObjectName, lpImportParam, nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

int CContainerManage::StartTransactionLogic(DWORD dwIP, const char * lpszTransactionData, int &lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	return CSystemManage::instance().StartTransactionLogic(dwIP, lpszTransactionData, lTransactionID, lpExecuteInfo);
}

int CContainerManage::StopTransactionLogic(DWORD dwIP, int lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	return CSystemManage::instance().StopTransactionLogic(dwIP, lTransactionID, lpExecuteInfo);
}

int CContainerManage::Recover(CServiceBson& stBson, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	IVirtualMemObject *pMemObject;
	LPEXECUTEPLANBSON lpExecutePlan;
	CExecutePlanManager stExecutePlanManager;
	CSystemTimestampTransactionManage stTransaction;
	
	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	stExecutePlanManager.Initial(lpExecutePlan, &stBson);
	
	//开启事务	
	stTransaction.StartTransaction(lpExecutePlan->m_nTimestamp);

	//根据执行计划查找对象对应的执行实例
	nRet = GetMemObject(lpExecutePlan, pMemObject);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//使用执行实例和执行计划，执行客户端命令
	if(pMemObject == NULL)
	{
		return MF_INNER_POINTER_NULL;
	}
	else
	{

		//备份事务链表
		nRet = CSystemManage::instance().SetTransactionLine(stBson, lpExecutePlan->m_nTimestamp, lpExecutePlan->m_nTransactionOffset, lpExecutePlan->m_nTransactionNum);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		QueryPerformanceCounter(&lpExecuteInfo->m_liExecuteStart);
		nRet = pMemObject->Recover(stBson, stExecutePlanManager, lAffectCount, lpExecuteInfo);
		QueryPerformanceCounter(&lpExecuteInfo->m_liExecuteEnd);
		//释放临界区
		pMemObject->CriticalRelease(stBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//写重做日志
	if(lpExecutePlan->m_bDBType == MF_DATABASE_MEMDB)
	{
		if(lpExecutePlan->m_bWriteLog == 1)
		{
			if(GetSystemParameterValue(MF_SERVER_WRITE_UNDOMODE) == 1)
			{
				lpExecutePlan->m_nDataFlag = MF_LOG_PLANHEAD_MAGIC_FLAG;
				CSystemManage::instance().WriteLog(stBson, stExecutePlanManager);
			}
		}
	}
	return MF_OK;
}

int CContainerManage::Preprocess(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	IVirtualMemObject *pMemObject;
	LPEXECUTEPLANBSON lpExecutePlan;
	
	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	//备份事务链表
	nRet = CSystemManage::instance().SetTransactionLine(stBson, lpExecutePlan->m_nTimestamp, lpExecutePlan->m_nTransactionOffset, lpExecutePlan->m_nTransactionNum);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	nRet = GetMemObject(lpExecutePlan, pMemObject);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	return pMemObject->Preprocess(stBson, stExecutePlanManager, lpExecuteInfo);
}

int CContainerManage::CriticalRelease(CServiceBson& stBson)
{
	int nRet;
	IVirtualMemObject *pMemObject;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();

	nRet = GetMemObject(lpExecutePlan, pMemObject);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	pMemObject->CriticalRelease(stBson);
	return MF_OK;
}

int CContainerManage::ResourceRelease(CServiceBson& stBson, int nRetValue)
{
	int nRet;
	LPOBJECTDEF lpObjectInfo;
	IVirtualMemObject *pMemObject;
	LPEXECUTEPLANBSON lpExecutePlan;
	CExecutePlanManager stExecutePlanManager;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	stExecutePlanManager.Initial(lpExecutePlan, &stBson);

	nRet = CSystemManage::instance().GetObjectInfo(lpExecutePlan->m_nObjectID, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	stBson.SetObjectInfo(lpObjectInfo);

	nRet = GetMemObject(lpExecutePlan, pMemObject);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	if(MF_OK != pMemObject->ResourceRelease(stBson, nRetValue, stExecutePlanManager))
	{
		return MF_INNER_SYS_SOURCERELEASE_ERROR;
	}

	return MF_OK;
}
