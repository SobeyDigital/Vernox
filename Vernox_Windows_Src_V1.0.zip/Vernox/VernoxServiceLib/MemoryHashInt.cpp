﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryHashIndex.h"
#include "MemoryHashInt.h"
#include "Check.h"
CMemoryHashInt::CMemoryHashInt(void)
{
}

CMemoryHashInt::~CMemoryHashInt(void)
{
}

/************************************************************************
		功能说明：
			获取关键字值
		参数说明：
			lpNodeData：节点数据
			varKey：关键字值
************************************************************************/
void CMemoryHashInt::GetKeyValue(LPVOID lpNodeData, VARDATA& varKey)
{
	LPINDEXSTRUCT lpIndex;

	lpIndex = (LPINDEXSTRUCT)lpNodeData;
	varKey.SetData(lpIndex->m_nKey);
}

/************************************************************************
		功能说明：
			获取关键字值
		参数说明：
			lpNodeData：节点数据
************************************************************************/
long long CMemoryHashInt::GetDataIDFromNodeData(LPVOID lpNodeData)
{
	return ((LPINDEXSTRUCT)lpNodeData)->m_nDataID;
}

/************************************************************************
		功能说明：
			设置节点数据
		参数说明：
			lpNodeData：节点数据
			varKey：关键字值
			nDataID：数据ID
************************************************************************/
void CMemoryHashInt::SetNodeData(LPVOID lpNodeData, VARDATA& varKey, long long nDataID)
{
	LPINDEXSTRUCT lpIndex;

	lpIndex = (LPINDEXSTRUCT)lpNodeData;
	lpIndex->m_nDataID     = nDataID;
	lpIndex->m_nKey		   = varKey.m_llValue;
	lpIndex->m_nNextOffset = 0;
}

/************************************************************************
		功能说明：
			清空节点数据
		参数说明：
			lpNodeData：节点数据
************************************************************************/
void CMemoryHashInt::ClearNodeData(LPVOID lpNodeData)
{
	LPINDEXSTRUCT lpIndex;

	lpIndex = (LPINDEXSTRUCT)lpNodeData;
	lpIndex->m_nDataID     = 0;
	lpIndex->m_nKey		   = 0;
	lpIndex->m_nNextOffset = 0;
}

/************************************************************************
		功能说明：
			计算Hash值
		参数说明：
			varKey：关键字指针
			nHashSize：Hash表大小
************************************************************************/
DWORD CMemoryHashInt::CalcKeyHash(VARDATA& varKey, int nHashSize)
{
	int nHashNodeNo;
	
	nHashNodeNo = varKey.m_llValue % nHashSize;
	return nHashNodeNo;
}

/************************************************************************
		功能说明：
			判断关键字是否重复
		参数说明：
			pBson：Bson对象
			bFieldNo：字段编号
			varKey:关键字
			lpHashNode:哈希结点
************************************************************************/
BOOL CMemoryHashInt::CheckKey(CServiceBson* pBson, VARDATA& varKey, BYTE bFieldNo, LPHASHNODE lpHashNode)
{
	int nRet;
	VARDATA varData;
	CMemoryFile* pFile;
	LPINDEXSTRUCT lpIndex;
	long long nIndexOffset;
	LPOBJECTDEF lpObjectInfo;
	CExpression stExpression;
	RECORDDATAINFO stRecordInfo;
	IVirtualMemoryFile* pVirtualFile;

	stRecordInfo.m_bDataPosition = MF_DATAPOSITION_LOCAL;
	//遍历冲突链表，判断关键字值是否重复
	nIndexOffset = lpHashNode->m_nIndexOffset;
	while(nIndexOffset)
	{
		lpIndex = (LPINDEXSTRUCT)ConvertOffsettoAddr(nIndexOffset);
		if(lpIndex->m_nKey == varKey.m_llValue)
		{
			//校验索引值是否合法
			lpObjectInfo = pBson->GetObjectInfo();
			nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pFile = (CMemoryFile*)pVirtualFile;
			stExpression.Initial(pBson, lpObjectInfo);

			stRecordInfo.m_nDataID = lpIndex->m_nDataID;
			nRet = pFile->GetRecordFieldValue(pBson, &stExpression, &stRecordInfo, bFieldNo, varData);
			if(nRet != MF_OK)
			{
				return FALSE;
			}
			if(varKey == varData)
			{
				return TRUE;
			}
			else
			{
				return FALSE;
			}
		}
		nIndexOffset = lpIndex->m_nNextOffset;
	}
	return FALSE;
}

