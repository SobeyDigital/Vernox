﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

//数字型HASH类，适用于用一个数字关联一个指针
class CMapSimple
{
	typedef struct stu_MapSimple_BaseData
	{
		int						 m_nID;					//数据ID
		LPVOID					 m_lpData;				//数据指针
		stu_MapSimple_BaseData * m_lpNext;				//下一个节点
	}MAPSIMPLEBASEDATA, *LPMAPSIMPLEBASEDATA;
protected:
	int					  m_nDataCount;
	LPMAPSIMPLEBASEDATA   *m_lpBaseData;
	CRITICAL_SECTION	  m_critMap;
public:
	CMapSimple(void);
	virtual ~CMapSimple(void);
public:
	int Initialize(int nMapSize);
	void Clear();
	int Set(int nID, LPVOID lpData);
	LPVOID Get(int nID);
	LPVOID Remove(int nID);
	LPVOID GetHeadPosition();
	void GetNext(LPVOID &nPos, int &nID, LPVOID &lpData);
};

//数字型HASH类，适用于用一个数字关联一个指针
class CMapLongLong
{
	typedef struct stu_MapSimple_BaseData
	{
		long long				 m_llKey;				//关键字
		long long				 m_llValue;				//值
		stu_MapSimple_BaseData * m_lpNext;				//下一个节点
	}MAPSIMPLEBASEDATA, *LPMAPSIMPLEBASEDATA;
protected:
	int					  m_nDataCount;
	LPMAPSIMPLEBASEDATA   *m_lpBaseData;
	CRITICAL_SECTION	  m_critMap;
public:
	CMapLongLong(void);
	virtual ~CMapLongLong(void);
public:
	int Initialize(int nMapSize);
	void Clear();
	int Set(long long llKey, long long llValue);
	long long Get(long long llKey);
};


//字符串型HASH类，适用于用一个32字节内字符串关联一个指针
class CMapString
{
	typedef struct stu_MapString_BaseData
	{
		char					 m_lpszDataID[32];		//数据ID
		LPVOID					 m_lpData;				//数据指针
		stu_MapString_BaseData * m_lpNext;				//下一个节点
	}MAPSTRINGBASEDATA, *LPMAPSTRINGBASEDATA;
protected:
	int					  m_nDataCount;
	LPMAPSTRINGBASEDATA * m_lpBaseData;
	CRITICAL_SECTION	  m_critMap;
	int	GetPos(const char * lpszDataID);
public:
	CMapString(void);
	virtual ~CMapString(void);
public:
	int Initialize(int nMapSize);
	void Clear();
	int Set(char * lpszDataID, LPVOID lpData);
	LPVOID Get(const char * lpszDataID);
	LPVOID Remove(const char * lpszDataID);
	LPVOID GetHeadPosition();
	void GetNext(LPVOID &nPos, char * &lpszDataID, LPVOID &lpData);
};

//数字排重类，适用于对一个64位数进行排重处理
class CMapDataID
{
	typedef struct stu_MapDataID_BaseData
	{
		__int64					 m_nDataID;				//数据ID
		stu_MapDataID_BaseData * m_lpNext;				//下一个节点
	}MAPDATAIDBASEDATA, *LPMAPDATAIDBASEDATA;
protected:
	__int64				  m_arDataID[16];
	int					  m_nDataCount;
	int					  m_nIndex;
	LPMAPDATAIDBASEDATA   m_lpBaseData;

	//保存数据到Hash数组上
	int SetData(__int64 nDataID);
public:
	CMapDataID(void);
	virtual ~CMapDataID(void);
public:
	void Clear();
	int  Set(__int64 nDataID, BOOL& bFind);
	BOOL Find(__int64 nDataID);
	LPVOID GetHeadPosition();
	void GetNext(LPVOID &nPos, __int64 &nDataID);
};

//DataID临时处理类，适用于HB树中
class CMapTemporaryDataID
{
protected:
	__int64		*		  m_lpDataID;
	int					  m_nDataCount;
public:
	CMapTemporaryDataID(void);
	virtual ~CMapTemporaryDataID(void);
public:
	void Set(__int64 nDataID);
	BOOL Check(__int64 nDataID);
};


class CMemStack
{
protected:
	LPBYTE	m_lpBuffer;					//栈缓存
	UINT	m_nBufferSize;				//栈缓存大小
	UINT	m_nElementSize;				//栈中元素的大小

	int		m_nElementNum;				//栈中元素个数
	LPBYTE	m_lpTopPtr;					//栈顶指针

	BOOL	m_bPointer;					//是否为指针
	BOOL    m_bAutoRelease;				//是否自动释放
public:
	CMemStack(void);
	~CMemStack(void);
public:
	//初始化
	void Initial(LPBYTE lpBuffer, UINT nBufferSize, UINT nElementSize , BOOL bPointer);

	//随机访问栈中元素
	void* GetElement(int nIndex);

	//获取栈中元素个数
	inline int GetSize()
	{
		return m_nElementNum;
	}

	//压栈
	int Push(void* pElement);

	//弹栈
	void* Pop();

	//获取栈顶指针
	void* Top();

	//清空
	inline void Clear()
	{
		m_nElementNum = 0;
		m_lpTopPtr	  = m_lpBuffer;
	}
};