﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "MapSimple.h"
#define MAX_DATAID_NUM 10000
class CDataIDContainer
{
protected:		
	BOOL				m_bUnique;
	UINT				m_nReocrdNum;

	UINT			    m_nDefaultSectionSize;
	USHORT				m_nCurrentBufferNo;
	LPBYTE				m_lpCurrentBuffer;

	CMapDataID			m_stMapDataID;
public:
	CDataIDContainer();
	~CDataIDContainer();

public:	
	//查找
	BOOL find(long long nDataID);

	//设置重复字段
	inline void SetUnique(BOOL bUnique)
	{
		m_bUnique = bUnique;
	}

	//弹出DataID
	virtual long long PopDataID() = 0;

	//清空DataID
	virtual void clear();
	
	//存入DataID
	virtual int push_back(long long nDataID) = 0;
	
	//DataID数量
	virtual UINT size() = 0;

	virtual void resize(UINT nDataIDNum) = 0;

	//移动到DataID的起始位置
	virtual void MoveFirst() = 0;

	//下一条DataID
	virtual int NextDataID(long long& nDataID) = 0;
};

//系统记录容器
class CServiceBson;
class CSysRecordContainer
{
protected:	
	UINT				m_nReocrdNum;
	UINT				m_nFirstRecordAddrID;
	LPSINGLERECORD		m_lpSingleRecord;

	CServiceBson*		m_pServiceBson;
	UINT			    m_nDefaultSectionSize;
	USHORT				m_nCurrentBufferNo;
	LPBYTE				m_lpCurrentBuffer;
public:
	CSysRecordContainer(CServiceBson* pBson);
	~CSysRecordContainer();

public:
	//存入DataID
	int AllocSingleRecord(LPSINGLERECORD& lpSingleRecord, int nFieldNum);

	//DataID数量
	inline UINT size()
	{
		return m_nReocrdNum;
	}

	//重分配大小
	inline void resize(UINT nReocrdNum)
	{
		m_nReocrdNum = nReocrdNum;
	}

	//移动到DataID的起始位置
	void MoveFirst();

	//下一条DataID
	int NextRecord(LPSINGLERECORD& lpSingleRecord);
};