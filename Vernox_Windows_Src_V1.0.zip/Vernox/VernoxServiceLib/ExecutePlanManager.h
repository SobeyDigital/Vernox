﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

//执行计划管理类，用于将客户端传递过来的执行计划BSON转换为具体的执行计划
class CExecutePlanManager
{
public:
	CExecutePlanManager(void);
	~CExecutePlanManager(void);

private:
	LPEXECUTEPLANBSON	m_lpExecutePlan;					//执行计划
	CServiceBson*		m_pServiceBson;						//Bson对象
	USHORT				m_nCurrentBufferNo;					//当前片段编号

	LPRECORDHEAD		m_lpRecord;							//记录指针
	LPEXECUTESTEP		m_lpStep;						    //步骤指针
	LPBYTE				m_lpCurrentBuffer;					//当前判断指针
	int					m_nCurrentRecordNo;					//当前记录编号
	int					m_nPageSize;						//页大小
private:
	BOOL CheckAuthority();
private:
	//判断兼容性函数
	BYTE GetCompatibleValueType(MF_VARDATA_TYPE bType);
	BYTE GetCompatibleFieldType(MF_SYS_FIELDTYPE bType);
	
	//获取表达式字段
	int GetExpField(LPOBJECTDEF lpObjectInfo, LPMATHEXPELEMENTBSON lpBsonExpField, BOOL bCondition, MF_SYS_FIELDTYPE& bFieldType);
	
	//获取表达式
	int GetExpression(LPOBJECTDEF lpObjectInfo, LPMATHEXPBSON lpMathExp, BOOL bCondition);
	
	//获取比较条件
	int GetCompareCondition(LPOBJECTDEF lpObjectInfo, LPCOMPAREEXPBSON lpCompareBson);
	
	//创建索引执行计划
	int CreateIndexPlan(LPOBJECTDEF lpObjectInfo, UINT& nIndexAddrID, UINT& nIndexNum);
private:
	//获取插入字段
	int GetInsertField(LPOBJECTDEF lpObjectInfo, LPINSERTEXECUTEPLANBSON lpInsertPlan);
	//获取查询字段
	int GetSelectField(LPOBJECTDEF lpObjectInfo, LPQUERYEXECUTEPLANBSON lpQueryPlan);
	//获取更新字段
	int GetUpdateField(LPOBJECTDEF lpObjectInfo, LPUPDATEEXECUTEPLANBSON lpUpdatePlan);
private:
	//获取where条件
	int GetCondition(LPOBJECTDEF lpObjectInfo, UINT nCondBsonOffset);
	int GetRecursionCondition(LPOBJECTDEF lpObjectInfo, UINT nCondBsonOffset);
	int GetDrection(LPOBJECTDEF lpObjectInfo, LPBASECONDITIONBSON lpCondition, LPRECURSION lpRecursionInfo);
private:
	int GetAlterSystemPlan(LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson);
	int GetAlterObjectPlan(LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson);
	int GetAlterUserPlan(LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson);
protected:
	int GetCommonQueryPlan();
protected:
	int GetCommonDeletePlan();
protected:
	int GetCommonUpdatePlan();
protected:
	int GetQueryPlan();
	int GetInsertPlan();
	int GetUpdatePlan();
	int GetDeletePlan();
	int GetAlterPlan();
	int GetCreatePlan();
	int GetUpdateRecordsetPlan();
public:	
	//初始化
	void Initial(LPEXECUTEPLANBSON lpExecutePlan, CServiceBson* pServiceBson);

	//获取执行计划
	int AnalysisExecutePlan();

	//移动到第一条记录
	int Move2FirstRecord();

	//下一条记录信息
	int NextRecord(UINT& nAddrID, LPRECORDHEAD& lpRecordHead);

	//移动到第一个步骤
	int Move2Step(int nStepNo = 0);

	//下一个步骤
	int NextStep(LPEXECUTESTEP& lpStep);

	//前一个步骤
	int PreStep(LPEXECUTESTEP& lpStep);

	//获取执行计划
	inline LPEXECUTEPLANBSON GetExecutePlan()
	{
		return m_lpExecutePlan;
	}

	//插入DataID
	int PushDataID(long long nDataID);

	//插入DataID
	int PushDataID2(long long nDataID);

	//获取数据ID数量
	inline int GetDataIDNum()
	{
		return m_lpExecutePlan->m_stSourceInfo.m_nRecordNum;
	}

	//获取页大小
	inline int GetPageSize()
	{
		if(m_nPageSize == 0)
		{
			return 10000;
		}
		else
		{
			return m_nPageSize;
		}
	}
};


