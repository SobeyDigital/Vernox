﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "UpdateBson.h"
CUpdateBson::CUpdateBson(CServiceBson* pBson)
{
	m_pBson				= pBson;
	m_lpObjectInfo		= NULL;
	m_lpBuffer			= NULL;
	m_nBufferSize		= 0;
	m_nDataSize			= 0;

}

CUpdateBson::~CUpdateBson(void)
{
}

/************************************************************************
		功能说明：
			从记录中获取字的长度
		参数说明：
			lpRecordBuffer：记录Buffer
			nBufferLen：记录Buffer长度
			bFieldNo：字段编号
			lpFieldBuffer：字段Buffer
			nFieldBufferLen：字段Buffer长度
************************************************************************/
int CUpdateBson::GetFieldBufferFromRecordBuffer(LPBYTE lpRecordBuffer, int nBufferLen, BYTE bFieldNo, LPBYTE& lpFieldBuffer, int& nFieldBufferLen)
{
	LPBYTE lpDataPtr;
	int nDataLen, nFieldDataOffset, nSectionEndOffset;
	BYTE bFieldType, bArrayLen, bTempFieldNo, bRecordSectionNo, bArrayType, bLen;

	nFieldBufferLen = 0;
	lpFieldBuffer	= NULL;
	//1.获取数据段映射表的长度
	bArrayLen   = *(BYTE*)lpRecordBuffer;

	//2.获取数据段映射表类型
	bArrayType  = *(BYTE*)(lpRecordBuffer + 1);

	//3.根据字段编号，获取当前字段应该属于哪一段数据
	bRecordSectionNo = (bFieldNo - 1) / MF_RECORDSECTION_FIELDNUM;
	if(bRecordSectionNo >= bArrayLen)
	{
		return MF_OK;
	}

	//4.获取数据片段的起始位置
	if(bArrayType == MF_RECORDSECTIONARRAY_BYTE)
	{
		BYTE* pFieldArray;
		pFieldArray = (BYTE*)(lpRecordBuffer + 2*sizeof(BYTE));

		nFieldDataOffset = pFieldArray[bRecordSectionNo];
		if(bRecordSectionNo + 1 >= bArrayLen)
		{
			nSectionEndOffset = nBufferLen;
		}	
		else
		{
			nSectionEndOffset = pFieldArray[bRecordSectionNo + 1];
		}
	}
	else if(bArrayType == MF_RECORDSECTIONARRAY_SHORT)
	{
		USHORT* pFieldArray;
		pFieldArray = (USHORT*)(lpRecordBuffer + 2*sizeof(BYTE));

		nFieldDataOffset = pFieldArray[bRecordSectionNo];
		if(bRecordSectionNo + 1 >= bArrayLen)
		{
			nSectionEndOffset = nBufferLen;
		}	
		else
		{
			nSectionEndOffset = pFieldArray[bRecordSectionNo + 1];
		}
	}
	else if(bArrayType == MF_RECORDSECTIONARRAY_INT)
	{
		int* pFieldArray;
		pFieldArray = (int*)(lpRecordBuffer + 2*sizeof(BYTE));

		nFieldDataOffset = pFieldArray[bRecordSectionNo];
		if(bRecordSectionNo + 1 >= bArrayLen)
		{
			nSectionEndOffset = nBufferLen;
		}	
		else
		{
			nSectionEndOffset = pFieldArray[bRecordSectionNo + 1];
		}
	}
	else
	{
		return MF_GETRECORD_INVALID_RECORDSECTIONARRAY;
	}

	if(nFieldDataOffset == nSectionEndOffset)
	{
		//空字段
		nFieldBufferLen = 0;
		lpFieldBuffer	= NULL;
		return MF_OK;
	}

	lpDataPtr = lpRecordBuffer + nFieldDataOffset;
	while(nFieldDataOffset < nSectionEndOffset)
	{
		lpFieldBuffer	 = lpDataPtr;
		bTempFieldNo	 = *(BYTE*)lpDataPtr;
		if(bTempFieldNo  == 0)
		{
			return MF_COMMON_INVALID_FIELDNO;
		}

		lpDataPtr		 += sizeof(BYTE);
		nFieldDataOffset += sizeof(BYTE);
		bFieldType		 = m_lpObjectInfo->m_lpField[bTempFieldNo - 1].m_bFieldType;

		if(bTempFieldNo > bFieldNo)
		{
			//空字段
			nFieldBufferLen = 0;
			lpFieldBuffer	= NULL;
			return MF_OK;
		}
		else if(bTempFieldNo == bFieldNo)
		{
			switch(bFieldType)
			{
			case MF_SYS_FIELDTYPE_INT:
				nFieldBufferLen = sizeof(BYTE) + sizeof(int);
				break;
			case MF_SYS_FIELDTYPE_BIGINT:
				nFieldBufferLen = sizeof(BYTE) + sizeof(long long);
				break;
			case MF_SYS_FIELDTYPE_DOUBLE:
			case MF_SYS_FIELDTYPE_DATE:
				nFieldBufferLen = sizeof(BYTE) + sizeof(double);
				break;
			case MF_SYS_FIELDTYPE_CHAR:
			case MF_SYS_FIELDTYPE_VARCHAR:
			case MF_SYS_FIELDTYPE_CLOB:
			case MF_SYS_FIELDTYPE_BLOB:
				//获取字段长度
				bLen = *(BYTE*)lpDataPtr;
				if(bLen != 255)
				{
					nDataLen  = bLen;
					nFieldBufferLen += sizeof(BYTE) + sizeof(BYTE) + nDataLen;
				}
				else
				{
					lpDataPtr += sizeof(BYTE);
					nDataLen  = *(int*)lpDataPtr;
					nFieldBufferLen += sizeof(BYTE) + sizeof(BYTE) + sizeof(int) + nDataLen;
				}
				break;
			}
			return MF_OK;
		}
		else
		{
			switch(bFieldType)
			{
			case MF_SYS_FIELDTYPE_INT:
				lpDataPtr			+= sizeof(int);
				nFieldDataOffset	+= sizeof(int);
				break;
			case MF_SYS_FIELDTYPE_BIGINT:
				lpDataPtr			+= sizeof(long long);
				nFieldDataOffset	+= sizeof(long long);
				break;
			case MF_SYS_FIELDTYPE_DOUBLE:
			case MF_SYS_FIELDTYPE_DATE:
				lpDataPtr			+= sizeof(double);
				nFieldDataOffset	+= sizeof(double);
				break;
			case MF_SYS_FIELDTYPE_CHAR:
			case MF_SYS_FIELDTYPE_VARCHAR:
			case MF_SYS_FIELDTYPE_CLOB:
			case MF_SYS_FIELDTYPE_BLOB:
				//获取字段长度
				bLen				= *(BYTE*)lpDataPtr;
				if(bLen != 255)
				{
					nDataLen		= bLen;
					lpDataPtr		+= sizeof(BYTE);
					nFieldDataOffset+= sizeof(BYTE);
				}
				else
				{
					lpDataPtr		+= sizeof(BYTE);
					nFieldDataOffset+= sizeof(BYTE);
					nDataLen		= *(int*)lpDataPtr;
					lpDataPtr		+= sizeof(int);
					nFieldDataOffset+= sizeof(int);
				}
				lpDataPtr			+= nDataLen;
				nFieldDataOffset	+= nDataLen;
				break;
			}
		}
	}
	nFieldBufferLen = 0;
	lpFieldBuffer	= NULL;
	return MF_OK;	
}

/************************************************************************
		功能说明：
			为记录分配空间
		参数说明：
			nBufferLen：分配空间长度
************************************************************************/
int CUpdateBson::AllocRecordBuffer(UINT nBufferLen)
{
	int nRet;
	if(m_lpBuffer == NULL || nBufferLen > m_nBufferSize)
	{
		m_nBufferSize = (nBufferLen / 32 + 1) * 32;
		nRet = m_pBson->AllocFromTempBuffer(m_nBufferSize, m_lpBuffer);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	m_nDataSize = 0;

	return MF_OK;
}

/************************************************************************
		功能说明：
			从BSON缓存中分配空间
		参数说明：
			nLen：空间大小
			nOffset：偏移
			lpAddr：地址指针
************************************************************************/
int CUpdateBson::AllocFromBsonBuffer(UINT nLen, UINT &nOffset, LPBYTE &lpAddr)
{
	int nNewDataLen, nOldDataLen;

	nNewDataLen = 0;						//分配后的数据长度
	nOldDataLen = 0;						//如果在分配的时候，发生因内存不足引起的Buffer重分配，
											//那么原始插入位置的指针(pInsertAddr)也就会发生变化，所以要记录插入位置的偏移，以便重新计算插入位置
	if(m_lpBuffer == NULL)
	{
		return MF_INNER_ALLOCMEM_FAILED;	
	}
	if(lpAddr == NULL)
	{
		nNewDataLen = m_nDataSize;		//在现有数据局末尾插入新数据
		nOldDataLen = nNewDataLen;
		if(nNewDataLen+nLen > m_nBufferSize)
		{	
			return MF_INNER_ALLOCMEM_FAILED;
		}
	}
	else
	{
		nNewDataLen = (int)(lpAddr - m_lpBuffer);	//在现有数据中间某处插入数据
		nOldDataLen = nNewDataLen;
		if(nNewDataLen+nLen > m_nBufferSize)
		{	
			return MF_INNER_ALLOCMEM_FAILED;
		}
	}

	nNewDataLen += nLen;
	if((UINT)nNewDataLen > m_nDataSize)
	{
		m_nDataSize = nNewDataLen;
	}
	nOffset = nOldDataLen;
	lpAddr  = m_lpBuffer + nOldDataLen;
	memset(lpAddr, 0, nLen);
	return MF_OK;
}

/************************************************************************
		功能说明：
			将字段值写入指定位置
		参数说明：
			pInsertAddr：指定的位置
			bFieldType：字段类型
			bFieldNo：字段编号
			varData：字段值
************************************************************************/
int CUpdateBson::WriteFieldData(MF_SYS_FIELDTYPE bFieldType, BYTE bFieldNo, VARDATA &varData, LPBYTE lpAddr)
{
	UINT nOffset;
	int nRet, nLen;
	switch(bFieldType)
	{
	case MF_SYS_FIELDTYPE_NULL:
		break;
	case MF_SYS_FIELDTYPE_INT:
		nLen = sizeof(BYTE) + sizeof(int);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((int*)lpAddr) = varData.GetCompatibleInt();
		break;
	case MF_SYS_FIELDTYPE_BIGINT:
		nLen = sizeof(BYTE) + sizeof(long long);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((long long*)lpAddr) = varData.GetCompatibleBigInt();
		break;
	case MF_SYS_FIELDTYPE_DATE:
	case MF_SYS_FIELDTYPE_DOUBLE:
		nLen = sizeof(BYTE) + sizeof(double);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((double*)lpAddr) = varData.GetCompatibleDouble();
		break;
	case MF_SYS_FIELDTYPE_CHAR:
	case MF_SYS_FIELDTYPE_VARCHAR:
	case MF_SYS_FIELDTYPE_CLOB:
	case MF_SYS_FIELDTYPE_BLOB:
		if(varData.m_nStrLen < 250)
		{
			nLen = sizeof(BYTE) + sizeof(BYTE) + varData.m_nStrLen;
			nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			*((BYTE*)lpAddr) = bFieldNo;
			lpAddr += sizeof(BYTE);
			*((BYTE*)lpAddr) = varData.m_nStrLen;
			lpAddr += sizeof(BYTE);
			memcpy(lpAddr, varData.m_lpszValue, varData.m_nStrLen);
		}
		else
		{
			nLen = sizeof(BYTE) + sizeof(BYTE) + sizeof(int) + varData.m_nStrLen;
			nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			*((BYTE*)lpAddr) = bFieldNo;
			lpAddr += sizeof(BYTE);
			*((BYTE*)lpAddr) = 255;
			lpAddr += sizeof(BYTE);
			*(int*)lpAddr = varData.m_nStrLen;
			lpAddr += sizeof(int);
			memcpy(lpAddr, varData.m_lpszValue, varData.m_nStrLen);
		}
		break;
	}
	return MF_OK;
}
/************************************************************************
		功能说明：
			插入字符串类型数据
		参数说明：
			pData：字符串数据
			nLen：字符串长度
************************************************************************/
BOOL CUpdateBson::AppendBuffer(void* pData, int nLen)
{
	int nOldLen;
	if(m_nDataSize + nLen <= m_nBufferSize)
	{
		nOldLen = m_nDataSize;				
		m_nDataSize += nLen;				

		memcpy(m_lpBuffer + nOldLen, pData, nLen);							
		return TRUE;
	}
	return FALSE;
}

void CUpdateBson::Initial(LPOBJECTDEF lpObjectInfo)
{
	m_lpObjectInfo = lpObjectInfo;
	m_stExpression.Initial(m_pBson, lpObjectInfo);
}

/************************************************************************
	功能说明：
		获取更新字段的长度
	参数说明：
		lpRecordInfo：原始记录信息
		lpExecuteField：执行字段
		nExecuteFieldNum：执行字段数
		nNewDataLen：更新后字符串长度
************************************************************************/
int CUpdateBson::GetBsonLen(LPRECORDDATAINFO lpRecordInfo, LPEXECUTEFIELDBSON lpExecuteField, int nExecuteFieldNum, int& nNewDataLen)
{
	LPBYTE lpFieldBuffer;
	LPMATHEXPBSON lpExpBson;
	VARDATA varData, varTemp;
	BYTE bFieldNo, bRecordSectionNum, bRecordSectionType;
	int i, nRet, nNewLen, nOldLen, nOldSectionArrayLen, nNewSectionArrayLen;

	nNewDataLen = lpRecordInfo->m_nRecordLen;	
	for(i = 0; i < nExecuteFieldNum; i++)
	{
		bFieldNo = lpExecuteField->m_bFieldNo;
		
		//获取原始字段长度
		nRet = GetFieldBufferFromRecordBuffer(lpRecordInfo->m_lpRecordBuffer, lpRecordInfo->m_nRecordLen, bFieldNo, lpFieldBuffer, nOldLen);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		//获取新字段的长度
		lpExpBson = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpExecuteField->m_nExpOffset);
		nRet = m_stExpression.GetExpressionResult(0, lpRecordInfo->m_lpRecordBuffer, lpRecordInfo->m_nRecordLen, lpExpBson,varTemp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = varTemp.GetCompatableValue(m_lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType, varData);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		nNewLen	= varData.m_nBufferLen;

		//定长字符串长度是否正确
		if(m_lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_CHAR)
		{
			if(varData.m_nStrLen > m_lpObjectInfo->m_lpField[bFieldNo - 1].m_bCharLen + 1)
			{
				return MF_COMMON_INVALID_STRINGLEN;
			}
		}

		//字段长度的增量
		nNewDataLen += nNewLen - nOldLen;
		if(lpExecuteField->m_nNextOffset != 0)
		{
			lpExecuteField = (LPEXECUTEFIELDBSON)m_pBson->ConvertOffset2Addr(lpExecuteField->m_nNextOffset);
		}
	}

	//字段的更新可能造成映射表长度的增减，所以还要计算映射表长度的增量
	//获取原始映射表长度
	bRecordSectionNum  = *(BYTE*)(lpRecordInfo->m_lpRecordBuffer);
	bRecordSectionType = *(BYTE*)(lpRecordInfo->m_lpRecordBuffer + 1);
	if(bRecordSectionType == MF_RECORDSECTIONARRAY_BYTE)
	{
		nOldSectionArrayLen = bRecordSectionNum*sizeof(BYTE);
	}
	else if(bRecordSectionType == MF_RECORDSECTIONARRAY_SHORT)
	{
		nOldSectionArrayLen = bRecordSectionNum*sizeof(USHORT);
	}
	else
	{
		nOldSectionArrayLen = bRecordSectionNum*sizeof(int);
	}
	
	//获取新映射表长度
	if(0 == m_lpObjectInfo->m_nFieldNum % MF_RECORDSECTION_FIELDNUM)
	{
		bRecordSectionNum = m_lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM; 
	}
	else
	{
		bRecordSectionNum = m_lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM + 1; 
	}
	if(nNewDataLen + bRecordSectionNum*sizeof(BYTE) < 250)
	{
		nNewSectionArrayLen = bRecordSectionNum*sizeof(BYTE);
	}
	else if(nNewDataLen + bRecordSectionNum*sizeof(USHORT) < 65530)
	{
		nNewSectionArrayLen = bRecordSectionNum*sizeof(USHORT);
	}
	else
	{
		nNewSectionArrayLen = bRecordSectionNum*sizeof(int);
	}

	nNewDataLen += nNewSectionArrayLen - nOldSectionArrayLen;
	return MF_OK;
}

//重载函数：用于UpdateRecordset
int CUpdateBson::GetBsonLen(LPRECORDDATAINFO lpRecordInfo, LPXMLFIELDBSON* lpFieldBsonMap, int& nNewDataLen)
{
	LPBYTE lpFieldBuffer;
	BYTE bFieldNo, bRecordSectionType, bRecordSectionNum;
	int i, nRet, nNewLen, nOldLen, nOldSectionArrayLen, nNewSectionArrayLen;;

	nNewDataLen = lpRecordInfo->m_nRecordLen;
	for(i = 0; i < m_lpObjectInfo->m_nFieldNum; i++)
	{
		if(lpFieldBsonMap[i] != NULL)
		{
			bFieldNo = lpFieldBsonMap[i]->m_bFieldNo;
			
			//获取原始字段长度
			nRet = GetFieldBufferFromRecordBuffer(lpRecordInfo->m_lpRecordBuffer, lpRecordInfo->m_nRecordLen, bFieldNo, lpFieldBuffer, nOldLen);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			//UPDATEREOCRDSET在预处理时已经对定长字符串字段值是否超长进行了判断，所以此处不用再判断
			//获取新字段长度
			nNewLen = lpFieldBsonMap[i]->m_nFieldDataLen;
			
			//获取增量
			nNewDataLen += nNewLen - nOldLen;
		}
	}

	//字段的更新可能造成映射表长度的增减，所以还要计算映射表长度的增量
	//获取原始映射表长度
	bRecordSectionNum  = *(BYTE*)(lpRecordInfo->m_lpRecordBuffer);
	bRecordSectionType = *(BYTE*)(lpRecordInfo->m_lpRecordBuffer + 1);
	if(bRecordSectionType == MF_RECORDSECTIONARRAY_BYTE)
	{
		nOldSectionArrayLen = bRecordSectionNum*sizeof(BYTE);
	}
	else if(bRecordSectionType == MF_RECORDSECTIONARRAY_SHORT)
	{
		nOldSectionArrayLen = bRecordSectionNum*sizeof(USHORT);
	}
	else
	{
		nOldSectionArrayLen = bRecordSectionNum*sizeof(int);
	}

	//获取新映射表长度
	if(0 == m_lpObjectInfo->m_nFieldNum % MF_RECORDSECTION_FIELDNUM)
	{
		bRecordSectionNum = m_lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM; 
	}
	else
	{
		bRecordSectionNum = m_lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM + 1; 
	}
	if(nNewDataLen + bRecordSectionNum*sizeof(BYTE) < 250)
	{
		nNewSectionArrayLen = bRecordSectionNum*sizeof(BYTE);
	}
	else if(nNewDataLen + bRecordSectionNum*sizeof(USHORT) < 65530)
	{
		nNewSectionArrayLen = bRecordSectionNum*sizeof(USHORT);
	}
	else
	{
		nNewSectionArrayLen = bRecordSectionNum*sizeof(int);
	}

	nNewDataLen += nNewSectionArrayLen - nOldSectionArrayLen;
	return MF_OK;
}

/************************************************************************
	功能说明：
		创建新的数据Buffer
	参数说明：
		nRecordLen：新记录长度
		lpFieldBsonMap：列映射表
		lpRecordInfo：原始记录信息
		lpParam：公共参数
************************************************************************/
int CUpdateBson::BuildBson(int nRecordLen, LPEXECUTEFIELDBSON* lpFieldBsonMap, LPRECORDDATAINFO lpRecordInfo, LPBASESTEPPARAM lpParam)
{
	BYTE bFieldNo;
	int nRet,i,nLen;
	VARDATA varData;
	void *arrFieldOffset;
	LPBYTE lpFieldBuffer;
	LPMATHEXPBSON lpExpBson;
	LPEXECUTEFIELDBSON lpExecuteField;
	BYTE bRecordSectionNum, bSectionArrayType;

	//1.为新数据分配一块内存Buffer
	nRet = AllocRecordBuffer(nRecordLen);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpParam->m_lpRecordBuffer = (long long)m_lpBuffer;

	//2.计算记录片段数量
	if(0 == m_lpObjectInfo->m_nFieldNum % MF_RECORDSECTION_FIELDNUM)
	{
		bRecordSectionNum = m_lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM; 
	}
	else
	{
		bRecordSectionNum = m_lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM + 1; 
	}
	*(BYTE*)(m_lpBuffer + m_nDataSize) = bRecordSectionNum;
	m_nDataSize	    += sizeof(BYTE);

	//3.创建记录片段映射表
	if(nRecordLen < 250)
	{
		bSectionArrayType = MF_RECORDSECTIONARRAY_BYTE;
		*(BYTE*)(m_lpBuffer	+ m_nDataSize) = bSectionArrayType;
		m_nDataSize	+= sizeof(BYTE);
		arrFieldOffset	= m_lpBuffer + m_nDataSize;
		m_nDataSize	+= bRecordSectionNum * sizeof(BYTE);
	}
	else if(nRecordLen < 65530)
	{
		bSectionArrayType = MF_RECORDSECTIONARRAY_SHORT;
		*(BYTE*)(m_lpBuffer	+ m_nDataSize) = bSectionArrayType;
		m_nDataSize	+= sizeof(BYTE);
		arrFieldOffset	= m_lpBuffer + m_nDataSize;
		m_nDataSize	+= bRecordSectionNum * sizeof(USHORT);
	}
	else
	{
		bSectionArrayType = MF_RECORDSECTIONARRAY_INT;
		*(BYTE*)(m_lpBuffer + m_nDataSize) = bSectionArrayType;
		m_nDataSize += sizeof(BYTE);
		arrFieldOffset	= m_lpBuffer + m_nDataSize;
		m_nDataSize	+= bRecordSectionNum * sizeof(int);
	}
	
	//4.进行更新操作
	if(lpParam->m_bRecordType == MF_RECORD_HBTREE)
	{
		//设置ChildDataID
		*(long long*)(m_lpBuffer + m_nDataSize) = *(long long*)(lpRecordInfo->m_lpRecordBuffer + m_nDataSize); 
		m_nDataSize += sizeof(long long);
		//设置BrotherDataID
		*(long long*)(m_lpBuffer + m_nDataSize) = *(long long*)(lpRecordInfo->m_lpRecordBuffer + m_nDataSize);
		m_nDataSize += sizeof(long long);
	}
	else if(lpParam->m_bRecordType == MF_RECORD_NODE)
	{
		LPNODEHEAD lpNodeHeadSrc, lpNodeHeadDest;
		lpNodeHeadSrc   = (LPNODEHEAD)(lpRecordInfo->m_lpRecordBuffer + m_nDataSize);
		lpNodeHeadDest  = (LPNODEHEAD)(m_lpBuffer + m_nDataSize);
		memcpy(lpNodeHeadDest, lpNodeHeadSrc, sizeof(NODEHEAD));
		
		m_nDataSize += sizeof(NODEHEAD);
	}
	else if(lpParam->m_bRecordType == MF_RECORD_RELATION)
	{
		LPRELATIONHEAD lpNodeHeadSrc, lpNodeHeadDest;
		lpNodeHeadSrc   = (LPRELATIONHEAD)(lpRecordInfo->m_lpRecordBuffer + m_nDataSize);
		lpNodeHeadDest  = (LPRELATIONHEAD)(m_lpBuffer + m_nDataSize);
		memcpy(lpNodeHeadDest, lpNodeHeadSrc, sizeof(RELATIONHEAD));

		m_nDataSize += sizeof(RELATIONHEAD);
	}

	for(i = 0; i < m_lpObjectInfo->m_nFieldNum; i++)
	{
		if(0 == i % MF_RECORDSECTION_FIELDNUM)
		{
			if(bSectionArrayType == MF_RECORDSECTIONARRAY_BYTE)
			{
				((BYTE*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else if(bSectionArrayType == MF_RECORDSECTIONARRAY_SHORT)
			{
				((USHORT*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else if(bSectionArrayType == MF_RECORDSECTIONARRAY_INT)
			{
				((int*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else
			{
				return MF_FAILED;
			}
		}

		if(lpFieldBsonMap[i] != NULL)
		{
			lpExecuteField	= lpFieldBsonMap[i];
			bFieldNo		= lpFieldBsonMap[i]->m_bFieldNo;
			lpExpBson		= (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpExecuteField->m_nExpOffset);
			//如果字段需要更新，则计算新的数据值，然后将数据写入到新数据Buffer中
			nRet = m_stExpression.GetExpressionResult(0, lpRecordInfo->m_lpRecordBuffer, lpRecordInfo->m_nRecordLen, lpExpBson,varData);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			if(varData.m_vt != MF_VARDATA_NULL)
			{
				nRet = WriteFieldData(m_lpObjectInfo->m_lpField[i].m_bFieldType, i+1, varData);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
		}
		else 
		{
			//如果字段不需要更新，则直接将原始Buffer拷贝到新数据Buffer中
			nRet = GetFieldBufferFromRecordBuffer(lpRecordInfo->m_lpRecordBuffer, lpRecordInfo->m_nRecordLen, i + 1, lpFieldBuffer, nLen);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			if(lpFieldBuffer != NULL)
			{
				if(!AppendBuffer(lpFieldBuffer, nLen))
				{
					return MF_INNER_ALLOCMEM_FAILED;
				}
			}
		}
	}
	return MF_OK;
}

int CUpdateBson::BuildBson(int nRecordLen, LPXMLFIELDBSON* lpFieldBsonMap, LPRECORDDATAINFO lpRecordInfo, LPBASESTEPPARAM lpParam)
{
	int nRet,i,nLen;
	void *arrFieldOffset;
	LPBYTE lpFieldBuffer;
	BYTE bRecordSectionNum, bSectionArrayType;

	//1.为新数据分配一块内存Buffer
	nRet = AllocRecordBuffer(nRecordLen);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpParam->m_lpRecordBuffer = (long long)m_lpBuffer;

	//2.计算记录片段数量
	if(0 == m_lpObjectInfo->m_nFieldNum % MF_RECORDSECTION_FIELDNUM)
	{
		bRecordSectionNum = m_lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM; 
	}
	else
	{
		bRecordSectionNum = m_lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM + 1; 
	}
	*(BYTE*)(m_lpBuffer + m_nDataSize) = bRecordSectionNum;
	m_nDataSize += sizeof(BYTE);

	//3.创建记录片段映射表
	if(nRecordLen < 250)
	{
		bSectionArrayType = MF_RECORDSECTIONARRAY_BYTE;
		*(BYTE*)(m_lpBuffer	+ m_nDataSize) = bSectionArrayType;
		m_nDataSize	+= sizeof(BYTE);
		arrFieldOffset	= m_lpBuffer + m_nDataSize;
		m_nDataSize	+= bRecordSectionNum * sizeof(BYTE);
	}
	else if(nRecordLen < 65530)
	{
		bSectionArrayType = MF_RECORDSECTIONARRAY_SHORT;
		*(BYTE*)(m_lpBuffer	+ m_nDataSize) = bSectionArrayType;
		m_nDataSize	+= sizeof(BYTE);
		arrFieldOffset	= m_lpBuffer + m_nDataSize;
		m_nDataSize	+= bRecordSectionNum * sizeof(USHORT);
	}
	else
	{
		bSectionArrayType = MF_RECORDSECTIONARRAY_INT;
		*(BYTE*)(m_lpBuffer + m_nDataSize) = bSectionArrayType;
		m_nDataSize += sizeof(BYTE);
		arrFieldOffset	= m_lpBuffer + m_nDataSize;
		m_nDataSize	+= bRecordSectionNum * sizeof(int);
	}

	//4.进行更新操作
	if(lpParam->m_bRecordType == MF_RECORD_HBTREE)
	{
		m_nDataSize += 2*sizeof(long long);
	}
	else if(lpParam->m_bRecordType == MF_RECORD_NODE)
	{
		m_nDataSize += sizeof(NODEHEAD);
	}
	else if(lpParam->m_bRecordType == MF_RECORD_RELATION)
	{
		m_nDataSize += sizeof(RELATIONHEAD);
	}

	for(i = 0; i < m_lpObjectInfo->m_nFieldNum; i++)
	{
		if(0 == i % MF_RECORDSECTION_FIELDNUM)
		{
			if(bSectionArrayType == MF_RECORDSECTIONARRAY_BYTE)
			{
				((BYTE*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else if(bSectionArrayType == MF_RECORDSECTIONARRAY_SHORT)
			{
				((USHORT*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else if(bSectionArrayType == MF_RECORDSECTIONARRAY_INT)
			{
				((int*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else
			{
				return MF_GETRECORD_INVALID_RECORDSECTIONARRAY;
			}
		}

		if(lpFieldBsonMap[i] != NULL)
		{
			if(lpFieldBsonMap[i]->m_nFieldDataOffset != 0)
			{
				lpFieldBuffer	= m_pBson->ConvertOffset2Addr(lpFieldBsonMap[i]->m_nFieldDataOffset);
				nLen			= lpFieldBsonMap[i]->m_nFieldDataLen;
				AppendBuffer(lpFieldBuffer, nLen);
			}
		}
		else 
		{
			//如果字段不需要更新，则直接将原始Buffer拷贝到新数据Buffer中
			nRet = GetFieldBufferFromRecordBuffer(lpRecordInfo->m_lpRecordBuffer, lpRecordInfo->m_nRecordLen, i + 1, lpFieldBuffer, nLen);
			if(nRet != MF_OK)
			{
				return nRet;
			} 

			if(lpFieldBuffer != NULL)
			{
				if(!AppendBuffer(lpFieldBuffer, nLen))
				{
					return MF_INNER_ALLOCMEM_FAILED;
				}
			}
		}
	}
	return MF_OK;
}
