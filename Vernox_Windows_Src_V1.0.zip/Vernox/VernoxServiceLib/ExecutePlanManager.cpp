﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "ExecutePlanManager.h"
#include "FunctionManager.h"
#include "Expression.h"
#include "MemoryFile.h"
#include "InsertBson.h"
#include "IndexSelector.h"

CExecutePlanManager::CExecutePlanManager(void)
{
	m_lpExecutePlan			= NULL;
	m_pServiceBson			= NULL;
	m_lpRecord				= NULL;
	m_lpStep				= NULL;
	m_nCurrentBufferNo		= 0;
	m_nCurrentRecordNo      = 0;
	m_lpCurrentBuffer		= 0;
	m_nPageSize				= 0;
}

CExecutePlanManager::~CExecutePlanManager(void)
{

}

/************************************************************************
	功能说明：
		判断权限
************************************************************************/
BOOL CExecutePlanManager::CheckAuthority()
{
	int nRet;
	LPUSERINFODEF lpUserInfo;
	MF_AUTHORITY_ID bAuthorityID;
	 
	if(m_lpExecutePlan->m_nType <= MF_EXECUTEPLAN_CMDTYPE_UPDATERECORDSET)
	{
		return TRUE;
	}

	nRet = CSystemManage::instance().GetUserInfo(m_lpExecutePlan->m_nUserID, lpUserInfo);
	if(nRet != MF_OK)
	{
		return FALSE;
	}
	if(lpUserInfo->m_bStatus == 0)
	{
		return FALSE;
	}
	else if(lpUserInfo->m_bAuthority[MF_AUTHORITY_DBA] == 1)
	{
		return TRUE;
	}
	else
	{
		if(m_lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_CREATE)
		{
			LPCREATEEXECUTEPLANBSON lpCreatePlan;
			lpCreatePlan = (LPCREATEEXECUTEPLANBSON)m_pServiceBson->ConvertOffset2Addr(m_lpExecutePlan->m_nCommandOffset);
			if(lpCreatePlan->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_OBJECT)
			{
				bAuthorityID = MF_AUTHORITY_CREATEOBJECT;
			}
			else if(lpCreatePlan->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_SEQUECNE)
			{
				bAuthorityID = MF_AUTHORITY_CREATESEQUENCE;
			}
			else
			{
				return FALSE;
			}

		}
		else if(m_lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_DROP)
		{
			LPDROPEXECUTEPLANBSON lpDropPlan;
			lpDropPlan = (LPDROPEXECUTEPLANBSON)m_pServiceBson->ConvertOffset2Addr(m_lpExecutePlan->m_nCommandOffset);
			if(lpDropPlan->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_OBJECT)
			{
				bAuthorityID = MF_AUTHORITY_DROPOBJECT;
			}
			else if(lpDropPlan->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_SEQUECNE)
			{
				bAuthorityID = MF_AUTHORITY_DROPSEQUENCE;
			}
			else
			{
				return FALSE;
			}
		}
		else if(m_lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_ALTER)
		{
			LPALTEREXECUTEPLANBSON lpAlterPlan;
			lpAlterPlan = (LPALTEREXECUTEPLANBSON)m_pServiceBson->ConvertOffset2Addr(m_lpExecutePlan->m_nCommandOffset);
			if(lpAlterPlan->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_OBJECT)
			{
				bAuthorityID = MF_AUTHORITY_ALTEROBJECT;
			}
			else if(lpAlterPlan->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_SEQUECNE)
			{
				bAuthorityID = MF_AUTHORITY_ALTERSYSTEM;
			}
			else
			{
				return FALSE;
			}
		}

		if(lpUserInfo->m_bAuthority[bAuthorityID] == 1)
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
	return TRUE;
}

/************************************************************************
	功能说明：
		获取数据的兼容性类型
	参数说明：
		bType：数据类型
************************************************************************/
BYTE CExecutePlanManager::GetCompatibleValueType(MF_VARDATA_TYPE bType)
{
	switch(bType)
	{
	case MF_VARDATA_INT:
	case MF_VARDATA_INT64:
	case MF_VARDATA_DOUBLE:
	case MF_VARDATA_DATE:
		return MF_COMPATIBLE_DATA_NUMBER;
	case MF_VARDATA_STRING:
		return MF_COMPATIBLE_DATA_STRING;
	case MF_VARDATA_BINARY:
		return MF_COMPATIBLE_DATA_BINARY;
	case MF_VARDATA_BYTE:
		return MF_COMPATIBLE_DATA_BYTE;
	default:
		return MF_COMPATIBLE_DATA_UNKNOWN;
	}
}

BYTE CExecutePlanManager::GetCompatibleFieldType(MF_SYS_FIELDTYPE bType)
{
	switch(bType)
	{
	case MF_SYS_FIELDTYPE_INT:                            
	case MF_SYS_FIELDTYPE_BIGINT:                         
	case MF_SYS_FIELDTYPE_DOUBLE:
	case MF_SYS_FIELDTYPE_DATE:
		return MF_COMPATIBLE_DATA_NUMBER;
	case MF_SYS_FIELDTYPE_CHAR:                           
	case MF_SYS_FIELDTYPE_VARCHAR:                        
	case MF_SYS_FIELDTYPE_CLOB:
		return MF_COMPATIBLE_DATA_STRING;
	case MF_SYS_FIELDTYPE_BLOB:
		return MF_COMPATIBLE_DATA_BINARY;
	default:
		return MF_COMPATIBLE_DATA_UNKNOWN;
	}
}

/************************************************************************
	功能说明：
		获取表达式字段
	参数说明：
		stBson：BSON对象
		lpBsonExpField：BSON表达式字段
		bCondition：是否是在查询条件中进行解析
		bFieldType：字段类型
************************************************************************/
int CExecutePlanManager::GetExpField(LPOBJECTDEF lpObjectInfo, LPMATHEXPELEMENTBSON lpBsonExpField, BOOL bCondition, MF_SYS_FIELDTYPE& bFieldType)
{
	BYTE bFieldNo;
	LPVOID lpValue;
	string pFieldName;

	bFieldNo = 0;
	if(lpBsonExpField->m_bField)
	{	
		pFieldName = (char*)lpBsonExpField->m_bDataBuffer; 
		if(pFieldName[0] != 0)
		{
			//pFieldName[0] = 0说明是COUNT(*)情况
			lpValue = lpObjectInfo->m_mapName2FieldNo.Get(pFieldName.c_str());
			if(lpValue == NULL)
			{
				if(strcmp(pFieldName.c_str(), "ROWID") == 0)
				{
					lpBsonExpField->m_bFieldNo = 255;
					bFieldType = MF_SYS_FIELDTYPE_BIGINT;
					lpBsonExpField->m_bDataType = MF_SYS_FIELDTYPE_BIGINT;
				}
				else if(bCondition)
				{
					if(strcmp(pFieldName.c_str(), "ROWNUM") == 0)
					{
						bFieldType = MF_SYS_FIELDTYPE_ROWNUM;
						lpBsonExpField->m_bDataType = MF_SYS_FIELDTYPE_ROWNUM;
					}
					else
					{		
						return MF_PARSESELECT_INVALID_FIELD_ERROR;
					}
				}
				else
				{
					return MF_PARSESELECT_INVALID_FIELD_ERROR;
				}
			}
			else
			{
				bFieldNo = (BYTE)reinterpret_cast<long long>(lpValue);
				lpBsonExpField->m_bFieldNo = bFieldNo;
				bFieldType = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;
			}
		}
	}
	else
	{
		bFieldType = lpBsonExpField->m_bDataType;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取表达式
	参数说明：
		lpObjectInfo：Object信息
		lpMathExp：BSON表达式
		bCondition：是否是条件表达式
************************************************************************/
int CExecutePlanManager::GetExpression(LPOBJECTDEF lpObjectInfo, LPMATHEXPBSON lpMathExp, BOOL bCondition)
{
	int nRet;
	MF_SYS_FIELDTYPE bType1, bType2;
	LPMATHEXPBSON lpBsonExp1, lpBsonExp2;
	LPMATHEXPELEMENTBSON lpExpFieldBson1, lpExpFieldBson2;

	bType1 = 0;
	bType2 = 0;
	if(lpMathExp->m_bExpressionType1 == 1)
	{
		lpBsonExp1 = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);

		nRet = GetExpression(lpObjectInfo, lpBsonExp1, bCondition);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		bType1 = lpBsonExp1->m_bValType;
	}
	else if(lpMathExp->m_bExpressionType1 == 0)
	{
		lpExpFieldBson1	= (LPMATHEXPELEMENTBSON)m_pServiceBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);
		nRet = GetExpField(lpObjectInfo, lpExpFieldBson1, bCondition, bType1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	if(lpMathExp->m_bExpressionType2 == 1)
	{
		lpBsonExp2 = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);

		nRet = GetExpression(lpObjectInfo, lpBsonExp2, bCondition);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		//获得表达式数据类型
		bType2 = lpBsonExp2->m_bValType;
	}
	else if(lpMathExp->m_bExpressionType2 == 0)
	{
		lpExpFieldBson2	= (LPMATHEXPELEMENTBSON)m_pServiceBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);
		nRet = GetExpField(lpObjectInfo, lpExpFieldBson2, bCondition, bType2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	
	if(bType1 == MF_SYS_FIELDTYPE_ROWNUM || bType1 == MF_SYS_FIELDTYPE_ROWNUM)
	{
		if(0 != lpMathExp->m_bOperator)
		{
			//错误：ROWNUM不支持四则运算
			return MF_PARSESELECT_INVALID_COMPATIBLETYPE_ERROR;
		}
		lpMathExp->m_bValType = MF_SYS_FIELDTYPE_ROWNUM;
		return MF_OK;
	}

	//判断表达式返回值类型、类型兼容
	if(0 != lpMathExp->m_bOperator && MF_EXECUTEPLAN_OPERATOR_SIGNMINUS != lpMathExp->m_bOperator)
	{
		//如果m_bOperator为0，说明表达式不是一个四则运算表达式，则不判断兼容性
		if(bType1 == MF_SYS_FIELDTYPE_NULL || bType2 == MF_SYS_FIELDTYPE_NULL)
		{
			//NULL类型不用判断兼容性
			lpMathExp->m_bValType = MF_SYS_FIELDTYPE_NULL;
			return MF_OK;
		}
		else if(40 <= lpMathExp->m_bOperator && 70 >= lpMathExp->m_bOperator)
		{
			//1.函数类型,不判断兼容性
			nRet = CFunctionManager::GetFunRetValType(lpMathExp->m_bOperator, lpMathExp->m_bValType);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			return MF_OK;
		}
		else if(bType1 == MF_SYS_FIELDTYPE_DATE && bType2 == MF_SYS_FIELDTYPE_DATE)
		{
			//2.两个Date类型只能相减，结果是Double类型
			if(lpMathExp->m_bOperator != MF_EXECUTEPLAN_OPERATOR_MINUS)
			{
				return MF_PARSECMD_INVALID_DATACOMPATIBLE_ERROR;
			}
			lpMathExp->m_bValType = MF_SYS_FIELDTYPE_DOUBLE;
			return MF_OK;
		}
		else if(bType1 == MF_SYS_FIELDTYPE_DATE || bType2 == MF_SYS_FIELDTYPE_DATE)
		{
			//3.包含一个Date类型只能做加、减、字符串连接
			if(lpMathExp->m_bOperator != MF_EXECUTEPLAN_OPERATOR_MINUS && lpMathExp->m_bOperator != MF_EXECUTEPLAN_OPERATOR_PLUS && lpMathExp->m_bOperator != MF_EXECUTEPLAN_OPERATOR_LINK)
			{
				return MF_PARSECMD_INVALID_DATACOMPATIBLE_ERROR;
			}
		}
		else if(MF_EXECUTEPLAN_OPERATOR_LINK != lpMathExp->m_bOperator && 0 != lpMathExp->m_bOperator)
		{
			//4.连接运算符会自动将运算符两边转换为字符串，所以不存在兼容性问题
			if(GetCompatibleFieldType(bType1) != GetCompatibleFieldType(bType2))
			{
				return MF_PARSESELECT_INVALID_COMPATIBLETYPE_ERROR;
			}
		}
	}
	else
	{
		//如果m_bOperator为0，则有且只有一个表达式无效
		if((lpMathExp->m_bExpressionType1 == 3 && lpMathExp->m_bExpressionType2 == 3) || (lpMathExp->m_bExpressionType1 != 3 && lpMathExp->m_bExpressionType2 != 3))
		{
			return MF_FAILED;
		}
	}
	//除法运算需要将结果转换成Double类型(注意：这里不是按照C++的规则，如：1/2结果为0.5而不是0)
	if(MF_EXECUTEPLAN_OPERATOR_DIVIDE == lpMathExp->m_bOperator)
	{
		lpMathExp->m_bValType = MF_SYS_FIELDTYPE_DOUBLE;
	}
	else
	{
		lpMathExp->m_bValType = bType1 > bType2 ? bType1 : bType2;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取条件字段
	参数说明：
		lpObjectInfo：Object信息
		lpCompareBson：BSON条件字段
************************************************************************/
int CExecutePlanManager::GetCompareCondition(LPOBJECTDEF lpObjectInfo, LPCOMPAREEXPBSON lpCompareBson)
{
	int nRet;
	LPMATHEXPBSON lpMathExp;

	if(lpCompareBson->m_bOperator == MF_EXECUTEPLAN_OPERATOR_IN || lpCompareBson->m_bOperator == MF_EXECUTEPLAN_OPERATOR_NOTIN)
	{
		LPINCONDITIONBSON lpInCondition;
		if(lpCompareBson->m_nMathExpOffset1 != 0)
		{
			lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompareBson->m_nMathExpOffset1);
			nRet = GetExpression(lpObjectInfo, lpMathExp, TRUE);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else
		{
			return MF_COMMON_INVALID_COMPARECONDITION;
		}

		if(lpCompareBson->m_nMathExpOffset2 != 0)
		{
			lpInCondition = (LPINCONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(lpCompareBson->m_nMathExpOffset2);
		}
		else
		{
			return MF_COMMON_INVALID_COMPARECONDITION;
		}
		//判断表达式类型和IN后面括号中的数据类型是否兼容
		if(GetCompatibleFieldType(lpInCondition->m_bDataType) != GetCompatibleFieldType(lpMathExp->m_bValType))
		{
			return MF_COMMON_INVALID_DATATYPE;
		}	
		return MF_OK;
	}

	if(lpCompareBson->m_nMathExpOffset1 != 0)
	{
		lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompareBson->m_nMathExpOffset1);
		nRet = GetExpression(lpObjectInfo, lpMathExp, TRUE);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		
		if(lpMathExp->m_bValType == MF_SYS_FIELDTYPE_ROWNUM)
		{
			lpCompareBson->m_bRowNum = 1;
			//表达式1为MF_SYS_FIELDTYPE_ROWNUM，则逻辑运算符为小于或小于等于
			if(lpCompareBson->m_nMathExpOffset2)
			{
				//直接计算表达式2的值，作为页大小
				VARDATA varData;
				CExpression stExpression;
				stExpression.Initial(m_pServiceBson, m_pServiceBson->GetObjectInfo());

				lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompareBson->m_nMathExpOffset2);
				nRet = GetExpression(lpObjectInfo, lpMathExp, TRUE);
				if(nRet != MF_OK)
				{
					return nRet;
				}

				nRet = stExpression.GetExpressionResult(lpMathExp, varData);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				else
				{
					if(lpCompareBson->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESS)
					{
						m_nPageSize = varData.m_nValue - 1;
					}
					else if(lpCompareBson->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESSEQUAL)
					{
						m_nPageSize = varData.m_nValue;
					}
					else
					{
						return MF_PARSESELECT_INVALID_ROWNUMEXPRESSION_ERROR;
					}
					return MF_OK;
				}
			}
			else 
			{
				return MF_PARSESELECT_INVALID_ROWNUMEXPRESSION_ERROR;
			}
		}
	}
	if(lpCompareBson->m_nMathExpOffset2 != 0)
	{	
		lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompareBson->m_nMathExpOffset2);
		nRet = GetExpression(lpObjectInfo, lpMathExp, TRUE);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(lpMathExp->m_bValType == MF_SYS_FIELDTYPE_ROWNUM)
		{
			lpCompareBson->m_bRowNum = 1;
			//表达式2为MF_SYS_FIELDTYPE_ROWNUM，则逻辑运算符为大于或大于等于
			if(lpCompareBson->m_nMathExpOffset1)
			{
				//直接计算表达式2的值，作为页大小
				VARDATA varData;
				CExpression stExpression;
				stExpression.Initial(m_pServiceBson, m_pServiceBson->GetObjectInfo());

				lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompareBson->m_nMathExpOffset2);
				nRet = stExpression.GetExpressionResult(lpMathExp, varData);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				else
				{
					if(lpCompareBson->m_bOperator == MF_EXECUTEPLAN_OPERATOR_GREATER)
					{
						m_nPageSize = varData.m_nValue - 1;
					}
					else if(lpCompareBson->m_bOperator == MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL)
					{
						m_nPageSize = varData.m_nValue;
					}
					else
					{
						return MF_PARSESELECT_INVALID_ROWNUMEXPRESSION_ERROR;
					}
					return MF_OK;
				}	
			}
			else 
			{
				return MF_PARSESELECT_INVALID_ROWNUMEXPRESSION_ERROR;
			}
		}
	}
	if(lpCompareBson->m_nMathExpOffset3 != 0)
	{
		lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompareBson->m_nMathExpOffset3);
		nRet = GetExpression(lpObjectInfo, lpMathExp, TRUE);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		创建索引执行计划
	参数说明：
		lpObjectInfo：对象信息
		nIndexOffset：索引偏移
		nIndexNum：索引数量
************************************************************************/
int CExecutePlanManager::CreateIndexPlan(LPOBJECTDEF lpObjectInfo, UINT& nIndexOffset, UINT& nIndexNum)
{
	int nRet;
	UINT nOffset;
	LPINDEXDEF lpIndex;
	LPINDEXEXECUTEPLAN lpIndexPlan, lpPreIndexPlan;

	nIndexOffset = 0;
	nIndexNum    = 0;
	for(lpIndex  = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext) 
	{
		nRet = m_pServiceBson->AllocFromBsonBuffer(lpIndexPlan, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(nIndexOffset  == 0)
		{
			nIndexOffset = nOffset;
		}
		else
		{
			lpPreIndexPlan->m_nNextOffset = nOffset;
		}
		lpPreIndexPlan = lpIndexPlan;

		lpIndexPlan->m_bFieldNo[0]		= lpIndex->m_bFieldNo[0];
		lpIndexPlan->m_bFieldNo[1]		= lpIndex->m_bFieldNo[1];
		lpIndexPlan->m_bFieldNo[2]		= lpIndex->m_bFieldNo[2];
		lpIndexPlan->m_bFieldNo[3]		= lpIndex->m_bFieldNo[3];
		lpIndexPlan->m_bFileNo			= lpIndex->m_bFileNo;
		lpIndexPlan->m_bIndexType		= lpIndex->m_bIndexType;
		lpIndexPlan->m_nIndexID			= lpIndex->m_nIndexID;
		lpIndexPlan->m_bConstraintType	= lpIndex->m_bConstraintType;
		nIndexNum++;
	} 
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取插入字段
	参数说明：
		lpObjectInfo：对象信息
		lpInsertPlan：插入执行计划
************************************************************************/
int CExecutePlanManager::GetInsertField(LPOBJECTDEF lpObjectInfo, LPINSERTEXECUTEPLANBSON lpInsertPlan)
{
	BYTE bFieldNo;
	LPVOID lpValue;
	string strFieldName;
	int i, nRet, nFieldNum;
	LPMATHEXPBSON lpMathExp;
	LPEXECUTEFIELDBSON lpBsonField;
	MF_SYS_FIELDTYPE bFieldType, bValueType;
	
	lpBsonField = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpInsertPlan->m_nExcuteFieldOffset); 
	nFieldNum = lpInsertPlan->m_nExecuteFieldNum;
	for(i = 0; i < nFieldNum; i++)
	{
		//校验字段名
		strFieldName =  (char*)m_pServiceBson->ConvertOffset2Addr(lpBsonField->m_nExpNameOffset);
		lpValue = lpObjectInfo->m_mapName2FieldNo.Get(strFieldName.c_str());
		if(lpValue == NULL)
		{
			return MF_PARSESELECT_INVALID_FIELD_ERROR;
		}
		else
		{
			bFieldNo = (BYTE)reinterpret_cast<long long>(lpValue);
		}
		
		lpBsonField->m_bFieldNo = bFieldNo;
		lpBsonField->m_bAllowNull = lpObjectInfo->m_lpField[bFieldNo - 1].m_bAllowNull;
		
		//解析表达式
		lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpBsonField->m_nExpOffset);
		nRet = GetExpression(lpObjectInfo, lpMathExp, FALSE);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		//判断表达式值类型与列类型是否兼容
		bFieldType = lpObjectInfo->m_lpField[bFieldNo-1].m_bFieldType;
		bValueType = lpMathExp->m_bValType;
		if(bValueType != MF_SYS_FIELDTYPE_NULL && GetCompatibleFieldType(bFieldType) != GetCompatibleValueType(bValueType))
		{
			return MF_PARSEISNERT_INVALID_COMPATIBLETYPE_ERROR;
		}

		if(0 != lpBsonField->m_nNextOffset)
		{
			lpBsonField = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpBsonField->m_nNextOffset);
		}
	}
	return MF_OK;
}
/************************************************************************
	功能说明：
		获取查询字段
	参数说明：
		lpObjectInfo：对象信息
		lpQueryPlan：BSON查询计划
************************************************************************/
int CExecutePlanManager::GetSelectField(LPOBJECTDEF lpObjectInfo, LPQUERYEXECUTEPLANBSON lpQueryPlan)
{
	int i, nRet;
	if(0 == lpQueryPlan->m_nExcuteFieldOffset)
	{
		LPBYTE lpAddr;
		UINT nOffset, nPreOffset;
		LPMATHEXPBSON lpExpBson;
		LPMATHEXPELEMENTBSON lpExpFieldBson;
		LPEXECUTEFIELDBSON lpFieldBson, lpPreFieldBson;
		//SELECT * 情况
		nPreOffset = 0;
		lpQueryPlan->m_nExcuteFieldNum = lpObjectInfo->m_nFieldNum;
		for(i = 0; i < lpObjectInfo->m_nFieldNum; i++)
		{
			if(lpObjectInfo->m_lpField[i].m_bObjectFieldNo == 0)
			{
				//字段被删除
				lpQueryPlan->m_nExcuteFieldNum--;
				continue;
			}

			nRet = m_pServiceBson->AllocFromBsonBuffer(lpFieldBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(nPreOffset != 0)
			{
				lpPreFieldBson = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(nPreOffset);
				lpPreFieldBson->m_nNextOffset = nOffset;
			}
			else
			{
				lpQueryPlan->m_nExcuteFieldOffset = nOffset;
			}
			nPreOffset = nOffset;
			
			lpFieldBson->m_bFieldNo = lpObjectInfo->m_lpField[i].m_bObjectFieldNo;
			lpFieldBson->m_bExpressionType = MF_EXPRESSION_FIELD;
			nRet = m_pServiceBson->AllocFromBsonBuffer(lpExpBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpFieldBson->m_nExpOffset = nOffset;
			lpExpBson->m_bValType	  =  lpObjectInfo->m_lpField[i].m_bFieldType;
			lpExpBson->m_bExpressionType1 = 0;
			nRet = m_pServiceBson->AllocFromBsonBuffer(lpExpFieldBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpExpBson->m_nExpOffset1   = nOffset;
			lpExpFieldBson->m_bField   = 1;
			lpExpFieldBson->m_bFieldNo = lpObjectInfo->m_lpField[i].m_bObjectFieldNo;
			
			lpExpBson->m_bExpressionType2 = 3;
			lpExpBson->m_nExpOffset2 = 0;
			
			//分配32个字节的Buffer存放列名
			lpAddr = NULL; 
			nRet = m_pServiceBson->AllocFromBsonBuffer(32, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpFieldBson->m_nExpNameOffset = nOffset;
			memcpy(lpAddr, lpObjectInfo->m_lpField[i].m_lpszName, 32);			
		}
	}
	else
	{
		BYTE bFieldNo;
		UINT nOffset,nFieldNum;
		LPMATHEXPBSON lpExpBson;
		LPEXECUTEFIELDBSON lpFieldBson;
		LPMATHEXPELEMENTBSON lpExpFieldBson;

		nOffset   = lpQueryPlan->m_nExcuteFieldOffset;
		nFieldNum = lpQueryPlan->m_nExcuteFieldNum;
		for(i = 0; i < (int)nFieldNum; i++)
		{
			//解析表达式
			lpFieldBson = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(nOffset);
			lpExpBson = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpFieldBson->m_nExpOffset);
			nRet = GetExpression(lpObjectInfo, lpExpBson, FALSE);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(MF_EXPRESSION_FIELD == lpFieldBson->m_bExpressionType)
			{
				lpExpFieldBson = (LPMATHEXPELEMENTBSON)m_pServiceBson->ConvertOffset2Addr(lpExpBson->m_nExpOffset1); 
				bFieldNo = lpExpFieldBson->m_bFieldNo;
				lpFieldBson->m_bFieldNo = bFieldNo;
				lpFieldBson->m_bAllowNull = lpObjectInfo->m_lpField[bFieldNo - 1].m_bAllowNull;
			}
			if(0 != lpFieldBson->m_nNextOffset)
			{
				nOffset = lpFieldBson->m_nNextOffset;
			}
		}
	}
	return MF_OK;
}
/************************************************************************
	功能说明：
		获取更新字段
	参数说明：
		lpObjectInfo：对象信息
		lpUpdatePlan：BSON更新计划
************************************************************************/
int CExecutePlanManager::GetUpdateField(LPOBJECTDEF lpObjectInfo, LPUPDATEEXECUTEPLANBSON lpUpdatePlan)
{
	BYTE bFieldNo;
	LPVOID lpValue;
	string strFieldName;
	int nRet, nFieldNum, i;
	LPMATHEXPBSON lpMathExp;
	LPEXECUTEFIELDBSON lpBsonField;
	MF_SYS_FIELDTYPE bFieldType,bValueType;
	
	bFieldType = 0;
	bValueType = 0;
	nFieldNum = lpUpdatePlan->m_nExecuteFieldNum;
	lpBsonField = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpUpdatePlan->m_nExcuteFieldOffset);
	for(i = 0; i < nFieldNum; i++)
	{
		//校验字段名
		strFieldName =  (char*)m_pServiceBson->ConvertOffset2Addr(lpBsonField->m_nExpNameOffset);
		lpValue = lpObjectInfo->m_mapName2FieldNo.Get(strFieldName.c_str());
		if(lpValue == NULL)
		{
			return MF_PARSESELECT_INVALID_FIELD_ERROR;
		}
		else
		{
			bFieldNo = (BYTE)reinterpret_cast<long long>(lpValue);
		}
		lpBsonField->m_bAllowNull = lpObjectInfo->m_lpField[bFieldNo - 1].m_bAllowNull;
		lpBsonField->m_bFieldNo = bFieldNo;

		//解析表达式
		lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpBsonField->m_nExpOffset);
		nRet = GetExpression(lpObjectInfo, lpMathExp, FALSE);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		//判断表达式值类型与列类型是否兼容
		bFieldType = lpObjectInfo->m_lpField[bFieldNo-1].m_bFieldType;
		bValueType = lpMathExp->m_bValType;
		if(bValueType != MF_SYS_FIELDTYPE_NULL && GetCompatibleFieldType(bFieldType) != GetCompatibleValueType(bValueType))
		{
			return MF_PARSEISNERT_INVALID_COMPATIBLETYPE_ERROR;
		}
		
		//创建索引计划
		nRet = CreateIndexPlan(lpObjectInfo, lpUpdatePlan->m_nUpdateIndexOffset, lpUpdatePlan->m_nIndexNum);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	
		if(0 != lpBsonField->m_nNextOffset)
		{
			lpBsonField = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpBsonField->m_nNextOffset);
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取查询字段
	参数说明：
		lpObjectInfo：对象信息
		nCondBsonOffset：where条件偏移
************************************************************************/
int CExecutePlanManager::GetCondition(LPOBJECTDEF lpObjectInfo, UINT nCondBsonOffset)
{
	int nRet;
	LPBASECONDITIONBSON lpConditionBson;
	LPCOMPAREEXPBSON lpCompareBson1, lpCompareBson2;

	if(0 == (int)nCondBsonOffset || -1 == (int)nCondBsonOffset)
	{
		//没有查询条件，或查询条件恒为假
		return MF_OK;
	}
	else
	{
		lpConditionBson = (LPBASECONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(nCondBsonOffset);
	}
	
	if(MF_CONDITION_LOGIC == lpConditionBson->m_bConditionType1)
	{
		nRet = GetCondition(lpObjectInfo, lpConditionBson->m_nConditionOffset1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}	
	else if(MF_CONDITION_COMPARE == lpConditionBson->m_bConditionType1)
	{
		lpCompareBson1 = (LPCOMPAREEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpConditionBson->m_nConditionOffset1);
		nRet = GetCompareCondition(lpObjectInfo, lpCompareBson1);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(lpCompareBson1->m_bRowNum)
		{
			lpConditionBson->m_bConditionType1   = MF_CONDITION_ROWNUM;
			lpConditionBson->m_nConditionOffset1 = 0;
		}
	}

	if(MF_CONDITION_LOGIC == lpConditionBson->m_bConditionType2)
	{
		nRet = GetCondition(lpObjectInfo, lpConditionBson->m_nConditionOffset2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}	
	else if(MF_CONDITION_COMPARE == lpConditionBson->m_bConditionType2)
	{
		lpCompareBson2 = (LPCOMPAREEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpConditionBson->m_nConditionOffset2);
		nRet = GetCompareCondition(lpObjectInfo, lpCompareBson2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpCompareBson2->m_bRowNum)
		{
			lpConditionBson->m_bConditionType2   = MF_CONDITION_ROWNUM;
			lpConditionBson->m_nConditionOffset2 = 0;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取递归条件
	参数说明：
		lpObjectInfo:对象信息
		nCondBsonOffset：条件偏移
************************************************************************/
int CExecutePlanManager::GetRecursionCondition(LPOBJECTDEF lpObjectInfo, UINT nCondBsonOffset)
{
	int nRet;
	BOOL bHBTree;
	LPINDEXDEF lpIndex;
	LPSTARTINFO lpStartInfo;
	LPRECURSION lpRecursionInfo;
	LPBASECONDITIONBSON lpCondition;
	CIndexSelector stIndexSelector(m_pServiceBson);

	lpRecursionInfo = (LPRECURSION)m_pServiceBson->ConvertOffset2Addr(nCondBsonOffset);
	lpStartInfo		= (LPSTARTINFO)m_pServiceBson->ConvertOffset2Addr(lpRecursionInfo->m_nStartCondOffset);
	
	//获取开始条件
	if(lpStartInfo->m_nWhereOffset != 0)
	{	
		nRet = GetCondition(lpObjectInfo, lpStartInfo->m_nWhereOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//获取递归方向
	bHBTree = FALSE;
	for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
	{
		if(lpIndex->m_bIndexType == MF_SYS_INDEXTYPE_HB_INT || lpIndex->m_bIndexType == MF_SYS_INDEXTYPE_HB_CHAR)
		{
			bHBTree = TRUE;
			break;
		}
	}

	if(bHBTree)
	{
		lpCondition = (LPBASECONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(lpRecursionInfo->m_nConnectCondOffset);  
		nRet = GetDrection(lpObjectInfo, lpCondition, lpRecursionInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpRecursionInfo->m_bDrection == 0)
		{
			return MF_PARSESELECT_INVALID_DRECITON_ERROR;
		}
	}

	//获取连接条件
	nRet = GetCondition(lpObjectInfo, lpRecursionInfo->m_nConnectCondOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取递归方向
	参数说明：
		lpObjectInfo：对象信息
		lpCondition：递归条件
		lpRecursionInfo：递归信息
************************************************************************/
int CExecutePlanManager::GetDrection(LPOBJECTDEF lpObjectInfo, LPBASECONDITIONBSON lpCondition, LPRECURSION lpRecursionInfo)
{
	int nRet;
	string strData;
	LPVOID lpValue;
	LPMATHEXPBSON lpMathExp;
	LPCOMPAREEXPBSON lpCompare1, lpCompare2;
	LPBASECONDITIONBSON lpCondition1, lpCondition2;
	LPMATHEXPELEMENTBSON lpFieldBson1, lpFieldBson2;
	
	if(lpCondition->m_bConditionType1 == MF_CONDITION_COMPARE)
	{
		lpCompare1 = (LPCOMPAREEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset1);
		if(lpCompare1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_PRIOR)
		{
			LPINDEXDEF lpIndex;
			BYTE bFieldNo1, bFieldNo2;
			lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompare1->m_nMathExpOffset1);
			lpFieldBson1 = (LPMATHEXPELEMENTBSON)m_pServiceBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1); 

			lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompare1->m_nMathExpOffset2);
			lpFieldBson2 = (LPMATHEXPELEMENTBSON)m_pServiceBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1); 
			
			strData = lpFieldBson1->m_bDataBuffer;
			lpValue = lpObjectInfo->m_mapName2FieldNo.Get(strData.c_str());
			if(lpValue == NULL)
			{
				return MF_PARSESELECT_INVALID_FIELD_ERROR;
			}
			else
			{
				bFieldNo1 = (BYTE)reinterpret_cast<long long>(lpValue);
			}

			strData = lpFieldBson2->m_bDataBuffer;
			lpValue = lpObjectInfo->m_mapName2FieldNo.Get(strData.c_str());
			if(lpValue == NULL)
			{
				return MF_PARSESELECT_INVALID_FIELD_ERROR;
			}
			else
			{
				bFieldNo2 = (BYTE)reinterpret_cast<long long>(lpValue);
			}

			for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
			{
				if(lpIndex->m_bIndexType == MF_SYS_INDEXTYPE_HB_INT || lpIndex->m_bIndexType == MF_SYS_INDEXTYPE_HB_CHAR)
				{
					if(lpIndex->m_bFieldNo[0] == bFieldNo1 && lpIndex->m_bFieldNo[1] == bFieldNo2)
					{
						lpRecursionInfo->m_bDrection     = 1;
						lpRecursionInfo->m_bIDFieldNo    = bFieldNo1;
						lpRecursionInfo->m_bPIDFieldNo   = bFieldNo2;
						lpCondition->m_bConditionType1   = MF_CONDITION_INVALID;
						lpCondition->m_nConditionOffset1 = 0;
						return MF_OK;
					}
					else if(lpIndex->m_bFieldNo[0] == bFieldNo2 && lpIndex->m_bFieldNo[1] == bFieldNo1)
					{
						lpRecursionInfo->m_bDrection     = 2;
						lpRecursionInfo->m_bIDFieldNo    = bFieldNo2;
						lpRecursionInfo->m_bPIDFieldNo   = bFieldNo1;
						lpCondition->m_bConditionType1   = MF_CONDITION_INVALID;
						lpCondition->m_nConditionOffset1 = 0;
						return MF_OK;
					}
					else
					{
						return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
					}
				}
			}
		}
	}
	else if(lpCondition->m_bConditionType1 == MF_CONDITION_LOGIC)
	{
		lpCondition1 = (LPBASECONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset1);
		nRet = GetDrection(lpObjectInfo, lpCondition1, lpRecursionInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpRecursionInfo->m_bDrection != 0)
		{
			return MF_OK;
		}
	}

	if(lpCondition->m_bConditionType2 == MF_CONDITION_COMPARE)
	{
		lpCompare2 = (LPCOMPAREEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset2);
		if(lpCompare2->m_bOperator == MF_EXECUTEPLAN_OPERATOR_PRIOR)
		{
			LPINDEXDEF lpIndex;
			BYTE bFieldNo1, bFieldNo2;
			lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompare2->m_nMathExpOffset1); 
			lpFieldBson1 = (LPMATHEXPELEMENTBSON)m_pServiceBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);  
			lpMathExp = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpCompare2->m_nMathExpOffset2);
			lpFieldBson2 = (LPMATHEXPELEMENTBSON)m_pServiceBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);

			strData = lpFieldBson1->m_bDataBuffer;
			lpValue = lpObjectInfo->m_mapName2FieldNo.Get(strData.c_str());
			if(lpValue == NULL)
			{
				return MF_PARSESELECT_INVALID_FIELD_ERROR;
			}
			else
			{
				bFieldNo1 = (BYTE)reinterpret_cast<long long>(lpValue);
			}

			strData = lpFieldBson2->m_bDataBuffer;
			lpValue = lpObjectInfo->m_mapName2FieldNo.Get(strData.c_str());
			if(lpValue == NULL)
			{
				return MF_PARSESELECT_INVALID_FIELD_ERROR;
			}
			else
			{
				bFieldNo2 = (BYTE)reinterpret_cast<long long>(lpValue);

			}

			for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
			{
				if(lpIndex->m_bIndexType == MF_SYS_INDEXTYPE_HB_INT || lpIndex->m_bIndexType == MF_SYS_INDEXTYPE_HB_CHAR)
				{
					if(lpIndex->m_bFieldNo[0] == bFieldNo1 && lpIndex->m_bFieldNo[1] == bFieldNo2)
					{
						lpRecursionInfo->m_bDrection		= 1;
						lpRecursionInfo->m_bIDFieldNo		= bFieldNo1;
						lpRecursionInfo->m_bPIDFieldNo		= bFieldNo2;
						lpCondition->m_bConditionType2		= MF_CONDITION_INVALID;
						lpCondition->m_nConditionOffset2	= 0;
						return MF_OK;
					}
					else if(lpIndex->m_bFieldNo[0] == bFieldNo2 && lpIndex->m_bFieldNo[1] == bFieldNo1)
					{
						lpRecursionInfo->m_bDrection		= 2;
						lpRecursionInfo->m_bIDFieldNo		= bFieldNo2;
						lpRecursionInfo->m_bPIDFieldNo		= bFieldNo1;
						lpCondition->m_bConditionType2		= MF_CONDITION_INVALID;
						lpCondition->m_nConditionOffset2	= 0;
						return MF_OK;
					}
					else
					{
						return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
					}
				}
			}
		}
	}
	else if(lpCondition->m_bConditionType2 == MF_CONDITION_LOGIC)
	{
		lpCondition2 = (LPBASECONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset1); 
		nRet = GetDrection(lpObjectInfo, lpCondition2, lpRecursionInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpRecursionInfo->m_bDrection != 0)
		{
			return MF_OK;
		}
	}
	return MF_OK;
}
/************************************************************************
	功能说明：
		获取修改执行计划
	参数说明：
		lpAlterExecutePlanBson：修改执行计划BSON
************************************************************************/
int CExecutePlanManager::GetAlterSystemPlan(LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson)
{
	int nRet;
	LPFILE_MEMDBFILEINFOBSON lpMemDBFileBson;

	lpMemDBFileBson = (LPFILE_MEMDBFILEINFOBSON)m_pServiceBson->ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
	if(MF_EXECUTEPLAN_ALTERTYPE_ADD_DBFILE == lpAlterExecutePlanBson->m_nType)
	{
		return MF_OK;
	}
	else if(MF_EXECUTEPLAN_ALTERTYPE_DROP_DBFILE == lpAlterExecutePlanBson->m_nType)
	{
		BYTE bFileType;
		LPMEMDBFILEDEF lpMemDBFileDef;
		if(!lpMemDBFileBson->m_bMemFile)
		{
			bFileType = lpMemDBFileBson->m_bFileType;
			nRet = CSystemManage::instance().GetMemDBFileInfo(lpMemDBFileBson->m_pOriginFilePath, lpMemDBFileDef);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpMemDBFileDef->m_bFileType != bFileType)
			{
				return MF_PARSECMD_ALTER_INDEX_TYPE_ERROR;
			}
			memcpy(lpMemDBFileBson->m_pOriginFilePath, lpMemDBFileDef->m_lpszFilePath, 256);
		}
		else
		{
			nRet = CSystemManage::instance().GetMemDBFileInfoByMem(lpMemDBFileBson->m_lpszMemFileName, lpMemDBFileDef);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			memcpy(lpMemDBFileBson->m_pOriginFilePath, lpMemDBFileDef->m_lpszFilePath, 256);
		}
		memcpy(lpAlterExecutePlanBson->m_pFilePath, lpMemDBFileDef->m_lpszFilePath, 256);
		return MF_OK;
	}
	else if(MF_EXECUTEPLAN_ALTERTYPE_MODIFY_DBFILE == lpAlterExecutePlanBson->m_nType)
	{
		BYTE bFileType;
		LPMEMDBFILEDEF lpMemDBFileDef;
		if(!lpMemDBFileBson->m_bMemFile)
		{
			bFileType = lpMemDBFileBson->m_bFileType;
			nRet = CSystemManage::instance().GetMemDBFileInfo(lpMemDBFileBson->m_pOriginFilePath, lpMemDBFileDef);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpMemDBFileDef->m_bFileType != bFileType)
			{
				return MF_PARSECMD_ALTER_INDEX_TYPE_ERROR;
			}
		}
		else
		{
			nRet = CSystemManage::instance().GetMemDBFileInfoByMem(lpMemDBFileBson->m_lpszMemFileName, lpMemDBFileDef);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		lpMemDBFileBson->m_bFileNo		 = lpMemDBFileDef->m_bFileNo;
		lpMemDBFileBson->m_bFileType	 = lpMemDBFileDef->m_bFileType;
		if(lpMemDBFileBson->m_lpszMemFileName[0] == 0)
		{
			memcpy(lpMemDBFileBson->m_lpszMemFileName, lpMemDBFileDef->m_lpszMemFileName, 64);
		}	
		if(lpMemDBFileBson->m_pAlterFilePath[0] == 0)
		{
			memcpy(lpMemDBFileBson->m_pAlterFilePath, lpMemDBFileBson->m_pOriginFilePath, 256);
		}
		else
		{
			lpMemDBFileBson->m_nFileSize = lpMemDBFileDef->m_nFileSize;
		}
	}
	else if(MF_EXECUTEPLAN_ALTERTYPE_SET_PARAMETER == lpAlterExecutePlanBson->m_nType)
	{
		int nValue;
		CMFString strItem;
		LPALTERSETEXPFIELDBSON lpBsonField;
		
		lpBsonField = (LPALTERSETEXPFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
		strItem = lpBsonField->m_pParameter;
		nValue = CSystemManage::instance().GetSystemParameter(strItem.c_str());
		if (MF_PARAMETER_UNKNOWN == nValue)
		{
			return	MF_PARSECMD_ALTER_SET_SYSTEM_PARAMETERNAME_ERROR;
		}
		((LPALTERSETEXPFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset))->m_bParameterType = nValue;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取修改执行计划
	参数说明：
		lpAlterExecutePlanBson：修改执行计划BSON
************************************************************************/
int CExecutePlanManager::GetAlterObjectPlan(LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson)
{
	BYTE bFieldNo;
	LPVOID lpValue;
	string strData;
	int nRet,nFieldNum;
	LPOBJECTDEF lpObjectInfo;
	map<string, BYTE>::iterator iter;

	nFieldNum = 0;
	bFieldNo  = 0;
	if(MF_EXECUTEPLAN_ALTERTYPE_ADD_FIELD == lpAlterExecutePlanBson->m_nType)
	{
		//添加列情况
		LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson;
		lpAlterObjectFieldBson = (LPALTEROBJECTFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
		nRet = CSystemManage::instance().GetObjectInfo(lpAlterObjectFieldBson->m_pObjectName, lpObjectInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpObjectInfo == NULL)
		{
			return MF_INNER_POINTER_NULL;
		} 
		m_pServiceBson->SetObjectInfo(lpObjectInfo);

		if(lpObjectInfo->m_bObjectType == MF_OBJECT_COMMON && m_lpExecutePlan->m_bObjectType != MF_OBJECT_COMMON)
		{
			return MF_PARSEALTER_INVALID_OBJECTTYPE_ERROR;
		}

		lpAlterObjectFieldBson->m_nObjectID = lpObjectInfo->m_nObjectID;
		return MF_OK;
	}
	else if(MF_EXECUTEPLAN_ALTERTYPE_ADD_INDEX == lpAlterExecutePlanBson->m_nType)
	{
		BOOL bTemp;
		BYTE bTempNo;
		int i, nCount;
		LPMEMDBFILEDEF lpMemDBFile;
		LPFILE_INDEXDEFBSON lpIndexBson;
		lpIndexBson = (LPFILE_INDEXDEFBSON)m_pServiceBson->ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset); 
		nRet = CSystemManage::instance().GetObjectInfo(lpIndexBson->m_pObjectName, lpObjectInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpObjectInfo == NULL)
		{
			return MF_INNER_POINTER_NULL;
		} 
		m_pServiceBson->SetObjectInfo(lpObjectInfo);

		if(lpObjectInfo->m_bObjectType == MF_OBJECT_COMMON && m_lpExecutePlan->m_bObjectType != MF_OBJECT_COMMON)
		{
			return MF_PARSEALTER_INVALID_OBJECTTYPE_ERROR;
		}

		nRet = CSystemManage::instance().GetMemDBFileInfo(lpIndexBson->m_pFilePath, lpMemDBFile);
		if(nRet != MF_OK)
		{
			nRet = CSystemManage::instance().GetMemDBFileInfoByMem(lpIndexBson->m_pFilePath, lpMemDBFile);
			if (nRet != MF_OK)
			{
				return nRet;
			}
		}
		if(lpMemDBFile == NULL)
		{
			return MF_INNER_POINTER_NULL;
		}
		//判断文件类型和关键词是否对应
		if(lpMemDBFile->m_bFileType != lpIndexBson->m_bFileType)
		{
			return MF_PARSECMD_ALTER_INDEX_TYPE_ERROR;
		}
		lpIndexBson->m_bFileNo				 = lpMemDBFile->m_bFileNo;
		lpIndexBson->m_nObjectID			 = lpObjectInfo->m_nObjectID;

		nCount = 0;
		for(i = 0; i < 4; i++)
		{
			strData = lpIndexBson->m_pFieldName[i];
			if(strData == "")
			{
				break;
			}
			lpValue = lpObjectInfo->m_mapName2FieldNo.Get(strData.c_str());
			if(lpValue == NULL)
			{
				return MF_PARSESELECT_INVALID_FIELD_ERROR;
			}
			else
			{
				bFieldNo = (BYTE)reinterpret_cast<long long>(lpValue);
			}

			if(bFieldNo == 0)
			{
				return MF_SYS_OBJECT_ADDINDEX_FIELDNAME_ERROR;
			}
			lpIndexBson->m_bFieldNo[i] = bFieldNo;
			nCount++;
		}
		if(i > 1)
		{
			if(lpIndexBson->m_bFileType != MF_SYS_FILETYPE_TREEINDEXFILE)
			{
				return MF_PARSECMD_ALTER_INDEX_TYPE_ERROR;
			}
			else
			{
				lpIndexBson->m_bIndexType = MF_SYS_INDEXTYPE_TREE_MULTINUM;
			}
		}
		else
		{
			nRet = GetIndexType(lpIndexBson->m_bFileType, lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType, lpIndexBson->m_bIndexType);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		//没有具体的索引类型，语法肯定有问题
		if(lpIndexBson->m_bIndexType == 0)
		{
			return MF_PARSECMD_ALTER_INDEX_TYPE_ERROR;
		}
		
		if(lpIndexBson->m_bIndexType == MF_SYS_INDEXTYPE_TREE_MULTINUM)
		{
			//调整索引顺序
			nCount--;
			bTemp = TRUE;
			for(i = 0; i <= nCount; i++)
			{
				bFieldNo = lpIndexBson->m_bFieldNo[i];
				if(lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_CHAR || lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_VARCHAR)
				{
					lpIndexBson->m_bIndexType = MF_SYS_INDEXTYPE_TREE_MULTISTR;
					if(bTemp)
					{
						bTempNo = lpIndexBson->m_bFieldNo[0];
						lpIndexBson->m_bFieldNo[0] = bFieldNo;
						lpIndexBson->m_bFieldNo[i] = bTempNo;
						bTemp = FALSE;
					}
					else
					{
						while(nCount > i)
						{
							bFieldNo = lpIndexBson->m_bFieldNo[nCount];
							if(lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType < 5)
							{
								bTempNo = lpIndexBson->m_bFieldNo[nCount];
								lpIndexBson->m_bFieldNo[nCount] = lpIndexBson->m_bFieldNo[i];
								lpIndexBson->m_bFieldNo[i] = bTempNo;
								break;
							}
							nCount--;
						}
					}
				}
			}
		}
		return MF_OK;
	}
	else if(MF_EXECUTEPLAN_ALTERTYPE_DROP_FIELD == lpAlterExecutePlanBson->m_nType)
	{
		//删除列情况
		LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson = NULL;
		lpAlterObjectFieldBson = (LPALTEROBJECTFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
		nRet = CSystemManage::instance().GetObjectInfo(lpAlterObjectFieldBson->m_pObjectName, lpObjectInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpObjectInfo == NULL)
		{
			return MF_INNER_POINTER_NULL;
		} 
		m_pServiceBson->SetObjectInfo(lpObjectInfo);

		if(lpObjectInfo->m_bObjectType == MF_OBJECT_COMMON && m_lpExecutePlan->m_bObjectType != MF_OBJECT_COMMON)
		{
			return MF_PARSEALTER_INVALID_OBJECTTYPE_ERROR;
		}

		lpAlterObjectFieldBson->m_nObjectID  = lpObjectInfo->m_nObjectID;
		return MF_OK;
	}
	else if(MF_EXECUTEPLAN_ALTERTYPE_DROP_INDEX == lpAlterExecutePlanBson->m_nType)
	{
		LPFILE_INDEXDEFBSON lpIndexBson = NULL;
		lpIndexBson = (LPFILE_INDEXDEFBSON)m_pServiceBson->ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset); 
		nRet = CSystemManage::instance().GetObjectInfo(lpIndexBson->m_pObjectName, lpObjectInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpObjectInfo == NULL)
		{
			return MF_INNER_POINTER_NULL;
		} 
		m_pServiceBson->SetObjectInfo(lpObjectInfo);

		if(lpObjectInfo->m_bObjectType == MF_OBJECT_COMMON && m_lpExecutePlan->m_bObjectType != MF_OBJECT_COMMON)
		{
			return MF_PARSEALTER_INVALID_OBJECTTYPE_ERROR;
		}

		lpIndexBson->m_nObjectID = lpObjectInfo->m_nObjectID;
		return MF_OK;
	}
	return MF_COMMON_INVALID_CMDTYPE;
}

/************************************************************************
	功能说明：
		获取修改执行计划
	参数说明：
		lpAlterExecutePlanBson：修改执行计划BSON
************************************************************************/
int CExecutePlanManager::GetAlterUserPlan(LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson)
{
	int nRet, i;
	LPUSERINFODEF lpUserInfo;
	LPAUTHORITYINFO lpAuthority;
	LPUSERINFOBSON lpUserInfoBson;
	
	lpUserInfoBson = (LPUSERINFOBSON)m_pServiceBson->ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
	nRet = CSystemManage::instance().GetUserInfo(lpUserInfoBson->m_pUserName, lpUserInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_DROP_AUTHORITY || lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_ADD_AUTHORITY)
	{
		for(i = 0; i < lpUserInfoBson->m_nAuthorityNum; i++)
		{
			nRet = CSystemManage::instance().GetAuthority((char*)lpUserInfoBson->m_pAuthorityName[i], lpAuthority);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpUserInfoBson->m_bAuthorityID[i] = lpAuthority->m_bAuthorityID;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取普通对象的查询执行计划
************************************************************************/
int CExecutePlanManager::GetCommonQueryPlan()
{
	int nRet;
	UINT nOffset;
	LPBYTE lpAddr;
	BOOL bStartIndex;
	LPSTARTINFO lpStartInfo;
	LPOBJECTDEF lpObjectInfo;
	LPRECURSION lpRecursionInfo;
	LPBASECONDITIONBSON lpCondition;
	LPOBJECTNAMEBSON lpObjectNameBson;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;	
	CIndexSelector stIndexSelector(m_pServiceBson);
	
	lpQueryPlan = (LPQUERYEXECUTEPLANBSON)((LPBYTE)m_lpExecutePlan + m_lpExecutePlan->m_nCommandOffset);
	lpQueryPlan->m_bQueryType = MF_QUERY_NORMAL;
	lpCommonCondition = (LPCOMMONCONDITION)m_pServiceBson->ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);

	//1.获取对象信息
	lpObjectNameBson = (LPOBJECTNAMEBSON)((LPBYTE)m_lpExecutePlan + lpQueryPlan->m_nObjectNameOffset);
	nRet = CSystemManage::instance().GetObjectInfo((char*)lpObjectNameBson->m_pObjectName, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(lpObjectInfo == NULL)
	{
		return MF_INNER_POINTER_NULL;
	}
	m_pServiceBson->SetObjectInfo(lpObjectInfo);

	if(lpObjectInfo->m_bObjectType != m_lpExecutePlan->m_bObjectType)
	{
		return MF_PARSESELECT_INVALID_OBJECTTYPE_ERROR;
	}
	lpQueryPlan->m_nObjectID					= lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_stSourceInfo.m_nObjectID = lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_nObjectID				= lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_bObjectType				= lpObjectInfo->m_bObjectType;

	//2.获取执行字段
	nRet = GetSelectField(lpObjectInfo, lpQueryPlan);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//判断查询字段是否为COUNT(*)考虑优化
	if(lpQueryPlan->m_nExcuteFieldNum == 1)
	{
		BOOL bCount;
		LPMATHEXPBSON lpMathExp;
		LPEXECUTEFIELDBSON lpFieldBson;
		LPMATHEXPELEMENTBSON lpMathFieldBson;

		bCount      = FALSE;
		lpFieldBson = (LPEXECUTEFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpQueryPlan->m_nExcuteFieldOffset);
		lpMathExp   = (LPMATHEXPBSON)m_pServiceBson->ConvertOffset2Addr(lpFieldBson->m_nExpOffset);
		if(lpMathExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_COUNT)
		{
			lpMathFieldBson = (LPMATHEXPELEMENTBSON)m_pServiceBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);
			if(lpMathFieldBson->m_bFieldNo == 0)
			{
				bCount = TRUE;
			}
		}
		if(bCount && lpCommonCondition->m_nWhereOffset == 0 && lpCommonCondition->m_nConnOffset == 0)
		{
			lpQueryPlan->m_bQueryType = MF_QUERY_COUNTALL;
		}
	}

	//3.获取where条件
	if((int)lpCommonCondition->m_nWhereOffset == -1)
	{
		lpQueryPlan->m_bQueryType = MF_QUERY_NULL;
	}
	else if(lpCommonCondition->m_nWhereOffset != 0)
	{	
		nRet = GetCondition(lpObjectInfo, lpCommonCondition->m_nWhereOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//获取递归条件条件
	if(lpCommonCondition->m_nConnOffset != 0)
	{
		bStartIndex = FALSE;
		if(lpCommonCondition->m_nIndexOffset == 0)
		{
			bStartIndex = TRUE;
		}
		nRet = GetRecursionCondition(lpObjectInfo, lpCommonCondition->m_nConnOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//创建索引执行计划
	if(lpCommonCondition->m_nConnOffset != 0)
	{
		lpRecursionInfo = (LPRECURSION)m_pServiceBson->ConvertOffset2Addr(lpCommonCondition->m_nConnOffset);
		if(lpRecursionInfo->m_bDrection != 2 && lpCommonCondition->m_nWhereOffset)
		{
			//如果不是向上递归，则使用where条件的索引
			lpCondition = (LPBASECONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset); 
			
			stIndexSelector.Clear();
			nRet = stIndexSelector.Initial(lpObjectInfo, lpCondition, NULL);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nRet = stIndexSelector.GetQueryIndex();
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpCommonCondition->m_nIndexOffset	= stIndexSelector.GetIndexOffset();
			lpCommonCondition->m_bQueryPlanType = stIndexSelector.GetQueryPlanType();
			lpCommonCondition->m_nRowNum		= stIndexSelector.GetRowNum();
		}	
		
		if(lpCommonCondition->m_nIndexOffset == 0)
		{
			lpStartInfo	= (LPSTARTINFO)m_pServiceBson->ConvertOffset2Addr(lpRecursionInfo->m_nStartCondOffset);
			lpCondition = (LPBASECONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(lpStartInfo->m_nWhereOffset);
			nRet = stIndexSelector.Initial(lpObjectInfo, lpCondition, NULL);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nRet = stIndexSelector.GetQueryIndex();
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpStartInfo->m_nIndexOffset			= stIndexSelector.GetIndexOffset();
			lpCommonCondition->m_bQueryPlanType = stIndexSelector.GetQueryPlanType();
			lpCommonCondition->m_nRowNum		= stIndexSelector.GetRowNum();
		}
	}
	else if(lpCommonCondition->m_nWhereOffset)
	{
		lpCondition = (LPBASECONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);  
		
		nRet = stIndexSelector.Initial(lpObjectInfo, lpCondition, NULL);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = stIndexSelector.GetQueryIndex();
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpCommonCondition->m_nIndexOffset	= stIndexSelector.GetIndexOffset();
		lpCommonCondition->m_bQueryPlanType = stIndexSelector.GetQueryPlanType();
		lpCommonCondition->m_nRowNum		= stIndexSelector.GetRowNum();
	}

	lpAddr = NULL;
	nRet   =  m_pServiceBson->AllocFromBsonBuffer(lpQueryPlan->m_nExcuteFieldNum*sizeof(VARDATA), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpQueryPlan->m_nDataArrayOffset = nOffset;
	
	if(m_nPageSize > 0)
	{
		lpQueryPlan->m_nPageSize = m_nPageSize;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取普通对象的删除执行计划
************************************************************************/
int CExecutePlanManager::GetCommonDeletePlan()
{
	int nRet;
	LPBYTE lpAddr;
	LPOBJECTDEF lpObjectInfo;
	LPBASECONDITIONBSON lpCondition;
	LPOBJECTNAMEBSON lpObjectNameBson;
	LPDELETEEXECUTEPLANBSON lpDeletePlan;
	CIndexSelector stIndexSelector(m_pServiceBson);

	lpDeletePlan = (LPDELETEEXECUTEPLANBSON)m_pServiceBson->ConvertOffset2Addr(m_lpExecutePlan->m_nCommandOffset);

	//1.获取对象信息
	lpObjectNameBson = (LPOBJECTNAMEBSON)m_pServiceBson->ConvertOffset2Addr(lpDeletePlan->m_nObjectNameOffset);
	nRet = CSystemManage::instance().GetObjectInfo((char*)lpObjectNameBson->m_pObjectName, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(lpObjectInfo == NULL)
	{
		return MF_INNER_POINTER_NULL;
	} 
	m_pServiceBson->SetObjectInfo(lpObjectInfo);

	if(lpObjectInfo->m_bObjectType != m_lpExecutePlan->m_bObjectType)
	{
		return MF_PARSEDELETE_INVALID_OBJECTTYPE_ERROR;
	}
	
	lpDeletePlan->m_nObjectID					= lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_nObjectID				= lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_stSourceInfo.m_nObjectID	= lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_bObjectType				= lpObjectInfo->m_bObjectType;

	//2.创建索引计划(由于建立的索引的字段不允许为空，所以m_pIndex中的所有字段在记录中一定都对应有值) 
	nRet = CreateIndexPlan(lpObjectInfo, lpDeletePlan->m_nDeleteIndexOffset, lpDeletePlan->m_nIndexNum);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//3.获取查询条件
	if(lpDeletePlan->m_nWhereOffset != 0)
	{
		nRet = GetCondition(lpObjectInfo, lpDeletePlan->m_nWhereOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		//4.获取索引执行字段
		lpCondition = (LPBASECONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(lpDeletePlan->m_nWhereOffset);
		nRet = stIndexSelector.Initial(lpObjectInfo, lpCondition, NULL);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = stIndexSelector.GetQueryIndex();
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpDeletePlan->m_nIndexOffset = stIndexSelector.GetIndexOffset();
	}

	//4.分配空间记录块信息
	lpAddr = NULL;
	nRet = m_pServiceBson->AllocFromBsonBuffer(MF_MAX_BLOCKINFO_NUM*sizeof(BLOCKINFO), m_lpExecutePlan->m_stSourceInfo.m_nBlockOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取普通对象的更新执行计划
************************************************************************/
int CExecutePlanManager::GetCommonUpdatePlan()
{
	int nRet;
	UINT nOffset;
	LPBYTE lpAddr;
	LPOBJECTDEF lpObjectInfo;
	LPOBJECTNAMEBSON lpObjectNameBson;
	LPUPDATEEXECUTEPLANBSON lpUpdatePlan;
	CIndexSelector stIndexSelector(m_pServiceBson);

	lpUpdatePlan = (LPUPDATEEXECUTEPLANBSON)((LPBYTE)m_lpExecutePlan + m_lpExecutePlan->m_nCommandOffset);
	//1.获取对象信息
	lpObjectNameBson = (LPOBJECTNAMEBSON)((LPBYTE)m_lpExecutePlan + lpUpdatePlan->m_nObjectNameOffset);
	nRet = CSystemManage::instance().GetObjectInfo((char*)lpObjectNameBson->m_pObjectName, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(lpObjectInfo == NULL)
	{
		return MF_INNER_POINTER_NULL;
	} 
	m_pServiceBson->SetObjectInfo(lpObjectInfo);

	if(lpObjectInfo->m_bObjectType != m_lpExecutePlan->m_bObjectType)
	{
		return MF_PARSEUPDATE_INVALID_OBJECTTYPE_ERROR;
	}

	lpUpdatePlan->m_nObjectID						= lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_nObjectID					= lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_stSourceInfo.m_nObjectID     = lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_bObjectType					= lpObjectInfo->m_bObjectType;
	//2.获取执行字段
	nRet = GetUpdateField(lpObjectInfo, lpUpdatePlan);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	//3.获取查询条件
	if(lpUpdatePlan->m_nWhereOffset != 0)
	{	
		nRet = GetCondition(lpObjectInfo, lpUpdatePlan->m_nWhereOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		//4.获取索引执行字段
		LPBASECONDITIONBSON lpCondition;
		lpCondition = (LPBASECONDITIONBSON)m_pServiceBson->ConvertOffset2Addr(lpUpdatePlan->m_nWhereOffset);
		nRet = stIndexSelector.Initial(lpObjectInfo, lpCondition, NULL);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = stIndexSelector.GetQueryIndex();
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpUpdatePlan->m_nIndexOffset = stIndexSelector.GetIndexOffset();
	}

	//5.分配空间记录块信息
	lpAddr = NULL;
	nRet = m_pServiceBson->AllocFromBsonBuffer(MF_MAX_BLOCKINFO_NUM*sizeof(BLOCKINFO), m_lpExecutePlan->m_stSourceInfo.m_nBlockOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}


	//6.创建字段映射表和字段映射数组
	lpAddr = NULL;
	nRet =  m_pServiceBson->AllocFromBsonBuffer(lpObjectInfo->m_nFieldNum*sizeof(LPEXECUTEFIELDBSON), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpUpdatePlan->m_nFieldMapOffset = nOffset;

	lpAddr = NULL;
	nRet =  m_pServiceBson->AllocFromBsonBuffer(lpObjectInfo->m_nFieldNum*sizeof(VARDATA), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpUpdatePlan->m_nDataArrayOffset = nOffset;
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取查询执行计划
	参数说明：
		lpExecutePlan：执行计划BSON
************************************************************************/
int CExecutePlanManager::GetQueryPlan()
{
	if(m_lpExecutePlan->m_bObjectType == MF_OBJECT_COMMON)
	{
		return GetCommonQueryPlan();
	}
	return MF_PARSESELECT_INVALID_OBJECTTYPE_ERROR;
}
/************************************************************************
	功能说明：
		获取插入执行计划
************************************************************************/
int CExecutePlanManager::GetInsertPlan()
{
	int nRet;
	UINT nOffset;
	LPBYTE lpAddr;
	LPOBJECTNAMEBSON lpObjectNameBson;
	LPINSERTEXECUTEPLANBSON lpInsertPlan;
	LPOBJECTDEF lpObjectInfo;

	lpInsertPlan     = (LPINSERTEXECUTEPLANBSON)((LPBYTE)m_lpExecutePlan + m_lpExecutePlan->m_nCommandOffset);
	//1.获取对象信息
	lpObjectNameBson = (LPOBJECTNAMEBSON)((LPBYTE)m_lpExecutePlan + lpInsertPlan->m_nObjectNameOffset);
	nRet = CSystemManage::instance().GetObjectInfo((char*)lpObjectNameBson->m_pObjectName, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(lpObjectInfo == NULL)
	{
		return MF_INNER_POINTER_NULL;
	}
	m_pServiceBson->SetObjectInfo(lpObjectInfo);

	if(lpObjectInfo->m_bObjectType != m_lpExecutePlan->m_bObjectType)
	{
		return MF_PARSEISNERT_INVALID_OBJECTTYPE_ERROR;
	}

	lpInsertPlan->m_nObjectID    = lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_nObjectID = lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_stSourceInfo.m_nObjectID = lpObjectInfo->m_nObjectID;

	//2.获取执行字段
	nRet = GetInsertField(lpObjectInfo, lpInsertPlan);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//3.创建索引执行计划
	nRet = CreateIndexPlan(lpObjectInfo, lpInsertPlan->m_nInsertIndexOffset, lpInsertPlan->m_nIndexNum);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//5.分配空间记录块信息
	lpAddr = NULL;
	nRet = m_pServiceBson->AllocFromBsonBuffer(MF_MAX_BLOCKINFO_NUM*sizeof(BLOCKINFO), m_lpExecutePlan->m_stSourceInfo.m_nBlockOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//6.创建一个列号->列偏移映射表，其大小和字段顺序与表结构保持一致
	lpAddr = NULL;
	nRet =  m_pServiceBson->AllocFromBsonBuffer(sizeof(LPEXECUTEFIELDBSON)*lpObjectInfo->m_nFieldNum, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpInsertPlan->m_nFieldMapOffset = nOffset;

	lpAddr = NULL;
	nRet =  m_pServiceBson->AllocFromBsonBuffer(sizeof(VARDATA)*lpObjectInfo->m_nFieldNum, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpInsertPlan->m_nDataArrayOffset = nOffset;
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取更新执行计划
************************************************************************/
int CExecutePlanManager::GetUpdatePlan()
{
	if(m_lpExecutePlan->m_bObjectType == MF_OBJECT_COMMON)
	{
		return GetCommonUpdatePlan();
	}
	return MF_PARSEUPDATE_INVALID_OBJECTTYPE_ERROR;
}

/************************************************************************
	功能说明：
		获取删除执行计划
************************************************************************/
int CExecutePlanManager::GetDeletePlan()
{
	if(m_lpExecutePlan->m_bObjectType == MF_OBJECT_COMMON)
	{
		return GetCommonDeletePlan();
	}
	return MF_PARSEDELETE_INVALID_OBJECTTYPE_ERROR;
}

/************************************************************************
	功能说明：
		获取修改计划
************************************************************************/
int CExecutePlanManager::GetAlterPlan()
{
	int nRet;
	LPALTEREXECUTEPLANBSON lpAlterBson;

	lpAlterBson = (LPALTEREXECUTEPLANBSON)((LPBYTE)m_lpExecutePlan + m_lpExecutePlan->m_nCommandOffset);
	if(MF_EXECUTEPLAN_ALTERTYPE_OBJECT == lpAlterBson->m_bObjectType)
	{
		nRet = GetAlterObjectPlan(lpAlterBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		return MF_OK;
	}
	else if(MF_EXECUTEPLAN_ALTERTYPE_SYSTEM == lpAlterBson->m_bObjectType)
	{
		nRet = GetAlterSystemPlan(lpAlterBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		return MF_OK;
	}
	else if(MF_EXECUTEPLAN_ALTERTYPE_USER == lpAlterBson->m_bObjectType)
	{
		nRet = GetAlterUserPlan(lpAlterBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		return MF_OK;
	}
	return MF_FAILED;
}

/************************************************************************
	功能说明：
		获取创建计划
************************************************************************/
int CExecutePlanManager::GetCreatePlan()
{
	LPCREATEEXECUTEPLANBSON lpCreateExecutePlanBson;
	lpCreateExecutePlanBson = (LPCREATEEXECUTEPLANBSON)m_pServiceBson->ConvertOffset2Addr(m_lpExecutePlan->m_nCommandOffset);
	if(lpCreateExecutePlanBson->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_OBJECT)
	{
		LPOBJECTDEFBSON lpObject;
		LPINDEXDEFBSON lpIndexField;

		lpObject = (LPOBJECTDEFBSON)m_pServiceBson->ConvertOffset2Addr(lpCreateExecutePlanBson->m_nPlanOffset);
		lpIndexField = (LPINDEXDEFBSON)m_pServiceBson->ConvertOffset2Addr(lpObject->m_nIndexOffset);

		while(lpIndexField)
		{
			if(lpIndexField->m_nNextOffset != 0)
			{
				lpIndexField = (LPINDEXDEFBSON)m_pServiceBson->ConvertOffset2Addr(lpIndexField->m_nNextOffset);
			}
			else
			{
				lpIndexField = NULL;
			}
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取修改结果集计划
************************************************************************/
int CExecutePlanManager::GetUpdateRecordsetPlan()
{
	LPVOID lpValue;
	string strFieldName;
	UINT nOffset, nAddrID;
	BYTE bFieldNo, bTempNo;
	LPOBJECTDEF lpObjectInfo;
	LPRECORDHEAD lpRecordHead;
	LPSOURCEINFO lpSourceInfo;
	LPXMLFIELDBSON lpXmlFieldBson;
	LPXMLFIELDINFO lpXmlFieldInfo;
	int nRet, i, j, nFieldValueLen;
	LPOBJECTNAMEBSON lpObjectNameBson;
	LPBYTE lpIsNull, lpAddr, lpFieldValue;
	LPUPDATERECORDSETPLANBSON lpUpdateRecordsetPlan;
	
	lpUpdateRecordsetPlan = (LPUPDATERECORDSETPLANBSON)((LPBYTE)m_lpExecutePlan + m_lpExecutePlan->m_nCommandOffset);
	lpObjectNameBson = (LPOBJECTNAMEBSON)((LPBYTE)m_lpExecutePlan + lpUpdateRecordsetPlan->m_nObjectNameOffset);
	nRet = CSystemManage::instance().GetObjectInfo((char*)lpObjectNameBson->m_pObjectName, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(lpObjectInfo == NULL)
	{
		return MF_INNER_POINTER_NULL;
	} 
	m_pServiceBson->SetObjectInfo(lpObjectInfo);

	m_lpExecutePlan->m_nObjectID					= lpObjectInfo->m_nObjectID;
	lpUpdateRecordsetPlan->m_nObjectID				= lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_stSourceInfo.m_nObjectID     = lpObjectInfo->m_nObjectID;
	m_lpExecutePlan->m_bObjectType					= lpObjectInfo->m_bObjectType;

	lpSourceInfo				  = &m_lpExecutePlan->m_stSourceInfo;
	lpSourceInfo->m_nRecordAddrID = lpUpdateRecordsetPlan->m_nRecordAddrID;
	lpSourceInfo->m_nRecordNum	  = lpUpdateRecordsetPlan->m_nExecuteStepNum;
	
	//1.创建一个与表结构中字段数量相等的数组，以表示表结构中某字段编号对应的字段是否为空
	lpIsNull = NULL;
	nRet	 =  m_pServiceBson->AllocFromCircleBuffer(lpObjectInfo->m_nFieldNum, lpIsNull);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//2.将LPXMLFIELDINFO中的列名转换为列号
	lpXmlFieldInfo = (LPXMLFIELDINFO)m_pServiceBson->ConvertOffset2Addr(lpUpdateRecordsetPlan->m_nFieldInfoOffset);
	for(i = 0; i < (int)lpUpdateRecordsetPlan->m_nFieldNum; i++)
	{
		strFieldName = (char*)m_pServiceBson->ConvertOffset2Addr(lpXmlFieldInfo[i].m_nFieldNameOffset);
		//根据列名获得列编号
		lpValue = lpObjectInfo->m_mapName2FieldNo.Get(strFieldName.c_str());
		if(lpValue == NULL)
		{
			lpXmlFieldInfo[i].m_bFieldNo   = 0;
			lpXmlFieldInfo[i].m_bFieldType = 0;
		}
		else
		{
			bFieldNo = (BYTE)reinterpret_cast<long long>(lpValue);
			lpXmlFieldInfo[i].m_bFieldNo   = bFieldNo;
			lpXmlFieldInfo[i].m_bFieldType = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;
		}
	}
	
	Move2FirstRecord();
	for(i = 0; i < (int)lpUpdateRecordsetPlan->m_nExecuteStepNum; i++)
	{	
		//3.遍历记录中的每个字段,将字段编号写入字段数据中
		NextRecord(nAddrID, lpRecordHead);
		lpXmlFieldBson = (LPXMLFIELDBSON)m_pServiceBson->ConvertOffset2Addr(lpRecordHead->m_nFieldOffset);
		for(j = 0; j < lpRecordHead->m_bFieldNum; j++)	
		{
			bTempNo  = lpXmlFieldBson[j].m_bTempNo;
			bFieldNo = lpXmlFieldInfo[bTempNo - 1].m_bFieldNo;
			
			lpXmlFieldBson[j].m_bFieldNo = bFieldNo;
			//将字段编号序列化到字段值中
			if(lpXmlFieldBson[j].m_bModify)
			{
				if(lpXmlFieldBson[j].m_nFieldDataOffset != 0)
				{
					lpFieldValue			= m_pServiceBson->ConvertOffset2Addr(lpXmlFieldBson[j].m_nFieldDataOffset);
					*(BYTE*)lpFieldValue	= bFieldNo;
					lpIsNull[bFieldNo - 1]	= 0;

					//定长字符串处理需要判断其长度是否正确
					if(lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_CHAR)
					{
						if(lpObjectInfo->m_lpField[bFieldNo - 1].m_bCharLen < 250)
						{
							nFieldValueLen = sizeof(BYTE) + sizeof(BYTE) + lpObjectInfo->m_lpField[bFieldNo - 1].m_bCharLen + 1;
						}
						else
						{
							nFieldValueLen = sizeof(BYTE) + sizeof(BYTE) + sizeof(int) + lpObjectInfo->m_lpField[bFieldNo - 1].m_bCharLen + 1;
						}

						if(nFieldValueLen < lpXmlFieldBson[j].m_nFieldDataLen)
						{
							return MF_COMMON_INVALID_STRINGLEN;
						}
					}
				}
				else
				{
					lpIsNull[bFieldNo - 1] = 1;
				}
			}
			else if(lpRecordHead->m_bType == MF_EXECUTE_STEP_INSERTDATA)
			{
				//对于插入操作，如果没有修改当前字段，表示当前字段为空
				lpIsNull[bFieldNo - 1] = 1;
			}
		}
		
		//4.对字段进行非空校验
		if(lpRecordHead->m_bType == MF_EXECUTE_STEP_INSERTDATA || lpRecordHead->m_bType == MF_EXECUTE_STEP_UPDATEDATA)
		{
			for(j = 0; j < lpObjectInfo->m_nFieldNum; j++)
			{
				if(0 == lpObjectInfo->m_lpField[j].m_bAllowNull && lpIsNull[j])
				{
					return MF_UPDATERECORDSET_INVALID_NULLFIELD_ERROR;
				}
			}
		}
	}

	//3.创建索引计划
	nRet = CreateIndexPlan(lpObjectInfo, lpUpdateRecordsetPlan->m_nIndexOffset, lpUpdateRecordsetPlan->m_nIndexNum);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//4.分配空间记录块信息
	lpAddr = NULL;
	nRet = m_pServiceBson->AllocFromBsonBuffer(MF_MAX_BLOCKINFO_NUM*sizeof(BLOCKINFO), m_lpExecutePlan->m_stSourceInfo.m_nBlockOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//5.创建字段映射表
	lpAddr = NULL;
	nRet   =  m_pServiceBson->AllocFromBsonBuffer(sizeof(LPXMLFIELDBSON)*lpObjectInfo->m_nFieldNum, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpUpdateRecordsetPlan->m_nFieldMapOffset = nOffset;
	return MF_OK;
}

/************************************************************************
	功能说明：
		初始化
	参数说明：
		lpExecutePlan：执行计划BSON
		pServiceBson：Bson对象
	特别说明：
		外部调用该函数，将客户端传过来的执行计划的BSON结构转换为内部使用的执行计划结构体
		注意：外部调用GetExecutePlan时已经对lpExecutePlan的时间戳和OBJECTID进行了赋值
************************************************************************/
void CExecutePlanManager::Initial(LPEXECUTEPLANBSON lpExecutePlan, CServiceBson* pServiceBson)
{
	m_lpExecutePlan			= lpExecutePlan;
	m_pServiceBson			= pServiceBson;
}

/************************************************************************
	功能说明：
		获取执行计划
	参数说明：
		stBson：Bson对象
		lpExecutePlan：执行计划BSON
	特别说明：
		外部调用该函数，将客户端传过来的执行计划的BSON结构转换为内部使用的执行计划结构体
		注意：外部调用GetExecutePlan时已经对lpExecutePlan的时间戳和OBJECTID进行了赋值
************************************************************************/
int CExecutePlanManager::AnalysisExecutePlan()
{
	int nRet;
	if(m_lpExecutePlan->m_nUserID == 0)
	{
		return MF_PARSECMD_INVALID_USER_ERROR;
	}
	else if(!CheckAuthority())
	{
		return MF_PARSECMD_INVALID_AUTHORITY_ERROR;
	}
	switch(m_lpExecutePlan->m_nType)
	{
	case MF_EXECUTEPLAN_CMDTYPE_QUERY:
		nRet = GetQueryPlan();
		break;
	case MF_EXECUTEPLAN_CMDTYPE_INSERT:
		nRet = GetInsertPlan();
		break;
	case MF_EXECUTEPLAN_CMDTYPE_UPDATE:
		nRet = GetUpdatePlan();
		break;
	case MF_EXECUTEPLAN_CMDTYPE_DELETE:
		nRet = GetDeletePlan();
		break;
	case MF_EXECUTEPLAN_CMDTYPE_UPDATERECORDSET:
		nRet = GetUpdateRecordsetPlan();
		break;
	case MF_EXECUTEPLAN_CMDTYPE_CREATE:
		//create的执行计划已经在客户端完成了处理，所以这里不需要再进行处理
		nRet = GetCreatePlan();
		break;
	case MF_EXECUTEPLAN_CMDTYPE_DROP:
		//drop的执行计划已经在客户端完成了处理，所以这里不需要再进行处理
		nRet = MF_OK;
		break;
	case MF_EXECUTEPLAN_CMDTYPE_ALTER:
		nRet = GetAlterPlan();
		break;
	default:
		nRet = MF_COMMON_INVALID_CMDTYPE;
	}
	if(nRet != MF_OK)
	{
		return nRet;
	}
	m_pServiceBson->LockBsonBufferSize();
	return MF_OK;
}

/************************************************************************
	功能说明：
		移动到第一条记录
************************************************************************/
int CExecutePlanManager::Move2FirstRecord()
{
	int nRet;
	UINT nAddrID;
	LPBYTE lpRecordAddr;

	if(m_lpExecutePlan->m_stSourceInfo.m_nRecordAddrID == 0)
	{
		//没有记录
		m_lpRecord	= NULL;
		m_nCurrentRecordNo  = 0;  
		return MF_OK;
	}
	nAddrID				= m_lpExecutePlan->m_stSourceInfo.m_nRecordAddrID;
	m_nCurrentBufferNo  = nAddrID >> 16;
	
	nRet = m_pServiceBson->ConvertAddrID2Addr(nAddrID, lpRecordAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	m_pServiceBson->GetSectionBufferAddr(m_nCurrentBufferNo, m_lpCurrentBuffer);

	m_lpRecord	= (LPRECORDHEAD)lpRecordAddr;
	m_nCurrentRecordNo  = 0;  
	return MF_OK;
}

/************************************************************************
	功能说明：
		下一条记录信息
	参数说明：
		nAddrID：地址ID
		lpRecordHead：记录头
************************************************************************/
int CExecutePlanManager::NextRecord(UINT& nAddrID, LPRECORDHEAD& lpRecordHead)
{
	USHORT nOffset;
	LPBYTE lpRecordAddr;

	m_nCurrentRecordNo++;
	if(m_nCurrentRecordNo > (int)m_lpExecutePlan->m_stSourceInfo.m_nRecordNum)
	{
		nAddrID		 = 0;
		lpRecordHead = NULL;
		return MF_OK;
	}
	else
	{
		nOffset			= (USHORT)((LPBYTE)m_lpRecord - m_lpCurrentBuffer);
		nAddrID			= m_pServiceBson->MakeAddrID(m_nCurrentBufferNo, nOffset);
		
		lpRecordHead    = m_lpRecord;
		if(lpRecordHead->m_bLast)
		{
			//切换到下一个缓存片段
			m_nCurrentBufferNo++;
			m_pServiceBson->GetSectionDataAddr(m_nCurrentBufferNo, lpRecordAddr);
			m_pServiceBson->GetSectionBufferAddr(m_nCurrentBufferNo, m_lpCurrentBuffer);

			m_lpRecord = (LPRECORDHEAD)lpRecordAddr;
		}
		else
		{
			m_lpRecord++;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		移动到指定步骤
************************************************************************/
int CExecutePlanManager::Move2Step(int nStepNo)
{
	int nRet, i;
	UINT nAddrID;
	LPBYTE lpStepAddr;
	LPEXECUTESTEP lpStep;

	if(m_lpExecutePlan->m_stStepInfo.m_nStepAddrID == 0)
	{
		m_lpStep = NULL;
		return MF_OK;
	}

	nAddrID				= m_lpExecutePlan->m_stStepInfo.m_nStepAddrID;
	m_nCurrentBufferNo  = m_pServiceBson->GetBufferNoFromAddrID(nAddrID);

	nRet = m_pServiceBson->ConvertAddrID2Addr(nAddrID, lpStepAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	m_lpStep = (LPEXECUTESTEP)lpStepAddr;
	for(i = 0; i < nStepNo; i++)
	{
		nRet = NextStep(lpStep);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		下一个步骤
	参数说明：
		lpStep：步骤信息
************************************************************************/
int CExecutePlanManager::NextStep(LPEXECUTESTEP& lpStep)
{
	LPBYTE lpStepAddr;

	lpStep	= m_lpStep;
	if(m_lpStep->m_bFlag == 2)
	{
		//切换到下一个缓存片段
		m_nCurrentBufferNo++;
		m_pServiceBson->GetSectionDataAddr(m_nCurrentBufferNo, lpStepAddr);
		if(lpStepAddr == NULL)
		{
			m_lpStep = NULL;
		}
		else
		{
			m_lpStep = (LPEXECUTESTEP)lpStepAddr;
		}
	}
	else
	{
		m_lpStep++;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		前一个步骤
	参数说明：
		lpStep：步骤信息
************************************************************************/
int CExecutePlanManager::PreStep(LPEXECUTESTEP& lpStep)
{
	LPBYTE lpStepAddr;

	lpStep = m_lpStep;
	if(lpStep == NULL)
	{
		return MF_OK;
	}
	if(lpStep->m_bFlag == 1)
	{
		//切换到前一个缓存片段
		m_nCurrentBufferNo--;
		if(m_nCurrentBufferNo == 0)
		{
			m_lpStep = NULL;
			return MF_OK;
		}
		m_pServiceBson->GetSectionBufferAddr(m_nCurrentBufferNo, lpStepAddr);
		if(lpStepAddr != NULL)
		{
			m_lpStep = (LPEXECUTESTEP)(lpStepAddr + m_lpExecutePlan->m_nDefaultSectionSize);
		}
		else
		{
			m_lpStep = NULL;
		}
	}
	else
	{
		m_lpStep--;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		插入DataID
	参数说明：
		nDataID：数据ID
************************************************************************/
int CExecutePlanManager::PushDataID(long long nDataID)
{
	int nRet;
	UINT nAddrID;
	LPRECORDHEAD lpRecordHead;

	nRet = m_pServiceBson->AllocRecord(lpRecordHead, nAddrID);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(0 == m_lpExecutePlan->m_stSourceInfo.m_nRecordAddrID)
	{
		m_lpExecutePlan->m_stSourceInfo.m_nRecordAddrID = nAddrID;
	}
	lpRecordHead->m_nDataID = nDataID;
	m_lpExecutePlan->m_stSourceInfo.m_nRecordNum++;

	return MF_OK;
}

//需要排重
int CExecutePlanManager::PushDataID2(long long nDataID)
{
	int nRet;
	UINT nAddrID;
	LPRECORDHEAD lpRecordHead;

	nRet = m_pServiceBson->AllocRecord(lpRecordHead, nAddrID);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(0 == m_lpExecutePlan->m_stSourceInfo.m_nRecordAddrID)
	{
		m_lpExecutePlan->m_stSourceInfo.m_nRecordAddrID = nAddrID;
	}
	lpRecordHead->m_nDataID = nDataID;
	m_lpExecutePlan->m_stSourceInfo.m_nRecordNum++;

	return MF_OK;
}

