﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/************************************************************************
	哈希表类

	总体介绍：
	KV索引分为两级来实现:文件级、索引级，该类属于索引级

	KV索引和数字索引相同都需要支持256种不同类型数据
	(注意：这里指的是256种不同数据的类型即不同的Object，然后要为不同的数据建立索引，而不是索引的类型有256种,KV索引的类型只有两种)
	这里需要将为这256种不同类型的数据建立的索引放入一个内存映射文件
	(原因：如果一个内存映射文件只存放1种类型数据的索引那么内存映射文件会很多，并且同一个数据可能会建立两种类型的索引，所以管理上会很复杂)
	
	一、内存的管理方式
	为了将相同IndexID的索引项，存放在相对集中的区域，在构建KV索引的时候，还是需要内存映射文件、内存块、索引项，三种结构，而对于内存块，会存放两种数据：索引项和哈希表
	文件级负责对索引块的管理，包括给索引级分配内存块、从索引级回收内存块(或回收存放哈希表的内存块)、维护空闲内存区链表
	索引级负责管理从文件级获取的内存块。具体的实现如下：
	1.当向内存映射文件中插入一个新的Hash表时，文件级分配一个内存块，然后将Hash表头写入内存
	2.当向一个空的Hash中插入一条索引项时，首先由文件级分配一块内存块给索引级，然后索引级根据Hash函数计算出该索引项所属的HashNode，最后将索引项插入内存，并将其索引项“挂”在HashNode上
	3.文件级分配给索引级的内存块，由索引级自行管理，当内存块满时，索引级向文件级再申请一个内存块，作为当前使用的内存块
	4.当删除一条索引项时就会留下一段空的内存空间，由于索引项的结构体中包含了一个m_nNextOffset,所以可以利用该结构很方便的建立空索引项栈(先进后出)具体实现步骤如下:
	  (1)在数据块头记录空闲索引栈的首地址m_nFreeIndexOffset(初始化为0，表示没有空闲索引块)
	  (2)当第一次删除索引项时将m_nFreeIndexOffset设置为该索引项相对于内存块的偏移量
	  (3)利用“插头法”来形成空块链表栈
	  (4)当插入一条新的索引项时,利用m_nFreeIndexOffset空索引栈是否有空块可以分配，如果有就执行“弹栈”操作，否则从索引级管理的当前内存块中分配一个空索引块，
		 如果当前内存块满就调用文件级的内存分配函数，从空闲区中分配一个内存块(文件级的AllocMemory函数会返回空内存块相对于文件头的偏移量，用这个偏移量+文件指针就可以得到该处的指针，然后直接插入索引项即可)
	  (5)当哈希表中所有的索引项被清空后，将调用文件级的DeAllocMemory函数回收内存块

	特别说明:虽然内存管理中提供了块的概念，但是块只是为了方便索引集中和内存回收提供的一种结构，在进行检索时，是通过Hash()函数根据key值直接定位数据ID的实际地址，和块无关

	二、索引级

	在哈希表级提供一个哈希结点(HashNode)的概念，一张哈希表是由若干个HashNode组成，一个HashNode链接着所有Hash值相同的索引项
	一个Object对应一张哈希表，哈希表负责完成以下功能：
	1.定位索引项(主要功能)
	  说明：结点的概念和redis的桶是一个概念
	  (1)HashNode的定位是直接根据关键字key通过Hash函数计算得到的(实际哈希函数返回的是HashNode相对于Hash头的偏移量，注意是结点头不是文件头)
	  (2)在HashNode中会存放索引项相对于内存文件首地址的偏移量，所以找到HashNode之后就可以直接定位到索引项了

	2.记录索引项链表长度
	  由于对于哈希表的冲突处理采用Separate chaining(拉链法)方法解决，所以相同Hash值的索引项会被挂在同一个HashNode上，那么需要记录这个链表的长度，
	  在特定的时候进行rehash

    
	这里需要特别注意两个偏移量的概念：根据key和Hash函数计算出的是HashNode的偏移量，这个偏移量是相对于Hash头的，这个值相当于一个虚拟地址
	而HashNode中存放的偏移量是索引项的相对于文件头的偏移量，这个值相当于是一个实际地址

	3.空闲区管理(见一)
	  

	三、文件级
	在文件级主要完成以下主要功能。
	1.完成IndexID向Hash表的映射
	  在文件级维护一张IndexID到Hash表的映射表，将为不同类型数据创建的KV索引和对应的Hash表对应起来
	  (采用256个元素的数组，数组中每个数据项包含一个IndexID和一个HashNode头相对于文件头的偏移量)

	2.完成从空闲区中分配内存(向哈希表级提供一个内存分配函数供其调用)
	  
	3.rehash
	  这是文件级的一个十分重要的操作，当hash表的冲突率或者索引项达到一定数目时，需要将哈希表进行扩张
	  扩张的实质就是将原来的Hash表迁移到一个容量更大的Hash表中
	  具体步骤如下：
	  (1)首先从内存的空闲区申请一块内存作为新的Hash表(reHashTable),reHashTable的容量需要是原HashTable的整数倍
	  (2)然后开始渐进式迁移，所谓渐进式迁移，就是并非一次性把HashTable中的所有节点都迁移到reHashTable中,因为这样会非常耗时。
		 渐进式迁移的策略是在每次进行索引的添加、删除查找时，从HashTable中的第一个结点开始，每次将一个结点中的所有索引项迁移到reHashTable中
		 而进行插入操作时，就直接将新的索引项加入reHashTable中。注意，当从HashTable中迁移完一个结点后，并不将此结点的m_nIndexOffset设置为0，
		 这样做的目的是在数据迁移完成之前，还是可以通过HashTable查找到大部分索引项(而如果要对新加入的索引项进行查找，就必须到reHashTable中去查找了)
	  (3)当HashTable中的所有索引项全部迁移到reHashTable中后，会释放HashTable，并将这部分空间加入到空闲区(这个空闲区之后可以分配给索引项或HashTable),
	     然后将reHashTable作为HashTable(在ROOT结构体中修改对应项的偏移)

     4.维护空闲区链表(见一)
	   在映射文件中会存在一个空闲区，然后在rehash完成后又会释放出新的空闲区，所以在文件级还需要将这些空闲区练成一个链表，
	   在链表头记录空闲区的大小和下一块空闲区的位置
		 
		
************************************************************************/

#pragma once
#define DEF_HASHBLOCK_SIZE (256*1024)
#define DEF_KEY_SIZE	  32
#define NEWHASHTABLEBLOCK 0
#define HASHTABLEBLOCK    1
#define INDEXBLOCK        2


class CMemoryHashFile;
class CMemoryHashIndex
{
protected:
	#pragma pack(1)
	//哈希结点结构体(这个结构体在内存中的位置是根据Hash函数直接定位的)
	typedef struct  
	{
		long long			m_nIndexOffset;							//该结点中第一个索引项的偏移(相对于文件头)
		int					m_nListLen;								//索引项链表的长度
	}HASHNODE,*LPHASHNODE;	

	//哈希表块头
	typedef struct
	{
		int					m_nDataFlag;							//数据标志，目前数据块为‘SBDB’
		int                 m_nBlockNo;								//块号(新插入块的编号 = 最大块号 + 1)
		long long           m_nTimestamp;							//时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
		int                 m_nBlockSize;							//块大小
		int                 m_nBlockHeadSize;						//块头大小
		BYTE                m_bStatus;								//数据锁定状态，一般修改单条数据不需要整块锁，但如果整块进行整理时就必须进行锁定，防止其他读取或者修改操作出现错乱
		BYTE                m_bFileNo;								//文件编号
		BYTE				m_bSaveFlag;							//数据库保存标志，防止单纯按照时间戳判断出现误判
		BYTE                m_bThreadNum;							//保留数据	
		
		long long			m_llHBTreeRootID;							//用于记录HB树索引的根结点
		BYTE				m_bBlockTypeFlag;						//块类型标志：0：未初始化的哈希表块 1：初始化的哈希表块 2：索引块
		int					m_nHashTableLen;						//哈希表长度
		int					m_nHashNodeSize;						//哈希结点的大小
		int					m_nHashIndexNodeSize;					//哈希索引项大小
		long long			m_nFreeBlockOffset;						//空闲块映射表偏移
		long long			m_nDataBlockOffset;						//满块映射表偏移
		long long			m_nReHashTableOffset;					//ReHash表偏移
		int					m_nRehashNodePos;
	}HASHBLOCKHEAD,*LPHASHBLOCKHEAD;
	
	//内存块头
	typedef struct
	{
		int					m_nDataFlag;							//数据标志，目前数据块为‘SBDB’
		int                 m_nBlockNo;								//块号(新插入块的编号 = 最大块号+1)
		long long           m_nTimestamp;							//时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
		int                 m_nBlockSize;							//块大小
		int                 m_nBlockHeadSize;						//块头大小
		BYTE                m_bStatus;								//数据锁定状态，一般修改单条数据不需要整块锁，但如果整块进行整理时就必须进行锁定，防止其他读取或者修改操作出现错乱
		BYTE                m_bFileNo;								//文件编号
		BYTE				m_bSaveFlag;							//数据库保存标志，防止单纯按照时间戳判断出现误判
		BYTE                m_bThreadNum;							//保留数据	

		BYTE				m_bBlockTypeFlag;						//块类型标志：0：未初始化的哈希表块 1：初始化的哈希表块 2：索引块
		BYTE				m_bBlockFull;							//块的空满状态，依次来判断块属于哪一个链表
		int					m_nTotalDataNum;						//可以容纳索引项的总条数
		int					m_nDataNum;								//现有索引项条数(剩余空间 = m_nTotalDataNum - m_nDataNum,为0表示块满，需要插入新块)
		long long			m_nFreeIndexOffset;						//空索引栈的首地址偏移(相对于文件头)
		long long			m_nNextBlockOffset;						//下一个内存块偏移
 		long long			m_nPreBlockOffset;						//前一个内存块偏移
	}INDEXBLOCKHEAD,*LPINDEXBLOCKHEAD;

	#pragma pack()
private:
	//防止此类被非法构造成对象或者复制
	CMemoryHashIndex(const CMemoryHashIndex&);
	CMemoryHashIndex& operator = (const CMemoryHashIndex&);

protected:
	int m_nIndexID;													//IndexID
	LPBYTE m_lpHashTable;											//指向哈希表头
	LPBYTE m_lpRehashTable;											//指向re哈希表头
	CMemoryHashFile* m_pHashFile;									//指向哈希表文件对象
	LPHASHBLOCKHEAD m_lpHashTableHead;								//m_pHashHead   = (LPHASHEAD)m_pHashTable
	LPHASHBLOCKHEAD m_lpRehashTableHead;							//m_pReHashHead = (LPHASHEAD)m_pReHashTable
protected:
	/************************************************************************
		功能说明：
			从空闲区队列中分配一条空索引项
	************************************************************************/
	int AllocBlock(LPEXECUTEPLANBSON lpExecutePlan, int& nBlockNo, int nObjdectID, int nBlockSize, long long llTimestamp);

	/************************************************************************
		功能说明：
			释放内存块(清空),并把块号添加到空块队列中
	************************************************************************/
	int FreeBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo, long long llTimestamp);

	/************************************************************************
		功能说明：
			修改根结点
	************************************************************************/
	int RootUpdate(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nBlockNo);

	/************************************************************************
		功能说明：
			将偏移转换为实际地址
	************************************************************************/
	LPBYTE ConvertOffsettoAddr(long long nOffset);

	/************************************************************************
		功能说明：
			将偏移转换为实际地址
	************************************************************************/
	long long ConvertAddrtoOffset(LPBYTE lpAddr);

	/************************************************************************
		功能说明：
			根据块号获得块在内存中的实际地址
	************************************************************************/
	LPBYTE ConvertBlockNotoAddr(int nBlockNo);

	/************************************************************************
		功能说明：
			将条索引项的实际地址转换为其块头的地址
	************************************************************************/
	int ConvertIndexOffsettoBlockOffset(long long nIndexOffset, int nBlockSize, long long& nBlockOffset);

	/************************************************************************
		功能说明：
			修改时间戳
	************************************************************************/
	void TimestampUpdate(LPEXECUTEPLANBSON lpExecutePlan, LPBASEBLOCKHEAD lpBlockHead, long long llTimestamp)
	{
		CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBlockCritical(), lpExecutePlan);
		//根据块的指针判断块的类型(存放哈希表的块还是存放索引项的块)
		if(lpBlockHead->m_nTimestamp != llTimestamp)
		{
			lpBlockHead->m_nTimestamp = llTimestamp;
			lpBlockHead->m_bSaveFlag  = 0;
		}
	}
	
	/************************************************************************
		功能说明：
			获取Hash结点
	************************************************************************/
	LPHASHNODE GetHashNode(LPBYTE lpHashTable ,int nHashPos)
	{
		return (LPHASHNODE)(lpHashTable + m_lpHashTableHead->m_nBlockHeadSize + nHashPos * m_lpHashTableHead->m_nHashNodeSize);
	}

	/************************************************************************
		功能说明：
			当达到reHash条件时开始执行reHash
	************************************************************************/
	int BeginRehash(LPEXECUTEPLANBSON lpExecutePlan, long long llTimestamp);

	/************************************************************************
		功能说明:
			实现ReHash
	************************************************************************/
	int Rehash(LPEXECUTEPLANBSON lpExecutePlan, int& nRehashNodePos, long long llTimestamp);

	/************************************************************************
		功能说明:
			在内存中插入一条索引项
	************************************************************************/
	int InsertData(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long llTimestamp);

	/************************************************************************
		功能说明:
			在内存中插入一条索引项
	************************************************************************/
	int DeleteData(LPINDEXINFO lpIndexInfo, LPHASHNODE lpHashNode, long long llTimestamp);

	/************************************************************************
		功能说明：
			获取关键字值
	************************************************************************/
	virtual void GetKeyValue(LPVOID lpNodeData, VARDATA& varKey){};

	/************************************************************************
		功能说明：
			获取关键字值
	************************************************************************/
	virtual long long GetDataIDFromNodeData(LPVOID lpNodeData){return 0;};

	/************************************************************************
		功能说明：
			设置节点数据
	************************************************************************/
	virtual void SetNodeData(LPVOID lpNodeData, VARDATA& varKey, long long nDataID){};

	/************************************************************************
		功能说明：
			清空节点数据
	************************************************************************/
	virtual void ClearNodeData(LPVOID lpNodeData){};

	/************************************************************************
		功能说明：
			计算Hash值
	************************************************************************/
	virtual DWORD CalcKeyHash(VARDATA& varKey, int nHashSize){return 0;};

	/************************************************************************
		功能说明：
			判断关键字是否重复
	************************************************************************/
	virtual BOOL CheckKey(CServiceBson* pBson, VARDATA& varKey, BYTE bFiedNo, LPHASHNODE lpHashNode){return TRUE;};

public:
	CMemoryHashIndex();
	~CMemoryHashIndex();

public:
	/************************************************************************
		功能说明：
			初始化哈希表管理类，让整个实例是可执行的
	************************************************************************/
	void SetHashTableAddr(LPBYTE lpHashTable, int nIndexID, CMemoryHashFile* pHashFile);

	/************************************************************************
		功能说明：
			创建哈希表块
	************************************************************************/
	void InitialHashBlock(LPHASHBLOCKHEAD pHashHead, int nIndexNodeSize, int nFreeBlockOffset = 0)
	{
		if(pHashHead == NULL)
		{
			pHashHead = m_lpHashTableHead;
		}
		pHashHead->m_nBlockHeadSize		= sizeof(HASHBLOCKHEAD);
		pHashHead->m_nHashNodeSize		= sizeof(HASHNODE);
		pHashHead->m_nHashIndexNodeSize	= nIndexNodeSize;
		pHashHead->m_bBlockTypeFlag		= 1;
		pHashHead->m_nHashTableLen		= (pHashHead->m_nBlockSize - pHashHead->m_nBlockHeadSize) / pHashHead->m_nHashNodeSize;   //注明：哈希块中是不需要记录现有节点数的，因为索引数据的插入位置是由哈希算法决定的，因此不可能越界
		pHashHead->m_nFreeBlockOffset	= nFreeBlockOffset;
		pHashHead->m_nDataBlockOffset	= 0;
		pHashHead->m_nReHashTableOffset = 0;
		pHashHead->m_llHBTreeRootID		= 0;
	}

	/************************************************************************
		功能说明：
			创建索引块
	************************************************************************/
	void InitialIndexBlock(LPINDEXBLOCKHEAD lpBlockHead, int nHeadSize)
	{
		lpBlockHead->m_nBlockHeadSize   = nHeadSize;
		lpBlockHead->m_bBlockTypeFlag   = 2;
		lpBlockHead->m_bBlockFull	    = 0;
		lpBlockHead->m_nTotalDataNum    = (lpBlockHead->m_nBlockSize- nHeadSize) / m_lpHashTableHead->m_nHashIndexNodeSize;
		lpBlockHead->m_nDataNum	        = 0;
		lpBlockHead->m_nFreeIndexOffset = 0;
		lpBlockHead->m_nNextBlockOffset = 0;
		lpBlockHead->m_nPreBlockOffset  = 0;
	}

	/************************************************************************
		功能说明：
			获取HB树根节点DataID
	************************************************************************/
	long long GetHBTreeRoot(LPEXECUTEPLANBSON lpExecutePlan)
	{
		CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBlockCritical(), lpExecutePlan);
		return m_lpHashTableHead->m_llHBTreeRootID;
	}
	
	/************************************************************************
		功能说明：
			设置HB树根节点DataID
	************************************************************************/
	void SetHBTreeRoot(LPEXECUTEPLANBSON lpExecutePlan, long long llDataID, long long llTimestamp)
	{
		CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBlockCritical(), lpExecutePlan);
		m_lpHashTableHead->m_llHBTreeRootID = llDataID;
		m_lpHashTableHead->m_nTimestamp		= llTimestamp;
	}

	/************************************************************************
		功能说明：
			删除Object
	************************************************************************/
	void DropObject(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, long long llTimestamp);

	/************************************************************************
		功能说明：
			根据nKey值在内存中插入一条索引项
	************************************************************************/
	int InsertIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long llTimestamp);

	/************************************************************************
		功能说明：
			根据nKey值在索引块中删除一个索引项
	************************************************************************/
	int DeleteIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long llTimestamp);

	/************************************************************************
		功能说明：
			根据关键字，获取数据ID
	************************************************************************/
	int GetDataID(LPINDEXINFO lpIndexInfo, CDataIDContainer* pDataIDContainer);
};