﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "CommonMemObject.h"
#include "MemoryFile.h"
#include "MemoryBTreeFile.h"
#include "MemoryHashFile.h"
#include "SystemManage.h"
#include "Expression.h"
#include "UpdateBson.h"
#include "RecordSetBson.h"
#include "InsertBson.h"
#include "FunctionManager.h"
#include "ExecutePlanManager.h"
#include "Check.h"

CCommonMemObject::CCommonMemObject(void)
{
}

CCommonMemObject::~CCommonMemObject(void)
{
}

int CCommonMemObject::Release()
{
	delete this;
	return MF_OK;
}

/************************************************************************
	功能说明：
		向索引文件中插入一条索引项
	参数说明：
		lpIndexInfo：索引信息
		nObjectID：对象ID
		lpExecutePlan：执行计划
		nTimestamp：时间戳
************************************************************************/
int CCommonMemObject::InsertIndex(LPINDEXINFO lpIndexInfo, int nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	int nRet;
	LPINDEXDEF lpIndex;
	IVirtualMemoryFile* pVirtualFile;
	CSystemLockStateManage stIndexLock;

	nRet = CSystemManage::instance().GetMemoryFileInstance(lpIndexInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//给索引加互斥锁
	nRet = CSystemManage::instance().GetIndexInfo(lpIndexInfo->m_nIndexID, lpIndex);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	stIndexLock.Inital(MF_LOCK_INDEX, lpExecutePlan, lpIndex);
	nRet = stIndexLock.Lock(MF_LOCK_STATUS_MUTEX, MF_LOCK_OUTOFTIME, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//插入索引
	if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_vt == MF_SYS_FIELDTYPE_NULL)
	{
		return MF_OK;
	}

	switch(lpIndexInfo->m_bIndexType)
	{
	case MF_SYS_INDEXTYPE_KV_INT:
	case MF_SYS_INDEXTYPE_KV_BIGINT:
	case MF_SYS_INDEXTYPE_KV_CHAR:
	case MF_SYS_INDEXTYPE_HB_CHAR:
	case MF_SYS_INDEXTYPE_HB_INT:
		nRet = ((CMemoryHashFile*)pVirtualFile)->InsertIndex(lpIndexInfo, nObjectID, lpExecutePlan, nTimestamp);
		break;
	case MF_SYS_INDEXTYPE_TREE_INT:
	case MF_SYS_INDEXTYPE_TREE_BIGINT:
	case MF_SYS_INDEXTYPE_TREE_DOUBLE:
	case MF_SYS_INDEXTYPE_TREE_MULTINUM:
	case MF_SYS_INDEXTYPE_TREE_MULTISTR:
	case MF_SYS_INDEXTYPE_FUZZY_CHAR:
		nRet = ((CMemoryBTreeFile*)pVirtualFile)->InsertIndex(lpIndexInfo, nObjectID, lpExecutePlan, nTimestamp);
		break;
	default:
		return MF_COMMON_INVALID_INDEXTYPE;
	}
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		向索引文件中插入一条索引项
	参数说明：
		lpIndexInfo：索引信息
		lpExecutePlan：执行计划
		nTimestamp：时间戳
************************************************************************/
int CCommonMemObject::DeleteIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	int nRet;
	LPINDEXDEF lpIndex;
	IVirtualMemoryFile* pVirtualFile;
	CSystemLockStateManage stIndexLock;

	nRet = CSystemManage::instance().GetMemoryFileInstance(lpIndexInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//给索引加互斥锁
	nRet = CSystemManage::instance().GetIndexInfo(lpIndexInfo->m_nIndexID, lpIndex);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	stIndexLock.Inital(MF_LOCK_INDEX, lpExecutePlan, lpIndex);
	nRet = stIndexLock.Lock(MF_LOCK_STATUS_MUTEX, MF_LOCK_OUTOFTIME, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	switch(lpIndexInfo->m_bIndexType)
	{
	case MF_SYS_INDEXTYPE_KV_INT:
	case MF_SYS_INDEXTYPE_KV_BIGINT:
	case MF_SYS_INDEXTYPE_KV_CHAR:
	case MF_SYS_INDEXTYPE_HB_CHAR:
	case MF_SYS_INDEXTYPE_HB_INT:
		nRet = ((CMemoryHashFile*)pVirtualFile)->DeleteIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
		break;
	case MF_SYS_INDEXTYPE_TREE_INT:
	case MF_SYS_INDEXTYPE_TREE_BIGINT:
	case MF_SYS_INDEXTYPE_TREE_DOUBLE:
	case MF_SYS_INDEXTYPE_TREE_MULTINUM:
	case MF_SYS_INDEXTYPE_TREE_MULTISTR:
	case MF_SYS_INDEXTYPE_FUZZY_CHAR:
		nRet = ((CMemoryBTreeFile*)pVirtualFile)->DeleteIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
		break;
	default:
		return MF_COMMON_INVALID_INDEXTYPE;
	}
	return nRet;
}

/************************************************************************
	功能说明：
		更新索引文件中的索引项
	参数说明：
		lpIndexInfo：索引信息
		nObjectID：对象ID
		lpExecutePlan：执行计划
		nTimestamp：时间戳
************************************************************************/
int CCommonMemObject::UpdateIndex(LPINDEXINFO lpIndexInfo, int nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	int nRet;
	LPINDEXDEF lpIndex;
	IVirtualMemoryFile* pVirtualFile;
	CSystemLockStateManage stIndexLock;
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpIndexInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//给索引加互斥锁
	nRet = CSystemManage::instance().GetIndexInfo(lpIndexInfo->m_nIndexID, lpIndex);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	stIndexLock.Inital(MF_LOCK_INDEX, lpExecutePlan, lpIndex);
	nRet = stIndexLock.Lock(MF_LOCK_STATUS_MUTEX, MF_LOCK_OUTOFTIME, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	switch(lpIndexInfo->m_bIndexType)
	{
	case MF_SYS_INDEXTYPE_KV_INT:
	case MF_SYS_INDEXTYPE_KV_BIGINT:
	case MF_SYS_INDEXTYPE_KV_CHAR:
	case MF_SYS_INDEXTYPE_HB_CHAR:
	case MF_SYS_INDEXTYPE_HB_INT:
		nRet = ((CMemoryHashFile*)pVirtualFile)->UpdateIndex(lpIndexInfo, nObjectID, lpExecutePlan, nTimestamp);
		break;
	case MF_SYS_INDEXTYPE_TREE_INT:
	case MF_SYS_INDEXTYPE_TREE_BIGINT:
	case MF_SYS_INDEXTYPE_TREE_DOUBLE:
	case MF_SYS_INDEXTYPE_TREE_MULTINUM:
	case MF_SYS_INDEXTYPE_TREE_MULTISTR:
	case MF_SYS_INDEXTYPE_FUZZY_CHAR:
		nRet = ((CMemoryBTreeFile*)pVirtualFile)->UpdateIndex(lpIndexInfo, nObjectID, lpExecutePlan, nTimestamp);
		break;
	}

	if(nRet == MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
	{
		return MF_OK;
	}
	else if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		临界区释放
	参数说明：
		stBson：Bson对象
************************************************************************/
void CCommonMemObject::CriticalRelease(CServiceBson& stBson)
{
	int i;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	for(i = 0; i < 20; i++)
	{
		if(lpExecutePlan->m_pCritStack[i] != 0)
		{
			::LeaveCriticalSection((LPCRITICAL_SECTION)lpExecutePlan->m_pCritStack[i]);
			lpExecutePlan->m_pCritStack[i] = 0;
		}
	}
}

/************************************************************************
	功能说明：
		获取记录数
	参数说明：
		stBson：Bson对象
		stExecutePlanManager：执行计划类
		nRecordNum：记录数
************************************************************************/
int CCommonMemObject::GetRecordNum(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int& nRecordNum, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPOBJECTDEF lpObjectInfo;
	long long* lpTransactionArray;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan		= stExecutePlanManager.GetExecutePlan();
	lpTransactionArray	= (long long*)stBson.GetPtrFromTempBuffer(lpExecutePlan->m_nTransactionOffset);
	TRANSACTIONARRAY stTransactionArray(lpExecutePlan->m_nTransactionNum, lpTransactionArray);

	nRet = CSystemManage::instance().GetObjectInfo(lpExecutePlan->m_nObjectID, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	nRet = GetDataNum(lpExecutePlan, lpObjectInfo, &stTransactionArray, nRecordNum);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}	

/************************************************************************
	功能说明：
		记录锁定块
	参数说明：
		stBson：Bson对象
		stExecutePlanManager：执行计划类
		lpExecuteInfo：统计信息
************************************************************************/
int CCommonMemObject::Preprocess(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPEXECUTEPLANBSON lpExecutePlan;
	
	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	switch(lpExecutePlan->m_nType)
	{
	case MF_EXECUTEPLAN_CMDTYPE_INSERT:
		nRet  = PreprocessInsert(stBson, stExecutePlanManager, lpExecuteInfo);
		break;
	case MF_EXECUTEPLAN_CMDTYPE_UPDATE:
		nRet  = PreprocessUpdate(stBson, stExecutePlanManager, lpExecuteInfo);
		break;
	case MF_EXECUTEPLAN_CMDTYPE_DELETE:
		nRet  = PreprocessDelete(stBson, stExecutePlanManager, lpExecuteInfo);
		break;
	case MF_EXECUTEPLAN_CMDTYPE_UPDATERECORDSET:
		nRet  = PreprocessUpdateRecordset(stBson, stExecutePlanManager);
		break;
	default:
		nRet  = MF_COMMON_INVALID_CMDTYPE;
	}
	return nRet;
}

/************************************************************************
	功能说明：
		对块上锁
	参数说明：
		stBson：BSON对象
		lpObjectInfo：对象信息
		nDataID：数据ID
		setBlockNo：块编号
************************************************************************/
int CCommonMemObject::LockBlock(CServiceBson& stBson, LPOBJECTDEF lpObjectInfo, long long& nDataID)
{
	CMemoryFile* pFile;
	int nRet, nBlockNo, i;
	LPBLOCKINFO lpBlockInfo;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	nRet  = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;
	
	//1.给Object加共享锁
	nRet = CSystemManage::instance().LockObject(lpExecutePlan, lpObjectInfo, MF_LOCK_STATUS_SHARE, MF_LOCK_OUTOFTIME);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	else if(lpObjectInfo->m_bStatus == MF_LOCK_STATUS_MUTEX)
	{
		return MF_OK;
	}
	//2.给块上锁
	nRet = pFile->LockBlock(lpExecutePlan, nDataID, MF_LOCK_OUTOFTIME);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	if(lpExecutePlan->m_stSourceInfo.m_nBlockNoNum > 10)
	{
		//解锁上锁的块
		lpBlockInfo = (LPBLOCKINFO)stBson.ConvertOffset2Addr(lpExecutePlan->m_stSourceInfo.m_nBlockOffset);
		for(i = 0; i < MF_MAX_BLOCKINFO_NUM; i++)
		{
			nBlockNo = lpBlockInfo[i].m_nBlockNo;
			if(nBlockNo == 0)
			{
				continue;
			}
			nRet = pFile->UnlockBlock(lpExecutePlan, nBlockNo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		
		//然后将对象级共享锁提升为互斥锁
		nRet = CSystemManage::instance().LockObject(lpExecutePlan, lpObjectInfo, MF_LOCK_STATUS_MUTEX, MF_LOCK_OUTOFTIME);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取某Object的所有有效记录数
	参数说明：
		lpExecutePlan：执行计划
		lpObjectInfo：对象信息
		lpTransactionArray：事务数组
		nDataNum：记录数量
************************************************************************/
int CCommonMemObject::GetDataNum(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, LPTRANSACTIONARRAY lpTransactionArray, int& nDataNum)
{
	int nRet;
	CMemoryFile* pFile;
	IVirtualMemoryFile* pVirtualFile;

	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;
	nRet = pFile->GetObjectDataNum(lpExecutePlan, lpObjectInfo, lpTransactionArray, nDataNum);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		根据索引获取DataID
	参数说明：
		stBson:BSON对象
		lpQueryInfo：查询信息
		pDataIDContainer：DataID容器
************************************************************************/
int CCommonMemObject::GetDataIDByIndex(CServiceBson& stBson, LPQUERYINFO lpQueryInfo, CDataIDContainer* pDataIDContainer)
{
	int nRet, i;
	Check stCheck;
	INDEXINFO stIndexInfo;
	LPINDEXEXECUTEPLAN lpIndexPlan;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;

	lpExecutePlan  = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	nRet = stCheck.Initial(&stBson, lpQueryInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	lpIndexPlan	= (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(lpQueryInfo->m_nIndexOffset);
	if(lpIndexPlan->m_nNextOffset != 0)
	{
		pDataIDContainer->SetUnique(TRUE);
	}

	while(lpIndexPlan)
	{
		if(lpIndexPlan->m_bIndexType == MF_SYS_INDEXTYPE_ROWID)
		{
			nRet = pDataIDContainer->push_back(lpIndexPlan->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_llValue);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpIndexPlan	= (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(lpIndexPlan->m_nNextOffset);
			continue;
		}

		stIndexInfo.m_pBson		   = &stBson;
		stIndexInfo.m_bFileNo	   = lpIndexPlan->m_bFileNo;
		stIndexInfo.m_nIndexID     = lpIndexPlan->m_nIndexID;
		stIndexInfo.m_bIndexType   = lpIndexPlan->m_bIndexType;
		stIndexInfo.m_bPagingType  = lpQueryInfo->m_bPagingType;
		stIndexInfo.m_nPageSize    = lpQueryInfo->m_nPageSize;
		stIndexInfo.m_nPagePos     = lpQueryInfo->m_nPageSize*(lpQueryInfo->m_nPageNo - 1);
		stIndexInfo.m_pCheck	   = &stCheck;

		stIndexInfo.m_bFieldNo[0]  = lpIndexPlan->m_bFieldNo[0];
		stIndexInfo.m_bFieldNo[1]  = lpIndexPlan->m_bFieldNo[1];
		stIndexInfo.m_bFieldNo[2]  = lpIndexPlan->m_bFieldNo[2];
		stIndexInfo.m_bFieldNo[3]  = lpIndexPlan->m_bFieldNo[3];

		stIndexInfo.m_pParam1	   = (LPVOID)lpIndexPlan->m_lpParamPtr1;
		stIndexInfo.m_pParam2	   = (LPVOID)lpIndexPlan->m_lpParamPtr2;
		stIndexInfo.m_pParam3	   = (LPVOID)lpIndexPlan->m_lpParamPtr3;
		stIndexInfo.m_nParam4	   = lpIndexPlan->m_nParam4;
		stIndexInfo.m_nParam5	   = lpIndexPlan->m_nParam5;
		
		stIndexInfo.m_stMultiIndex.m_nIndexNum = 0;
		for(i = 0; i < 4; i++)
		{
			if(lpIndexPlan->m_bFieldNo[i] == 0)
			{
				break;
			}
			else
			{
				stIndexInfo.m_stMultiIndex.m_nIndexNum++;
				memcpy(&stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i], &lpIndexPlan->m_stMultiIndex.m_lpIndexCondition[i], sizeof(INDEXCONDITION));
			}
		}

		nRet = CSystemManage::instance().GetMemoryFileInstance(lpIndexPlan->m_bFileNo, pVirtualFile);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		switch(lpIndexPlan->m_bIndexType)
		{
		case MF_SYS_INDEXTYPE_KV_INT:
		case MF_SYS_INDEXTYPE_KV_BIGINT:
		case MF_SYS_INDEXTYPE_KV_CHAR:
			nRet = ((CMemoryHashFile*)pVirtualFile)->GetDataID(&stIndexInfo, pDataIDContainer);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			break;
		case MF_SYS_INDEXTYPE_TREE_INT:
		case MF_SYS_INDEXTYPE_TREE_BIGINT:
		case MF_SYS_INDEXTYPE_TREE_DOUBLE:
		case MF_SYS_INDEXTYPE_TREE_MULTINUM:
		case MF_SYS_INDEXTYPE_TREE_MULTISTR:
		case MF_SYS_INDEXTYPE_FUZZY_CHAR:
			nRet = ((CMemoryBTreeFile*)pVirtualFile)->GetDataID(&stIndexInfo, pDataIDContainer);
			if(nRet == MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
			{
				return MF_OK;
			}
			else if(nRet != MF_OK)
			{
				return nRet;
			}
			break;
		default:
			return MF_COMMON_INVALID_INDEXTYPE;
		}

		lpIndexPlan	= (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(lpIndexPlan->m_nNextOffset);
		stIndexInfo.clear();
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			全表遍历
		参数说明：
			stBson:BSON对象
			lpQueryInfo：查询信息
			pDataIDContainer：DataID容器
************************************************************************/
int CCommonMemObject::GetDataIDDriect(CServiceBson& stBson, LPQUERYINFO lpQueryInfo, CDataIDContainer* pDataIDContainer)
{
	Check stCheck;
	BOOL bRelation;
	BYTE bLinkType;
	CMemoryFile* pFile;
	LPOBJECTDEF lpObjectInfo;
	int nRet, nInnerDataNo, nCount;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;
	long long nDataID, nBlockMapOffset;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpObjectInfo  = lpQueryInfo->m_lpObjectInfo;
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile; 

	//执行全表遍历	
	bLinkType		= 0;
	nBlockMapOffset = 0;
	nInnerDataNo	= 0;
	stCheck.Initial(&stBson, lpQueryInfo);

	nCount = 0;
	while(TRUE)
	{
		bRelation = FALSE;
		nRet = pFile->GetNextDataID(lpExecutePlan, lpObjectInfo->m_nObjectID, bRelation, bLinkType, nBlockMapOffset, nInnerDataNo, nDataID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(nDataID == 0)
		{
			break;
		}
		if(stCheck.CheckRecordValid(nDataID))
		{
			nCount++;
			if(nCount > lpQueryInfo->m_nPageSize*(lpQueryInfo->m_nPageNo - 1))
			{
				nRet = pDataIDContainer->push_back(nDataID);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				if(lpQueryInfo->m_bPagingType == MF_PAGING_FIRST && (int)pDataIDContainer->size() >= lpQueryInfo->m_nPageSize)
				{
					break;
				}
			}
		}
	}
	return MF_OK;
}


/************************************************************************
	功能说明：
		执行数据插入
	参数说明：
		stBson:Bson对象
		lpParam:公共参数
		lpStep：执行步骤
************************************************************************/
int CCommonMemObject::ExecuteInsertData(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep)
{
	int i, nRet;
	LPBYTE lpAddr;
	CMemoryFile* pFile;
	CExpression stExpression;
	LPOBJECTDEF lpObjectInfo;
	LPRECORDHEAD lpRecordHead;
	LPBASESTEPPARAM lpBaseParam;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;

	lpBaseParam  = (LPBASESTEPPARAM)lpParam;
	lpObjectInfo = (LPOBJECTDEF)lpBaseParam->m_lpObjectInfo;
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;	

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	stExpression.Initial(&stBson, lpObjectInfo);
	//创建插入记录
	if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_INSERT)
	{
		int nOffset;
		VARDATA varData;
		LPVARDATA lpDataArray;
		LPMATHEXPBSON lpExpBson;
		CInsertBson stInsertBson(&stBson);																							//zhy:优化
		LPINSERTEXECUTEPLANBSON lpInsertPlan;
		LPEXECUTEFIELDBSON *lpFieldBsonMap, lpFieldBson;
		
		lpInsertPlan    = (LPINSERTEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
		lpDataArray     = (LPVARDATA)stBson.ConvertOffset2Addr(lpInsertPlan->m_nDataArrayOffset);
		lpFieldBsonMap  = (LPEXECUTEFIELDBSON*)stBson.ConvertOffset2Addr(lpInsertPlan->m_nFieldMapOffset);;
		memset(lpFieldBsonMap, 0, sizeof(LPEXECUTEFIELDBSON)*lpObjectInfo->m_nFieldNum);
		memset(lpDataArray, 0, sizeof(VARDATA)*lpObjectInfo->m_nFieldNum);
	
		nRet = stBson.ConvertAddrID2Addr((UINT)lpStep->m_nParam1, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpRecordHead = (LPRECORDHEAD)lpAddr;

		nOffset = lpInsertPlan->m_nExcuteFieldOffset;
		for(i = 0; i < lpInsertPlan->m_nExecuteFieldNum; i++)
		{
			lpFieldBson = (LPEXECUTEFIELDBSON)stBson.ConvertOffset2Addr(nOffset);
			lpFieldBsonMap[lpFieldBson->m_bFieldNo - 1] = lpFieldBson;
			if(lpFieldBson->m_nNextOffset != 0)
			{
				nOffset = lpFieldBson->m_nNextOffset; 
			}
		}

		for(i = 0; i < lpObjectInfo->m_nFieldNum; i++)
		{
			if(lpFieldBsonMap[i] == NULL)
			{
				continue;
			}
			lpExpBson = (LPMATHEXPBSON)stBson.ConvertOffset2Addr(lpFieldBsonMap[i]->m_nExpOffset);
			nRet = stExpression.GetExpressionResult(lpExpBson, varData);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpDataArray[i].SetData(varData);
		}
	
		nRet = stInsertBson.BuildBson(lpBaseParam, lpObjectInfo, lpFieldBsonMap, lpDataArray, *lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_UPDATERECORDSET)
	{
		int i;
		BYTE bFieldNo;
		CInsertBson stInsertBson(&stBson);
		LPUPDATERECORDSETPLANBSON lpUpdateRecordsetPlan;
		LPXMLFIELDBSON* lpFieldBsonMap, lpXmlFieldBson;

		lpUpdateRecordsetPlan = (LPUPDATERECORDSETPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
		lpFieldBsonMap = (LPXMLFIELDBSON*)stBson.ConvertOffset2Addr(lpUpdateRecordsetPlan->m_nFieldMapOffset);;
		memset(lpFieldBsonMap, 0, sizeof(LPXMLFIELDBSON)*lpObjectInfo->m_nFieldNum);

		nRet = stBson.ConvertAddrID2Addr((UINT)lpStep->m_nParam1, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpRecordHead = (LPRECORDHEAD)lpAddr;

		lpXmlFieldBson  = (LPXMLFIELDBSON)stBson.ConvertOffset2Addr(lpRecordHead->m_nFieldOffset);
		for(i = 0; i < lpRecordHead->m_bFieldNum; i++)
		{
			bFieldNo = lpXmlFieldBson[i].m_bFieldNo;
			if(bFieldNo != 0)
			{
				lpFieldBsonMap[bFieldNo - 1] = &lpXmlFieldBson[i];
			}
		}
		//将插入的记录进行序列化
		nRet = stInsertBson.BuildBson(lpBaseParam, lpObjectInfo, lpFieldBsonMap, *lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	
	nRet = pFile->InsertData(stBson, lpBaseParam, lpStep);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	return MF_OK;
}

/************************************************************************
	功能说明：
		执行数据删除
	参数说明：
		stBson:Bson对象
		lpParam：公共参数
		lpStep：执行步骤
************************************************************************/
int	CCommonMemObject::ExecuteDeleteData(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep)
{
	int nRet;
	CMemoryFile* pFile;
	LPOBJECTDEF lpObjectInfo;
	LPBASESTEPPARAM lpBaseParam;
	IVirtualMemoryFile* pVirtualFile;

	lpBaseParam = (LPBASESTEPPARAM)lpParam;
	lpObjectInfo = (LPOBJECTDEF)lpBaseParam->m_lpObjectInfo;
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;	
	nRet = pFile->DeleteData(stBson, lpBaseParam, lpStep);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}	

/************************************************************************
	功能说明：
		执行数据更新
	参数说明：
		stBson:Bson对象
		lpParam：公共参数
		stStep：执行步骤
************************************************************************/
int	CCommonMemObject::ExecuteUpdateData(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep)
{
	int i, nRet;
	LPBYTE lpAddr;
	CMemoryFile* pFile;	
	LPOBJECTDEF lpObjectInfo;
	LPRECORDHEAD lpRecordHead;
	LPBASESTEPPARAM lpBaseParam;
	RECORDDATAINFO stRecordInfo;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;

	lpBaseParam = (LPBASESTEPPARAM)lpParam;
	lpObjectInfo = (LPOBJECTDEF)lpBaseParam->m_lpObjectInfo;
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;	

	nRet = stBson.ConvertAddrID2Addr((UINT)lpStep->m_nParam1, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpRecordHead = (LPRECORDHEAD)lpAddr;

	//获取原始记录
	stRecordInfo.m_nDataID	     = lpRecordHead->m_nDataID;
	stRecordInfo.m_nTimestamp    = lpBaseParam->m_nTimestamp;
	stRecordInfo.m_bDataPosition = MF_DATAPOSITION_ROLLBACK;
	nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(stRecordInfo.m_lpRecordBuffer == NULL)
	{
		return MF_COMMON_RECORD_NOTEXIT;
	}
	//创建更新记录
	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_UPDATE)
	{
		CUpdateBson stUpdateBson(&stBson);
		LPUPDATEEXECUTEPLANBSON lpUpdatePlan;
		LPEXECUTEFIELDBSON *lpFieldBsonMap, lpFieldBson, lpFieldBson2;		

		lpUpdatePlan   = (LPUPDATEEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
		lpFieldBsonMap = (LPEXECUTEFIELDBSON*)stBson.ConvertOffset2Addr(lpUpdatePlan->m_nFieldMapOffset);
		memset(lpFieldBsonMap, 0, sizeof(LPEXECUTEFIELDBSON)*lpObjectInfo->m_nFieldNum);

		lpFieldBson  = (LPEXECUTEFIELDBSON)stBson.ConvertOffset2Addr(lpUpdatePlan->m_nExcuteFieldOffset);
		lpFieldBson2 = lpFieldBson;
		for(i = 0; i < (int)lpUpdatePlan->m_nExecuteFieldNum; i++)
		{ 
			lpFieldBsonMap[lpFieldBson2->m_bFieldNo - 1] = lpFieldBson2;
			if(lpFieldBson2->m_nNextOffset != 0)
			{
				lpFieldBson2 = (LPEXECUTEFIELDBSON)stBson.ConvertOffset2Addr(lpFieldBson2->m_nNextOffset);
			}
		}

		//创建更新后的记录
		stUpdateBson.Initial(lpObjectInfo);
		nRet = stUpdateBson.BuildBson(lpRecordHead->m_nRecordLen, lpFieldBsonMap,&stRecordInfo, lpBaseParam);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_UPDATERECORDSET)
	{
		int i;
		CUpdateBson stUpdateBson(&stBson);
		LPUPDATERECORDSETPLANBSON lpUpdateRecordsetPlan; 
		LPXMLFIELDBSON* lpFieldBsonMap, lpXmlFieldBson;

		lpUpdateRecordsetPlan	= (LPUPDATERECORDSETPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
		lpFieldBsonMap			= (LPXMLFIELDBSON*)stBson.ConvertOffset2Addr(lpUpdateRecordsetPlan->m_nFieldMapOffset);;
		memset(lpFieldBsonMap, 0, sizeof(LPEXECUTEFIELDBSON)*lpObjectInfo->m_nFieldNum);

		//获取字段映射表
		lpXmlFieldBson  = (LPXMLFIELDBSON)stBson.ConvertOffset2Addr(lpRecordHead->m_nFieldOffset);
		for(i = 0; i < lpRecordHead->m_bFieldNum; i++)
		{
			if(lpXmlFieldBson[i].m_bModify)
			{
				lpFieldBsonMap[lpXmlFieldBson[i].m_bFieldNo - 1] = &lpXmlFieldBson[i];
			}
		}

		//创建更新后的记录
		stUpdateBson.Initial(lpObjectInfo);
		nRet = stUpdateBson.BuildBson(lpRecordHead->m_nRecordLen, lpFieldBsonMap, &stRecordInfo, lpBaseParam);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	
	//更新记录
	nRet = pFile->UpdateData(stBson, lpBaseParam, lpStep);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	return MF_OK;
}

/************************************************************************
	功能说明：
		执行索引插入
	参数说明：
		stBson:Bson对象
		lpParam：公共参数
		lpStep：执行步骤
************************************************************************/
int CCommonMemObject::ExecuteInsertIndex(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep)
{
	int nRet, i;
	BYTE bFieldNo;
	LPBYTE lpAddr;
	VARDATA varData;
	CMemoryFile* pFile;
	INDEXINFO stIndexInfo;
	CExpression stExpression;
	LPOBJECTDEF lpObjectInfo;
	LPRECORDHEAD lpRecordHead;
	LPBASESTEPPARAM lpBaseParam;
	RECORDDATAINFO stRecordInfo;
	LPINDEXEXECUTEPLAN lpIndexPlan;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;
	LPINDEXCONDITION lpIndexCondition;

 	lpBaseParam  = (LPBASESTEPPARAM)lpParam;
	
	nRet = stBson.ConvertAddrID2Addr((UINT)lpStep->m_nParam1, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpRecordHead = (LPRECORDHEAD)lpAddr;
	
	lpIndexPlan  = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr((UINT)lpStep->m_nParam2);
	lpObjectInfo = (LPOBJECTDEF)lpBaseParam->m_lpObjectInfo;
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;	

	//1.获取关键字值
	stRecordInfo.m_bDataPosition = MF_DATAPOSITION_LOCAL;
	stRecordInfo.m_nTimestamp	 = lpBaseParam->m_nTimestamp;
	stRecordInfo.m_nDataID		 = lpRecordHead->m_nDataID;
	nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(stRecordInfo.m_lpRecordBuffer == NULL)
	{
		return MF_COMMON_RECORD_NOTEXIT;
	}
	
	stExpression.Initial(&stBson, lpObjectInfo);
	
	stIndexInfo.m_stMultiIndex.m_nIndexNum = 0;
	for(i = 0; i < 4; i++)
	{
		bFieldNo = lpIndexPlan->m_bFieldNo[i];
		if(bFieldNo == 0)
		{
			break;
		}
		else
		{
			stIndexInfo.m_stMultiIndex.m_nIndexNum++;
			lpIndexCondition = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];
		}
		nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varData);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpIndexPlan->m_bConstraintType == MF_CONSTRAINT_PRIMARYKEY && varData.m_vt == MF_SYS_FIELDTYPE_NULL)
		{
			return MF_COMMON_INVALID_NULLPRIMARYKEY;
		}

		lpIndexCondition->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
		lpIndexCondition->m_bFieldNo   = bFieldNo;
		lpIndexCondition->m_bFieldType = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;
		lpIndexCondition->m_varCondition2.SetData(varData);
		if(lpIndexPlan->m_bIndexType <= 10)
		{
			break;
		}
	}

	if(lpIndexPlan->m_bIndexType > 10)
	{
		//将DataID作为最后一个关键字
		stIndexInfo.m_stMultiIndex.m_nIndexNum++;
		lpIndexCondition = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];

		lpIndexCondition->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
		lpIndexCondition->m_bFieldType = MF_SYS_FIELDTYPE_BIGINT;
		lpIndexCondition->m_varCondition2.SetData(lpRecordHead->m_nDataID);
	}

	//2.插入索引
	stIndexInfo.m_pBson        = &stBson;
	stIndexInfo.m_nIndexID	   = lpIndexPlan->m_nIndexID;
	stIndexInfo.m_bFileNo	   = lpIndexPlan->m_bFileNo;
	stIndexInfo.m_bIndexType   = lpIndexPlan->m_bIndexType;
	stIndexInfo.m_nDataID      = lpRecordHead->m_nDataID;
	stIndexInfo.m_bFieldNo[0]  = lpIndexPlan->m_bFieldNo[0];
	stIndexInfo.m_bFieldNo[1]  = lpIndexPlan->m_bFieldNo[1];
	stIndexInfo.m_bFieldNo[2]  = lpIndexPlan->m_bFieldNo[2];
	stIndexInfo.m_bFieldNo[3]  = lpIndexPlan->m_bFieldNo[3];

	if(lpIndexPlan->m_bConstraintType == MF_CONSTRAINT_PRIMARYKEY)
	{
		stIndexInfo.m_bUnique = TRUE;
	}
	else if(lpIndexPlan->m_bConstraintType == MF_CONSTRAINT_UNIQUE)
	{
		stIndexInfo.m_bUnique = TRUE;
	}

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	nRet = InsertIndex(&stIndexInfo, lpExecutePlan->m_nObjectID, lpExecutePlan, lpExecutePlan->m_nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		执行索引删除
	参数说明：
		stBson:Bson对象
		lpParam：公共参数
		stStep：执行步骤
************************************************************************/
int CCommonMemObject::ExecuteDeleteIndex(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep)
{
	int nRet, i;
	BYTE bFieldNo;
	LPBYTE lpAddr;
	VARDATA varData;
	CMemoryFile* pFile;
	INDEXINFO stIndexInfo;
	CExpression stExpression;
	LPOBJECTDEF lpObjectInfo;
	LPRECORDHEAD lpRecordHead;
	LPBASESTEPPARAM lpBaseParam;
	RECORDDATAINFO stRecordInfo;
	LPINDEXCONDITION lpIndexField;
	LPINDEXEXECUTEPLAN lpIndexPlan;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;
	
	lpBaseParam   = (LPBASESTEPPARAM)lpParam;
	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	nRet = stBson.ConvertAddrID2Addr((UINT)lpStep->m_nParam1, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpRecordHead = (LPRECORDHEAD)lpAddr;

	lpIndexPlan  = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr((UINT)lpStep->m_nParam2);
	lpObjectInfo = (LPOBJECTDEF)lpBaseParam->m_lpObjectInfo;
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;	

	//1.获取关键字值
	stRecordInfo.m_nTimestamp    = lpBaseParam->m_nTimestamp;
	stRecordInfo.m_bDataPosition = MF_DATAPOSITION_ROLLBACK;
	stRecordInfo.m_nDataID		 = lpRecordHead->m_nDataID;
	nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(stRecordInfo.m_lpRecordBuffer == NULL)
	{
		return MF_COMMON_RECORD_NOTEXIT;
	}
	stExpression.Initial(&stBson, lpObjectInfo);
	stIndexInfo.m_stMultiIndex.m_nIndexNum = 0;
	for(i = 0; i < 4; i++)
	{
		bFieldNo = lpIndexPlan->m_bFieldNo[i];
		if(bFieldNo == 0)
		{
			break;
		}
		else
		{
			stIndexInfo.m_stMultiIndex.m_nIndexNum++;
			lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];
		}	
		nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varData);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
		lpIndexField->m_bFieldNo   = bFieldNo;
		lpIndexField->m_bFieldType = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;;
		lpIndexField->m_varCondition1.SetData(varData);
	}
	//将DataID作为最后一个关键字
	stIndexInfo.m_stMultiIndex.m_nIndexNum++;
	lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];

	lpIndexField->m_bOperator   = MF_EXECUTEPLAN_OPERATOR_EQUAL;
	lpIndexField->m_bFieldType  = MF_SYS_FIELDTYPE_BIGINT;
	lpIndexField->m_varCondition1.SetData(lpRecordHead->m_nDataID);

	//2.删除索引
	stIndexInfo.m_pBson         = &stBson;
	stIndexInfo.m_nIndexID		= lpIndexPlan->m_nIndexID;
	stIndexInfo.m_bFileNo		= lpIndexPlan->m_bFileNo;
	stIndexInfo.m_bIndexType	= lpIndexPlan->m_bIndexType;
	stIndexInfo.m_bFileNo		= lpIndexPlan->m_bFileNo;
	stIndexInfo.m_nDataID       = lpRecordHead->m_nDataID;
	nRet = DeleteIndex(&stIndexInfo, lpExecutePlan, lpExecutePlan->m_nTimestamp);
	if(nRet != MF_OK)
	{
		Trace(_T("ExecuteDeleteIndex"), 0, 0, _T("删除索引失败, 错误码%d"), nRet);
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		执行索引更新的索引插入操作
	参数说明：
		stBson:Bson对象
		lpParam：公共参数
		stStep：执行步骤
************************************************************************/
int	CCommonMemObject::ExecuteUpdateInsertIndex(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep)
{
	BOOL bEqual;
	int nRet, i;
	BYTE bFieldNo;
	LPBYTE lpAddr;
	CMemoryFile* pFile;
	INDEXINFO stIndexInfo;
	LPOBJECTDEF lpObjectInfo;
	CExpression stExpression;
	LPRECORDHEAD lpRecordHead;
	RECORDDATAINFO stRecordInfo;
	LPBASESTEPPARAM lpBaseParam;
	VARDATA varOldKey, varNewKey;
	LPINDEXCONDITION lpIndexField;
	LPINDEXEXECUTEPLAN lpIndexPlan;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpBaseParam		= (LPBASESTEPPARAM)lpParam;
	nRet = stBson.ConvertAddrID2Addr((UINT)lpStep->m_nParam1, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpRecordHead = (LPRECORDHEAD)lpAddr;

	lpIndexPlan  = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr((UINT)lpStep->m_nParam2);
	lpObjectInfo = (LPOBJECTDEF)lpBaseParam->m_lpObjectInfo;
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;	

	bEqual = TRUE;
	stExpression.Initial(&stBson, lpObjectInfo);
	stIndexInfo.m_stMultiIndex.m_nIndexNum = 0;
	for(i = 0; i < 4; i++)
	{
		bFieldNo = lpIndexPlan->m_bFieldNo[i];
		if(bFieldNo == 0)
		{
			break;
		}
		else
		{
			stIndexInfo.m_stMultiIndex.m_nIndexNum++;
			lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];
		}
		//1.获取新关键字值
		stRecordInfo.m_nDataID		 = lpRecordHead->m_nDataID;
		stRecordInfo.m_nTimestamp    = lpBaseParam->m_nTimestamp;
		stRecordInfo.m_bDataPosition = MF_DATAPOSITION_LOCAL;
		nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}	
		if(stRecordInfo.m_lpRecordBuffer == NULL)
		{
			return MF_COMMON_RECORD_NOTEXIT;
		}
		nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varNewKey);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		//2.获取原始关键字值
		stRecordInfo.m_nDataID			= lpRecordHead->m_nDataID;
		stRecordInfo.m_nTimestamp		= lpBaseParam->m_nTimestamp;
		stRecordInfo.m_bDataPosition	= MF_DATAPOSITION_ROLLBACK;
		nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(stRecordInfo.m_lpRecordBuffer == NULL)
		{
			return MF_COMMON_RECORD_NOTEXIT;
		}
		nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varOldKey);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
		lpIndexField->m_bFieldNo   = bFieldNo;
		lpIndexField->m_bFieldType = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;;
		lpIndexField->m_varCondition2.SetData(varNewKey);
		if(varNewKey.m_vt == MF_VARDATA_NULL)
		{
			if(lpIndexPlan->m_bConstraintType == MF_CONSTRAINT_PRIMARYKEY)
			{
				return MF_COMMON_INVALID_NULLPRIMARYKEY;
			}
			else
			{
				return MF_OK;
			}
		}
		
		if(varOldKey != varNewKey)
		{
			bEqual = FALSE;
		}
	}
	//把DataID作为最后一个关键字
	stIndexInfo.m_stMultiIndex.m_nIndexNum++;
	lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];

	lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
	lpIndexField->m_bFieldType = MF_SYS_FIELDTYPE_BIGINT;
	lpIndexField->m_varCondition2.SetData(lpRecordHead->m_nDataID);

	if(!bEqual)
	{
		//插入索引
		stIndexInfo.m_pBson         = &stBson;
		stIndexInfo.m_nIndexID		= lpIndexPlan->m_nIndexID;
		stIndexInfo.m_bFileNo		= lpIndexPlan->m_bFileNo;
		stIndexInfo.m_bIndexType	= lpIndexPlan->m_bIndexType;
		stIndexInfo.m_bFileNo		= lpIndexPlan->m_bFileNo;
		stIndexInfo.m_nDataID		= lpRecordHead->m_nDataID;
		stIndexInfo.m_bFieldNo[0]	= lpIndexPlan->m_bFieldNo[0];
		stIndexInfo.m_bFieldNo[1]	= lpIndexPlan->m_bFieldNo[1];
		stIndexInfo.m_bFieldNo[2]	= lpIndexPlan->m_bFieldNo[2];
		stIndexInfo.m_bFieldNo[3]	= lpIndexPlan->m_bFieldNo[3];

		if(lpIndexPlan->m_bConstraintType == MF_CONSTRAINT_PRIMARYKEY || lpIndexPlan->m_bConstraintType == MF_CONSTRAINT_UNIQUE)
		{
			stIndexInfo.m_bUnique = TRUE;
		}
		
		nRet = InsertIndex(&stIndexInfo, lpExecutePlan->m_nObjectID, lpExecutePlan, lpExecutePlan->m_nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		执行索引更新的索引删除操作
	参数说明：
		stBson:Bson对象
		lpParam：公共参数
		stStep：执行步骤
************************************************************************/
int CCommonMemObject::ExecuteUpdateDeleteIndex(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep)
{
	BOOL bEqual;
	int nRet, i;
	BYTE bFieldNo;
	LPBYTE lpAddr;
	CMemoryFile* pFile;
	INDEXINFO stIndexInfo;
	LPOBJECTDEF lpObjectInfo;
	CExpression stExpression;
	LPRECORDHEAD lpRecordHead;
	RECORDDATAINFO stRecordInfo;
	LPBASESTEPPARAM lpBaseParam;
	VARDATA varOldKey, varNewKey;
	LPINDEXCONDITION lpIndexField;
	LPINDEXEXECUTEPLAN lpIndexPlan;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpBaseParam		= (LPBASESTEPPARAM)lpParam;
	nRet = stBson.ConvertAddrID2Addr((UINT)lpStep->m_nParam1, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpRecordHead = (LPRECORDHEAD)lpAddr;

	lpIndexPlan  = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr((UINT)lpStep->m_nParam2);
	lpObjectInfo = (LPOBJECTDEF)lpBaseParam->m_lpObjectInfo;
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;	

	bEqual = TRUE;
	stExpression.Initial(&stBson, lpObjectInfo);
	stIndexInfo.m_stMultiIndex.m_nIndexNum = 0;
	for(i = 0; i < 4; i++)
	{
		bFieldNo = lpIndexPlan->m_bFieldNo[i];
		if(bFieldNo == 0)
		{
			break;
		}
		else
		{
			stIndexInfo.m_stMultiIndex.m_nIndexNum++;
			lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];
		}
		//1.获取新关键字值
		stRecordInfo.m_nDataID			= lpRecordHead->m_nDataID;
		stRecordInfo.m_nTimestamp		= lpBaseParam->m_nTimestamp;
		stRecordInfo.m_bDataPosition	= MF_DATAPOSITION_LOCAL;
		nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}	
		if(stRecordInfo.m_lpRecordBuffer == NULL)
		{
			return MF_COMMON_RECORD_NOTEXIT;
		}
		nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varNewKey);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		//2.获取原始关键字值
		stRecordInfo.m_nDataID			= lpRecordHead->m_nDataID;
		stRecordInfo.m_nTimestamp		= lpBaseParam->m_nTimestamp;
		stRecordInfo.m_bDataPosition	= MF_DATAPOSITION_ROLLBACK;
		nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(stRecordInfo.m_lpRecordBuffer == NULL)
		{
			return MF_COMMON_RECORD_NOTEXIT;
		}
		nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varOldKey);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
		lpIndexField->m_bFieldNo   = bFieldNo;
		lpIndexField->m_bFieldType = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;;
		lpIndexField->m_varCondition1.SetData(varOldKey);
		if(varOldKey != varNewKey)
		{
			bEqual = FALSE;
		}

		if(varOldKey.m_vt == MF_VARDATA_NULL)
		{
			return MF_OK;
		}
	}
	//把DataID作为最后一个关键字
	stIndexInfo.m_stMultiIndex.m_nIndexNum++;
	lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];

	lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
	lpIndexField->m_bFieldType = MF_SYS_FIELDTYPE_BIGINT;
	lpIndexField->m_varCondition1.SetData(lpRecordHead->m_nDataID);

	if(!bEqual)
	{
		//删除索引
		stIndexInfo.m_pBson         = &stBson;
		stIndexInfo.m_nIndexID		= lpIndexPlan->m_nIndexID;
		stIndexInfo.m_bFileNo		= lpIndexPlan->m_bFileNo;
		stIndexInfo.m_bIndexType	= lpIndexPlan->m_bIndexType;
		stIndexInfo.m_bFileNo		= lpIndexPlan->m_bFileNo;
		stIndexInfo.m_nDataID		= lpRecordHead->m_nDataID;
		stIndexInfo.m_bFieldNo[0]	= lpIndexPlan->m_bFieldNo[0];
		stIndexInfo.m_bFieldNo[1]	= lpIndexPlan->m_bFieldNo[1];
		stIndexInfo.m_bFieldNo[2]	= lpIndexPlan->m_bFieldNo[2];
		stIndexInfo.m_bFieldNo[3]	= lpIndexPlan->m_bFieldNo[3];

		nRet = DeleteIndex(&stIndexInfo, lpExecutePlan, lpExecutePlan->m_nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}
/************************************************************************
	功能说明：
		资源释放
	参数说明：
		stBson：Bson对象
		nRetValue：返回值类型
		stExecutePlanManager：执行计划
************************************************************************/
int CCommonMemObject::ResourceRelease(CServiceBson& stBson, int nRetValue, CExecutePlanManager& stExecutePlanManager)
{
	int nRet,i;
	LPINDEXDEF lpIndex;
	CMemoryFile* pFile;
	LPSTEPINFO lpStepInfo;
	LPBLOCKINFO lpBlockInfo;
	LPOBJECTDEF lpObjectInfo;
	LPSOURCEINFO lpSourceInfo;
	CMemoryHashFile* pHashFile;
	CMemoryBTreeFile* pBTreeFile;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;
	MF_EXECUTEPLAN_CMDTYPE bCommandType;
	CSystemTimestampTransactionManage stTransaction;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	bCommandType  = lpExecutePlan->m_nType;
	lpSourceInfo  = &lpExecutePlan->m_stSourceInfo;
	lpStepInfo    = &lpExecutePlan->m_stStepInfo;
	lpObjectInfo  = stBson.GetObjectInfo();

	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;

	if(nRetValue == MF_OK)
	{
		//执行成功修改记录数
		if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_INSERT)
		{
			pFile->SetObjectData(lpExecutePlan->m_nObjectID, lpExecutePlan, lpExecutePlan->m_bObjectType, lpExecutePlan->m_stSourceInfo.m_nRecordNum, 0, lpExecutePlan->m_nTimestamp);
		}
		else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_DELETE)
		{
			pFile->SetObjectData(lpExecutePlan->m_nObjectID, lpExecutePlan, lpExecutePlan->m_bObjectType, 0, lpExecutePlan->m_stSourceInfo.m_nRecordNum, lpExecutePlan->m_nTimestamp);
		}
		else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_UPDATERECORDSET)
		{
			LPUPDATERECORDSETPLANBSON lpUpdateRecordsetPlan;
			lpUpdateRecordsetPlan = (LPUPDATERECORDSETPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
			pFile->SetObjectData(lpExecutePlan->m_nObjectID, lpExecutePlan, lpExecutePlan->m_bObjectType, lpUpdateRecordsetPlan->m_nInsertStepNum, lpUpdateRecordsetPlan->m_nDeleteStepNum, lpExecutePlan->m_nTimestamp);
		}
	}


	//1.判断返回值类型决定是否需要回滚
	if(nRetValue != MF_OK && bCommandType != MF_EXECUTEPLAN_CMDTYPE_QUERY)
	{
		if(lpStepInfo->m_nStepAddrID != 0)
		{
			nRet = StepRollBack(stBson, stExecutePlanManager, lpObjectInfo);
			if(nRet == MF_OK)
			{
				Trace(_T("StepRollBack"), 0, 700001001, _T("回滚成功，SQL语句：%s"), ((LPBYTE)lpExecutePlan)+lpExecutePlan->m_nSqlOffset);
			}
			else
			{
				Trace(_T("StepRollBack"), MF_TRACE_LEVEL_FAILED, 700001002, _T("回滚失败，错误码%d，SQL语句：%s"), nRet, ((LPBYTE)lpExecutePlan)+lpExecutePlan->m_nSqlOffset);

			}
		}
	}
	else if(bCommandType == MF_EXECUTEPLAN_CMDTYPE_DELETE)
	{
		//块整理
		nRet = pFile->MergeMemory(lpExecutePlan);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
	{
		nRet = CSystemManage::instance().GetMemoryFileInstance(lpIndex->m_bFileNo, pVirtualFile);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpIndex->m_bIndexType <= 10)
		{
			pHashFile = (CMemoryHashFile*)pVirtualFile;
			pHashFile->SetObjectData(lpExecutePlan, lpIndex->m_nIndexID);
		}
		else
		{
			pBTreeFile = (CMemoryBTreeFile*)pVirtualFile;
			pBTreeFile->SetObjectData(lpExecutePlan, lpIndex->m_nIndexID);
		}
	}

	//2.解锁块
	if(lpSourceInfo->m_nBlockOffset != 0)
	{
		lpBlockInfo = (LPBLOCKINFO)stBson.ConvertOffset2Addr(lpSourceInfo->m_nBlockOffset);
		CSystemManage::instance().UnLockObject(lpExecutePlan, lpObjectInfo, MF_MAX_BLOCKINFO_NUM, lpBlockInfo);
	}

	//3.清空事务链表
	for(i = 0; i < lpObjectInfo->m_bMaxTransactionNum; i++)
	{
		if(lpObjectInfo->m_lpTimestampArray[i] == lpSourceInfo->m_nTimestamp)
		{
			lpObjectInfo->m_lpTimestampArray[i] = 0;
		}
	}

	//4.释放临界区资源
	for(i = 0; i < 20; i++)
	{
		if(lpExecutePlan->m_pCritStack[i] != 0)
		{
			::LeaveCriticalSection((LPCRITICAL_SECTION)lpExecutePlan->m_pCritStack[i]);
			lpExecutePlan->m_pCritStack[i] = 0;
		}
	}

	//5.事务提交
	stTransaction.CommitTransaction(lpExecutePlan->m_nTimestamp);
	return MF_OK;
}

/************************************************************************
	功能说明：
		步骤回滚
	参数说明：
		stBson：BSON对象
		stExecutePlanManager：执行计划
		lpObjectInfo：对象信息
************************************************************************/
int CCommonMemObject::StepRollBack(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPOBJECTDEF lpObjectInfo)
{
	BOOL bEqual;
	BYTE bFieldNo;
	LPBYTE lpAddr;
	int i, j, nRet;
	CMemoryFile* pFile;
	INDEXINFO stIndexInfo;
	CExpression stExpression;
	LPRECORDHEAD lpRecordHead;
	LPEXECUTESTEP lpExecuteStep;
	RECORDDATAINFO stRecordInfo;
	LPINDEXCONDITION lpIndexField;
	LPINDEXEXECUTEPLAN lpIndexPlan;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;
	VARDATA varData, varNewKey, varOldKey;

	lpExecutePlan = (LPEXECUTEPLANBSON)stExecutePlanManager.GetExecutePlan();
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;

	stRecordInfo.m_nTimestamp = lpExecutePlan->m_nTimestamp;
	nRet = stExecutePlanManager.Move2Step(lpExecutePlan->m_stStepInfo.m_nCurrentStepNo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	stExpression.Initial(&stBson, lpObjectInfo);
	stExecutePlanManager.Move2Step(lpExecutePlan->m_stStepInfo.m_nCurrentStepNo);
	for(i = lpExecutePlan->m_stStepInfo.m_nCurrentStepNo; i >= 0; i--)
	{
		nRet = stExecutePlanManager.PreStep(lpExecuteStep);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = stBson.ConvertAddrID2Addr((UINT)lpExecuteStep->m_nParam1, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpRecordHead = (LPRECORDHEAD)lpAddr;
		switch(lpExecuteStep->m_bStepType)
		{
		case MF_EXECUTE_STEP_INSERTDATA:
			nRet = pFile->InsertRollBack(lpRecordHead->m_nDataID, lpExecutePlan->m_nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			break;
		case MF_EXECUTE_STEP_DELETEDATA:
			nRet = pFile->DeleteRollBack(lpRecordHead->m_nDataID, lpExecutePlan->m_nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			break;
		case MF_EXECUTE_STEP_UPDATEDATA:
			nRet = pFile->UpdateRollBack(lpExecutePlan, lpRecordHead->m_nDataID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			break;
		case MF_EXECUTE_STEP_INSERTINDEX:
			lpIndexPlan = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr((UINT)lpExecuteStep->m_nParam2);
			stRecordInfo.m_bDataPosition = MF_DATAPOSITION_LOCAL;
			stRecordInfo.m_nDataID		 = lpRecordHead->m_nDataID;
			nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(stRecordInfo.m_lpRecordBuffer == NULL)
			{
				return MF_COMMON_RECORD_NOTEXIT;
			}

			stIndexInfo.clear();
			for(j = 0; j < 4; j++)
			{
				bFieldNo = lpIndexPlan->m_bFieldNo[j];
				if(bFieldNo == 0)
				{
					break;
				}
				else
				{
					stIndexInfo.m_stMultiIndex.m_nIndexNum++;
					lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[j];
				}
				nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varData);
				if(nRet != MF_OK)
				{
					return nRet;
				}

				lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
				lpIndexField->m_bFieldNo   = bFieldNo;
				lpIndexField->m_bFieldType = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;
				lpIndexField->m_varCondition1.SetData(varData);
			}
			stIndexInfo.m_stMultiIndex.m_nIndexNum++;
			lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[j];

			lpIndexField->m_bOperator   = MF_EXECUTEPLAN_OPERATOR_EQUAL;
			lpIndexField->m_bFieldType  = MF_SYS_FIELDTYPE_BIGINT;
			lpIndexField->m_varCondition1.SetData(lpRecordHead->m_nDataID);	

			stIndexInfo.m_pBson         = &stBson;
			stIndexInfo.m_nIndexID		= lpIndexPlan->m_nIndexID;
			stIndexInfo.m_bFileNo		= lpIndexPlan->m_bFileNo;
			stIndexInfo.m_bIndexType	= lpIndexPlan->m_bIndexType;
			stIndexInfo.m_bFileNo		= lpIndexPlan->m_bFileNo;
			stIndexInfo.m_nDataID		= lpRecordHead->m_nDataID;
			stIndexInfo.m_bFieldNo[0]	= lpIndexPlan->m_bFieldNo[0];
			stIndexInfo.m_bFieldNo[1]	= lpIndexPlan->m_bFieldNo[1];
			stIndexInfo.m_bFieldNo[2]	= lpIndexPlan->m_bFieldNo[2];
			stIndexInfo.m_bFieldNo[3]	= lpIndexPlan->m_bFieldNo[3];

			nRet = DeleteIndex(&stIndexInfo, lpExecutePlan, lpExecutePlan->m_nTimestamp);
			if(nRet != MF_OK)
			{
				Trace(_T("CCommonMemObject::StepRollBack"), 0, 0, _T("回滚时，删除索引失败，错误码%d"), nRet);
			}
			break;
		case MF_EXECUTE_STEP_UPDATEINSERTINDEX:
			lpIndexPlan = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr((UINT)lpExecuteStep->m_nParam2);

			bEqual = TRUE;
			stIndexInfo.clear();
			for(j = 0; j < 4; j++)
			{
				bFieldNo = lpIndexPlan->m_bFieldNo[j];
				if(bFieldNo == 0)
				{
					break;
				}
				else
				{
					stIndexInfo.m_stMultiIndex.m_nIndexNum++;
					lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[j];
				}

				//获取当前关键字
				stRecordInfo.m_nDataID		 = lpRecordHead->m_nDataID;
				stRecordInfo.m_bDataPosition = MF_DATAPOSITION_LOCAL;
				nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				if(stRecordInfo.m_lpRecordBuffer == NULL)
				{
					return MF_COMMON_RECORD_NOTEXIT;
				}
				nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varNewKey);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				
				//获取原始关键字
				stRecordInfo.m_nDataID		 = lpRecordHead->m_nDataID;
				stRecordInfo.m_nTimestamp	 = lpExecutePlan->m_nTimestamp;	
				stRecordInfo.m_bDataPosition = MF_DATAPOSITION_ROLLBACK;
				nRet =pFile->GetRecordBuffer(stBson, &stRecordInfo);
				if(nRet != MF_OK)
				{
					return MF_OK;
				}
				if(stRecordInfo.m_lpRecordBuffer == NULL)
				{
					return MF_COMMON_RECORD_NOTEXIT;
				}
				nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varOldKey);
				if(nRet != MF_OK)
				{
					return nRet;
				}

				lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
				lpIndexField->m_bFieldNo   = bFieldNo;
				lpIndexField->m_bFieldType = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;
				lpIndexField->m_varCondition1.SetData(varNewKey);
				if(varOldKey != varNewKey)
				{
					bEqual = FALSE;
				}
			}
			stIndexInfo.m_stMultiIndex.m_nIndexNum++;
			lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[j];

			lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
			lpIndexField->m_bFieldType = MF_SYS_FIELDTYPE_BIGINT;
			lpIndexField->m_varCondition1.SetData(lpRecordHead->m_nDataID);

			stIndexInfo.m_pBson         = &stBson;
			stIndexInfo.m_nIndexID		= lpIndexPlan->m_nIndexID;
			stIndexInfo.m_bFileNo		= lpIndexPlan->m_bFileNo;
			stIndexInfo.m_bIndexType	= lpIndexPlan->m_bIndexType;
			stIndexInfo.m_bFileNo		= lpIndexPlan->m_bFileNo;
			stIndexInfo.m_nDataID		= lpRecordHead->m_nDataID;

			stIndexInfo.m_bFieldNo[0]	= lpIndexPlan->m_bFieldNo[0];
			stIndexInfo.m_bFieldNo[1]	= lpIndexPlan->m_bFieldNo[1];
			stIndexInfo.m_bFieldNo[2]	= lpIndexPlan->m_bFieldNo[2];
			stIndexInfo.m_bFieldNo[3]	= lpIndexPlan->m_bFieldNo[3];
			if(!bEqual)
			{
				DeleteIndex(&stIndexInfo, lpExecutePlan, lpExecutePlan->m_nTimestamp);
			}
			break;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		执行步骤
	参数说明：
		stBson:Bson对象
		lpParam:公共参数
		stStep：执行步骤
************************************************************************/
int CCommonMemObject::ExecuteStep(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep, int &lAffectCount)
{
	int nRet;
	switch(lpStep->m_bStepType)
	{
	case MF_EXECUTE_STEP_INSERTDATA:
		lAffectCount++;
		nRet = ExecuteInsertData(stBson, lpParam, lpStep);
		break;
	case MF_EXECUTE_STEP_DELETEDATA:
		lAffectCount++;
		nRet = ExecuteDeleteData(stBson, lpParam, lpStep);
		break;
	case MF_EXECUTE_STEP_UPDATEDATA:
		lAffectCount++;
		nRet = ExecuteUpdateData(stBson, lpParam, lpStep);
		break;
	case MF_EXECUTE_STEP_INSERTINDEX:
		nRet = ExecuteInsertIndex(stBson, lpParam, lpStep);
		break;
	case MF_EXECUTE_STEP_DELETEINDEX:
		nRet = ExecuteDeleteIndex(stBson, lpParam, lpStep);
		break;
	case MF_EXECUTE_STEP_UPDATEINSERTINDEX:
		nRet = ExecuteUpdateInsertIndex(stBson, lpParam, lpStep);
		break;
	case MF_EXECUTE_STEP_UPDATEDELETEINDEX:
		nRet = ExecuteUpdateDeleteIndex(stBson, lpParam, lpStep);
		break;
	default:
		return MF_COMMON_INVALID_STEPTYPE;
	}
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		执行命令
	参数说明：
		stBson：BSON对象
		stExecutePlanManager：执行计划对象
		lAffectCount：影响行数
************************************************************************/
int CCommonMemObject::ExecuteCommand(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_INSERT)
	{
		nRet = Insert(stBson, stExecutePlanManager, lAffectCount, lpExecuteInfo);
	}
	else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_UPDATE)
	{
		nRet = Update(stBson, stExecutePlanManager, lAffectCount, lpExecuteInfo);
	}
	else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_DELETE)
	{
		nRet = Delete(stBson, stExecutePlanManager, lAffectCount, lpExecuteInfo);
	}
	else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_QUERY)
	{
		//返回执行结果行数
	}
	if(nRet != MF_OK)
	{
		return nRet;
	}
	else
	{
		return MF_OK;
	}
}

/************************************************************************
	功能说明：
		获取结果集
	参数说明：
		stBson：BSON对象
		stExecutePlanManager：执行计划对象
		lpBsonRs：结果集Buffer
		nBsonRsSize：结果集Buffer大小
************************************************************************/
int CCommonMemObject::GetRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet, nDataNum;
	QUERYINFO stQueryInfo;
	LPOBJECTDEF lpObjectInfo;
	long long* lpTransactionArray;
	LPEXECUTEPLANBSON lpExecutePlan;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	CRecordSetBson stRecordsetBson(&stBson);
	CExecuteDataID stDataIDContainer(&stBson);

	lpExecutePlan		= stExecutePlanManager.GetExecutePlan();
	lpTransactionArray	= (long long*)stBson.GetPtrFromTempBuffer(lpExecutePlan->m_nTransactionOffset);
	TRANSACTIONARRAY stTransactionArray(lpExecutePlan->m_nTransactionNum, lpTransactionArray);
	
	if(lpExecutePlan->m_nType != MF_EXECUTEPLAN_CMDTYPE_QUERY)
	{
		return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
	}

	if(lpExecutePlan->m_nCommandOffset == 0)
	{
		return MF_INNER_POINTER_NULL;
	}
	lpQueryPlan			= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	lpCommonCondition	= (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	lpObjectInfo		= stBson.GetObjectInfo();
	
	//获取DataID
	if(lpQueryPlan->m_bQueryType == MF_QUERY_COUNTALL)
	{
		nRet = GetDataNum(lpExecutePlan, lpObjectInfo, &stTransactionArray, nDataNum);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		stDataIDContainer.resize(nDataNum);
	}
	else if(lpQueryPlan->m_bQueryType == MF_QUERY_NULL)
	{
		//恒为假，什么都不做
	}
	else if(lpQueryPlan->m_bQueryType == MF_QUERY_NORMAL)
	{
		stQueryInfo.m_bPagingType   = lpQueryPlan->m_bPageType;
		stQueryInfo.m_lpObjectInfo	= lpObjectInfo;
		stQueryInfo.m_nIndexOffset  = lpCommonCondition->m_nIndexOffset;
		stQueryInfo.m_nWhereOffset  = lpCommonCondition->m_nWhereOffset;
		stQueryInfo.m_nPageNo       = lpQueryPlan->m_nPageNo;
		stQueryInfo.m_nPageSize     = lpQueryPlan->m_nPageSize;
		stQueryInfo.m_nTimestamp    = lpExecutePlan->m_nTimestamp;
		stQueryInfo.m_dwWhereHash   = lpExecutePlan->m_dwWhereHash;
		stQueryInfo.m_lpTransactionArray = &stTransactionArray;

		if(lpQueryPlan->m_bPageType == MF_PAGING_NORMAL)
		{
			//常规分页模式
			nRet = GetDataIDByPage(stBson, &stQueryInfo, &stDataIDContainer, lpExecuteInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}		
		}
		else
		{
			//不分页模式或FIRST分页模式
			nRet = GetRecordDataID(stBson, &stQueryInfo, &stDataIDContainer, lpExecuteInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}

	QueryPerformanceCounter(&lpExecuteInfo->m_liIndexSearchEnd);
	//从符合条件的结果集中找到所查询的字段，并创建查询结果集Bson
	nRet = stRecordsetBson.Initial(MF_OBJECT_COMMON);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	nRet = stRecordsetBson.BuildBson(lpQueryPlan, lpExecutePlan->m_nTimestamp, &stDataIDContainer, lpBsonRs, nBsonRsSize);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取结果集
	参数说明：
		stBson：BSON对象
		stExecutePlanManager：执行计划对象
		lpExecuteInfo：统计信息
************************************************************************/
int CCommonMemObject::UpdateRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	LPSTEPINFO lpStepInfo;
	LPOBJECTDEF lpObjectInfo;
	int	i, nRet, nAffectCount;
	LPEXECUTESTEP lpExecuteStep;
	LPBASESTEPPARAM lpBaseParam;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(lpExecutePlan->m_nType != MF_EXECUTEPLAN_CMDTYPE_UPDATERECORDSET)
	{
		return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
	}
	if(lpExecutePlan->m_nCommandOffset == 0)
	{
		return MF_INNER_POINTER_NULL;
	}
	nRet = CSystemManage::instance().GetObjectInfo(lpExecutePlan->m_nObjectID, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	lpBaseParam					= &lpExecutePlan->m_stBaseParam;
	lpBaseParam->m_bRecordType	= lpExecutePlan->m_stSourceInfo.m_bRecordType;
	lpBaseParam->m_lpObjectInfo	= (long long)lpObjectInfo;
	lpBaseParam->m_nTimestamp	= lpExecutePlan->m_nTimestamp;

	//2.执行步骤
	nAffectCount = 0;
	lpStepInfo = &lpExecutePlan->m_stStepInfo;
	stExecutePlanManager.Move2Step();
	for(i = 0; i < (int)lpStepInfo->m_nExecuteStepNum; i++)
	{
		nRet = stExecutePlanManager.NextStep(lpExecuteStep);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = ExecuteStep(stBson, lpBaseParam, lpExecuteStep, nAffectCount);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpStepInfo->m_nCurrentStepNo = i;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		插入的预处理操作
	参数说明：
		stBson：BSON对象
		stExecutePlanManager：执行计划
		lpExecuteInfo：统计信息
************************************************************************/
int CCommonMemObject::PreprocessInsert(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	BYTE bFieldNo;
	VARDATA varData;
	LPINDEXDEF lpIndex;
	LPVARDATA lpDataArray;
	LPSTEPINFO lpStepInfo;
	LPMATHEXPBSON lpExpBson;
	LPOBJECTDEF lpObjectInfo;
	CExpression stExpression;
	LPSOURCEINFO lpSourceInfo;
	BLOCKINFO arBlockInfo[20];
	LPRECORDHEAD lpRecordHead;
	UINT nAddrID, nIndexOffset;
	LPEXECUTESTEP lpExecuteStep;
	LPINDEXEXECUTEPLAN lpIndexPlan;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;
	CInsertBson stInsertBson(&stBson);						
	LPINSERTEXECUTEPLANBSON lpInsertPlan;
	int nRet, i, nFieldDataLen, nOffset, nRecordLen;
	LPEXECUTEFIELDBSON lpFieldBson, *lpFieldBsonMap;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	lpInsertPlan  = (LPINSERTEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	lpSourceInfo  = &lpExecutePlan->m_stSourceInfo;
	lpSourceInfo->m_nTimestamp = lpExecutePlan->m_nTimestamp;
	memset(arBlockInfo, 0, sizeof(arBlockInfo));

	//1.根据ObjectID获取表的相关信息
	lpObjectInfo  = stBson.GetObjectInfo();
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	stExpression.Initial(&stBson, lpObjectInfo);

	//2.获取字段映射表
	lpFieldBsonMap = (LPEXECUTEFIELDBSON*)stBson.ConvertOffset2Addr(lpInsertPlan->m_nFieldMapOffset);
	memset(lpFieldBsonMap, 0, lpObjectInfo->m_nFieldNum*sizeof(LPEXECUTEFIELDBSON*));

	nOffset = lpInsertPlan->m_nExcuteFieldOffset;
	for(i = 0; i < lpInsertPlan->m_nExecuteFieldNum; i++)
	{
		lpFieldBson = (LPEXECUTEFIELDBSON)stBson.ConvertOffset2Addr(nOffset);
		lpFieldBsonMap[lpFieldBson->m_bFieldNo - 1] = lpFieldBson;
		if(lpFieldBson->m_nNextOffset != 0)
		{
			nOffset = lpFieldBson->m_nNextOffset; 
		}
	}

	//3.对表结构进行非空检验(即表结构中的非空列必须出现在执行计划列中)
	for(i = 0; i < lpObjectInfo->m_nFieldNum; i++)
	{
		if(0 == lpObjectInfo->m_lpField[i].m_bAllowNull)
		{
			if(lpFieldBsonMap[i] == NULL)
			{
				return MF_EXECUTEINSERT_INVALID_NULLFIELD_ERROR;
			}
			else
			{
				lpExpBson = (LPMATHEXPBSON)stBson.ConvertOffset2Addr(lpFieldBsonMap[i]->m_nExpOffset);
				if(lpExpBson->m_bValType == MF_SYS_FIELDTYPE_NULL)
				{
					return MF_EXECUTEINSERT_INVALID_NULLFIELD_ERROR;
				}
			}
		}
	}

	//4.获取插入字段的长度
	lpDataArray = (LPVARDATA)stBson.ConvertOffset2Addr(lpInsertPlan->m_nDataArrayOffset);
	for(i = 0; i < lpObjectInfo->m_nFieldNum; i++)
	{
		if(lpFieldBsonMap[i] == NULL)
		{
			lpDataArray[i].m_vt = 0;
			continue;
		}

		bFieldNo = lpFieldBsonMap[i]->m_bFieldNo;
		if(lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_CHAR || lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_VARCHAR || lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_CLOB)
		{
			lpExpBson = (LPMATHEXPBSON)stBson.ConvertOffset2Addr(lpFieldBsonMap[i]->m_nExpOffset);
			if(lpExpBson == NULL)
			{
				return MF_EXECUTEINSERT_INVALID_EXPRESSION_ERROR;
			}
			//字符串需要计算表达式的值来获取长度
			nRet = stExpression.GetExpressionResult(lpExpBson, varData);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			
			//定长字符串需要判断长度是否正确
			if(lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_CHAR)
			{
				nFieldDataLen = lpObjectInfo->m_lpField[bFieldNo - 1].m_bCharLen + 1;
				if(varData.m_nStrLen > nFieldDataLen)
				{
					return MF_COMMON_INVALID_STRINGLEN;
				}
			}
		}
		else
		{
			//非字符串类型只需要将表达式的类型赋值给varData，在GetBsonLen函数中会直接根据数据类型获取数据长度
			varData.m_vt = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;
		}
		lpDataArray[i].SetData(varData);
	}
	nRecordLen = stInsertBson.GetBsonLen(lpObjectInfo, lpDataArray, lpSourceInfo->m_bRecordType);
	if(nRecordLen == -1)
	{
		return MF_CREATEPLAN_GETRECORDLEN_FAILED;
	}

	nRet = stBson.AllocRecord(lpRecordHead, nAddrID);
	if(nRet != MF_OK)
	{
		return nRet; 
	}
	lpSourceInfo->m_nRecordAddrID = nAddrID;
	lpSourceInfo->m_nRecordNum	  = 1;
	lpSourceInfo->m_bRecordType   = MF_RECORD_COMMON;
	lpRecordHead->m_nRecordLen    = nRecordLen;
	lpRecordHead->m_bType		  = MF_EXECUTE_STEP_INSERTDATA;
	//5.给对象加共享锁，并将插入记录与对应DataID绑定
	nRet = CSystemManage::instance().LockObject(lpExecutePlan, lpObjectInfo, MF_LOCK_STATUS_SHARE, MF_LOCK_OUTOFTIME);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	nRet = ((CMemoryFile*)pVirtualFile)->BindDataID(stExecutePlanManager, 1, arBlockInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//6.创建插入步骤
	lpStepInfo = &lpExecutePlan->m_stStepInfo;
	lpStepInfo->m_nExecuteStepNum = lpInsertPlan->m_nIndexNum + 1;
	nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpStepInfo->m_nStepAddrID = nAddrID;

	//步骤1：插入数据
	lpExecuteStep->m_bStepType = MF_EXECUTE_STEP_INSERTDATA;
	lpExecuteStep->m_nParam1   = lpSourceInfo->m_nRecordAddrID;

	//步骤2：插入索引
	nIndexOffset = lpInsertPlan->m_nInsertIndexOffset;
	while(nIndexOffset)
	{
		nRet   = stBson.AllocStep(lpExecuteStep, nAddrID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpIndexPlan = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(nIndexOffset);

		lpExecuteStep->m_bStepType	   = MF_EXECUTE_STEP_INSERTINDEX;
		lpExecuteStep->m_nParam1	   = lpSourceInfo->m_nRecordAddrID;
		lpExecuteStep->m_nParam2	   = nIndexOffset;

		nIndexOffset = lpIndexPlan->m_nNextOffset;
	}

	//修改各类文件头时间戳
	((CMemoryFile*)pVirtualFile)->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
	for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
	{
		nRet = CSystemManage::instance().GetMemoryFileInstance(lpIndex->m_bFileNo, pVirtualFile);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(lpIndex->m_bIndexType >= 1 && lpIndex->m_bIndexType <= 6)
		{
			((CMemoryHashFile*)pVirtualFile)->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
		}
		else if(lpIndex->m_bIndexType >= 11 && lpIndex->m_bIndexType <= 16)
		{
			((CMemoryBTreeFile*)pVirtualFile)->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
		}
	}

	lpExecutePlan->m_nTotalDataSize			= stBson.GetExecutePlanDataSize();
	lpExecutePlan->m_nFreeSectionAddrID		= stBson.GetFreeSectionAddrID();
	lpExecutePlan->m_nSectionStartOffset	= stBson.GetSectionStartOffset();
	lpExecutePlan->m_nBsonDataSize			= stBson.GetBsonDataSize();

	return MF_OK;
}

/************************************************************************
	功能说明：
		删除的预处理操作
	参数说明：
		stBson：BSON对象
		stExecutePlanManager：执行计划
		lpExecuteInfo：统计信息
************************************************************************/
int CCommonMemObject::PreprocessDelete(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int i, nRet;
	long long nDatID;
	CMemoryFile* pFile;
	UINT nRecordAddrID;
	LPINDEXDEF lpIndex;
	QUERYINFO stQueryInfo;
	LPSTEPINFO lpStepInfo;
	LPBLOCKINFO lpBlockInfo;
	LPOBJECTDEF lpObjectInfo;
	LPRECORDHEAD lpRecordHead;
	LPSOURCEINFO lpSourceInfo;
	UINT nAddrID, nIndexOffset;
	LPEXECUTESTEP lpExecuteStep;
	long long* lpTransactionArray;
	LPINDEXEXECUTEPLAN lpIndexPlan;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;
	LPDELETEEXECUTEPLANBSON lpDeletePlan;
	CExecuteDataID stDataIDContainer(&stBson);

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	lpDeletePlan  = (LPDELETEEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	lpSourceInfo  = &lpExecutePlan->m_stSourceInfo;
	lpSourceInfo->m_nTimestamp = lpExecutePlan->m_nTimestamp;

	lpTransactionArray = (long long*)stBson.GetPtrFromTempBuffer(lpExecutePlan->m_nTransactionOffset);
	TRANSACTIONARRAY stTransactionArray(lpExecutePlan->m_nTransactionNum, lpTransactionArray);

	//1.根据ObjectID获取表的相关信息
	lpObjectInfo  = stBson.GetObjectInfo();

	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile; 

	stQueryInfo.m_nIndexOffset       = lpDeletePlan->m_nIndexOffset;
	stQueryInfo.m_nConnOffset        = 0;
	stQueryInfo.m_nWhereOffset		 = lpDeletePlan->m_nWhereOffset;
	stQueryInfo.m_lpObjectInfo       = lpObjectInfo;
	stQueryInfo.m_lpTransactionArray = &stTransactionArray;
	stQueryInfo.m_bPagingType		 = MF_PAGING_FIRST;
	stQueryInfo.m_nPageNo			 = 1;
	stQueryInfo.m_nPageSize			 = stExecutePlanManager.GetPageSize();
	stQueryInfo.m_nTimestamp         = lpSourceInfo->m_nTimestamp;
	nRet = GetRecordDataID(stBson, &stQueryInfo, &stDataIDContainer, lpExecuteInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//2.锁块
	lpBlockInfo = (LPBLOCKINFO)stBson.ConvertOffset2Addr(lpSourceInfo->m_nBlockOffset);
	stDataIDContainer.MoveFirst();
	for(i = 0; i < (int)stDataIDContainer.size(); i++)
	{
		nRet = stDataIDContainer.NextRecordHead(lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = LockBlock(stBson, lpObjectInfo, lpRecordHead->m_nDataID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	
	//记录上锁块信息
	for(i = 0; i < MF_MAX_BLOCKINFO_NUM; i++)
	{
		if(lpBlockInfo[i].m_nBlockNo != 0)
		{
			lpBlockInfo[i].m_bSource    = MF_SOURCE_FROM_EXISTBLOCK;
			lpBlockInfo[i].m_bObjectType= MF_OBJECT_COMMON;
			lpBlockInfo[i].m_bAlloc     = 0;
		}
	}

	//3.数据备份
	stDataIDContainer.MoveFirst();
	for(i = 0; i < (int)stDataIDContainer.size(); i++)
	{
		stDataIDContainer.NextDataID(nDatID);
		nRet = pFile->DataBackUp(nDatID, lpSourceInfo->m_nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//4.分配空间存放DataID
	lpSourceInfo->m_nRecordAddrID = stDataIDContainer.GetDataIDAddr();
	lpSourceInfo->m_nRecordNum    = stDataIDContainer.size();	
	lpSourceInfo->m_bRecordType   = MF_RECORD_COMMON;
	
	//5.创建删除步骤
	lpStepInfo = &lpExecutePlan->m_stStepInfo;
	lpStepInfo->m_nExecuteStepNum = lpDeletePlan->m_nIndexNum*lpSourceInfo->m_nRecordNum + lpSourceInfo->m_nRecordNum;
	
	stExecutePlanManager.Move2FirstRecord();
	for(i = 0; i < (int)lpSourceInfo->m_nRecordNum; i++)
	{
		//步骤：删除数据
		nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpStepInfo->m_nStepAddrID == 0)
		{
			lpStepInfo->m_nStepAddrID = nAddrID;
		}

		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		lpExecuteStep->m_bStepType	   = MF_EXECUTE_STEP_DELETEDATA;
		lpExecuteStep->m_nParam1	   = nRecordAddrID;
	}

	stExecutePlanManager.Move2FirstRecord();
	for(i = 0; i < (int)lpSourceInfo->m_nRecordNum; i++)
	{
		//步骤：删除索引
		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		nIndexOffset = lpDeletePlan->m_nDeleteIndexOffset;
		while(nIndexOffset)
		{
			nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpIndexPlan = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(nIndexOffset);

			lpExecuteStep->m_bStepType		= MF_EXECUTE_STEP_DELETEINDEX;
			lpExecuteStep->m_nParam1		= nRecordAddrID;
			lpExecuteStep->m_nParam2		= nIndexOffset;

			nIndexOffset = lpIndexPlan->m_nNextOffset;
		}
	}

	//修改各类文件头时间戳
	pFile->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
	for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
	{
		nRet = CSystemManage::instance().GetMemoryFileInstance(lpIndex->m_bFileNo, pVirtualFile);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(lpIndex->m_bIndexType >= 1 && lpIndex->m_bIndexType <= 6)
		{
			((CMemoryHashFile*)pVirtualFile)->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
		}
		else if(lpIndex->m_bIndexType >= 11 && lpIndex->m_bIndexType <= 16)
		{
			((CMemoryBTreeFile*)pVirtualFile)->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
		}
	}

	lpExecutePlan->m_nTotalDataSize			= stBson.GetExecutePlanDataSize();
	lpExecutePlan->m_nBsonDataSize			= stBson.GetBsonDataSize();
	lpExecutePlan->m_nFreeSectionAddrID		= stBson.GetFreeSectionAddrID();
	lpExecutePlan->m_nSectionStartOffset	= stBson.GetSectionStartOffset();
	return MF_OK;
}

/************************************************************************
	功能说明：
		更新的预处理操作
	参数说明：
		stBson：BSON对象
		stExecutePlanManager：执行计划
		lpExecuteInfo：统计信息
************************************************************************/
int CCommonMemObject::PreprocessUpdate(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet, j;
	long long nDataID;
	CMemoryFile* pFile;
	LPINDEXDEF lpIndex;
	QUERYINFO stQueryInfo;
	LPSTEPINFO lpStepInfo;
	LPBLOCKINFO lpBlockInfo;
	LPMATHEXPBSON lpExpBson;
	LPOBJECTDEF lpObjectInfo;
	LPRECORDHEAD lpRecordHead;
	LPSOURCEINFO lpSourceInfo;
	LPEXECUTESTEP lpExecuteStep;
	RECORDDATAINFO stRecordInfo;
	long long* lpTransactionArray;
	LPINDEXEXECUTEPLAN lpIndexPlan;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;
	CUpdateBson stUpdateBson(&stBson);
	LPUPDATEEXECUTEPLANBSON lpUpdatePlan;
	CExecuteDataID stDataIDContainer(&stBson);
	UINT nAddrID, nRecordAddrID, nIndexOffset, i;
	LPEXECUTEFIELDBSON lpFieldBson, lpTempFieldBson, *lpFieldBsonMap;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	lpUpdatePlan  = (LPUPDATEEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	lpSourceInfo  = &lpExecutePlan->m_stSourceInfo;
	lpSourceInfo->m_nTimestamp = lpExecutePlan->m_nTimestamp;	

	lpTransactionArray = (long long*)stBson.GetPtrFromTempBuffer(lpExecutePlan->m_nTransactionOffset);
	TRANSACTIONARRAY stTransactionArray(lpExecutePlan->m_nTransactionNum, lpTransactionArray);
	
	//1.根据ObjectID获取表的相关信息
	lpObjectInfo  = stBson.GetObjectInfo();
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile; 

	//2.获取更新的字段信息
	if(lpUpdatePlan->m_nExcuteFieldOffset != 0)
	{
		lpFieldBson = (LPEXECUTEFIELDBSON)stBson.ConvertOffset2Addr(lpUpdatePlan->m_nExcuteFieldOffset);
	}
	else
	{
		return MF_EXECUTEUPDATE_INVALID_FIELD_ERROR;
	}

	//获取字段映射表
	lpFieldBsonMap  = (LPEXECUTEFIELDBSON*)stBson.ConvertOffset2Addr(lpUpdatePlan->m_nFieldMapOffset);
	lpTempFieldBson = lpFieldBson;
	for(j = 0; j < (int)lpUpdatePlan->m_nExecuteFieldNum; j++)
	{ 
		lpFieldBsonMap[lpTempFieldBson->m_bFieldNo - 1] = lpTempFieldBson;
		if(lpTempFieldBson->m_nNextOffset != 0)
		{
			lpTempFieldBson = (LPEXECUTEFIELDBSON)stBson.ConvertOffset2Addr(lpTempFieldBson->m_nNextOffset);
		}
	}

	//对参与更新的字段进行非空判断
	for(j = 0; j < lpObjectInfo->m_nFieldNum; j++)
	{
		if(0 == lpObjectInfo->m_lpField[j].m_bAllowNull && lpFieldBsonMap[j] != NULL)
		{
			lpExpBson = (LPMATHEXPBSON)stBson.ConvertOffset2Addr(lpFieldBsonMap[j]->m_nExpOffset);
			if(lpExpBson->m_bValType == MF_SYS_FIELDTYPE_NULL)
			{
				return MF_EXECUTEINSERT_INVALID_NULLFIELD_ERROR;
			}
		}
	}

	//3.获取更新记录的DataID
	stQueryInfo.m_nIndexOffset			= lpUpdatePlan->m_nIndexOffset;
	stQueryInfo.m_nConnOffset			= 0;
	stQueryInfo.m_nWhereOffset			= lpUpdatePlan->m_nWhereOffset;
	stQueryInfo.m_lpObjectInfo			= lpObjectInfo;
	stQueryInfo.m_lpTransactionArray	= &stTransactionArray;
	stQueryInfo.m_nTimestamp			= lpSourceInfo->m_nTimestamp;
	stQueryInfo.m_bPagingType			= MF_PAGING_FIRST;
	stQueryInfo.m_nPageNo				= 1;
	stQueryInfo.m_nPageSize				= stExecutePlanManager.GetPageSize();
	
	stRecordInfo.m_nTimestamp			= lpSourceInfo->m_nTimestamp; 
	stRecordInfo.m_lpTransactionArray	= &stTransactionArray;
	nRet = GetRecordDataID(stBson, &stQueryInfo, &stDataIDContainer, lpExecuteInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpSourceInfo->m_nRecordAddrID = stDataIDContainer.GetDataIDAddr();
	lpSourceInfo->m_nRecordNum    = stDataIDContainer.size();
	lpSourceInfo->m_bRecordType   = MF_RECORD_COMMON;
	
	//4.锁块
	lpBlockInfo = (LPBLOCKINFO)stBson.ConvertOffset2Addr(lpSourceInfo->m_nBlockOffset);
	stDataIDContainer.MoveFirst();
	for(i = 0; i < stDataIDContainer.size(); i++)
	{
		nRet = stDataIDContainer.NextRecordHead(lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = LockBlock(stBson, lpObjectInfo, lpRecordHead->m_nDataID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//记录上锁块信息
	for(i = 0; i < MF_MAX_BLOCKINFO_NUM; i++)
	{
		if(lpBlockInfo[i].m_nBlockNo != 0)
		{
			lpBlockInfo[i].m_bSource    = MF_SOURCE_FROM_EXISTBLOCK;
			lpBlockInfo[i].m_bAlloc     = 0;
			lpBlockInfo[i].m_bObjectType= MF_OBJECT_COMMON;
		}
	}

	//5.数据备份
	stDataIDContainer.MoveFirst();
	for(i = 0; i < stDataIDContainer.size(); i++)
	{
		nRet = stDataIDContainer.NextDataID(nDataID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = pFile->DataBackUp(nDataID, lpSourceInfo->m_nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//6.计算更新后记录的长度
	stDataIDContainer.MoveFirst();
	stExecutePlanManager.Move2FirstRecord();
	for(i = 0; i < stDataIDContainer.size(); i++)
	{
		nRet = stDataIDContainer.NextDataID(nDataID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		//计算新记录的长度
		nRet = stExecutePlanManager.NextRecord(nAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		stRecordInfo.m_nDataID	     = nDataID;
		stRecordInfo.m_bDataPosition = MF_DATAPOSITION_ROLLBACK;
		nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(stRecordInfo.m_lpRecordBuffer == NULL)
		{
			continue;
		}
		stUpdateBson.Initial(lpObjectInfo);
		nRet = stUpdateBson.GetBsonLen(&stRecordInfo, lpFieldBson, lpUpdatePlan->m_nExecuteFieldNum, lpRecordHead->m_nRecordLen);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//7.创建更新步骤
	lpStepInfo = &lpExecutePlan->m_stStepInfo;
	lpStepInfo->m_nExecuteStepNum = lpUpdatePlan->m_nIndexNum*lpSourceInfo->m_nRecordNum*2 + lpSourceInfo->m_nRecordNum;
	
	//创建更新数据步骤
	stExecutePlanManager.Move2FirstRecord();
	for(i = 0; i < lpSourceInfo->m_nRecordNum; i++)
	{
		nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpStepInfo->m_nStepAddrID == 0)
		{
			lpStepInfo->m_nStepAddrID = nAddrID;
		}
	
		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpExecuteStep->m_bStepType	   = MF_EXECUTE_STEP_UPDATEDATA;
		lpExecuteStep->m_nParam1	   = nRecordAddrID;
	}

	//创建插入索引步骤
	stExecutePlanManager.Move2FirstRecord();
	for(i = 0; i < lpSourceInfo->m_nRecordNum; i++)
	{
		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nIndexOffset = lpUpdatePlan->m_nUpdateIndexOffset;
		while(nIndexOffset)
		{
			nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpIndexPlan = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(nIndexOffset);

			lpExecuteStep->m_bStepType	   = MF_EXECUTE_STEP_UPDATEINSERTINDEX;
			lpExecuteStep->m_nParam1	   = nRecordAddrID;
			lpExecuteStep->m_nParam2	   = nIndexOffset;

			nIndexOffset = lpIndexPlan->m_nNextOffset;
		}
	}

	//创建删除索引步骤
	stExecutePlanManager.Move2FirstRecord();
	for(i = 0; i < lpSourceInfo->m_nRecordNum; i++)
	{
		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nIndexOffset = lpUpdatePlan->m_nUpdateIndexOffset;
		while(nIndexOffset)
		{
			nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpIndexPlan = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(nIndexOffset);

			lpExecuteStep->m_bStepType	   = MF_EXECUTE_STEP_UPDATEDELETEINDEX;
			lpExecuteStep->m_nParam1	   = nRecordAddrID;
			lpExecuteStep->m_nParam2	   = nIndexOffset;

			nIndexOffset = lpIndexPlan->m_nNextOffset;
		}
	}

	//修改各类文件头时间戳
	pFile->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
	for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
	{
		nRet = CSystemManage::instance().GetMemoryFileInstance(lpIndex->m_bFileNo, pVirtualFile);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(lpIndex->m_bIndexType >= 1 && lpIndex->m_bIndexType <= 6)
		{
			((CMemoryHashFile*)pVirtualFile)->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
		}
		else if(lpIndex->m_bIndexType >= 11 && lpIndex->m_bIndexType <= 16)
		{
			((CMemoryBTreeFile*)pVirtualFile)->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
		}
	}

	lpExecutePlan->m_nTotalDataSize			= stBson.GetExecutePlanDataSize();
	lpExecutePlan->m_nBsonDataSize			= stBson.GetBsonDataSize();
	lpExecutePlan->m_nFreeSectionAddrID		= stBson.GetFreeSectionAddrID();
	lpExecutePlan->m_nSectionStartOffset	= stBson.GetSectionStartOffset();
	return MF_OK;
}

/************************************************************************
	功能说明：
		UpdateRecordset的预处理操作
	参数说明：
		stBson：BSON对象
		stExecutePlanManager：执行计划
************************************************************************/
int CCommonMemObject::PreprocessUpdateRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager)
{
	CMemoryFile *pFile; 
	LPINDEXDEF lpIndex;
	set<int> setBlockNo;
	LPSTEPINFO lpStepInfo;
	LPBLOCKINFO lpBlockInfo;
	LPOBJECTDEF lpObjectInfo;
	LPRECORDHEAD lpRecordHead;
	LPSOURCEINFO lpSourceInfo;
	BLOCKINFO arBlockInfo[20];
	LPEXECUTESTEP lpExecuteStep;
	RECORDDATAINFO stRecordInfo;
	LPXMLFIELDINFO lpXmlFieldInfo;
	set<int>::iterator iterBlockNo;
	vector<BLOCKINFO> vecBlockInfo;
	LPINDEXEXECUTEPLAN lpIndexPlan;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile *pVirtualFile;
	CUpdateBson stUpdateBson(&stBson);
	UINT nAddrID, nRecordAddrID, nIndexOffset;
	LPXMLFIELDBSON lpXmlFieldBson, *lpFieldBsonMap;
	LPUPDATERECORDSETPLANBSON lpUpdateRecordsetPlan;
	int	nRet, nRecordNum, j, nLen, nFreeSize, i, n, nRecordLen, nBlockNo, nInsertRecordNum;

	lpExecutePlan					= stExecutePlanManager.GetExecutePlan();
	lpUpdateRecordsetPlan			= (LPUPDATERECORDSETPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	lpSourceInfo					= &lpExecutePlan->m_stSourceInfo;
	lpSourceInfo->m_bRecordType		= MF_RECORD_COMMON;
	memset(arBlockInfo, 0, sizeof(arBlockInfo));

	lpObjectInfo  = stBson.GetObjectInfo();
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;
	
	//分配空间记录块信息
	lpBlockInfo = (LPBLOCKINFO)stBson.ConvertOffset2Addr(lpSourceInfo->m_nBlockOffset);
	//1.给更新或删除操作所涉及的块上锁
	nRecordNum = lpUpdateRecordsetPlan->m_nUpdateStepNum + lpUpdateRecordsetPlan->m_nDeleteStepNum;
	stExecutePlanManager.Move2FirstRecord();
	for(i = 0; i < nRecordNum; i++)
	{
		nRet = stExecutePlanManager.NextRecord(nAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = LockBlock(stBson, lpObjectInfo, lpRecordHead->m_nDataID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nBlockNo = GetBlockNoFromDataID(lpRecordHead->m_nDataID);
		setBlockNo.insert(nBlockNo);
	}
	
	//记录上锁块信息
	for(i = 0; i < MF_MAX_BLOCKINFO_NUM; i++)
	{
		if(lpBlockInfo[i].m_nBlockNo != 0)
		{
			lpBlockInfo[i].m_bSource		= MF_SOURCE_FROM_EXISTBLOCK;
			lpBlockInfo[i].m_bObjectType	= MF_OBJECT_COMMON;
			lpBlockInfo[i].m_bAlloc			= 0;
		}
	}

	//记录删除和更新的块中的剩余空间
	for(i = 0, iterBlockNo = setBlockNo.begin(); iterBlockNo != setBlockNo.end(); iterBlockNo++, i++)
	{
		nRet = pFile->GetBlockFreeSize(*iterBlockNo, nFreeSize);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		arBlockInfo[i].m_nBlockNo   = *iterBlockNo;
		arBlockInfo[i].m_nBlockSize = nFreeSize;
	}

	//2.数据备份
	stExecutePlanManager.Move2FirstRecord();
	for(i = 0; i < nRecordNum; i++)
	{
		stExecutePlanManager.NextRecord(nAddrID, lpRecordHead);
		nRet = pFile->DataBackUp(lpRecordHead->m_nDataID, lpSourceInfo->m_nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	
	//3.对UpdateRecordset中的增、删、改操作进行预处理
	stExecutePlanManager.Move2FirstRecord();
	nInsertRecordNum = 0;
	stUpdateBson.Initial(lpObjectInfo);
	for(i = 0; i < (int)lpUpdateRecordsetPlan->m_nExecuteStepNum; i++)
	{
		stExecutePlanManager.NextRecord(nAddrID, lpRecordHead);
		if(lpRecordHead->m_bType == MF_EXECUTE_STEP_DELETEDATA)
		{
		}
		else if(lpRecordHead->m_bType == MF_EXECUTE_STEP_UPDATEDATA)
		{
			//从回滚区中取出原始数据
			lpXmlFieldInfo  = (LPXMLFIELDINFO)stBson.ConvertOffset2Addr(lpUpdateRecordsetPlan->m_nFieldInfoOffset);
			lpFieldBsonMap  = (LPXMLFIELDBSON*)stBson.ConvertOffset2Addr(lpUpdateRecordsetPlan->m_nFieldMapOffset);
			memset(lpFieldBsonMap, 0, sizeof(LPXMLFIELDBSON)*lpObjectInfo->m_nFieldNum);
			
			lpXmlFieldBson  = (LPXMLFIELDBSON)stBson.ConvertOffset2Addr(lpRecordHead->m_nFieldOffset);
			for(j = 0; j < lpRecordHead->m_bFieldNum; j++)
			{
				if(lpXmlFieldBson[j].m_bModify)
				{
					lpFieldBsonMap[lpXmlFieldBson[j].m_bFieldNo - 1] = &lpXmlFieldBson[j];
				}
			}
			
			stRecordInfo.m_nDataID			= lpRecordHead->m_nDataID;
			stRecordInfo.m_nTimestamp		= lpSourceInfo->m_nTimestamp;
			stRecordInfo.m_bDataPosition	= MF_DATAPOSITION_ROLLBACK;
			nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(stRecordInfo.m_lpRecordBuffer == NULL)
			{
				return MF_COMMON_RECORD_NOTEXIT;
			}
			//获取更新记录的长度
			nRet = stUpdateBson.GetBsonLen(&stRecordInfo, lpFieldBsonMap, lpRecordHead->m_nRecordLen);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			//获取新记录增长的长度
			nLen = lpRecordHead->m_nRecordLen - stRecordInfo.m_nRecordLen;
			if(nLen > 0)
			{
				nBlockNo = ::GetBlockNoFromDataID(lpRecordHead->m_nDataID);
				for(n = 0; n < 20; n++)
				{
					if(arBlockInfo[n].m_nBlockNo == nBlockNo)
					{
						arBlockInfo[n].m_nBlockSize -= nLen;
					}
				}
			}
		}
		else if(lpRecordHead->m_bType == MF_EXECUTE_STEP_INSERTDATA)
		{
			//插入操作，获取插入记录的长度
			lpFieldBsonMap = (LPXMLFIELDBSON*)stBson.ConvertOffset2Addr(lpUpdateRecordsetPlan->m_nFieldMapOffset);
			memset(lpFieldBsonMap, 0, sizeof(LPXMLFIELDBSON)*lpObjectInfo->m_nFieldNum);

			lpXmlFieldBson = (LPXMLFIELDBSON)stBson.ConvertOffset2Addr(lpRecordHead->m_nFieldOffset);
			for(j = 0; j < lpRecordHead->m_bFieldNum; j++)
			{
				if(lpXmlFieldBson[j].m_bModify)
				{
					lpFieldBsonMap[lpXmlFieldBson[j].m_bFieldNo - 1] = &lpXmlFieldBson[j];
				}
			}

			//获取插入记录的长度
			nRecordLen = CInsertBson::GetBsonLen(lpObjectInfo, lpFieldBsonMap, lpSourceInfo->m_bRecordType);
			if(nRecordLen == -1)
			{
				return MF_CREATEPLAN_GETRECORDLEN_FAILED;
			}
			lpRecordHead->m_nRecordLen = nRecordLen;
			nInsertRecordNum++;
		}
	}

	//4.将插入数据与块进行绑定
	nRet = pFile->BindDataID(stExecutePlanManager, nInsertRecordNum, arBlockInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//5.创建执行步骤
	lpStepInfo = &lpExecutePlan->m_stStepInfo;
	lpStepInfo->m_nExecuteStepNum = lpUpdateRecordsetPlan->m_nIndexNum*lpUpdateRecordsetPlan->m_nDeleteStepNum + lpUpdateRecordsetPlan->m_nIndexNum*lpUpdateRecordsetPlan->m_nUpdateStepNum*2 + lpUpdateRecordsetPlan->m_nIndexNum*lpUpdateRecordsetPlan->m_nInsertStepNum + lpSourceInfo->m_nRecordNum;
	stExecutePlanManager.Move2FirstRecord();
	
	//创建数据删除步骤
	for(i = 0; i < (int)lpUpdateRecordsetPlan->m_nDeleteStepNum; i++)
	{
		nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpStepInfo->m_nStepAddrID == 0)
		{
			lpStepInfo->m_nStepAddrID = nAddrID;
		}

		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpExecuteStep->m_bStepType		= MF_EXECUTE_STEP_DELETEDATA;
		lpExecuteStep->m_nParam1		= nRecordAddrID;
	}

	//创建数据更新步骤
	for(i = 0; i < (int)lpUpdateRecordsetPlan->m_nUpdateStepNum; i++)
	{
		nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpStepInfo->m_nStepAddrID == 0)
		{
			lpStepInfo->m_nStepAddrID = nAddrID;
		}

		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpExecuteStep->m_bStepType		= MF_EXECUTE_STEP_UPDATEDATA;
		lpExecuteStep->m_nParam1		= nRecordAddrID;
	}

	//创建数据插入步骤
	for(i = 0; i < (int)lpUpdateRecordsetPlan->m_nInsertStepNum; i++)
	{
		nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpStepInfo->m_nStepAddrID == 0)
		{
			lpStepInfo->m_nStepAddrID = nAddrID;
		}

		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		lpExecuteStep->m_bStepType		= MF_EXECUTE_STEP_INSERTDATA;
		lpExecuteStep->m_nParam1		= nRecordAddrID;
	}

	stExecutePlanManager.Move2FirstRecord();
	//创建索引删除步骤
	for(i = 0; i < (int)lpUpdateRecordsetPlan->m_nDeleteStepNum; i++)
	{
		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		nIndexOffset = lpUpdateRecordsetPlan->m_nIndexOffset;
		while(nIndexOffset)
		{
			nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpIndexPlan = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(nIndexOffset);

			lpExecuteStep->m_bStepType		= MF_EXECUTE_STEP_DELETEINDEX;
			lpExecuteStep->m_nParam1		= nRecordAddrID;
			lpExecuteStep->m_nParam2		= nIndexOffset;

			nIndexOffset = lpIndexPlan->m_nNextOffset;
		}
	}

	//创建更新操作中的索引插入步骤
	for(i = 0; i < (int)lpUpdateRecordsetPlan->m_nUpdateStepNum; i++)
	{
		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		nIndexOffset = lpUpdateRecordsetPlan->m_nIndexOffset;
		while(nIndexOffset)
		{
			nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpIndexPlan = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(nIndexOffset);

			lpExecuteStep->m_bStepType		= MF_EXECUTE_STEP_UPDATEINSERTINDEX;
			lpExecuteStep->m_nParam1		= nRecordAddrID;
			lpExecuteStep->m_nParam2		= nIndexOffset;

			nIndexOffset = lpIndexPlan->m_nNextOffset;
		}
	}
	
	//创建更新操作中的索引删除步骤,
	stExecutePlanManager.Move2FirstRecord();
	for(i = 0; i < (int)lpUpdateRecordsetPlan->m_nDeleteStepNum; i++)
	{
		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	for(i = 0; i < (int)lpUpdateRecordsetPlan->m_nUpdateStepNum; i++)
	{
		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nIndexOffset = lpUpdateRecordsetPlan->m_nIndexOffset;
		while(nIndexOffset)
		{
			nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpIndexPlan = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(nIndexOffset);

			lpExecuteStep->m_bStepType		= MF_EXECUTE_STEP_UPDATEDELETEINDEX;
			lpExecuteStep->m_nParam1		= nRecordAddrID;
			lpExecuteStep->m_nParam2		= nIndexOffset;

			nIndexOffset = lpIndexPlan->m_nNextOffset;
		}
	}

	//创建索引插入步骤
	for(i = 0; i < (int)lpUpdateRecordsetPlan->m_nInsertStepNum; i++)
	{
		nRet = stExecutePlanManager.NextRecord(nRecordAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nIndexOffset = lpUpdateRecordsetPlan->m_nIndexOffset;
		while(nIndexOffset)
		{
			nRet = stBson.AllocStep(lpExecuteStep, nAddrID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpIndexPlan = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(nIndexOffset);

			lpExecuteStep->m_bStepType		= MF_EXECUTE_STEP_INSERTINDEX;
			lpExecuteStep->m_nParam1		= nRecordAddrID;
			lpExecuteStep->m_nParam2		= nIndexOffset;

			nIndexOffset = lpIndexPlan->m_nNextOffset;
		}
	}


	//修改各类文件头时间戳
	pFile->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
	for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
	{
		nRet = CSystemManage::instance().GetMemoryFileInstance(lpIndex->m_bFileNo, pVirtualFile);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(lpIndex->m_bIndexType >= 1 && lpIndex->m_bIndexType <= 6)
		{
			((CMemoryHashFile*)pVirtualFile)->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
		}
		else if(lpIndex->m_bIndexType >= 11 && lpIndex->m_bIndexType <= 16)
		{
			((CMemoryBTreeFile*)pVirtualFile)->TimestampUpdate(lpExecutePlan, lpExecutePlan->m_nTimestamp);
		}
	}

	lpExecutePlan->m_nTotalDataSize			= stBson.GetExecutePlanDataSize();
	lpExecutePlan->m_nBsonDataSize			= stBson.GetBsonDataSize();
	lpExecutePlan->m_nFreeSectionAddrID		= stBson.GetFreeSectionAddrID();
	lpExecutePlan->m_nSectionStartOffset	= stBson.GetSectionStartOffset();
	return MF_OK;
}

/************************************************************************
	功能说明：
		按页获取数据ID
	参数说明：
		stBson:Bson对象
		lpQuertInfo:查询信息
		pDataIDContainer：DataID容器
		lpExecuteInfo：统计信息
************************************************************************/
int CCommonMemObject::GetDataIDByPage(CServiceBson& stBson, LPQUERYINFO lpQuertInfo, CDataIDContainer* pDataIDContainer, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	long long nBufferNo;
	LPOBJECTDEF lpObjectInfo;

	lpObjectInfo = lpQuertInfo->m_lpObjectInfo;

	nBufferNo = lpObjectInfo->m_nObjectID;
	nBufferNo = nBufferNo << 32;
	nBufferNo = nBufferNo | lpQuertInfo->m_dwWhereHash;
	nRet = CSystemManage::instance().GetPage(nBufferNo, lpQuertInfo->m_nPageNo, lpQuertInfo->m_nPageSize, pDataIDContainer);
	if(nRet != MF_OK)
	{
		//如果页面不存在，则需要重新分页
		pDataIDContainer->clear();
		IVirtualMemoryFile* pVirtualFile;
		nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = GetRecordDataID(stBson, lpQuertInfo, pDataIDContainer, lpExecuteInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = CSystemManage::instance().Paging(nBufferNo, pDataIDContainer, lpQuertInfo->m_nPageSize);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		
		//获取对应页面
		pDataIDContainer->clear();
		nRet = CSystemManage::instance().GetPage(nBufferNo, lpQuertInfo->m_nPageNo, lpQuertInfo->m_nPageSize, pDataIDContainer);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取记录的DataID值
	参数说明：
		stBson:Bson对象
		lpQuertInfo:查询信息
		pDataIDContainer：DataID容器
		lpExecuteInfo：统计信息
************************************************************************/
int CCommonMemObject::GetRecordDataID(CServiceBson& stBson, LPQUERYINFO lpQuertInfo, CDataIDContainer* pDataIDContainer, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	if(lpQuertInfo->m_nIndexOffset != 0)
	{
		//1.根据索引条件获取DataID
		nRet = GetDataIDByIndex(stBson, lpQuertInfo, pDataIDContainer);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else 
	{
		//2.全表遍历
		nRet = GetDataIDDriect(stBson, lpQuertInfo, pDataIDContainer);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	return MF_OK;
}

/************************************************************************
	功能说明：
		执行插入操作
	参数说明：
		stBson:Bson对象
		stExecutePlanManager：执行计划管理
		lAffectCount：影响的行数
		lpExecuteInfo：操作信息
************************************************************************/
int CCommonMemObject::Insert(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet, i;
	LPSTEPINFO lpStepInfo;
	LPOBJECTDEF lpObjectInfo;
	LPBASESTEPPARAM lpBaseParam;
	LPEXECUTESTEP lpExecuteStep;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(lpExecutePlan->m_nType != MF_EXECUTEPLAN_CMDTYPE_INSERT)
	{
		return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
	}
	if(lpExecutePlan->m_nCommandOffset == 0)
	{
		return MF_INNER_POINTER_NULL;
	}
	
	lpObjectInfo  = stBson.GetObjectInfo();
	//执行步骤
	lpBaseParam					= &lpExecutePlan->m_stBaseParam;
	lpBaseParam->m_bRecordType	= lpExecutePlan->m_stSourceInfo.m_bRecordType;
	lpBaseParam->m_lpObjectInfo	= (long long)lpObjectInfo;
	lpBaseParam->m_nTimestamp	= lpExecutePlan->m_nTimestamp;

	lAffectCount = 0;
	lpStepInfo   = &lpExecutePlan->m_stStepInfo;
	stExecutePlanManager.Move2Step();
	for(i = 0; i < (int)lpStepInfo->m_nExecuteStepNum; i++)
	{
		lpStepInfo->m_nCurrentStepNo = i;
		nRet = stExecutePlanManager.NextStep(lpExecuteStep);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = ExecuteStep(stBson, lpBaseParam, lpExecuteStep, lAffectCount);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		执行更新操作
	参数说明：
		stBson：BSON对象
		lpExecutePlan：执行计划
		lAffectCount：影响的行数
************************************************************************/
int CCommonMemObject::Update(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int	nRet, i;
	LPSTEPINFO lpStepInfo;
	vector<int>	vecBlockNo;
	LPOBJECTDEF lpObjectInfo;
	LPEXECUTESTEP lpExecuteStep;
	LPBASESTEPPARAM lpBaseParam;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(lpExecutePlan->m_nType != MF_EXECUTEPLAN_CMDTYPE_UPDATE)
	{
		return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
	}
	if(lpExecutePlan->m_nCommandOffset == 0)
	{
		return MF_INNER_POINTER_NULL;
	}
	
	lpObjectInfo  = stBson.GetObjectInfo();
	//执行步骤
	lpBaseParam					= &lpExecutePlan->m_stBaseParam;
	lpBaseParam->m_bRecordType	= lpExecutePlan->m_stSourceInfo.m_bRecordType;
	lpBaseParam->m_lpObjectInfo	= (long long)lpObjectInfo;
	lpBaseParam->m_nTimestamp	= lpExecutePlan->m_nTimestamp;

	lAffectCount = 0;
	lpStepInfo   = &lpExecutePlan->m_stStepInfo;
	stExecutePlanManager.Move2Step();
	for(i = 0; i < (int)lpStepInfo->m_nExecuteStepNum; i++)
	{
		lpStepInfo->m_nCurrentStepNo = i;
		nRet = stExecutePlanManager.NextStep(lpExecuteStep);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = ExecuteStep(stBson, lpBaseParam, lpExecuteStep, lAffectCount);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		执行删除操作
	参数说明：
		stBson：BSON对象
		lpExecutePlan：执行计划BSON
		lAffectCount：影响的行数
************************************************************************/
int CCommonMemObject::Delete(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet, i;
	LPSTEPINFO lpStepInfo;
	vector<int> vecBlockNo;
	LPOBJECTDEF lpObjectInfo;
	LPEXECUTESTEP lpExecuteStep;
	LPBASESTEPPARAM lpBaseParam;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(lpExecutePlan->m_nType != MF_EXECUTEPLAN_CMDTYPE_DELETE)
	{
		return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
	}
	if(lpExecutePlan->m_nCommandOffset == 0)
	{
		return MF_INNER_POINTER_NULL;
	}
	
	lpObjectInfo  = stBson.GetObjectInfo();
	//执行步骤
	lpBaseParam					= &lpExecutePlan->m_stBaseParam;
	lpBaseParam->m_bRecordType	= lpExecutePlan->m_stSourceInfo.m_bRecordType;
	lpBaseParam->m_lpObjectInfo	= (long long)lpObjectInfo;
	lpBaseParam->m_nTimestamp	= lpExecutePlan->m_nTimestamp;

	lAffectCount = 0;
	lpStepInfo   = &lpExecutePlan->m_stStepInfo;
	stExecutePlanManager.Move2Step();
	for(i = 0; i < (int)lpStepInfo->m_nExecuteStepNum; i++)
	{
		lpStepInfo->m_nCurrentStepNo = i;
		nRet = stExecutePlanManager.NextStep(lpExecuteStep);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		nRet = ExecuteStep(stBson, lpBaseParam, lpExecuteStep, lAffectCount);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	return MF_OK;
}

/************************************************************************
		功能说明：
			重建索引
		参数说明：
			stBson：BSON对象
			nObjectID：对象ID
			lpHashTable：索引执行计划
************************************************************************/
int CCommonMemObject::IndexRebuild(CServiceBson& stBson, int nObjectID, LPINDEXDEFBSON lpIndexBson)
{
	Check stCheck;
	VARDATA varData;
	long long nDataID;
	CMemoryFile* pFile;
	QUERYINFO stQueryInfo;
	INDEXINFO stIndexInfo;
	LPINDEXDEFBSON lpIndex;
	BYTE bFieldNo, bLinkType;
	LPOBJECTDEF lpObjectInfo;
	CExpression stExpression;
	RECORDDATAINFO stRecordInfo;
	int nRet, i, j, nInnerDataNo;
	LPINDEXCONDITION lpIndexField;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;
	CExecuteDataID stDataIDContainer(&stBson);
	long long nBlockMapOffset, *lpTransactionArray;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();

	lpTransactionArray = (long long*)stBson.GetPtrFromTempBuffer(lpExecutePlan->m_nTransactionOffset);
	TRANSACTIONARRAY stTransactionArray(lpExecutePlan->m_nTransactionNum, lpTransactionArray);
	//1.获取对象信息
	lpObjectInfo  = stBson.GetObjectInfo();
	
	//2.获取数据文件指针
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;

	//3.获取该对象所有记录的DataID
	stQueryInfo.m_lpObjectInfo = lpObjectInfo;
	bLinkType		= 0;
	nBlockMapOffset = 0;
	nInnerDataNo	= 0;
	stCheck.Initial(&stBson, &stQueryInfo);
	while(TRUE)
	{
		nRet = pFile->GetNextDataID(lpExecutePlan, lpObjectInfo->m_nObjectID, FALSE, bLinkType, nBlockMapOffset, nInnerDataNo, nDataID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(nDataID == 0)
		{
			break;
		}
		if(stCheck.CheckRecordValid(nDataID))
		{
			nRet = stDataIDContainer.push_back(nDataID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}
	
	//4.遍历索引链表重建索引
	stExpression.Initial(&stBson, lpObjectInfo);
	stRecordInfo.m_nTimestamp = lpExecutePlan->m_nTimestamp;
	for(lpIndex = lpIndexBson; lpIndex != NULL;)
	{
		//设置索引的基本信息
		stIndexInfo.m_nIndexID      = lpIndex->m_nIndexID;
		stIndexInfo.m_bIndexType    = lpIndex->m_bIndexType;
		stIndexInfo.m_bFileNo		= lpIndex->m_bFileNo;
		stIndexInfo.m_bFieldNo[0]   = lpIndex->m_bFieldNo[0];
		stIndexInfo.m_bFieldNo[1]   = lpIndex->m_bFieldNo[1];
		stIndexInfo.m_bFieldNo[2]   = lpIndex->m_bFieldNo[2];
		stIndexInfo.m_bFieldNo[3]   = lpIndex->m_bFieldNo[3];

		if(lpIndex->m_bConstraintType == MF_CONSTRAINT_PRIMARYKEY)
		{
			stIndexInfo.m_bUnique = TRUE;
		}
		else if(lpIndex->m_bConstraintType == MF_CONSTRAINT_UNIQUE)
		{
			stIndexInfo.m_bUnique = TRUE;
		}

		//遍历Object的所有记录，获取索引的关键字值
		stDataIDContainer.MoveFirst();
		for(i = 0; i < (int)stDataIDContainer.size(); i++)
		{
			nRet = stDataIDContainer.NextDataID(nDataID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			stRecordInfo.m_nDataID = nDataID;
			stIndexInfo.m_nDataID  = nDataID;
			//设置索引的关键字值
			stIndexInfo.m_stMultiIndex.m_nIndexNum = 0;
			for(j = 0; j < 4; j++)
			{
				bFieldNo = lpIndex->m_bFieldNo[j];
				if(bFieldNo == 0)
				{
					break;
				}
				else
				{
					stIndexInfo.m_stMultiIndex.m_nIndexNum++;
					lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];
				}

				nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				if(stRecordInfo.m_lpRecordBuffer == NULL)
				{
					return MF_COMMON_RECORD_NOTEXIT;
				}
				nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varData);
				if(nRet != MF_OK)
				{
					return nRet;
				}

				if(lpIndex->m_bConstraintType == MF_CONSTRAINT_PRIMARYKEY && varData.m_vt == MF_SYS_FIELDTYPE_NULL)
				{
					return MF_COMMON_INVALID_NULLPRIMARYKEY;
				}
				lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
				lpIndexField->m_bFieldNo   = bFieldNo;
				lpIndexField->m_bFieldType = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;
				lpIndexField->m_varCondition2.SetData(varData);
			}
			
			stIndexInfo.m_stMultiIndex.m_nIndexNum++;
			lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];

			lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
			lpIndexField->m_bFieldType = MF_SYS_FIELDTYPE_BIGINT;
			lpIndexField->m_varCondition2.SetData(nDataID);

			//插入索引
			nRet = InsertIndex(&stIndexInfo, lpExecutePlan->m_nObjectID, lpExecutePlan, lpExecutePlan->m_nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}

		if(lpIndex->m_nNextOffset == 0)
		{
			lpIndex = NULL;
		}
		else
		{
			lpIndex = (LPINDEXDEFBSON)stBson.ConvertOffset2Addr(lpIndex->m_nNextOffset);
		}	
	}
	return MF_OK;
}	
/************************************************************************
		功能说明：
			导出对象数据
		参数说明：
			stBson：Bson对象
			pObjectName：对象名
			lpExportParam：导出参数
			nTimestamp：时间戳
************************************************************************/
int	CCommonMemObject::ExportObject(CServiceBson& stBson, char* pObjectName, LPEXPORTPARAM lpExportParam, long long nTimestamp)
{
	UINT nOffset;
	LPINDEXDEF lpIndex;
	CMemoryFile* pFile;
	LPOBJECTDEF lpObjectInfo;
	int nRet, i, nTransactionNum;
	long long* lpTransactionArray;
	IVirtualMemoryFile* pVirtualFile;
	LPOBJECTDEFBSON lpObjectInfoBson;
	LPCREATEEXECUTEPLANBSON lpCreatePlan;
	LPOBJECTBUFFERHEAD lpObjectBufferHead;
	LPINDEXDEFBSON lpIndexBson, lpPreIndexBson;
	LPOBJECTFIELDDEFBSON lpFieldBson, lpPreFieldBson;

	//获取对象信息
	nRet = CSystemManage::instance().GetObjectInfo(pObjectName, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//获取数据文件指针
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;
	
	//备份事务链表
	if(lpExportParam->m_nTransactionOffset == 0)
	{
		nRet = CSystemManage::instance().SetTransactionLine(stBson, nTimestamp, lpExportParam->m_nTransactionOffset, nTransactionNum);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpTransactionArray = (long long*)stBson.GetPtrFromTempBuffer(lpExportParam->m_nTransactionOffset);
	}
	else
	{
		lpTransactionArray = (long long*)stBson.GetPtrFromTempBuffer(lpExportParam->m_nTransactionOffset);
	}
	TRANSACTIONARRAY stTransactionArray(nTransactionNum, lpTransactionArray);

	//为数据头分配空间
	nRet = stBson.AllocFromBsonBuffer(lpObjectBufferHead, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpObjectBufferHead->m_nFlag			= MAKEHEADFLAG('E','X','O','B');
	lpObjectBufferHead->m_bObjectType	= MF_OBJECT_COMMON;
	//预留字节存放长度
	if(lpExportParam->m_nBlockMapOffset == 0)
	{
		//说明数据导出还未开始，那么需要把ObjectInfo序列化到Buffer中
		//标识位：为1表示该Buffer存放了ObjectInfo信息，为0表示只存放了数据值
		lpObjectBufferHead->m_bBufferType = 1;
		lpObjectBufferHead->m_bObjectInfoOffset = stBson.GetBsonDataSize();
		
		//填充CREATEEXECUTEPLANBSON结构体，用于将来建表
		nRet = stBson.AllocFromBsonBuffer(lpCreatePlan, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		//填充对象信息
		nRet = stBson.AllocFromBsonBuffer(lpObjectInfoBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpCreatePlan->m_nPlanOffset         = nOffset;
		lpObjectInfoBson->m_bFileNo         = lpObjectInfo->m_bFileNo;
		lpObjectInfoBson->m_bImplementClass = lpObjectInfo->m_bImplementClass;
		lpObjectInfoBson->m_nBlockSize      = lpObjectInfo->m_nBlockSize;
		lpObjectInfoBson->m_nDataID         = lpObjectInfo->m_nDataID;
		lpObjectInfoBson->m_nFieldNum       = lpObjectInfo->m_nFieldNum;
		lpObjectInfoBson->m_nObjectID       = lpObjectInfo->m_nObjectID;
		lpObjectInfoBson->m_bObjectType     = lpObjectInfo->m_bObjectType;
		memcpy(lpObjectInfoBson->m_bObjectName, lpObjectInfo->m_lpszName, 32);

		//填充对象字段信息
		lpPreFieldBson = NULL;
		for(i = 0; i < lpObjectInfo->m_nFieldNum; i++)
		{
			nRet = stBson.AllocFromBsonBuffer(lpFieldBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpPreFieldBson != NULL)
			{
				lpPreFieldBson->m_nNextOffset = nOffset;
			}
			else
			{
				lpObjectInfoBson->m_nFieldOffset = nOffset;
			}
			lpPreFieldBson = lpFieldBson;
			
			lpFieldBson->m_bFieldNo   = lpObjectInfo->m_lpField[i].m_bObjectFieldNo;
			lpFieldBson->m_bAllowNull = lpObjectInfo->m_lpField[i].m_bAllowNull;
			lpFieldBson->m_bFieldType = lpObjectInfo->m_lpField[i].m_bFieldType;
			lpFieldBson->m_bCharLen   = lpObjectInfo->m_lpField[i].m_bCharLen;
			memcpy(lpFieldBson->m_bFieldName, lpObjectInfo->m_lpField[i].m_lpszName, 32);
		}

		//填充对象索引信息
		lpPreIndexBson = NULL;
		for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
		{
			nRet = stBson.AllocFromBsonBuffer(lpIndexBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpPreIndexBson != NULL)
			{
				lpPreIndexBson->m_nNextOffset	 = nOffset;
			}
			else
			{
				lpObjectInfoBson->m_nIndexOffset = nOffset;
			}
			lpPreIndexBson = lpIndexBson;

			lpIndexBson->m_bFieldNo[0]		= lpIndex->m_bFieldNo[0];
			lpIndexBson->m_bFieldNo[1]		= lpIndex->m_bFieldNo[1];
			lpIndexBson->m_bFieldNo[2]		= lpIndex->m_bFieldNo[2];
			lpIndexBson->m_bFieldNo[3]		= lpIndex->m_bFieldNo[3];
			lpIndexBson->m_bFileNo			= lpIndex->m_bFileNo;
			lpIndexBson->m_bIndexType		= lpIndex->m_bIndexType;
			lpIndexBson->m_nBlockSize		= lpIndex->m_nBlockSize;
			lpIndexBson->m_nDataID			= lpIndex->m_nDataID;
			lpIndexBson->m_nIndexID			= lpIndex->m_nIndexID;
			lpIndexBson->m_bConstraintType  = lpIndex->m_bConstraintType;
			memcpy(lpIndexBson->m_pIndexName, lpIndex->m_lpszName, 32);
		}
		lpObjectBufferHead->m_nDataOffset = stBson.GetBsonDataSize();
		nRet = pFile->ExportObject(stBson, lpObjectInfo->m_nObjectID, lpExportParam, nTimestamp, &stTransactionArray);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpObjectBufferHead->m_nBufferLen = stBson.GetBsonDataSize() - sizeof(OBJECTBUFFERHEAD);
	}
	else
	{
		//标识位：为1表示该Buffer存放了ObjectInfo信息，为0表示只存放了数据值
		lpObjectBufferHead->m_bBufferType = 0;
		lpObjectBufferHead->m_nDataOffset = stBson.GetBsonDataSize();
		nRet = pFile->ExportObject(stBson, lpObjectInfo->m_nObjectID, lpExportParam, nTimestamp, &stTransactionArray);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpObjectBufferHead->m_nBufferLen = stBson.GetBsonDataSize() - sizeof(OBJECTBUFFERHEAD);
	}
	if(lpExportParam->m_bComplete)
	{
		lpObjectBufferHead->m_bComplete = 1;
	}
	else
	{
		lpObjectBufferHead->m_bComplete = 0;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			导入数据
		参数说明：
			stBson：Bson对象
			lpImportParam：导入参数
			pObjectName：对象名称
			nTimestamp：时间戳
************************************************************************/
int	CCommonMemObject::ImportObject(CServiceBson& stBson, char* pObjectName, LPIMPORTPARAM lpImportParam, long long nTimestamp)
{
	BYTE bFieldNo;
	VARDATA varKey;
	BOOL bSameIndex;
	long long nDataID;
	UINT nIndexOffset;
	CMemoryFile* pFile;
	LPINDEXDEF lpIndex;
	INDEXINFO stIndexInfo;
	CExpression stExpression;
	LPOBJECTDEF lpObjectInfo;
	LPINDEXDEFBSON lpIndexBson;
	FILE_INDEXDEFBSON stIndexDefBson;
	LPBYTE lpDataBuffer, lpImpBuffer;
	IVirtualMemoryFile* pVirtualFile;
	LPOBJECTFIELDDEFBSON lpFieldBson;
	LPOBJECTDEFBSON lpObjectInfoBson;
	LPINDEXCONDITION lpIndexCondition;
	int nRet, i, nDataLen, nRecordLen;
	LPCREATEEXECUTEPLANBSON lpCreatePlan;
	LPRECORDBUFFERHEAD lpRecordBufferHead;
	LPOBJECTBUFFERHEAD lpObjectBufferHead;
	LPCTSTR lpDataFilePath, lpBTreeFilePath, lpKVFilePath;

	//1.获取Buffer的长度和类型：为1表示该Buffer存放了ObjectInfo信息，为0表示只存放了数据值
	lpImpBuffer			= stBson.GetBuffer();
	lpObjectBufferHead	= (LPOBJECTBUFFERHEAD)lpImpBuffer;
	
	//2.获取对象信息
	lpFieldBson = NULL;
	if(1 == lpObjectBufferHead->m_bBufferType)
	{
		//获取文件路径
		CSystemManage::instance().GetFilePath(MF_SYS_FILETYPE_DATAFILE, lpDataFilePath);
		CSystemManage::instance().GetFilePath(MF_SYS_FILETYPE_TREEINDEXFILE, lpBTreeFilePath);
		CSystemManage::instance().GetFilePath(MF_SYS_FILETYPE_KVINDEXFILE, lpKVFilePath);

		//判断是否有与创建已经创建了同名对象
		lpCreatePlan		= (LPCREATEEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpObjectBufferHead->m_bObjectInfoOffset);
		lpObjectInfoBson	= (LPOBJECTDEFBSON)stBson.ConvertOffset2Addr(lpCreatePlan->m_nPlanOffset);
		if(!CSystemManage::instance().FindObject(lpObjectInfoBson->m_bObjectName))
		{
			//创建对象
			nRet = CSystemManage::instance().AddObject(stBson, NULL, nTimestamp, lpObjectInfoBson, lpDataFilePath, lpBTreeFilePath, lpKVFilePath);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nRet = CSystemManage::instance().GetObjectInfo(lpObjectInfoBson->m_bObjectName, lpObjectInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			stBson.SetObjectInfo(lpObjectInfo);
		}
		else
		{
			nRet = CSystemManage::instance().GetObjectInfo(lpObjectInfoBson->m_bObjectName, lpObjectInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			//判断两个对象是否为同一个对象，如果不是同一个对象，则出现异常
			if(lpObjectInfoBson->m_bObjectType != lpObjectInfo->m_bObjectType)
			{
				return MF_COMMON_INVALID_OBJECTID;
			}
			else if(lpObjectInfoBson->m_nFieldNum != lpObjectInfo->m_nFieldNum)
			{
				return MF_COMMON_INVALID_OBJECTID;
			}
			else
			{
				for(i = 0; i < lpObjectInfo->m_nFieldNum; i++)
				{
					if(lpFieldBson == NULL)
					{
						lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpObjectInfoBson->m_nFieldOffset);
					}
					else if(lpFieldBson->m_nNextOffset != 0)
					{
						lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpFieldBson->m_nNextOffset);
					}
					if(strcmp(lpFieldBson->m_bFieldName, lpObjectInfo->m_lpField[i].m_lpszName) != 0)
					{
						return MF_COMMON_INVALID_OBJECTID;
					}
					if(lpFieldBson->m_bAllowNull != lpObjectInfo->m_lpField[i].m_bAllowNull)
					{
						return MF_COMMON_INVALID_OBJECTID;
					}
					if(lpFieldBson->m_bFieldType != lpObjectInfo->m_lpField[i].m_bFieldType)
					{
						return MF_COMMON_INVALID_OBJECTID;
					}
				}
			}
			
			stBson.SetObjectInfo(lpObjectInfo);
			//创建索引
			if(lpObjectInfoBson->m_nIndexOffset)
			{
				nIndexOffset = lpObjectInfoBson->m_nIndexOffset;
				while(nIndexOffset)
				{
					bSameIndex  = FALSE;
					lpIndexBson = (LPINDEXDEFBSON)stBson.ConvertOffset2Addr(nIndexOffset);
					for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
					{
						if(strcmp(lpIndexBson->m_pIndexName, lpIndex->m_lpszName) == 0)
						{
							bSameIndex = TRUE;
							break;

						}
						else if(lpIndex->m_bFieldNo[0] == lpIndexBson->m_bFieldNo[0] && lpIndex->m_bFieldNo[1] == lpIndexBson->m_bFieldNo[1] && lpIndex->m_bFieldNo[2] == lpIndexBson->m_bFieldNo[2] && lpIndex->m_bFieldNo[3] == lpIndexBson->m_bFieldNo[3])
						{
							if(lpIndex->m_bIndexType == lpIndexBson->m_bIndexType)
							{
								bSameIndex = TRUE;
								break;
							}
						}
					}
					if(bSameIndex)
					{
						nIndexOffset = lpObjectInfoBson->m_nNextOffset;
						continue;
					}
					stIndexDefBson.m_nObjectID			= lpObjectInfo->m_nObjectID;
					stIndexDefBson.m_bObjectType		= lpObjectInfo->m_bObjectType;
					stIndexDefBson.m_bConstraintType	= lpIndexBson->m_bConstraintType;
					stIndexDefBson.m_bIndexType			= lpIndexBson->m_bIndexType;
					stIndexDefBson.m_bFieldNo[0]		= lpIndexBson->m_bFieldNo[0];
					stIndexDefBson.m_bFieldNo[1]		= lpIndexBson->m_bFieldNo[1];
					stIndexDefBson.m_bFieldNo[2]		= lpIndexBson->m_bFieldNo[2];
					stIndexDefBson.m_bFieldNo[3]		= lpIndexBson->m_bFieldNo[3];
					stIndexDefBson.m_nBlockSize			= lpIndexBson->m_nBlockSize;
					memcpy(stIndexDefBson.m_pIndexName, lpIndexBson->m_pIndexName, 32);
					memcpy(stIndexDefBson.m_pObjectName, lpObjectInfo->m_lpszName, 32);
					if(stIndexDefBson.m_bIndexType < 10)
					{
						//KV索引
						stIndexDefBson.m_bFileType = MF_SYS_FILETYPE_KVINDEXFILE;
						memcpy(stIndexDefBson.m_pFilePath, lpKVFilePath, 256);
					}
					else
					{
						//B树索引
						stIndexDefBson.m_bFileType = MF_SYS_FILETYPE_TREEINDEXFILE;
						memcpy(stIndexDefBson.m_pFilePath, lpBTreeFilePath, 256);
					}
					for(i = 0; i < 4; i++)
					{
						memcpy(stIndexDefBson.m_pFieldName[i], lpObjectInfo->m_lpField[lpIndexBson->m_bFieldNo[i] - 1].m_lpszName, 32);
					}

					nRet = CSystemManage::instance().AlterObjectAddIndex(stBson, nTimestamp, &stIndexDefBson);
					if(nRet == MF_SYS_OBJECT_ADDINDEX_EXIST)
					{
						nIndexOffset = lpObjectInfoBson->m_nNextOffset;
						continue;
					}
					else if(nRet != MF_OK)
					{
						return nRet;
					}
					nIndexOffset = lpObjectInfoBson->m_nNextOffset;
				}
			}
		}
	}
	else
	{
		if(pObjectName != NULL)
		{
			nRet = CSystemManage::instance().GetObjectInfo(pObjectName, lpObjectInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else
		{
			return MF_COMMON_INVALID_OBJECTID;
		}
		stBson.SetObjectInfo(lpObjectInfo);
	}

	//3.获取数据文件指针
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;

	lpDataBuffer = lpImpBuffer + lpObjectBufferHead->m_nDataOffset;
	nDataLen	 = lpObjectBufferHead->m_nBufferLen + sizeof(OBJECTBUFFERHEAD) - lpObjectBufferHead->m_nDataOffset;
	while(nDataLen > 0)
	{
		//插入数据
		lpRecordBufferHead	= (LPRECORDBUFFERHEAD)lpDataBuffer;
		nRecordLen			= lpRecordBufferHead->m_nRecordLen;
		nRet = pFile->InsertData(lpObjectInfo->m_nObjectID, lpObjectInfo->m_bObjectType, lpDataBuffer + sizeof(RECORDBUFFERHEAD), nRecordLen, nTimestamp, nDataID);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		//创建索引
		stExpression.Initial(&stBson, lpObjectInfo);
		for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
		{
			//1.获取关键字值
			stIndexInfo.clear();
			stIndexInfo.m_stMultiIndex.m_nIndexNum = 0;
			for(i = 0; i < 4; i++)
			{
				bFieldNo = lpIndex->m_bFieldNo[i];
				if(bFieldNo == 0)
				{
					break;
				}
				else
				{
					stIndexInfo.m_stMultiIndex.m_nIndexNum++;
					lpIndexCondition = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];
				}
				nRet = stExpression.GetFieldValueFromRecordBuffer(0, lpDataBuffer + sizeof(RECORDBUFFERHEAD), nRecordLen, bFieldNo, varKey);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				if(lpIndex->m_bConstraintType == MF_CONSTRAINT_PRIMARYKEY && varKey.m_vt == MF_SYS_FIELDTYPE_NULL)
				{
					return MF_COMMON_INVALID_NULLPRIMARYKEY;
				}

				lpIndexCondition->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
				lpIndexCondition->m_bFieldNo   = bFieldNo;
				lpIndexCondition->m_bFieldType = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;
				lpIndexCondition->m_varCondition2.SetData(varKey);
				if(lpIndex->m_bIndexType <= 10)
				{
					break;
				}
			}

			if(lpIndex->m_bIndexType > 10)
			{
				//将DataID作为最后一个关键字
				stIndexInfo.m_stMultiIndex.m_nIndexNum++;
				lpIndexCondition = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];

				lpIndexCondition->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
				lpIndexCondition->m_bFieldType = MF_SYS_FIELDTYPE_BIGINT;
				lpIndexCondition->m_varCondition2.SetData(nDataID);
			}

			//2.插入索引
			stIndexInfo.m_pBson        = &stBson;
			stIndexInfo.m_nIndexID	   = lpIndex->m_nIndexID;
			stIndexInfo.m_bFileNo	   = lpIndex->m_bFileNo;
			stIndexInfo.m_bIndexType   = lpIndex->m_bIndexType;
			stIndexInfo.m_nDataID      = nDataID;
			stIndexInfo.m_bFieldNo[0]  = lpIndex->m_bFieldNo[0];
			stIndexInfo.m_bFieldNo[1]  = lpIndex->m_bFieldNo[1];
			stIndexInfo.m_bFieldNo[2]  = lpIndex->m_bFieldNo[2];
			stIndexInfo.m_bFieldNo[3]  = lpIndex->m_bFieldNo[3];

			if(lpIndex->m_bConstraintType == MF_CONSTRAINT_PRIMARYKEY)
			{
				stIndexInfo.m_bUnique = TRUE;
			}
			else if(lpIndex->m_bConstraintType == MF_CONSTRAINT_UNIQUE)
			{
				stIndexInfo.m_bUnique = TRUE;
			}

			nRet = InsertIndex(&stIndexInfo, lpObjectInfo->m_nObjectID, NULL, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		nDataLen		-= nRecordLen + sizeof(RECORDBUFFERHEAD);
		lpDataBuffer	+= nRecordLen + sizeof(RECORDBUFFERHEAD);
	}

	pFile->SetObjectData(lpObjectInfo->m_nObjectID, NULL, lpObjectInfo->m_bObjectType, lpObjectBufferHead->m_nDataNum, 0, nTimestamp);
	pFile->TimestampUpdate(NULL, nTimestamp);
	for(lpIndex = lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
	{
		nRet = CSystemManage::instance().GetMemoryFileInstance(lpIndex->m_bFileNo, pVirtualFile);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(lpIndex->m_bIndexType >= 1 && lpIndex->m_bIndexType <= 6)
		{
			((CMemoryHashFile*)pVirtualFile)->TimestampUpdate(NULL, nTimestamp);
		}
		else if(lpIndex->m_bIndexType >= 11 && lpIndex->m_bIndexType <= 16)
		{
			((CMemoryBTreeFile*)pVirtualFile)->TimestampUpdate(NULL, nTimestamp);
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			导入数据
		参数说明：
			stBson：Bson对象
			stExecutePlanManager：执行计划
			lAffectCount：执行条数
			lpExecuteInfo：统计信息
************************************************************************/
int CCommonMemObject::Recover(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int i, nRet;
	LPBYTE lpAddr;
	CMemoryFile* pFile;
	LPSTEPINFO lpStepInfo;
	vector<int> vecBlockNo;
	LPBLOCKINFO lpBlockInfo;
	LPOBJECTDEF lpObjectInfo;
	LPSOURCEINFO lpSourceInfo;
	LPRECORDHEAD lpRecordHead;
	LPBASESTEPPARAM lpBaseParam;
	LPEXECUTESTEP lpExecuteStep;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pVirtualFile;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	nRet = CSystemManage::instance().GetObjectInfo(lpExecutePlan->m_nObjectID, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;

	lpBaseParam					= &lpExecutePlan->m_stBaseParam;
	lpBaseParam->m_bRecordType	= lpExecutePlan->m_stSourceInfo.m_bRecordType;
	lpBaseParam->m_lpObjectInfo	= (long long)lpObjectInfo;
	lpBaseParam->m_nTimestamp	= lpExecutePlan->m_nTimestamp;

	//1.资源申请
	lpSourceInfo = &lpExecutePlan->m_stSourceInfo;
	lpBlockInfo  = (LPBLOCKINFO)stBson.ConvertOffset2Addr(lpSourceInfo->m_nBlockOffset);
	for(i = 0; i < MF_MAX_BLOCKINFO_NUM; i++)
	{
		if(lpBlockInfo[i].m_bAlloc)
		{
			nRet = pFile->AllocBlock(lpExecutePlan, lpBlockInfo[i]);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}
	
	//2.锁定块
	nRet = CSystemManage::instance().LockObject(lpExecutePlan, lpObjectInfo, lpSourceInfo->m_nBlockNoNum, lpBlockInfo, MF_LOCK_OUTOFTIME);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//3.数据备份
	nRet = stExecutePlanManager.Move2Step();
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpStepInfo	= &lpExecutePlan->m_stStepInfo;
	for(i = 0; i < (int)lpStepInfo->m_nExecuteStepNum; i++)
	{
		nRet = stExecutePlanManager.NextStep(lpExecuteStep);
		if(nRet != MF_OK)
		{
			return nRet;
		}
 
		if(lpExecuteStep->m_bStepType == MF_EXECUTE_STEP_DELETEDATA || lpExecuteStep->m_bStepType == MF_EXECUTE_STEP_UPDATEDATA)
		{
			nRet = stBson.ConvertAddrID2Addr((UINT)lpExecuteStep->m_nParam1, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpRecordHead = (LPRECORDHEAD)lpAddr;
			nRet = pFile->DataBackUp(lpRecordHead->m_nDataID, lpExecutePlan->m_nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}
    
	//4.执行步骤
	lpStepInfo->m_nCurrentStepNo = 0;
	nRet = stExecutePlanManager.Move2Step();
	if(nRet != MF_OK)
	{
		return nRet;
	}

	lAffectCount = 0;
	for(i = 0; i < (int)lpStepInfo->m_nExecuteStepNum; i++)
	{
		nRet = stExecutePlanManager.NextStep(lpExecuteStep);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = ExecuteStep(stBson, lpBaseParam, lpExecuteStep, lAffectCount);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpStepInfo->m_nCurrentStepNo = i;
	}
	return MF_OK;
}
