﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "FunctionManager.h"
#include "SystemManage.h"
#include "MemoryFile.h"

CFunctionManager::CFunctionManager()
{

}

CFunctionManager::~CFunctionManager()
{

}

//序列操作函数
int CFunctionManager::NextVal(LPCTSTR lpszName, VARDATA& varResult)
{
	int nRet;
	long long nValue;
	nRet = CSystemManage::instance().GetSequenceNextVal(lpszName, nValue);
	varResult.SetData(nValue);
	return nRet;
}

int CFunctionManager::CurrVal(LPCTSTR lpszName, VARDATA& varResult)
{
	int nRet;
	long long nValue;
	nRet = CSystemManage::instance().GetSequenceCurrentVal(lpszName, nValue);
	varResult.SetData(nValue);
	return nRet;
}

//COUNT函数
int CFunctionManager::Count(CServiceBson& stBson, CDataIDContainer* pDataIDContainer, VARDATA& varResult, LPTRANSACTIONARRAY lpTransactionArray, long long nTimestamp, BYTE bFieldNo)
{
	BYTE bFileNo;
	unsigned int i;
	long long nDatID;
	CMemoryFile* pFile;
	int nRet, nCount,*arrField;
	RECORDDATAINFO stRecordInfo;
	IVirtualMemoryFile* pVirutalFile;
	if(0 == bFieldNo)
	{
		//COUNT(*)情况
		nCount = pDataIDContainer->size();
	}
	else
	{
		nCount  = 0;
		stRecordInfo.m_nTimestamp         = nTimestamp;
		stRecordInfo.m_lpTransactionArray = lpTransactionArray;
		pDataIDContainer->MoveFirst();
		for(i = 0; i < pDataIDContainer->size(); i++)
		{
			pDataIDContainer->NextDataID(nDatID);
			if(i == 0)
			{
				bFileNo = GetFileNoFromDataID(nDatID);
				nRet    = CSystemManage::instance().GetMemoryFileInstance(bFileNo, pVirutalFile);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				pFile	= (CMemoryFile*)pVirutalFile;
			}
			stRecordInfo.m_nDataID = nDatID;
			nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(stRecordInfo.m_lpRecordBuffer == NULL)
			{
				return MF_COMMON_RECORD_NOTEXIT;
			}
			arrField = (int*)(stRecordInfo.m_lpRecordBuffer + sizeof(BYTE));
			if(arrField[bFieldNo - 1] != 0)
			{
				nCount++;
			}
		}
	}
	varResult.SetData(nCount);
	return MF_OK;
}

int CFunctionManager::Count(CServiceBson& stBson, CSysRecordContainer* pRecordContainer, VARDATA& varResult, BYTE bFieldNo)
{
	int nCount;
	unsigned int i;
	LPSINGLERECORD lpSingleRecord;
	if(0 == bFieldNo)
	{
		//COUNT(*)情况
		nCount = pRecordContainer->size();
	}
	else
	{
		nCount  = 0;
		pRecordContainer->MoveFirst();
		for(i = 0; i < pRecordContainer->size(); i++)
		{
			pRecordContainer->NextRecord(lpSingleRecord);
			if(lpSingleRecord == NULL)
			{
				return MF_COMMON_RECORD_NOTEXIT;
			}
			if(lpSingleRecord->m_lpRecordData[bFieldNo - 1].m_vt != MF_VARDATA_NULL)
			{
				nCount++;
			}
		}
	}
	varResult.SetData(nCount);
	return MF_OK;
}

//获得普通函数的函数值
int CFunctionManager::GetFunctionVal(CServiceBson& stBson, BYTE bFunType, const VARDATA& varValue1, const VARDATA& varValue2, VARDATA& varResult)
{
	int nRet;
	switch(bFunType)
	{
	case MF_EXECUTEPLAN_OPERATOR_SYSDATE:
		nRet = SysData(varResult);
		break;
	case MF_EXECUTEPLAN_OPERATOR_NEXTVAL:
		nRet = NextVal(varValue1.m_lpszValue, varResult);
		break;
	case MF_EXECUTEPLAN_OPERATOR_CURRVAL:
		nRet = CurrVal(varValue1.m_lpszValue, varResult);
		break;
	case MF_EXECUTEPLAN_OPERATOR_TODATE:
		if(varValue1.m_vt == MF_VARDATA_DATE)
		{
			varResult.SetData(varValue1);
		}
		else
		{
			nRet = ToDate(varValue1.m_lpszValue, varValue2.m_lpszValue, varResult);
		}
		break;
	case MF_EXECUTEPLAN_OPERATOR_TOCHAR:
		nRet = ToChar(stBson, varValue1, varResult, varValue2.m_lpszValue);
		break;
	}
	return nRet;
}

//重载函数获得聚合函数的函数值
int CFunctionManager::GetFunctionVal(CServiceBson& stBson, BYTE bFunType, CDataIDContainer* pDataIDContainer, const VARDATA& varValue, VARDATA& varResult, LPTRANSACTIONARRAY lpTransactionArray, long long nTimestamp)
{
	int nRet;
	switch(bFunType)
	{
	case MF_EXECUTEPLAN_OPERATOR_COUNT:
		nRet = Count(stBson, pDataIDContainer, varResult, lpTransactionArray, nTimestamp, varValue.m_bValue);
		break;
	}
	return nRet;
}

int CFunctionManager::GetFunctionVal(CServiceBson& stBson, BYTE bFunType, CSysRecordContainer* pRecordContainer, const VARDATA& varValue, VARDATA& varResult)
{
	int nRet;
	switch(bFunType)
	{
	case MF_EXECUTEPLAN_OPERATOR_COUNT:
		nRet = Count(stBson, pRecordContainer, varResult, varValue.m_bValue);
		break;
	}
	return nRet;
}

//判断执行字段是否为COUNT(*)
BOOL CFunctionManager::IsCountAll(CServiceBson& stBson, LPEXECUTEFIELDBSON lpFieldBson)
{
	LPMATHEXPBSON lpMathExp;
	LPMATHEXPELEMENTBSON pMathFieldBson;

	lpMathExp = (LPMATHEXPBSON)stBson.ConvertOffset2Addr(lpFieldBson->m_nExpOffset);
	if(lpMathExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_COUNT)
	{
		pMathFieldBson = (LPMATHEXPELEMENTBSON)stBson.ConvertOffset2Addr(lpMathExp->m_nExpOffset1);
		if(pMathFieldBson->m_bFieldNo == 0)
		{
			return TRUE;
		}
	}
	return FALSE;
}

