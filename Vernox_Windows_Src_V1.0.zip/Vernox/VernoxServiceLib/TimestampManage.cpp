﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "TimestampManage.h"
#include "MemoryFile.h"
CTimestampManage * CTimestampManage::m_pSinstance = NULL;

CTimestampManage::CTimestampManage(void)
{
	GetSystemTimeAsFileTime((LPFILETIME)&m_nCurTimestampVal);

	::InitializeCriticalSection(&m_critTimestamp);
	::InitializeCriticalSection(&m_critTranaction);
	
	m_lpMemoryFileHead				= NULL;
	m_lpTimestampTransactionHead	= NULL;
	m_lpTimestampTransactionTail	= NULL;
	
	memset(m_arTimestampTransaction, 0, sizeof(m_arTimestampTransaction));
}

CTimestampManage::~CTimestampManage(void)
{
	::DeleteCriticalSection(&m_critTimestamp);
	::DeleteCriticalSection(&m_critTranaction);
}

CTimestampManage & CTimestampManage::instance()
{
	if(NULL == m_pSinstance)
	{
		m_pSinstance = new CTimestampManage;
	}
	return *m_pSinstance;
}

void CTimestampManage::DestoryInstance()
{
	if(m_pSinstance != NULL)
	{
		delete m_pSinstance;
		m_pSinstance = NULL;
	}
}

//函数最快执行时间大约为34ns,每秒最多可提供250万个时间戳
//时间戳变换成时间的方式代码为(nTimestamp为时间戳)：
//nTimestamp = nTimestamp >> 2;
//COleDateTime odt(*(LPFILETIME)&nTimestamp);
//odt.Format(_T("%Y-%m-%d %H:%M:%S"));

long long CTimestampManage::GetTimestamp()
{
	long long nTimestamp;

	//注意：此处大括号不能去掉
	GetSystemTimeAsFileTime((LPFILETIME)&nTimestamp);
	nTimestamp = nTimestamp << 2;
	if(TRUE)
	{
		EnterCriticalSection(&m_critTimestamp);
		//这里添加异常捕获机制是为了防止出现临界区锁死的情况
		try
		{
			if(nTimestamp > m_nCurTimestampVal)
			{
				//这个值完全符合要求，我们需要记录一下就直接返回给应用程序使用
				m_nCurTimestampVal = nTimestamp;
			}
			else
			{
				m_nCurTimestampVal++;
				nTimestamp = m_nCurTimestampVal;
			}
		}
		catch (...)
		{
			//即使出现异常，我们也可以为其产生时间戳
			m_nCurTimestampVal++;
			nTimestamp = m_nCurTimestampVal;
		}
		LeaveCriticalSection(&m_critTimestamp);
	}

	return nTimestamp;
}

//开启事务
void CTimestampManage::StartTransaction(long long nTimestamp)
{
	LPTIMESTAMP_TRANSACTION lpTimestampTransaction;
	EnterCriticalSection(&m_critTimestamp);
	try
	{
		//lpTimestampTransaction = new TIMESTAMP_TRANSACTION;
		GetTractionStruct(lpTimestampTransaction);
		lpTimestampTransaction->m_nCurTimestampVal = nTimestamp;
		lpTimestampTransaction->m_nState		   = MF_TIMESTAMP_TRANSACTION_STATE_START;
		lpTimestampTransaction->m_pNext			   = NULL;
		if(m_lpTimestampTransactionTail != NULL)
		{
			m_lpTimestampTransactionTail->m_pNext = lpTimestampTransaction;
			m_lpTimestampTransactionTail = lpTimestampTransaction;
		}
		else
		{
			m_lpTimestampTransactionHead = lpTimestampTransaction;
			m_lpTimestampTransactionTail = lpTimestampTransaction;
		}
	}
	catch (...)
	{
	}
	LeaveCriticalSection(&m_critTimestamp);
}

void CTimestampManage::SetTimestamp(long long llTimestamp)
{
	EnterCriticalSection(&m_critTimestamp);
	if (llTimestamp > m_nCurTimestampVal)
	{
		m_nCurTimestampVal = llTimestamp;
	}
	LeaveCriticalSection(&m_critTimestamp);
}

void CTimestampManage::SetSystemFileHead(LPSYSTEMFILEHEAD pFileHead)
{
	EnterCriticalSection(&m_critTimestamp);
	try
	{
		if(pFileHead == NULL)
		{
			m_lpMemoryFileHead = NULL;
		}
		else
		{
			//把系统文件的头内存共享过来，部分内容由这儿进行管理
			m_lpMemoryFileHead = pFileHead;
			if(pFileHead->m_nEndTimestamp != 0)
			{
				//用于系统初始化时，设置文件上次的最大时间戳，保证此值不会向回走
				m_nCurTimestampVal = pFileHead->m_nEndTimestamp;
			}
		}
	}
	catch (...)
	{
	}
	LeaveCriticalSection(&m_critTimestamp);
}

void CTimestampManage::TimestampTransactionFinish(long long nCurTimestampVal)
{
	LPTIMESTAMP_TRANSACTION lpTimestampTransaction, lpPrev, lpPrev2, lpTemp;
	
	EnterCriticalSection(&m_critTimestamp);
	try
	{
		lpPrev  = NULL;
		lpPrev2 = NULL;
		for(lpTimestampTransaction = m_lpTimestampTransactionHead; lpTimestampTransaction != NULL;)
		{
			//查找对应时间戳，并进行状态处理，目前的原则是在系统内存文件里记录目前可以存盘的最大时间戳，如果中间有未完成的时间戳，那么在两个未完成的时间戳之间只保留一个最大的完成时间戳
			if(lpTimestampTransaction->m_nCurTimestampVal == nCurTimestampVal)
			{
				lpTimestampTransaction->m_nState   = MF_TIMESTAMP_TRANSACTION_STATE_FINISH;
				if(lpTimestampTransaction->m_pNext != NULL && lpTimestampTransaction->m_pNext->m_nState == MF_TIMESTAMP_TRANSACTION_STATE_FINISH)
				{
					lpTemp = lpTimestampTransaction->m_pNext;
					lpTimestampTransaction->m_nCurTimestampVal = lpTimestampTransaction->m_pNext->m_nCurTimestampVal;
					lpTimestampTransaction->m_pNext = lpTimestampTransaction->m_pNext->m_pNext;
					if(m_lpTimestampTransactionTail == lpTemp)
					{
						m_lpTimestampTransactionTail = lpTimestampTransaction;
					}
					/*delete lpTemp;*/
					ReleaseTractionStruct(lpTemp);
				}

				if(lpPrev == NULL)
				{
					//修改系统内存文件头的最后事务时戳
					if(m_lpMemoryFileHead != NULL)
					{
						m_lpMemoryFileHead->m_nEndTimestamp = lpTimestampTransaction->m_nCurTimestampVal;
					}
					//这个时间戳排在第一个，需要修改头
					m_lpTimestampTransactionHead = lpTimestampTransaction->m_pNext;
					if(m_lpTimestampTransactionTail == lpTimestampTransaction)
					{
						m_lpTimestampTransactionTail = NULL;
					}
					//释放空间
					//delete lpTimestampTransaction;							//耗时8微秒
					ReleaseTractionStruct(lpTimestampTransaction);
				}
				else if(lpPrev->m_nState == MF_TIMESTAMP_TRANSACTION_STATE_START)
				{
					//前一个事务处于未结束状态，所以只修改当前事务的状态，不需要做任何处理
				}
				else if(lpPrev->m_nState == MF_TIMESTAMP_TRANSACTION_STATE_FINISH)
				{
					//需要把前一个完成状态删除
					if(lpPrev2 == NULL)
					{
						//按道理这种情况不可能存在
						m_lpTimestampTransactionHead = lpTimestampTransaction->m_pNext;
						if(m_lpTimestampTransactionTail == lpTimestampTransaction)
						{
							m_lpTimestampTransactionTail = NULL;
						}
						/*delete lpPrev;
						delete lpTimestampTransaction;*/

						ReleaseTractionStruct(lpPrev);
						ReleaseTractionStruct(lpTimestampTransaction);
					}
					else
					{
						lpPrev2->m_pNext = lpTimestampTransaction;
						//delete lpPrev;
						ReleaseTractionStruct(lpPrev);
					}
				}

				break;
			}
			else
			{
				lpPrev2 = lpPrev;
				lpPrev  = lpTimestampTransaction;
				lpTimestampTransaction = lpTimestampTransaction->m_pNext;
			}
		}
	}
	catch (...)
	{
	}
	LeaveCriticalSection(&m_critTimestamp);
}

BOOL CTimestampManage::CheckFinishFlag(long long nTimestamp)
{
	int nState;
	LPTIMESTAMP_TRANSACTION lpTimestampTransaction;
	EnterCriticalSection(&m_critTimestamp);
	nState = MF_TIMESTAMP_TRANSACTION_STATE_FINISH;
	try
	{
		for(lpTimestampTransaction = m_lpTimestampTransactionHead; lpTimestampTransaction != NULL; lpTimestampTransaction = lpTimestampTransaction->m_pNext)
		{
			//查找对应时间戳，并进行状态处理，目前的原则是在系统内存文件里记录目前可以存盘的最大时间戳，如果中间有未完成的时间戳，那么在两个未完成的时间戳之间只保留一个最大的完成时间戳
			if(lpTimestampTransaction->m_nCurTimestampVal == nTimestamp)
			{
				nState = lpTimestampTransaction->m_nState;
				break;
			}
		}
	}
	catch (...)
	{
		nState = MF_TIMESTAMP_TRANSACTION_STATE_START;
	}
	LeaveCriticalSection(&m_critTimestamp);
	if(nState == MF_TIMESTAMP_TRANSACTION_STATE_FINISH)
	{
		//Trace(_T("CheckFinishFlag"), 0, 101001001,_T("时间戳%lld失效"), nTimestamp);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

BOOL CTimestampManage::CheckTransactionActive()
{
	if(m_lpTimestampTransactionHead == NULL)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

long long GetSystemTimestamp()
{
	return CTimestampManage::instance().GetTimestamp();
}

void SetSystemTimestamp(long long nTimestamp)
{
	CTimestampManage::instance().SetTimestamp(nTimestamp);
}

CSystemTimestampTransactionManage::CSystemTimestampTransactionManage()
{
}

CSystemTimestampTransactionManage::~CSystemTimestampTransactionManage()
{
}

void CSystemTimestampTransactionManage::StartTransaction(long long nTimestamp)
{
	CTimestampManage::instance().StartTransaction(nTimestamp);
}

void CSystemTimestampTransactionManage::CommitTransaction(long long nTimestamp)
{
	CTimestampManage::instance().TimestampTransactionFinish(nTimestamp);
}

CSystemLockStateManage::CSystemLockStateManage()
{
	m_bLockType		 = 0;
	m_lpExecutePlan	 = NULL;
	m_lpLockObject   = NULL;
}

CSystemLockStateManage::~CSystemLockStateManage(void)
{	
	switch(m_bLockType)
	{
	case MF_LOCK_INDEX:
		{
			LPINDEXDEF lpIndexInfo;
			lpIndexInfo = (LPINDEXDEF)m_lpLockObject;
			CSystemManage::instance().UnLockIndex(m_lpExecutePlan, lpIndexInfo);
		}
		break;
	case MF_LOCK_BLOCK:
		{
			LPBASEBLOCKHEAD lpBlockHead;
			lpBlockHead = (LPBASEBLOCKHEAD)m_lpLockObject;
			CSystemManage::instance().UnLockBlock(m_lpExecutePlan, lpBlockHead);
		}
		break;
	}
}

int CSystemLockStateManage::Lock(MF_LOCK_STATUS_TYPE bStatus, DWORD dwMilliseconds, long long nTimestamp)
{
	int nRet;
	switch(m_bLockType)
	{
	case MF_LOCK_INDEX:
		{
			LPINDEXDEF lpIndexInfo;
			lpIndexInfo = (LPINDEXDEF)m_lpLockObject;
			nRet = CSystemManage::instance().LockIndex(m_lpExecutePlan, lpIndexInfo, bStatus, dwMilliseconds, nTimestamp);
		}
		break;
	case MF_LOCK_BLOCK:
		{
			LPBASEBLOCKHEAD lpBlockHead;
			lpBlockHead = (LPBASEBLOCKHEAD)m_lpLockObject;
			nRet = CSystemManage::instance().LockBlock(m_lpExecutePlan, lpBlockHead, dwMilliseconds);
		}
	default:
		return MF_COMMON_LOCKTYPE_ERROR;
	}

	return nRet;
}

int CTimestampManage::SetTransactionLine(CServiceBson& stBson, long long nTimestamp, UINT& nTransactionOffset, int& nTransactionNum)
{
	int nRet;
	UINT nOffset;
	long long* pTimestamp;
	LPTIMESTAMP_TRANSACTION lpTimestampTransaction;
	
	nTransactionOffset	= 0;
	nTransactionNum		= 0;
	EnterCriticalSection(&m_critTranaction);				//活动事务链是临界资源
	try
	{
		//try catch是为了防止程序异常导致临界区无法释放
		for(lpTimestampTransaction = m_lpTimestampTransactionHead; lpTimestampTransaction != NULL; lpTimestampTransaction = lpTimestampTransaction->m_pNext)
		{
			if(lpTimestampTransaction->m_nState != MF_TIMESTAMP_TRANSACTION_STATE_FINISH && lpTimestampTransaction->m_nCurTimestampVal <= nTimestamp)
			{
				//事务是活动事务，并且该事务在当前事务之前发起则需要被备份
				//这种分配空间的方式，所有时间戳都被分配在连续的内存中，所以可以按照数组的方式来访问
				nRet = stBson.AllocFromTempBuffer(pTimestamp, nOffset);
				if(nRet != MF_OK)
				{
					LeaveCriticalSection(&m_critTranaction);
					return nRet;
				}
				if(nTransactionOffset == 0)
				{
					nTransactionOffset = nOffset;
				}
				*pTimestamp = lpTimestampTransaction->m_nCurTimestampVal;
				nTransactionNum++;
			}
		}
		LeaveCriticalSection(&m_critTranaction);
	}
	catch (...)
	{
		LeaveCriticalSection(&m_critTranaction);
		return MF_FAILED;
	}
	return MF_OK;
}

//获取事务资源
void CTimestampManage::GetTractionStruct(LPTIMESTAMP_TRANSACTION& lpTransaction)
{
	int i;
	EnterCriticalSection(&m_critTranaction);	
	for(i = 0; i < 256; i++)
	{
		if(m_arTimestampTransaction[i].m_nState  == 0)
		{
			m_arTimestampTransaction[i].m_nState = 1;
			lpTransaction = &m_arTimestampTransaction[i];
			LeaveCriticalSection(&m_critTranaction);
			return;
		}
	}
	LeaveCriticalSection(&m_critTranaction);
	//清理事务链表
	lpTransaction = NULL;
}

//释放事务资源
void CTimestampManage::ReleaseTractionStruct(LPTIMESTAMP_TRANSACTION lpTransaction)
{
	EnterCriticalSection(&m_critTranaction);
	memset(lpTransaction, 0, sizeof(TIMESTAMP_TRANSACTION));
	LeaveCriticalSection(&m_critTranaction);
}