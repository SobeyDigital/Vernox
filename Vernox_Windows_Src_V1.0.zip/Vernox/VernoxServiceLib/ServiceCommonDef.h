﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
/************************************************************************
				定义服务端专用的一系列结构体
************************************************************************/
#include "../VernoxBaseLib/CommonDataDef.h"

class Check;
class CServiceBson;

#pragma pack(1)
//可变类型结构体数组定义
typedef struct stu_VARDATAARRAY
{
	int				    m_nFieldNum;
	int					m_nSize;
	BYTE			    m_bValid;
	BYTE				m_bEnd;
	BYTE				m_bReserved[2];
	VARDATA				m_lpRecordData[1];
}SINGLERECORD,*LPSINGLERECORD;

//系统表结果集定义
typedef struct stu_SYSRECORDSET
{
	int							m_nRecordNum;				//记录条数
	vector<LPSINGLERECORD>		m_vecSingleRecord;			//记录数据

	stu_SYSRECORDSET()
	{
		m_nRecordNum = 0;
	}

	~stu_SYSRECORDSET()
	{
		for(int i = 0; i < m_nRecordNum; i++)
		{
			delete m_vecSingleRecord[i];
		}
		m_vecSingleRecord.clear();
	}
}SYSRECORDSET,*LPSYSRECORDSET;

typedef struct stu_TRANSACTIONARRAY
{
	BYTE			m_bNum;
	long long*		m_pArray;

	stu_TRANSACTIONARRAY()
	{
		m_bNum = 0;
		m_pArray = NULL;
	}

	stu_TRANSACTIONARRAY(BYTE bNum, long long* pArray)
	{
		m_bNum = bNum;
		m_pArray = pArray;
	}
	~stu_TRANSACTIONARRAY()
	{
		m_bNum = 0;
		m_pArray = NULL;
	}

	BOOL CheckDataVisiable(long long nTimestamp)
	{
		int i;
		for(i = 0; i < m_bNum; i++)
		{
			if(m_pArray[i] == nTimestamp)
			{
				return FALSE;
			}
		}
		return TRUE;
	}
}TRANSACTIONARRAY, *LPTRANSACTIONARRAY;

//索引信息
typedef struct st_INDEXINFO
{
	CServiceBson*					m_pBson;				//Bson对象
	
	//索引基本信息
	int								m_nIndexID;				//索引ID
	BYTE							m_bFileNo;				//索引文件编号
	MF_SYS_INDEXTYPE				m_bIndexType;			//索引类型
	BYTE							m_bReserved[2];			//保留字段
	BYTE							m_bFieldNo[4];			//字段编号
	MULTIINDEX						m_stMultiIndex;			//符合索引信息

	BOOL							m_bUnique;				//是否是唯一索引
	
	//索引分页信息
	MF_PAGING_TYPE			        m_bPagingType;			//分页类型
	int								m_nPagePos;				//页面位置
	int								m_nPageSize;			//页面大小
	
	//索引结果信息
	int								m_nCount;				//记录数
	BOOL						    m_bEndSearch;			//查询是否结束
	BOOL							m_bFirstString;			//是否为第一个字符串
	long long						m_nDataID;			    //数据ID	
		
	//索引参数信息
	Check*							m_pCheck;				//除索引条件之外的其他条件，用于判断记录是否合法
	LPVOID							m_pParam1;				//参数1
	LPVOID							m_pParam2;				//参数2
	LPVOID							m_pParam3;				//参数3
	long long						m_nParam4;				//参数4
	long long						m_nParam5;				//参数5
	st_INDEXINFO()
	{
		clear();
	}

	void clear()
	{
		m_nIndexID		 = 0;
		m_nCount		 = 0;
		m_bFileNo		 = 0;
		m_nDataID		 = 0;
		m_bFirstString	 = 0;
		m_bIndexType	 = 0;
		m_bEndSearch 	 = 0;
		m_bPagingType	 = 0;
		m_nPageSize		 = 0;
		m_bFieldNo[0]	 = 0;			
		m_bFieldNo[1]    = 0;
		m_bFieldNo[2]    = 0;
		m_bFieldNo[3]    = 0;

		m_bUnique		 = FALSE;
		m_pCheck		 = NULL;
		m_pParam1		 = NULL;
		m_pParam2		 = NULL;
		m_pParam3		 = NULL;
		m_nParam4	     = 0;
		m_nParam5	     = 0;
		memset(&m_stMultiIndex, 0, sizeof(MULTIINDEX));
	}
}INDEXINFO, *LPINDEXINFO;

//查询信息
typedef struct stu_QUERYINFO
{
	UINT							m_nIndexOffset;			//索引条件地址指针
	int								m_nWhereOffset;			//where条件偏移
	int								m_nConnOffset;			//Connect条件偏移
	
	UINT							m_nConditionOffset;		//条件偏移
	long long						m_nDataID;				//数据ID
	MF_PAGING_TYPE					m_bPagingType;			//分页类型
	BYTE							m_bEndSearch;			//查询是否结束
	BYTE							m_bLevel;				//递归层数
	BYTE							m_bReserved;			//保留字段
	int								m_nPageSize;			//页面大小
	int								m_nPageNo;				//页面编号
	int							    m_nCount;				//记录数量
	DWORD							m_dwWhereHash;			//where条件的Hash值
	LPOBJECTDEF					    m_lpObjectInfo;			//对象信息	
	LPTRANSACTIONARRAY				m_lpTransactionArray;	//事务信息
	long long						m_nTimestamp;			//时间戳

	stu_QUERYINFO()
	{
		m_nIndexOffset				= 0;
		m_nWhereOffset				= 0;
		m_nConnOffset				= 0;
		m_nConditionOffset			= 0;
		m_nDataID					= 0;
		m_bPagingType				= 0;
		m_bEndSearch				= 0;	
		m_bLevel					= 255;				   //递归不能大于255
		m_nPageSize					= 0;
		m_nPageNo					= 0;
		m_nCount					= 0;
		m_lpObjectInfo				= 0;		
		m_lpTransactionArray		= 0;
		m_nTimestamp				= 0;
	}
}QUERYINFO, *LPQUERYINFO;

//关键字映射表(用于处理符合索引)
typedef struct
{	
	BYTE				m_bKeyOffset[4];		//关键字偏移，相对于LPKEYINFO起始位置，如果是字符串则指向字符串位置的偏移
	int				    m_nTotalKeyLen;			//关键字总长度
	int					m_nBufferOffset;		//关键字Buffer相对于LPKEYINFO起始位置的偏移，由于LPKEYINFO在关键字Buffer的中间，所以关键字Buffer的位置应该是LPKEYINFO - m_nKeyBufferOffset
}KEYINFO,*LPKEYINFO;

//关键字Buffer信息，16个字节小于KEYINFO的大小
typedef struct
{
	BYTE		m_bFlag;						//标志位，恒等于1
	BYTE		m_bReserved[3];					//保留字段
	int			m_nBufferSize;					//关键字大小
	long long	m_llNextOffset;					//下一个Buffer偏移
}KEYBUFFERINFO, *LPKEYBUFFERINFO;

//记录信息
typedef struct stu_RECORDDATAINFO
{
	long long			m_nDataID;				//数据ID
	MF_RECORD_TYPE		m_bRecordType;			//记录类型
	MF_DATAPOSITION		m_bDataPosition;		//数据位置(本地or回滚区)
	MF_DATAPOSITION		m_bAcutalDataPosition;	//实际获取数据位置
	BYTE				m_bReserved;			//保留字段

	long long			m_nTimestamp;			//时间戳
	LPTRANSACTIONARRAY  m_lpTransactionArray;	//事务数组
	int					m_nRecordLen;			//记录长度
	LPBYTE				m_lpRecordBuffer;		//记录Buffer
	
	long long			m_nParam1;				//参数1
	long long			m_nParam2;				//参数2
	long long			m_nRetValue;			//返回值
	stu_RECORDDATAINFO()
	{
	 	m_lpRecordBuffer		= NULL;
		m_nRecordLen			= 0;		
		*(int *)&m_bRecordType	= 0;				
		m_lpTransactionArray	= NULL;	
		m_nDataID				= 0;				
		m_nTimestamp			= 0;
		m_nParam1				= 0;
		m_nParam2				= 0;
	}
}RECORDDATAINFO, *LPRECORDDATAINFO;

//字段值信息
typedef struct stu_FIELDVALUEINFO
{
	BYTE				m_bFieldNo;				//字段编号
	LPMATHEXPBSON		m_lpMathExpression;		//数学表达式
	VARDATA				m_varFieldValue;		//字段值

	stu_FIELDVALUEINFO()
	{
		m_bFieldNo				= 0;			
		m_lpMathExpression		= NULL;		
	}
}FIELDVALUEINFO, *LPFIELDVALUEINFO;

//节点头
typedef struct
{
	long long	m_nFirstRelation;				//第一个关系ID
	long long   m_nFirstInRelation;				//第一个反关系ID
}NODEHEAD,*LPNODEHEAD;

typedef struct
{
	long long	m_nStartNodeID;					//起始节点ID
	long long   m_nNextRelationID;				//下一个关系ID
	long long	m_nEndNodeID;					//结束节点ID
	long long   m_nNextInRelationID;			//下一个反关系ID
}RELATIONHEAD,*LPRELATIONHEAD;

//导出参数
typedef struct
{
	BYTE		m_bLikType;
	BYTE		m_bReserved[3];
	UINT		m_nTransactionOffset;
	long long	m_nBlockMapOffset;
	int			m_nInnerDataPos;
	int			m_nRecordNum;
	BOOL		m_bComplete;
	BOOL		m_bRelation;
}EXPORTPARAM, *LPEXPORTPARAM;

typedef struct
{
	LPVOID		m_bParam1;
}IMPORTPARAM, *LPIMPORTPARAM;

//导入参数
#pragma pack()