﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                    内存文件管理类                                                                             //
//                                                                                                                                               //
//    实现内存文件管理类，实现内存数据的存储和查询。整个类主要管理好如何分块，如何管理多种对象在同一个文件中的情况，整个体系采用内存偏移来实现地 //
//址的链接，实现保存到文件，然后重新读取出来只需要做简单处理即可恢复整个数据结构。目前块大小默认按照1MB来进行分配，文件头部既可以浏览所有块信息，//
//也可以按照某个对象的数据链和空余链进行浏览。                                                                                                   //
//                                                                                                                                               //
//                                                                                                                            吴春中、张浩阳     //
//                                                                                                                            2014年7月          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma once
#include "MemoryBlock.h"
#include "MapSimple.h"
#define DEF_BLOCK_SIZE (1024*1024)
#define LINK_TYPE		BYTE
#define FREE_LINK		1
#define FULL_LINK		2

class CMemoryHashFile;
/************************************************************************
	内存文件类：实现对于内存块管理的相关操作
************************************************************************/
class CMemoryFile: public CBaseMemoryFile
{
protected:
	#pragma pack(1)
	/************************************************************************
		内存文件头(需要写入内存)
		说明，在内存文件类中，块地址映射表中的数据相当于一个定长数据
		这里的，块个数就是地址映射表中表项的个数，
		通过块个数和映射表表项长度来定位地址映射表中表项的插入位置
		地址映射表中的数据(表项)是顺序存放的，所以可以根据块号利用二分法在地址映射表中根据块号查询其对应的映射表位置，从而获得该块的地址
	************************************************************************/
	typedef struct 
	{
		int		m_nDataFlag;										//数据标志，目前定为‘SBMF’
		long long m_nTimestamp;										//文件保存的时间戳
		BYTE	m_bFileNo;											//文件编号
		BYTE	m_bStatus;											//内存文件数据锁定状态
		USHORT	m_usDatabaseGuid;									//数据库唯一标识
		long long m_nFileTotalSize;									//文件总大小
		int		m_nFileHeaderSize;									//文件头大小
		int		m_nBlockNum;										//块个数
		int		m_nBlockMapStructSize;								//块地址映射表中表项的长度，实际为FILEBLOCKMAP结构体大小
		int		m_nBlockMapStartOffset;								//指向第一个FILEBLOCKMAP结构体的地址
		long long m_nBlockStartOffset;								//块的起始地址
		BASEFILEOBJECTDEF m_stFileObjectData[MAX_OBJECT_NUM];		//文件对象数据表
		BASEFILEOBJECTDEF m_stFileRelationData[MAX_OBJECT_NUM];		//关系对象数据表

		int		m_nInnerMaxNo;										//块编号最大值，用于插入时
		long long m_nFileFreeSize;									//空闲区大小
		long long m_nFileFreeMemoryOffset;							//空闲空间首地址
		long long m_nFreeBlockMapOffset;							//对象删除等回收的BLOCK块的映射结点偏移地址
		long long m_nBlockMapSize;									//块映射表大小
		int		m_nMaxBlockMapNum;									//最大块数量
	}FILEHEAD, *LPFILEHEAD;
	
	typedef struct
	{
		LINK_TYPE		m_bLikType;
		BOOL			m_bStart;
		BOOL			m_bLock;
		BOOL		    m_bRelationObject; 
		int				m_nBlockNo;
		long long		m_nBlockMapOffset;
	}LINKINFO,*LPLINKINFO;
	#pragma pack()
protected:
	friend class CMemoryBlock;
	LPFILEHEAD	m_lpMemoryFileHead;									//内存映射文件头(m_pMemoryFileHead = (MemoryFileHead*)m_pFile)
	LPBASEFILEBLOCKMAPHEAD m_lpBlockMapTail;						//文件块映射链表尾
	CMapSimple	m_mapMemoryBlock;									//块号和内存块对象指针映射Map
	int			m_nFreeLinkLen;
protected:
	//防止此类被非法构造成对象或者复制
	CMemoryFile(const CMemoryFile&);
	CMemoryFile& operator = (const CMemoryFile&);

protected:
	/************************************************************************
		功能说明：
			初始化内存文件管理类，让整个实例是可执行的
	************************************************************************/
	int SetFileAddr(LPBYTE pFileAddr);

	/************************************************************************
		功能说明：
			获取起始块的偏移
	************************************************************************/
	int GetStartBlockMapOffset(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, LINK_TYPE bLinkType, BOOL bRelation, long long& nBlockMapOffset);

	/************************************************************************
		功能说明：
			获取当前块的下一个块的偏移
	************************************************************************/
	void GetNextBlockMapOffset(LPEXECUTEPLANBSON lpExecutePlan, long long& nBlockMapOffset);

	/************************************************************************
		功能说明：
			从满块或空块链表上获取一个块对象
	************************************************************************/
	int GetBlockFromLink(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, LPLINKINFO lpLinkInfo, CMemoryBlock*& pBlock);

	/************************************************************************
		功能说明：
			在链表中查找nBlockNo对应的块
	************************************************************************/
	BOOL FindBlockInLink(LPEXECUTEPLANBSON lpExecutePlan , int nObjectID, LINK_TYPE blinkType, MF_OBJECT_TYPE bObjectType, int nBlockNo);
	
	/************************************************************************
		功能说明：
			将内部数据ID转换成块类的实例指针
	************************************************************************/
	CMemoryBlock* ConvertDataIDtoBlockObject(long long nDataID);

	/************************************************************************
		功能说明：
			根据对象ID获取一个Object数据
	************************************************************************/
	int GetFileObject(int nObjectID, LPBASEFILEOBJECTDEF& lpFileObject, BOOL bRelationObject);

	/************************************************************************
		功能说明：
			分配空间并创建内存块
	************************************************************************/
	int AllocBlock(LPEXECUTEPLANBSON lpExecutePlan, int& nBlockNo, int nBlockSize = DEF_BLOCK_SIZE);
	int AllocBlock(int nObjectID, BYTE bObjectType, int nBlockSize, long long nTimestamp, int& nBlockNo);
	
	/************************************************************************
		功能说明：
			行迁移
	************************************************************************/
	int RecordRemove(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo, long long& nNextDataID);

	/************************************************************************
		功能说明：
			将一个映射表结点插入一个链表(头插法)
	************************************************************************/
	int InsertMapStruct(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, BYTE bObjectType, MF_OBJECT_TYPE bLinkType, long long nBlockMapOffset);

	/************************************************************************
		功能说明：
			将一个某块从一个链表移动到另一个链表
	************************************************************************/
	int MoveMapStruct(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, BYTE bObjectType, int nBlockNo, LINK_TYPE bSrcLinkType);

public:
	CMemoryFile(void);
	~CMemoryFile(void);

public:
	/************************************************************************
		功能说明：
			分配块
	************************************************************************/
	int AllocBlock(LPEXECUTEPLANBSON lpExecutePlan, BLOCKINFO& stBlockInfo);

	/************************************************************************
		功能说明：
			解锁块
	************************************************************************/
	int UnlockBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo);

	/************************************************************************
		功能说明：
			锁定块
	************************************************************************/
	int LockBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo, DWORD dwMilliseconds);

	/************************************************************************
		功能说明：
			锁定块
	************************************************************************/
	int LockBlock(LPEXECUTEPLANBSON lpExecutePlan, long long& nDataID, DWORD dwMilliseconds);

	/************************************************************************
		功能说明：
			提供给Update的RollBack函数
	************************************************************************/
	int UpdateRollBack(LPEXECUTEPLANBSON lpExecutePlan, long long nDataID);
	
	/************************************************************************
		功能说明：
			提供给Delete的回滚
	************************************************************************/
	int DeleteRollBack(long long nDataID, long long nTimestamp);

	/************************************************************************
		功能说明：
			提供给Insert的回滚
	************************************************************************/
	int InsertRollBack(long long nDataID, long long nTimestamp);

	/************************************************************************
		 功能说明：
			创建对象信息
	************************************************************************/
	int CreateObject(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, BYTE bObjectType, long long nTimestamp);

	/************************************************************************
		功能说明：
			获取某Object的所有记录数
	************************************************************************/
	int GetObjectDataNum(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, LPTRANSACTIONARRAY lpTransactionArray, int& nDataNum);

	/************************************************************************
		功能说明：
			获取对象记录数量指针
	************************************************************************/
	long long* GetObjectDataPtr(int nObjectID, MF_OBJECT_TYPE bObjectType);

	/************************************************************************
		功能说明：
			将记录与即将插入的位置进行绑定
	***********************************************************************/
	int BindDataID(CExecutePlanManager& stExecutePlanManager, int nRecordNum, LPBLOCKINFO arBlockInfo);

	/************************************************************************
		功能说明：
			将数据写入内存
	***********************************************************************/
	int InsertData(CServiceBson& stBson, LPBASESTEPPARAM lpBaseParam, LPEXECUTESTEP lpStep);
	int InsertData(int nObjectID, MF_OBJECT_TYPE bObjectType, LPBYTE lpBuffer, int nLen, long long nTimestamp, long long& nDataID);

	/************************************************************************
		功能说明：
			修改内存文件的对应数据
	************************************************************************/
	int UpdateData(CServiceBson& stBson, LPBASESTEPPARAM lpBaseParam, LPEXECUTESTEP lpStep);

	/************************************************************************
		功能说明：
			从内存文件中删除对应数据
	************************************************************************/
	int DeleteData(CServiceBson& stBson, LPBASESTEPPARAM lpBaseParam, LPEXECUTESTEP lpStep);
	int DeleteData(CServiceBson& stBson, long long nDataID);

	/************************************************************************
		功能说明：
			用于进行数据块内存整理
	************************************************************************/
	int MergeMemory(LPEXECUTEPLANBSON lpExecutePlan);

	/************************************************************************
		功能说明：
			删除对象时，调此函数释放对应内存块
	************************************************************************/
	int RecycleFileData(LPEXECUTEPLANBSON lpExecutePlan);

	/************************************************************************
		功能说明：
			获取文件的空间信息
	************************************************************************/
	int GetFileSpace(LPEXECUTEPLANBSON lpExecutePlan, long long &nFileTotalSize, long long &nFileUseSize, long long &nFileFreeSize);
	
	/************************************************************************
		功能说明：
			获取块空闲空间大小
	************************************************************************/
	int GetBlockFreeSize(int nBlockNo, int& nFreeSize);

	/************************************************************************
		功能说明：
			删除对象
	************************************************************************/
	int DropObject(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID);

	/************************************************************************
		功能说明：
			设置文件数据
	************************************************************************/
	void SetObjectData(int nObjectID, LPEXECUTEPLANBSON lpExecutePlan, MF_OBJECT_TYPE bObjectType, long long nInsertDataNum, long long nDeleteDataNum, long long nTimestamp);
	
	/************************************************************************
		功能说明：
			数据备份
	************************************************************************/
	int DataBackUp(long long nDataID, long long nTimestamp);

	/************************************************************************
		功能说明：
			闪回
	************************************************************************/
	int FlashBack(int nBlockNo, LPBYTE &pBuffer, long long nTimestamp);

	/************************************************************************
		功能说明:
			获取文件头
	************************************************************************/
	virtual LPBASEFILEHEAD GetFileHead()
	{
		return (LPBASEFILEHEAD)m_lpMemoryFileHead;
	}

	/************************************************************************
		功能说明：
			修改时间戳
	************************************************************************/
	void TimestampUpdate(LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
	{
		//根据块的指针判断块的类型(存放哈希表的块还是存放索引项的块)
		CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileCritical(), lpExecutePlan);
		if(m_lpMemoryFileHead->m_nTimestamp < nTimestamp)
		{
			m_lpMemoryFileHead->m_nTimestamp = nTimestamp;
		}
	}

	/************************************************************************
		功能说明：
			清理文件数据
	************************************************************************/
	void ClearDataFile();

	/************************************************************************
		功能说明：
			下一个DataID（用于全表遍历）
	************************************************************************/
	int GetNextDataID(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, BOOL bRelation, LINK_TYPE& bLikType, long long& nBlockMapOffset, int& nDataNo, long long& nDataID);

	/************************************************************************
		功能说明：
			获取记录Buffer
	************************************************************************/
	int GetRecordBuffer(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo);
	
	/************************************************************************
		功能说明：
			获取记录指针
	************************************************************************/
	int GetRecordPtr(LPRECORDDATAINFO lpRecordInfo);

	/************************************************************************
		功能说明：
			获取记录中的字段值
	************************************************************************/
	int GetRecordFieldValue(CServiceBson *pBson, CExpression* pExpression, LPRECORDDATAINFO lpRecordInfo, BYTE bFieldNo, VARDATA& varResult);

	/************************************************************************
		功能说明：
			导出表
	************************************************************************/
	int ExportObject(CServiceBson& stBson, int nObjectID, LPEXPORTPARAM lpExportParam, long long nTimestamp, LPTRANSACTIONARRAY lpTransactionArray);

	/************************************************************************
		功能说明：
			获取记录数量
	************************************************************************/
	long long GetRecordNum();

	/************************************************************************
		功能说明：
			备份文件数据
	************************************************************************/
	int BackUpFileData(LPBYTE lpBuffer, int nBufferSize);
};
