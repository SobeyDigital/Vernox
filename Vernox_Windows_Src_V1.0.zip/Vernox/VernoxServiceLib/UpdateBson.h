﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "Expression.h"
class CUpdateBson
{
public:
	CUpdateBson(CServiceBson* pServiceBson);
	~CUpdateBson(void);

private:
	CServiceBson*	m_pBson;
	CExpression		m_stExpression;
	LPOBJECTDEF		m_lpObjectInfo;

	LPBYTE			m_lpBuffer;					
	UINT			m_nBufferSize;				
	UINT			m_nDataSize;				

private:
	/************************************************************************
		功能说明：
			从记录中获取字段Buffer
	************************************************************************/
	int GetFieldBufferFromRecordBuffer(LPBYTE lpRecordBuffer, int nBufferLen, BYTE bFieldNo, LPBYTE& lpFieldBuffer, int& nFieldBufferLen);

	/************************************************************************
		功能说明：
			为记录分配空间
	************************************************************************/
	int AllocRecordBuffer(UINT nBufferLen);

	/************************************************************************
		功能说明：
			从BSON缓存中分配空间
	************************************************************************/
	int AllocFromBsonBuffer(UINT nLen, UINT &nOffset, LPBYTE &lpAddr);

	/************************************************************************
		功能说明：
			将字段值写入指定位置
	************************************************************************/
	int WriteFieldData(MF_SYS_FIELDTYPE bFieldType, BYTE bFieldNo, VARDATA &varData, LPBYTE lpAddr = NULL);

	/************************************************************************
		功能说明：
			插入字符串类型数据
	************************************************************************/
	BOOL AppendBuffer(void* pData, int nLen);

public:
	void Initial(LPOBJECTDEF lpObjectInfo);

	//获取更新字段的长度	
	int GetBsonLen(LPRECORDDATAINFO lpRecordInfo, LPEXECUTEFIELDBSON lpExecuteField, int nFieldNum, int& nNewDataLen);
	int GetBsonLen(LPRECORDDATAINFO lpRecordInfo, LPXMLFIELDBSON* lpFieldBsonMap, int& nNewDataLen);

	//创建Bson
	int BuildBson(int nRecordLen, LPEXECUTEFIELDBSON* lpFieldBsonMap, LPRECORDDATAINFO lpRecordInfo, LPBASESTEPPARAM lpParam);
	int BuildBson(int nRecordLen, LPXMLFIELDBSON* lpFieldBsonMap, LPRECORDDATAINFO lpRecordInfo, LPBASESTEPPARAM lpParam);
};
