﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include "DataIDContainer.h"
class CExecuteDataID : public CDataIDContainer
{
public:
	CExecuteDataID(CServiceBson* pServiceBson);
	~CExecuteDataID(void);

private:
	UINT	m_nCurrentDataIDNo;		    //当前DataID编号
	UINT	m_nDataIDAddrID;			//DataID的起始地址ID
	UINT	m_nDataIDNum;				//DataID数量
	CServiceBson* m_pServiceBson;		//Bson对象
	
	LPRECORDHEAD m_lpRecordHead;
public:
	virtual int push_back(long long nDataID);
	
	inline UINT size()
	{
		return m_nDataIDNum;
	}

	inline void resize(UINT nDataIDNum)
	{
		m_nDataIDNum = nDataIDNum;
	}

	inline UINT GetDataIDAddr()
	{
		return m_nDataIDAddrID;
	}

	//清空
	virtual void clear();

	//弹出DataID
	virtual long long PopDataID();

	//移动到DataID的起始位置
	virtual void MoveFirst();

	//下一条DataID
	virtual int NextDataID(long long& nDataID);
	
	//下一条记录头
	virtual int NextRecordHead(LPRECORDHEAD& lpRecordHead);
};
