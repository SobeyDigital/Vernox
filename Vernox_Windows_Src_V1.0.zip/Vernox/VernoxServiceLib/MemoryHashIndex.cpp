﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryHashFile.h"
#include "MemoryHashIndex.h"
#include "MemoryHashFile.h"
#include "MemoryFile.h"
#include "Check.h"
CMemoryHashIndex::CMemoryHashIndex(void)
{
}


CMemoryHashIndex::~CMemoryHashIndex(void)
{
}
/************************************************************************
		功能说明：
			从空闲区队列中分配一条空索引项
************************************************************************/
int CMemoryHashIndex::AllocBlock(LPEXECUTEPLANBSON lpExecutePlan, int& nBlockNo, int nObjdectID, int nBlockSize, long long llTimestamp)
{
	return m_pHashFile->AllocBlock(lpExecutePlan, nBlockNo, nObjdectID, nBlockSize, llTimestamp);
}

/************************************************************************
		功能说明：
			释放内存块(清空),并把块号添加到空块队列中
************************************************************************/
int CMemoryHashIndex::FreeBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo, long long llTimestamp)
{
	return m_pHashFile->FreeBlock(lpExecutePlan, nBlockNo, llTimestamp);
}

/************************************************************************
		功能说明：
			修改根结点
************************************************************************/
int CMemoryHashIndex::RootUpdate(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nBlockNo)
{
	return m_pHashFile->RootUpdate(lpExecutePlan, nIndexID, nBlockNo);
}

/************************************************************************
		功能说明：
			将偏移转换为实际地址
************************************************************************/
LPBYTE CMemoryHashIndex::ConvertOffsettoAddr(long long nOffset)
{
	return m_pHashFile->m_lpFileAddr + nOffset;
}

/************************************************************************
		功能说明：
			将偏移转换为实际地址
************************************************************************/
long long CMemoryHashIndex::ConvertAddrtoOffset(LPBYTE lpAddr)
{
	return lpAddr - m_pHashFile->m_lpFileAddr;
}

/************************************************************************
		功能说明：
			根据块号获得块在内存中的实际地址
************************************************************************/
LPBYTE CMemoryHashIndex::ConvertBlockNotoAddr(int nBlockNo)
{
	return m_pHashFile->ConvertBlockNotoAddr(nBlockNo);
}

/************************************************************************
		功能说明：
			将条索引项的实际地址转换为其块头的地址
		参数说明:
			nMemoryOffset：实际地址
			nBlockHeadOffset：块头地址
			nBlockSize:块大小
		特别说明:
			由于内存文件中内存块的大小固定(不论内存块是用于存放索引项还是哈希表)，
			所以可以很方便的计算一个实际地址(相对于文件头的偏移量)所属的块块头地址
			转换完成后，根据nBlockHeadOffset取出块头标识进行校验，校验失败则发挥FASLE
************************************************************************/
int CMemoryHashIndex::ConvertIndexOffsettoBlockOffset(long long nIndexOffset, int nBlockSize, long long& nBlockOffset)
{
	LPINDEXBLOCKHEAD lpBlockHead;
 
	nBlockOffset = (nIndexOffset / DEF_HASHBLOCK_SIZE) * DEF_HASHBLOCK_SIZE; 
	lpBlockHead = (LPINDEXBLOCKHEAD)(m_pHashFile->m_lpFileAddr + nBlockOffset);
	if(INDEXBLOCK == lpBlockHead->m_bBlockTypeFlag && lpBlockHead->m_nDataFlag == MAKEHEADFLAG('S','B','D','B'))			
	{
		return MF_OK;
	}
	else
	{
		return MF_KVINDEX_INVALINDEXOFFSET_ERROR;
	}
}

/************************************************************************
		功能说明：
			当达到reHash条件时开始执行reHash
		参数说明：
			lpExecutePlan：执行计划时间戳
			llTimestamp：时间戳
		步骤：
			分配一个原哈希表两倍大小的块，作为reHash表，由于ReHash是渐进式的，所以具体的ReHash操作是在执行增闪插该时进行的
************************************************************************/
int CMemoryHashIndex::BeginRehash(LPEXECUTEPLANBSON lpExecutePlan, long long llTimestamp)
{
	int nRet, nAllocBlockSize, nBlockNo;
	//分配一个原哈希表两倍大小的块，作为reHash表
	nAllocBlockSize = 4*m_lpHashTableHead->m_nBlockSize;

	//执行块分配
	nBlockNo = 0;
	nRet = AllocBlock(lpExecutePlan, nBlockNo, m_nIndexID, nAllocBlockSize, llTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	m_lpRehashTable = ConvertBlockNotoAddr(nBlockNo);
	if(m_lpRehashTable == NULL)
	{
		return MF_KVINDEX_INVALIDBLOCKNO_ERROR;
	}

	//修改Hash表中的相关变量
	m_lpRehashTableHead = (LPHASHBLOCKHEAD)m_lpRehashTable;
	InitialHashBlock(m_lpRehashTableHead, m_lpHashTableHead->m_nHashIndexNodeSize);	

	m_lpHashTableHead->m_nReHashTableOffset = ConvertAddrtoOffset(m_lpRehashTable);
	m_lpRehashTableHead->m_llHBTreeRootID   = m_lpHashTableHead->m_llHBTreeRootID;
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpRehashTable, llTimestamp);
	return MF_OK;
}

/************************************************************************
		功能说明:
			实现ReHash
		参数说明:
			lpExecutePlan：执行计划
			nRehashNodePos：要进行reHash的结点编号
			llTimestamp：时间戳
		特别说明:
			ReHash的步骤
			1.首先从空闲区链表中分配一块空间区，作为reHashTable，并将其入口偏移量赋值给ROOT结构体的m_nReHashTableOffset成员
			2.采用渐进式实现ReHash，即每次进行索引的添加、删除查找时，从HashTable中的第一个结点开始，每次将一个结点中的所有索引项迁移到reHashTable中(用m_nReHashIndex来记录迁移进行到了第几个节点)
			  注意，迁移的具体实现方式：
			  (1)获得需要迁移的HashNode的地址
			  (2)遍历HashNode的索引链表，获得每一个索引项的key值，然后在reHash表中算出这个key值所在的HashNode的编号，即其相对于HashNode头的偏移
			     (根据m_reHashTableOffset和这个编号就可以计算出这个HashNode的地址)然后将索引项的key值和dataID写入该HashNode
			  (3)同样采用“插头法”形成索引链表
		    3.ReHash完成之后，释放m_HashTableOffset指定的哈希表，然后将ROOT结构体中m_HashTableOffset的值赋为m_nReHashTableOffset，并将m_nReHashTableOffset赋值为0

			可以看到这种方式有一个相当大的好处，就是在渐进式执行reHash的时候，没有进行任何数据的移动，并且可以很方便的使HashTable和reHashTable中都存在原有索引项的位置信息
			(新插入的索引项直接插入reHashTable)这样在reHash完成之前，对于原索引项的检索都可以很方便的从HashTable从获取，而不需要去reHashTable中获取
************************************************************************/
int CMemoryHashIndex::Rehash(LPEXECUTEPLANBSON lpExecutePlan, int& nRehashNodePos, long long llTimestamp)
{
	VARDATA varKey;
	LPBYTE lpBlock;
	LPVOID lpNodeData;
	int nRet, nRehashNodeNo, nBlockNo;
	LPHASHNODE lpHashNode, lpRehashNode;
	long long nCurrentOffset, nBlockOffset;
	//遍历lpHashNode结点，将其中的所有索引项，全部挂到reHash表的结点上				
	lpHashNode = GetHashNode(m_lpHashTable, nRehashNodePos);

	while(0 == lpHashNode->m_nIndexOffset && nRehashNodePos < m_lpHashTableHead->m_nHashTableLen - 1)
	{
		lpHashNode++;			//将哈希表中reHash的位置向下移动一个结点长度
		nRehashNodePos++;
	}

	while(lpHashNode->m_nListLen)
	{
		//在ReHashTable中计算该索引项所在的结点的顺序，并获得其地址指针
		nCurrentOffset = lpHashNode->m_nIndexOffset;
		lpNodeData	   = ConvertOffsettoAddr(nCurrentOffset);
		GetKeyValue(lpNodeData, varKey);
	
		nRehashNodeNo  = CalcKeyHash(varKey, m_lpRehashTableHead->m_nHashTableLen);	
		lpRehashNode   = GetHashNode(m_lpRehashTable, nRehashNodeNo);

		//首先将该索引项在原HashTable中的结点中断开，然后再将该索引项插入ReHashTable中的相应结点
		lpHashNode->m_nIndexOffset   = *(long long*)lpNodeData;

		*(long long*)lpNodeData	     = lpRehashNode->m_nIndexOffset;	
		lpRehashNode->m_nIndexOffset = nCurrentOffset;
									 
		lpHashNode->m_nListLen--;									//递减原哈希表冲突链表长度
		lpRehashNode->m_nListLen++;									//递增reHash表冲突链表长度

		nRet = ConvertIndexOffsettoBlockOffset(nCurrentOffset, DEF_HASHBLOCK_SIZE, nBlockOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpBlock = ConvertOffsettoAddr(nBlockOffset);

		TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)lpBlock, llTimestamp);
	}
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpHashTable, llTimestamp);

	nRehashNodePos++;
	if(nRehashNodePos == m_lpHashTableHead->m_nHashTableLen)
	{
		nRet = RootUpdate(lpExecutePlan, m_nIndexID, m_lpRehashTableHead->m_nBlockNo);		//reHash结束，执行RootUpdate
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nBlockNo = m_lpHashTableHead->m_nBlockNo;
		m_lpRehashTableHead->m_nDataBlockOffset = m_lpHashTableHead->m_nDataBlockOffset;	//将满块链表首地址赋值给reHash表
		m_lpRehashTableHead->m_nFreeBlockOffset = m_lpHashTableHead->m_nFreeBlockOffset;	//将空块链表首地址赋值给reHash表
		m_lpRehashTableHead->m_llHBTreeRootID   = m_lpHashTableHead->m_llHBTreeRootID;

		m_lpHashTable		= m_lpRehashTable;
		m_lpHashTableHead	= m_lpRehashTableHead;
		m_lpRehashTable		= NULL;
		m_lpRehashTableHead = NULL;
		FreeBlock(lpExecutePlan, nBlockNo, llTimestamp);						 //回收原Hash表
		return MF_OK;
	}
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpRehashTable, llTimestamp);
	return MF_OK;
}

/************************************************************************
		功能说明：
			在内存中插入一条索引项
		参数说明：
			lpIndexInfo：索引信息
			lpExecutePlan：执行计划
			llTimestamp：时间戳
************************************************************************/
int CMemoryHashIndex::InsertData(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long llTimestamp)
{
	LPBYTE lpNodeData;
	int nRet, nBlockNo;
	LPINDEXBLOCKHEAD lpBlockHead;
	long long nCurrentBlockOffset, nInsertOffset;

	//首先在哈希头中找到一个可以插入索引项的块
	//注意：不论是在HashTable中插入索引项还是在ReHashTable中插入索引项
	//		对于内存块的实际管理都是由HashTable来完成
	//		删除同理，即在进行ReHash未完成之前，虽然对于索引数据的插入操作和部分删除操作会在ReHash表上进行，但对于数据块的管理都由原Hash表负责

	nCurrentBlockOffset = m_lpHashTableHead->m_nFreeBlockOffset;
	if(0 == nCurrentBlockOffset)
	{
		//如果没有可插数据块，则需要向文件级申请一块内存块
		nRet = AllocBlock(lpExecutePlan, nBlockNo, m_nIndexID, DEF_HASHBLOCK_SIZE, llTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;						
		}
		else
		{
			lpBlockHead = (LPINDEXBLOCKHEAD)ConvertBlockNotoAddr(nBlockNo);
			nCurrentBlockOffset = ConvertAddrtoOffset((LPBYTE)lpBlockHead);
			InitialIndexBlock(lpBlockHead, sizeof(INDEXBLOCKHEAD));
			m_lpHashTableHead->m_nFreeBlockOffset = nCurrentBlockOffset;
		}												
	}
	else
	{
		lpBlockHead = (LPINDEXBLOCKHEAD)ConvertOffsettoAddr(nCurrentBlockOffset);
	}

	if(lpBlockHead->m_nFreeIndexOffset)
	{
		//如果空闲索引项链表不为空，则从空闲索引项链表中分配一块空索引项进行插入
		nInsertOffset = lpBlockHead->m_nFreeIndexOffset;			//获得插入位置的偏移
		lpNodeData    = ConvertOffsettoAddr(nInsertOffset);			//获得插入位置指针

		lpBlockHead->m_nFreeIndexOffset = *(long long*)lpNodeData;  //将该空索引项删除空索引链
	}
	else
	{
		//如果空闲索引项链表为空，则从空闲区中分配一块空索引项进行插入
		nInsertOffset = nCurrentBlockOffset + lpBlockHead->m_nBlockHeadSize + lpBlockHead->m_nDataNum * m_lpHashTableHead->m_nHashIndexNodeSize;		//获得插入位置的偏移
		lpNodeData    = ConvertOffsettoAddr(nInsertOffset);	       //获得插入位置指针
	}

	//将索引项写入内存
	SetNodeData(lpNodeData, lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2, lpIndexInfo->m_nDataID);

	lpBlockHead->m_nDataNum++;									  //修改块头的相关数据，对内存进行整理

	if(lpBlockHead->m_nDataNum == lpBlockHead->m_nTotalDataNum)
	{
		//将该内存块移至满块链表中
		m_lpHashTableHead->m_nFreeBlockOffset = lpBlockHead->m_nNextBlockOffset;						//将该块从空块链表中删除
		if(lpBlockHead->m_nNextBlockOffset != 0)
		{
			((LPINDEXBLOCKHEAD)(ConvertOffsettoAddr(lpBlockHead->m_nNextBlockOffset)))->m_nPreBlockOffset = 0;
		}

		lpBlockHead->m_nNextBlockOffset			= m_lpHashTableHead->m_nDataBlockOffset;				//将该块插入满块链表中
		m_lpHashTableHead->m_nDataBlockOffset	= nCurrentBlockOffset;
		lpBlockHead->m_nPreBlockOffset			= 0;
		if(lpBlockHead->m_nNextBlockOffset != 0)
		{
			((LPINDEXBLOCKHEAD)(ConvertOffsettoAddr(lpBlockHead->m_nNextBlockOffset)))->m_nPreBlockOffset = nCurrentBlockOffset;
		}

		lpBlockHead->m_bBlockFull = 1;
	}
	lpIndexInfo->m_nParam4 = nInsertOffset;
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)lpBlockHead, llTimestamp);
	return MF_OK;	
}

/************************************************************************
		功能说明:
			从内存中删除一条索引项
		参数说明:
			lpIndexInfo：索引信息
			lpHashNode：哈希结点
			llTimestamp：时间戳
		返回值说明:
			返回插入的索引项的偏移
		特别说明：
			该函数是实际将索引项从内存中删除的函数
************************************************************************/
int CMemoryHashIndex::DeleteData(LPINDEXINFO lpIndexInfo, LPHASHNODE lpHashNode, long long llTimestamp)
{
	int nRet;
	VARDATA varKey;
	LPEXECUTEPLANBSON lpExecutePlan;
	LPBYTE lpBlock, lpNodeData, lpPreNodeData;
	long long nIndexOffset, nBlockOffset, nDataID;
	LPINDEXBLOCKHEAD lpBlockHead, lpPreBlockHead, lpNextBlockHead;
	//遍历冲突链表，找到要删除的索引项，和其前驱

	lpNodeData		= NULL;
	lpPreNodeData	= NULL;
	nIndexOffset	= lpHashNode->m_nIndexOffset;
	lpExecutePlan	= (LPEXECUTEPLANBSON)lpIndexInfo->m_pBson->GetBuffer();
	while(nIndexOffset != 0)
	{
		lpNodeData = ConvertOffsettoAddr(nIndexOffset);
		GetKeyValue(lpNodeData, varKey);
		nDataID = GetDataIDFromNodeData(lpNodeData);
		if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1 == varKey && nDataID == lpIndexInfo->m_nDataID)
		{
			//计算删除的索引项属于哪一个块
			nRet = ConvertIndexOffsettoBlockOffset(nIndexOffset, DEF_HASHBLOCK_SIZE, nBlockOffset);
			if(nRet != MF_OK)
			{	
				return nRet;
			}
			lpBlock = ConvertOffsettoAddr(nBlockOffset);	
			
			//将该索引项从冲突链表中删除
			if(!lpPreNodeData)
			{
				//如果前驱为空则直接将该索引项的后继挂在索引结点上
				lpHashNode->m_nIndexOffset  = *(long long*)lpNodeData;	
			}
			else
			{
				*(long long*)lpPreNodeData  = *(long long*)lpNodeData;
			}
			lpHashNode->m_nListLen--;

			//清空索引项，并用插头法将该索引项加入对应块的空索引链表
			ClearNodeData(lpNodeData);

			*(long long*)lpNodeData = ((LPINDEXBLOCKHEAD)lpBlock)->m_nFreeIndexOffset;
			((LPINDEXBLOCKHEAD)lpBlock)->m_nFreeIndexOffset = nIndexOffset;
			((LPINDEXBLOCKHEAD)lpBlock)->m_nDataNum--;
			
			//如果该块在删除数据之前属于满块链表，则需要将其移动至空块链表
			if(1 == ((LPINDEXBLOCKHEAD)lpBlock)->m_bBlockFull)					
			{
				((LPINDEXBLOCKHEAD)lpBlock)->m_bBlockFull = 0;

				//将该块从满块链表中删除
				lpBlockHead = (LPINDEXBLOCKHEAD)lpBlock;
				if(lpBlockHead->m_nPreBlockOffset == 0)
				{
					m_lpHashTableHead->m_nDataBlockOffset = lpBlockHead->m_nNextBlockOffset;	//如果前驱结点为空，则说明该块是满块链表的第一个块
				}
				else
				{
					lpPreBlockHead = (LPINDEXBLOCKHEAD)(ConvertOffsettoAddr(lpBlockHead->m_nPreBlockOffset));
					lpPreBlockHead->m_nNextBlockOffset = lpBlockHead->m_nNextBlockOffset;
					TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)lpPreBlockHead, llTimestamp);
				}
			
				if(lpBlockHead->m_nNextBlockOffset)
				{
					lpNextBlockHead = (LPINDEXBLOCKHEAD)(ConvertOffsettoAddr(lpBlockHead->m_nNextBlockOffset));
					lpNextBlockHead->m_nPreBlockOffset = lpBlockHead->m_nPreBlockOffset;	  //如果后继结为空，则不进行任何操作
					TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)lpNextBlockHead, llTimestamp);
				}
			
				//将该块插入空块链表(插头法)
				lpBlockHead->m_nPreBlockOffset = 0;									
				lpBlockHead->m_nNextBlockOffset = m_lpHashTableHead->m_nFreeBlockOffset;
				m_lpHashTableHead->m_nFreeBlockOffset = nBlockOffset;
				
				TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpHashTable, llTimestamp);
			}
			TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)lpBlock, llTimestamp);
			return MF_OK;
		}
		else
		{
			nIndexOffset  = *(long long*)lpNodeData;	//将指针移动到下一个索引结点
			lpPreNodeData = lpNodeData;
		}
	}

	//如果跳出循环说明没有找到对应的key删除失败
	return MF_FAILED;									
}

/************************************************************************
		功能说明：
			初始化哈希表管理类，让整个实例是可执行的
		参数说明：
			lpHashTable：哈希表的首地址指针，需要记录在m_lpHashTable变量中
			nIndexID：索引ID
			pHashFile：文件对象指针
		特别说明：
			同时还需要把m_lpHashHead成员变量也初始化出来，便于后续的写入和读取操作
************************************************************************/
void CMemoryHashIndex::SetHashTableAddr(LPBYTE lpHashTable, int nIndexID, CMemoryHashFile* pHashFile)
{
	m_pHashFile = pHashFile;
	m_nIndexID = nIndexID;

	m_lpHashTable = lpHashTable;
	m_lpHashTableHead = (LPHASHBLOCKHEAD)m_lpHashTable;

	if(m_lpHashTableHead->m_nReHashTableOffset != 0)
	{
		m_lpRehashTable		= ConvertOffsettoAddr(m_lpHashTableHead->m_nReHashTableOffset);
		m_lpRehashTableHead = (LPHASHBLOCKHEAD)m_lpRehashTable;
	}
	else
	{
		m_lpRehashTable = NULL;
		m_lpRehashTableHead = NULL;
	}
}

/************************************************************************
		功能说明：
			删除Object
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			llTimestamp：时间戳
		步骤：
			1.遍历CalcKeyHash表的满块链表和空块链表，调用FreeBlock依次释放
			2.释放哈希表块
			3.如果在进行reHash则对ReHashTable执行1、2步骤
************************************************************************/
void CMemoryHashIndex::DropObject(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, long long llTimestamp)
{
	LPINDEXBLOCKHEAD lpBlockHead;
	long long nBlockOffset, nCurrentBlockOffset;
	//1.遍历CalcKeyHash表的数据块链表，调用FreeBlock依次释放
	nBlockOffset = m_lpHashTableHead->m_nDataBlockOffset;
	while(nBlockOffset)
	{
		nCurrentBlockOffset = nBlockOffset;												//获得当前块的偏移
		lpBlockHead  = (LPINDEXBLOCKHEAD)ConvertOffsettoAddr(nCurrentBlockOffset);		//获得当前块头指针	
		nBlockOffset = lpBlockHead->m_nNextBlockOffset;									//将偏移量该为下一个块
		FreeBlock(lpExecutePlan, lpBlockHead->m_nBlockNo, llTimestamp);					//释放当前块
	}

	//2.遍历CalcKeyHash表的空块链表，调用FreeBlock依次释放
	nBlockOffset = m_lpHashTableHead->m_nFreeBlockOffset;
	while(nBlockOffset)
	{
		nCurrentBlockOffset = nBlockOffset;												//获得当前块的偏移
		lpBlockHead  = (LPINDEXBLOCKHEAD)ConvertOffsettoAddr(nCurrentBlockOffset);		//获得当前块头指针	
		nBlockOffset = lpBlockHead->m_nNextBlockOffset;									//将偏移量该为下一个块
		FreeBlock(lpExecutePlan, lpBlockHead->m_nBlockNo, llTimestamp);					//释放当前块
	}
	
	//3.释放哈希表块
	FreeBlock(lpExecutePlan, m_lpHashTableHead->m_nBlockNo, llTimestamp);		
	
	//4.如果在进行reHash则对ReHashTable执行1、2步骤
	if(m_lpRehashTable != NULL)
	{
		nBlockOffset = m_lpRehashTableHead->m_nDataBlockOffset;
		while(nBlockOffset)
		{
			//遍历ReHash表的满块链表，调用FreeBlock依次释放
			nCurrentBlockOffset = nBlockOffset;											//获得当前块的偏移
			lpBlockHead = (LPINDEXBLOCKHEAD)ConvertOffsettoAddr(nCurrentBlockOffset);	//获得当前块头指针	
			nBlockOffset = lpBlockHead->m_nNextBlockOffset;								//将偏移量该为下一个块
			FreeBlock(lpExecutePlan, lpBlockHead->m_nBlockNo, llTimestamp);				//释放当前块
		}

		//遍历ReHash表的空块链表，调用FreeBlock依次释放
		nBlockOffset = m_lpRehashTableHead->m_nFreeBlockOffset;
		while(nBlockOffset)
		{
			nCurrentBlockOffset = nBlockOffset;											//获得当前块的偏移
			lpBlockHead = (LPINDEXBLOCKHEAD)ConvertOffsettoAddr(nCurrentBlockOffset);	//获得当前块头指针	
			nBlockOffset = lpBlockHead->m_nNextBlockOffset;								//将偏移量该为下一个块
			FreeBlock(lpExecutePlan, lpBlockHead->m_nBlockNo, llTimestamp);				//释放当前块
		}
		//释放ReHash表
		FreeBlock(lpExecutePlan, m_lpRehashTableHead->m_nBlockNo, llTimestamp);					
	}
}

/************************************************************************
		功能说明：
			根据nKey值在内存中插入一条索引项
		参数说明：
			lpIndexInfo：索引信息
			lpExecutePlan：执行计划
			llTimestamp：时间戳
************************************************************************/
int CMemoryHashIndex::InsertIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long llTimestamp)
{
	LPBYTE lpNodeData;
	LPHASHNODE lpHashNode;
	long long nIndexOffset;
	int nRet, nHashNodePos;

	nIndexOffset  = 0;
	
	//判断关键字是否重复
	nHashNodePos = CalcKeyHash(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2,m_lpHashTableHead->m_nHashTableLen);
	lpHashNode   = GetHashNode(m_lpHashTable, nHashNodePos);
	if(CheckKey(lpIndexInfo->m_pBson, lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2, lpIndexInfo->m_bFieldNo[0], lpHashNode))
	{
		return MF_KVINDEX_MULTIKEY_ERROR;		
	}
	
	if(m_lpRehashTable != NULL)
	{
		nHashNodePos = CalcKeyHash(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2, m_lpRehashTableHead->m_nHashTableLen);
		lpHashNode	 = GetHashNode(m_lpRehashTable, nHashNodePos);
		if(CheckKey(lpIndexInfo->m_pBson, lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2, lpIndexInfo->m_bFieldNo[0], lpHashNode))
		{
			return MF_KVINDEX_MULTIKEY_ERROR;		
		}
	}

	//判断是否发生了reHash
	if(m_lpRehashTable != NULL)
	{
		nRet = InsertData(lpIndexInfo, lpExecutePlan, llTimestamp);		
		if(nRet != MF_OK)
		{
			return nRet;
		}
		
		//将该索引项加入reHash表
		nIndexOffset = lpIndexInfo->m_nParam4;
		lpNodeData   = ConvertOffsettoAddr(nIndexOffset);
		*(long long*)lpNodeData    = lpHashNode->m_nIndexOffset;
		lpHashNode->m_nIndexOffset = nIndexOffset;
		lpHashNode->m_nListLen++;											//递增冲突链表长度

		nRet = Rehash(lpExecutePlan, m_lpHashTableHead->m_nRehashNodePos, llTimestamp);	//进行reHash
		if(nRet != MF_OK)
		{
			return nRet;
		}

		//更新reHash表的时间戳
		if(m_lpRehashTable != NULL)
		{
			TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpRehashTable, llTimestamp);
		}
	}
	else
	{
		//将数据写入内存
		nRet = InsertData(lpIndexInfo, lpExecutePlan, llTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		//将该索引项加入Hash表
		nIndexOffset = lpIndexInfo->m_nParam4;
		lpNodeData	 = ConvertOffsettoAddr(nIndexOffset);
		*(long long*)lpNodeData    = lpHashNode->m_nIndexOffset;
		lpHashNode->m_nIndexOffset = nIndexOffset;
		lpHashNode->m_nListLen++;				 

		//如果冲突链表长度>5，执行reHash
		if(lpHashNode->m_nListLen >= 5 && m_lpRehashTable == NULL)
		{
			nRet = BeginRehash(lpExecutePlan, llTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}

	//更新Hash表的时间戳
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpHashTable, llTimestamp);
	return MF_OK;
}

/************************************************************************
		功能说明：
			根据nKey值在索引块中删除一个索引项
		参数说明：
			lpIndexInfo：索引信息
			lpExecutePlan：执行计划
			llTimestamp：时间戳
************************************************************************/
int CMemoryHashIndex::DeleteIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long llTimestamp)
{
	LPHASHNODE lpHashNode;
	int nRet, nHashNodePos;
	lpExecutePlan = (LPEXECUTEPLANBSON)lpIndexInfo->m_pBson->GetBuffer();
	//利用哈希算法计算关键字在哈希表中的位置，并通过该位置获得哈希结点的指针
	nHashNodePos = CalcKeyHash(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1, m_lpHashTableHead->m_nHashTableLen);
	lpHashNode = GetHashNode(m_lpHashTable, nHashNodePos);
	if(!m_lpRehashTable)
	{
		//判断是否进行reHash,如果没有进行reHash，那么直接返回删除结果
		nRet = DeleteData(lpIndexInfo, lpHashNode, lpExecutePlan->m_nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//如果索引正在进行reHash操作，并且如果删除失败，则查找该关键字是否在reHashTable中
		nRet = DeleteData(lpIndexInfo, lpHashNode, lpExecutePlan->m_nTimestamp);
		if(nRet == MF_FAILED)
		{
			//利用哈希算法计算关键字在ReHash表中的位置，并通过该位置获得哈希结点的指针
			nHashNodePos = CalcKeyHash(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1,m_lpRehashTableHead->m_nHashTableLen);
			lpHashNode = (LPHASHNODE)(m_lpRehashTable + m_lpRehashTableHead->m_nBlockHeadSize + nHashNodePos * m_lpRehashTableHead->m_nHashNodeSize);
			nRet = DeleteData(lpIndexInfo, lpHashNode, lpExecutePlan->m_nTimestamp);
			if(nRet != MF_OK && nRet != MF_FAILED)
			{
				return nRet;
			}
			nRet = Rehash(lpExecutePlan, m_lpHashTableHead->m_nRehashNodePos, llTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else if(nRet == MF_OK)
		{
			nRet = Rehash(lpExecutePlan, m_lpHashTableHead->m_nRehashNodePos, llTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else
		{
			return nRet;
		}
	}

	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpHashTable, llTimestamp);
	return MF_OK;
}

/************************************************************************
		功能说明：
			根据关键字，获取数据ID
		参数说明：
			lpIndexInfo：索引信息
			pDataIDContainer：DataID容器
************************************************************************/
int CMemoryHashIndex::GetDataID(LPINDEXINFO lpIndexInfo, CDataIDContainer* pDataIDContainer)
{
	VARDATA varKey;
	LPBYTE lpNodeData;
	CServiceBson* pBson;
	int nHashNodeNo, nRet;
	LPHASHNODE lpHashNode;
	long long nIndexOffset, nDataID;

	pBson = lpIndexInfo->m_pBson;
	nDataID					= 0;
	lpIndexInfo->m_nDataID  = 0;
	//利用哈希算法计算关键字在哈希表中的位置，并通过该位置获得哈希结点的指针
	nHashNodeNo = CalcKeyHash(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1, m_lpHashTableHead->m_nHashTableLen);
	lpHashNode  = GetHashNode(m_lpHashTable, nHashNodeNo);

	//遍历冲突链表，返回关键字对应的DataID
	nIndexOffset = lpHashNode->m_nIndexOffset;
	while(nIndexOffset)
	{
		lpNodeData = ConvertOffsettoAddr(nIndexOffset);
		GetKeyValue(lpNodeData, varKey);
		if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1 == varKey)
		{
			nDataID = GetDataIDFromNodeData(lpNodeData);
			if(lpIndexInfo->m_bIndexType == MF_SYS_INDEXTYPE_HB_INT || lpIndexInfo->m_bIndexType == MF_SYS_INDEXTYPE_HB_CHAR)
			{
				//对于HB树索引不作判断
				nRet = pDataIDContainer->push_back(nDataID);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
			else if(!lpIndexInfo->m_pCheck || lpIndexInfo->m_pCheck->CheckRecordValid(nDataID))
			{
				nRet = pDataIDContainer->push_back(nDataID);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
			break;
		}
		nIndexOffset = *(long long*)lpNodeData;
	}

	if(m_lpRehashTable != NULL)
	{
		nHashNodeNo = CalcKeyHash(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1,m_lpRehashTableHead->m_nHashTableLen);
		lpHashNode = GetHashNode(m_lpRehashTable, nHashNodeNo);
		nIndexOffset = lpHashNode->m_nIndexOffset;
		while(nIndexOffset)
		{
			lpNodeData = ConvertOffsettoAddr(nIndexOffset);
			GetKeyValue(lpNodeData, varKey);
			if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1 == varKey)
			{
				nDataID = GetDataIDFromNodeData(lpNodeData);
				if(!lpIndexInfo->m_pCheck|| lpIndexInfo->m_pCheck->CheckRecordValid(nDataID))
				{
					pDataIDContainer->push_back(nDataID);
				}
				break;
			}
			nIndexOffset = *(long long*)lpNodeData;
		}
	}
	return MF_OK;
}