﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "SysMemObject.h"
#include "RecordSetBson.h"
#include "Expression.h"
#include "ExecutePlanManager.h"
CSysMemObject::CSysMemObject(void)
{
	
}

CSysMemObject::~CSysMemObject(void)
{
}

int CSysMemObject::Release()
{
	delete this;
	return MF_OK;
}

int CSysMemObject::GetRecordNum(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int& nRecordNum, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	nRecordNum = 0;
	return MF_OK;
}

int CSysMemObject::Preprocess(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	lpExecutePlan->m_nTotalDataSize = stBson.GetExecutePlanDataSize();
	lpExecutePlan->m_nBsonDataSize  = stBson.GetBsonDataSize();
	return MF_OK;
}

void CSysMemObject::CriticalRelease(CServiceBson& stBson)
{
	int i;
	LPEXECUTEPLANBSON lpExecutePlan;
	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();

	for(i = 0; i < 20; i++)
	{
		if(lpExecutePlan->m_pCritStack[i] != 0)
		{
			::LeaveCriticalSection((LPCRITICAL_SECTION)lpExecutePlan->m_pCritStack[i]);
		}
	}
}

int CSysMemObject::ResourceRelease(CServiceBson& stBson, int nRetValue, CExecutePlanManager& stExecutePlanManager)
{
	LPEXECUTEPLANBSON lpExecutePlan;
	CSystemTimestampTransactionManage stTransaction;
	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();

	CriticalRelease(stBson);
	stTransaction.CommitTransaction(lpExecutePlan->m_nTimestamp);
	return MF_OK;
}

int CSysMemObject::ExecuteCommand(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_ALTER)
	{
		nRet = SysAlter(stBson, lpExecutePlan, lAffectCount, lpExecuteInfo);
	}
	else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_CREATE)
	{
		nRet = SysCreate(stBson, lpExecutePlan, lAffectCount, lpExecuteInfo);
	}
	else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_DROP)
	{
		nRet = SysDrop(stBson, lpExecutePlan, lAffectCount, lpExecuteInfo);
	}
	else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_INSERT)
	{
		return MF_COMMON_INVALID_CMDTYPE;
	}
	else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_UPDATE)
	{
		return MF_COMMON_INVALID_CMDTYPE;
	}
	else if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_DELETE)
	{
		return MF_COMMON_INVALID_CMDTYPE;
	}
	else
	{
		return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
	}
	return nRet;
}

int CSysMemObject::GetRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPOBJECTDEF lpObjectInfo;
	LPEXECUTEPLANBSON lpExecutePlan;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	CRecordSetBson stRecordsetBson(&stBson);
	CSysRecordContainer stRecordContainer(&stBson);

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(lpExecutePlan->m_nType != MF_EXECUTEPLAN_CMDTYPE_QUERY)
	{
		return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
	}
	lpQueryPlan = (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);

	//根据ObjectID获取表的相关信息
	lpObjectInfo= stBson.GetObjectInfo();

	//获取系统表的所有值
	switch(lpObjectInfo->m_nObjectID)
	{
	case MF_SYS_OBJECTTYPE_DUAL:
		nRet = CSystemManage::instance().GetDualData(stBson, stRecordContainer);
		break;
	case MF_SYS_OBJECTTYPE_OBJECT:
		nRet = CSystemManage::instance().GetVObjectData(stBson, stRecordContainer);
		break;
	case MF_SYS_OBJECTTYPE_FIELD:
		nRet = CSystemManage::instance().GetVColumnData(stBson, stRecordContainer);
		break;
	case MF_SYS_OBJECTTYPE_INDEX:
		nRet = CSystemManage::instance().GetVIndexData(stBson, stRecordContainer);
		break;
	case MF_SYS_OBJECTTYPE_SEQUENCE:
		nRet = CSystemManage::instance().GetVSequenceData(stBson, stRecordContainer);
		break;
	case MF_SYS_OBJECTTYPE_FILE:
		nRet = CSystemManage::instance().GetVDataFileData(stBson, stRecordContainer);
		break;	
	case MF_SYS_OBJECTTYPE_STATISTICS:
		nRet = CSystemManage::instance().GetVStatisticsData(stBson, stRecordContainer);
		break;
	case MF_SYS_OBJECTTYPE_SESSION:
		nRet = CSystemManage::instance().GetVSessionData(stBson, stRecordContainer);
		break;
	case MF_SYS_OBJECTTYPE_SOAPSERVER:
		nRet = CSystemManage::instance().GetVSoapServerData(stBson, stRecordContainer);
		break;
	case MF_SYS_OBJECTTYPE_USERINFO:
		nRet = CSystemManage::instance().GetVUserData(stBson, stRecordContainer);
		break;
	case MF_SYS_OBJECTTYPE_AUTHORITY:
		nRet = CSystemManage::instance().GetVAuthority(stBson, stRecordContainer);
		break;
	case MF_SYS_OBJECTTYPE_WORKLOAD:
		nRet = CSystemManage::instance().GetVWorkLoad(stBson, stRecordContainer);
		break;
	default:
		nRet = MF_COMMON_INVALID_DATATYPE;
	}
	if(nRet != MF_OK)
	{
		return nRet;
	}
	QueryPerformanceCounter(&lpExecuteInfo->m_liIndexSearchEnd);
	nRet = stRecordsetBson.Initial(MF_OBJECT_COMMON);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//将结果集转换为BSON
	nRet = stRecordsetBson.BuildBson(lpQueryPlan, lpObjectInfo, &stRecordContainer, lpBsonRs, nBsonRsSize);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	lpExecutePlan->m_nTotalDataSize  = stBson.GetExecutePlanDataSize();
	lpExecutePlan->m_nBsonDataSize   = stBson.GetBsonDataSize();
	return MF_OK;
}

int CSysMemObject::UpdateRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	QueryPerformanceCounter(&lpExecuteInfo->m_liIndexSearchEnd);
	return MF_FAILED;
}

int CSysMemObject::SysAlter(CServiceBson& stBson, LPEXECUTEPLANBSON lpExecutePlan, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	if(lpExecutePlan->m_nType != MF_EXECUTEPLAN_CMDTYPE_ALTER)
	{
		return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
	}
	if(lpExecutePlan->m_nCommandOffset == 0)
	{
		return MF_INNER_POINTER_NULL;
	}

	QueryPerformanceCounter(&lpExecuteInfo->m_liIndexSearchEnd);
	LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson = (LPALTEREXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_ADD_FIELD)
	{
		LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson;
		if(lpAlterExecutePlanBson->m_nPlanOffset == 0)
		{
			return MF_INNER_POINTER_NULL;
		}
		lpAlterObjectFieldBson = (LPALTEROBJECTFIELDBSON)(stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset));
		
		if(lpAlterObjectFieldBson->m_nFieldNum <= 0 || lpAlterObjectFieldBson->m_nFieldOffset == 0)
		{
			return MF_INNER_POINTER_NULL;
		}
		nRet = CSystemManage::instance().AlterObjectAddField(stBson, lpExecutePlan->m_nTimestamp, lpAlterObjectFieldBson);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_DROP_FIELD)
	{
		LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson;
		if(lpAlterExecutePlanBson->m_nPlanOffset == 0)
		{
			return MF_INNER_POINTER_NULL;
		}
		lpAlterObjectFieldBson = (LPALTEROBJECTFIELDBSON)stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
		
		if(lpAlterObjectFieldBson->m_nFieldNum <= 0 || lpAlterObjectFieldBson->m_nFieldOffset == 0)
		{
			return MF_INNER_POINTER_NULL;
		}
		nRet = CSystemManage::instance().AlterObjectDropField(stBson, lpExecutePlan->m_nTimestamp, lpAlterObjectFieldBson);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_ADD_INDEX)
	{
		LPFILE_INDEXDEFBSON lpIndexBson;
		if(lpAlterExecutePlanBson->m_nPlanOffset == 0)
		{
			return MF_INNER_POINTER_NULL;
		}
		lpIndexBson = (LPFILE_INDEXDEFBSON)(stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset));

		nRet = CSystemManage::instance().AlterObjectAddIndex(stBson, lpExecutePlan->m_nTimestamp, lpIndexBson);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_DROP_INDEX)
	{
		LPFILE_INDEXDEFBSON lpIndexBson;
		lpIndexBson = (LPFILE_INDEXDEFBSON)(stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset));
		if(lpIndexBson == NULL)
		{
			return MF_INNER_POINTER_NULL;
		}

		nRet = CSystemManage::instance().AlterObjectDropIndex(lpExecutePlan, lpIndexBson->m_nObjectID, lpIndexBson);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_ADD_DBFILE)
	{
		LPFILE_MEMDBFILEINFOBSON lpMemDBFileBson = NULL;
		if(lpAlterExecutePlanBson->m_nPlanOffset == 0)
		{
			return MF_INNER_POINTER_NULL;
		}
		lpMemDBFileBson = (LPFILE_MEMDBFILEINFOBSON)(stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset));
		if(lpMemDBFileBson->m_nFileSize == 0)
		{
			return MF_SYS_DBFILE_NO_FILESIZE_ERROR;
		}
		if(strlen(lpMemDBFileBson->m_pAlterFilePath) == 0)
		{
			return MF_SYS_DBFILE_NO_FILEPATH_ERROR;
		}
		if(strlen(lpMemDBFileBson->m_lpszMemFileName) == 0)
		{
			return MF_SYS_DBFILE_NO_MEMFILE_ERROR;
		}
		if(lpMemDBFileBson->m_bFileType != MF_SYS_FILETYPE_DATAFILE && lpMemDBFileBson->m_bFileType != MF_SYS_FILETYPE_TREEINDEXFILE && lpMemDBFileBson->m_bFileType != MF_SYS_FILETYPE_KVINDEXFILE)
		{
			return MF_SYS_DBFILE_NO_FILETYPE_ERROR;
		}
		nRet = CSystemManage::instance().AddMemDBFile(lpExecutePlan->m_nTimestamp, lpMemDBFileBson->m_pAlterFilePath, lpMemDBFileBson->m_lpszMemFileName, lpMemDBFileBson->m_bFileType, lpMemDBFileBson->m_nFileSize);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_DROP_DBFILE)
	{
		if(lpAlterExecutePlanBson->m_pFilePath[0] == 0)
		{
			return MF_SYS_DBFILE_NOTEXIST;
		}
		nRet = CSystemManage::instance().DropMemDBFile(lpExecutePlan->m_nTimestamp, lpAlterExecutePlanBson->m_pFilePath);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_MODIFY_DBFILE)
	{
		LPFILE_MEMDBFILEINFOBSON lpMemDBFileBson;
		if(lpAlterExecutePlanBson->m_nPlanOffset == 0)
		{
			return MF_INNER_POINTER_NULL;
		}
		lpMemDBFileBson = (LPFILE_MEMDBFILEINFOBSON)(stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset));
		nRet = CSystemManage::instance().ModifyMemDBFile(stBson, lpExecutePlan->m_nTimestamp, lpMemDBFileBson);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_SET_PARAMETER)
	{
		LPALTERSETEXPFIELDBSON lpBsonField;
		lpBsonField = (LPALTERSETEXPFIELDBSON)stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
		//修改参数，将神仙代码封装一个setparemater来调用 在systemmanger下写
		nRet = CSystemManage::instance().SetParameterValue(lpBsonField->m_bParameterType, *(int*)(lpBsonField->m_bDataBuffer));
		if(nRet != MF_OK)
		{
			return nRet;
		}

	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_ADD_AUTHORITY)
	{
		LPUSERINFOBSON lpUserInfoBson;
		lpUserInfoBson = (LPUSERINFOBSON)stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
		if(lpUserInfoBson == NULL)
		{
			return MF_INNER_POINTER_NULL;
		}
		nRet = CSystemManage::instance().AlterUserAddAuthority(lpUserInfoBson, lpExecutePlan->m_nTimestamp);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_DROP_AUTHORITY)
	{
		LPUSERINFOBSON lpUserInfoBson;
		lpUserInfoBson = (LPUSERINFOBSON)stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
		if(lpUserInfoBson == NULL)
		{
			return MF_INNER_POINTER_NULL;
		}
		nRet = CSystemManage::instance().AlterUserDropAuthority(lpUserInfoBson, lpExecutePlan->m_nTimestamp);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_CHANGE_PASSWORD)
	{
		LPUSERINFOBSON lpUserInfoBson;
		lpUserInfoBson = (LPUSERINFOBSON)stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
		if(lpUserInfoBson == NULL)
		{
			return MF_INNER_POINTER_NULL;
		}
		nRet = CSystemManage::instance().AlterUserChangePassword(lpUserInfoBson, lpExecutePlan->m_nTimestamp);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_DISABLE_USER)
	{
		LPUSERINFOBSON lpUserInfoBson;
		lpUserInfoBson = (LPUSERINFOBSON)stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
		if(lpUserInfoBson == NULL)
		{
			return MF_INNER_POINTER_NULL;
		}
		nRet = CSystemManage::instance().AlterUserDisable(lpUserInfoBson, lpExecutePlan->m_nTimestamp);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpAlterExecutePlanBson->m_nType == MF_EXECUTEPLAN_ALTERTYPE_ENABLE_USER)
	{
		LPUSERINFOBSON lpUserInfoBson;
		lpUserInfoBson = (LPUSERINFOBSON)stBson.ConvertOffset2Addr(lpAlterExecutePlanBson->m_nPlanOffset);
		if(lpUserInfoBson == NULL)
		{
			return MF_INNER_POINTER_NULL;
		}
		nRet = CSystemManage::instance().AlterUserEnable(lpUserInfoBson, lpExecutePlan->m_nTimestamp);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	return MF_OK;
}

int CSysMemObject::SysCreate(CServiceBson& stBson, LPEXECUTEPLANBSON lpExecutePlan, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPCREATEEXECUTEPLANBSON lpCreateExecutePlanBson;
	if(lpExecutePlan->m_nType != MF_EXECUTEPLAN_CMDTYPE_CREATE)
	{
		return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
	}
	if(lpExecutePlan->m_nCommandOffset == 0)
	{
		return MF_INNER_POINTER_NULL;
	}

	QueryPerformanceCounter(&lpExecuteInfo->m_liIndexSearchEnd);
	lpCreateExecutePlanBson = (LPCREATEEXECUTEPLANBSON)(stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset));
	if(lpCreateExecutePlanBson->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_SEQUECNE)
	{
		LPFILE_SEQUENCEDEFBSON lpSequence;
		lpSequence = (LPFILE_SEQUENCEDEFBSON)stBson.ConvertOffset2Addr(lpCreateExecutePlanBson->m_nPlanOffset);
		if(lpSequence == NULL)
		{
			return MF_INNER_POINTER_NULL;
		}
		nRet = CSystemManage::instance().AddSequence(lpExecutePlan->m_nTimestamp, lpSequence->m_lpszName, lpSequence->m_nCurrentVal, lpSequence->m_nIncrementBy, lpSequence->m_nMinVal, lpSequence->m_nMaxVal, lpSequence->m_bCycleFlag, lpSequence->m_bCacheFlag);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpCreateExecutePlanBson->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_OBJECT)
	{
		LPOBJECTDEFBSON lpObject;
		char *pDataFilePath, *pTreeFilePath, *pKVFilePath;
		lpObject = (LPOBJECTDEFBSON)stBson.ConvertOffset2Addr(lpCreateExecutePlanBson->m_nPlanOffset);
		if(lpObject == NULL)
		{
			return MF_INNER_POINTER_NULL;
		}
		pDataFilePath = (char*)stBson.ConvertOffset2Addr(lpCreateExecutePlanBson->m_nDataFilePathOffset);
		pTreeFilePath = (char*)stBson.ConvertOffset2Addr(lpCreateExecutePlanBson->m_nTreeFilePathOffset);
		pKVFilePath   = (char*)stBson.ConvertOffset2Addr(lpCreateExecutePlanBson->m_nKVFilePathOffset);
		nRet = CSystemManage::instance().AddObject(stBson, lpExecutePlan, lpExecutePlan->m_nTimestamp, lpObject, pDataFilePath, pTreeFilePath, pKVFilePath);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	else if(lpCreateExecutePlanBson->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_USER)
	{
		LPUSERINFOBSON lpUserInfo;
		lpUserInfo = (LPUSERINFOBSON)stBson.ConvertOffset2Addr(lpCreateExecutePlanBson->m_nPlanOffset);
		if(lpUserInfo == NULL)
		{
			return MF_INNER_POINTER_NULL;
		}
		nRet = CSystemManage::instance().AddUser(lpUserInfo, lpExecutePlan->m_nTimestamp);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		else
		{
			return nRet;
		}
	}
	return MF_OK;
}

int CSysMemObject::SysDrop(CServiceBson& stBson, LPEXECUTEPLANBSON lpExecutePlan, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	//语法原型为DROP 类型 对象名，比如：
	//删除对象为DROP OBJECT OBJECTNAME
	//删除序列为DROP SEQUENCE SEQNAME
	int nRet;
	if(lpExecutePlan->m_nType != MF_EXECUTEPLAN_CMDTYPE_DROP)
	{
		return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
	}
	if(lpExecutePlan->m_nCommandOffset == 0)
	{
		return MF_INNER_POINTER_NULL;
	}

	QueryPerformanceCounter(&lpExecuteInfo->m_liIndexSearchEnd);
	LPDROPEXECUTEPLANBSON lpDropExecutePlanBson = (LPDROPEXECUTEPLANBSON)(stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset));
	if(lpDropExecutePlanBson->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_SEQUECNE)
	{
		nRet = CSystemManage::instance().DropSequence(lpExecutePlan->m_nTimestamp, lpDropExecutePlanBson->m_pDataName);
		if(MF_SYS_SEQUENCE_NOTEXIST == nRet)
		{
			nRet = MF_OK;
			lAffectCount = 0;
		}
		else if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		return nRet;
	}
	else if(lpDropExecutePlanBson->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_OBJECT)
	{
		nRet = CSystemManage::instance().DropObject(lpExecutePlan, lpDropExecutePlanBson->m_pDataName);
		if(MF_SYS_OBJECT_NOTEXIST == nRet)
		{
			nRet = MF_OK;
			lAffectCount = 0;
		}
		else if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		return nRet;
	}
	else if(lpDropExecutePlanBson->m_nType == MF_EXECUTEPLAN_OBJECTTYPE_USER)
	{
		nRet = CSystemManage::instance().DropUser(lpDropExecutePlanBson->m_pDataName, lpExecutePlan->m_nTimestamp);
		if(MF_OK == nRet)
		{
			lAffectCount = 1;
		}
		return nRet;
	}
	return MF_OK;
}

int CSysMemObject::ExportObject(CServiceBson& stBson, char* pObjectName, LPEXPORTPARAM lpExportParam, long long nTimestamp)
{
	lpExportParam->m_bComplete = TRUE;
	return MF_OK;
}
int CSysMemObject::ImportObject(CServiceBson& stBson, char* pObjectName, LPIMPORTPARAM lpImportParam, long long nTimestamp)
{
	return MF_OK;
}

USHORT CSysMemObject::GetDatabaseGuid()
{
	return CSystemManage::instance().GetDatabaseGuid();
}

int CSysMemObject::Recover(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	return ExecuteCommand(stBson, stExecutePlanManager, lAffectCount, lpExecuteInfo);
}
