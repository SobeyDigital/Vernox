﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "Expression.h"
#include "FunctionManager.h"
#include "MemoryFile.h"
CExpression::CExpression()
{
	m_pBson			= NULL;
	m_lpObjectInfo	= NULL;
	m_pFile			= NULL;
}
CExpression::~CExpression()
{

}

int CExpression::GetDataValue(CBaseBson& stBson, LPMATHEXPELEMENTBSON lpFieldBson, VARDATA& stVarData)
{
	switch(lpFieldBson->m_bDataType)
	{
	case MF_VARDATA_NULL:
		stVarData.m_vt = MF_VARDATA_NULL;
		break;
	case MF_VARDATA_INT:
		stVarData.SetData(*(int*)(lpFieldBson->m_bDataBuffer));
		break;
	case MF_VARDATA_INT64:
		stVarData.SetData(*(long long*)(lpFieldBson->m_bDataBuffer));
		break;
	case MF_VARDATA_DOUBLE:
		stVarData.SetData(*(double*)(lpFieldBson->m_bDataBuffer), MF_VARDATA_DOUBLE);
		break;
	case MF_VARDATA_DATE:
		stVarData.SetData(*(double*)(lpFieldBson->m_bDataBuffer), MF_VARDATA_DATE);
		break;
	case MF_VARDATA_STRING:
		stVarData.SetData(lpFieldBson->m_bDataBuffer, lpFieldBson->m_nDataLen);
		break;
	case MF_VARDATA_BINARY:
		stVarData.SetBinaryData((LPBYTE)lpFieldBson->m_bDataBuffer, lpFieldBson->m_nDataLen);
		break;
	case MF_VARDATA_UNKNOWN:
		stVarData.SetData(lpFieldBson->m_bFieldNo);
		break;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		计算表达式字段值
	参数说明：
		lpFieldBson：字段
		varResult：结果 
		pDataArray：记录
************************************************************************/
int CExpression::GetFieldValue(LPMATHEXPELEMENTBSON lpFieldBson, VARDATA& varResult, LPSINGLERECORD lpDataArray)
{
	int nRet = MF_OK;
	if(lpFieldBson->m_bField)
	{
		if(lpDataArray == NULL)
		{
			if(lpFieldBson->m_bFieldNo == 0)
			{
				//COUNT(*)
				varResult.m_bValue = 0;
			}
			else
			{
				return MF_COMMON_INVALID_FIELD;
			}
		}
		else
		{
			varResult.SetData(lpDataArray->m_lpRecordData[lpFieldBson->m_bFieldNo - 1]);
		}
	}
	else
	{
		nRet = GetDataValue(*m_pBson, lpFieldBson, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		初始化
	参数说明：
		pBson：Bson对象
		lpObjectInfo：对象信息
************************************************************************/
void CExpression::Initial(CServiceBson* pBson, LPOBJECTDEF lpObjectInfo)
{
	int nRet;
	IVirtualMemoryFile* pVirtualFile;

	m_pBson			= pBson;
	m_lpObjectInfo	= lpObjectInfo;

	if(lpObjectInfo != NULL && lpObjectInfo->m_bFileNo != 1)
	{
		nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
		if(nRet != MF_OK)
		{
			m_pFile = NULL;
		}
		else
		{
			m_pFile = (CMemoryFile*)pVirtualFile;
		}
	}
	else
	{
		m_pFile = NULL;
	}
}

/************************************************************************
		功能说明：
			从记录中获取字符串型字段值
		参数说明：
			nDataID：数据ID，用于支持DataID
			lpRecordBuffer：记录Buffer
			nBufferLen：记录Buffer长度
			bFieldNo：字段编号
			varResult：字段值
************************************************************************/
int CExpression::GetFieldValueFromRecordBuffer(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen, BYTE bFieldNo, VARDATA& varResult)
{
	LPBYTE lpDataPtr;
	int nDataLen, nRet, nFieldDataOffset, nSectionEndOffset;
	BYTE bFieldType, bArrayLen, bTempFieldNo, bRecordSectionNo, bArrayType, bLen;

	if(bFieldNo == 255)
	{
		//返回DataID
		varResult.SetData(nDataID);
		return MF_OK;
	}
	//1.获取数据段映射表的长度
	bArrayLen   = *(BYTE*)lpRecordBuffer;

	//2.获取数据段映射表类型
	bArrayType  = *(BYTE*)(lpRecordBuffer + 1);
	
	//3.根据字段编号，获取当前字段应该属于哪一段数据
	bRecordSectionNo = (bFieldNo - 1) / MF_RECORDSECTION_FIELDNUM;
	if(bRecordSectionNo >= bArrayLen)
	{
		return MF_OK;
	}

	//4.获取数据片段的起始位置
	if(bArrayType == MF_RECORDSECTIONARRAY_BYTE)
	{
		BYTE* pFieldArray;
		pFieldArray = (BYTE*)(lpRecordBuffer + 2*sizeof(BYTE));

		nFieldDataOffset = pFieldArray[bRecordSectionNo];
		if(bRecordSectionNo + 1 >= bArrayLen)
		{
			nSectionEndOffset = nBufferLen;
		}	
		else
		{
			nSectionEndOffset = pFieldArray[bRecordSectionNo + 1];
		}
	}
	else if(bArrayType == MF_RECORDSECTIONARRAY_SHORT)
	{
		USHORT* pFieldArray;
		pFieldArray = (USHORT*)(lpRecordBuffer + 2*sizeof(BYTE));

		nFieldDataOffset = pFieldArray[bRecordSectionNo];
		if(bRecordSectionNo + 1 >= bArrayLen)
		{
			nSectionEndOffset = nBufferLen;
		}	
		else
		{
			nSectionEndOffset = pFieldArray[bRecordSectionNo + 1];
		}
	}
	else if(bArrayType == MF_RECORDSECTIONARRAY_INT)
	{
		int* pFieldArray;
		pFieldArray = (int*)(lpRecordBuffer + 2*sizeof(BYTE));

		nFieldDataOffset = pFieldArray[bRecordSectionNo];
		if(bRecordSectionNo + 1 >= bArrayLen)
		{
			nSectionEndOffset = nBufferLen;
		}	
		else
		{
			nSectionEndOffset = pFieldArray[bRecordSectionNo + 1];
		}
	}
	else
	{
		return MF_FAILED;
	}

	if(nFieldDataOffset == nSectionEndOffset)
	{
		//空字段
		varResult.m_vt = MF_SYS_FIELDTYPE_NULL;
		return MF_OK;
	}

	lpDataPtr = lpRecordBuffer + nFieldDataOffset;
	while(nFieldDataOffset < nSectionEndOffset)
	{
		bTempFieldNo	 = *(BYTE*)lpDataPtr;
		if(bTempFieldNo  == 0)
		{
			return MF_COMMON_INVALID_FIELDNO;
		}

		lpDataPtr		 += sizeof(BYTE);
		nFieldDataOffset += sizeof(BYTE);
		bFieldType		 = m_lpObjectInfo->m_lpField[bTempFieldNo - 1].m_bFieldType;
		
		if(bTempFieldNo > bFieldNo)
		{
			//空字段
			varResult.m_vt = MF_SYS_FIELDTYPE_NULL;
			return MF_OK;
		}
		else if(bTempFieldNo == bFieldNo)
		{
			switch(bFieldType)
			{
			case MF_SYS_FIELDTYPE_INT:
				varResult.SetData(*(int*)lpDataPtr);
				break;
			case MF_SYS_FIELDTYPE_BIGINT:
				varResult.SetData(*(long long*)lpDataPtr);
				break;
			case MF_SYS_FIELDTYPE_DOUBLE:
				varResult.SetData(*(double*)lpDataPtr, MF_SYS_FIELDTYPE_DOUBLE);
				break;
			case MF_SYS_FIELDTYPE_DATE:
				varResult.SetData(*(DATE*)lpDataPtr, MF_SYS_FIELDTYPE_DATE);
				break;
			case MF_SYS_FIELDTYPE_CHAR:
			case MF_SYS_FIELDTYPE_VARCHAR:
			case MF_SYS_FIELDTYPE_CLOB:
				//获取字段长度
				LPBYTE lpszValue;
				bLen		= *(BYTE*)lpDataPtr;
				if(bLen != 255)
				{
					nDataLen  = bLen;
					lpDataPtr += sizeof(BYTE);
				}
				else
				{
					lpDataPtr += sizeof(BYTE);
					nDataLen  = *(int*)lpDataPtr;
					lpDataPtr += sizeof(int);
				}
				nRet = m_pBson->AllocFromCircleBuffer(nDataLen, lpszValue);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				memcpy(lpszValue, lpDataPtr, nDataLen);
				varResult.SetData((char*)lpszValue, nDataLen);
				break;
			case MF_SYS_FIELDTYPE_BLOB:
				LPBYTE lpValue;
				bLen		= *(BYTE*)lpDataPtr;
				if(bLen != 255)
				{
					nDataLen  = bLen;
					lpDataPtr += sizeof(BYTE);
				}
				else
				{
					lpDataPtr += sizeof(BYTE);
					nDataLen  = *(int*)lpDataPtr;
					lpDataPtr += sizeof(int);
				}
				nRet = m_pBson->AllocFromCircleBuffer(nDataLen, lpValue);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				memcpy(lpValue, lpDataPtr, nDataLen);
				varResult.SetBinaryData((LPBYTE)lpValue, nDataLen);
				break;
			}
			return MF_OK;
		}
		else
		{
			switch(bFieldType)
			{
			case MF_SYS_FIELDTYPE_INT:
				lpDataPtr			+= sizeof(int);
				nFieldDataOffset	+= sizeof(int);
				break;
			case MF_SYS_FIELDTYPE_BIGINT:
				lpDataPtr			+= sizeof(long long);
				nFieldDataOffset	+= sizeof(long long);
				break;
			case MF_SYS_FIELDTYPE_DOUBLE:
			case MF_SYS_FIELDTYPE_DATE:
				lpDataPtr			+= sizeof(double);
				nFieldDataOffset	+= sizeof(double);
				break;
			case MF_SYS_FIELDTYPE_CHAR:
			case MF_SYS_FIELDTYPE_VARCHAR:
			case MF_SYS_FIELDTYPE_CLOB:
			case MF_SYS_FIELDTYPE_BLOB:
				//获取字段长度
				bLen				= *(BYTE*)lpDataPtr;
				if(bLen != 255)
				{
					nDataLen		= bLen;
					lpDataPtr		+= sizeof(BYTE);
					nFieldDataOffset+= sizeof(BYTE);
				}
				else
				{
					lpDataPtr		+= sizeof(BYTE);
					nFieldDataOffset+= sizeof(BYTE);
					nDataLen		= *(int*)lpDataPtr;
					lpDataPtr		+= sizeof(int);
					nFieldDataOffset+= sizeof(int);
				}
				lpDataPtr			+= nDataLen;
				nFieldDataOffset	+= nDataLen;
				break;
			}
		}
	}
	
	//空字段
	varResult.m_vt = MF_SYS_FIELDTYPE_NULL;
	return MF_OK;	
}

/************************************************************************
		功能说明：
			从记录中获取字符串型字段值
		参数说明：
			nDataID：数据ID用于(ROWID的查询)
			lpRecordBuffer：记录Buffer
			nBufferLen：缓存大小
			lpMathElement：算数表达式元素
			varResult：表达式值
************************************************************************/
int CExpression::GetExpElementValue(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen, LPMATHEXPELEMENTBSON lpMathElement, VARDATA& varResult)
{
	int nRet;
	if(lpMathElement->m_bField)
	{
		nRet = GetFieldValueFromRecordBuffer(nDataID, lpRecordBuffer, nBufferLen, lpMathElement->m_bFieldNo, varResult);
	}
	else
	{
		nRet = ::GetDataValue(lpMathElement, varResult);
	}
	return nRet;
}

int CExpression::GetExpElementValue(LPRECORDDATAINFO lpRecordInfo, LPMATHEXPELEMENTBSON lpMathElement, VARDATA& varResult)
{
	int nRet;
	if(lpMathElement->m_bField)
	{
		if(m_pFile != NULL)
		{
			nRet = m_pFile->GetRecordFieldValue(m_pBson, this, lpRecordInfo, lpMathElement->m_bFieldNo, varResult);
		}
		else
		{
			return MF_INNER_POINTER_NULL;
		}
	}
	else
	{
		nRet = ::GetDataValue(lpMathElement, varResult);
	}
	return nRet;
}


/************************************************************************
	功能说明：
		计算表达式值
	参数说明：
		pDataIDContainer：所有记录
		lpMathExp：数学表达式
		varResult：结果
************************************************************************/
int CExpression::GetExpressionResult(CDataIDContainer* pDataIDContainer, LPMATHEXPBSON lpMathExp, VARDATA& varResult)
{
	int nRet;
	VARDATA varValue1, varValue2;
	LPMATHEXPBSON pMathExpBson1, pMathExpBson2;
	LPMATHEXPELEMENTBSON lpFieldBson1, lpFieldBson2;

	//在Where条件中进行逻辑判断时会出现pMathExpression为NULL的情况，pMathExpression为NULL说明该表达式为真，直接返回1
	if(NULL == lpMathExp)
	{
		varResult.SetData(1);			
		return MF_OK;
	}

	//计算表达式1的结果
	if(3 == lpMathExp->m_bExpressionType1)
	{
		varValue1.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType1)
	{
		pMathExpBson1 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);	
		nRet = GetExpressionResult(pMathExpBson1, varValue1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson1 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);
		nRet = GetFieldValue(lpFieldBson1, varValue1, NULL);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式2的结果
	if(3 == lpMathExp->m_bExpressionType2)
	{
		varValue2.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType2)
	{
		pMathExpBson2 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);	
		nRet = GetExpressionResult(pMathExpBson2, varValue2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson2 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);
		nRet = GetFieldValue(lpFieldBson2, varValue2, NULL);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式结果
	switch(lpMathExp->m_bOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_COUNT:
		{
			long long *pTransactionArray;
			LPEXECUTEPLANBSON lpExecutePlan;
			lpExecutePlan = (LPEXECUTEPLANBSON)m_pBson->GetBuffer();
			
			pTransactionArray = (long long*)m_pBson->GetPtrFromTempBuffer(lpExecutePlan->m_nTransactionOffset);
			TRANSACTIONARRAY stTransactionArray(lpExecutePlan->m_nTransactionNum, pTransactionArray);
			nRet = CFunctionManager::GetFunctionVal(*m_pBson, lpMathExp->m_bOperator, pDataIDContainer, varValue1, varResult, &stTransactionArray, lpExecutePlan->m_nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			break;
		}
	default:
		return MF_COMMON_INVALID_OPERATOR;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		计算表达式值
	参数说明：
		lpMathExp：数学表达式
		varResult：结果
************************************************************************/
int CExpression::GetExpressionResult(LPMATHEXPBSON lpMathExp, VARDATA& varResult)
{
	int nRet;
	VARDATA varValue1, varValue2;
	LPMATHEXPBSON lpMathExpBson1, lpMathExpBson2;
	LPMATHEXPELEMENTBSON lpFieldBson1, lpFieldBson2;

	//在Where条件中进行逻辑判断时会出现pMathExpression为NULL的情况，pMathExpression为NULL说明该表达式为真，直接返回1
	if(NULL == lpMathExp)
	{
		varResult.SetData(1);			
		return MF_OK;
	}

	//计算表达式1的结果
	if(3 == lpMathExp->m_bExpressionType1)
	{
		varValue1.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType1)
	{
		lpMathExpBson1 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);	
		nRet = GetExpressionResult(lpMathExpBson1, varValue1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson1 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);
		nRet = GetFieldValue(lpFieldBson1, varValue1, NULL);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式2的结果
	if(3 == lpMathExp->m_bExpressionType2)
	{
		varValue2.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType2)
	{
		lpMathExpBson2 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);	
		nRet = GetExpressionResult(lpMathExpBson2, varValue2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson2 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);
		nRet = GetFieldValue(lpFieldBson2, varValue2, NULL);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式结果
	switch(lpMathExp->m_bOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_NULL:
		varResult = varValue1;
		break;
	case MF_EXECUTEPLAN_OPERATOR_PLUS:
		varResult = varValue1 + varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_MINUS:
		varResult = varValue1 - varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_MULTIPLY:
		varResult = varValue1 * varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_DIVIDE:
		varResult = varValue1 / varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_LINK:
		nRet = varValue1.Link(*m_pBson, varValue2, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		break;
	case MF_EXECUTEPLAN_OPERATOR_SIGNMINUS:
		varResult = varValue2 - varValue1;
		break;
	case MF_EXECUTEPLAN_OPERATOR_SYSDATE:
	case MF_EXECUTEPLAN_OPERATOR_CURRVAL:
	case MF_EXECUTEPLAN_OPERATOR_NEXTVAL:
	case MF_EXECUTEPLAN_OPERATOR_TOCHAR:
		nRet = CFunctionManager::GetFunctionVal(*m_pBson, lpMathExp->m_bOperator, varValue1, varValue2, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		break;
	case MF_EXECUTEPLAN_OPERATOR_TODATE:
		if(lpFieldBson1->m_bDataType == MF_VARDATA_DATE)
		{
			//说明时间值已经在客户端算出这里直接取值即可
			varResult.SetData(varValue1);
		}
		else
		{
			nRet = CFunctionManager::GetFunctionVal(*m_pBson, lpMathExp->m_bOperator, varValue1, varValue2, varResult);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	default:
		return MF_COMMON_INVALID_OPERATOR;
	}
	return MF_OK;
}

int CExpression::GetExpressionResult(LPSINGLERECORD lpDataArray, LPMATHEXPBSON lpMathExp, VARDATA& varResult)
{
	int nRet;
	VARDATA varValue1, varValue2;
	LPMATHEXPBSON lpMathExpBson1, lpMathExpBson2;
	LPMATHEXPELEMENTBSON lpFieldBson1, lpFieldBson2;
	//在Where条件中进行逻辑判断时会出现pMathExpression为NULL的情况，pMathExpression为NULL说明该表达式为真，直接返回1
	if(NULL == lpMathExp)
	{
		varResult.SetData(1);			
		return MF_OK;
	}

	//计算表达式1的结果
	if(3 == lpMathExp->m_bExpressionType1)
	{
		varValue1.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType1)
	{
		lpMathExpBson1 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);	
		nRet = GetExpressionResult(lpDataArray, lpMathExpBson1, varValue1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson1 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);
		nRet = GetFieldValue(lpFieldBson1, varValue1, lpDataArray);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式2的结果
	if(3 == lpMathExp->m_bExpressionType2)
	{
		varValue2.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType2)
	{
		lpMathExpBson2 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);
		nRet = GetExpressionResult(lpDataArray, lpMathExpBson2, varValue2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson2 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);
		nRet = GetFieldValue(lpFieldBson2, varValue2, lpDataArray);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式结果
	switch(lpMathExp->m_bOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_NULL:
		varResult = varValue1;
		break;
	case MF_EXECUTEPLAN_OPERATOR_PLUS:
		varResult = varValue1 + varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_MINUS:
		varResult = varValue1 - varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_MULTIPLY:
		varResult = varValue1 * varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_DIVIDE:
		varResult = varValue1 / varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_LINK:
		nRet = varValue1.Link(*m_pBson, varValue2, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		break;
	case MF_EXECUTEPLAN_OPERATOR_SIGNMINUS:
		varResult = varValue2 - varValue1;
		break;
	case MF_EXECUTEPLAN_OPERATOR_SYSDATE:
	case MF_EXECUTEPLAN_OPERATOR_CURRVAL:
	case MF_EXECUTEPLAN_OPERATOR_NEXTVAL:
	case MF_EXECUTEPLAN_OPERATOR_TOCHAR:
		nRet = CFunctionManager::GetFunctionVal(*m_pBson, lpMathExp->m_bOperator, varValue1, varValue2, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		break;
	case MF_EXECUTEPLAN_OPERATOR_TODATE:
		if(lpFieldBson1->m_bDataType == MF_VARDATA_DATE)
		{
			//说明时间值已经在客户端算出这里直接取值即可
			varResult.SetData(varValue1);
		}
		else
		{
			nRet = CFunctionManager::GetFunctionVal(*m_pBson, lpMathExp->m_bOperator, varValue1, varValue2, varResult);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	default:
		return MF_COMMON_INVALID_OPERATOR;
	}
	return MF_OK;
}

int CExpression::GetExpressionResult(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen, LPMATHEXPBSON lpMathExp, VARDATA& varResult)
{
	int nRet;
	VARDATA varValue1, varValue2;
	LPMATHEXPBSON lpMathExpBson1, lpMathExpBson2;
	LPMATHEXPELEMENTBSON lpFieldBson1, lpFieldBson2;

	varResult.Free();

	//在Where条件中进行逻辑判断时会出现pMathExpression为NULL的情况，pMathExpression为NULL说明该表达式为真，直接返回1
	if(NULL == lpMathExp)
	{
		varResult.SetData(1);			
		return MF_OK;
	}
	else if(lpMathExp->m_bValType == MF_SYS_FIELDTYPE_NULL)
	{
		varResult.m_vt = MF_VARDATA_NULL;	
		return MF_OK;
	}

	//计算表达式1的结果
	if(3 == lpMathExp->m_bExpressionType1)
	{
		varValue1.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType1)
	{
		lpMathExpBson1 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);	
		nRet = GetExpressionResult(nDataID, lpRecordBuffer, nBufferLen, lpMathExpBson1, varValue1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson1 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);
		nRet = GetExpElementValue(nDataID, lpRecordBuffer, nBufferLen, lpFieldBson1, varValue1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式2的结果
	if(3 == lpMathExp->m_bExpressionType2)
	{
		varValue2.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType2)
	{
		lpMathExpBson2 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);
		nRet = GetExpressionResult(nDataID, lpRecordBuffer, nBufferLen, lpMathExpBson2, varValue2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson2 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);
		nRet = GetExpElementValue(nDataID, lpRecordBuffer, nBufferLen, lpFieldBson2, varValue2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式结果
	switch(lpMathExp->m_bOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_NULL:
		varResult.SetData(varValue1);
		break;
	case MF_EXECUTEPLAN_OPERATOR_PLUS:
		varResult.SetData(varValue1 + varValue2);
		break;
	case MF_EXECUTEPLAN_OPERATOR_MINUS:
		varResult.SetData(varValue1 - varValue2);
		break;
	case MF_EXECUTEPLAN_OPERATOR_MULTIPLY:
		varResult.SetData(varValue1 * varValue2);
		break;
	case MF_EXECUTEPLAN_OPERATOR_DIVIDE:
		varResult.SetData(varValue1 / varValue2);
		break;
	case MF_EXECUTEPLAN_OPERATOR_SIGNMINUS:
		varResult.SetData(varValue2 - varValue1);
		break;
	case MF_EXECUTEPLAN_OPERATOR_LINK:
		nRet = varValue1.Link(*m_pBson, varValue2, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		break;
	case MF_EXECUTEPLAN_OPERATOR_SYSDATE:
	case MF_EXECUTEPLAN_OPERATOR_CURRVAL:
	case MF_EXECUTEPLAN_OPERATOR_NEXTVAL:
	case MF_EXECUTEPLAN_OPERATOR_TOCHAR:
		nRet = CFunctionManager::GetFunctionVal(*m_pBson, lpMathExp->m_bOperator, varValue1, varValue2, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		break;
	case MF_EXECUTEPLAN_OPERATOR_TODATE:
		if(lpFieldBson1->m_bDataType == MF_VARDATA_DATE)
		{
			//说明时间值已经在客户端算出这里直接取值即可
			varResult.SetData(varValue1);
		}
		else
		{
			nRet = CFunctionManager::GetFunctionVal(*m_pBson, lpMathExp->m_bOperator, varValue1, varValue2, varResult);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	default:
		return MF_COMMON_INVALID_OPERATOR;
	}
	return MF_OK;
}

int CExpression::GetExpressionResult(LPRECORDDATAINFO lpRecordInfo, LPMATHEXPBSON lpMathExp, VARDATA& varResult)
{
	int nRet;
	VARDATA varValue1, varValue2;
	LPMATHEXPBSON lpMathExpBson1, lpMathExpBson2;
	LPMATHEXPELEMENTBSON lpFieldBson1, lpFieldBson2;

	varResult.Free();

	//在Where条件中进行逻辑判断时会出现pMathExpression为NULL的情况，pMathExpression为NULL说明该表达式为真，直接返回1
	if(NULL == lpMathExp)
	{
		varResult.SetData(1);			
		return MF_OK;
	}
	else if(lpMathExp->m_bValType == MF_SYS_FIELDTYPE_NULL)
	{
		varResult.m_vt = MF_VARDATA_NULL;	
		return MF_OK;
	}

	//计算表达式1的结果
	if(3 == lpMathExp->m_bExpressionType1)
	{
		varValue1.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType1)
	{
		lpMathExpBson1 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);	
		nRet = GetExpressionResult(lpRecordInfo, lpMathExpBson1, varValue1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson1 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);
		nRet = GetExpElementValue(lpRecordInfo, lpFieldBson1, varValue1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式2的结果
	if(3 == lpMathExp->m_bExpressionType2)
	{
		varValue2.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType2)
	{
		lpMathExpBson2 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);
		nRet = GetExpressionResult(lpRecordInfo, lpMathExpBson2, varValue2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson2 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);
		nRet = GetExpElementValue(lpRecordInfo, lpFieldBson2, varValue2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式结果
	switch(lpMathExp->m_bOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_NULL:
		varResult.SetData(varValue1);
		break;
	case MF_EXECUTEPLAN_OPERATOR_PLUS:
		varResult.SetData(varValue1 + varValue2);
		break;
	case MF_EXECUTEPLAN_OPERATOR_MINUS:
		varResult.SetData(varValue1 - varValue2);
		break;
	case MF_EXECUTEPLAN_OPERATOR_MULTIPLY:
		varResult.SetData(varValue1 * varValue2);
		break;
	case MF_EXECUTEPLAN_OPERATOR_DIVIDE:
		varResult.SetData(varValue1 / varValue2);
		break;
	case MF_EXECUTEPLAN_OPERATOR_SIGNMINUS:
		varResult.SetData(varValue2 - varValue1);
		break;
	case MF_EXECUTEPLAN_OPERATOR_LINK:
		nRet = varValue1.Link(*m_pBson, varValue2, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		break;
	case MF_EXECUTEPLAN_OPERATOR_SYSDATE:
	case MF_EXECUTEPLAN_OPERATOR_CURRVAL:
	case MF_EXECUTEPLAN_OPERATOR_NEXTVAL:
	case MF_EXECUTEPLAN_OPERATOR_TOCHAR:
		nRet = CFunctionManager::GetFunctionVal(*m_pBson, lpMathExp->m_bOperator, varValue1, varValue2, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		break;
	case MF_EXECUTEPLAN_OPERATOR_TODATE:
		if(lpFieldBson1->m_bDataType == MF_VARDATA_DATE)
		{
			//说明时间值已经在客户端算出这里直接取值即可
			varResult.SetData(varValue1);
		}
		else
		{
			nRet = CFunctionManager::GetFunctionVal(*m_pBson, lpMathExp->m_bOperator, varValue1, varValue2, varResult);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	default:
		return MF_COMMON_INVALID_OPERATOR;
	}
	return MF_OK;
}
int CExpression::GetExpressionResult(CSysRecordContainer* pRecordContainer, LPMATHEXPBSON lpMathExp, VARDATA& varResult)
{
	int nRet;
	VARDATA varValue1, varValue2;
	LPMATHEXPBSON pMathExpBson1, pMathExpBson2;
	LPMATHEXPELEMENTBSON lpFieldBson1, lpFieldBson2;

	//在Where条件中进行逻辑判断时会出现pMathExpression为NULL的情况，pMathExpression为NULL说明该表达式为真，直接返回1
	if(NULL == lpMathExp)
	{
		varResult.SetData(1);			
		return MF_OK;
	}

	//计算表达式1的结果
	if(3 == lpMathExp->m_bExpressionType1)
	{
		varValue1.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType1)
	{
		pMathExpBson1 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);	
		nRet = GetExpressionResult(pMathExpBson1, varValue1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson1 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset1);
		nRet = GetFieldValue(lpFieldBson1, varValue1, NULL);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式2的结果
	if(3 == lpMathExp->m_bExpressionType2)
	{
		varValue2.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType2)
	{
		pMathExpBson2 = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);	
		nRet = GetExpressionResult(pMathExpBson2, varValue2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson2 = (LPMATHEXPELEMENTBSON)m_pBson->ConvertOffset2Addr(lpMathExp->m_nExpOffset2);
		nRet = GetFieldValue(lpFieldBson2, varValue2, NULL);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式结果
	switch(lpMathExp->m_bOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_COUNT:
		{
			long long *pTransactionArray;
			LPEXECUTEPLANBSON lpExecutePlan;
			lpExecutePlan = (LPEXECUTEPLANBSON)m_pBson->GetBuffer();

			pTransactionArray = (long long*)m_pBson->GetPtrFromTempBuffer(lpExecutePlan->m_nTransactionOffset);
			TRANSACTIONARRAY stTransactionArray(lpExecutePlan->m_nTransactionNum, pTransactionArray);
			nRet = CFunctionManager::GetFunctionVal(*m_pBson, lpMathExp->m_bOperator, pRecordContainer, varValue1, varResult);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			break;
		}
	default:
		return MF_COMMON_INVALID_OPERATOR;
	}
	return MF_OK;
}