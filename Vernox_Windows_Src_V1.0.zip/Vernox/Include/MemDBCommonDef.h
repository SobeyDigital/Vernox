﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include <stdio.h>
#include "TypeDef.h"

#define MF_DEBUG
//定义系统内部错误号
#define MF_OK												 0       //正确，无错误
#define MF_FAILED                                            1       //失败，通用失败方式（不建议使用） 
#define MF_INNER_EXPCETION_FAILED                            2       //内部错误，异常失败
#define MF_INNER_ALLOCMEM_FAILED                             3       //内部错误，分配内存失败
#define MF_INNER_POINTER_NULL                                4       //内部错误，指针为空
#define MF_INNER_OPENMEMFILE_FAILED                          5       //内部错误，打开内存文件失败
#define MF_INNER_MAPMEMFILE_FAILED                           6       //内部错误，映射内存文件地址失败
#define MF_INNER_FILENO_ERROR                                7       //内部错误，文件编号校验不正确
#define MF_INNER_BLOCKNO_ERROR                               8       //内部错误，块编号不正确，找不到对应数据
#define MF_INNER_INNERNO_NOTEXIST                            9       //内部错误，内部编号不正确，找不到对应数据
#define MF_INNER_INNERNO_DATAERROR                           10      //内部错误，在块内通过块号定位的数据不正确（外部校验未通过）
#define MF_INNER_ALLOWBLOCK_NOENOUGHSPACE                    11      //内部错误，分配数据块时发现空间不够
#define MF_INNER_FILENO_NOTEXIST                             12      //内部错误，引用的文件编号不存在
#define MF_INNER_OBJECTID_NOTEXIST                           13      //内部错误，引用的对象ID不存在
#define MF_INNER_INDEXID_NOTEXIST                            14      //内部错误，引用的索引ID不存在
#define MF_INNER_ITEMDATASIZE_ERROR                          15      //内部错误，发现块头中记录的m_nBlockDataStructSize（定长数据长度），与预期的不符
#define MF_INNER_INSTANCE_UNINITALIZE                        16      //内部错误，实例未初始化
#define MF_INNER_MEMSIZE_ERROR                               17      //内部错误，非法内存大小
#define MF_INNER_SYS_OBJECTMAP_DATAERROR                     20      //内部错误，OBJECTMAP记录的OBJECTID不正确
#define MF_INNER_SYS_BLOCKSIZE_ERROR                         21      //内部错误，块头记录的m_nBlockSize不正确，目前系统文件的所有块的大小都固定为256KB
#define MF_INNER_SYS_TRACE_INIT_ERROR                        22      //内部错误，日志初始化失败
#define MF_INNER_SYS_TRACE_EVENT_FAILED                      23      //内部错误，日志事件初始化失败
#define MF_INNER_SYS_UNINITIALIZE_FAILED                     24      //内部错误，系统没有初始化
#define MF_INNER_SYS_INVALID_PARAMETER_ERROR                 25      //内部错误，参数错误或者叫非法参数
#define MF_INNER_SYS_MEMDBFILENAME_INVALID                   26      //内部错误，给定的内存文件名非法
#define MF_INNER_SYS_SOURCEOCCUPIED_INVALID                  27      //内部错误，资源被占用
#define MF_INNER_SYS_SOURCERELEASE_ERROR					 28		 //内部错误，资源释放出错
#define MF_INNER_SYS_FULLOBJECT_ERROR    					 29		 //内部错误，文件中对象已满
#define MF_INNER_SYS_RELEASELOCK_ERROR    					 30		 //内部错误，释放锁失败
#define MF_INNER_SYS_OPENSHMEM_ERROR    					 31		 //内部错误，打开共享内存失败

#define MF_INNER_SYS_INITIALIZECOM_INVALID					 50		 //内部错误，初始化COM组件错误
#define MF_INNER_SYS_CREATEXMLDOM_INVALID					 51		 //内部错误，创建XMLDOM失败
#define MF_INNER_SYS_CREATEXMLROOT_INVALID					 52		 //创建XML根节点失败
#define MF_INNER_SYS_LOADXML_ERROR							 53		 //加载XML失败
#define MF_INNER_SYS_NOMATCHNODE_ERROR						 54		 //未找到指定xml结点
#define MF_INNER_SYS_NULLNODE_ERROR							 55      //结点为空
#define MF_INNER_SYS_TRANSACTIONLOGIC_EXIST_FAILED		     56      //事务字符串已经存在导致失败

#define MF_SYS_DBFILE_FILENAME_ERROR                         100     //添加或另存内存数据文件时，指定的新文件已经存在
#define MF_SYS_DBFILE_MEMFILENAME_ERROR                      101     //添加内存数据文件时，指定的内存文件名已经存在
#define MF_SYS_DBFILE_SERVICESTORAGE_NOTRESPONSE             102     //添加内存数据文件时，请求服务执行无响应
#define MF_SYS_DBFILE_NOTEXIST                               103     //指定的内存数据文件不存在
#define MF_SYS_DBFILE_SERVICE_FILENO_ERROR                   104     //VernoxStorage检查到添加的文件编号重复错误
#define MF_SYS_DBFILE_SERVICE_FILEPATH_ERROR                 105     //VernoxStorage检查到添加的文件路径重复错误
#define MF_SYS_DBFILE_SERVICE_MEMFILE_ERROR                  106     //VernoxStorage检查到添加的内存文件名重复错误
#define MF_SYS_DBFILE_SERVICE_NEWFILE_FAILED                 107     //VernoxStorage保存新文件重复
#define MF_SYS_DBFILE_SERVICE_NOTEXIST                       108     //VernoxStorage没找到对应文件
#define MF_SYS_DBFILE_SERVICE_CHANGEFILE_FAILED              109     //VernoxStorage改变文件路径失败
#define MF_SYS_DBFILE_FILENO_REPEATERROR                     110     //发现数据中出现了重复的文件编号，整个系统无法启动
#define MF_SYS_DBFILE_FILENO_ERROR                           111     //添加的文件编号重复错误
#define MF_SYS_DBFILE_FILEEXIST                              112     //添加或另存内存数据文件时，指定的新文件已经存在
#define MF_SYS_DBFILE_MEMFILEEXIST                           113     //添加内存数据文件时，指定的内存文件名已经存在
#define MF_SYS_DBFILE_NO_FILESIZE_ERROR                      114     //添加内存数据文件时，未指定文件大小
#define MF_SYS_DBFILE_NO_FILEPATH_ERROR                      115     //添加内存数据文件时，未指定文件路径
#define MF_SYS_DBFILE_NO_MEMFILE_ERROR                       116     //添加内存数据文件时，未指定内存文件名
#define MF_SYS_DBFILE_NO_FILETYPE_ERROR                      117     //添加内存数据文件时，文件类型错误
#define MF_SYS_DBFILE_NOSUPPORT_FILETYPE_FAILED              118     //初始化内存文件实例时，遇到不支持的文件类型

#define MF_SYS_SEQUENCE_ADDNAMEEXIST                         200     //序列添加时，重名失败
#define MF_SYS_SEQUENCE_NOTEXIST                             201     //序列不存在
#define MF_SYS_SEQUENCE_MAXVALUE                             202     //序列值已经达到最大值
#define MF_SYS_SEQUENCE_NAME_REPEATERROR                     203     //发现序列中出现重复名字的序列，整个系统无法启动

#define MF_SYS_OBJECT_REPEATERROR                            300     //发现数据中出现了重复的对象编号，整个系统无法启动
#define MF_SYS_OBJECT_FIELDORDERERROR                        301     //发现对象数据中的字段序号不正确
#define MF_SYS_OBJECT_NOTEXIST                               302     //通过对象名找对象信息不存在
#define MF_SYS_OBJECT_ADDNAMEEXIST                           303     //数据对象添加时，重名失败
#define MF_SYS_OBJECT_NOFIELD                                304     //数据对象添加时没有列数据
#define MF_SYS_OBJECT_MANYFIELD                              305     //数据对象添加时列数据太多
#define MF_SYS_OBJECT_DATAFILE_NOTEXIST                      306     //数据对象添加时给定的数据文件名不存在
#define MF_SYS_OBJECT_BINDEXFILE_NOTEXIST                    307     //数据对象添加时给定的B树索引文件名不存在
#define MF_SYS_OBJECT_KVINDEXFILE_NOTEXIST                   308     //数据对象添加时给定的KV索引文件名不存在
#define MF_SYS_OBJECT_INDEXTYPE_NOTSUPPORT                   309     //数据索引类型不支持
#define MF_SYS_OBJECT_DELETENOTEXIST                         310     //删除数据对象添加时，没找到指定对象
#define MF_SYS_OBJECT_ADDFIELDNAME_EXIST                     311     //添加的对象字段出现重复
#define MF_SYS_OBJECT_FIELDNO_ERROR                          312     //数据对象添加时，有索引存在的情况下，字段序列不正确
#define MF_SYS_OBJECT_DELETEFIELDNO_NOTEXIST                 313     //删除字段时，字段名不存在
#define MF_SYS_OBJECT_DELETEINDEX_NOTEXIST                   314     //删除字段时，索引名不存在
#define MF_SYS_OBJECT_ADDINDEX_EXIST                         315     //添加索引时，索引名重复
#define MF_SYS_OBJECT_ADDINDEX_FILETYPE_ERROR                316     //添加索引时，给定的文件类型和索引类型不符合
#define MF_SYS_OBJECT_ADDINDEX_FIELDNAME_ERROR               317     //添加索引时，给定的索引字段找不到
#define MF_SYS_OBJECT_INDEX_INVALID_FIELDTYPE_ERROR          318     //转换索引类型时遇到错误字段类型
#define MF_SYS_OBJECT_INDEX_INVALID_FILETYPE_ERROR           319     //转换索引类型时遇到传入的文件类型为系统文件或者数据文件
#define MF_SYS_OBJECT_INDEX_NOSUPPORT_FILETYPE_ERROR         320     //转换索引类型时遇到传入的文件类型不支持
#define MF_SYS_OBJECT_GRAPHFIELD_ERROR                       321     //图对象字段错误
#define MF_SYS_OBJECT_ALTERGRAPH_ERROR                       322     //图对象表结构不允许修改
#define MF_SYS_OBJECT_IMPLEMENTCLASS_ERROR					 323	 //对象实现类出错
#define MF_SYS_OBJECT_IMPLEMENTCLASS_LOAD					 324	 //系统正在载入文件，暂时禁用非系统对象插件
#define MF_SYS_OBJECT_ADDINDEX_MULTIPRIMRAYKEY_ERROR         325     //添加索引时，存在多个主键，异常

#define MF_SYS_USER_NOTEXIST                                 330     //用户信息不存在
#define MF_SYS_USER_ADDNAMEEXIST                             331     //添加用户时发现用户名已存在
#define MF_SYS_USER_REPEATERROR								 332     //发现数据中出现了重复的用户编号，整个系统无法启动

#define MF_SYS_AUTHORITY_NOTEXIST                            340     //用户信息不存在

#define MF_PARSECMD_INVALID_START_ERROR                      500     //解析命令时遇到非法开始字符错误
#define MF_PARSECMD_INVALID_CHAR_ERROR                       501     //解析命令时遇到非法字符错误
#define MF_PARSECMD_INVALID_COMMAND_ERROR                    502     //解析命令时遇到非法命令错误
#define MF_PARSECMD_INVALID_NULL_ERROR                       503     //解析命令时发现命令为空错误
#define MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR              504     //解析CREATE命令时出现语法错误
#define MF_PARSECMD_INVALID_SELECT_SYNTAX_ERROR              505     //解析SELECT命令时出现语法错误
#define MF_PARSECMD_INVALID_INSERT_SYNTAX_ERROR              506     //解析INSERT命令时出现语法错误
#define MF_PARSECMD_INVALID_UPDATE_SYNTAX_ERROR				 507	 //解析UPDATE命令时出现语法错误
#define MF_PARSECMD_INVALID_DELETE_SYNTAX_ERROR				 508	 //解析DELETE命令时出现语法错误
#define MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR               509     //解析ALTER命令时出现语法错误
#define MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR                  510     //SQL语句中的期待对象名时，语法上有错误
#define MF_PARSECMD_FIELDNAME_SYNTAX_ERROR                   511     //SQL语句中的期待字段时，语法上有错误
#define MF_PARSECMD_INVALID_NUMBER_ERROR                     512     //SQL语句中的期待数字数据时，语法上有错误
#define MF_PARSECMD_INVALID_STRING_ERROR                     513     //SQL语句中的期待字符串数据时，语法上有错误
#define MF_PARSECMD_INVALID_OPERATOR_ERROR                   514     //SQL语句中的期待运算符时，语法上有错误
#define MF_PARSECMD_INVALID_EXPRESSION_ERROR                 515     //SQL语句中的期待表达式时，语法上有错误
#define MF_PARSECMD_INVALID_DATACOMPATIBLE_ERROR             516     //SQL语句中的期待数据时，类型兼容上有错误
#define MF_PARSECMD_INVALID_FUNCTION_ERROR					 517     //SQL语句中的期待函数时，函数出错
#define MF_PARSECMD_INVALID_USER_ERROR						 518     //解析SQL语句时发现用户错误
#define MF_PARSECMD_INVALID_AUTHORITY_ERROR					 519     //解析SQL语句时发现权限错误
#define MF_PARSECMD_EXECUTEPALN_LACKSPACE_ERROR				 529     //解析SQL语句时发现执行计划空间不足
#define MF_PARSECMD_EXECUTEPALN_INVALID_SIZE_ERROR			 530	 //解析SQL语句时发现执行计划大小有误

#define MF_PARSECMD_EMPTY_STRING							 530	 //解析SQL语句发现是空字符串

#define MF_PARSECREATE_OBJECT_EXIT_ERROR					 540	 //解析创建对象命令时，发现对象已存在
#define MF_PARSECREATE_USER_PASSWORDFORMAT_ERROR			 541	 //解析创建用户命令时，发现密码格式错误

#define MF_PARSESELECT_INVALID_NULLOBJECT_ERROR				 551	 //解析查询命令时发现表名为空错误
#define MF_PARSESELECT_INVALID_MULTIOBJECT_ERROR			 552	 //解析查询命令时发现有多个表名错误
#define MF_PARSESELECT_INVALID_OBJECT_ERROR					 553	 //解析查询命令时发现表名错误
#define MF_PARSESELECT_INVALID_FIELD_ERROR					 554	 //解析查询命令时发现非法列名
#define MF_PARSESELECT_INVALID_QUERYINDEX_ERROR				 555	 //解析查询命令时发现非法查询索引 
#define MF_PARSESELECT_INVALID_FIELDRANGE_ERROR				 556     //解析查询命令时发现字段范围异常：如 SNO>20 AND SNO<10
#define MF_PARSESELECT_INVALID_COMPATIBLETYPE_ERROR          557	 //解析查询命令时发现数据兼容性异常
#define MF_PARSESELECT_INVALID_WHERECONDITION_ERROR          558     //解析查询命令是发现查询条件错误
#define MF_PARSESELECT_INVALID_DATATYPE_ERROR				 559     //解析查询命令是发现数据类型错误
#define MF_PARSESELECT_INVALID_CONNECTION_ERROR				 560     //解析查询命令是发现CONNECTIONT条件错误
#define MF_PARSESELECT_INVALID_DRECITON_ERROR				 561     //解析查询命令是发现CONNECTIONT方向错误
#define MF_PARSESELECT_INVALID_SEQUENCE_ERROR				 562     //解析查询命令是发现序列错误
#define MF_PARSESELECT_INVALID_PAGING_ERROR					 563     //解析查询命令是发现分页错误
#define MF_PARSESELECT_INVALID_OBJECTTYPE_ERROR				 564     //解析查询命令对象类型不匹配
#define MF_PARSESELECT_INVALID_ROWNUMEXPRESSION_ERROR		 565     //非法ROWNUM表达式
#define MF_PARSESELECT_INVALID_LOGICOPERATOR_ERROR			 566     //非法逻辑表达式

#define MF_PARSEUPDATE_INVALID_QUERYINDEX_ERROR				 570	 //解析更新命名时发现非法索引 
#define MF_PARSEUPDATE_INVALID_FIELD_ERROR					 571     //解析更新命名时发现非法字段名
#define MF_PARSEUPDATE_INVALID_EXPRESSION_ERROR				 572     //解析更新命名时发现非法表达式
#define MF_PARSEUPDATE_INVALID_OBJECTTYPE_ERROR				 573     //解析更新命令对象类型不匹配
#define MF_PARSEUPDATE_INVALID_OBJECTNAME_ERROR				 574	 //解析更新命令对象名不正确

#define MF_PARSEDELETE_INVALID_QUERYINDEX_ERROR				 580	 //解析删除命令时发现非法删除索引 
#define MF_PARSEDELETE_INVALID_OBJECT_ERROR	     			 581     //解析删除命令对发现表名错误
#define MF_PARSEDELETE_INVALID_OBJECTTYPE_ERROR				 582     //解析删除命令对象类型不匹配
#define MF_PARSEDELETE_INVALID_CONDITION_ERROR				 583     //解析删除命令对象类型不匹配

#define MF_PARSEALTER_INVALID_OBJECTTYPE_ERROR				 585     //解析修改命令对象类型不匹配

#define MF_PARSEISNERT_INVALID_FIELD_ERROR					 590     //解析插入命令时发现非法列名
#define MF_PARSEISNERT_INVALID_COMPATIBLETYPE_ERROR			 591     //解析插入命令时发现数据兼容类型错误
#define MF_PARSEISNERT_INVALID_NULLPOINTER_ERROR			 592     //解析插入命令时空指针错误
#define MF_PARSEISNERT_INVALID_OBJECTTYPE_ERROR				 593     //解析插入命令对象类型不匹配
#define MF_PARSEISNERT_INVALID_RELATIONNODECOND_ERROR		 594     //解析插入命令对象关系的节点条件错误
#define MF_PARSEINSERT_INVALID_OBJECT_ERROR					 595	 //解析插入命令时发现表名错误

#define MF_CREATELOGIC_INVALID_NULLQUEUE_ERROR				 600	 //创建执行逻辑时发现后缀表达式栈队列空错误
#define MF_CREATELOGIC_INVALID_QUEUE_ERROR					 601     //创建执行逻辑时发现后缀表达式队列错误
#define MF_CREATELOGIC_INVALID_LOGICSTACK_ERROR				 602     //创建执行逻辑时发现逻辑达式栈错误

#define MF_CREATEEXPRESSION_INVALID_NULLQUEUE_ERROR			 610	 //创建表达式时发现后缀表达式队列为空错误
#define MF_CREATEEXPRESSION_INVALID_QUEUE_ERROR				 611     //创建表达式时发现后缀表达式队列错误
#define MF_CREATEEXPRESSION_INVALID_EXPRESSIONSTACK_ERROR	 612     //创建表达式时发现表达式栈错误


#define MF_EXECUTEQUERY_INVALID_INDEXCONDITION_ERROR         650	 //执行查询语句时发现索引条件错误				 	 
#define MF_EXECUTEQUERY_INVALID_DATA_ERROR					 651	 //执行查询语句时发现数据错误	
#define MF_EXECUTEQUERY_INVALID_NULLFIELD_ERROR				 652	 //执行查询语句时发现空字段
#define MF_EXECUTEQUERY_INVALID_NULLDATA_ERROR				 653	 //执行查询语句时发现没有满足条件的字段
#define MF_EXECUTEQUERY_INVALID_OPERATOR_ERROR               654     //执行查询语句时发现运算符错误
#define MF_EXECUTEQUERY_INVALID_ANALYSISBUFFER_ERROR         655     //执行查询语句时反序列化Buffer错误
#define MF_EXECUTEQUERY_INVALID_NULLPOINT_ERROR				 656     //执行查询语句时空指针异常

#define MF_EXECUTEUPDATE_INVALID_ANALYSISBUFFER_ERROR        660     //执行修改语句时反序列化Buffer
#define MF_EXECUTEUPDATE_INVALID_NULLDATA_ERROR				 661	 //执行修改语句时发现没有满足条件的字段
#define MF_EXECUTEUPDATE_INVALID_NULLFIELD_ERROR			 662     //执行修改语句时发现不允许为空的字段为空错误
#define MF_EXECUTEUPDATE_INVALID_FIELD_ERROR			     663     //执行修改语句时发现字段非法
#define MF_EXECUTEUPDATE_INVALID_CHARLEN_ERROR				 664	 //执行修改语句时发现定长字符串长度异常


#define MF_EXECUTEDELETE_INVALID_ANALYSISBUFFER_ERROR        670     //执行删除语句时反序列化Buffer
#define MF_EXECUTEDELETE_INVALID_NULLDATA_ERROR				 671	 //执行删除语句时发现没有满足条件的字段


#define MF_EXECUTEINSERT_INVALID_NULLFIELD_ERROR			 700     //执行插入语句时发现不允许为空的字段为空错误
#define MF_EXECUTEINSERT_INVALID_APPENDDATA_ERROR			 701     //执行插入语句时序列化数据失败
#define MF_EXECUTEINSERT_INVALID_EXPRESSION_ERROR			 702     //执行插入语句时表达式错误

#define MF_EXECUTERECORDSETUPDATE_INVALID_NULLEXEPLAN_ERROR  710     //执行结果集更新时，发现执行计划为空

#define MF_PARSECMD_INVALID_DROP_SYNTAX_ERROR                800     //删除语句语法错误
#define MF_PARSECMD_DROP_LACK_KEYWORD_ERROR                  801     //删除语句缺少关键词错误
#define MF_PARSECMD_CREATE_LACK_WITH_ERROR                   804     //创建语句缺少With错误
#define MF_PARSECMD_CREATE_LACK_BY_ERROR                     805     //创建语句缺少By错误
#define MF_PARSECMD_CREATE_LACK_BRACE_ERROR                  806     //创建语句缺少括号错误
#define MF_PARSECMD_CREATE_FIELD_NOTEXISTS_ERROR             807     //创建语句中的列不存在错误
#define MF_PARSECMD_CREATE_LACK_KEYWORD_ERROR                808     //创建语句缺少关键词错误
#define MF_PARSECMD_CREATE_INDEXNAME_EXIST_ERROR			 809     //创建语句索引名称重复，错误
#define MF_PARSECMD_CREATE_LACK_PRIMARYINDEX_ERROR			 810     //创建语句主键缺少索引错误
#define MF_PARSECMD_CREATE_HBINDEX_FIELDTYPE_NOTQUEAL		 811     //创建语句中HB树索引的主键字段与父亲字段的数据类型不相同

#define MF_PARSECMD_ALTER_LACK_BRACE_ERROR                   820     //修改语句缺少括号错误
#define MF_PARSECMD_ALTER_LACK_KEYWORD_ERROR                 821     //修改语句缺少关键词错误
#define MF_PARSECMD_ALTER_SET_SYSTEM_INIT_ERROR              822     //修改系统参数，初始化未初始化完成，无法获取系统参数
#define MF_PARSECMD_ALTER_SET_SYSTEM_PARAMETERNAME_ERROR     823     //修改系统参数，参数值不合法
#define MF_PARSECMD_ALTER_INDEX_TYPE_ERROR                   824     //修改索引时，发现给定的数据文件类型

#define MF_PARSECMD_INVALID_GRANT_SYNTAX_ERROR               825     //授权语句语法错误
#define MF_PARSECMD_INVALID_REVOKE_SYNTAX_ERROR              826     //授权语句语法错误

#define MF_INTERFACE_NOT_OPEN                                900     //未打开数据库链接
#define MF_INTERFACE_SOCKET_CREATE_FAILED                    901     //连接服务器时，创建Socket失败
#define MF_INTERFACE_SOCKET_CONNECT_FAILED                   902     //连接服务器失败
#define MF_INTERFACE_SENDDATA_FAILED                         903     //发送数据失败
#define MF_INTERFACE_RECEIVEDATA_TIMEOUT                     904     //接收数据超时
#define MF_INTERFACE_RECEIVEDATA_CONNECTRESET                905     //接收数据链接重置
#define MF_INTERFACE_RECEIVEDATA_FAILED                      906     //接收数据失败
#define MF_INTERFACE_RECEIVEDATA_DATAERROR                   907     //接收数据错误
#define MF_INTERFACE_RECEIVEDATA_TOKENERROR                  908     //通讯令牌错误
#define MF_INTERFACE_SERVER_PARSE_FAILED                     909     //服务名解析失败
#define MF_INTERFACE_SERVER_PARSE_ERROR                      910     //未找到传入的服务名
#define MF_INTERFACE_CLIENT_LOAD_FAILED                      911     //加载SobeyMemClient.dll库失败
#define MF_INTERFACE_CLIENT_FUNC_FAILED                      912     //定位SobeyMemClient.dll库函数失败

//非系统级错误码定义，从1000开始

//文件级异常1000~1049
#define MF_MEMORYFILE_ALLOCBLOCK_NOENOUGHMEMORY_ERROR		 1000	  //分配空块时，空间不足错误
#define MF_MEMORYFILE_ALLOCBLOCK_INVALIDDATAFLAG_ERROR		 1001	  //分配空块时，块标识错误
#define MF_MEMORYFILE_ALLOCBLOCK_NULLPOINTBLOCK_ERROR		 1002	  //分配空块时，未找到指定块
#define MF_MEMORYFILE_ALLOCBLOCK_INVALDRESOURCETYPE_ERROR	 1003     //分配空块时，块来源错误
#define MF_MEMORYFILE_ALLOCBLOCK_LOCKNEWBLOCK_ERROR			 1004	  //分配空块时，锁定新块失败
#define MF_MEMORYFILE_ALLOCNEWDATA_NOENOUGHMEMORY_ERROR		 1005	  //分配新数据时，空间不足
#define MF_MEMORYFILE_MERGEMEMORY_BLOCKPOINTER_ERROR		 1006	  //整理文件时，块指针错误
#define MF_MEMORYFILE_INSERTMAPSTRUCT_ERROR					 1007	  //插入块映射表错误
#define MF_MEMORYFILE_MOVEMAPSTRUCT_ERROR					 1008	  //插入块映射表错误

#define MF_MEMORYFILE_DATA_TIMESTAMP_ERROR					 1015	  //数据时间戳错误
#define MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR		 1016	  //将DataID转换成对象指针时，DataID错误
#define MF_MEMORYFILE_FINDMAPSTRUCT_INVALIDLIST_ERROR		 1017     //在某链表(满块链表或空块链表)中查找某一结点时，链表起始地址错误
#define MF_MEMORYFILE_FINDMAPSTRUCT_NOBLOCKMATCH_ERROR		 1018     //在某链表(满块链表或空块链表)中查找某一结点时，没有相应块匹配错误
#define MF_MEMORYFILE_GETFIELDDATA_INVALIDFIELDNO_ERROR		 1019     //根据字段编号获取字段值时，字段编号错误
#define MF_MEMORYFILE_GETSTRINGDATA_INVALIDVARDATA_ERROR	 1020     //获取字符串字段时，变长数据错误
#define MF_MEMORYFILE_GETVARDATA_INVALIDVARDATA_ERROR	     1021     //获取变长数据时，变长数据错误
#define MF_MEMORYFILE_GETINSERTDATAID_NEWBLOCKLOCK_ERROR	 1022     //绑定插入记录时，发现新分配的块已被上锁
#define MF_MEMORYFILE_GETFILEOBJECT_NOOBJECTMATHC_ERROR	     1023     //获取对象信息时，无对象匹配
#define MF_MEMORYFILE_GETBLOCKPTR_BLOCKNO_ERROR				 1024     //获取对象信息时，无对象匹配

#define MF_MEMORYFILE_INSERTDATA_INVALIDMEMORYMAP_ERROR		 1025     //插入数据时，映射表错误
#define MF_MEMORYFILE_INSERTDATA_INVALIDOBJECTID_ERROR		 1026	  //插入数据时，ObjectID错误
#define MF_MEMORYFILE_INSERTDATA_INVALIDDATAID_ERROR         1027     //插入数据时，DataID错误
#define MF_MEMORYFILE_INSERTDATA_NOENOUGHMEMORY_ERROR        1028     //插入数据时，空间不足错误

#define MF_MEMORYFILE_READDATA_INVALIDDATAID_ERROR           1030     //读取数据时，DataID错误
#define MF_MEMORYFILE_READDATA_NULLDATA_ERROR				 1031     //读取数据时，数据已被删除

#define MF_MEMORYFILE_UPDATEDATA_INVALIDDATAID_ERROR         1035     //更新数据时，DataID错误
#define MF_MEMORYFILE_UPDATEROLLBACK_BUFFERSIZE_ERROR		 1036	  //更新回滚时，空间长度错误

#define MF_MEMORYFILE_DELETEDATA_INVALIDDATAID_ERROR         1040     //删除数据时，DataID错误

//B树索引相关异常1050~1099
#define MF_BTREEINDEX_INVALIDROOTNO_ERROR					 1050     //根节点编号错误
#define MF_BTREEINDEX_INVALIDNODENO_ERROR					 1051     //节点编号错误
#define MF_BTREEINDEX_INVALIDNODETYPE_ERROR					 1052     //节点类型错误
#define MF_BTREEINDEX_INVALIDINXEXID_ERROR					 1053	  //IndexID错误
#define MF_BTREEINDEX_INVALIDINDEXTYPE_ERROR				 1054     //索引类型错误
#define MF_BTREEINDEX_ALLOCBLOCK_NOENOUGHMEMORY_ERROR        1055     //没有足够的空间分配内存错误
#define MF_BTREEINDEX_CONVERTNODENO_INVALIDNODENO_ERROR		 1056     //将块号转换为指针时，块号异常
#define MF_BTREEINDEX_FINDMAPSTRUCT_INVALIDLIST_ERROR		 1057     //在某链表(满块链表或空块链表)中查找某一结点时，链表起始地址错误
#define MF_BTREEINDEX_FINDMAPSTRUCT_NOBLOCKMATCH_ERROR		 1058     //在某链表(满块链表或空块链表)中查找某一结点时，没有节点匹配

#define MF_BTREEINDEX_TREESEARCH_NULLPOINTER_ERROR			 1060     //遍历B树时，空指针错误
#define MF_BTREEINDEX_TREESEARCH_NULLDATA					 1061     //遍历B树时，没有找到合适数据
#define MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH				 1062     //遍历B树时，没有匹配的关键字
#define MF_BTREEINDEX_BINARYSEARCH_NOKEYEQUAL				 1063     //遍历B树时，没有相同的关键字
#define MF_BTREEINDEX_UNIQUEKEY_EXIST					     1064	  //遍历B树时，唯一关键字存在
#define MF_BTREEINDEX_DELETESTRING_IDNOTMATCH				 1065     //删除B树索引字符串关键字时DATAID不匹配
#define MF_BTREEINDEX_GETMULTIKEYINFO_ERROR   				 1066     //获取字符串符合索引的关键字信息失败
#define MF_BTREEINDEX_DELETEKEY_KEYPOSERROR   				 1067     //删除B树索引字符串关键字时，关键字位置错误
#define MF_BTREEINDEX_DELETEINDEX_NODEERROR				  	 1068     //删除B树索引字符串关键字时,节点错误

#define MF_BTREEINDEX_MERGENODE_ERROR   					 1070     //B树索引合并错误

#define MF_BTREEINDEX_RECYCLEBUFFERSIZE_ERROR   			 1075     //回收Buffer大小错误
//KV索引相关异常1100~1149
#define MF_KVINDEX_INVALIDROOTNO_ERROR						 1100     //根节点编号错误
#define MF_KVINDEX_INVALIDBLOCKNO_ERROR						 1101     //节点编号错误
#define MF_KVINDEX_INVALIDINDEXID_ERROR						 1102     //IndexID错误
#define MF_KVINDEX_INVALINDEXOFFSET_ERROR					 1103     //索引偏移错误
#define MF_KVINDEX_INVALIDINDEXTYPE_ERROR					 1104     //索引类型错误
#define MF_KVINDEX_MULTIKEY_ERROR							 1105     //关键字值重复
#define MF_KVINDEX_ALLOCBLOCK_NOENOUGHMEMORY_ERROR			 1110     //没有足够的空间分配内存错误
#define MF_KVINDEX_PARENT_NOTFOUND_ERROR		             1111     //二叉树父亲结点未找到

//回滚区异常1150~1159
#define MF_MEMANALYSIS_NULLPOINTER_ERROR				     1150	   //空指针异常
#define MF_ROLLBACKBUFFER_GETDATA_BLOCKNUM_ERROR			 1151	   //获取回滚区数据轮数失效错误
#define MF_ROLLBACKBUFFER_GETDATA_OFFSET_ERROR			     1152	   //获取回滚区数据偏移量错误
#define MF_ROLLBACKBUFFER_GETDATA_TIMESTAMP_ERROR			 1153	   //获取回滚区数据时间错误

//分页异常1160~1169
#define MF_PAGING_ERROR										 1160       //分页异常
#define MF_PAGING_LACKPAGEBUFFER_ERROR    					 1161		//页面Buffer不足
#define MF_PAGING_INVALIDBUFFERNO_ERROR    					 1162		//非法缓存编号
#define MF_PAGING_INVALIDPAGENO_ERROR    					 1163		//非法页编号
#define MF_PAGING_PAGETIMEOUT_ERROR							 1164       //页面失效(被覆盖)

//HB树索引相关异常1170~1179
#define MF_HBINDEX_DELETEINDEX_EXSITCHILD_ERROR			     1170		//HB树结点存在孩子结点，删除失败
#define MF_HBINDEX_UPDATEINDEX_EXSITCHILD_ERROR			     1171		//HB树结点存在孩子结点，更新失败
#define MF_HBINDEX_UPDATEINDEX_INVALIDPID_ERROR			     1172		//父亲结点错误，删除失败

//记录Buffer相关异常1200~1250
#define MF_ROWDATABUFFER_NULL_POINTER					     1200		//空指针异常
#define MF_ROWDATABUFFER_NULL_DATABUFFER					 1201		//空数据异常
#define MF_ROWDATABUFFER_INVALID_FIELDTYPE					 1202		//非法列类型
#define MF_ROWDATABUFFER_INVALID_BUFFERLEN					 1203		//非法BUFFER长度

//Check的相关异常
#define MF_CHECK_GETFIELDVALUE_ERROR						 1300		//从记录中获取字段值异常

//公共异常1500以后
#define MF_COMMON_INVALID_DATA								 1500		//非法数据
#define MF_COMMON_INVALID_DATATYPE							 1501       //非法数据类型
#define MF_COMMON_INVALID_FUNTYPE                            1502       //非法函数类型          
#define MF_COMMON_INVALID_OPERATOR                           1503       //非法运算符
#define MF_COMMON_INVALID_DATEFORMAT                         1504       //非法日期格式
#define MF_COMMON_INVALID_DATE                               1505       //非法日期
#define MF_COMMON_INVALID_CMDTYPE                            1506       //非法命令类型
#define MF_COMMON_INVALID_FIELD		                         1508       //非法列
#define MF_COMMON_INVALID_OBJECTID							 1509	    //错误对象ID
#define MF_COMMON_INVALID_COMPARECONDITION					 1510	    //比较条件错误
#define MF_COMMON_INVALID_STRINGLEN							 1511       //字符串长度错误
#define MF_COMMON_INVALID_NULLPRIMARYKEY					 1512       //空主键异常
#define MF_COMMON_INVALID_INDEXTYPE							 1513       //非法索引类型
#define MF_COMMON_INVALID_NONEPRIMARYKEY					 1514		//缺少主键
#define MF_COMMON_MAX_DATANUM								 1515		//记录数已达上限
#define MF_COMMON_MAX_OBJECT								 1516		//对象数已达上限
#define MF_COMMON_MAX_INDEX								     1517		//索引数已达上限
#define MF_COMMON_INVALID_STEPTYPE							 1518		//步骤类型错误
#define MF_COMMON_INVALID_OBJECTTYPE						 1519		//对象类型错误
#define MF_COMMON_RECORD_NOTEXIT     						 1520		//记录不存在
#define MF_COMMON_INVALID_FIELDTYPE	                         1521       //非法列
#define MF_COMMON_INVALID_EXECUTEBLOCKNUM	                 1522       //操作所涉及的块数量超过限制
#define MF_COMMON_INVALID_DATABASE			                 1523       //非法数据库
#define MF_COMMON_INVALID_FIELDNO		                     1524       //非法列编号
#define MF_COMMON_INVALID_BUFFERSIZE		                 1525       //非法缓存大小
#define MF_COMMON_FILE_NOTEXIT				                 1526       //文件不存在
#define MF_COMMON_LOCKTYPE_ERROR				             1527       //锁类型错误

//创建执行计划异常
#define MF_CREATEPLAN_GETRECORDLEN_FAILED				     1550	    //创建执行计划时获取记录长度失败
#define MF_CREATEPLAN_INVALIDBUFFERNO_FAILED				 1551	    //创建执行计划时缓存编号错误

//登录异常信息
#define MF_USERLOGIN_INVALIDUSERNAME_FAILED					 1560	    //用户名不存在
#define MF_USERLOGIN_INVALIDPASSWORD_FAILED					 1561	    //密码不正确
#define MF_USERLOGIN_DISABLE_USER							 1562	    //用户被禁用

//闪回异常信息
#define MF_FLASHBACK_TIMEOUT								 1610		//调用闪回超时
#define MF_FLASHBACK_INVALID_MAP_SIZE						 1611		//调用闪回时检测到映射表大小异常
#define MF_FLASHBACK_INVALID_BUFFER_SIZE					 1612		//调用闪回时检测缓存大小
//验证数据库GUID的异常
#define MF_SYS_DATABASE_GUID_UNMATCH						 1620		//验证数据库GUID失败，读到的日志文件与数据库不匹配

//获取记录的错误
#define MF_GETRECORD_INVALID_RECORDSECTIONARRAY				 1700		//获取记录时，记录片段数组错误

//索引优化器异常
#define MF_INDEXOPTIMIZER_CONDITIONOFFSET_ERROR				 3000		//索引优化器中，查询条件偏移异常
#define MF_INDEXOPTIMIZER_EXPRESSIONOFFSET_ERROR			 3001		//索引优化器中，表达式偏移异常
#define MF_INDEXOPTIMIZER_LOGICOPERATOR_ERROR				 3002		//索引优化器中，逻辑运算符错误
#define MF_INDEXOPTIMIZER_COMPAREOPERATOR_ERROR				 3003		//索引优化器中，比较运算符错误
#define MF_INDEXOPTIMIZER_MATHEXPTYPE_ERROR					 3004		//索引优化器中，算数运算符类型错误
#define MF_INDEXOPTIMIZER_SUBINDEXPLANSTACK_ERROR			 3005		//索引优化器中，子索引计划栈错误
#define MF_INDEXOPTIMIZER_INDEXNUM_ERROR					 3006		//索引优化器中，索引数量错误
#define MF_INDEXOPTIMIZER_INDEXTYPE_ERROR					 3007		//索引优化器中，索引类型错误
#define MF_INDEXOPTIMIZER_INDEXCONDITION_ERROR				 3008		//索引优化器中，索引条件错误
#define MF_INDEXOPTIMIZER_GETOPTIMALINDEX_ERROR				 3009		//索引优化器中，获取最佳索引错误
//返回值
#define MF_CLUSTER_REDO_FAILED								 4080		//集群出现错误
#define MF_CLUSTER_REDO_LACK_OF_BUFFER						 4081		//集群缓存太小，需要重分配
#define MF_CLUSTER_NEW_REDO									 0			//有新的日志文件/打开新的日志文件成功
#define MF_CLUSTER_NO_NEW_REDO								 4082		//没有新的日志文件
#define MF_CLUSTER_READ_REDO_SUCCEED						 0			//读取一条执行计划成功
#define MF_CLUSTER_CURRENT_REDO_FINISH						 4083		//已读取到当前文件末尾
#define MF_CLUSTER_NO_REDO									 4084		//没有日志文件

//重作日志恢复错误
#define MF_REDO_INIT_FAILED									4100		//初始化重作日志管理结构体失败
#define MF_REDO_TIMESTAMP_LESSTHAN_ZERO						4101		//重作日志恢复时，输入的时间戳小于零
#define MF_REDO_TIMESTAMP_LESSTHAN_FIRSTONE					-33			//重作日志恢复时，输入的时间小于第一条时间戳
#define MF_REDO_REDOID_LESSEQUAL_ZERO						-32			//重作日志恢复时，日志文件编号小于等于零
#define MF_REDO_READ_SIZE_NOT_EQUAL							4103		//重作日志恢复时，读取数据的大小不对
#define MF_REDO_CHECK_GUID_FAIL								4104		//重作日志恢复时，校验数据库guid失败
#define MF_REDO_TIMESTAMP_NOT_FOUND							4105		//重作日志恢复时，找不到指定时间戳对应的记录
#define MF_REDO_NO_REDO_FILE								-34			//重作日志恢复时，没有日志文件

//更新结果错误
#define MF_UPDATERECORDSET_FIELDNOTEXIT_ERROR				 8050		//更新结果集字段值不存在
#define MF_UPDATERECORDSET_FIELDCANNOTMODIFY_ERROR			 8051		//更新结果集字段不允许修改
#define MF_UPDATERECORDSET_RECORDSETCANNOTMODIFY_ERROR		 8052	    //结果集不允许修改
#define MF_UPDATERECORDSET_INVALID_NULLFIELD_ERROR			 8054	    //结果集时非空字段为空错误
#define MF_UPDATERECORDSET_INVALID_FIELD_ERROR				 8055	    //结果集时字段异常

//导出错误
#define MF_EXPORTOBJECT_DATALEN_ERROR						 8100		//导出时数据长度错误		
#define MF_EXPORTOBJECT_DATANUM_ERROR						 8101		//导出时记录总数异常

#define MAKEHEADFLAG(a,b,c,d) (((DWORD)(a)<<0)|((DWORD)(b)<<8)|((DWORD)(c)<<16)|((DWORD)(d)<<24))
#define MF_LOG_PLANHEAD_MAGIC_FLAG                           MAKEHEADFLAG(19, 77, 2, 16)  //执行计划写入归档日志的魔法值
#define MAX_OBJECT_NUM									     256

//组合生成DATAID数据
//bFileNo文件编号，nBlockNo为块编号，nInnerNo块内编号
inline long long MakeDataID(BYTE bFileNo, int nBlockNo, int nInnerNo)
{
	long long nDataID = nBlockNo;
	nDataID = (nDataID<<8) + bFileNo;
	nDataID = (nDataID<<24) + (nInnerNo & 0XFFFFF);
	return nDataID;
}

//从DataID中获取文件编号
inline BYTE GetFileNoFromDataID(long long nDataID)
{
	return (BYTE)((nDataID>>24)&0x000000FF);
}

//从DataID中获取块编号
inline int GetBlockNoFromDataID(long long nDataID)
{
	return (int)((nDataID>>32)&0xFFFFFFFF);
}

//从DataID中获取块内编号
inline int GetInnerNoFromDataID(long long nDataID)
{
	return (int)(nDataID&0xFFFFF);
}
//将偏移量放在后四位   时间放在前四位和后四位 生成ID
inline long long MakeRollBackDataID(UINT nTimestamp, int nVarDataInsertOffset)
{
	long long nVarDataInsert = 0;
	nVarDataInsert += nTimestamp;
	nVarDataInsert += nVarDataInsert<<32;
	nVarDataInsert = nVarDataInsert & 0xFFFFFFFF00000000;
	nVarDataInsert += nVarDataInsertOffset;
	return nVarDataInsert;
}

//从RollBackDataID中获取偏移量
inline int GetRollBackOffsetID(long long nVarDataInsert)
{
	return (int)nVarDataInsert;
}

//从RollBackDataID中获取时间
inline UINT GetRollBackBlockTime(long long nVarDataInsert)
{
	return (UINT)(nVarDataInsert>>32);
}

//锁定标志
#define MF_LOCK_STATUS_TYPE                               BYTE
#define MF_LOCK_STATUS_NULL                               0    //无锁（未锁定状态）
#define MF_LOCK_STATUS_SHARE                              1    //共享锁
#define MF_LOCK_STATUS_MUTEX                              2    //互斥锁

//锁超时时间长度定义
#define MF_LOCK_OUTOFTIME                                 1000 //默认1000毫秒

//可变类型数据类型定义
#define MF_VARDATA_TYPE                                   BYTE
#define MF_VARDATA_UNKNOWN                                0   //未知数据类型
#define MF_VARDATA_INT                                    1   //32位整数类型
#define MF_VARDATA_INT64                                  2   //64位整数类型
#define MF_VARDATA_DOUBLE                                 3   //浮点数类型
#define MF_VARDATA_DATE									  4	  //日期型数据
#define MF_VARDATA_STRING                                 6   //字符串类型
#define MF_VARDATA_BINARY                                 8   //二进制类型
#define MF_VARDATA_BYTE									  9   //BYTE类型
#define MF_VARDATA_NULL									  10  //NULL类型
#define MF_VARDATA_ARRAYBIGINT							  11  //BIGINT数组
#define MF_VARDATA_ARRAYINT								  12  //INT数组
#define MF_VARDATA_MAX									  20  //最大值类型

//内存插件实现类定义
#define MF_MEMOBJECT_IMPLEMENTCLASS_TYPE                  BYTE
#define MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM                1    //系统对象实现插件
#define MF_MEMOBJECT_IMPLEMENTCLASS_COMMON                2    //通用对象实现插件
#define MF_MEMOBJECT_IMPLEMENTCLASS_HBTREE                3    //HB树对象实现插件
#define MF_MEMOBJECT_IMPLEMENTCLASS_GRAPH                 4    //图对象实现插件

//常量定义
#define MF_SYS_NUMBER_TYPE                                BYTE
#define MF_SYS_NUMBER_TYPE_INVALID                        0   //非法数字
#define MF_SYS_NUMBER_TYPE_INT                            1   //普通十进制整数
#define MF_SYS_NUMBER_TYPE_SPECIAL_INT                    2   //特殊整数，包含十六进制、或则带K、M、G、T等等
#define MF_SYS_NUMBER_TYPE_DOUBLE                         3   //浮点数
#define MF_SYS_NUMBER_TYPE_STRING						  4   //字符串
#define MF_SYS_NUMBER_TYPE_BINARY						  5	  //二进制

//系统对象定义，前100预留给系统内使用，后面再统一为每个表或索引分配一个ID值
#define MF_SYS_OBJECTTYPE                                 BYTE
#define MF_SYS_OBJECTTYPE_DUAL                            0   //系统虚拟表
#define MF_SYS_OBJECTTYPE_FILE                            1   //系统文件表
#define MF_SYS_OBJECTTYPE_OBJECT                          2   //系统对象表
#define MF_SYS_OBJECTTYPE_INDEX                           3   //系统索引表
#define MF_SYS_OBJECTTYPE_SEQUENCE                        4   //系统序列表
#define MF_SYS_OBJECTTYPE_STATISTICS                      5   //系统统计表
#define MF_SYS_OBJECTTYPE_SESSION                         6   //会话统计表
#define MF_SYS_OBJECTTYPE_SOAPSERVER                      7   //Soap服务统计表
#define MF_SYS_OBJECTTYPE_USERINFO                        8   //用户信息表
#define MF_SYS_OBJECTTYPE_AUTHORITY                       9   //权限表
#define MF_SYS_OBJECTTYPE_FIELD	                          10  //字段信息表
#define MF_SYS_OBJECTTYPE_WORKLOAD                        11  //服务工作量统计表

//文件类型定义
#define MF_SYS_FILETYPE                                   BYTE
#define MF_SYS_FILETYPE_SYSFILE                           1   //系统文件
#define MF_SYS_FILETYPE_DATAFILE                          2   //数据文件
#define MF_SYS_FILETYPE_TREEINDEXFILE                     3   //树索引文件
#define MF_SYS_FILETYPE_KVINDEXFILE                       4   //KV索引文件
#define MF_SYS_FILETYPE_HBTREEINDEXFILE					  5   //二叉树索引文件
//数据类型定义
#define MF_SYS_FIELDTYPE                                  BYTE
#define MF_SYS_FIELDTYPE_UNKNOWN                          0   //未知类型
#define MF_SYS_FIELDTYPE_INT                              1   //整数型(32位有符号)
#define MF_SYS_FIELDTYPE_BIGINT                           2   //大整数型(64位有符号)
#define MF_SYS_FIELDTYPE_DOUBLE                           3   //浮点数(日期型)
#define MF_SYS_FIELDTYPE_DATE                             4   //日期型数据
#define MF_SYS_FIELDTYPE_CHAR                             5   //固定长度字符串(最大支持32KB)
#define MF_SYS_FIELDTYPE_VARCHAR                          6   //变化长度字符串(最大支持32KB)
#define MF_SYS_FIELDTYPE_CLOB                             7   //大字符串(最大支持2GB)
#define MF_SYS_FIELDTYPE_BLOB                             8   //二进制(最大支持2GB)
#define MF_SYS_FIELDTYPE_NULL				              10  //空字段类型
#define MF_SYS_FIELDTYPE_ARRAYBIGINT					  11  //BIGINT数组
#define MF_SYS_FIELDTYPE_ARRAYINT						  12  //INT数组
#define MF_SYS_FIELDTYPE_ROWNUM				              13  //ROWNUM字段类型

//索引类型定义
#define MF_SYS_INDEXTYPE                                  BYTE
#define MF_SYS_INDEXTYPE_ROWID                            0   //ROWID索引
#define MF_SYS_INDEXTYPE_KV_INT                           1   //整数型KV索引
#define MF_SYS_INDEXTYPE_KV_BIGINT                        2   //大整数型KV索引
#define MF_SYS_INDEXTYPE_KV_DOUBLE                        3   //浮点数、日期类型KV索引
#define MF_SYS_INDEXTYPE_KV_CHAR                          4   //固定长度字符串KV索引
#define MF_SYS_INDEXTYPE_HB_INT		                      5   //二叉树整型索引（主要用于ML目录结构）
#define MF_SYS_INDEXTYPE_HB_CHAR	                      6   //二叉树字符串型索引（主要用于ML目录结构）
#define MF_SYS_INDEXTYPE_TREE_INT                         11  //整数型B树索引
#define MF_SYS_INDEXTYPE_TREE_BIGINT                      12  //大整数型B树索引
#define MF_SYS_INDEXTYPE_TREE_DOUBLE                      13  //浮点数、日期类型B树索引
#define MF_SYS_INDEXTYPE_TREE_MULTINUM                    14  //复合索引(不含字符串)
#define MF_SYS_INDEXTYPE_TREE_MULTISTR					  15  //复合索引(含字符串)
#define MF_SYS_INDEXTYPE_FUZZY_CHAR                       16  //字符串模糊查询索引

#define MF_SYS_INDEXTYPE_FULL_OBJECT                      30  //全表遍历，作为一种特殊索引

//参数字段类型定义
#define MF_PARAMETER_FIELDTYPE                                  BYTE
#define MF_PARAMETER_FIELDTYPE_ORIGINAL                   1   //对象原始字段
#define MF_PARAMETER_FIELDTYPE_COMMFUN					  2   //普通函数
#define MF_PARAMETER_FIELDTYPE_AGGREFUN                   3   //聚合函数
#define MF_PARAMETER_FIELDTYPE_EXPRESSION                 4   //表达式字段

//文件操作命令
#define MF_SYS_FILECMD                                    BYTE
#define MF_SYS_FILECMD_NONE                               0   //无需任何处理
#define MF_SYS_FILECMD_NEWFILE                            1   //新建内存数据文件
#define MF_SYS_FILECMD_CHANGEFILEPATH                     2   //修改内存数据文件路径
#define MF_SYS_FILECMD_CHANGEFILESIZE                     3   //修改内存数据文件大小
#define MF_SYS_FILECMD_DROPFILE                           4   //删除内存数据文件

//条件数据类型定义
#define MF_COND_FIELDTYPE                                 BYTE
#define MF_COND_FIELDTYPE_INT                             1   //整数型(32位有符号)
#define MF_COND_FIELDTYPE_BIGINT                          2   //大整数型(64位有符号)
#define MF_COND_FIELDTYPE_DOUBLE                          3   //浮点数(日期型)
#define MF_COND_FIELDTYPE_CHAR                            4   //固定长度字符串(最大支持32KB)

//执行计划命令类型
#define MF_EXECUTEPLAN_CMDTYPE                            BYTE
#define MF_EXECUTEPLAN_CMDTYPE_QUERY                      1   //查询命令
#define MF_EXECUTEPLAN_CMDTYPE_INSERT                     2   //插入命令
#define MF_EXECUTEPLAN_CMDTYPE_UPDATE                     3   //修改命令
#define MF_EXECUTEPLAN_CMDTYPE_DELETE                     4   //删除命令
#define MF_EXECUTEPLAN_CMDTYPE_UPDATERECORDSET            5   //删除命令

//对象修改命令
#define MF_EXECUTEPLAN_CMDTYPE_ALTER                      32   //对象修改命令
#define MF_EXECUTEPLAN_CMDTYPE_CREATE                     33   //对象创建命令
#define MF_EXECUTEPLAN_CMDTYPE_DROP                       34   //对象删除命令

//执行计划中的数据结构类型定义
#define MF_EXECUTEPLAN_OBJECTTYPE                         BYTE
#define MF_EXECUTEPLAN_OBJECTTYPE_OBJECT                  1   //数据对象
#define MF_EXECUTEPLAN_OBJECTTYPE_SEQUECNE                2   //序列数据
#define MF_EXECUTEPLAN_OBJECTTYPE_USER		              3   //序列数据
//执行计划中修改的类型定义
#define MF_EXECUTEPLAN_ALTERTYPE                          BYTE
#define MF_EXECUTEPLAN_ALTERTYPE_ADD_FIELD                0   //添加字段
#define MF_EXECUTEPLAN_ALTERTYPE_DROP_FIELD               1   //删除字段
#define MF_EXECUTEPLAN_ALTERTYPE_ADD_INDEX                2   //添加索引
#define MF_EXECUTEPLAN_ALTERTYPE_DROP_INDEX               3   //删除索引
#define MF_EXECUTEPLAN_ALTERTYPE_ADD_DBFILE               4   //添加数据文件
#define MF_EXECUTEPLAN_ALTERTYPE_DROP_DBFILE              5   //删除数据文件
#define MF_EXECUTEPLAN_ALTERTYPE_MODIFY_DBFILE            6   //修改数据文件
#define MF_EXECUTEPLAN_ALTERTYPE_SET_PARAMETER            7   //设置系统参数
#define MF_EXECUTEPLAN_ALTERTYPE_ADD_AUTHORITY            8   //添加用户权限
#define MF_EXECUTEPLAN_ALTERTYPE_DROP_AUTHORITY           9   //删除用户权限
#define MF_EXECUTEPLAN_ALTERTYPE_CHANGE_PASSWORD          10  //修改用户密码
#define MF_EXECUTEPLAN_ALTERTYPE_DISABLE_USER             11  //启动用户
#define MF_EXECUTEPLAN_ALTERTYPE_ENABLE_USER              12  //停止用户

#define MF_EXECUTEPLAN_ALTERTYPE_OBJECT				      1
#define MF_EXECUTEPLAN_ALTERTYPE_SYSTEM                   2
#define MF_EXECUTEPLAN_ALTERTYPE_USER					  3
//数学运算符类型
#define MF_EXECUTEPLAN_OPERATORTYPE
#define MF_EXECUTEPLAN_OPERATORTYPE_UNKNOWN               0   //不是运算符
#define MF_EXECUTEPLAN_OPERATORTYPE_SINGLE				  1   //单目运算符
#define MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE                2   //双目运算符
#define MF_EXECUTEPLAN_OPERATORTYPE_MINUS                 3   //"-"号，同时兼容单目运算符和双目运算符#define MF_EXECUTEPLAN_OPERATORTYPE_MINUS                
#define MF_EXECUTEPLAN_OPERATORTYPE_PRIOR                 4   //PRIOR符号
#define MF_EXECUTEPLAN_OPERATORTYPE_INVALID               5   //非法运算符

//数学运算符
#define MF_EXECUTEPLAN_OPERATOR                           BYTE
#define MF_EXECUTEPLAN_OPERATOR_NULL                      0   //不做任何运算，相当于直接赋值
#define MF_EXECUTEPLAN_OPERATOR_PLUS                      1   //加运算，相当于SQL的+运算符
#define MF_EXECUTEPLAN_OPERATOR_MINUS                     2   //减运算，相当于SQL的-运算符
#define MF_EXECUTEPLAN_OPERATOR_MULTIPLY                  3   //乘运算，相当于SQL的*运算符
#define MF_EXECUTEPLAN_OPERATOR_DIVIDE                    4   //除运算，相当于SQL的/运算符
#define MF_EXECUTEPLAN_OPERATOR_LINK                      5   //字符串拼接运算，相当于SQL的||运算符
#define MF_EXECUTEPLAN_OPERATOR_LIKE					  6   //字符串匹配运算符
#define MF_EXECUTEPLAN_OPERATOR_IN                        7   //集合运算，相当于SQL的IN运算
#define MF_EXECUTEPLAN_OPERATOR_NOTIN                     8   //集合运算，相当于SQL的NOT IN运算

#define MF_EXECUTEPLAN_OPERATOR_EQUAL                     10  //==
#define MF_EXECUTEPLAN_OPERATOR_NOTEQUAL                  11  //<>
#define MF_EXECUTEPLAN_OPERATOR_GREATER                   12  //>
#define MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL              13  //>=
#define MF_EXECUTEPLAN_OPERATOR_LESS                      14  //<
#define MF_EXECUTEPLAN_OPERATOR_LESSEQUAL                 15  //<=
#define MF_EXECUTEPLAN_OPERATOR_BETWEEN                   16  //BETWEEN   >=和<=
#define MF_EXECUTEPLAN_OPERATOR_BETWEENB				  17  //BETWEENB  >和<=
#define MF_EXECUTEPLAN_OPERATOR_BETWEENE                  18  //BETWEENE  >=和<
#define MF_EXECUTEPLAN_OPERATOR_BETWEENBE                 19  //BETWEENBE >和<
#define MF_EXECUTEPLAN_OPERATOR_PRIOR                     20  //PRIOR
#define MF_EXECUTEPLAN_OPERATOR_LPRIOR                    21  //PRIOR在等号左边
#define MF_EXECUTEPLAN_OPERATOR_RPRIOR                    22  //PRIOR在等号右边

#define MF_EXECUTEPLAN_OPERATOR_AND						  31  //AND
#define MF_EXECUTEPLAN_OPERATOR_OR                        32  //OR
#define MF_EXECUTEPLAN_OPERATOR_NOT						  33  //NOT
#define MF_EXECUTEPLAN_OPERATOR_SIGNMINUS                 34  //负号

//聚合函数40~49
#define MF_EXECUTEPLAN_OPERATOR_COUNT					  40  //COUNT函数	

//普通函数50~59
#define MF_EXECUTEPLAN_OPERATOR_SYSDATE					  50  //SYSDATA函数		
#define MF_EXECUTEPLAN_OPERATOR_SEQUENCE                  51  //序列
#define MF_EXECUTEPLAN_OPERATOR_NEXTVAL					  52  //NEXTVAL函数	
#define MF_EXECUTEPLAN_OPERATOR_CURRVAL					  53  //CURRVAL函数	
#define MF_EXECUTEPLAN_OPERATOR_TOCHAR				      54  //TO_CHAR函数
#define MF_EXECUTEPLAN_OPERATOR_TODATE				      55  //TO_DATE函数
#define MF_EXECUTEPLAN_OPERATOR_CHECKCHILD				  56  //CHECKCHILD函数
#define MF_EXECUTEPLAN_OPERATOR_SHORTESTPATH			  57  //SHORTESTPATH函数

#define MF_EXECUTEPLAN_OPERATOR_LEFTBRACKET				  70  //左括号
#define MF_EXECUTEPLAN_OPERATOR_RIGHTBRACKET			  71  //右括号

//查询条件类型
#define MF_CONDITION_TYPE								  BYTE
#define MF_CONDITION_COMPARE							  0	  //比较表达式		
#define MF_CONDITION_LOGIC								  1	  //逻辑表达式
#define MF_CONDITION_ROWNUM								  2	  //ROWNUM达式
#define MF_CONDITION_INVALID							  3   //无效表达式

//TCP连接命令定义
#define MF_INTERFACE_TCPCOMMAND                           BYTE
#define MF_INTERFACE_TCPCOMMAND_TEST                      0  //测试连接是否可用命令
#define MF_INTERFACE_TCPCOMMAND_OK                        1  //回复结果为成功
#define MF_INTERFACE_TCPCOMMAND_FAIL                      2  //回复结果为失败
#define MF_INTERFACE_TCPCOMMAND_DISCONNECT                3  //断开连接命令
#define MF_INTERFACE_TCPCOMMAND_EXECUTECOMMAND            5  //调SQL执行命令
#define MF_INTERFACE_TCPCOMMAND_GETRECORDSET              6  //检索执行命令
#define MF_INTERFACE_TCPCOMMAND_UPDATERECORDSET           7  //更新结果集命令
#define MF_INTERFACE_TCPCOMMAND_STARTTRANSACTIONLOGIC     8  //开始短事务锁
#define MF_INTERFACE_TCPCOMMAND_STOPTRANSACTIONLOGIC      9  //结束短事务锁
#define MF_INTERFACE_TCPCOMMAND_GETEXECUTEPLANINFO	      10 //获取执行计划


#define MF_INTERFACE_COMMAND_USERLOGIN					  20 //用户登录
#define MF_INTERFACE_COMMAND_USERLOGOUT					  21 //用户登录

#define MF_INTERFACE_TCPCOMMAND_EXPORTOBJECT              80 //对象导出
#define MF_INTERFACE_TCPCOMMAND_IMPORTOBJECT              81 //对象导入

#define MF_DEFAULT_BUFFER_SIZE								8388608		//8MB，定义一个常量，用于new临时buffer大小，方便统一改动


//日志体系定义
#define MF_TRACE_FILE_SIZE                                4194304 //日志共享内存暂时定义为4MB
#define MF_TRACE_FILE_WORNING_SIZE                        1048576 //日志共享空间剩余小于1MB时就应该提醒服务写文件
#define MF_TRACE_FILE_WORNING_SIZEEX                      3145728 //日志共享空间剩余小于1MB时就应该提醒服务写文件
#define MF_TRACE_FILE_TRACENAME                           _T("Global\\MemDBSysTraceFile") //系统日志文件名
#define MF_TRACE_FILE_TRACEEVENT                          _T("Global\\MemDBSysTraceEvent")//系统日志事件名
#define MF_TRACE_FILE_LOGNAME                             _T("Global\\MemDBSysLogFile")   //操作日志文件名
#define MF_TRACE_FILE_LOGEVENT                            _T("Global\\MemDBSysLogEvent")  //操作日志事件名

#define MF_TRACE_FILE_TRACE_KEY									 (0x53425452)		//"S"+"B"+"T"+"R"
#define MF_TRACE_FILE_LOG_KEY								     (0x53424C4F)		//"S"+"B"+"L"+"O"
#define MF_STORAGEMEM_FILE_KEY									 (0x5342534D)		//"S"+"B"+"S"+"M"
#define ME_TEMPORARYMEM_KEY										 (0x5342544D)		//"S"+"B"+"T"+"M"
#define MF_MEMFILE_BASEKEY							 		   	 (0x53424600)		//"S"+"B"+"F"+id

//日志等级定义
#define MF_TRACE_LEVEL_FAILED                             1 //出现严重错误，剩余逻辑没执行完的，是用于通常的失败报错情况
#define MF_TRACE_LEVEL_ERROR                              2 //出现逻辑错误
#define MF_TRACE_LEVEL_IMPORTANT_INFORMATION              3 //非常重要信息，比如服务启动之类的
#define MF_TRACE_LEVEL_WARNING                            4 //严重警告，可能导致系统故障

#define MF_TRACE_LEVEL_INNER_EFFICIENCYLOG                20 //调试信息，函数执行效率的日志，主要是执行时间
#define MF_TRACE_LEVEL_INNER_DEBUG                        21 //调试信息，包括主要函数的参数

#define MF_DEF_ALLOC_SIZE	1024

//表达式类型
#define MF_EXPRESSIONTYPE								   BYTE
#define MF_EXPRESSION_UNKNOWN							   0    //未知表达式类型
#define MF_EXPRESSION_FIELD								   1    //单字段表达式
#define MF_EXPRESSION_COMMFUN                              2    //常规函数表达式
#define MF_EXPRESSION_AGGREFUN							   3    //聚合函数表达式
#define MF_EXPRESSION_CONSTMATH							   4    //常量表达式(可以根据表达式本身直接计算出表达式值(如不包含字段名和聚合函数的表达式))
#define MF_EXPRESSION_VARMATH							   5    //变量四则运算表达式
#define MF_EXPRESSION_AGGREMATH							   6    //集合表达式(IN,NOTIN)

//表达式字段值类型
#define MF_COMPATIBLE_DATATYPE					           BYTE  //数据兼容类型
#define MF_COMPATIBLE_DATA_UNKNOWN						   0	 //未知类型
#define MF_COMPATIBLE_DATA_NUMBER					       1     //数字型
#define MF_COMPATIBLE_DATA_STRING                          2     //字符串型
#define MF_COMPATIBLE_DATA_BYTE                            3     //BYTE型
#define MF_COMPATIBLE_DATA_BINARY                          4     //二进制型
#define MF_COMPATIBLE_DATA_NULL						       5     //空类型
#define MF_COMPATIBLE_DATA_ALL						       6     //所有类型

//检索转义字符定义
#define MF_OPERATOR_PERCENT								   1	 //百分号定义“%”，实现无限个字符的匹配
#define MF_OPERATOR_UNDERLINE							   2	 //下划线定义“_”，实现一个字符的匹配

#define MF_OPERATOR_ERROR_SLASH							   1651 //匹配字符串末尾有单独的转义符'\'

//系统全局参数宏定义
#define MF_PARAMETER_TYPE                                  int
#define MF_PARAMETER_UNKNOWN     						   0      //未知参数类型
#define MF_SERVICE_PORT								       1      //Web Service的监听端口，默认为8080；
#define MF_SERVICE_WORKERS							       2      //Web Service的服务线程数量，默认为10 ；
#define MF_TCP_LISTEN_IP							       3      //TCP监听IP地址，默认为0，表示不绑定网卡；
#define MF_TCP_LISTEN_PORT							       4      //TCP监听端口，默认为8000；
#define MF_TCP_TIMEOUT								       5      //TCP发送及接收数据超时时间，默认为60秒；
#define MF_SERVER_TRACE_LEVEL						       6      //系统日志等级，默认为10；
#define MF_SERVER_EFFICIENCY_TRACE					       7      //系统效率日志，默认为0；
#define MF_SERVER_PARALLELMODE						       8      //并行模式，0：读写互不影响，1：串行方式执行；
#define MF_SERVER_WRITE_UNDOMODE					       9      //写重做日志模式(默认为1)，0：不写，1：写
#define MF_SERVER_EXECUTETIME_MONITOR				       10     //执行时间监控，用于改善SQL性能，默认100毫秒
#define MF_SERVER_CASE_SENSITIVE					       11     //字符串大小写是否敏感，0为不敏感、1为敏感，默认为0；
#define MF_MEMORY_TEMPORARY_SIZE					       12     //临时内存大小(大量数据检索使用)，单位为MB，默认48
#define MF_MEMORY_UNDO_SIZE							       13     //重做内存大小，用于数据回滚或一致性读取使用，默认48MB；
#define MF_MEMORY_PROCESS_SIZE						       14     //处理线程私有内存大小，处理与客户端通讯，默认2MB ；
#define MF_MEMORY_PLAN_REMAINSIZE					       15     //执行计划空间大小，默认10KB；
#define MF_MEMORY_SQLPLAN_MAXSIZE					       16     //SQL执行计划最大大小，默认10MB；
#define MF_MEMORY_RECORDSETPLAN_MAXSIZE				       17     //结果集执行计划最大大小，默认500MB；
#define MF_WRITE_FILE_DELAY_TIME					       18     //写文件延迟时间，默认为3秒；
#define MF_WRITE_UNDO_DELAY_TIME					       19     //写重做日志文件延迟时间，默认为3秒；
#define MF_WRITE_TRACE_DELAY_TIME					       20     //写日志文件延迟时间，默认为3秒；
#define MF_WRITE_UNDO_MAX_SIZE						       21     //重做日志文件大小
#define MF_WRITE_TRACE_MAX_SIZE						       22     //操作日志文件大小
#define MF_BLOCK_DATA_SIZE							       23     //数据块的大小，默认为1MB；
#define MF_BLOCK_BTREE_INDEX_SIZE					       24     //B树索引块大小，默认为32KB；
#define MF_BLOCK_BTREE_DATA_SIZE					       25     //B树数据块大小，默认为32KB(必需为索引块的整数倍)；
#define MF_BLOCK_HASH_INDEX_SIZE					       26     //HASH索引块大小，默认为256KB；
#define MF_BLOCK_HASH_INDEX_CHAIN_MAXSIZE			       27     //哈希索引链最大长度，超过此长度就自动增加哈希的基础槽位长度，默认为8；
#define MF_BLOCK_HASH_INDEX_EXPAND_RATIO			       28     //哈希索引的基础槽位膨胀率，默认为4；
#define MF_BLOCK_USED_RATIO							       29     //数据块使用率，达到此值表示块已经写满，默认为80；
#define MF_BLOCK_INSERT_MAXUSE_RATIO                       30     //插入数据最大使用率，超过此值不允许继续插入，默认为90；
#define MF_BLOCK_FREE_RATIO							       31     //数据块剩余率，删除数据后剩余数据率低于此值可再用，默认为40；
#define MF_BLOCK_REORGANIZE_RATIO					       32     //数据块整理率，达到此值时引起块内整理预判，默认为80；
#define MF_BLOCK_RECYCLE_RATIO						       33     //数据块回收率，达到此值时进行数据整理重组，默认为10；
#define MF_BLOCK_INDEX_DIVIDE_MODE					       34     //索引分裂方式，1：表示按照一半的方式进行分裂，2：表示按照九比一的比率分裂，3：表示按照一比九的比率分裂；
#define MF_OBJECT_TRANSACTION_MAXNUM					   35     //对象所支持的最大事务数
#define MF_TRANSACTION_LOGIC_SLOT_COUNT					   36     //短事务锁槽位数量，默认100
#define MF_TRANSACTION_LOGIC_TIMEOUT					   37     //短事务锁有效时间，单位为秒，默认60秒
#define MF_ACTIVE_LOG_FILES									38		//活动重做日志数量，默认20
#define MF_PERSISTENCE_INTERVALS							39		//持久化时间间隔（单位：秒），按照事务完成进行持久化处理，默认3

//#define MF_PARAMETER_TYPE_MAX_COUNT                        52     //参数最大个数
#define MF_PARAMETER_TYPE_MAX_COUNT                        64     //参数最大个数


#define MF_SYS_BLOCKSIZE									262144	//系统表的块大小定义，目前暂时定为256KB
#define MF_SYS_BLOCKFREESIZE								52428	//系统块保留空余空间，目前只有保存OBJECT对象的块需要这样处理，其他的目前按照空余2048字节即可
#define MF_TRACE_BUFFER_SIZE								512     //日志格式化Buffer

#define MF_WHERECONDITION_TYPE							   BYTE
#define MF_WHERECONDITION_OTHER							   0	  //其他类型
#define MF_WHERECONDITION_IN							   1	  //IN类型

//指定数据位置
#define MF_DATAPOSITION									   BYTE
#define MF_DATAPOSITION_UNKNOWN							   0
#define MF_DATAPOSITION_LOCAL							   1      //本地数据
#define MF_DATAPOSITION_ROLLBACK						   2      //回滚区数据

//执行计划步骤
#define MF_EXECUTE_STEP									   BYTE
#define MF_EXECUTE_STEP_LOCKSOURCE		                   1	   //资源上锁
#define MF_EXECUTE_STEP_QUERYDATA						   2	   //查询数据
#define MF_EXECUTE_STEP_INSERTDATA						   3       //插入数据
#define MF_EXECUTE_STEP_DELETEDATA                         4       //删除数据
#define MF_EXECUTE_STEP_UPDATEDATA                         5       //更新数据
#define MF_EXECUTE_STEP_INSERTINDEX                        6       //插入索引
#define MF_EXECUTE_STEP_DELETEINDEX                        7       //删除索引
#define MF_EXECUTE_STEP_UPDATEINSERTINDEX                  8       //更新时插入索引
#define MF_EXECUTE_STEP_UPDATEDELETEINDEX                  9       //更新时删除索引

#define MF_EXECUTE_STEP_INSERTHBTREE                       10       //插入索引
#define MF_EXECUTE_STEP_DELETEHBTREE                       11      //删除索引
#define MF_EXECUTE_STEP_UPDATEHBTREE                       12      //更新索引

#define MF_EXECUTE_STEP_CREATERELATION					   13      //建立关系
#define MF_EXECUTE_STEP_DELETERELATION  				   14      //删除关系
#define MF_EXECUTE_STEP_DELETENODE  					   15      //删除节点

//文件类型
#define MF_FILE_TYPE									   BYTE
#define MF_FILE_TYPE_UNKNOWN							   0
#define MF_FILE_TYPE_DIRECTORY							   1
#define MF_FILE_TYPE_OTHERS								   2

//约束类型CONSTRAINT
#define MF_CONSTRAINT_TYPE								   BYTE
#define MF_CONSTRAINT_NORMAL							   0        //普通约束
#define MF_CONSTRAINT_PRIMARYKEY					       1		//主键
#define MF_CONSTRAINT_UNIQUE							   2		//唯一索引

//查询类型定义
#define MF_QUERY_TYPE									   BYTE
#define MF_QUERY_NULL									   0	//空结果集(如where 1 = 2)
#define MF_QUERY_COUNTALL								   1	//COUNT(*)条件
#define MF_QUERY_NORMAL									   2    //普通查询
#define MF_QUERY_GRAPH									   3    //图查询
#define MF_QUERY_GRAPH_NULLNODE							   4    //不限制节点条件的图查询

//分页类型
#define MF_PAGING_TYPE									   BYTE
#define MF_PAGING_NULL									   0	//未分页
#define MF_PAGING_FIRST									   1	//FIRST模式
#define MF_PAGING_NORMAL							       2	//常规模式

//内存通信内存文件定义
#define MF_STORAGEMEM_FILE_NAME							_T("Global\\StorageMemFile")
#define MF_STORAGEMEM_FILE_SIZE							3145728				//3*1024*1024，3MB
#define MF_STORAGEMEM_BLOCK_SIZE						1048576				//1mb offset
														//文件头信息大小fhs；fhs~(fhs+1)mb，闪回块数据用（大小1mb）；(fhs+1)~(fhs+2)mb，备份文件头数据用（大小1mb）
typedef struct 
{
	int		m_nBufferSize;
	int		m_nStartOffset;
	int		m_nEndOffset;
}REDOBUFFERPOS, *LPREDOBUFFERPOS;

//内存通信指令定义
#define MF_STORAGEMEM_TYPE									BYTE
#define MF_STORAGEMEM_COMMAND_NO							0		//无命令，未使用
#define MF_STORAGEMEM_COMMAND_FLASHBACK						2		//调用闪回（持久化中可使用）
#define MF_STORAGEMEM_COMMAND_COPYMAP						3		//备份映射表（持久化中可使用）


//数据库类型(前32预留给系统)
#define MF_DATABASE_TYPE									BYTE
#define MF_DATABASE_MEMDB									0	//内存数据库
#define MF_DATABASE_FAIL									233

//执行计划缓存片段大小
#define MF_BUFFERSECTION_SIZE								8192		//缓存片段大小
#define MF_RECYCLESECTION_SIZE								16384		//循环缓存大小
#define MF_TEMPBUFFER_SIZE									16384		//临时缓存大小
#define MF_RECORDBUFFER_SIZE								16384		//记录缓存大小

//块来源类型
#define MF_BLOCK_SOURCE										BYTE
#define MF_SOURCE_FROM_EXISTBLOCK							1
#define MF_SOURCE_FROM_FREEBLOCK							2
#define MF_SOURCE_FROM_FREEMEMORY							3

//锁类型
#define MF_LOCK_TYPE										BYTE
#define MF_LOCK_INDEX										1			 //索引锁		
#define MF_LOCK_BLOCK										2			 //块锁		

//对象类型
#define MF_OBJECT_TYPE										BYTE
#define MF_OBJECT_COMMON									1			 //普通对象

//记录类型
#define MF_RECORD_TYPE										BYTE		 //图对象类型
#define MF_RECORD_COMMON									1			 //通用类型
#define MF_RECORD_HBTREE									2			 //HB树类型
#define MF_RECORD_NODE										3			 //节点类型
#define MF_RECORD_RELATION									4			 //关系类型

//权限类型
#define MF_AUTHORITY_ID										BYTE		 //权限类型
#define MF_AUTHORITY_DBA								    1			 //管理员权限
#define MF_AUTHORITY_ALTERSYSTEM							2			 //系统修改权限
#define MF_AUTHORITY_CREATEOBJECT							3			 //创建对象表权限
#define MF_AUTHORITY_ALTEROBJECT							4			 //修改对象表权限
#define MF_AUTHORITY_DROPOBJECT								5			 //删除对象表权限
#define MF_AUTHORITY_CREATESEQUENCE							6			 //创建序列权限
#define MF_AUTHORITY_DROPSEQUENCE							7			 //删除序列权限

//执行计划中块信息的最大数量
#define MF_MAX_BLOCKINFO_NUM								20

//记录段中字段数量
#define MF_RECORDSECTION_FIELDNUM							4			//记录段中字段数量	

//数据片段数组类型
#define MF_RECORDSECTIONARRAY_TYPE							BYTE		
#define MF_RECORDSECTIONARRAY_BYTE							1			//BYTE型数组
#define MF_RECORDSECTIONARRAY_SHORT							2			//SHORT型数组
#define MF_RECORDSECTIONARRAY_INT							3			//INT型数组

//查询计划的类型
#define MF_QUERYPLAN_TYPE									BYTE
#define MF_QUERYPLAN_ALL									1			//全表遍历
#define MF_QUERYPLAN_INDEX									2			//全索引遍历，覆盖索引
#define MF_QUERYPLAN_RANGE_BTREE							3			//B树范围查询
#define MF_QUERYPLAN_RANGE_KV								4			//KV范围查询

//方向
#define MF_DIRECTION_TYPE									BYTE
#define MF_DIRECTION_NULL									0			//无方向
#define MF_DIRECTION_POSITIVE								1			//正方向
#define MF_DIRECTION_NEGATIVE								2			//反方向

#pragma pack(1)
//用于管理一个Object的所有块
typedef struct 
{
	int			m_nID;												      //对象ID
	long long	m_nFullBlockMapOffset;								      //同相同Object的所有块组成成的链表，指向FILEBLOCKMAP结构体地址
	long long	m_nFreeBlockMapOffset;								      //可插数据块组成链表，指向FILEBLOCKMAP结构体地址 
	long long	m_nFinishedTimestamp;								      //修改完成时间戳，指内存服务中已经提交的时间戳
	long long	m_nPersistentTimestamp;									  //数据持久化时间戳，指当前已经写入磁盘的数据时间戳
	long long	m_nRecordNum;										      //一个Object的记录数
	BYTE		m_bReserved[4];										      //保留数据
}BASEFILEOBJECTDEF, *LPBASEFILEOBJECTDEF;

//文件头基础定义
typedef struct 
{
	int                 m_nDataFlag;                                   //数据标志，目前系统文件为‘SBSF’、数据文件为‘SBDF’、B树索引文件为‘SBBF’、KV树索引文件为‘SBHF’
	long long           m_nTimestamp;                                  //文件保存的时间戳
	BYTE                m_bFileNo;                                     //文件编号
	BYTE                m_bStatus;                                     //内存文件数据锁定状态
	USHORT				m_usDatabaseGuid;							   //数据库唯一标识
	long long           m_nFileTotalSize;                              //文件总大小
	int                 m_nFileHeaderSize;                             //文件头大小
	int                 m_nBlockNum;                                   //块个数
	int                 m_nBlockMapStructSize;                         //块地址映射表中表项的长度，实际为FILEBLOCKMAP结构体大小
	int                 m_nBlockMapStartOffset;                        //指向第一个FILEBLOCKMAP结构体的地址
	long long	        m_nBlockStartOffset;                           //块的起始地址
	BASEFILEOBJECTDEF   m_stuObjectDef[MAX_OBJECT_NUM];	    		   //不同类型索引的块的入口地址数组
}BASEFILEHEAD, *LPBASEFILEHEAD;

//数据文件头基础定义
typedef struct 
{
	int                 m_nDataFlag;                                   //数据标志，目前系统文件为‘SBSF’、数据文件为‘SBDF’、B树索引文件为‘SBBF’、KV树索引文件为‘SBHF’
	long long           m_nTimestamp;                                  //文件保存的时间戳
	BYTE                m_bFileNo;                                     //文件编号
	BYTE                m_bStatus;                                     //内存文件数据锁定状态
	USHORT				m_usDatabaseGuid;							   //数据库唯一标识
	long long           m_nFileTotalSize;                              //文件总大小
	int                 m_nFileHeaderSize;                             //文件头大小
	int                 m_nBlockNum;                                   //块个数
	int                 m_nBlockMapStructSize;                         //块地址映射表中表项的长度，实际为FILEBLOCKMAP结构体大小
	int                 m_nBlockMapStartOffset;                        //指向第一个FILEBLOCKMAP结构体的地址
	long long	        m_nBlockStartOffset;                           //块的起始地址
	BASEFILEOBJECTDEF   m_stuObjectDef[MAX_OBJECT_NUM];	    		   //不同类型索引的块的入口地址数组
	BASEFILEOBJECTDEF	m_stFileRelationData[MAX_OBJECT_NUM];		   //关系对象数据表
}BASEDATAFILEHEAD, *LPBASEDATAFILEHEAD;

//块映射表结点定义
typedef struct
{
	int					  m_nBlockNo;                                   //块号
	long long             m_nBlockOffset;                               //块偏移位置，使用m_pFileBodyAddr地址加上此值就是块的偏移地址，一般情况下只有初始化才需要此地址
	long long             m_nNextOffset;                                //下一个同类型的块的偏移量，指向的是下一个FILEBLOCKMAP结果体地址
}BASEFILEBLOCKMAP, *LPBASEFILEBLOCKMAP;

//块映射表头定义
typedef struct
{
	int					m_nBlockMapNum;								   //映射表中结点数量
	BYTE				m_bReserved[4];								   //保留字段
	long long			m_nNextBlockMapOffset;						   //下一个映射表偏移
	BASEFILEBLOCKMAP	m_pBlockMap[1];								   //映射表数组
}BASEFILEBLOCKMAPHEAD, *LPBASEFILEBLOCKMAPHEAD;

//块头基础定义
typedef struct 
{
	int                 m_nDataFlag;                                   //数据标志，目前数据块为‘SBDB’
	int                 m_nBlockNo;                                    //块号(新插入块的编号 = 最大块号+1)
	long long           m_nTimestamp;                                  //时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
	int                 m_nBlockSize;                                  //块大小
	int                 m_nBlockHeadSize;                              //块头大小
	BYTE                m_bStatus;                                     //数据锁定状态，一般修改单条数据不需要整块锁，但如果整块进行整理时就必须进行锁定，防止其他读取或者修改操作出现错乱
	BYTE                m_bFileNo;                                     //文件编号
	BYTE                m_bSaveFlag;                                   //数据库保存标志，防止单纯按照时间戳判断出现误判
	BYTE                m_bThreadNum;                                  //共享线程数
}BASEBLOCKHEAD, *LPBASEBLOCKHEAD;

//系统文件头定义
typedef struct
{
	int                 m_nDataFlag;                                   //数据标志，目前系统文件为‘SBSF’
	long long           m_nTimestamp;								   //文件保存的时间戳
	BYTE                m_bFileNo;                                     //文件编号
	BYTE                m_bStatus;                                     //内存文件数据锁定状态，0：正常状态、1：文件加载状态、2：文件禁止访问状态
	USHORT				m_usDatabaseGuid;							   //数据库唯一标识
	long long           m_nFileTotalSize;                              //文件总大小
	int                 m_nFileHeaderSize;                             //文件头大小
	int                 m_nBlockNum;                                   //块个数
	int                 m_nBlockMapStructSize;                         //块地址映射表中表项的长度，实际为FILEBLOCKMAP结构体大小
	int                 m_nBlockMapStartOffset;                        //指向第一个FILEBLOCKMAP结构体的地址
	long long	        m_nBlockStartOffset;                           //块的起始地址
	BASEFILEOBJECTDEF   m_stuFileObjectData[256];                      //系统文件对象数据表

	long long           m_nFileFreeSize;                               //空闲区大小
	long long           m_nFileFreePos;                                //空闲空间首地址
	int	            	m_nInnerMaxNo;                                 //块编号最大值，用于插入时
	int                 m_nObjectMaxID;                                //对象最大ID，用于添加新OBJECT或索引时使用，前面100为系统预留，所以此值初始值为100
	BYTE                m_bFileMaxNo;                                  //文件编号最大值，用于新加数据文件使用，注意编号为1的表示系统文件
	BYTE                m_bSysTimeChange;                              //系统时间变化，0表示完全正常，1表示时间大幅度向后改变，2、表示时间向前改变
	BYTE                m_bFileCMD;                                    //发生VernoxStorage.exe进程请求立即执行新建文件的请求，0：表示无任何处理，1：内存文件处理请求（具体新建数据在本文件内部的文件数据中），32：完成内存文件的处理请求，服务进程收到此状态后修改为0
	BYTE                m_bReservedByte;                               //保留字节
	int                 m_nRedoLogMaxID;                               //重做日志的最大ID，属于给发号用的
	long long           m_nBeginTimestamp;                             //文件修改的开始时间戳（由VernoxStorage.exe程序修改），最后一次保存文件后设置此值相当于告诉写文件进程，需要关注的最小时间戳
	long long           m_nEndTimestamp;                               //文件修改的结束时间戳（由本进程负责维护和修改），每完成一个修改事务的时间戳就写入此值（每次写入时负责检查是否还有小于此时间戳的修改事务，如果有就不填写，放置数据漏写），也是VernoxStorage.exe程序写入磁盘的最大时间戳
	long long           m_nFreeBlockOffset;                            //对象删除等回收的BLOCK块偏移地址

	//全局参数定义
	char				m_cDatabaseName[MAX_PATH];						//数据库名
	char				m_cDatabasePath[MAX_PATH];						//数据库路径
	int	                m_nServicePort;                                //SERVICE_PORT ：Web Service的监听端口，默认为8080；
	int	                m_nServiceWorkers;                             //SERVICE_WORKERS： Web Service的服务线程数量，默认为10 ；
	int	                m_nTCPListenIP;                                //TCP_LISTEN_IP：TCP监听IP地址，默认为0，表示不绑定网卡；
	int	                m_nTCPListenPort;                              //TCP_LISTEN_PORT：TCP监听端口，默认为8000；
	int	                m_nTCPTimeout;                                 //TCP_TIMEOUT ：TCP发送及接收数据超时时间，默认为60秒；
	int	                m_nServerTraceLevel;                           //SERVER_TRACE_LEVEL：系统日志等级，默认为10；
	int	                m_nServerEfficiencyTrace;                      //SERVER_EFFICIENCY_TRACE：系统效率日志，默认为0；
	int	                m_nServerParallelMode;                         //SERVER_PARALLELMODE：并行模式，0：读写互不影响，1：串行方式执行；
	int	                m_nServerWriteUndoMode;                        //SERVER_WRITE_UNDOMODE ：写重做日志模式(默认为1)，0：不写，1：写
	int	                m_nServerExecuteTimeMonitor;                   //SERVER_EXECUTETIME_MONITOR：执行时间监控，用于改善SQL性能，默认5000毫秒
	int	                m_nServerCaseSensitive;                        //SERVER_CASE_SENSITIVE：字符串大小写是否敏感，0为不敏感、1为敏感，默认为0；
	int	                m_nMemoryTemporarySize;                        //MEMORY_TEMPORARY_SIZE：临时内存大小(大量数据检索使用)，单位为MB，默认48
	int	                m_nMemoryUndoSize;                             //MEMORY_UNDO_SIZE：重做内存大小，用于数据回滚或一致性读取使用，默认48MB；
	int	                m_nMemoryProcessSize;                          //MEMORY_PROCESS_SIZE：处理线程私有内存大小，处理与客户端通讯，默认2MB ；
	int	                m_nMemoryPlanRemainSize;                       //MEMORY_PLAN_REMAINSIZE：执行计划空间大小，默认10KB；
	int	                m_nMemorySQLPlanMaxSize;                       //MEMORY_SQLPLAN_MAXSIZE：SQL执行计划最大大小，默认10MB；
	int	                m_nMemoryRecordsetPlanMaxSize;                 //MEMORY_RECORDSETPLAN_MAXSIZE：结果集执行计划最大大小，默认500MB；
	int	                m_nWriteFileDelayTime;                         //WRITE_FILE_DELAY_TIME：写文件延迟时间，默认为3秒；
	int	                m_nWriteUndoDelayTime;                         //WRITE_UNDO_DELAY_TIME：写重做日志文件延迟时间，默认为3秒；
	int	                m_nWriteTraceDelayTime;                        //WRITE_TRACE_DELAY_TIME：写日志文件延迟时间，默认为3秒；
	int	                m_nWriteUndoMaxSize;                           //WRITE_UNDO_MAX_SIZE ：重做日志文件大小
	int	                m_nWriteTraceMaxSize;                          //WRITE_TRACE_MAX_SIZE ：操作日志文件大小
	int	                m_nBlockDataSize;                              //BLOCK_DATA_SIZE：数据块的大小，默认为1MB；
	int	                m_nBlockBTreeIndexSize;                        //BLOCK_BTREE_INDEX_SIZE：B树索引块大小，默认为32KB；
	int	                m_nBlockBTreeDataSize;                         //BLOCK_BTREE_DATA_SIZE：B树数据块大小，默认为32KB(必需为索引块的整数倍)；
	int	                m_nBlockHashIndexSize;                         //BLOCK_HASH_INDEX_SIZE：HASH索引块大小，默认为256KB；
	int	                m_nBlockHashIndexChainMaxSize;                 //BLOCK_HASH_INDEX_CHAIN_MAXSIZE：哈希索引链最大长度，超过此长度就自动增加哈希的基础槽位长度，默认为8；
	int	                m_nBlockHashIndexExpandRatio;                  //BLOCK_HASH_INDEX_EXPAND_RATIO：哈希索引的基础槽位膨胀率，默认为4；
	int	                m_nBlockUsedRatio;                             //BLOCK_USED_RATIO ：数据块使用率，达到此值表示块已经写满，默认为80；
	int	                m_nBlockInsertMaxUseRatio;                     //BLOCK_INSERT_MAXUSE_RATIO：插入数据最大使用率，超过此值不允许继续插入，默认为90；
	int	                m_nBlockFreeRatio;                             //BLOCK_FREE_RATIO ：数据块剩余率，删除数据后剩余数据率低于此值可再用，默认为40；
	int	                m_nBlockReorganizeRatio;                       //BLOCK_REORGANIZE_RATIO ：数据块整理率，达到此值时引起块内整理预判，默认为80；
	int	                m_nBlockRecycleRatio;                          //BLOCK_RECYCLE_RATIO：数据块回收率，达到此值时进行数据整理重组，默认为10；
	int	                m_nBlockIndexDivideMode;                       //BLOCK_INDEX_DIVIDE_MODE ：索引分裂方式，1：表示按照一半的方式进行分裂，2：表示按照九比一的比率分裂，3：表示按照一比九的比率分裂；
	int					m_nObjectTransactionMaxNum;					   //OBJECT_TRANSACTION_MAXNUM:对象支持的最大事务数，默认4
	int					m_nTransactionLogicSlotCount;				   //TRANSACTION_LOGIC_SLOT_COUNT:短事务锁槽位数量，默认100
	int					m_nTransactionLogicTimeout;					   //TRANSACTION_LOGIC_TIMEOUT:短事务锁有效时间，单位为秒，默认60秒
	int					m_nActiveLogFiles;							   //ACTIVE_LOG_FILES：活动重做日志数量，默认20
	int					m_nPersistenceIntervals;					   //PERSISTENCE_INTERVALS：持久化时间间隔（单位：秒），按照事务完成进行持久化处理，默认3
	int                 m_bReservedParameter[16];                      //保留参数
}SYSTEMFILEHEAD, *LPSYSTEMFILEHEAD;

//系统文件Block头，直接为块的开始位置存放的数据，描述块内数据信息
typedef struct 
{
	int                m_nDataFlag;                                   //数据标志，目前数据块为‘SBDB’
	int                m_nBlockNo;                                    //块号(新插入块的编号 = 最大块号+1)
	long long          m_nTimestamp;                                  //时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
	int                m_nBlockSize;                                  //块大小
	int                m_nBlockHeadSize;                              //块头大小
	BYTE               m_bStatus;                                     //数据锁定状态，一般修改单条数据不需要整块锁，但如果整块进行整理时就必须进行锁定，防止其他读取或者修改操作出现错乱
	BYTE               m_bFileNo;                                     //文件编号
	BYTE               m_bSaveFlag;                                   //数据库保存标志，防止单纯按照时间戳判断出现误判
	BYTE               m_bReserved;                                   //保留数据
	int                m_nObjectID;                                   //数据对象ID，相当于数据库的表
	int                m_nInnerMaxNo;                                 //块内编号最大值，用于插入时
	int                m_nDataInsertOffset;                           //定长数据插入位置偏移
	int                m_nVarDataInsertOffset;                        //变长数据插入位置偏移
	int                m_nBlockDataStructSize;                        //定长数据结构体大小
	int                m_nDataNum;                                    //现有定长数据条数
}SYSTEMBLOCKHEAD, *LPSYSTEMBLOCKHEAD;

//系统文件定义BSON结构
typedef struct
{
	int                m_nInnerNo;                                    //数据内部编号
	int				   m_bMemFile;									  //是否为内存文件名
	BYTE               m_bFileNo;                                     //文件编号
	MF_SYS_FILETYPE    m_bFileType;                                   //文件类型，1：系统文件、2：数据文件、3：B树索引文件、4：KV索引文件
	MF_SYS_FILECMD     m_bFileCMD;                                    //文件层面的命令，0表示无任何处理，1：请求新建文件，2：改变物理文件路径，3：请求改变物理文件大小
	BYTE               m_bDropFlag;                                   //保留数据
	char               m_pOriginFilePath[256];                        //原始物理文件路径
	char               m_pAlterFilePath[256];                         //修改物理文件路径
	char               m_lpszMemFileName[64];                         //内存文件名
	long long          m_nFileSize;									  //文件大小
}FILE_MEMDBFILEINFOBSON, *LPFILE_MEMDBFILEINFOBSON;

//系统文件定义
typedef struct
{
	int                m_nInnerNo;                                    //数据内部编号
	BYTE               m_bFileNo;                                     //文件编号
	MF_SYS_FILETYPE    m_bFileType;                                   //文件类型，1：系统文件、2：数据文件、3：B树索引文件、4：KV索引文件
	MF_SYS_FILECMD     m_bFileCMD;                                    //文件层面的命令，0表示无任何处理，1：请求新建文件，2：改变物理文件路径，3：请求改变物理文件大小
	BYTE               m_bDropFlag;                                   //保留数据
	char               m_lpszFilePath[256];                           //物理文件路径
	char               m_lpszMemFileName[64];                         //内存文件名
	long long          m_nFileSize;									  //文件大小
	long long          m_nLoadSize;									  //加载大小
}FILE_MEMDBFILEINFO, *LPFILE_MEMDBFILEINFO;

//系统对象列定义
typedef struct
{
	BYTE               m_bObjectFieldNo;                              //数据对象列编号
	MF_SYS_FIELDTYPE   m_bFieldType;                                  //列类型，1：整数型(32位有符号)、2：长整数型(64位有符号)、3：日期、浮点数类型、4：固定长度字符串(最大支持32KB)、5：变化长度字符串（限制在32KB以内）、6：大字符串（限制在2GB以内）、7：二进制类型
	BYTE               m_bDropFlag;                                   //删除标志
	BYTE			   m_bCharLen;								      //定长字段长度
	BYTE               m_bAllowNull;                                  //允许为空标识
	char               m_lpszName[32];                                //对象列名名称，系统外部来访问均用此名称
}FILE_OBJECTFIELDDEF, *LPFILE_OBJECTFIELDDEF;

//系统对象定义
typedef struct
{
	int                m_nObjectID;                                   //数据对象ID
	MF_OBJECT_TYPE	   m_bObjectType;								  //对象类型
	BYTE               m_bReserved[3];								  //保留字段
	char               m_lpszName[32];                                //对象名称，系统外部来访问均用此名称
	int                m_nBlockSize;                                  //数据块大小
	BYTE			   m_nFieldNum1;								  //列数量1
	BYTE               m_nFieldNum2;                                  //列数量2
	BYTE               m_bFileNo;                                     //文件编号
	BYTE               m_bImplementClass;                             //实现类序号，从0开始
	FILE_OBJECTFIELDDEF m_stFirstField;                               //第一列定义
}FILE_OBJECTDEF, *LPFILE_OBJECTDEF;

//系统索引定义BSON结构
typedef struct
{
	int                m_nInnerNo;                                    //数据内部编号
	int                m_nIndexID;                                    //索引ID
	int                m_nObjectID;                                   //数据对象ID
	MF_OBJECT_TYPE	   m_bObjectType;								  //对象类型
	MF_CONSTRAINT_TYPE m_bConstraintType;							  //约束条件
	BYTE			   m_bReserved[2];								  //保留字段
	char               m_pObjectName[32];                             //数据对象名
	char               m_pIndexName[32];                              //索引名
	char			   m_pFieldName[4][32];							  //字段名
	char			   m_pFilePath[256];						      //索引文件路径
	MF_SYS_FILETYPE    m_bFileType;                                   //索引文件类型
	MF_SYS_INDEXTYPE   m_bIndexType;                                  //索引类型
	BYTE               m_bFileNo;                                     //文件编号
	BYTE               m_bDropFlag;                                   //删除标志
	BYTE               m_bFieldNo[4];                                 //索引字段编号
	int                m_nBlockSize;                                  //数据块大小
}FILE_INDEXDEFBSON, *LPFILE_INDEXDEFBSON;

//系统索引定义
typedef struct
{
	int                m_nInnerNo;                                    //数据内部编号
	int                m_nIndexID;                                    //索引ID
	int                m_nObjectID;                                   //数据对象ID
	MF_OBJECT_TYPE	   m_bObjectType;							      //对象类型
	BYTE			   m_bReserved[3];								  //保留字段
	char               m_lpszName[32];                                //对象名称，系统外部来访问均用此名称
	int                m_nBlockSize;                                  //数据块大小
	MF_SYS_INDEXTYPE   m_bIndexType;                                  //索引类型
	BYTE               m_bFileNo;                                     //文件编号
	BYTE               m_bDropFlag;                                   //删除标志
	BYTE               m_bConstraintType;                             //约束类型
	BYTE               m_bFieldNo[4];                                 //索引字段编号
	int                m_nDataNum;                                    //参考数据量，新建索引时建议填写此值
}FILE_INDEXDEF, *LPFILE_INDEXDEF;

//系统序列定义BSON结构
typedef struct
{
	int                m_nInnerNo;                                    //数据内部编号
	char               m_lpszName[32];                                //序列名称，系统外部来访问均用此名称
	long long          m_nMinVal;									  //序列开始值
	long long          m_nCurrentVal;                                 //序列当前值
	long long          m_nMaxVal;                                     //序列序列值
	int                m_nIncrementBy;                                //序列增长步序
	BYTE               m_bCycleFlag;                                  //循环序列标志
	BYTE               m_bCacheFlag;                                  //为保证顺序，每次在内存中分配一定数量（20个），即每20个才会更新一次文件
	BYTE               m_bDropFlag;                                   //删除标志
	BYTE               m_bReserved;                                   //保留数据
}FILE_SEQUENCEDEFBSON, *LPFILE_SEQUENCEDEFBSON;

//系统序列定义
typedef struct
{
	int                m_nInnerNo;                                    //数据内部编号
	char               m_lpszName[32];                                //序列名称，系统外部来访问均用此名称
	long long          m_nMinVal;                                     //序列开始值
	long long          m_nCurrentVal;                                 //序列当前值
	long long          m_nMaxVal;                                     //序列序列值
	int                m_nIncrementBy;                                //序列增长步序
	BYTE               m_bCycleFlag;                                  //循环序列标志
	BYTE               m_bCacheFlag;                                  //为保证顺序，每次在内存中分配一定数量（20个），即每20个才会更新一次文件
	BYTE               m_bDropFlag;                                   //删除标志
	BYTE               m_bReserved;                                   //保留数据
}FILE_SEQUENCEDEF, *LPFILE_SEQUENCEDEF;

//日志系统头结构体定义
typedef struct
{
	int                m_nDataFlag;                                   //数据标志，目前定义日志标识‘SBMT’
	int                m_nFileTotalSize;                              //文件总大小
	int                m_nFileHeaderSize;                             //文件头大小
	BYTE               m_bFileType;                                   //日志类型，1：软件日常日志，2：软件数据修改日志
	BYTE               m_bWriteFinishFlag;                            //操作结束标志，0：表示日志写完，可以随时分文件；1：表示数据还未写完，分文件会导致第二个文件数据错乱
	BYTE               m_bReserved[2];                                //保留数据
	int                m_nWritePos;                                   //日志写入位置
	int                m_nReadPos;                                    //日志读取位置
}FILE_TRACEMEMFILEHEAD, *LPFILE_TRACEMEMFILEHEAD;

typedef struct
{
	int					m_nInnerNo;									   //内部编号
	long long 			m_nUserID;									   //用户ID
	BYTE				m_bStatus;									   //状态：启动、停用
	BYTE				m_bDropFlag;
	BYTE				m_bReserved[2];								   //保留字段
	char				m_pUserName[24];							   //用户名
	BYTE				m_pPassword[24];							   //用户密码
	MF_AUTHORITY_ID	m_bAuthorityID[64];								   //权限类型
}FILE_USERINFO, *LPFILE_USERINFO;

typedef struct
{
	MF_AUTHORITY_ID		m_bAuthorityID;								   //权限ID
	BYTE				m_bDropFlag;								   //删除标识
	BYTE				m_bReserved[2];								   //保留字段
	char				m_pAuthorityName[32];						   //权限名
	char				m_pAuthorityDesc[128];						   //权限描述
}FILE_AUTHORITY, *LPFILE_AUTHORITY;

//临时内存头结构体定义
typedef struct
{
	UINT               m_nDataFlag;                                   //数据标志，目前定义日志标识‘SBTM’
	UINT               m_nTotalSize;                                  //内存总大小
	UINT               m_nHeaderSize;                                 //内存头大小
	UINT               m_nLastAllocPos;                               //内存最后一个分配位置
	UINT               m_nFreePos;                                    //内存释放位置
	UINT               m_nAllocPos;                                   //内存分配位置
}TEMPORARYMEMHEAD, *LPTEMPORARYMEMHEAD;

//临时内存分配块数据结构体定义
typedef struct
{
	UINT               m_nSize;                                       //内存块大小
	UINT               m_nNextPos;                                    //下一块内存位置
	long long          m_nAllocTime;                                  //内存分配时间
	BYTE               m_bStatus;                                     //内存数据块状态
	BYTE               m_bFlag;                                       //块标志
	BYTE               m_bMemAddr;                                    //内存开始地址
}TEMPORARYMEMBLOCK, *LPTEMPORARYMEMBLOCK;

//服务端执行耗时统计信息
typedef struct
{
	FILETIME            m_ftStartTime;                                 //执行开始时间
	FILETIME            m_ftEndTime;                                   //执行结束时间
	LARGE_INTEGER       m_liStart;                                     //开始时间点
	LARGE_INTEGER       m_liFrequence;                                 //CPU频率
	LARGE_INTEGER       m_liParsePlanStart;                            //执行计划解析开始时间点
	LARGE_INTEGER       m_liPretreatmentStart;                         //预处理执行开始时间点
	LARGE_INTEGER       m_liExecuteStart;                              //开始执行时间点
	LARGE_INTEGER       m_liIndexSearchEnd;                            //索引扫描完成时间点
	LARGE_INTEGER       m_liExecuteEnd;                                //结束执行时间点
	LARGE_INTEGER       m_liWriteLogEnd;                               //写日志结束时间点
	LARGE_INTEGER       m_liEnd;                                       //结束时间点
	LONG                m_lWorkLoad;                                   //服务端运算量
	LONG                m_lReserved;                                   //保留数据
}MF_EXECUTESTATISTICSINFO;

//重做日志头结构体定义，48字节
typedef struct
{
	char				m_lpszFileFlag[14];							   //文件头标识，“VernoxLog”
	USHORT				m_usDatabaseGuid;							   //数据库唯一标识
	int					m_nSequenceNO;								   //内部序号
	int					m_nVersion;									   //文件版本号
	FILETIME			m_ftCreateTime;								   //文件创建时间
	long long			m_nBeginTimestamp;							   //开始时间戳
	long long			m_nEndTimestamp;							   //结束时间戳
}MF_REDOLOGFILEHEAD;

typedef struct
{
	BYTE                m_bCmdType;                                    //命令类型，1：首次设置客户端信息，2：修改客户64位用户数据，3：修改客户32位用户数据
	BYTE                m_bReserved;                                   //保留数据
	char                m_lpszProgramName[24];                         //应用程序名字
	DWORD               m_dwProcessID;                                 //进程ID
	DWORD               m_dwThreadID;                                  //线程ID
	ULONG               m_ulIP;                                        //IP
	USHORT              m_usPort;                                      //端口
	ULONGLONG           m_ullUserData;                                 //64位用户数据
	DWORD               m_dwUserData;                                  //32位用户数据
	char				m_pUserName[24];							   //用户名
	char				m_pPassword[24];							   //用户密码
}MF_CLIENTINFO;


//采用TCP通讯方式的结构体定义
typedef struct 
{
	BYTE                           m_bVersion;                    	   //命令版本号，主要是做兼容处理的
	MF_INTERFACE_TCPCOMMAND        m_bType;                       	   //命令类型
	BYTE                           m_bToken;                      	   //通讯令牌数据，用于避免命令和返回不是匹配的
	BYTE						   m_bReserved;						   //保留数据
	int                            m_lDigitalData;                	   //数字型数据，当m_bType为MF_INTERFACE_TCPCOMMAND_FAIL时表示错误码，当MF_INTERFACE_TCPCOMMAND_OK时表示数字型的执行结果
	int                            m_lDataLength;                 	   //命令后面的实际数据体长度
	char                           m_lpszParam[100];              	   //参数，目前返回时为执行统计信息，命令时为空
}MF_SERVICE_TCP_COMMAND, *LPMF_SERVICE_TCP_COMMAND;

//文件信息的结构提定义
typedef struct STRUCT_MASTERSLAVE_FILEINFO
{
	BYTE	m_bFileType;											  //文件类型，1：系统文件、2：数据文件、3：B树索引文件、4：KV索引文件
	BYTE	m_bFileNo;												  //文件编号
	BYTE	m_bReserved[2];											  //保留数据
	long long m_nFileSize;											  //文件大小
	TCHAR   m_lpszMemFileName[64];								 	  //内存文件名
	TCHAR   m_lpszFilePath[256];									  //物理文件路径
}MF_MASTERSLAVE_FILEINFO, *LPMF_MASTERSLAVE_FILEINFO;

//Server与Storage之间内存通信
typedef struct
{
	int						m_nFileTotalSize;							//文件总大小
	int						m_nFileHeaderSize;							//文件头大小
	int						m_nBakBlockOffset;							//保存Block的位置偏移（=文件头大小）
	int						m_nBakFileHeadOffset;						//保存文件头备份区的位置偏移（=文件头大小）
	int						m_nObjectNo;								//对象编号
	int						m_nBlockNo;									//块编号
	int						m_nCycleTime;								//监听周期（单位ms）
	int						m_nResult;									//操作结果
	long long				m_nTimestamp;								//持久化时间戳
	long long				m_nMapSize;									//映射表大小
	ULONG					m_ulIP;										//集群指令参数
	ULONG					m_ulLocalIP;								//集群指令参数
	USHORT					m_usPort;									//集群指令参数
	MF_STORAGEMEM_TYPE		m_bClusterCommandType;						//集群指令参数
	MF_STORAGEMEM_TYPE		m_bCommandType;								//操作标志，0：等待操作指令，1：执行闪回操作，2：备份映射表
	BYTE					m_bFileNo;									//文件编号
	BYTE					m_bServer;									//SobeyMenServer服务是否启动，0：未启动，1：已启动
	BYTE					m_bReserved;								//保留数据
}STORAGEMEMHEAD, *LPSTORAGEMEMHEAD;


//根据重作日志重建/备份数据库，记录已完成的位置
typedef struct
{
	FILETYPE	m_hFile;								//当前重作日志文件的句柄
	int			m_nRedoLogID;							//当前重作日志文件的编号
	long long	m_llTimestamp;							//时间戳		记录已经读取完的执行计划的时间戳
	DWORD		m_dwReadPos;							//已经读取完成的位置
	TCHAR		m_lpRedoDir[256];						//重作日志文件所在的文件夹
	TCHAR		m_lpRedoFilePath[256];					//当前重作日志文件的路径
	TCHAR		m_lpNextRedoFilePath[256];				//下一个重作日志文件的路径
}REDOPROCESS, *LPREDOPROCESS;

//执行计划基础头结构
typedef struct
{
	UINT						   m_nTotalDataSize;			   //缓存中数据总大小
	UINT						   m_nBsonDataSize;				   //Bson缓存中数据大小
	UINT                           m_nDefaultSectionSize;		   //默认缓存片段大小
	UINT						   m_nFreeSectionAddrID;		   //空闲缓存片段的地址ID
	UINT						   m_nSectionStartOffset;		   //片段起始地址偏移
	UINT						   m_nClientSectionNum;			   //客户端片段数
	UINT                           m_nClientBsonDataSize;          //客户端Bson数据大小
	int                            m_nDataFlag;                    //数据标志，目前定为‘PLAN’
	MF_EXECUTEPLAN_CMDTYPE		   m_nType;						   //命令类型
	BYTE                           m_bVersion;                     //版本号，目前为1
	BYTE						   m_bWriteLog;					   //为1表示需要写重做日志，否则不用处理。BSON脚本是否需要写入数据库的重做日志，判断规则为：所有DDL语句（表结构、数据文件等系统修改语句），所有DML语句（插入、修改、删除），DQL语句中的查询序列。
	BYTE						   m_bFieldNum;					   //字段数量
	MF_DATABASE_TYPE			   m_bDBType;					   //数据库类型
	MF_OBJECT_TYPE				   m_bObjectType;				   //对象类型
	BYTE						   m_bReserved[2];				   //保留字段
	long long                      m_nTimestamp;                   //当前时间戳
}BASEEXECUTEPLANHEAD, *LPBASEEXECUTEPLANHEAD;

//数据导出文件头
//文件格式
//文件头 + n*（表头 + 表数据）
typedef struct
{
	int			m_nVersion;				//版本号
	int			m_nFileFlag;			//EXDA, ExportData
	char		m_pDataFlag[7];			//Vernox\0
	int			m_nObjectCount;			//表数量
}EXPORTFILEHEAD, *LPEXPORTFILEHEAD;

//数据导出表头
typedef struct
{
	long long	m_llObjectDataSize;		//表数据总长度，包括表头结构
	int			m_nVersion;				//版本号
	int			m_nFileFlag;			//EXOB, ExportObject
	char		m_pDataFlag[7];			//Vernox\0
	char		m_pObjectName[32];
	
	USHORT		m_usDataBaseGuid;
	LONGLONG	m_llTimeStamp;			//导出时间戳
	ULONG		m_ulHostIP;
	char		m_pMachineName[32];
	char		m_pUserName[24];
	int			m_nObjectCount;			//表数量
	int			m_nTotalDataNum;		//总记录数
}EXPORTOBJECTFILEHEAD, *LPEXPORTOBJECTFILEHEAD;

#pragma pack()

