﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#ifdef WIN32
	#ifdef _M_X64
		#ifdef DEBUG
			#pragma comment(lib, "..\\LibX64\\VernoxBaseLibD.lib")
		#else
			#pragma comment(lib, "..\\LibX64\\VernoxBaseLib.lib")
		#endif
	#else
		#ifdef DEBUG
			#pragma comment(lib, "..\\Lib\\VernoxBaseLibD.lib")
		#else
			#pragma comment(lib, "..\\Lib\\VernoxBaseLib.lib")
		#endif
	#endif
	#include "MemDBCommonDef.h"
	#include "../VernoxBaseLib/CommonBaseAPI.h"
	#include "../VernoxBaseLib/CommonDataDef.h"
	#include "../VernoxBaseLib/ParseSql.h"
	#include "../VernoxBaseLib/MemoryBaseAnalysis.h"
	#include "../VernoxBaseLib/MemDBRecordset.h"
	#include "../VernoxBaseLib/ShareMemory.h"
	#include "../VernoxBaseLib/MFString.h"
#else
	#include "MemDBCommonDef.h"
	#include "auto_tchar.h"
	#include "../VernoxBaseLib/CommonBaseAPI.h"
	#include "../VernoxBaseLib/CommonDataDef.h"
	#include "../VernoxBaseLib/ParseSql.h"
	#include "../VernoxBaseLib/MemDBRecordset.h"
	#include "../VernoxBaseLib/ShareMemory.h"
	#include "../VernoxBaseLib/LinuxCommonAPI.h"
	#include "../VernoxBaseLib/MFString.h"
#endif
