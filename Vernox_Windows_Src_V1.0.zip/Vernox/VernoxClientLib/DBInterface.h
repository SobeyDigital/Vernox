﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "../Include/SobeyMemBaseExport.h"
#include "../Include/SobeyDBInterface.h"
class CTableMap;
class CMemDBRecordset;

typedef BOOL (*CALLBACK_VERNOXEXCHANGE)(LPVOID lpParam, char *lpszTitle, int nTotal, int nPos);

#define FIRST_IPADDRESS(x)  (((x) >> 24) & 0xff)
#define SECOND_IPADDRESS(x) (((x) >> 16) & 0xff)
#define THIRD_IPADDRESS(x)  (((x) >> 8) & 0xff)
#define FOURTH_IPADDRESS(x) ((x) & 0xff)

typedef struct
{
	ULONGLONG m_ftServerStartTime;
	ULONGLONG m_ftServerEndTime;
	LONGLONG m_llServerFrequence;
	LONGLONG m_llServerStart;
	LONGLONG m_llServerParsePlanStart;
	LONGLONG m_llServerPretreatmentStart;
	LONGLONG m_llServerExecuteStart;
	LONGLONG m_llServerIndexSearchEnd;
	LONGLONG m_llServerExecuteEnd;
	LONGLONG m_llServerWriteLogEnd;
	LONGLONG m_llServerEnd;
	ULONG m_ulServerWorkLoad;
	ULONGLONG m_ftStartTime;
	ULONGLONG m_ftEndTime;
	LONGLONG m_llFrequence;
	LONGLONG m_llStart;
	LONGLONG m_llParseEnd;
	LONGLONG m_llReceiveEnd;
	LONGLONG m_llEnd;
	LONG m_nRet;
	LONG m_nSqlType;
	LONG m_nEstimateNum;
}MF_EXECUTE_STATISTICS;

typedef struct
{
	WCHAR				m_pObjectName[32];							 //对象名
	MF_OBJECT_TYPE		m_bObjectType;							     //对象类型
	WCHAR				m_pIndexName[32];							 //索引名
	MF_SYS_INDEXTYPE	m_bIndexType;								 //索引类型
	BYTE				m_bDrection;								 //递归方向
	BYTE				m_bRecursionLevel;							 //递归深度
	int					m_nRowNumber;								 //记录数量
	WCHAR				m_pDescribe[100];							 //描述信息
}EXECUTEPLANDESCRIBE, *LPEXECUTEPLANDESCRIBE;

class CDBInterface : public ISobeyDBConnection
{
public:
	CDBInterface(void);
	~CDBInterface(void);

protected:
	typedef struct 
	{
		char m_cProtocol[MAX_PATH];
		char m_cHost[MAX_PATH];
		char m_cPort[MAX_PATH];
		char m_cWriteLog[MAX_PATH];
	}STRUCT_ADDRESS, LPSTRUCT_ADDRESS;


	typedef struct 
	{
		char m_cSobeyDB[MAX_PATH];
		char m_cDatabaseName[MAX_PATH];
		vector<STRUCT_ADDRESS> m_vecAddress;
	}STRUCT_CONNECT_CONFIG;

	typedef struct
	{
		ULONG			m_ulIP;
		USHORT			m_usPort;
		int				m_nSessionNum;
	}CONNECTINFO, *LPCONNECTINFO;

protected:
	int					m_nSessionNum;					//当前链接数量
	int					m_nNodeNum;						//节点数量
	CONNECTINFO			m_lpConnectInfo[10];			//集群负载
	CRITICAL_SECTION	m_csInterFace;
	ULONG				m_ulHostIP;
	USHORT				m_usHostPort;
	BOOL				m_bOpenFlag;
	
	int					m_lWriteEfficiencyLog;
	//通过TCP方式需要的参数
	ULONG				m_uServiceTCPIP;
	USHORT				m_uServiceTCPPort;

	SOCKET				m_skSocket;
	BYTE				m_bRandomFactor;				//随机因子
	char				m_pUserName[24];
	char				m_pPassword[24];
protected:
	BYTE CreateRandomFactor();
	BOOL ConvertStr(char* pSrc, WCHAR* pDest, int nLen);
protected:
	int  Connect(BOOL bRetry);
	void ClearSocket();

	int OpenDatabase(BOOL bRetry);
	int ConnectToService(BOOL bRetry);
	int UserLogin();
public:
	int OpenWithAddress(char *lpszUserName, char *lpszPassword, ULONG ulIP, USHORT usPort);
	int OpenWithAddress(char *lpszUserName, char *lpszPassword, char* lpszHost, char* lpszPort);
	int OpenCore(char * lpszServerName, char * lpszUserName, char * lpszPassword);

protected:
	void GetSocketInfo(ULONG &ulIP, USHORT &usPort);
	BOOL ReceiveBuffer(char *pBuffer, int nSize);
	int GetStatisticsData(MF_EXECUTE_STATISTICS* pStatisticsInfo, char * lpszParam);
	int ConvertStatisticsData(MF_EXECUTE_STATISTICS* pStatisticsInfo, LPCTSTR lpszStatistics);

	char* RemoveSpaceFromString(char* lpStr);
	BOOL IsCharacter(char c);
	BOOL ParseConnectConfig(char *lpServerName, FILE * fp, STRUCT_CONNECT_CONFIG &stConfig);
	int ParseConnectConfig(char *lpServerName, STRUCT_CONNECT_CONFIG &stConfig);
protected:
	int TCPExecuteCommand(const char* lpszSql, int& nAffectCount, MF_EXECUTE_STATISTICS* pStatisticsInfo);
	int TCPGetRecordset(const char* lpszSql, CMemDBRecordset& stRs, MF_EXECUTE_STATISTICS* pStatisticsInfo);
	int TCPUpdateRecordset(CMemDBRecordset& stRs, MF_EXECUTE_STATISTICS* pStatisticsInfo);
	int TCPGetExecutePlanInfo(const char* lpszSql, LPEXECUTEPLANINFO lpExecutePlanInfo, MF_EXECUTE_STATISTICS* pStatisticsInfo);

#ifdef WIN32
	int TCPStartTransactionLogic(BSTR bstrTransactionData, LONG* plTransactionID, MF_EXECUTE_STATISTICS* pStatisticsInfo);
	int TCPStopTransactionLogic(LONG lTransactionID, MF_EXECUTE_STATISTICS* pStatisticsInfo);
#endif
public:
	int FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
		if(m_skSocket != INVALID_SOCKET)
		{
			closesocket(m_skSocket);
			m_skSocket = INVALID_SOCKET;
		}
	}
public:
	int SplitSql(char* lpszBuffer, int nLen, vector<char*>& vecSql);
	int ExecuteCommand(const char* lpszSql, int& nAffectCount, MF_EXECUTE_STATISTICS* pStatisticsInfo);
	int GetRecordset(const char* lpszSql, CMemDBRecordset& stRs, MF_EXECUTE_STATISTICS* pStatisticsInfo);
	int UpdateRecordset(CMemDBRecordset& stRs, MF_EXECUTE_STATISTICS* pStatisticsInfo);
	int GetExecutePlanInfo(const char* lpszSql, LPEXECUTEPLANDESCRIBE lpExecutePlanDesc, MF_EXECUTE_STATISTICS* pStatisticsInfo);

	int ExportObject(char *lpObjectNameArray, int nObjectCount, char *lpszExportFilePath, CALLBACK_VERNOXEXCHANGE pCallback, LPVOID lpParam);
	int ImportObject(char *lpszImportFilePath, CALLBACK_VERNOXEXCHANGE pCallback, LPVOID lpParam);
protected:
	int ExportObject(char *lpszObjectName, FILE *fp, CALLBACK_VERNOXEXCHANGE pCallback, LPVOID lpParam);
	int ImportObject(FILE *fp, CALLBACK_VERNOXEXCHANGE pCallback, LPVOID lpParam);
public:
	
#ifdef WIN32
	int StartTransactionLogic(BSTR bstrTransactionData, LONG* plTransactionID);
	int StopTransactionLogic(LONG lTransactionID);
#endif

	ULONG GetIpAddress();
	ULONG StringToIpAddress(char* lpIpAddress);

public:
	int UserLogOut(int& nRetValue);
	int SqlQuery(char* lpSql, int& nAffectCount, CMemDBRecordset& stRs,  LPEXECUTEPLANDESCRIBE lpExecutePlanDesc, MF_EXECUTE_STATISTICS* pStatisticsInfo);
public:
	static int CreateInstance(ISobeyDBConnection * &pConnection);
	//释放数据库连接对象资源函数
	void Release();

	//连接到数据库函数
	int Open(char * lpszServerName, char * lpszUserName, char * lpszPassword);

	//关闭数据库连接函数
	void Close();

	//数据库执行函数
	int Execute(char * lpszSqlText, int &lAffectCount, void * lpDescription);

	//数据库查询数据到结果集函数
	int GetRecordset(char * lpszSqlText, ISobeyDBRecordset** pRecordset, void * lpDescription = NULL);

	//结果集更新执行函数
	int UpdateRecordset(ISobeyDBRecordset* pRecordset, void * lpDescription = NULL);
};

extern void ReleaseResource();
