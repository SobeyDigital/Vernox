﻿// stdafx.cpp : 只包括标准包含文件的源文件
// SobeyMemInterfaceLib.pch 将作为预编译头
// stdafx.obj 将包含预编译类型信息

#include "stdafx.h"

// TODO: 在 STDAFX.H 中
// 引用任何所需的附加头文件，而不是在此文件中引用
#ifdef WIN32
#include <dbghelp.h>

#pragma comment (lib, "dbghelp.lib")
#define EXCEPTION_NO_MEMORY STATUS_NO_MEMORY

string GetExceptionName(unsigned code)
{
	string strMsg;
	char lpszBuffer[1024];
	memset(lpszBuffer, 0, 1024);
	switch (code)
	{
	case EXCEPTION_NO_MEMORY:
		strMsg = _T("No Memory");
		break;
	case EXCEPTION_ACCESS_VIOLATION :
		strMsg = _T("Access Violation");
		break;
	case EXCEPTION_DATATYPE_MISALIGNMENT :
		strMsg = _T("Datatype Misalignment");
		break;
	case EXCEPTION_BREAKPOINT :
		strMsg = _T("Breakpoint");
		break;
	case EXCEPTION_SINGLE_STEP :
		strMsg = _T("Single Step");
		break;
	case EXCEPTION_ARRAY_BOUNDS_EXCEEDED :
		strMsg = _T("Array Bounds Exceeded");
		break;
	case EXCEPTION_FLT_DENORMAL_OPERAND :
		strMsg = _T("Float Denormal Operand");
		break;
	case EXCEPTION_FLT_DIVIDE_BY_ZERO :
		strMsg = _T("Float Divide by Zero");
		break;
	case EXCEPTION_FLT_INEXACT_RESULT :
		strMsg = _T("Float Inexact Result");
		break;
	case EXCEPTION_FLT_INVALID_OPERATION :
		strMsg = _T("Float Invalid Operation");
		break;
	case EXCEPTION_FLT_OVERFLOW :
		strMsg = _T("Float Overflow");
		break;
	case EXCEPTION_FLT_STACK_CHECK :
		strMsg = _T("Float Stack Check");
		break;
	case EXCEPTION_FLT_UNDERFLOW :
		strMsg = _T("Float Underflow");
		break;
	case EXCEPTION_INT_DIVIDE_BY_ZERO :
		strMsg = _T("Integer Divide by Zero");
		break;
	case EXCEPTION_INT_OVERFLOW :
		strMsg = _T("Integer Overflow");
		break;
	case EXCEPTION_PRIV_INSTRUCTION :
		strMsg = _T("Privileged Instruction");
		break;
	case EXCEPTION_IN_PAGE_ERROR :
		strMsg = _T("In Page Error");
		break;
	case EXCEPTION_ILLEGAL_INSTRUCTION :
		strMsg = _T("Illegal Instruction");
		break;
	case EXCEPTION_NONCONTINUABLE_EXCEPTION :
		strMsg = _T("Noncontinuable Exception");
		break;
	case EXCEPTION_STACK_OVERFLOW :
		strMsg = _T("Stack Overflow");
		break;
	case EXCEPTION_INVALID_DISPOSITION :
		strMsg = _T("Invalid Disposition");
		break;
	case EXCEPTION_GUARD_PAGE :
		strMsg = _T("Guard Page");
		break;
	case EXCEPTION_INVALID_HANDLE :
		strMsg = _T("Invalid Handle");
		break;
	case 0xE06D7363 :
		strMsg = _T("Microsoft C++ Exception");
		break;
	default :
		sprintf_s(lpszBuffer, 1024, "0X%08X", code);
		strMsg = lpszBuffer;
	};
	return strMsg;
}


string GetCurrentStack(ULONG ulCode, CONTEXT * pctx, long nMaxFrame)
{
	char lpszBuffer[1024];
	memset(lpszBuffer, 0, 1024);
	string strTemp,strMsg,strRowMsg, strLine;
#ifdef _M_X64
	int nFrame;
	HMODULE	hMod;
	DWORD dwTemp;
	BYTE symbol [ 512 ];
	STACKFRAME64 pframe;
	DWORD64 dwDisplacement;
	IMAGEHLP_LINE img_line;
	HANDLE		hProc,hThread;
	TCHAR lpszFileName[MAX_PATH];
	PIMAGEHLP_SYMBOL pSym = (PIMAGEHLP_SYMBOL)&symbol;
	ZeroMemory(&pframe, sizeof(STACKFRAME64));

	hProc = GetCurrentProcess();
	hThread = GetCurrentThread();
	::SymInitialize(hProc, 0, TRUE);

	sprintf_s(lpszBuffer, 1024, "ExceptionName:%s      ExceptionCode:0X%X\r\n\r\n", GetExceptionName(ulCode), ulCode);
	strMsg = lpszBuffer;
	strMsg += _T("[Offset]ModuleFileName  FunctionName  SourceFileName[LN:LineNO]\r\n");

	memset(&pframe, 0, sizeof(STACKFRAME64));
	pframe.AddrPC.Offset       = pctx->Rip;
	pframe.AddrPC.Mode         = AddrModeFlat;
	pframe.AddrStack.Offset    = pctx->Rsp;
	pframe.AddrStack.Mode      = AddrModeFlat;
	pframe.AddrFrame.Offset    = pctx->Rbp;
	pframe.AddrFrame.Mode      = AddrModeFlat;

	for(nFrame = 0;nFrame < nMaxFrame;nFrame++)
	{
		if(!StackWalk64 (IMAGE_FILE_MACHINE_AMD64,
			hProc, 
			hThread, 
			&pframe, 
			pctx,
			NULL,
			SymFunctionTableAccess64,
			SymGetModuleBase64,
			NULL))
			break;

		if (pframe.AddrFrame.Offset == 0)  
		{  
			break;  
		}

		strLine = _T("");
		hMod = (HMODULE)SymGetModuleBase (hProc, pframe.AddrPC.Offset);
		if (hMod)
		{
			memset(lpszFileName,0,MAX_PATH*sizeof(TCHAR));
			GetModuleFileName(hMod, lpszFileName, MAX_PATH);
			sprintf_s(lpszBuffer, 1024, "[%I64x]%s", pframe.AddrPC.Offset,lpszFileName);
			strTemp = lpszBuffer;
			strLine += strTemp;
		}
		memset(&img_line, 0, sizeof(IMAGEHLP_LINE));
		img_line.SizeOfStruct = sizeof(IMAGEHLP_LINE);

		dwDisplacement	= 0;
		dwTemp			= 0;
		memset(pSym, 0, sizeof(symbol)) ;
		pSym->SizeOfStruct = sizeof(IMAGEHLP_SYMBOL) ;
		pSym->MaxNameLength = sizeof(symbol) - sizeof(IMAGEHLP_SYMBOL);
		if(SymGetSymFromAddr64(hProc, pframe.AddrPC.Offset, &dwDisplacement, pSym))
		{
			strTemp = pSym->Name;
			if(nFrame == 0 && strTemp == _T("MyExceptionHandler"))
			{
				continue;
			}
			strLine += _T("  ")+strTemp;
		}
		if (SymGetLineFromAddr64 (hProc, pframe.AddrPC.Offset, &dwTemp, &img_line))
		{
			strTemp = img_line.FileName;
			sprintf_s(lpszBuffer, 1024, "  %s[LN:%d]", strTemp,img_line.LineNumber);
			strRowMsg = lpszBuffer;
			strLine += strRowMsg;
		}
		strMsg += strLine + _T("\r\n");
	}
	::SymCleanup(hProc);
#else
	int nFrame;
	BYTE symbol [512];
	HMODULE		hMod;
	STACKFRAME	pframe;
	DWORD dwDisplacement;
	IMAGEHLP_LINE img_line;
	HANDLE		hProc,hThread;
	TCHAR lpszFileName[MAX_PATH];
	PIMAGEHLP_SYMBOL pSym = (PIMAGEHLP_SYMBOL)&symbol;
	hProc = GetCurrentProcess();
	hThread = GetCurrentThread();
	::SymInitialize(hProc, 0, TRUE);

	sprintf_s(lpszBuffer, 1024, "ExceptionName:%s      ExceptionCode:0X%X\r\n\r\n", GetExceptionName(ulCode), ulCode);
	strMsg = lpszBuffer;
	strMsg += _T("[Offset]ModuleFileName  FunctionName  SourceFileName[LN:LineNO]\r\n");

	memset(&pframe, 0, sizeof(STACKFRAME));
	pframe.AddrPC.Offset       = pctx->Eip;
	pframe.AddrPC.Mode         = AddrModeFlat;
	pframe.AddrStack.Offset    = pctx->Esp;
	pframe.AddrStack.Mode      = AddrModeFlat;
	pframe.AddrFrame.Offset    = pctx->Ebp;
	pframe.AddrFrame.Mode      = AddrModeFlat;

	for(nFrame = 0;nFrame < nMaxFrame;nFrame++)
	{
		if(!StackWalk (IMAGE_FILE_MACHINE_I386,
			hProc, 
			hThread, 
			&pframe, 
			pctx,
			(PREAD_PROCESS_MEMORY_ROUTINE)ReadProcessMemory,
			SymFunctionTableAccess,
			SymGetModuleBase,
			0))
			break;

		if (pframe.AddrFrame.Offset == 0)
		{
			break;
		}

		strLine = _T("");
		hMod = (HMODULE)SymGetModuleBase (hProc, pframe.AddrPC.Offset);
		if (hMod)
		{
			memset(lpszFileName,0,MAX_PATH*sizeof(TCHAR));
			GetModuleFileName(hMod, lpszFileName, MAX_PATH);
			sprintf_s(lpszBuffer, 1024, "[%I64x]%s", pframe.AddrPC.Offset,lpszFileName);
			strTemp = lpszBuffer;
			strLine += strTemp;
		}
		memset(&img_line, 0, sizeof(IMAGEHLP_LINE));
		img_line.SizeOfStruct = sizeof(IMAGEHLP_LINE);

		dwDisplacement = 0;
		memset(pSym, 0, sizeof(symbol)) ;
		pSym->SizeOfStruct = sizeof(IMAGEHLP_SYMBOL) ;
		pSym->MaxNameLength = sizeof(symbol) - sizeof(IMAGEHLP_SYMBOL);
		if(SymGetSymFromAddr(hProc, pframe.AddrPC.Offset, &dwDisplacement, pSym))
		{
			strTemp = pSym->Name;
			if(nFrame == 0 && strTemp == _T("MyExceptionHandler"))
			{
				continue;
			}
			strLine += _T("  ")+strTemp;
		}
		if (SymGetLineFromAddr (hProc, pframe.AddrPC.Offset, &dwDisplacement, &img_line))
		{
			strTemp = img_line.FileName;
			sprintf_s(lpszBuffer, 1024, "  %s[LN:%d]", strTemp,img_line.LineNumber);
			strRowMsg = lpszBuffer;
			strLine += strRowMsg;
		}
		strMsg += strLine + _T("\r\n");
	}
	::SymCleanup(hProc);
#endif
	return strMsg;
}


int MyExceptionHandler(ULONG ulCode, EXCEPTION_POINTERS* lpExceptionPointer)
{
	string strText;
	strText = GetCurrentStack(ulCode, lpExceptionPointer->ContextRecord, 20);
	Trace0(_T("ExceptionHandler"), 0, 100000000, strText.c_str());
	return EXCEPTION_EXECUTE_HANDLER;
}
#endif

//extern CTableMap*	g_pTableMap;
void ReleaseResource()
{
	ExitTraceSystem();
	/*if(g_pTableMap != NULL)
	{
		delete g_pTableMap;
		g_pTableMap = NULL;
	}*/
}