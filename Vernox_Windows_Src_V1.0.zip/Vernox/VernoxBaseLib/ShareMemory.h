﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#ifdef WIN32
#include <WinBase.h>
#include "MemDBCommonDef.h"
#else
#include <sys/shm.h>
#include <errno.h>
#include <semaphore.h>
#include <fcntl.h>
#include "../Include/MemDBCommonDef.h"
#endif

class CShareMemory
{
public:
	CShareMemory();
	~CShareMemory();
public:
	static MFID CreateShareMemory(key_t nKey, size_t nMemSize, LPCTSTR lpName);
	static BOOL DestoryShareMemory(MFID &nMemId);
	static MFID OpenShareMemory(key_t nKey, LPCTSTR lpName);
	static BOOL CloseShareMemory(MFID &nMemId);
	static void* ShMemAttach(MFID nMemId, void * pMemaddr = 0, int nFlag = 0);
	static BOOL ShMemDetach(void * pMemaddr = 0);
	static BOOL ShareMemoryExsist(MFID nMemId);
	static BOOL GetShareMemorySuccess(MFID nMemId);
};

//////////////////////////////////////////////////////////////////////////

EVENTTYPE CreateEventSem(LPSECURITY_ATTRIBUTES lpEventAttributes, LPCTSTR lpName);

BOOL CreateEventSemSuccess(EVENTTYPE hEvent);

