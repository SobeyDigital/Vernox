﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

//日期类
#define YEAR		0
#define MONTH		1
#define DAY			2
#define HOUR		3
#define MIN			4
#define SEC			5

class CDate
{
private:
	CDate(void);
	~CDate(void);
private:
	//拆分日期字符串或日期格式字符串
	static int ParseString(char* pDate, vector<CMFString>& vecString, BOOL bFormat);
	//时间转换函数
	static DATE ConvertToDateTime(int nYear, int nMonth, int nDay, int nHour, int nMin, int nSec);
public:
	//将字符串转换为日期
	static int ToDate(char* pDate, char* pFormat, DATE& dtDate);
	//将日期转换为字符串
	static int ToChar(CBaseBson& stBson, DATE dtDate, char* pFormat, LPBYTE &lpDate);
	//将数据转换为字符串
	static int ToChar(CBaseBson& stBson, VARDATA varData, LPBYTE &lpData);
	//解析日期格式
	static int ParseFormat(char* pFormat, vector<CMFString>& vecString, BOOL& bDouble, BOOL& bHour24);
};


