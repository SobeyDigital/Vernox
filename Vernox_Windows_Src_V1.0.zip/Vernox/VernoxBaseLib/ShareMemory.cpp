﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "ShareMemory.h"

CShareMemory::CShareMemory()
{
	// TODO Auto-generated constructor stub
}

CShareMemory::~CShareMemory()
{
	// TODO Auto-generated destructor stub
}

/*
*		功能说明：
*			创建共享内存
*			共享内存不存在则创建并返回内存标识符（id）
*			共享内存存在则返回失败
*		参数说明：
*			nKey：共享内存Key值
*			nMemSize：共享内存大小
*		返回值：
*			内存标识符（id），失败返回-1
*/
MFID CShareMemory::CreateShareMemory(key_t nKey, size_t nMemSize, LPCTSTR lpName)
{
#ifdef WIN32
	return CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE | SEC_COMMIT, 0, nMemSize, lpName);
#else
	//IPC_CREAT | IPC_EXCL表示如果共享内存存在，则创建失败，如果共享内存不存在则创建成功
	//return shmget(nKey, nMemSize, IPC_CREAT | IPC_EXCL | 0666);
	return shmget(nKey, nMemSize, IPC_CREAT | 0666);
#endif
}

/*
*		功能说明：
*			销毁共享内存
*		参数说明：
*			nMemNo：共享内存编号
*/
BOOL CShareMemory::DestoryShareMemory(MFID &nMemId)
{
#ifdef WIN32
	if (CloseHandle(nMemId))
	{
		nMemId = NULL;
		return TRUE;
	} 
	else
	{
		nMemId = NULL;
		return FALSE;
	}
#else
	if(shmctl(nMemId, IPC_RMID, NULL) != MF_OK)
	{
		Sleep(10);
		shmctl(nMemId, IPC_RMID, NULL);
		nMemId = 0;
		return FALSE;
	}
	else
	{
		nMemId = 0;
		return TRUE;
	}
#endif
}

/*
*			功能说明：
*			打开已存在的共享内存
*		参数说明：
*			nKey：共享内存Key值
*		返回值：
*			内存标识符（id），失败返回-1
*/
MFID CShareMemory::OpenShareMemory(key_t nKey, LPCTSTR lpName)
{
#ifdef WIN32
	return OpenFileMapping(FILE_MAP_WRITE|FILE_MAP_READ, FALSE, lpName);
#else
	return shmget(nKey, 0, 0);
#endif
}

BOOL CShareMemory::CloseShareMemory(MFID &nMemId)
{
#ifdef WIN32
	if (CloseHandle(nMemId))
	{
		nMemId = NULL;
		return TRUE;
	} 
	else
	{
		nMemId = NULL;
		return FALSE;
	}
#else
	nMemId = 0;
	return TRUE;
#endif
}


/*
*		功能说明：
*			映射共享内存
*		参数说明：
*			nMemNo：共享内存编号
*			pMemaddr：起始地址
*			nFlag：标志
*/
void* CShareMemory::ShMemAttach(MFID nMemId, void * pMemaddr, int nFlag)
{
#ifdef WIN32
	return MapViewOfFile(nMemId, FILE_MAP_READ|FILE_MAP_WRITE, 0, 0, 0);
#else
	void* pShMem;
	pShMem = shmat(nMemId, pMemaddr, nFlag);
	if(pShMem == (void*)-1)
	{
		int n;
		n = (int)errno;
		return NULL;
	}
	else
	{
		return pShMem;
	}
#endif
}


/*
*		功能说明：
*			断开共享内存链接
*		参数说明：
*			pMemaddr：共享内存地址
*/
BOOL CShareMemory::ShMemDetach(void* pMemaddr)
{
#ifdef WIN32
	if (UnmapViewOfFile(pMemaddr))
	{
		pMemaddr = NULL;
		return TRUE;
	} 
	else
	{
		pMemaddr = NULL;
		return FALSE;
	}
#else
	int nRet;
	nRet = shmdt(pMemaddr);
	if(nRet != MF_OK)
	{
		pMemaddr = NULL;
		return FALSE;
	}
	else
	{
		pMemaddr = NULL;
		return TRUE;
	}
#endif
}


BOOL CShareMemory::ShareMemoryExsist(MFID nMemId)
{
#ifdef WIN32
	if (nMemId == NULL)
	{
		return FALSE;
	} 
	else
	{
		return TRUE;
	}
#else
	if (nMemId > 0)
	{
		return TRUE;
	} 
	else
	{
		return FALSE;
	}
#endif
}

BOOL CShareMemory::GetShareMemorySuccess(MFID nMemId)
{
#ifdef WIN32
	if (nMemId == NULL)
	{
		return FALSE;
	} 
	else
	{
		return TRUE;
	}
#else
	if (nMemId == -1)
	{
		return FALSE;
	} 
	else
	{
		return TRUE;
	}
#endif
}


//////////////////////////////////////////////////////////////////////////

EVENTTYPE CreateEventSem(LPSECURITY_ATTRIBUTES lpEventAttributes, LPCTSTR lpName)
{
#ifdef WIN32
	return CreateEvent(lpEventAttributes, FALSE, FALSE, lpName);
#else
	return sem_open(lpName, O_CREAT, 0644, 1);
#endif
}

BOOL CreateEventSemSuccess(EVENTTYPE hEvent)
{
#ifdef WIN32
	if (hEvent == NULL)
	{
		return FALSE;
	} 
	else
	{
		return TRUE;
	}
#else
	if (hEvent == SEM_FAILED)
	{
		return FALSE;
	} 
	else
	{
		return TRUE;
	}
#endif
}

