﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

class CBaseBson;
class CBaseExpression
{
protected:
	CBaseExpression(void);
	~CBaseExpression(void);
protected:
	//获取数据值
	static int GetDataValue(CBaseBson& stBson, LPMATHEXPELEMENTBSON lpFieldBson, VARDATA& stVarData);
public:
	//获得表达式类型
	static BYTE GetExpressionType(int nExpBsonOffset, CBaseBson& stBson);
	static int  GetExpressionResult(CBaseBson& stBson, LPMATHEXPBSON lpMathExp, VARDATA& varResult);
};
