﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "BaseExpression.h"
#include "BaseFunManager.h"

CBaseExpression::CBaseExpression(void)
{
}

CBaseExpression::~CBaseExpression(void)
{
}

int CBaseExpression::GetDataValue(CBaseBson& stBson, LPMATHEXPELEMENTBSON lpFieldBson, VARDATA& stVarData)
{
	switch(lpFieldBson->m_bDataType)
	{
	case MF_VARDATA_NULL:
		stVarData.m_vt = MF_VARDATA_NULL;
		break;
	case MF_VARDATA_INT:
		stVarData.SetData(*(int*)(lpFieldBson->m_bDataBuffer));
		break;
	case MF_VARDATA_INT64:
		stVarData.SetData(*(long long*)(lpFieldBson->m_bDataBuffer));
		break;
	case MF_VARDATA_DOUBLE:
		stVarData.SetData(*(double*)(lpFieldBson->m_bDataBuffer), MF_VARDATA_DOUBLE);
		break;
	case MF_VARDATA_DATE:
		stVarData.SetData(*(double*)(lpFieldBson->m_bDataBuffer), MF_VARDATA_DATE);
		break;
	case MF_VARDATA_STRING:
		stVarData.SetData(lpFieldBson->m_bDataBuffer, lpFieldBson->m_nDataLen);
		break;
	case MF_VARDATA_BINARY:
		stVarData.SetBinaryData((LPBYTE)lpFieldBson->m_bDataBuffer, lpFieldBson->m_nDataLen);
		break;
	case MF_VARDATA_UNKNOWN:
		stVarData.SetData(lpFieldBson->m_bFieldNo);
		break;
	}
	return MF_OK;
}
//获得表达式类型(BSON)
BYTE CBaseExpression::GetExpressionType(int nExpBsonOffset, CBaseBson& stBson)
{
	LPMATHEXPBSON lpExpBson;
	LPMATHEXPELEMENTBSON lpFieldBson;

	//如果根节点是函数类型的话，那么表达式一定是一个函数
	lpExpBson = (LPMATHEXPBSON)stBson.ConvertOffset2Addr(nExpBsonOffset);	
	if(lpExpBson->m_bOperator >= 40 && lpExpBson->m_bOperator < 50)
	{
		return MF_EXPRESSION_AGGREFUN;
	}
	else if(lpExpBson->m_bOperator >= 50 && lpExpBson->m_bOperator < 60)
	{
		return MF_EXPRESSION_COMMFUN;
	}
	else if(lpExpBson->m_bOperator == 0)
	{
		//表达式只有一个元素的情况，比如select sno from student 或 select 2 from student
		lpFieldBson = (LPMATHEXPELEMENTBSON)stBson.ConvertOffset2Addr(lpExpBson->m_nExpOffset1);
		if(lpFieldBson->m_bField)
		{
			return MF_EXPRESSION_FIELD;			//select sno from student这种情况
		}
		else
		{
			return MF_EXPRESSION_CONSTMATH;		//select 2 from student这种情况
		}
	}
	else
	{
		//表达式一定是一个四则运算表达式，此时需要遍历整个表达式树以判断表达式中是否包含字段或者聚合函数
		//如果表达式中包含字段或聚合函数则返回MF_EXPRESSION_VARMATH类型，否则返回MF_EXPRESSION_CONSTMATH
		if(lpExpBson->m_bExpressionType1 == 1)
		{
			BYTE bTemp = GetExpressionType(lpExpBson->m_nExpOffset1, stBson);
			if(bTemp == MF_EXPRESSION_AGGREFUN || bTemp == MF_EXPRESSION_FIELD || bTemp == MF_EXPRESSION_VARMATH)
			{
				return MF_EXPRESSION_VARMATH;
			}
		}
		else if(lpExpBson->m_bExpressionType1 == 0)
		{
			lpFieldBson = (LPMATHEXPELEMENTBSON)stBson.ConvertOffset2Addr(lpExpBson->m_nExpOffset1);
			if(lpFieldBson->m_bField)
			{
				return MF_EXPRESSION_VARMATH;			
			}
		}

		if(lpExpBson->m_bExpressionType2 == 1)
		{
			BYTE bTemp = GetExpressionType(lpExpBson->m_nExpOffset2, stBson);
			if(bTemp == MF_EXPRESSION_AGGREFUN || bTemp == MF_EXPRESSION_FIELD || bTemp == MF_EXPRESSION_VARMATH)
			{
				return MF_EXPRESSION_VARMATH;
			}
		}
		else if(lpExpBson->m_bExpressionType2 == 0)
		{
			lpFieldBson = (LPMATHEXPELEMENTBSON)stBson.ConvertOffset2Addr(lpExpBson->m_nExpOffset2);
			if(lpFieldBson->m_bField)
			{
				return MF_EXPRESSION_VARMATH;		
			}
		}
		return MF_EXPRESSION_CONSTMATH;
	}
}

int CBaseExpression::GetExpressionResult(CBaseBson& stBson, LPMATHEXPBSON lpMathExp, VARDATA& varResult)
{
	int nRet;
	VARDATA varValue1, varValue2;
	LPMATHEXPBSON pMathExpBson1, pMathExpBson2;
	LPMATHEXPELEMENTBSON lpFieldBson1, lpFieldBson2;

	//在Where条件中进行逻辑判断时会出现pMathExpression为NULL的情况，pMathExpression为NULL说明该表达式为真，直接返回1
	if(NULL == lpMathExp)
	{
		varResult.SetData(1);			
		return MF_OK;
	}

	//计算表达式1的结果
	if(3 == lpMathExp->m_bExpressionType1)
	{
		varValue1.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType1)
	{
		pMathExpBson1 = (LPMATHEXPBSON)(stBson.ConvertOffset2Addr(lpMathExp->m_nExpOffset1));	
		nRet = GetExpressionResult(stBson, pMathExpBson1, varValue1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson1 = (LPMATHEXPELEMENTBSON)(stBson.ConvertOffset2Addr(lpMathExp->m_nExpOffset1));
		nRet = GetDataValue(stBson, lpFieldBson1, varValue1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式2的结果
	if(3 == lpMathExp->m_bExpressionType2)
	{
		varValue2.SetData(0);
	}
	else if(1 == lpMathExp->m_bExpressionType2)
	{
		pMathExpBson2 = (LPMATHEXPBSON)(stBson.ConvertOffset2Addr(lpMathExp->m_nExpOffset2));	
		nRet = GetExpressionResult(stBson, pMathExpBson2, varValue2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//获得字段值
		lpFieldBson2 = (LPMATHEXPELEMENTBSON)(stBson.ConvertOffset2Addr(lpMathExp->m_nExpOffset2));
		nRet = GetDataValue(stBson, lpFieldBson2, varValue2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算表达式结果
	switch(lpMathExp->m_bOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_NULL:
		varResult = varValue1;
		break;
	case MF_EXECUTEPLAN_OPERATOR_PLUS:
		varResult = varValue1 + varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_MINUS:
		varResult = varValue1 - varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_MULTIPLY:
		varResult = varValue1 * varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_DIVIDE:
		varResult = varValue1 / varValue2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_LINK:
		nRet = varValue1.Link(stBson, varValue2, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		break;
	case MF_EXECUTEPLAN_OPERATOR_SIGNMINUS:
		varResult = varValue2 - varValue1;
		break;
	}
	return MF_OK;
}
