/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "ServerStatusManage.h"

CServerStatusManage::CServerStatusManage(void)
{
	m_pFileAddr			= NULL;
	m_pMemoryFileHead	= NULL;
	m_nMemoryShmId		= NULL;
	memset(m_arFile, 0, sizeof(m_arFile));
}

CServerStatusManage::~CServerStatusManage(void)
{
	m_pMemoryFileHead = NULL;
	if(m_pFileAddr != NULL)
	{
		CShareMemory::ShMemDetach(m_pFileAddr);
	}
	if(CShareMemory::ShareMemoryExsist(m_nMemoryShmId))
	{
		CShareMemory::CloseShareMemory(m_nMemoryShmId);
	}
}

//�����������ݶ�Ϊ�������ݣ������Ͳ���Ҫ���������ݿ���
int CServerStatusManage::LoadMemDBFileData(LPSYSTEMBLOCKHEAD lpSystemBlockHead)
{
	int i;
	BYTE bFileNo;
	LPFILE_MEMDBFILEINFO lpFileMemDBFileInfo;
	if(lpSystemBlockHead->m_nObjectID != MF_SYS_OBJECTTYPE_FILE)
	{
		//������Ӧ�ó����������
		return MF_INNER_SYS_OBJECTMAP_DATAERROR;
	}
	if(lpSystemBlockHead->m_nBlockDataStructSize != sizeof(FILE_MEMDBFILEINFO))
	{
		//�ṹ�巢���仯��
		return MF_INNER_ITEMDATASIZE_ERROR;
	}
	//ֱ�ӰѶ�������ת���ɽṹ��
	lpFileMemDBFileInfo = (LPFILE_MEMDBFILEINFO)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
	for(i = 0;i < lpSystemBlockHead->m_nDataNum; i++)
	{
		//���ɾ�����
		if(lpFileMemDBFileInfo[i].m_bDropFlag == 1)
		{
			//ֱ�Ӻ���
			continue;
		}
		bFileNo = lpFileMemDBFileInfo[i].m_bFileNo;
		m_arFile[bFileNo].m_bFileNo = bFileNo;
		m_arFile[bFileNo].m_bFileType = lpFileMemDBFileInfo[i].m_bFileType;
		m_arFile[bFileNo].m_pFileCMD  = &lpFileMemDBFileInfo[i].m_bFileCMD;
		m_arFile[bFileNo].m_nFileSize = lpFileMemDBFileInfo[i].m_nFileSize;
		m_arFile[bFileNo].m_pLoadSize = &lpFileMemDBFileInfo[i].m_nLoadSize;
	}
	return MF_OK;
}

int CServerStatusManage::Initialize()
{
	int nRet;
	key_t nShmKey;
	long long nDataOffset;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPBASEFILEBLOCKMAP lpBaseFileBlockMap;

	//�̶�ϵͳ�ļ����ڴ��ļ���
	nShmKey = MF_MEMFILE_BASEKEY + MF_SYS_FILETYPE_SYSFILE;
	m_nMemoryShmId = CShareMemory::OpenShareMemory(nShmKey, ("Global\\MemDBSysFile"));
	if(!CShareMemory::GetShareMemorySuccess(m_nMemoryShmId))
	{
		m_nMemoryShmId = 0;
		return MF_INNER_OPENMEMFILE_FAILED;//��ʧ��
	}

	m_pFileAddr = (LPBYTE)CShareMemory::ShMemAttach(m_nMemoryShmId);
	if(m_pFileAddr == NULL)
	{
		m_nMemoryShmId = 0;
		CShareMemory::CloseShareMemory(m_nMemoryShmId);
		return MF_INNER_MAPMEMFILE_FAILED;
	}
	m_pMemoryFileHead = (LPSYSTEMFILEHEAD)m_pFileAddr;
	if (m_pMemoryFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'S', 'F'))
	{
		m_pMemoryFileHead = NULL;
		CShareMemory::CloseShareMemory(m_nMemoryShmId);
		m_nMemoryShmId = 0;
		return MF_INNER_MAPMEMFILE_FAILED;
	}

	//�����ļ�����
	if(m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nID == MF_SYS_OBJECTTYPE_FILE)
	{
		//��ȡ�ļ�������Ϣ
		nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFullBlockMapOffset;
		while(nDataOffset != 0)
		{
			lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
			lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			nRet = LoadMemDBFileData(lpSystemBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
		}

		nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFreeBlockMapOffset;
		while(nDataOffset != 0)
		{
			lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
			lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			nRet = LoadMemDBFileData(lpSystemBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
		}
	}
	return MF_OK;
}

int CServerStatusManage::GetProgressStatus(double &dblProgress, long long &nTotalFileSize, long long &nLoadFileSize)
{
	int i;
	if(m_pMemoryFileHead == NULL)
	{
		return MF_FAILED;
	}
	else if(m_pMemoryFileHead->m_bStatus == 0)
	{
		dblProgress = 90.0;
		return MF_FAILED;
	}
	else
	{
		nTotalFileSize = 0;
		nLoadFileSize  = 0;
		dblProgress    = 10.0;
		for(i = 0;i < 255;i++)
		{
			if(m_arFile[i].m_bFileNo == 0)
			{
				continue;
			}
			nTotalFileSize += m_arFile[i].m_nFileSize;
			nLoadFileSize  += *m_arFile[i].m_pLoadSize;
		}
		if(nTotalFileSize != 0)
		{
			dblProgress = 10.0 + nLoadFileSize * 80.0/nTotalFileSize;
			return MF_OK;
		}
	}
	return MF_FAILED;
}

int CServerStatusManage::UpdateFileStatus(BYTE &bFileNO)
{
	int i, nRet;
	long long nDataOffset;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPBASEFILEBLOCKMAP lpBaseFileBlockMap;
	//�����ļ�����
	if(m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nID == MF_SYS_OBJECTTYPE_FILE)
	{
		//��ȡ�ļ�������Ϣ
		nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFullBlockMapOffset;
		while(nDataOffset != 0)
		{
			lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
			lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			nRet = LoadMemDBFileData(lpSystemBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
		}

		nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFreeBlockMapOffset;
		while(nDataOffset != 0)
		{
			lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
			lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			nRet = LoadMemDBFileData(lpSystemBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
		}
	}

	//����һ�������½����ļ�
	for(i = 0;i < 255;i++)
	{
		if(m_arFile[i].m_pFileCMD == NULL)
		{
			continue;
		}
		if(*m_arFile[i].m_pFileCMD == MF_SYS_FILECMD_NEWFILE)
		{
			bFileNO = m_arFile[i].m_bFileNo;
			return MF_OK;
		}
	}
	return MF_FAILED;
}

int CServerStatusManage::GetFileProgressStatus(BYTE bFileNO, long long &nFileSize, long long &nLoadSize)
{
	if(m_arFile[bFileNO].m_pFileCMD == NULL)
	{
		return MF_FAILED;
	}
	else if(*m_arFile[bFileNO].m_pFileCMD == MF_SYS_FILECMD_NEWFILE)
	{
		nFileSize = m_arFile[bFileNO].m_nFileSize;
		nLoadSize = *m_arFile[bFileNO].m_pLoadSize;
		return MF_OK;
	}
	else
	{
		return MF_FAILED;
	}
}
