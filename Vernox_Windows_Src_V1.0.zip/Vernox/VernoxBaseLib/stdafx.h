﻿// stdafx.h : 标准系统包含文件的包含文件，
// 或是经常使用但不常更改的
// 特定于项目的包含文件
//

#pragma once

#define WIN32_LEAN_AND_MEAN             			// 从 Windows 头中排除极少使用的资料
#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS      // 某些 CString 构造函数将是显式的

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN            // 从 Windows 头中排除极少使用的资料
#endif

#ifdef WIN32

//屏蔽C语言警告信息
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_NONSTDC_NO_DEPRECATE 


#include "targetver.h"
//#include <afx.h>
//#include <afxwin.h>         // MFC 核心组件和标准组件
//#include <comdef.h>
//#include <comutil.h>
//#include "afxtempl.h"
#include "windows.h"
#include "time.h"
#include "atlbase.h"
#include "atlcom.h"
#include <stdlib.h>

#include "MemDBCommonDef.h"
#include ".\TinyXML\tinyxml.h"
#else
#include "../Include/MemDBCommonDef.h"
#include "./TinyXML/tinyxml.h"
#include "LinuxCommonAPI.h"
#endif

#include <map>
#include <set>
#include<stack>
#include<queue>
#include <vector>
#include <string>
#include "CommonBaseAPI.h"
#include "MFString.h"
#include "BaseBson.h"
#include "ShareMemory.h"
using namespace std;
