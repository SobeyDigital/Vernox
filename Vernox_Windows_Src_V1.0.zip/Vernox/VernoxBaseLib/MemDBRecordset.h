﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "../Include/SobeyDBInterface.h"
class CMemDBRecordset : public ISobeyDBRecordset
{
private:
	typedef struct st_FIELD
	{	
		MF_SYS_FIELDTYPE              m_bFieldType;							//列类型
		BYTE						  m_bAllowNull;							//是否允许为空	
		MF_PARAMETER_FIELDTYPE        m_bFieldNameType;						//字段名类型(逻辑字段或原始字段)，实际列此值为0，且m_lpszName、m_lpszObjectName是有值的，否则m_lpszName、m_lpszObjectName为空值，且m_lpszTitle为表达式内容，超过30字符直接截掉。
		BYTE						  m_bMaxLen;			     			//保留字段
		BYTE						  m_bPrimaryKey;						//是否主键
		BYTE						  m_bAutoIncrement;						//是否自增字段
		BYTE						  m_bReserved[2];						//保留数据
		wchar_t                       m_lpszName[32];						//对象列名名称
		wchar_t						  m_lpszRsName[32];					    //rs:name用于存放没有别名的聚合函数和表达式
		wchar_t                       m_lpszTitle[32];						//对象列名返回名称，相当于SQL的AS功能，默认情况下m_lpszTitle和m_lpszName相同
		wchar_t                       m_lpszObjectName[32];					//对象名，为以后多表联合查询预留
		
		st_FIELD()
		{
			m_bFieldType		= 0;
			m_bAllowNull		= 0;
			m_bFieldNameType	= 0;
			m_bMaxLen			= 0;
			m_bPrimaryKey		= 0;
			m_bAutoIncrement	= 0;
			m_bReserved[0]		= 0;
			m_bReserved[1]		= 0;
			memset(m_lpszName, 0, 32*sizeof(wchar_t));
			memset(m_lpszRsName, 0, 32*sizeof(wchar_t));
			memset(m_lpszTitle, 0, 32*sizeof(wchar_t));
			memset(m_lpszObjectName, 0 ,32*sizeof(wchar_t));
		}
	
	}FIELD,*LPFIELD;

	//MYSQL
	enum mf_enum_mysql_timestamp_type
	{
		MYSQL_TIMESTAMP_NONE= -2, MYSQL_TIMESTAMP_ERROR= -1,
		MYSQL_TIMESTAMP_DATE= 0, MYSQL_TIMESTAMP_DATETIME= 1, MYSQL_TIMESTAMP_TIME= 2
	};

	typedef struct mf_st_mysql_time
	{
		unsigned int  year, month, day, hour, minute, second;
		unsigned long second_part;  /**< microseconds */
		char       neg;
		enum mf_enum_mysql_timestamp_type time_type;
	} MF_MYSQL_TIME;

private:
	LPBYTE					m_lpBuffer;						//结果集Buffer
	int						m_nRowNum;						//总行数
	int						m_nFieldNum;					//列数
	LPFIELD					m_lpFieldInfo;					//列信息
	LPRECORD				m_lpRecordset;					//结果集
	BOOL					m_bAutoRelease;					//是否自动释放
	BOOL				    m_bRecordsetCanModify;			//对象是否可以修改
	MF_DATABASE_TYPE	    m_bDatabaseType;				//数据库类型
	UPDATERECORDSETPLANBSON	m_stUpdateReocrdsetBson;		//修改结果集BSON


	int						m_nQueryRowNum;					//查询行数，结果集的原始行数，不包括插入的行
	int						m_nCurrentRowNo;				//当前行号
	long long				m_nInsertDataID;				//插入DataID
	vector<LPRECORD>		m_vecInsertRecord;				//插入记录
	LPRECORD				m_lpCurrentRecord;				//当前记录
public:
	CMemDBRecordset();
	~CMemDBRecordset(void);
private:
	WCHAR*  ConvertNumber2Char(long long nValue);
	WCHAR*  ConvertNumber2Char(double dblValue);
	WCHAR*  ConvertDate(DATE dtValue);
	WCHAR*  ConvertBinary(LPBYTE pValue, int nLen);
	WCHAR*  ConvertStr(char* pValue, int nLen);
	BOOL    ConvertStr(char* pSrc, WCHAR* pDest, int nLen);

private:
	long long	ConvertWChar2Number(WCHAR* lpszValue);
	double		ConvertWChar2Double(WCHAR* lpszValue);
	int			ConvertWChar2Date(WCHAR* lpszValue, DATE& dtResult);
	char*		ConvertWChar2Str(WCHAR* lpszValue, int& nLen);
#ifdef WIN32
	char*		ConvertBSTR2Str(BSTR bstrValue, int& nLen);
#endif
private:
	//解析行
	int AnalysisRow(LPBYTE lpRowBuffer, int nRowLen, RECORD& stRecordset);
	
	//获取执行字段
	int GetExecuteField(CBaseBson& stBson, LPRECORD lpRecord, LPRECORDHEAD lpRecordHead);

	//解析结果集，获取MemDB格式的UpdateRecordset执行计划
	int ParseRecordsetMemDB(CBaseBson& stBson, LPEXECUTEPLANBSON& lpExecutePlan);

public:
	//设置行数
	void SetRowNum(int nRowNum)
	{
		m_nQueryRowNum = nRowNum;
	}

	//获取行
	LPRECORD GetRow(int nNum)
	{
		return &m_lpRecordset[nNum];
	}

	//设置列
	int SetFieldValue(int nFieldNo, WCHAR* pValue);

public:
	//释放结果集资源函数
	void Free();
	void Release();
	
	//获取结果集行数
	int GetRowNum()
	{
		return m_nQueryRowNum;
	}

	//获取结果集列数
	int GetFieldNum()
	{
		return m_nFieldNum;
	}

	//获取结果集字段名
	wchar_t* FieldName(int nIndex);

	//获取结果集字段类型
	MF_SYS_FIELDTYPE FieldType(int nIndex);

	//向结果集中添加一行
	int AddNew(long long &nGetDataId);

	//删除结果集中的当前行
	int Delete();

	//判断结果集中当前行是否第一行
	BOOL bof();

	//判断结果集中当前行是否最后一行后一行
	BOOL eof();

	//设置结果集中的第一行为当前行
	int MoveFirst();

	//设置结果集中的下一行为当前行
	int MoveNext();

	//设置结果集中的前一行为当前行
	int MovePrevious();

	//设置结果集中的最后一行为当前行
	int MoveLast();

	//设置给定的DataID行为当前行
	int SetCurrentRow(long long nDataID);
	int SetCurrentRow(int nRowNo);

	//获取结果集中当前行的DataID
	int GetDataID(long long &llDataID);

	//获取结果集中当前行指定列的值(32位整数)
	int FieldValue(int nIndex, int &nValue);

	//获取结果集中当前行指定列的值(64位整数)
	int FieldValue(int nIndex, __int64 &nValue);

	//获取结果集中当前行指定列的值(浮点数)
	int FieldValue(int nIndex, double &dblValue);

	//获取结果集中当前行指定列的值(字符串数)
	int FieldValue(int nIndex, char* &pValue);

	//获取结果集中当前行指定列的值(字符串数,UNICODE编码格式)
	int FieldValue(int nIndex, wchar_t* &pValue);

	//获取结果集中当前行指定列的值(字符串数)
	int FieldValue(int nIndex, string &strValue);

	//获取结果集中当前行指定列的值(二进制数)
	int FieldValue(int nIndex, LPBYTE &lpValue, int &nSize);
	
	//设置结果集中当前行指定列的值(32位整数)
	int SetField(int nIndex, int nValue);

	//设置结果集中当前行指定列的值(64位整数)
	int SetField(int nIndex, __int64 nValue);

	//设置结果集中当前行指定列的值(浮点数)
	int SetField(int nIndex, double dblValue);

	//设置结果集中当前行指定列的值(字符串数)
	int SetField(int nIndex, char* lpValue);

	//设置结果集中当前行指定列的值(字符串数)
	int SetField(int nIndex, wchar_t* lpValue);

	//设置结果集中当前行指定列的值(二进制数)
	int SetField(int nIndex, LPBYTE lpValue, int nSize);

#ifdef WIN32
	//设置结果集中当前行指定列的值(BSTR)
	int SetField(int nIndex, const BSTR& bstrValue, int nLen);
	//设置结果集中当前行指定列的值(可变类型)
	int SetField(int nIndex, const VARIANT& varSrc);
#endif

public:
	//解析结果集
	int	AnalysisRecordset(LPBYTE lpRecordsetBuffer, BOOL bAutoRelease);

	//解析结果集，获取UpdateRecordset执行计划
	int ParseRecordset(CBaseBson& stBson, LPEXECUTEPLANBSON& lpExecutePlan);

	//清理行状态
	void ClearState();

	static int CreateInstance(ISobeyDBRecordset * &pRecordset);
};

