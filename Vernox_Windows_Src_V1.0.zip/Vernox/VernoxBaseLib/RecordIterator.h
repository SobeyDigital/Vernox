/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

//��¼������
class CRecordIterator
{
private:
	typedef struct  
	{
		UINT			m_nNextSectionOffset;	//��һ������Ƭ��ƫ��
	}BUFFERSECTIONHEAD, *LPBUFFERSECTIONHEAD;
public:
	CRecordIterator(void);
	~CRecordIterator(void);
private:
	LPBYTE				m_lpBuffer;
	LPEXECUTEPLANBSON	m_lpExecutePlan;
	LPBYTE				m_lpCurrentSection;			   				//��ǰ����Ƭ��
	USHORT				m_nBufferSectionNum;
	LPBYTE				m_arrBufferSection[MAX_SECTION_BUFFER];		//����Ƭ������

	UINT				m_nCurrentBufferNo;
	UINT				m_nCurrentRecordNo;
	LPBYTE				m_lpCurrentBuffer;
	LPRECORDHEAD		m_lpRecord;
public:
	void Inital(LPBYTE lpBuffer);

	//�ƶ�����һ����¼
	void Move2FirstRecord();

	//��һ����¼��Ϣ
	void NextRecord(LPRECORDHEAD& lpRecordHead);

};
