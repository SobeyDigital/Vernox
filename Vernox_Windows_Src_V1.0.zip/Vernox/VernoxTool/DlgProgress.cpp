/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// DlgProgress.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Resource.h"
#include "process.h"
#include "DlgProgress.h"


// CDlgProgress �Ի���
extern int ExceptionHandlerBox(ULONG ulCode, EXCEPTION_POINTERS* lpExceptionPointer);
#define WM_USER_FINISHED		(WM_USER + 0x401)

IMPLEMENT_DYNAMIC(CDlgProgress, CDialog)

CDlgProgress::CDlgProgress(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgProgress::IDD, pParent)
{
	m_plistObjectName = NULL;
	m_lpParam = NULL;
	m_pVernoxProgressCallback = NULL;
	m_bCancelFlag = FALSE;
	m_hCallbackThread = NULL;
	m_nTotal = 0;
	memset(m_lpTitle, 0, sizeof(m_lpTitle));
}

CDlgProgress::~CDlgProgress()
{
}

void CDlgProgress::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROGRESS, m_ctlProgress);
	DDX_Control(pDX, IDC_STATIC_INFO, m_staticInfo);
}


BEGIN_MESSAGE_MAP(CDlgProgress, CDialog)
	ON_MESSAGE(WM_USER_FINISHED, OnFinished)
END_MESSAGE_MAP()


// CDlgProgress ��Ϣ��������

BOOL CDlgProgress::OnInitDialog()
{
	DWORD dwThreadID;
	CDialog::OnInitDialog();

	SetWindowText(m_strTitle);
	m_ctlProgress.SetRange32(0, 100);
	m_ctlProgress.SetPos(0);

	dwThreadID = 0;
	m_hCallbackThread	= (HANDLE)_beginthreadex(NULL, 0, TaskProgressThread, (LPVOID)this, 0, (unsigned int *)&dwThreadID);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

int CDlgProgress::TaskProgressCore()
{
	if(m_pVernoxProgressCallback != NULL)
	{
		m_pVernoxProgressCallback(this, m_strFileName, *m_plistObjectName, m_lpParam);
	}
	return 0;
}

unsigned int WINAPI CDlgProgress::TaskProgressThread(LPVOID data)
{
	CDlgProgress *pDlg;
	__try
	{
		pDlg = (CDlgProgress *)data;
		pDlg->TaskProgressCore();
	}
	__except(ExceptionHandlerBox(GetExceptionCode(), GetExceptionInformation()))
	{
	}
	CloseHandle(pDlg->m_hCallbackThread);
	pDlg->m_hCallbackThread = NULL;
	pDlg->PostMessage(WM_USER_FINISHED, 0, 0);
	return 0;
}


void CDlgProgress::OnCancel()
{
	int nRet;
	nRet = MessageBox(_T("�Ƿ�ǿ����ֹ��"), _T("����"), MB_OKCANCEL);
	if(nRet != IDOK)
	{
		return;
	}
	m_bCancelFlag = TRUE;
	WaitForSingleObject(m_hCallbackThread, 120000);
	CDialog::OnCancel();
}

void CDlgProgress::OnOK()
{
	//CDialog::OnOK();
}

LRESULT CDlgProgress::OnFinished(WPARAM w, LPARAM l)
{
	if(m_hCallbackThread == NULL && !m_bCancelFlag)
	{
		CDialog::OnOK();
	}
	return 0;
}

BOOL CDlgProgress::SetProcess(char *lpszTitle, int nTotal, int nPos)
{
	if(nTotal != 0 && m_nTotal != nTotal)
	{
		m_nTotal = nTotal;
		m_ctlProgress.SetRange32(0, nTotal);
	}
	m_ctlProgress.SetPos(nPos);
	if(strcmp(m_lpTitle, lpszTitle) != 0)
	{
		WCHAR lpTitle[32];
		strcpy(m_lpTitle, lpszTitle);
		memset(lpTitle, 0, sizeof(lpTitle));
		MultiByteToWideChar(CP_UTF8, NULL, lpszTitle, -1, lpTitle, 32);
		m_staticInfo.SetWindowText(lpTitle);
	}
	if(m_bCancelFlag)
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

BOOL VernoxProcessCallback(LPVOID lpParam, char *lpszTitle, int nTotal, int nPos)
{
	CDlgProgress *pProgress = (CDlgProgress *)lpParam;
	if(pProgress != NULL)
	{
		return pProgress->SetProcess(lpszTitle, nTotal, nPos);
	}
	return TRUE;
}