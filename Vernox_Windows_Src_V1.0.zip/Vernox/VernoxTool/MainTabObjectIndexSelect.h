/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "afxwin.h"


// CMainTabObjectIndexSelect �Ի���

class CMainTabObjectIndexSelect : public CDialog
{
	DECLARE_DYNAMIC(CMainTabObjectIndexSelect)

public:
	CMainTabObjectIndexSelect(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMainTabObjectIndexSelect();

// �Ի�������
	enum { IDD = IDD_MAINTAB_OBJECT_INDEX_SELECT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	int m_nCount;
	CString* m_pData;
	CListCtrl* m_pListIndex;
	int m_nIndexRowNum;
	int m_nIndexColNum;
	BOOL m_bComma;

	CListBox m_listboxLeft;
	CListBox m_listboxRight;

public:
	void SetInitData(CString* pstrText, int nCount, CListCtrl* pListIndex, int nIndexRowNum, int nIndexColNum, BOOL bComma);

public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedBtnMoveRight();
	afx_msg void OnBnClickedBtnMoveLeft();
	afx_msg void OnLbnDblclkListboxUnselected();
	afx_msg void OnLbnDblclkListboxSelected();
};
