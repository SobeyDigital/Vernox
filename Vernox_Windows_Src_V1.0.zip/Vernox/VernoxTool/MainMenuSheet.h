/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "MainMenuSheetObjectSelect.h"

extern ISobeyDBConnectionPtr g_pSobeyInterface;
// CMainMenuSheet �Ի���

class CDlgProgress;
class CMainMenuSheet : public CDialog
{
	DECLARE_DYNAMIC(CMainMenuSheet)

public:
	CMainMenuSheet(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMainMenuSheet();

// �Ի�������
	enum { IDD = IDD_MAINMENU_SHEET };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

public:
	CMainMenuSheetObjectSelect m_dlgObjectSelect;

protected:
	int CMessageBox(LPCTSTR lpText, UINT nType = (MB_OK|MB_SYSTEMMODAL))
	{
		return MessageBox(lpText, 0, nType);
	}

	static BOOL CALLBACK ExportObjectThread(CDlgProgress *pProgress, LPCTSTR lpszFileName, list<CString> &listObjectName, LPVOID lpParam);
	static BOOL CALLBACK ImportObjectThread(CDlgProgress *pProgress, LPCTSTR lpszFileName, list<CString> &listObjectName, LPVOID lpParam);
protected:
	virtual void OnCancel();
	virtual void OnOK();
public:
	afx_msg void OnBnClickedBtnCreateObject();
	afx_msg void OnBnClickedBtnEditObject();
	afx_msg void OnBnClickedBtnQueryObject();
	afx_msg void OnBnClickedBtnExportObject();
	afx_msg void OnBnClickedBtnImportObject();
};
