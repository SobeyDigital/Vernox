/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// stdafx.cpp : ֻ������׼�����ļ���Դ�ļ�
// SobeyMemTool.pch ����ΪԤ����ͷ
// stdafx.obj ������Ԥ����������Ϣ

#include "stdafx.h"

extern ISobeyDBConnectionPtr g_pSobeyInterface;

// wchar -> utf8
char* SMT_UnicodeToUTF8(const wchar_t * lpwData)
{
	int nLength, nwLength;
	char *lpData;

	nLength = 0;
	nwLength = 0;
	lpData = NULL;

	if (lpwData == NULL)
	{
		return NULL;
	}
	nwLength = (int)wcslen(lpwData);
	if (nwLength == 0)
	{
		return NULL;
	}

	nLength = WideCharToMultiByte(CP_UTF8, 0, lpwData,  nwLength, NULL, NULL, NULL, NULL) + 1;
	lpData = new char[nLength];
	if (lpData == NULL)
	{
		return NULL;
	}
	memset(lpData, 0, nLength);

	WideCharToMultiByte(CP_UTF8, 0, lpwData, nwLength, lpData, nLength, NULL, NULL);
	return lpData;
}

// utf8 -> wchar
wchar_t* SMT_UTF8ToUnicode(const char * lpszData)
{
	int nLength, nwLength;
	wchar_t *lpwsData;

	nLength = 0;
	nwLength = 0;
	lpwsData = NULL;

	if (lpszData == NULL)
	{
		return NULL;
	}
	nLength = (int)strlen(lpszData);
	if (nLength == 0)
	{
		return NULL;
	}

	nwLength = MultiByteToWideChar(CP_UTF8, NULL, lpszData, nLength, NULL, NULL) + 1;
	lpwsData = new wchar_t[nwLength];
	if (lpwsData == NULL)
	{
		return NULL;
	}
	memset(lpwsData, 0, (nwLength)*sizeof(wchar_t));

	MultiByteToWideChar(CP_UTF8, NULL, lpszData, nLength, lpwsData, nwLength);
	return lpwsData;
}

int SplitSql(char* lpszBuffer, int nLen, vector<char*>& vecSql)
{
	int i;
	char *pSql, chWord;
	BOOL bSingleQuote, bDoubleQuote;

	pSql   = NULL;
	bSingleQuote = FALSE;
	bDoubleQuote = FALSE;

	for(i = 0; i < nLen; i++)
	{
		if(bSingleQuote)
		{
			if(lpszBuffer[i] == '\'')
			{
				if(lpszBuffer[i + 1] == '\'')
				{
					i++;
					continue;
				}
				bSingleQuote = FALSE;
			}
			else
			{
				continue;
			}
		}
		else if(bDoubleQuote)
		{
			if(lpszBuffer[i] == '\"')
			{
				bDoubleQuote = FALSE;
			}
			else
			{
				continue;
			}
		}
		else
		{
			if(lpszBuffer[i] == '\'')
			{
				bSingleQuote = TRUE;
			}
			else if(lpszBuffer[i] == '\"')
			{
				bDoubleQuote = TRUE;
			}
			else if(lpszBuffer[i] == ';')
			{
				chWord = lpszBuffer[i + 1];
				lpszBuffer[i + 1] = 0;

				lpszBuffer[i] = 0;
				vecSql.push_back(pSql);
				lpszBuffer[i + 1] = chWord;

				pSql = NULL;
			}
			else if(lpszBuffer[i] == ' ' || lpszBuffer[i] == '	' || lpszBuffer[i] == '\r' || lpszBuffer[i] == '\n')
			{
				//���Զ���ո�ͷָ���
				continue;
			}
			else if(pSql == NULL)
			{
				pSql = lpszBuffer + i;
			}
		}
	}
	if(bSingleQuote)
	{
		return MF_PARSECMD_INVALID_STRING_ERROR;
	}

	if(lpszBuffer[i - 1] != ';')
	{
		if(pSql != NULL)
		{
			vecSql.push_back(pSql);
		}
	}
	return MF_OK;
}


//ȥ��ǰ��ո�
char* RemoveSpaceFromString(char* lpStr)
{
	char* pSql;
	int nSqlLength;

	if (lpStr == NULL)
	{
		return NULL;
	}

	pSql = lpStr;
	while (TRUE)
	{
		if (pSql[0] == ' ')
		{
			pSql++;
		} 
		else
		{
			break;
		}
	}
	nSqlLength = strlen(pSql);
	while (TRUE)
	{
		if (pSql[nSqlLength-1] == ' ')
		{
			nSqlLength--;
			pSql[nSqlLength] = 0;
		} 
		else
		{
			break;
		}
	}

	return pSql;
}

//����SQL��������
//-1���쳣
//0������ִ�мƻ���������֧���������ͣ�ͳһ��GetRecordSet���棩
//1��DQL��䣨GetRecordSet��
//2��DML��䣨Execute��
//3��DDL��䣨Execute��
//4��updaterecordset�����ﲻ֧��
//MF_PARSECMD_EMPTY_STRING���մ�
//
//lpSql������sqlʵ����ʼλ��
//lpSql��ı�ָ��λ�ã��ⲿbuffer��ע���ͷ�
int ParseSqlType(char* &lpSql)
{
	char *pSql, *pSqlTemp;
	try
	{
		if (lpSql == NULL)
		{
			return -1;
		}
		pSql = lpSql;

		//ȥ��ǰ��ո�
		pSql = RemoveSpaceFromString(pSql);
		if (pSql[0] == 0)
		{
			return MF_PARSECMD_EMPTY_STRING;
		}
		pSqlTemp = pSql;						//��¼һ��

		//����ָ������
#ifdef WIN32
		if (strnicmp(pSql, "vernox:", 6) == 0 )
		{
			pSql = pSql + 6;
			pSql = RemoveSpaceFromString(pSql);
		} 

		if (strnicmp(pSql, "explain ", 8) == 0)
		{
			//����ִ�мƻ�
			lpSql = pSql + 8;
			return 0;
		} 
		else if (strnicmp(pSql, "select", 6) == 0)
		{
			//DQL���
			lpSql = pSql;
			return 1;
		} 
		else if (strnicmp(pSql, "insert", 6) == 0 || strnicmp(pSql, "update", 6) == 0 || strnicmp(pSql, "delete", 6) == 0)
		{
			//DML���
			lpSql = pSql;
			return 2;
		} 
		else if (strnicmp(pSql, "create", 6) == 0 || strnicmp(pSql, "revoke", 6) == 0 || strnicmp(pSql, "alter", 5) == 0 || strnicmp(pSql, "grant", 5) == 0 || strnicmp(pSql, "drop", 4) == 0)
		{
			//DDL���
			lpSql = pSql;
			return 3;
		} 
		else
		{
			//���ﲻ֧��updaterecordset
			return 4;
		}
#else
		if (strncasecmp(pSql, "vernox:", 6) == 0 )
		{
			pSql = pSql + 6;
			pSql = RemoveSpaceFromString(pSql);
		} 

		nSqlType = -1;
		if (strncasecmp(pSql, "explain ", 8) == 0)
		{
			//����ִ�мƻ�
			lpSql = pSql + 8;
			return 0;
		} 
		else if (strncasecmp(pSql, "select", 6) == 0)
		{
			//DQL���
			lpSql = pSql;
			return 1;
		} 
		else if (strncasecmp(pSql, "insert", 6) == 0 || strncasecmp(pSql, "update", 6) == 0 || strncasecmp(pSql, "delete", 6) == 0)
		{
			//DML���
			lpSql = pSql;
			return 2;
		} 
		else if (strncasecmp(pSql, "create", 6) == 0 || strncasecmp(pSql, "revoke", 6) == 0 || strncasecmp(pSql, "alter", 5) == 0 || strncasecmp(pSql, "grant", 5) == 0 || strncasecmp(pSql, "drop", 4) == 0)
		{
			//DDL���
			lpSql = pSql;
			return 3;
		} 
		else
		{
			//���ﲻ֧��updaterecordset
			return 4
		}
#endif

		return -2;
	}
	catch (...)
	{
		return -3;
	}
	return -4;
}

ULONG StringToIpAddress(char* lpIpAddress)
{
	ULONG ulIP;
	if (lpIpAddress == NULL)
	{
		return INADDR_NONE;
	}
	ulIP = ntohl(inet_addr(lpIpAddress));
	if (ulIP == INADDR_NONE)
	{
		//ip�Ƿ�
		//�������ַ�����������������һ��
		hostent *phostent;
		phostent = gethostbyname(lpIpAddress);
		if(phostent == NULL)
		{
			return INADDR_NONE;
		}

		////�����������IP
		//int nAdapter = 0;
		//ULONG ulIPAddressList[8] = {0};
		//for(nAdapter = 0; phostent->h_addr_list[nAdapter]; nAdapter++)
		//{   
		//	ulIPAddressList[nAdapter] = ntohl(((IN_ADDR*)phostent->h_addr_list[nAdapter])->s_addr);
		//	if ((ulIPAddressList[nAdapter] == 0) || (ulIPAddressList[nAdapter] == INADDR_NONE))
		//	{
		//		break;
		//	}
		//	if (nAdapter >= 8)
		//	{
		//		break;
		//	}
		//}

		ulIP = ntohl(((IN_ADDR*)phostent->h_addr_list[0])->s_addr);

		return ulIP;
	}
	else
	{
		return ulIP;
	}

	return INADDR_NONE;
}

#define CONVERT_FROM_BYTE_TO_T 1099511627776  //1T
#define CONVERT_FROM_BYTE_TO_G 1073741824    //1G
#define CONVERT_FROM_BYTE_TO_M 1048576      //1M
#define CONVERT_FROM_BYTE_TO_K 1024        //1K

#define ConvertSpace(Space, strSpace)\
{\
	CString strUnit;\
	float fSpace;\
	if(Space >= CONVERT_FROM_BYTE_TO_T || Space <= -CONVERT_FROM_BYTE_TO_T)\
{\
	fSpace = (float)Space/(float)CONVERT_FROM_BYTE_TO_T;\
	strUnit = _T(" TB");\
}\
  else if(Space >= CONVERT_FROM_BYTE_TO_G || Space <= -CONVERT_FROM_BYTE_TO_G)\
{\
	fSpace = (float)Space/(float)CONVERT_FROM_BYTE_TO_G;\
	strUnit = _T(" GB");\
}\
  else if(Space >= CONVERT_FROM_BYTE_TO_M || Space <= -CONVERT_FROM_BYTE_TO_M)\
{\
	fSpace = (float)Space/(float)CONVERT_FROM_BYTE_TO_M;\
	strUnit = _T(" MB");\
}\
  else if(Space >= CONVERT_FROM_BYTE_TO_K || Space <= -CONVERT_FROM_BYTE_TO_K)\
{\
	fSpace = (float)Space/(float)CONVERT_FROM_BYTE_TO_K;\
	strUnit = _T(" KB");\
}\
  else\
{\
	fSpace = (float)Space;\
	strUnit = _T(" bytes");\
}\
	if((fSpace - 10.0 < 0 && fSpace >= 0)|| (fSpace + 10.0 > 0 && fSpace < 0))\
{\
	fSpace = floor(fSpace * 100)/100;\
	strSpace.Format(_T("%.2f%s"), fSpace, strUnit);\
}\
  else if((fSpace - 100.0 < 0 && fSpace >= 0)||(fSpace + 100.0 > 0 && fSpace < 0))\
{\
	fSpace = floor(fSpace * 10)/10;\
	strSpace.Format(_T("%.1f%s"), fSpace, strUnit);\
}\
  else\
{\
	fSpace = floor(fSpace);\
	strSpace.Format(_T("%.0f%s"), fSpace, strUnit);\
}\
}


#include <dbghelp.h>

#pragma comment (lib, "dbghelp.lib")
#define EXCEPTION_NO_MEMORY STATUS_NO_MEMORY

CString GetExceptionNameEx(unsigned code)
{
	CString strMsg;
	switch (code)
	{
	case EXCEPTION_NO_MEMORY:
		strMsg = _T("No Memory");
		break;
	case EXCEPTION_ACCESS_VIOLATION :
		strMsg = _T("Access Violation");
		break;
	case EXCEPTION_DATATYPE_MISALIGNMENT :
		strMsg = _T("Datatype Misalignment");
		break;
	case EXCEPTION_BREAKPOINT :
		strMsg = _T("Breakpoint");
		break;
	case EXCEPTION_SINGLE_STEP :
		strMsg = _T("Single Step");
		break;
	case EXCEPTION_ARRAY_BOUNDS_EXCEEDED :
		strMsg = _T("Array Bounds Exceeded");
		break;
	case EXCEPTION_FLT_DENORMAL_OPERAND :
		strMsg = _T("Float Denormal Operand");
		break;
	case EXCEPTION_FLT_DIVIDE_BY_ZERO :
		strMsg = _T("Float Divide by Zero");
		break;
	case EXCEPTION_FLT_INEXACT_RESULT :
		strMsg = _T("Float Inexact Result");
		break;
	case EXCEPTION_FLT_INVALID_OPERATION :
		strMsg = _T("Float Invalid Operation");
		break;
	case EXCEPTION_FLT_OVERFLOW :
		strMsg = _T("Float Overflow");
		break;
	case EXCEPTION_FLT_STACK_CHECK :
		strMsg = _T("Float Stack Check");
		break;
	case EXCEPTION_FLT_UNDERFLOW :
		strMsg = _T("Float Underflow");
		break;
	case EXCEPTION_INT_DIVIDE_BY_ZERO :
		strMsg = _T("Integer Divide by Zero");
		break;
	case EXCEPTION_INT_OVERFLOW :
		strMsg = _T("Integer Overflow");
		break;
	case EXCEPTION_PRIV_INSTRUCTION :
		strMsg = _T("Privileged Instruction");
		break;
	case EXCEPTION_IN_PAGE_ERROR :
		strMsg = _T("In Page Error");
		break;
	case EXCEPTION_ILLEGAL_INSTRUCTION :
		strMsg = _T("Illegal Instruction");
		break;
	case EXCEPTION_NONCONTINUABLE_EXCEPTION :
		strMsg = _T("Noncontinuable Exception");
		break;
	case EXCEPTION_STACK_OVERFLOW :
		strMsg = _T("Stack Overflow");
		break;
	case EXCEPTION_INVALID_DISPOSITION :
		strMsg = _T("Invalid Disposition");
		break;
	case EXCEPTION_GUARD_PAGE :
		strMsg = _T("Guard Page");
		break;
	case EXCEPTION_INVALID_HANDLE :
		strMsg = _T("Invalid Handle");
		break;
	case 0xE06D7363 :
		strMsg = _T("Microsoft C++ Exception");
		break;
	default :
		strMsg.Format(_T("0X%08X"),code);
	};
	return strMsg;
}

CString GetCurrentStackEx(ULONG ulCode, CONTEXT * pctx, long nMaxFrame)
{
	CString		strTemp,strMsg,strRowMsg, strLine;
#ifdef _M_X64
	int nFrame;
	HMODULE	hMod;
	DWORD dwTemp;
	BYTE symbol [ 512 ];
	STACKFRAME64 pframe;
	DWORD64 dwDisplacement;
	IMAGEHLP_LINE img_line;
	HANDLE		hProc,hThread;
	TCHAR lpszFileName[MAX_PATH];
	PIMAGEHLP_SYMBOL pSym = (PIMAGEHLP_SYMBOL)&symbol;
	ZeroMemory(&pframe, sizeof(STACKFRAME64));

	hProc = GetCurrentProcess();
	hThread = GetCurrentThread();
	::SymInitialize(hProc, 0, TRUE);

	strMsg.Format(_T("ExceptionName:%s		ExceptionCode:0X%X\r\n\r\n"), GetExceptionNameEx(ulCode), ulCode);
	strMsg += _T("[Offset]ModuleFileName  FunctionName  SourceFileName[LN:LineNO]\r\n");

	memset(&pframe, 0, sizeof(STACKFRAME64));
	pframe.AddrPC.Offset       = pctx->Rip;
	pframe.AddrPC.Mode         = AddrModeFlat;
	pframe.AddrStack.Offset    = pctx->Rsp;
	pframe.AddrStack.Mode      = AddrModeFlat;
	pframe.AddrFrame.Offset    = pctx->Rbp;
	pframe.AddrFrame.Mode      = AddrModeFlat;

	for(nFrame = 0;nFrame < nMaxFrame;nFrame++)
	{
		if(!StackWalk64 (IMAGE_FILE_MACHINE_AMD64,
			hProc, 
			hThread, 
			&pframe, 
			pctx,
			NULL,
			SymFunctionTableAccess64,
			SymGetModuleBase64,
			NULL))
			break;

		if (pframe.AddrFrame.Offset == 0)  
		{  
			break;  
		}

		//��ȡ�ļ���ַ
		strLine = _T("");
		hMod = (HMODULE)SymGetModuleBase (hProc, pframe.AddrPC.Offset);
		if (hMod)
		{
			memset(lpszFileName,0,MAX_PATH*sizeof(TCHAR));
			GetModuleFileName(hMod, lpszFileName, MAX_PATH);
			strTemp.Format(_T("[%I64x]%s"),pframe.AddrPC.Offset,lpszFileName);
			strLine += strTemp;
		}
		memset(&img_line, 0, sizeof(IMAGEHLP_LINE));
		img_line.SizeOfStruct = sizeof(IMAGEHLP_LINE);

		//��ȡ������
		dwDisplacement	= 0;
		dwTemp			= 0;
		memset(pSym, 0, sizeof(symbol)) ;
		pSym->SizeOfStruct = sizeof(IMAGEHLP_SYMBOL) ;
		pSym->MaxNameLength = sizeof(symbol) - sizeof(IMAGEHLP_SYMBOL);
		if(SymGetSymFromAddr64(hProc, pframe.AddrPC.Offset, &dwDisplacement, pSym))
		{
			strTemp = pSym->Name;
			if(nFrame == 0 && strTemp == _T("MyExceptionHandler"))
			{
				continue;
			}
			strLine += _T("  ")+strTemp;
		}

		//��ȡ�к�
		if (SymGetLineFromAddr64 (hProc, pframe.AddrPC.Offset, &dwTemp, &img_line))
		{
			strTemp = img_line.FileName;
			strRowMsg.Format(_T("  %s[LN:%d]"),strTemp,img_line.LineNumber);
			strLine += strRowMsg;
		}
		strMsg += strLine + _T("\r\n");
	}
	::SymCleanup(hProc);
#else
	int nFrame;
	BYTE symbol [512];
	HMODULE		hMod;
	STACKFRAME	pframe;
	DWORD dwDisplacement;
	IMAGEHLP_LINE img_line;
	HANDLE		hProc,hThread;
	TCHAR lpszFileName[MAX_PATH];
	PIMAGEHLP_SYMBOL pSym = (PIMAGEHLP_SYMBOL)&symbol;
	hProc = GetCurrentProcess();
	hThread = GetCurrentThread();
	::SymInitialize(hProc, 0, TRUE);

	strMsg.Format(_T("ExceptionName:%s      ExceptionCode:0X%X\r\n\r\n"), GetExceptionNameEx(ulCode), ulCode);
	strMsg += _T("[Offset]ModuleFileName  FunctionName  SourceFileName[LN:LineNO]\r\n");

	memset(&pframe, 0, sizeof(STACKFRAME));
	pframe.AddrPC.Offset       = pctx->Eip;
	pframe.AddrPC.Mode         = AddrModeFlat;
	pframe.AddrStack.Offset    = pctx->Esp;
	pframe.AddrStack.Mode      = AddrModeFlat;
	pframe.AddrFrame.Offset    = pctx->Ebp;
	pframe.AddrFrame.Mode      = AddrModeFlat;

	for(nFrame = 0;nFrame < nMaxFrame;nFrame++)
	{
		if(!StackWalk (IMAGE_FILE_MACHINE_I386,
			hProc, 
			hThread, 
			&pframe, 
			pctx,
			(PREAD_PROCESS_MEMORY_ROUTINE)ReadProcessMemory,
			SymFunctionTableAccess,
			SymGetModuleBase,
			0))
			break;

		if (pframe.AddrFrame.Offset == 0)
		{
			break;
		}

		strLine = _T("");
		hMod = (HMODULE)SymGetModuleBase (hProc, pframe.AddrPC.Offset);
		if (hMod)
		{
			memset(lpszFileName,0,MAX_PATH*sizeof(TCHAR));
			GetModuleFileName(hMod, lpszFileName, MAX_PATH);
			strTemp.Format(_T("[%08x]%s"),pframe.AddrPC.Offset,lpszFileName);
			strLine += strTemp;
		}
		memset(&img_line, 0, sizeof(IMAGEHLP_LINE));
		img_line.SizeOfStruct = sizeof(IMAGEHLP_LINE);

		dwDisplacement = 0;
		memset(pSym, 0, sizeof(symbol)) ;
		pSym->SizeOfStruct = sizeof(IMAGEHLP_SYMBOL) ;
		pSym->MaxNameLength = sizeof(symbol) - sizeof(IMAGEHLP_SYMBOL);
		if(SymGetSymFromAddr(hProc, pframe.AddrPC.Offset, &dwDisplacement, pSym))
		{
			strTemp = pSym->Name;
			if(nFrame == 0 && strTemp == _T("MyExceptionHandler"))
			{
				continue;
			}
			strLine += _T("  ")+strTemp;
		}
		if (SymGetLineFromAddr (hProc, pframe.AddrPC.Offset, &dwDisplacement, &img_line))
		{
			strTemp = img_line.FileName;
			strRowMsg.Format(_T("  %s[LN:%d]"),strTemp,img_line.LineNumber);
			strLine += strRowMsg;
		}
		strMsg += strLine + _T("\r\n");
	}
	::SymCleanup(hProc);
#endif
	return strMsg;
}

int ExceptionHandlerBox(ULONG ulCode, EXCEPTION_POINTERS* lpExceptionPointer)
{
	CString strText, strMsg;
	strText = GetCurrentStackEx(ulCode, lpExceptionPointer->ContextRecord, 20);
	::MessageBox(NULL, strText, _T("�쳣"), MB_OK|MB_SYSTEMMODAL);
	return EXCEPTION_EXECUTE_HANDLER;
}