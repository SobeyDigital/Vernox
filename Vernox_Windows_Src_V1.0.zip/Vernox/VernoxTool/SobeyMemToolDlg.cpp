/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// SobeyMemToolDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "SobeyMemToolDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CSobeyMemToolDlg �Ի���




CSobeyMemToolDlg::CSobeyMemToolDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSobeyMemToolDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON_VERNOX);
	m_bSpliting = FALSE;
	m_ptOld = CPoint(0,0);
	m_iOffsetX = 0;
}

CSobeyMemToolDlg::~CSobeyMemToolDlg()
{
	STRUCT_TABPAGE st;
	list<STRUCT_TABPAGE>::iterator iter;
	while (m_listMainTab.size())
	{
		m_tabMain.DeleteItem(0);

		st = m_listMainTab.front();
		m_listMainTab.pop_front();
		DeleteMainTabItem(st);
	}
}

void CSobeyMemToolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TAB_MENU, m_tabMenu);
	DDX_Control(pDX, IDC_TREE_DATABASE_STRUCTURE, m_treeDB);
	DDX_Control(pDX, IDC_TAB_MAIN, m_tabMain);
	DDX_Control(pDX, IDC_STATIC_SEPARATOR, m_ctrlSeparator);
}

BEGIN_MESSAGE_MAP(CSobeyMemToolDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_LOGOUT, &CSobeyMemToolDlg::OnBnClickedBtnLogout)
	ON_BN_CLICKED(IDC_BTN_EXIT, &CSobeyMemToolDlg::OnBnClickedBtnExit)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_MENU, &CSobeyMemToolDlg::OnTcnSelchangeTabMenu)
	ON_BN_CLICKED(IDC_BTN_EXECUTE, &CSobeyMemToolDlg::OnBnClickedBtnExecute)
	ON_BN_CLICKED(IDC_BTN_REFRESH, &CSobeyMemToolDlg::OnBnClickedBtnRefresh)
	ON_NOTIFY(NM_RCLICK, IDC_TAB_MAIN, &CSobeyMemToolDlg::OnNMRClickTabMain)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_MAIN, &CSobeyMemToolDlg::OnTcnSelchangeTabMain)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BTN_MAKE_UPPER, &CSobeyMemToolDlg::OnBnClickedBtnMakeUpper)
	ON_BN_CLICKED(IDC_BTN_MAKE_LOWER, &CSobeyMemToolDlg::OnBnClickedBtnMakeLower)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()


// CSobeyMemToolDlg ��Ϣ��������

BOOL CSobeyMemToolDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	//////////////////////////////////////////////////////////////////////////
	//��Ա������ʼ��
	memset(m_cBufferDisplay, 0, sizeof(m_cBufferDisplay));
	memset(m_cBufferTrans, 0, sizeof(m_cBufferTrans));
	memset(m_wBufferDisplay, 0, sizeof(m_wBufferDisplay));

	m_nTabCount = 1;

	//////////////////////////////////////////////////////////////////////////
	//��ʼ��tabMenu
	m_tabMenu.InsertItem(0, _T("�ļ�"));
	m_tabMenu.InsertItem(1, _T("�༭"));
	m_tabMenu.InsertItem(2, _T("����"));
	m_tabMenu.InsertItem(3, _T("����"));

	m_dlgMainMenuFile.Create(IDD_MAINMENU_FILE, GetDlgItem(IDC_TAB_MENU));
	m_dlgMainMenuEdit.Create(IDD_MAINMENU_EDIT, GetDlgItem(IDC_TAB_MENU));
	m_dlgMainMenuSheet.Create(IDD_MAINMENU_SHEET, GetDlgItem(IDC_TAB_MENU));
	m_dlgMainMenuTool.Create(IDD_MAINMENU_TOOL, GetDlgItem(IDC_TAB_MENU));

	this->GetClientRect(&m_rcThis);
	m_tabMenu.GetClientRect(&m_rcMenu); 
	m_rcMenuTab.top = m_rcMenu.top + 22; 
	m_rcMenuTab.bottom = m_rcMenu.bottom - 2; 
	m_rcMenuTab.left = m_rcMenu.left + 2; 
	m_rcMenuTab.right = m_rcMenu.right - 2;

	m_dlgMainMenuFile.MoveWindow(&m_rcMenuTab);
	m_dlgMainMenuEdit.MoveWindow(&m_rcMenuTab);
	m_dlgMainMenuSheet.MoveWindow(&m_rcMenuTab);
	m_dlgMainMenuTool.MoveWindow(&m_rcMenuTab);

	MainMenuDisplay(0);
	//////////////////////////////////////////////////////////////////////////
	//��ʼ��treeDB
	ShowDatabaseStatus(m_dlgLogin.m_strConnectName);

	//////////////////////////////////////////////////////////////////////////
	//��ʼ��������

	//////////////////////////////////////////////////////////////////////////
	m_tabMenu.DeleteItem(4);			//��ʱ���������ҳ��

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CSobeyMemToolDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CSobeyMemToolDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CSobeyMemToolDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CSobeyMemToolDlg::MainMenuDisplay(int nIndex)
{
	m_tabMenu.SetCurSel(nIndex);
	switch (nIndex)
	{
	case 0:
		{
			m_tabMenu.MoveWindow(&m_rcMenu);
			MainControlVisible(TRUE);

			m_dlgMainMenuFile.ShowWindow(TRUE);
			m_dlgMainMenuEdit.ShowWindow(FALSE);
			m_dlgMainMenuSheet.ShowWindow(FALSE);
			m_dlgMainMenuTool.ShowWindow(FALSE);
		}
		break;
	case 1:
		{
			m_tabMenu.MoveWindow(&m_rcMenu);
			MainControlVisible(TRUE);

			m_dlgMainMenuFile.ShowWindow(FALSE);
			m_dlgMainMenuEdit.ShowWindow(TRUE);
			m_dlgMainMenuSheet.ShowWindow(FALSE);
			m_dlgMainMenuTool.ShowWindow(FALSE);
		}
		break;
	case 2:
		{
			m_tabMenu.MoveWindow(&m_rcMenu);
			MainControlVisible(TRUE);

			m_dlgMainMenuFile.ShowWindow(FALSE);
			m_dlgMainMenuEdit.ShowWindow(FALSE);
			m_dlgMainMenuSheet.ShowWindow(TRUE);
			m_dlgMainMenuTool.ShowWindow(FALSE);
		}
		break;
	case 3:
		{
			m_tabMenu.MoveWindow(&m_rcMenu);
			MainControlVisible(TRUE);

			m_dlgMainMenuFile.ShowWindow(FALSE);
			m_dlgMainMenuEdit.ShowWindow(FALSE);
			m_dlgMainMenuSheet.ShowWindow(FALSE);
			m_dlgMainMenuTool.ShowWindow(TRUE);
		}
		break;
	default:
		break;
	}
}

void CSobeyMemToolDlg::MainControlVisible(BOOL bVisible)
{
	m_tabMain.ShowWindow(bVisible);
	m_treeDB.ShowWindow(bVisible);
	GetDlgItem(IDC_BTN_EXECUTE)->ShowWindow(bVisible);
	GetDlgItem(IDC_BTN_REFRESH)->ShowWindow(bVisible);
	GetDlgItem(IDC_BTN_LOGOUT)->ShowWindow(bVisible);
	GetDlgItem(IDC_BTN_EXIT)->ShowWindow(bVisible);
}

void CSobeyMemToolDlg::ShowTreeDatabase(LPCTSTR lpDatabaseName)
{
	CString strText;
	char *lpValue;
	wchar_t *lpwValue, *lpwValue1, *lpwValue2, *lpwValue3, *lpwValue4, *lpwValue5;
	ISobeyDBRecordsetPtr rs, rsTable;
	int nRet, nValue;
	LONGLONG llValue;
	double dbValue;
	MF_EXECUTE_STATISTICS stStatisticsInfo;
	HTREEITEM hItemRoot, hItemSecond, hItemThird, hItemForth, hItemTemp;

	m_treeDB.DeleteAllItems();

	hItemRoot = m_treeDB.InsertItem(lpDatabaseName, NULL, NULL);
	
	//��
	hItemSecond = m_treeDB.InsertItem(_T("��"), NULL, NULL, hItemRoot);
	
	sprintf(m_cBufferDisplay, "select * from v$object");
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
	nRet = g_pSobeyInterface->GetRecordset(m_cBufferDisplay, &rs, &stStatisticsInfo);
	if (nRet != MF_OK)
	{
		goto ShowTreeDatabase_Failed;
	}

	rs->MoveFirst();
	while (!rs->eof())
	{
		rs->FieldValue(2, lpwValue);
		hItemThird = m_treeDB.InsertItem(lpwValue, NULL, NULL, hItemSecond);

		//�ֶ�
		hItemForth = m_treeDB.InsertItem(_T("�ֶ�"), NULL, NULL, hItemThird);

		rs->FieldValue(2, lpValue);
		sprintf(m_cBufferDisplay, "select * from v$column where objectname = '%s'", lpValue);

		memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
		nRet = g_pSobeyInterface->GetRecordset(m_cBufferDisplay, &rsTable, &stStatisticsInfo);
		if (nRet != MF_OK)
		{
			goto ShowTreeDatabase_Failed;
		}

		rsTable->MoveFirst();
		while (!rsTable->eof())
		{
			rsTable->FieldValue(2, lpwValue);
			if (_tcsicmp(lpwValue, _T("char")) == 0)
			{
				rsTable->FieldValue(1, lpwValue1);
				rsTable->FieldValue(2, lpwValue2);
				rsTable->FieldValue(3, lpwValue3);
				rsTable->FieldValue(4, lpwValue4);
				if (_tcsicmp(lpwValue4, _T("yes")) == 0)
				{
					strText.Format(_T("%s,%s(%s),not null"), lpwValue1, lpwValue2, lpwValue3);
				} 
				else
				{
					strText.Format(_T("%s,%s(%s)"), lpwValue1, lpwValue2, lpwValue3);
				}
			} 
			else
			{
				rsTable->FieldValue(1, lpwValue1);
				rsTable->FieldValue(2, lpwValue2);
				rsTable->FieldValue(4, lpwValue4);
				if (_tcsicmp(lpwValue4, _T("yes")) == 0)
				{
					strText.Format(_T("%s,%s,not null"), lpwValue1, lpwValue2);
				} 
				else
				{
					strText.Format(_T("%s,%s"), lpwValue1, lpwValue2);
				}
			}
			hItemTemp = m_treeDB.InsertItem(strText, NULL, NULL, hItemForth);
			rsTable->MoveNext();
		}

		//����
		hItemForth = m_treeDB.InsertItem(_T("����"), NULL, NULL, hItemThird);

		rs->FieldValue(2, lpValue);
		sprintf(m_cBufferDisplay, "select * from v$index where objectname = '%s'", lpValue);

		memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
		nRet = g_pSobeyInterface->GetRecordset(m_cBufferDisplay, &rsTable, &stStatisticsInfo);
		if (nRet != MF_OK)
		{
			goto ShowTreeDatabase_Failed;
		}

		rsTable->MoveFirst();
		while (!rsTable->eof())
		{
			rsTable->FieldValue(2, lpwValue2);
			rsTable->FieldValue(3, lpwValue3);
			rsTable->FieldValue(4, lpwValue4);
			rsTable->FieldValue(5, lpwValue5);
			strText.Format(_T("%s(%s),%s,%s"), lpwValue2, lpwValue3, lpwValue4, lpwValue5);
			hItemTemp = m_treeDB.InsertItem(strText, NULL, NULL, hItemForth);
			rsTable->MoveNext();
		}
		rs->MoveNext();
	}
	

	//����
	hItemSecond = m_treeDB.InsertItem(_T("����"), NULL, NULL, hItemRoot);

	sprintf(m_cBufferDisplay, "select * from v$index");
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
	nRet = g_pSobeyInterface->GetRecordset(m_cBufferDisplay, &rs, &stStatisticsInfo);
	if (nRet != MF_OK)
	{
		goto ShowTreeDatabase_Failed;
	}
	rs->MoveFirst();
	while (!rs->eof())
	{
		rs->FieldValue(1, lpwValue1);
		rs->FieldValue(2, lpwValue2);
		rs->FieldValue(3, lpwValue3);
		rs->FieldValue(4, lpwValue4);
		rs->FieldValue(5, lpwValue5);
		strText.Format(_T("%s: %s(%s),%s,%s"), lpwValue1, lpwValue2, lpwValue3, lpwValue4, lpwValue5);
		hItemTemp = m_treeDB.InsertItem(strText, NULL, NULL, hItemSecond);
		rs->MoveNext();
	}

	//����
	hItemSecond = m_treeDB.InsertItem(_T("����"), NULL, NULL, hItemRoot);

	sprintf(m_cBufferDisplay, "select * from v$sequence");
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
	nRet = g_pSobeyInterface->GetRecordset(m_cBufferDisplay, &rs, &stStatisticsInfo);
	if (nRet != MF_OK)
	{
		goto ShowTreeDatabase_Failed;
	}
	rs->MoveFirst();
	while (!rs->eof())
	{
		rs->FieldValue(1, lpwValue1);
		rs->FieldValue(5, lpwValue2);
		rs->FieldValue(4, lpwValue3);
		rs->FieldValue(2, lpwValue4);
		rs->FieldValue(3, lpwValue5);
		strText.Format(_T("%s: %s(+%s, %s~%s)"), lpwValue1, lpwValue2, lpwValue3, lpwValue4, lpwValue5);
		hItemTemp = m_treeDB.InsertItem(strText, NULL, NULL, hItemSecond);
		rs->MoveNext();
	}


	//�洢
	hItemSecond = m_treeDB.InsertItem(_T("�洢"), NULL, NULL, hItemRoot);
	sprintf(m_cBufferDisplay, "select * from v$datafile");
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
	nRet = g_pSobeyInterface->GetRecordset(m_cBufferDisplay, &rs, &stStatisticsInfo);
	if (nRet != MF_OK)
	{
		goto ShowTreeDatabase_Failed;
	}

	m_listFileInfo.clear();
	rs->MoveFirst();
	while (!rs->eof())
	{
		rs->FieldValue(4, lpwValue);
		hItemThird = m_treeDB.InsertItem(lpwValue, NULL, NULL, hItemSecond);

		rs->FieldValue(5, lpwValue);
		llValue = _wtoi64(lpwValue);
		if (llValue < 1024)
		{
			dbValue = llValue;
			strText.Format(_T("�ļ���С��%d B"), llValue);
		}
		else if (llValue >= 1024 && llValue < 1048576)
		{
			dbValue = llValue/1024.0;
			strText.Format(_T("�ļ���С��%.2f KB"), dbValue);
		}
		else if (llValue >= 1048576 && llValue < 1073741824)
		{
			dbValue = llValue/1048576.0;
			strText.Format(_T("�ļ���С��%.2f MB"), dbValue);
		}
		else
		{
			dbValue = llValue/1073741824.0;
			strText.Format(_T("�ļ���С��%.2f GB"), dbValue);
		}
		hItemTemp = m_treeDB.InsertItem(strText, NULL, NULL, hItemThird);
		rs->FieldValue(7, lpwValue);
		llValue = _wtoi64(lpwValue);
		if (llValue < 1024)
		{
			dbValue = llValue;
			strText.Format(_T("���ÿռ䣺%d B"), llValue);
		}
		else if (llValue >= 1024 && llValue < 1048576)
		{
			dbValue = llValue/1024.0;
			strText.Format(_T("���ÿռ䣺%.2f KB"), dbValue);
		}
		else if (llValue >= 1048576 && llValue < 1073741824)
		{
			dbValue = llValue/1048576.0;
			strText.Format(_T("���ÿռ䣺%.2f MB"), dbValue);
		}
		else
		{
			dbValue = llValue/1073741824.0;
			strText.Format(_T("���ÿռ䣺%.2f GB"), dbValue);
		}
		hItemTemp = m_treeDB.InsertItem(strText, NULL, NULL, hItemThird);
		rs->FieldValue(6, lpwValue);
		llValue = _wtoi64(lpwValue);
		if (llValue < 1024)
		{
			dbValue = llValue;
			strText.Format(_T("���ÿռ䣺%d B"), llValue);
		}
		else if (llValue >= 1024 && llValue < 1048576)
		{
			dbValue = llValue/1024.0;
			strText.Format(_T("���ÿռ䣺%.2f KB"), dbValue);
		}
		else if (llValue >= 1048576 && llValue < 1073741824)
		{
			dbValue = llValue/1048576.0;
			strText.Format(_T("���ÿռ䣺%.2f MB"), dbValue);
		}
		else
		{
			dbValue = llValue/1073741824.0;
			strText.Format(_T("���ÿռ䣺%.2f GB"), dbValue);
		}
		hItemTemp = m_treeDB.InsertItem(strText, NULL, NULL, hItemThird);

		STRUCT_FILEINFO st;
		rs->FieldValue(4, lpwValue);
		st.m_strFileName = lpwValue;
		rs->FieldValue(2, nValue);
		st.m_nFileType = nValue;
		m_listFileInfo.push_back(st);

		rs->MoveNext();
	}

	return;
ShowTreeDatabase_Failed:
	m_treeDB.DeleteAllItems();
	hItemRoot = m_treeDB.InsertItem(_T("��ȡ���ݿ���Ϣʧ��..."), NULL, NULL);
}



void CSobeyMemToolDlg::ShowDatabaseStatus(LPCTSTR lpDatabaseName)
{
	ShowTreeDatabase(lpDatabaseName);
}

void CSobeyMemToolDlg::CreateNewMainTabPage(int nType, void *lpDescribe)
{
	CRect rs;
	int nSize, nRet;
	CString strText;
	STRUCT_TABPAGE stTabPage;
	memset(&stTabPage, 0, sizeof(STRUCT_TABPAGE));

	nSize = m_listMainTab.size();
	switch (nType)
	{
	case MF_TABPAGE_TYPE_QUERY:
		{
			CMainTabQuery *pTabQuery;
			pTabQuery = new CMainTabQuery;

			stTabPage.m_lpTabPage = (LPVOID)pTabQuery;
			stTabPage.m_nTabPageType = nType;
			stTabPage.m_nTabCount = m_nTabCount;
			m_nTabCount++;
			m_listMainTab.push_front(stTabPage);

			strText.Format(_T("��ѯ%d"), stTabPage.m_nTabCount);
			m_tabMain.InsertItem(0, strText);

			pTabQuery->Create(IDD_MAINTAB_QUERY, GetDlgItem(IDC_TAB_MAIN));

			m_tabMain.GetClientRect(&rs); 
			rs.top += 22; 
			rs.bottom -= 2; 
			rs.left += 2; 
			rs.right -= 2;
			pTabQuery->MoveWindow(&rs);

			MainTabDisplay(0);
		}
		break;
	case MF_TABPAGE_TYPE_CREATE_OBJECT:
		{
			CMainTabObject *pTabCreateObject;
			pTabCreateObject = new CMainTabObject;

			stTabPage.m_lpTabPage = (LPVOID)pTabCreateObject;
			stTabPage.m_nTabPageType = nType;
			stTabPage.m_nTabCount = m_nTabCount;
			m_nTabCount++;
			m_listMainTab.push_front(stTabPage);

			strText.Format(_T("������%d"), stTabPage.m_nTabCount);
			m_tabMain.InsertItem(0, strText);

			pTabCreateObject->Create(IDD_MAINTAB_OBJECT, GetDlgItem(IDC_TAB_MAIN));

			m_tabMain.GetClientRect(&rs); 
			rs.top += 22; 
			rs.bottom -= 2; 
			rs.left += 2; 
			rs.right -= 2;
			pTabCreateObject->MoveWindow(&rs);

			MainTabDisplay(0);
		}
		break;
	case MF_TABPAGE_TYPE_EDIT_OBJECT:
		{
			//ѡ����Ҫ�༭�ı�
			//֮�����������˫�����Ҽ���������Ӧ
			int nLevel;
			HTREEITEM hItem;
			CString strObjectName, strTemp;
			hItem = m_treeDB.GetSelectedItem();
			if (hItem == NULL)
			{
				CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�༭�ı���"));
				return;
			}
			strObjectName = m_treeDB.GetItemText(hItem);

			hItem = m_treeDB.GetParentItem(hItem);
			if (hItem == NULL)
			{
				CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�༭�ı���"));
				return;
			}
			strTemp = m_treeDB.GetItemText(hItem);
			if (strTemp != _T("��"))
			{
				CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�༭�ı���"));
				return;
			}

			nLevel = 1;
			while (hItem = m_treeDB.GetParentItem(hItem))
			{
				if (hItem == NULL)
				{
					break;
				}
				nLevel++;
			}
			if (nLevel != 2)
			{
				CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�༭�ı���"));
				return;
			}


			//���￪ʼ�����༭��
			CMainTabObject *pTabCreateObject;
			pTabCreateObject = new CMainTabObject;

			stTabPage.m_lpTabPage = (LPVOID)pTabCreateObject;
			stTabPage.m_nTabPageType = nType;
			stTabPage.m_nTabCount = m_nTabCount;
			m_nTabCount++;
			m_listMainTab.push_front(stTabPage);

			strText.Format(_T("%s:�༭%d"), strObjectName, stTabPage.m_nTabCount);
			m_tabMain.InsertItem(0, strText);

			pTabCreateObject->Create(IDD_MAINTAB_OBJECT, GetDlgItem(IDC_TAB_MAIN));
			pTabCreateObject->OpenExistedObject(strObjectName);

			m_tabMain.GetClientRect(&rs); 
			rs.top += 22; 
			rs.bottom -= 2; 
			rs.left += 2; 
			rs.right -= 2;
			pTabCreateObject->MoveWindow(&rs);

			MainTabDisplay(0);
		}
		break;
	case MF_TABPAGE_TYPE_QUERY_OBJECT:
		{
			//ѡ����Ҫ�༭�ı�
			//֮�����������˫�����Ҽ���������Ӧ
			int nLevel;
			HTREEITEM hItem;
			CString strObjectName, strTemp, strSql;
			hItem = m_treeDB.GetSelectedItem();
			if (hItem == NULL)
			{
				CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�༭�ı���"));
				return;
			}
			strObjectName = m_treeDB.GetItemText(hItem);

			hItem = m_treeDB.GetParentItem(hItem);
			if (hItem == NULL)
			{
				CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�༭�ı���"));
				return;
			}
			strTemp = m_treeDB.GetItemText(hItem);
			if (strTemp != _T("��"))
			{
				CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�༭�ı���"));
				return;
			}

			nLevel = 1;
			while (hItem = m_treeDB.GetParentItem(hItem))
			{
				if (hItem == NULL)
				{
					break;
				}
				nLevel++;
			}
			if (nLevel != 2)
			{
				CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�༭�ı���"));
				return;
			}


			//���￪ʼ�����༭��
			CMainTabQuery *pTabQuery;
			pTabQuery = new CMainTabQuery;

			stTabPage.m_lpTabPage = (LPVOID)pTabQuery;
			stTabPage.m_nTabPageType = nType;
			stTabPage.m_nTabCount = m_nTabCount;
			m_nTabCount++;
			m_listMainTab.push_front(stTabPage);

			strText.Format(_T("��ѯ%d"), stTabPage.m_nTabCount);
			m_tabMain.InsertItem(0, strText);

			pTabQuery->Create(IDD_MAINTAB_QUERY, GetDlgItem(IDC_TAB_MAIN));
			strSql.Format(_T("select * from %s"), strObjectName);
			pTabQuery->m_reSql.SetWindowText(strSql);
			pTabQuery->ExecuteSql();

			m_tabMain.GetClientRect(&rs); 
			rs.top += 22; 
			rs.bottom -= 2; 
			rs.left += 2; 
			rs.right -= 2;
			pTabQuery->MoveWindow(&rs);

			MainTabDisplay(0);
		}
		break;
	case MF_TABPAGE_TYPE_REDO_ANALYSE:
		{
			if (lpDescribe == NULL || lpDescribe == L"")
			{
				break;
			} 

			CMainTabRedoAnalyse *pTabRedoAnalyse;
			pTabRedoAnalyse = new CMainTabRedoAnalyse;

			stTabPage.m_lpTabPage = (LPVOID)pTabRedoAnalyse;
			stTabPage.m_nTabPageType = nType;
			stTabPage.m_nTabCount = m_nTabCount;
			m_nTabCount++;
			m_listMainTab.push_front(stTabPage);

			char lpRedoFilePath[MAX_PATH];
			wchar_t *lwpRedoFilePath, *lwpName;
			lwpRedoFilePath = (wchar_t*)lpDescribe;
			lwpName = wcsrchr(lwpRedoFilePath, L'\\')+1;
			WideCharToMultiByte(CP_ACP, 0, lwpRedoFilePath, wcslen(lwpRedoFilePath)+1, lpRedoFilePath, MAX_PATH, NULL, NULL);
			strText.Format(_T("%s:������־����%d"), lwpName, stTabPage.m_nTabCount);

			m_tabMain.InsertItem(0, strText);

			pTabRedoAnalyse->Create(IDD_MAINTAB_REDO, GetDlgItem(IDC_TAB_MAIN));

			m_tabMain.GetClientRect(&rs); 
			rs.top += 22; 
			rs.bottom -= 2; 
			rs.left += 2; 
			rs.right -= 2;
			pTabRedoAnalyse->MoveWindow(&rs);

			MainTabDisplay(0);
			nRet = pTabRedoAnalyse->RedoAnalyse(lpRedoFilePath);
			if(nRet != MF_OK)
			{
				CMessageBox(_T("����������־ʧ�ܣ�"));
			}
		}
		break;
	default:
		break;
	}
	return;
}

void CSobeyMemToolDlg::MainTabDisplay(int nIndex)
{
	int i = 0;
	list<STRUCT_TABPAGE>::iterator iter;

	m_tabMain.SetCurSel(nIndex);
	for (iter = m_listMainTab.begin(); iter != m_listMainTab.end(); iter++)
	{
		if (i == nIndex)
		{
			CDialog *pDlg;
			pDlg = (CDialog*)(((STRUCT_TABPAGE)*iter).m_lpTabPage);
			pDlg->ShowWindow(TRUE);
		} 
		else
		{
			CDialog *pDlg;
			pDlg = (CDialog*)(((STRUCT_TABPAGE)*iter).m_lpTabPage);
			pDlg->ShowWindow(FALSE);
		}
		i++;
	}
}


void CSobeyMemToolDlg::DeleteMainTabItem(STRUCT_TABPAGE st)
{
	switch (st.m_nTabPageType)
	{
	case MF_TABPAGE_TYPE_QUERY:
	case MF_TABPAGE_TYPE_QUERY_OBJECT:
		{
			CMainTabQuery *pTabQuery;
			pTabQuery = (CMainTabQuery*)st.m_lpTabPage;
			delete pTabQuery;
		}
		break;
	case MF_TABPAGE_TYPE_CREATE_OBJECT:
	case MF_TABPAGE_TYPE_EDIT_OBJECT:
		{
			CMainTabObject *pTabCreateObject;
			pTabCreateObject = (CMainTabObject*)st.m_lpTabPage;
			delete pTabCreateObject;
		}
		break;
	case MF_TABPAGE_TYPE_REDO_ANALYSE:
		{
			CMainTabRedoAnalyse *pTabRedoAnalyse;
			pTabRedoAnalyse = (CMainTabRedoAnalyse*)st.m_lpTabPage;
			delete pTabRedoAnalyse;
		}
		break;
	default:
		break;
	}
}


//////////////////////////////////////////////////////////////////////////

void CSobeyMemToolDlg::OnBnClickedBtnLogout()
{
	int nRet;
	CString strText;
	while (TRUE)
	{
		if (IDOK == m_dlgLogin.DoModal())
		{
			//��¼
			nRet = g_pSobeyInterface->Open(m_dlgLogin.m_cConnectName, m_dlgLogin.m_cUserID, m_dlgLogin.m_cUserPW);
			if (MF_OK == nRet)
			{
				return;
			}
			else
			{
				strText.Format(_T("��¼ʧ�ܣ������룺%d��%s��"), nRet, GetErrorWDescription(nRet));
				CMessageBox(strText);
				continue;
			}
		} 
		else
		{
			////�˳�
			//CDialog::OnOK();
			return;
		}
	}
}

void CSobeyMemToolDlg::OnBnClickedBtnExit()
{
	//ExitProcess(0);
	CDialog::OnOK();
}

void CSobeyMemToolDlg::OnTcnSelchangeTabMenu(NMHDR *pNMHDR, LRESULT *pResult)
{
	int nCurSel = m_tabMenu.GetCurSel();
	MainMenuDisplay(nCurSel);

	*pResult = 0;
}

void CSobeyMemToolDlg::OnBnClickedBtnExecute()
{
	int nCurSel = m_tabMain.GetCurSel();
	if (nCurSel < 0)
	{
		return;
	}

	int i = 0;
	list<STRUCT_TABPAGE>::iterator iter;
	for (iter = m_listMainTab.begin(); iter != m_listMainTab.end(); iter++)
	{
		if (i == nCurSel)
		{
			STRUCT_TABPAGE st;
			st = (STRUCT_TABPAGE)*iter;
			
			switch (st.m_nTabPageType)
			{
			case MF_TABPAGE_TYPE_QUERY:
			case MF_TABPAGE_TYPE_QUERY_OBJECT:
				{
					CMainTabQuery *pTabQuery;
					pTabQuery = (CMainTabQuery*)st.m_lpTabPage;

					pTabQuery->ExecuteSql();
				}
				break;
			case MF_TABPAGE_TYPE_CREATE_OBJECT:
			case MF_TABPAGE_TYPE_EDIT_OBJECT:
				{
					//CMainTabObject *pTabObject;
					//pTabObject = (CMainTabObject*)st.m_lpTabPage;

					//pTabObject->CreateNewObject();
				}
				break;
			case MF_TABPAGE_TYPE_REDO_ANALYSE:
				{
					;
				}
				break;
			default:
				break;
			}
			

			break;
		}
		i++;
	}
}

void CSobeyMemToolDlg::OnBnClickedBtnRefresh()
{
	ShowDatabaseStatus(m_dlgLogin.m_strConnectName);
}

//�����Ҽ��ر�ѡ�
void CSobeyMemToolDlg::OnNMRClickTabMain(NMHDR *pNMHDR, LRESULT *pResult)
{
	*pResult = 0;

	int nCurSel = m_tabMain.GetCurSel();
	if (nCurSel < 0)
	{
		return;
	}

	CString strText;
	TCHAR szLabel[64]; 
	TC_ITEM iItemTC; 
	iItemTC.mask=TCIF_TEXT|TCIF_IMAGE; 
	iItemTC.pszText=szLabel; 
	iItemTC.cchTextMax = 63; 
	m_tabMain.GetItem(nCurSel,&iItemTC);

	strText.Format(_T("�ر�ѡ���%s����"), szLabel);
	if (IDYES == CMessageBox(strText, MB_YESNO|MB_SYSTEMMODAL))
	{
		m_tabMain.DeleteItem(nCurSel);

		int i = 0;
		list<STRUCT_TABPAGE>::iterator iter;
		for (iter = m_listMainTab.begin(); iter != m_listMainTab.end(); iter++)
		{
			if (i == nCurSel)
			{
				STRUCT_TABPAGE st;
				st = (STRUCT_TABPAGE)*iter;
				DeleteMainTabItem(st);

				m_listMainTab.erase(iter);
				if (nCurSel == 0)
				{
					MainTabDisplay(nCurSel);
				} 
				else
				{
					MainTabDisplay(nCurSel - 1);
				}
				break;
			}
			i++;
		}
	}

	*pResult = 0;
}

void CSobeyMemToolDlg::OnTcnSelchangeTabMain(NMHDR *pNMHDR, LRESULT *pResult)
{
	int nCurSel = m_tabMain.GetCurSel();
	MainTabDisplay(nCurSel);

	*pResult = 0;
}

void CSobeyMemToolDlg::OnSize(UINT nType, int cx, int cy)
{
	CRect rtCtrl, rtClient;
	CDialog::OnSize(nType, cx, cy);

	//�ƶ������ڴ�С
	GetClientRect(rtClient);
	m_treeDB.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.bottom = rtClient.bottom - 5;
	m_treeDB.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
	m_ctrlSeparator.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.bottom = rtClient.bottom - 5;
	m_ctrlSeparator.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);

	m_tabMain.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.bottom = rtClient.bottom - 5;
	rtCtrl.right = rtClient.right - 5;
	m_tabMain.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);

	list<STRUCT_TABPAGE>::iterator iter;

	rtCtrl.top += 22; 
	rtCtrl.bottom -= 2; 
	rtCtrl.left += 2; 
	rtCtrl.right -= 2;
	for (iter = m_listMainTab.begin(); iter != m_listMainTab.end(); iter++)
	{
		((CDialog*)(((STRUCT_TABPAGE)*iter).m_lpTabPage))->SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
	}
}

void CSobeyMemToolDlg::OnCancel()
{
	int nRet;
	nRet = MessageBox(_T("ȷ���˳����ݿ⹤�ߣ�"), _T("��ʾ"), MB_OKCANCEL);
	if(nRet != IDOK)
	{
		return;
	}

	CDialog::OnCancel();
}

void CSobeyMemToolDlg::OnOK()
{
	//CDialog::OnOK();
}

void CSobeyMemToolDlg::OnBnClickedBtnMakeUpper()
{
	int nCurSel = m_tabMain.GetCurSel();
	if (nCurSel < 0)
	{
		return;
	}

	int i = 0;
	list<STRUCT_TABPAGE>::iterator iter;
	for (iter = m_listMainTab.begin(); iter != m_listMainTab.end(); iter++)
	{
		if (i == nCurSel)
		{
			STRUCT_TABPAGE st;
			st = (STRUCT_TABPAGE)*iter;

			switch (st.m_nTabPageType)
			{
			case MF_TABPAGE_TYPE_QUERY:
			case MF_TABPAGE_TYPE_QUERY_OBJECT:
				{
					CMainTabQuery *pTabQuery;
					pTabQuery = (CMainTabQuery*)st.m_lpTabPage;

					pTabQuery->MakeUpper();
				}
				break;
			case MF_TABPAGE_TYPE_CREATE_OBJECT:
			case MF_TABPAGE_TYPE_EDIT_OBJECT:
				{
					;
				}
				break;
			case MF_TABPAGE_TYPE_REDO_ANALYSE:
				{
					;
				}
				break;
			default:
				break;
			}


			break;
		}
		i++;
	}
}

void CSobeyMemToolDlg::OnBnClickedBtnMakeLower()
{
	int nCurSel = m_tabMain.GetCurSel();
	if (nCurSel < 0)
	{
		return;
	}

	int i = 0;
	list<STRUCT_TABPAGE>::iterator iter;
	for (iter = m_listMainTab.begin(); iter != m_listMainTab.end(); iter++)
	{
		if (i == nCurSel)
		{
			STRUCT_TABPAGE st;
			st = (STRUCT_TABPAGE)*iter;

			switch (st.m_nTabPageType)
			{
			case MF_TABPAGE_TYPE_QUERY:
			case MF_TABPAGE_TYPE_QUERY_OBJECT:
				{
					CMainTabQuery *pTabQuery;
					pTabQuery = (CMainTabQuery*)st.m_lpTabPage;

					pTabQuery->MakeLower();
				}
				break;
			case MF_TABPAGE_TYPE_CREATE_OBJECT:
			case MF_TABPAGE_TYPE_EDIT_OBJECT:
				{
					;
				}
				break;
			case MF_TABPAGE_TYPE_REDO_ANALYSE:
				{
					;
				}
				break;
			default:
				break;
			}


			break;
		}
		i++;
	}
}

void CSobeyMemToolDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	int iOffsetX;
	CRect rtTree, rtMain, rtSplit;
	if(m_bSpliting)
	{
		iOffsetX = point.x - m_ptOld.x;
		m_treeDB.GetWindowRect(rtTree);
		m_tabMain.GetWindowRect(rtMain);
		m_ctrlSeparator.GetWindowRect(rtSplit);
		ScreenToClient(rtTree);
		ScreenToClient(rtMain);
		ScreenToClient(rtSplit);
		if(rtTree.left + 50 < rtSplit.left + iOffsetX
			&& rtMain.right - 200 > rtSplit.right + iOffsetX)//���ſؼ�
		{
			rtSplit.OffsetRect(iOffsetX, 0);
			m_ctrlSeparator.MoveWindow(rtSplit);
			m_ptOld = point;
			m_iOffsetX += iOffsetX;
		}
	}
	else
	{
		m_ctrlSeparator.GetWindowRect(rtSplit);
		ScreenToClient(rtSplit);
		if(rtSplit.PtInRect(point))
			SetCursor(LoadCursor(NULL,IDC_SIZEWE));
	}


	CDialog::OnMouseMove(nFlags, point);
}

void CSobeyMemToolDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	CRect rtSplit;
	m_ctrlSeparator.GetWindowRect(rtSplit);
	ScreenToClient(rtSplit);
	if(rtSplit.PtInRect(point))
	{
		SetCursor(LoadCursor(NULL,IDC_SIZEWE));
		m_bSpliting = TRUE;
		m_ptOld = point;
		m_iOffsetX = 0;
		m_ctrlSeparator.ShowWindow(SW_SHOW);
		SetCapture();
	}
	CDialog::OnLButtonDown(nFlags, point);
}

void CSobeyMemToolDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	CRect rtTree, rtMain;
	if(m_bSpliting)
	{
		list<STRUCT_TABPAGE>::iterator iter;

		m_treeDB.GetWindowRect(rtTree);
		m_tabMain.GetWindowRect(rtMain);
		ScreenToClient(rtTree);
		ScreenToClient(rtMain);
		rtTree.right += m_iOffsetX;
		rtMain.left += m_iOffsetX;
		m_treeDB.MoveWindow(rtTree);
		m_tabMain.MoveWindow(rtMain);

		rtMain.top += 22; 
		rtMain.bottom -= 2; 
		rtMain.left += 2; 
		rtMain.right -= 2;
		for (iter = m_listMainTab.begin(); iter != m_listMainTab.end(); iter++)
		{
			((CDialog*)(((STRUCT_TABPAGE)*iter).m_lpTabPage))->SetWindowPos(NULL, 0, 0, rtMain.Width(), rtMain.Height(), SWP_NOMOVE | SWP_NOZORDER);
		}
		m_ctrlSeparator.ShowWindow(SW_HIDE);
		ReleaseCapture();
	}
	m_bSpliting = FALSE;
	CDialog::OnLButtonUp(nFlags, point);
}
