/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MainTabQuery.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "SobeyMemToolDlg.h"		//�����Ѿ������� MainTabQuery.h
#include "MainTabQuery.h"
//#include "MainTabQuery.h"


// CMainTabQuery �Ի���

IMPLEMENT_DYNAMIC(CMainTabQuery, CDialog)

CMainTabQuery::CMainTabQuery(CWnd* pParent /*=NULL*/)
	: CDialog(CMainTabQuery::IDD, pParent)
{
	m_bSpliting = FALSE;
	m_ptOld = CPoint(0,0);
	m_iOffsetY = 0;
}

CMainTabQuery::~CMainTabQuery()
{
}

void CMainTabQuery::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//DDX_Control(pDX, IDC_EDIT_SQL, m_editSql);
	DDX_Control(pDX, IDC_TAB_QUERY, m_tabQuery);
	DDX_Control(pDX, IDC_RICHEDIT_SQL, m_reSql);
	DDX_Control(pDX, IDC_STATIC_SEPARATOR, m_ctrlSeparator);
}

BOOL CMainTabQuery::OnInitDialog()
{
	CDialog::OnInitDialog();

	//��ʼ���ؼ�
	//��ʼ��tabQuery
	m_tabQuery.InsertItem(0, _T("���"));
	m_tabQuery.InsertItem(1, _T("��Ϣ"));
	//m_tabQuery.InsertItem(2, _T("�Ự"));

	m_dlgMainTabQueryResult.Create(IDD_MAINTAB_QUERY_RESULT, GetDlgItem(IDC_TAB_QUERY));
	m_dlgMainTabQueryInfo.Create(IDD_MAINTAB_QUERY_INFO, GetDlgItem(IDC_TAB_QUERY));

	m_pRs = NULL;

	CRect rs; 
	m_tabQuery.GetClientRect(&rs); 
	rs.top += 22; 
	rs.bottom -= 2; 
	rs.left += 2; 
	rs.right -= 2;

	m_dlgMainTabQueryResult.MoveWindow(&rs);
	m_dlgMainTabQueryInfo.MoveWindow(&rs);

	TabQueryChange(0);

	CHARFORMAT cf;
	m_reSql.GetSelectionCharFormat(cf);
	wcscpy(cf.szFaceName ,_T("����"));//��������
	m_reSql.SetSelectionCharFormat(cf);


	return TRUE;
}


BEGIN_MESSAGE_MAP(CMainTabQuery, CDialog)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_QUERY, &CMainTabQuery::OnTcnSelchangeTabQuery)
	ON_WM_SIZE()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()


// CMainTabQuery ��Ϣ��������

void CMainTabQuery::ExecuteSql()
{
	char *lpSql, *lpRealSql;
	int nSqlCount, i, nRet, nAffectCount, nSqlTpye;
	CString strSql, strTemp;
	MF_EXECUTE_STATISTICS stStatisticsInfo;
	DWORD dwDisplay, dwTotal;
	LARGE_INTEGER liFrequence, liBegin, liEnd;
	vector<char*> vecSql;
	UpdateData(TRUE);

	m_strPreQuerySql = _T("");
	nAffectCount = 0;
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));

	lpSql = NULL;
	strSql = m_reSql.GetSelText();
	strSql.Trim();
	if(strSql.GetLength() == 0)
	{
		m_reSql.GetWindowText(strSql);
		strSql.Trim();
	}
	if (strSql == _T(""))
	{
		return;
	}

	//��ս����
	QueryPerformanceFrequency(&liFrequence);
	QueryPerformanceCounter(&liBegin);
	m_dlgMainTabQueryResult.ClearResult();
	QueryPerformanceCounter(&liEnd); 
	dwDisplay = (DWORD)(1000000 * (liEnd.QuadPart - liBegin.QuadPart) / liFrequence.QuadPart ); //���㵽΢����

	lpSql = SMT_UnicodeToUTF8(strSql);
	if (lpSql == NULL)
	{
		strTemp.Format(_T("����ת��ʧ�ܣ������룺%d��SQL��䣺%s\r\n"), GetLastError(), strSql);
		m_dlgMainTabQueryInfo.TextShow(strTemp);

		TabQueryChange(1);
	}

	vecSql.clear();
	nRet = SplitSql(lpSql, strlen(lpSql), vecSql);
	if (nRet == MF_PARSECMD_INVALID_STRING_ERROR)
	{
		nAffectCount = 0;
		strTemp.Format(_T("δ�ҵ������ĵ����ţ�SQL��䣺%s\r\n"), strSql);
		m_dlgMainTabQueryInfo.TextShow(strTemp);
		TabQueryChange(1);
	}
	else if (nRet != MF_OK)
	{
		nAffectCount = 0;

		strTemp.Format(_T("SplitSqlʧ�ܣ�SQL��䣺%s\r\n"), strSql);
		m_dlgMainTabQueryInfo.TextShow(strTemp);

		TabQueryChange(1);
	}
	else
	{
		nSqlCount = vecSql.size();
		if (nSqlCount == 0)
		{
			strTemp.Format(_T("SplitSqlʧ�ܣ�����0�������SQL��䣺%s\r\n"), strSql);
			m_dlgMainTabQueryInfo.TextShow(strTemp);

			TabQueryChange(1);
		}
		else if (nSqlCount == 1)
		{
			nAffectCount = 0;
			memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));

			lpRealSql = lpSql;
			nSqlTpye = ParseSqlType(lpRealSql);
			if (nSqlTpye < 0)
			{
				strTemp.Format(_T("����Sql������SQL��䣺%s\r\n"), strSql);
				m_dlgMainTabQueryInfo.TextShow(strTemp);

				TabQueryChange(1);
			}
			else if (nSqlTpye == MF_PARSECMD_EMPTY_STRING)
			{
				//�մ���������ִ��
				;
			}
			else if (nSqlTpye == 0)
			{
				strTemp.Format(_T("�ݲ�֧�ֽ���ִ�мƻ���SQL��䣺%s\r\n"), strSql);
				m_dlgMainTabQueryInfo.TextShow(strTemp);

				TabQueryChange(1);
			}
			else if (nSqlTpye == 1)
			{
				nRet = g_pSobeyInterface->GetRecordset(lpRealSql, &m_rs, &stStatisticsInfo);
				if (nRet != MF_OK)
				{
					strTemp.Format(_T("ִ��ʧ�ܣ�����ֵ��%d��%s���������룺%d��%s��\r\nSQL��䣺%s\r\n"), nRet, GetErrorWDescription(nRet), stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet), strSql);
					m_dlgMainTabQueryInfo.TextShow(strTemp);

					TabQueryChange(1);
				}
				else
				{
					if (m_pRs != NULL)
					{
						m_pRs->Release();
					}
					m_pRs = m_rs.Detach();
					//��ʾִ�н��
					QueryPerformanceFrequency(&liFrequence);
					QueryPerformanceCounter(&liBegin);
					nRet = m_dlgMainTabQueryResult.DisplayResult(m_pRs);
					QueryPerformanceCounter(&liEnd); 
					dwDisplay += (DWORD)(1000000 * (liEnd.QuadPart - liBegin.QuadPart) / liFrequence.QuadPart ); //���㵽΢����

					//��ʾ�����Ϣ
					nAffectCount = m_pRs->GetRowNum();
					ShowResultInfo(nSqlTpye, nAffectCount, dwDisplay, stStatisticsInfo);
					TabQueryChange(0);

					m_strPreQuerySql = strSql;
				}
			}
			else if (nSqlTpye == 2 || nSqlTpye == 3)
			{
				nRet = g_pSobeyInterface->Execute(lpRealSql, nAffectCount, &stStatisticsInfo);
				if (nRet != MF_OK)
				{
					strTemp.Format(_T("ִ��ʧ�ܣ�����ֵ��%d��%s���������룺%d��%s��\r\nSQL��䣺%s\r\n"), nRet, GetErrorWDescription(nRet), stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet), strSql);
					m_dlgMainTabQueryInfo.TextShow(strTemp);

					TabQueryChange(1);
				}
				else
				{
					//��ʾִ�н��
					ShowResultInfo(nSqlTpye, nAffectCount, dwDisplay, stStatisticsInfo);
					TabQueryChange(1);
				}
			}
			else
			{
				strTemp.Format(_T("����Sql������SQL��䣺%s\r\n"), strSql);
				m_dlgMainTabQueryInfo.TextShow(strTemp);

				TabQueryChange(1);
			}
		}
		else		//nSqlCount > 1
		{
			BOOL bOK = FALSE;
			i = 0;
			QueryPerformanceFrequency(&liFrequence);
			QueryPerformanceCounter(&liBegin);
			while (TRUE)
			{
				nAffectCount = 0;
				memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));

				bOK = FALSE;
				lpRealSql = vecSql[i];
				nSqlTpye = ParseSqlType(lpRealSql);
				if (nSqlTpye < 0)
				{
					//����Sql������
					bOK = FALSE;
				}
				else if (nSqlTpye == MF_PARSECMD_EMPTY_STRING)
				{
					//�մ���������ִ��
					bOK = TRUE;
				}
				else if (nSqlTpye == 0)
				{
					//�ݲ�֧�ֽ���ִ�мƻ�
					bOK = FALSE;
				}
				else if (nSqlTpye == 1)
				{
					nRet = g_pSobeyInterface->GetRecordset(lpRealSql, &m_rs, &stStatisticsInfo);
					if (nRet != MF_OK)
					{
						bOK = FALSE;
					}
					else
					{
						bOK = TRUE;
					}
				}
				else if (nSqlTpye == 2 || nSqlTpye == 3)
				{
					nRet = g_pSobeyInterface->Execute(lpRealSql, nAffectCount, &stStatisticsInfo);
					if (nRet != MF_OK)
					{
						bOK = FALSE;
					}
					else
					{
						bOK = TRUE;	
					}
				}
				else
				{
					//����Sql������
					bOK = FALSE;
				}

				if (bOK)
				{
					//�ɹ�����ʾ���
					i++;
					if (i == nSqlCount)
					{
						QueryPerformanceCounter(&liEnd); 
						dwTotal = (DWORD)(1000000 * (liEnd.QuadPart - liBegin.QuadPart) / liFrequence.QuadPart ); //���㵽΢����
						strTemp.Format(_T("ִ��ȫ��%d��SQL���ɹ���\r\n�ͻ����ܺ�ʱ��%d us\r\n"), i, dwTotal);
						m_dlgMainTabQueryInfo.TextShow(strTemp);

						TabQueryChange(1);
						break;
					}
				} 
				else
				{
					wchar_t *lpwSql;

					QueryPerformanceCounter(&liEnd); 
					dwTotal = (DWORD)(1000000 * (liEnd.QuadPart - liBegin.QuadPart) / liFrequence.QuadPart ); //���㵽΢����
					lpwSql = SMT_UTF8ToUnicode(vecSql[i]);
					if (lpwSql == NULL)
					{
						strTemp.Format(_T("ִ�е�%d��SQL���ʧ�ܣ������룺%d��%s��\r\nSQL��䣺%ws\r\n�ͻ����ܺ�ʱ��%d us\r\n"), i+1, stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet), strSql, dwTotal);
					} 
					else
					{
						strTemp.Format(_T("ִ�е�%d��SQL���ʧ�ܣ������룺%d��%s��\r\nSQL��䣺%ws\r\n�ͻ����ܺ�ʱ��%d us\r\n"), i+1, stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet), lpwSql, dwTotal);
						delete[] lpwSql;
					}
					m_dlgMainTabQueryInfo.TextShow(strTemp);

					TabQueryChange(1);
					break;
				}
			}
		}
	}
	
	delete[] lpSql;
	return;
}

void CMainTabQuery::ExecuteSql(CString strSql)
{
	char *lpSql;
	int nRet, nAffectCount, nSqlTpye;
	CString strTemp;
	MF_EXECUTE_STATISTICS stStatisticsInfo;
	DWORD dwDisplay;
	LARGE_INTEGER liFrequence, liBegin, liEnd;
	
	if (strSql == _T(""))
	{
		//���벻��Ϊ��
		return;
	}

	UpdateData(TRUE);
	m_strPreQuerySql = _T("");

	//��ս����
	QueryPerformanceFrequency(&liFrequence);
	QueryPerformanceCounter(&liBegin);
	m_dlgMainTabQueryResult.ClearResult();
	QueryPerformanceCounter(&liEnd); 
	dwDisplay = (DWORD)(1000000 * (liEnd.QuadPart - liBegin.QuadPart) / liFrequence.QuadPart ); //���㵽΢����

	lpSql = NULL;
	lpSql = SMT_UnicodeToUTF8(strSql);
	if (lpSql == NULL)
	{
		strTemp.Format(_T("����ת��ʧ�ܣ������룺%d��SQL��䣺%s\r\n"), GetLastError(), strSql);
		m_dlgMainTabQueryInfo.TextShow(strTemp);

		TabQueryChange(1);
	}

	nAffectCount = 0;
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));

	nSqlTpye = ParseSqlType(lpSql);
	if (nSqlTpye < 0)
	{
		strTemp.Format(_T("����Sql������SQL��䣺%s\r\n"), strSql);
		m_dlgMainTabQueryInfo.TextShow(strTemp);

		TabQueryChange(1);
	}
	else if (nSqlTpye == MF_PARSECMD_EMPTY_STRING)
	{
		//�մ���������ִ��
		;
	}
	else if (nSqlTpye == 0)
	{
		strTemp.Format(_T("�ݲ�֧�ֽ���ִ�мƻ���SQL��䣺%s\r\n"), strSql);
		m_dlgMainTabQueryInfo.TextShow(strTemp);

		TabQueryChange(1);
	}
	else if (nSqlTpye == 1)
	{
		nRet = g_pSobeyInterface->GetRecordset(lpSql, &m_rs, &stStatisticsInfo);
		if (nRet != MF_OK)
		{
			strTemp.Format(_T("ִ��ʧ�ܣ�����ֵ��%d��%s���������룺%d��%s��\r\nSQL��䣺%s\r\n"), nRet, GetErrorWDescription(nRet), stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet), strSql);
			m_dlgMainTabQueryInfo.TextShow(strTemp);

			TabQueryChange(1);
		}
		else
		{
			if (m_pRs != NULL)
			{
				m_pRs->Release();
			}
			m_pRs = m_rs.Detach();
			//��ʾִ�н��
			QueryPerformanceFrequency(&liFrequence);
			QueryPerformanceCounter(&liBegin);
			nRet = m_dlgMainTabQueryResult.DisplayResult(m_pRs);
			QueryPerformanceCounter(&liEnd); 
			dwDisplay += (DWORD)(1000000 * (liEnd.QuadPart - liBegin.QuadPart) / liFrequence.QuadPart ); //���㵽΢����

			//��ʾ�����Ϣ
			nAffectCount = m_pRs->GetRowNum();
			ShowResultInfo(nSqlTpye, nAffectCount, dwDisplay, stStatisticsInfo);
			TabQueryChange(0);

			m_strPreQuerySql = strSql;
		}
	}
	else if (nSqlTpye == 2 || nSqlTpye == 3)
	{
		nRet = g_pSobeyInterface->Execute(lpSql, nAffectCount, &stStatisticsInfo);
		if (nRet != MF_OK)
		{
			strTemp.Format(_T("ִ��ʧ�ܣ�����ֵ��%d��%s���������룺%d��%s��\r\nSQL��䣺%s\r\n"), nRet, GetErrorWDescription(nRet), stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet), strSql);
			m_dlgMainTabQueryInfo.TextShow(strTemp);

			TabQueryChange(1);
		}
		else
		{
			//��ʾִ�н��
			ShowResultInfo(nSqlTpye, nAffectCount, dwDisplay, stStatisticsInfo);
			TabQueryChange(1);
		}
	}
	else
	{
		strTemp.Format(_T("����Sql������SQL��䣺%s\r\n"), strSql);
		m_dlgMainTabQueryInfo.TextShow(strTemp);

		TabQueryChange(1);
	}
	
	delete[] lpSql;
	return;
}

//����ִ����һ�εĲ�ѯ������ˢ�½������������ʾ
void CMainTabQuery::RedoLastQuery()
{
	ExecuteSql(m_strPreQuerySql);
}


void CMainTabQuery::ShowResultInfo(int nSqlType, LONG lAffectCount, DWORD dwDisplay, MF_EXECUTE_STATISTICS stStatisticsInfo)
{
	CString strTemp, strText;

	DWORD dwServerTime, dwClientIme, dwClientParseIme, dwServerCallTime, dwClientReceiveIme, dwPrepareTime, dwApplyResourceTime, dwIndexSerchTime, dwDataExtractTime, dwServerExecuteTime, dwWriteLogTime, dwReleaseResourceTime, dwOtherTime;
	SYSTEMTIME stServerStart, stServerEnd, stStart, stEnd;

	if(stStatisticsInfo.m_llServerFrequence == 0)
	{
		dwServerTime			 = 0;
		dwPrepareTime			 = 0;
		dwApplyResourceTime		 = 0;
		dwIndexSerchTime		 = 0;
		dwDataExtractTime		 = 0;
		dwServerExecuteTime		 = 0;
		dwWriteLogTime			 = 0;
		dwReleaseResourceTime	 = 0;
		dwOtherTime				 = 0;
	}
	else
	{
		FileTimeToSystemTime((FILETIME *)&stStatisticsInfo.m_ftServerStartTime, &stServerStart);
		FileTimeToSystemTime((FILETIME *)&stStatisticsInfo.m_ftServerEndTime, &stServerEnd);
		if(stStatisticsInfo.m_llServerEnd > stStatisticsInfo.m_llServerStart && stStatisticsInfo.m_llServerStart != 0)
		{
			dwServerTime	 = (DWORD)(1000000 * (stStatisticsInfo.m_llServerEnd - stStatisticsInfo.m_llServerStart) / stStatisticsInfo.m_llServerFrequence);//���㵽΢����
		}
		else
		{
			dwServerTime	 = 0;
		}

		if(stStatisticsInfo.m_llServerPretreatmentStart > stStatisticsInfo.m_llServerStart && stStatisticsInfo.m_llServerStart != 0)
		{
			dwPrepareTime	 = (DWORD)(1000000 * (stStatisticsInfo.m_llServerPretreatmentStart - stStatisticsInfo.m_llServerStart) / stStatisticsInfo.m_llServerFrequence);//���㵽΢����
		}
		else
		{
			dwPrepareTime = 0;
		}

		if(stStatisticsInfo.m_llServerExecuteStart > stStatisticsInfo.m_llServerPretreatmentStart && stStatisticsInfo.m_llServerPretreatmentStart != 0)
		{
			dwApplyResourceTime	 = (DWORD)(1000000 * (stStatisticsInfo.m_llServerExecuteStart - stStatisticsInfo.m_llServerPretreatmentStart) / stStatisticsInfo.m_llServerFrequence);//���㵽΢����
		}
		else
		{
			dwApplyResourceTime = 0;
		}
		if(stStatisticsInfo.m_llServerIndexSearchEnd > stStatisticsInfo.m_llServerExecuteStart && stStatisticsInfo.m_llServerExecuteStart != 0)
		{
			dwIndexSerchTime = (DWORD)(1000000 * (stStatisticsInfo.m_llServerIndexSearchEnd - stStatisticsInfo.m_llServerExecuteStart) / stStatisticsInfo.m_llServerFrequence);//���㵽΢����
		}
		else
		{
			dwIndexSerchTime = 0;
		}

		if(stStatisticsInfo.m_llServerExecuteEnd > stStatisticsInfo.m_llServerIndexSearchEnd && stStatisticsInfo.m_llServerIndexSearchEnd != 0)
		{
			dwDataExtractTime	 = (DWORD)(1000000 * (stStatisticsInfo.m_llServerExecuteEnd - stStatisticsInfo.m_llServerIndexSearchEnd) / stStatisticsInfo.m_llServerFrequence);//���㵽΢����
		}
		else
		{
			dwDataExtractTime = 0;
		}



		if(stStatisticsInfo.m_llServerExecuteEnd > stStatisticsInfo.m_llServerExecuteStart && stStatisticsInfo.m_llServerExecuteStart != 0)
		{
			dwServerExecuteTime	 = (DWORD)(1000000 * (stStatisticsInfo.m_llServerExecuteEnd - stStatisticsInfo.m_llServerExecuteStart) / stStatisticsInfo.m_llServerFrequence);//���㵽΢����
		}
		else
		{
			dwServerExecuteTime	 = 0;
		}

		if(stStatisticsInfo.m_llServerWriteLogEnd > stStatisticsInfo.m_llServerExecuteEnd && stStatisticsInfo.m_llServerExecuteEnd != 0)
		{
			dwWriteLogTime		 = (DWORD)(1000000 * (stStatisticsInfo.m_llServerWriteLogEnd - stStatisticsInfo.m_llServerExecuteEnd) / stStatisticsInfo.m_llServerFrequence);//���㵽΢����
		}
		else
		{
			dwWriteLogTime		 = 0;
		}

		if(stStatisticsInfo.m_llServerEnd > stStatisticsInfo.m_llServerWriteLogEnd && stStatisticsInfo.m_llServerWriteLogEnd != 0)
		{
			dwReleaseResourceTime	 = (DWORD)(1000000 * (stStatisticsInfo.m_llServerEnd - stStatisticsInfo.m_llServerWriteLogEnd) / stStatisticsInfo.m_llServerFrequence);//���㵽΢����
		}
		else
		{
			dwReleaseResourceTime = 0;
		}
	}
	if(stStatisticsInfo.m_llFrequence == 0)
	{
		dwClientIme			 = 0;
		dwClientParseIme	 = 0;
		dwServerCallTime	 = 0;
		dwClientReceiveIme	 = 0;
	}
	else
	{
		FileTimeToSystemTime((FILETIME *)&stStatisticsInfo.m_ftStartTime, &stStart);
		FileTimeToSystemTime((FILETIME *)&stStatisticsInfo.m_ftEndTime, &stEnd);
		if(stStatisticsInfo.m_llEnd > stStatisticsInfo.m_llStart && stStatisticsInfo.m_llStart != 0)
		{
			dwClientIme		 = (DWORD)(1000000 * (stStatisticsInfo.m_llEnd - stStatisticsInfo.m_llStart) / stStatisticsInfo.m_llFrequence);//���㵽΢����
		}
		else
		{
			dwClientIme		 = 0;
		}

		if(stStatisticsInfo.m_llParseEnd > stStatisticsInfo.m_llStart && stStatisticsInfo.m_llStart != 0)
		{
			dwClientParseIme	 = (DWORD)(1000000 * (stStatisticsInfo.m_llParseEnd - stStatisticsInfo.m_llStart) / stStatisticsInfo.m_llFrequence);//���㵽΢����
		}
		else
		{
			dwClientParseIme	 = 0;
		}

		if(stStatisticsInfo.m_llReceiveEnd > stStatisticsInfo.m_llParseEnd && stStatisticsInfo.m_llParseEnd != 0)
		{
			dwServerCallTime = (DWORD)(1000000 * (stStatisticsInfo.m_llReceiveEnd - stStatisticsInfo.m_llParseEnd) / stStatisticsInfo.m_llFrequence);//���㵽΢����
		}
		else
		{
			dwServerCallTime = 0;
		}

		if(stStatisticsInfo.m_llEnd > stStatisticsInfo.m_llReceiveEnd && stStatisticsInfo.m_llReceiveEnd != 0)
		{
			dwClientReceiveIme	 = (DWORD)(1000000 * (stStatisticsInfo.m_llEnd - stStatisticsInfo.m_llReceiveEnd) / stStatisticsInfo.m_llFrequence);//���㵽΢����
		}
		else
		{
			dwClientReceiveIme	 = 0;
		}
	}

	strText = _T("");
	if(0 == nSqlType)
	{
		strText.Format(_T("�ܺ�ʱ��%.3lfs\r\n"), (double)dwClientIme/1000000.0);
	}
	else if(1 == nSqlType)
	{
		//DQL���
		dwOtherTime = dwServerTime - dwPrepareTime - dwIndexSerchTime - dwDataExtractTime;
		strTemp.Format(_T("����˺�ʱ��%d΢�룬�ͻ��˺�ʱ��%d΢�룬�����ʱ��%d΢�룬����%d����¼��\r\n"), dwServerTime, dwClientIme, dwDisplay, lAffectCount);
		strText += strTemp;
		if(stStatisticsInfo.m_llFrequence != 0)
		{
			strTemp.Format(_T("ִ�п�ʼʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d������ʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d��\r\n"), 
				stStart.wYear, stStart.wMonth, stStart.wDay, stStart.wHour, stStart.wMinute, stStart.wSecond, stStart.wMilliseconds,
				stEnd.wYear, stEnd.wMonth, stEnd.wDay, stEnd.wHour, stEnd.wMinute, stEnd.wSecond, stEnd.wMilliseconds);
			strText += strTemp;
		}
		if(stStatisticsInfo.m_llServerFrequence != 0)
		{
			strTemp.Format(_T("����ִ�п�ʼʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d������ʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d��\r\n"), 
				stServerStart.wYear, stServerStart.wMonth, stServerStart.wDay, stServerStart.wHour, stServerStart.wMinute, stServerStart.wSecond, stServerStart.wMilliseconds,
				stServerEnd.wYear, stServerEnd.wMonth, stServerEnd.wDay, stServerEnd.wHour, stServerEnd.wMinute, stServerEnd.wSecond, stServerEnd.wMilliseconds);
			strText += strTemp;

			strTemp.Format(_T("�����   ����׼����%d΢�룬����ɨ�裺%d΢�룬������ȡ��%d΢�룬����ʱ�䣺%d΢�룬\r\n"), 
				dwPrepareTime, dwIndexSerchTime, dwDataExtractTime, dwOtherTime);
			strText += strTemp;
		}
		if(stStatisticsInfo.m_llFrequence != 0)
		{
			strTemp.Format(_T("�ͻ���   ���ݴ�����%d΢�룬������ã�%d΢�룬���ݽ��գ�%d΢��\r\n"), dwClientParseIme, dwServerCallTime, dwClientReceiveIme);
			strText += strTemp;
		}
	}
	else if(2 == nSqlType)
	{
		//DML���
		dwOtherTime = dwServerTime - dwPrepareTime - dwApplyResourceTime - dwServerExecuteTime - dwWriteLogTime - dwReleaseResourceTime;
		strTemp.Format(_T("����ִ�к�ʱ��%d΢�룬�ͻ���ִ�к�ʱ��%d΢�룬������պ�ʱ��%d΢�룬����ֵ��%d��\r\n"), dwServerTime, dwClientIme, dwDisplay, lAffectCount);
		strText += strTemp;
		if(stStatisticsInfo.m_llFrequence != 0)
		{
			strTemp.Format(_T("ִ�п�ʼʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d������ʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d��\r\n"), 
				stStart.wYear, stStart.wMonth, stStart.wDay, stStart.wHour, stStart.wMinute, stStart.wSecond, stStart.wMilliseconds,
				stEnd.wYear, stEnd.wMonth, stEnd.wDay, stEnd.wHour, stEnd.wMinute, stEnd.wSecond, stEnd.wMilliseconds);
			strText += strTemp;
		}
		if(stStatisticsInfo.m_llServerFrequence != 0)
		{
			strTemp.Format(_T("����ִ�п�ʼʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d������ʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d��\r\n"), 
				stServerStart.wYear, stServerStart.wMonth, stServerStart.wDay, stServerStart.wHour, stServerStart.wMinute, stServerStart.wSecond, stServerStart.wMilliseconds,
				stServerEnd.wYear, stServerEnd.wMonth, stServerEnd.wDay, stServerEnd.wHour, stServerEnd.wMinute, stServerEnd.wSecond, stServerEnd.wMilliseconds);
			strText += strTemp;
			strTemp.Format(_T("�����   ����׼����%d΢�룬��Դ���룺%d΢�룬����ִ�У�%d΢�룬д����־��%d΢�룬��Դ�ͷţ�%d΢�룬����ʱ�䣺%d΢�룬\r\n"), 
				dwPrepareTime, dwApplyResourceTime, dwServerExecuteTime, dwWriteLogTime, dwReleaseResourceTime, dwOtherTime);
			strText += strTemp;
		}
		if(stStatisticsInfo.m_llFrequence != 0)
		{
			strTemp.Format(_T("�ͻ���   ���ݴ�����%d΢�룬������ã�%d΢��\r\n"), dwClientParseIme, dwServerCallTime);
			strText += strTemp;
		}
	}
	else if(3 == nSqlType)
	{
		//DDL���
		dwOtherTime = dwServerTime - dwPrepareTime - dwApplyResourceTime - dwServerExecuteTime - dwWriteLogTime - dwReleaseResourceTime;
		strTemp.Format(_T("����ִ�к�ʱ��%d΢�룬�ͻ���ִ�к�ʱ��%d΢�룬������պ�ʱ��%d΢�룬����ֵ��%d��\r\n"), dwServerTime, dwClientIme, dwDisplay, lAffectCount);
		strText += strTemp;
		if(stStatisticsInfo.m_llFrequence != 0)
		{
			strTemp.Format(_T("ִ�п�ʼʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d������ʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d��\r\n"), 
				stStart.wYear, stStart.wMonth, stStart.wDay, stStart.wHour, stStart.wMinute, stStart.wSecond, stStart.wMilliseconds,
				stEnd.wYear, stEnd.wMonth, stEnd.wDay, stEnd.wHour, stEnd.wMinute, stEnd.wSecond, stEnd.wMilliseconds);
			strText += strTemp;
		}
		if(stStatisticsInfo.m_llServerFrequence != 0)
		{
			strTemp.Format(_T("����ˣ�ִ�п�ʼʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d������ʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d��\r\n"), 
				stServerStart.wYear, stServerStart.wMonth, stServerStart.wDay, stServerStart.wHour, stServerStart.wMinute, stServerStart.wSecond, stServerStart.wMilliseconds,
				stServerEnd.wYear, stServerEnd.wMonth, stServerEnd.wDay, stServerEnd.wHour, stServerEnd.wMinute, stServerEnd.wSecond, stServerEnd.wMilliseconds);
			strText += strTemp;
			strTemp.Format(_T("�����   ����׼����%d΢�룬��Դ���룺%d΢�룬����ִ�У�%d΢�룬д����־��%d΢�룬��Դ�ͷţ�%d΢�룬����ʱ�䣺%d΢�룬\r\n"), 
				dwPrepareTime, dwApplyResourceTime, dwServerExecuteTime, dwWriteLogTime, dwReleaseResourceTime, dwOtherTime);
			strText += strTemp;
		}
		if(stStatisticsInfo.m_llFrequence != 0)
		{
			strTemp.Format(_T("�ͻ���   ���ݴ�����%d΢�룬������ã�%d΢��\r\n"), dwClientParseIme, dwServerCallTime);
			strText += strTemp;
		}
	}
	else if (4 == nSqlType)
	{
		//����Ӧ�ý�����
		//���������
		dwOtherTime = dwServerTime - dwPrepareTime - dwApplyResourceTime - dwServerExecuteTime - dwWriteLogTime - dwReleaseResourceTime;
		strTemp.Format(_T("����ִ�к�ʱ��%d΢�룬�ͻ���ִ�к�ʱ��%d΢�룬������պ�ʱ��%d΢�룬����ֵ��%d��\r\n"), dwServerTime, dwClientIme, dwDisplay, lAffectCount);
		strText += strTemp;
		if(stStatisticsInfo.m_llFrequence != 0)
		{
			strTemp.Format(_T("ִ�п�ʼʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d������ʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d��\r\n"), 
				stStart.wYear, stStart.wMonth, stStart.wDay, stStart.wHour, stStart.wMinute, stStart.wSecond, stStart.wMilliseconds,
				stEnd.wYear, stEnd.wMonth, stEnd.wDay, stEnd.wHour, stEnd.wMinute, stEnd.wSecond, stEnd.wMilliseconds);
			strText += strTemp;
		}
		if(stStatisticsInfo.m_llServerFrequence != 0)
		{
			strTemp.Format(_T("����ִ�п�ʼʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d������ʱ�䣺%04d-%02d-%02d %02d:%02d:%02d.%03d��\r\n"), 
				stServerStart.wYear, stServerStart.wMonth, stServerStart.wDay, stServerStart.wHour, stServerStart.wMinute, stServerStart.wSecond, stServerStart.wMilliseconds,
				stServerEnd.wYear, stServerEnd.wMonth, stServerEnd.wDay, stServerEnd.wHour, stServerEnd.wMinute, stServerEnd.wSecond, stServerEnd.wMilliseconds);
			strText += strTemp;
			strTemp.Format(_T("�����   ����׼����%d΢�룬��Դ���룺%d΢�룬����ִ�У�%d΢�룬д����־��%d΢�룬��Դ�ͷţ�%d΢�룬����ʱ�䣺%d΢�룬\r\n"), 
				dwPrepareTime, dwApplyResourceTime, dwServerExecuteTime, dwWriteLogTime, dwReleaseResourceTime, dwOtherTime);
			strText += strTemp;
		}
		if(stStatisticsInfo.m_llFrequence != 0)
		{
			strTemp.Format(_T("�ͻ���   ���ݴ�����%d΢�룬������ã�%d΢��\r\n"), dwClientParseIme, dwServerCallTime);
			strText += strTemp;
		}
	}
	m_dlgMainTabQueryInfo.TextShow(strText);
}

void CMainTabQuery::TabQueryChange(int nIndex)
{
	m_tabQuery.SetCurSel(nIndex);
	switch (nIndex)
	{
	case 0:
		m_dlgMainTabQueryResult.ShowWindow(TRUE);
		m_dlgMainTabQueryInfo.ShowWindow(FALSE);
		break;
	case 1:
		m_dlgMainTabQueryResult.ShowWindow(FALSE);
		m_dlgMainTabQueryInfo.ShowWindow(TRUE);
		break;
	default:
		break;
	}
}

void CMainTabQuery::MakeUpper()
{
	long nStartChar, nEndChar;
	CString strInput, strLeft, strMid, strRight, strOutput;

	nStartChar = -1;
	nEndChar = -1;
	m_reSql.GetSel(nStartChar, nEndChar);
	if(nEndChar - nStartChar > 0)
	{
		strInput = m_reSql.GetSelText();
		strInput.MakeUpper();
		m_reSql.ReplaceSel(strInput);
		m_reSql.SetSel(nStartChar, nEndChar);
	}
	else
	{
		m_reSql.GetWindowText(strInput);
		strOutput = strInput.MakeUpper();
		m_reSql.SetWindowText(strOutput);
	}
}

void CMainTabQuery::MakeLower()
{
	long nStartChar, nEndChar;
	CString strInput, strLeft, strMid, strRight, strOutput;

	nStartChar = -1;
	nEndChar = -1;
	m_reSql.GetSel(nStartChar, nEndChar);
	if(nEndChar - nStartChar > 0)
	{
		strInput = m_reSql.GetSelText();
		strInput.MakeLower();
		m_reSql.ReplaceSel(strInput);
		m_reSql.SetSel(nStartChar, nEndChar);
	}
	else
	{
		m_reSql.GetWindowText(strInput);
		strOutput = strInput.MakeLower();
		m_reSql.SetWindowText(strOutput);
	}
}


//////////////////////////////////////////////////////////////////////////
//�ؼ���Ӧ
void CMainTabQuery::OnTcnSelchangeTabQuery(NMHDR *pNMHDR, LRESULT *pResult)
{
	int nCurSel = m_tabQuery.GetCurSel();
	TabQueryChange(nCurSel);

	*pResult = 0;
}

void CMainTabQuery::OnSize(UINT nType, int cx, int cy)
{
	CRect rtCtrl, rtClient;
	CDialog::OnSize(nType, cx, cy);

	//�ƶ������ڴ�С
	GetClientRect(rtClient);
	m_reSql.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.right = rtClient.right;
	m_reSql.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
	m_ctrlSeparator.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.right = rtClient.right;
	m_ctrlSeparator.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
	m_tabQuery.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.right = rtClient.right;
	rtCtrl.bottom = rtClient.bottom;
	m_tabQuery.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);

	rtCtrl.top += 22; 
	rtCtrl.bottom -= 2; 
	rtCtrl.left += 2; 
	rtCtrl.right -= 2;

	m_dlgMainTabQueryResult.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
	m_dlgMainTabQueryInfo.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
}

void CMainTabQuery::OnCancel()
{
	//CDialog::OnCancel();
}

void CMainTabQuery::OnOK()
{
	//CDialog::OnOK();
}

void CMainTabQuery::OnMouseMove(UINT nFlags, CPoint point)
{
	int iOffsetY;
	CRect rtSQL, rtQuery, rtSplit;
	if(m_bSpliting)
	{
		iOffsetY = point.y - m_ptOld.y;
		m_reSql.GetWindowRect(rtSQL);
		m_tabQuery.GetWindowRect(rtQuery);
		m_ctrlSeparator.GetWindowRect(rtSplit);
		ScreenToClient(rtSQL);
		ScreenToClient(rtQuery);
		ScreenToClient(rtSplit);
		if(rtSQL.top + 50 < rtSplit.top + iOffsetY
			&& rtQuery.bottom - 100 > rtSplit.top + iOffsetY)//���ſؼ�
		{
			rtSplit.OffsetRect(0,iOffsetY);
			m_ctrlSeparator.MoveWindow(rtSplit);
			m_ptOld = point;
			m_iOffsetY += iOffsetY;
		}
	}
	else
	{
		m_ctrlSeparator.GetWindowRect(rtSplit);
		ScreenToClient(rtSplit);
		if(rtSplit.PtInRect(point))
			SetCursor(LoadCursor(NULL,IDC_SIZENS));
	}

	CDialog::OnMouseMove(nFlags, point);
}

void CMainTabQuery::OnLButtonDown(UINT nFlags, CPoint point)
{
	CRect rtSplit;
	m_ctrlSeparator.GetWindowRect(rtSplit);
	ScreenToClient(rtSplit);
	if(rtSplit.PtInRect(point))
	{
		SetCursor(LoadCursor(NULL,IDC_SIZENS));
		m_bSpliting = TRUE;
		m_ptOld = point;
		m_iOffsetY = 0;
		m_ctrlSeparator.ShowWindow(SW_SHOW);
		SetCapture();
	}
	CDialog::OnLButtonDown(nFlags, point);
}

void CMainTabQuery::OnLButtonUp(UINT nFlags, CPoint point)
{
	CRect rtSQL, rtQuery;
	if(m_bSpliting)
	{
		m_reSql.GetWindowRect(rtSQL);
		m_tabQuery.GetWindowRect(rtQuery);
		ScreenToClient(rtSQL);
		ScreenToClient(rtQuery);
		rtSQL.bottom += m_iOffsetY;
		rtQuery.top += m_iOffsetY;		
		m_tabQuery.MoveWindow(rtQuery);

		rtQuery.top += 22; 
		rtQuery.bottom -= 2; 
		rtQuery.left += 2; 
		rtQuery.right -= 2;
		m_dlgMainTabQueryResult.SetWindowPos(NULL, 0, 0, rtQuery.Width(), rtQuery.Height(), SWP_NOMOVE | SWP_NOZORDER);
		m_dlgMainTabQueryInfo.SetWindowPos(NULL, 0, 0, rtQuery.Width(), rtQuery.Height(), SWP_NOMOVE | SWP_NOZORDER);

		m_reSql.MoveWindow(rtSQL);
		m_ctrlSeparator.ShowWindow(SW_HIDE);
		ReleaseCapture();
	}
	m_bSpliting = FALSE;
	CDialog::OnLButtonUp(nFlags, point);
}
