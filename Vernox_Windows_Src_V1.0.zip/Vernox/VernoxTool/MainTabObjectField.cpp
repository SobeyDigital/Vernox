/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MainTabObjectField.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "MainTabObjectField.h"


// CMainTabObjectField �Ի���

IMPLEMENT_DYNAMIC(CMainTabObjectField, CDialog)

CMainTabObjectField::CMainTabObjectField(CWnd* pParent /*=NULL*/)
	: CDialog(CMainTabObjectField::IDD, pParent)
{
	m_nRow = 0;
	m_nCol = 0;
	m_nExistedCount = -1;
}

CMainTabObjectField::~CMainTabObjectField()
{
}

void CMainTabObjectField::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_OBJECT, m_listObject);
	DDX_Control(pDX, IDC_EDIT_TEMP, m_editTemp);
	DDX_Control(pDX, IDC_COMBO_TEMP, m_cbTemp);
}

BOOL CMainTabObjectField::OnInitDialog()
{
	CDialog::OnInitDialog();

	//��ʼ���ؼ�
	m_listObject.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_INFOTIP);

	m_listObject.InsertColumn(0, _T(""), LVCFMT_LEFT, 20);
	m_listObject.InsertColumn(1, _T("�ֶ���"), LVCFMT_LEFT, 100);
	m_listObject.InsertColumn(2, _T("��������"), LVCFMT_LEFT, 100);
	m_listObject.InsertColumn(3, _T("����"), LVCFMT_LEFT, 100);
	m_listObject.InsertColumn(4, _T("������ֵ��NULL��"), LVCFMT_LEFT, 120);

	m_listObject.InsertItem(0, _T("."));

	m_editTemp.ShowWindow(SW_HIDE);
	m_cbTemp.ShowWindow(SW_HIDE);

	return TRUE;
}

BEGIN_MESSAGE_MAP(CMainTabObjectField, CDialog)
	ON_NOTIFY(NM_CLICK, IDC_LIST_OBJECT, &CMainTabObjectField::OnNMClickListObject)
	ON_EN_KILLFOCUS(IDC_EDIT_TEMP, &CMainTabObjectField::OnEnKillfocusEditTemp)
	ON_CBN_KILLFOCUS(IDC_COMBO_TEMP, &CMainTabObjectField::OnCbnKillfocusComboTemp)
	ON_WM_SIZE()
END_MESSAGE_MAP()


// CMainTabObjectField ��Ϣ��������

void CMainTabObjectField::AddItem(CString strFirstColValue)
{
	int nColumnCount = m_listObject.GetItemCount();

	m_listObject.InsertItem(nColumnCount, strFirstColValue);
}

void CMainTabObjectField::DeleteItem()
{
	int i, nColumnCount;
	nColumnCount = m_listObject.GetItemCount();
	//������ɾ�����һ���ֶ�
	if (nColumnCount <= 1)
	{
		return;
	}

	for (i = nColumnCount - 1; i >= 0; i--) 
	{ 
		if (m_listObject.GetItemState(i, LVIS_SELECTED) == LVIS_SELECTED)		//��i�б�ѡ��
		{
			if (m_nExistedCount <= 1)
			{
				CMessageBox(_T("��Ҫ��������һ���ֶΣ�"));
				break;
			}
			m_listObject.DeleteItem(i);
			m_nExistedCount--;
		}
	}
}

void CMainTabObjectField::SetExistedCount(int nCount)
{
	m_nExistedCount = nCount;
}

//////////////////////////////////////////////////////////////////////////

void CMainTabObjectField::OnNMClickListObject(NMHDR *pNMHDR, LRESULT *pResult)
{
	*pResult = 0;

	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<NMITEMACTIVATE*>(pNMHDR);

	NM_LISTVIEW* pNMListView=(NM_LISTVIEW*)pNMHDR;
	CRect rc;
	m_nRow = pNMListView->iItem;		//���ѡ�е���  
	m_nCol = pNMListView->iSubItem;		//���ѡ���� 

	if (m_nRow == -1 || m_nCol == 0 || m_nRow < m_nExistedCount)
	{
		return;
	}

	if (m_nCol == 1 || m_nCol == 3)		//�༭�� 
	{  
		m_listObject.GetSubItemRect(m_nRow, m_nCol, LVIR_LABEL, rc);		//��������RECT 
		m_editTemp.SetParent(&m_listObject);								//ת������Ϊ�б����е�����
		m_editTemp.MoveWindow(rc);											//�ƶ�Edit��RECT���ڵ�λ�� 
		m_editTemp.SetWindowText(m_listObject.GetItemText(m_nRow, m_nCol));	//���������е�ֵ����Edit�ؼ���  
		m_editTemp.ShowWindow(SW_SHOW);										//��ʾEdit�ؼ�  
		m_editTemp.SetFocus();												//����Edit����
		m_editTemp.ShowCaret();												//��ʾ���
		m_editTemp.SetSel(-1);												//������ƶ������
	}
	else if (m_nCol == 2 || m_nCol == 4)		//������
	{
		m_listObject.GetSubItemRect(m_nRow, m_nCol, LVIR_LABEL, rc);		//��������RECT
		m_cbTemp.SetParent(&m_listObject);									//ת������Ϊ�б����е�����
		m_cbTemp.MoveWindow(rc);											//�ƶ�Edit��RECT���ڵ�λ��
		m_cbTemp.SetWindowText(m_listObject.GetItemText(m_nRow, m_nCol));	//���������е�ֵ����Edit�ؼ���		//û������
		m_cbTemp.ShowWindow(SW_SHOW);										//��ʾEdit�ؼ�
		m_cbTemp.SetFocus();												//����Edit����

		m_cbTemp.ResetContent();
		if (m_nCol == 2)
		{
			m_cbTemp.AddString(_T("int"));
			m_cbTemp.AddString(_T("bigint"));
			m_cbTemp.AddString(_T("double"));
			m_cbTemp.AddString(_T("date"));
			m_cbTemp.AddString(_T("char"));
			m_cbTemp.AddString(_T("varchar"));
			m_cbTemp.AddString(_T("clob"));
			m_cbTemp.AddString(_T("blob"));
		}
		else if (m_nCol == 4)
		{
			m_cbTemp.AddString(_T("no"));
			m_cbTemp.AddString(_T("yes"));
		}
	}
}

void CMainTabObjectField::OnEnKillfocusEditTemp()
{
	CString strTemp;  
	m_editTemp.GetWindowText(strTemp);						//�õ��û�������µ�����  
	m_listObject.SetItemText(m_nRow, m_nCol, strTemp);		//���ñ༭���������  
	m_editTemp.ShowWindow(SW_HIDE);							//���ر༭�� 
}

void CMainTabObjectField::OnCbnKillfocusComboTemp()
{
	CString strTemp;  
	m_cbTemp.GetWindowText(strTemp);						//�õ��û�������µ�����
	if (strTemp != _T(""))
	{
		m_listObject.SetItemText(m_nRow, m_nCol, strTemp);	//���ñ༭���������
		if (m_nCol == 2)
		{
			if (strTemp.CompareNoCase(_T("int")) == 0)
			{
				m_listObject.SetItemText(m_nRow, 3, _T("4"));
			} 
			else if (strTemp.CompareNoCase(_T("bigint")) == 0)
			{
				m_listObject.SetItemText(m_nRow, 3, _T("8"));
			}
			else if (strTemp.CompareNoCase(_T("double")) == 0)
			{
				m_listObject.SetItemText(m_nRow, 3, _T("8"));
			}
			else if (strTemp.CompareNoCase(_T("date")) == 0)
			{
				m_listObject.SetItemText(m_nRow, 3, _T("8"));
			}
			else if (strTemp.CompareNoCase(_T("char")) == 0)
			{
				m_listObject.SetItemText(m_nRow, 3, _T(""));
			}
			else if (strTemp.CompareNoCase(_T("varchar")) == 0)
			{
				m_listObject.SetItemText(m_nRow, 3, _T("255"));
			}
			else if (strTemp.CompareNoCase(_T("clob")) == 0)
			{
				m_listObject.SetItemText(m_nRow, 3, _T("255"));
			}
			else if (strTemp.CompareNoCase(_T("blob")) == 0)
			{
				m_listObject.SetItemText(m_nRow, 3, _T("255"));
			}
			else
			{
				m_listObject.SetItemText(m_nRow, 3, _T(""));
			}
		}
	} 
	m_cbTemp.ShowWindow(SW_HIDE);							//���ر༭�� 
}
void CMainTabObjectField::OnCancel()
{
	//CDialog::OnCancel();
}

void CMainTabObjectField::OnOK()
{
	//CDialog::OnOK();
}

void CMainTabObjectField::OnSize(UINT nType, int cx, int cy)
{
	CRect rtCtrl, rtClient;
	CDialog::OnSize(nType, cx, cy);

	//�ƶ������ڴ�С
	GetClientRect(rtClient);
	m_listObject.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.right = rtClient.right - 2;
	rtCtrl.bottom = rtClient.bottom - 2;
	m_listObject.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
}
