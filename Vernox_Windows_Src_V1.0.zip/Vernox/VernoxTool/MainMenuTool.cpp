/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MainMenuTool.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "SobeyMemToolDlg.h"
//#include "MainMenuTool.h"


// CMainMenuTool �Ի���

IMPLEMENT_DYNAMIC(CMainMenuTool, CDialog)

CMainMenuTool::CMainMenuTool(CWnd* pParent /*=NULL*/)
	: CDialog(CMainMenuTool::IDD, pParent)
{

}

CMainMenuTool::~CMainMenuTool()
{
}

void CMainMenuTool::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMainMenuTool, CDialog)
	ON_BN_CLICKED(IDC_BTN_USER_MANAGER, &CMainMenuTool::OnBnClickedBtnUserManager)
END_MESSAGE_MAP()


// CMainMenuTool ��Ϣ��������

void CMainMenuTool::OnBnClickedBtnUserManager()
{
	CSobeyMemToolDlg *pParent;
	pParent = (CSobeyMemToolDlg*)GetParent()->GetParent();

	m_dlgToolUserManager.SetInitData(pParent->m_dlgLogin.m_strUserID);
	m_dlgToolUserManager.DoModal();
}

void CMainMenuTool::OnOK()
{
	//CDialog::OnOK();
}

void CMainMenuTool::OnCancel()
{
	//CDialog::OnCancel();
}