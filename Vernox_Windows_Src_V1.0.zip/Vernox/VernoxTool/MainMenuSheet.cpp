/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MainMenuSheet.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "SobeyMemToolDlg.h"		//�����Ѿ������� MainMenuSheet.h
#include "MainMenuSheet.h"
#include "DlgProgress.h"



// CMainMenuSheet �Ի���

IMPLEMENT_DYNAMIC(CMainMenuSheet, CDialog)

CMainMenuSheet::CMainMenuSheet(CWnd* pParent /*=NULL*/)
	: CDialog(CMainMenuSheet::IDD, pParent)
{

}

CMainMenuSheet::~CMainMenuSheet()
{
}

void CMainMenuSheet::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMainMenuSheet, CDialog)
	ON_BN_CLICKED(IDC_BTN_CREATE_OBJECT, &CMainMenuSheet::OnBnClickedBtnCreateObject)
	ON_BN_CLICKED(IDC_BTN_EDIT_OBJECT, &CMainMenuSheet::OnBnClickedBtnEditObject)
	ON_BN_CLICKED(IDC_BTN_EXPORT_OBJECT, &CMainMenuSheet::OnBnClickedBtnExportObject)
	ON_BN_CLICKED(IDC_BTN_IMPORT_OBJECT, &CMainMenuSheet::OnBnClickedBtnImportObject)
	ON_BN_CLICKED(IDC_BTN_QUERY_OBJECT, &CMainMenuSheet::OnBnClickedBtnQueryObject)
END_MESSAGE_MAP()


// CMainMenuSheet ��Ϣ��������

void CMainMenuSheet::OnBnClickedBtnCreateObject()
{
	CSobeyMemToolDlg *pParent;
	pParent = (CSobeyMemToolDlg*)GetParent()->GetParent();
	pParent->CreateNewMainTabPage(MF_TABPAGE_TYPE_CREATE_OBJECT);
}

void CMainMenuSheet::OnBnClickedBtnEditObject()
{
	CSobeyMemToolDlg *pParent;
	pParent = (CSobeyMemToolDlg*)GetParent()->GetParent();
	pParent->CreateNewMainTabPage(MF_TABPAGE_TYPE_EDIT_OBJECT);
}

void CMainMenuSheet::OnBnClickedBtnQueryObject()
{
	CSobeyMemToolDlg *pParent;
	pParent = (CSobeyMemToolDlg*)GetParent()->GetParent();
	pParent->CreateNewMainTabPage(MF_TABPAGE_TYPE_QUERY_OBJECT);
}

void CMainMenuSheet::OnBnClickedBtnExportObject()
{
	CSobeyMemToolDlg *pParent;
	pParent = (CSobeyMemToolDlg*)GetParent()->GetParent();

	if (IDOK == m_dlgObjectSelect.DoModal())
	{
		CDlgProgress dlg;
		dlg.m_strTitle = _T("��������");
		dlg.m_plistObjectName = &m_dlgObjectSelect.m_listObject;
		dlg.m_strFileName = m_dlgObjectSelect.m_strExportFile;
		dlg.m_lpParam = this;
		dlg.m_pVernoxProgressCallback = ExportObjectThread;
		dlg.DoModal();
	} 
	else
	{
		;
	}
	return;

	int nLevel;
	HTREEITEM hItem;
	TCHAR lptDefaultDir[MAX_PATH];
	CString strObjectName, strTemp, strText, strDefaultName, strDefaultDir, strFilter, strExportFile;
	hItem = pParent->m_treeDB.GetSelectedItem();
	if (hItem == NULL)
	{
		CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�����ı���"));
		return;
	}
	strObjectName = pParent->m_treeDB.GetItemText(hItem);

	hItem = pParent->m_treeDB.GetParentItem(hItem);
	if (hItem == NULL)
	{
		CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�����ı���"));
		return;
	}
	strTemp = pParent->m_treeDB.GetItemText(hItem);
	if (strTemp != _T("��"))
	{
		CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�����ı���"));
		return;
	}

	nLevel = 1;
	while (hItem = pParent->m_treeDB.GetParentItem(hItem))
	{
		if (hItem == NULL)
		{
			break;
		}
		nLevel++;
	}
	if (nLevel != 2)
	{
		CMessageBox(_T("����������ݿ���Ϣ����ѡ����Ҫ�����ı���"));
		return;
	}
	GetModuleFileName(NULL, lptDefaultDir, MAX_PATH);
	(_tcsrchr(lptDefaultDir, '\\'))[0] = 0;
	(_tcsrchr(lptDefaultDir, '\\'))[1] = 0;
	strDefaultDir.Format(_T("%sData"), lptDefaultDir);
	strFilter = _T("�ļ� (*.db)|*.db|�����ļ� (*.*)|*.*||");
	strDefaultName.Format(_T("%s.db"), strObjectName);
	CFileDialog dlgFile(FALSE, NULL, strDefaultName, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, strFilter);
	dlgFile.GetOFN().lpstrInitialDir = strDefaultDir;  
	if (IDOK == dlgFile.DoModal())
	{
		strExportFile = dlgFile.GetPathName();
		strText.Format(_T("��������%s�����ݵ��ļ���%s��"), strObjectName, strExportFile);
		if (IDYES == CMessageBox(strText, MB_YESNO|MB_SYSTEMMODAL))
		{
			CDlgProgress dlg;
			dlg.m_strTitle = _T("��������");
			dlg.m_plistObjectName = &m_dlgObjectSelect.m_listObject;
			dlg.m_strFileName = strExportFile;
			dlg.m_lpParam = this;
			dlg.m_pVernoxProgressCallback = ExportObjectThread;
			dlg.DoModal();
		}
	}
}

void CMainMenuSheet::OnBnClickedBtnImportObject()
{
	TCHAR lptDefaultDir[MAX_PATH];
	CDBInterface *pSobeyInterface;
	CString strText, strImportFile, strDefaultDir, strFilter;
	pSobeyInterface = (CDBInterface*)(ISobeyDBConnection*)g_pSobeyInterface;

	GetModuleFileName(NULL, lptDefaultDir, MAX_PATH);
	(_tcsrchr(lptDefaultDir, '\\'))[0] = 0;
	(_tcsrchr(lptDefaultDir, '\\'))[1] = 0;
	strDefaultDir.Format(_T("%sData"), lptDefaultDir);
	strFilter = _T("�ļ� (*.db)|*.db|�����ļ� (*.*)|*.*||");
	CFileDialog dlgFile(TRUE, NULL, NULL, OFN_HIDEREADONLY|OFN_READONLY, strFilter);
	dlgFile.GetOFN().lpstrInitialDir = strDefaultDir;  
	if (IDOK == dlgFile.DoModal())
	{
		strImportFile = dlgFile.GetPathName();
		strText.Format(_T("�����ļ���%s��"), strImportFile);
		if (IDYES == CMessageBox(strText, MB_YESNO|MB_SYSTEMMODAL))
		{
			CDlgProgress dlg;
			dlg.m_strTitle = _T("�������");
			dlg.m_plistObjectName = NULL;
			dlg.m_strFileName	= strImportFile;
			dlg.m_lpParam		= this;
			dlg.m_pVernoxProgressCallback = ImportObjectThread;
			dlg.DoModal();
		}
		else
		{
			;
		}	
	} 
	else
	{
		;
	}
	CSobeyMemToolDlg *pParent;
	pParent = (CSobeyMemToolDlg*)GetParent()->GetParent();
	pParent->OnBnClickedBtnRefresh();
}

void CMainMenuSheet::OnOK()
{
	//CDialog::OnOK();
}

void CMainMenuSheet::OnCancel()
{
	//CDialog::OnCancel();
}

BOOL CALLBACK CMainMenuSheet::ExportObjectThread(CDlgProgress *pProgress, LPCTSTR lpszFileName, list<CString> &listObjectName, LPVOID lpParam)
{
	CString strText;
	int nRet, nCount;
	char lpFileName[MAX_PATH], *lpObjectNameArray, *lpObjectName;
	CDBInterface *pSobeyInterface;

	lpObjectNameArray = NULL;

	pSobeyInterface = (CDBInterface*)(ISobeyDBConnection*)g_pSobeyInterface;
	memset(lpFileName, 0, sizeof(lpFileName));
	WideCharToMultiByte(CP_ACP, 0, lpszFileName, -1, lpFileName, MAX_PATH, NULL, NULL);

	nCount = listObjectName.size();
	if (nCount < 1 || nCount > 255)
	{
		strText.Format(_T("��������%d���쳣����������������Ϊ��255"), nCount);
		::MessageBox(NULL, strText, _T("��ʾ"), MB_OK|MB_SYSTEMMODAL);
		return FALSE;
	}
	lpObjectNameArray = new char[nCount*MAX_PATH];
	memset(lpObjectNameArray, 0, nCount*MAX_PATH);
	list<CString>::iterator iter;
	lpObjectName = lpObjectNameArray;
	for (iter = listObjectName.begin(); iter != listObjectName.end(); iter++)
	{
		WideCharToMultiByte(CP_ACP, 0, *iter, -1, lpObjectName, MAX_PATH, NULL, NULL);
		lpObjectName[MAX_PATH-1] = 0;
		lpObjectName += MAX_PATH;
	}

	nRet = pSobeyInterface->ExportObject(lpObjectNameArray, nCount, lpFileName, VernoxProcessCallback, pProgress);
	if (nRet != 0)
	{
		strText.Format(_T("��������ʧ�ܣ������룺%d��%s����"), nRet, GetErrorWDescription(nRet));
		::MessageBox(NULL, strText, _T("��ʾ"), MB_OK|MB_SYSTEMMODAL);
		if (lpObjectNameArray != NULL)
		{
			delete[] lpObjectNameArray;
			lpObjectNameArray = NULL;
		}
		return FALSE;
	}
	else
	{
		strText.Format(_T("���������ļ���%s���ɹ���"), lpszFileName);
		::MessageBox(NULL, strText, _T("��ʾ"), MB_OK|MB_SYSTEMMODAL);
		if (lpObjectNameArray != NULL)
		{
			delete[] lpObjectNameArray;
			lpObjectNameArray = NULL;
		}
		return TRUE;
	}
	if (lpObjectNameArray != NULL)
	{
		delete[] lpObjectNameArray;
		lpObjectNameArray = NULL;
	}
	return TRUE;
}

BOOL CALLBACK CMainMenuSheet::ImportObjectThread(CDlgProgress *pProgress, LPCTSTR lpszFileName, list<CString> &listObjectName, LPVOID lpParam)
{
	int nRet;
	CString strText;
	char lpFileName[MAX_PATH];
	CDBInterface *pSobeyInterface;
	pSobeyInterface = (CDBInterface*)(ISobeyDBConnection*)g_pSobeyInterface;
	memset(lpFileName, 0, sizeof(lpFileName));
	WideCharToMultiByte(CP_ACP, 0, lpszFileName, -1, lpFileName, MAX_PATH, NULL, NULL);

	nRet = pSobeyInterface->ImportObject(lpFileName, VernoxProcessCallback, pProgress);
	if (nRet != 0)
	{
		strText.Format(_T("��������ʧ�ܣ������룺%d��%s����"), nRet, GetErrorWDescription(nRet));
		::MessageBox(NULL, strText, _T("��ʾ"), MB_OK|MB_SYSTEMMODAL);
		return FALSE;
	}
	else
	{
		strText.Format(_T("���������ļ���%s���ɹ���"), lpszFileName);
		::MessageBox(NULL, strText, _T("��ʾ"), MB_OK|MB_SYSTEMMODAL);
		return TRUE;
	}
	return TRUE;
}