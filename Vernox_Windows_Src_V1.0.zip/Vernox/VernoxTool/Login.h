/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "afxwin.h"

#include "LoginNewConnectConfig.h"

#define MF_TOOL_ID_MAX_LENGTH_WCHAR		23
#define MF_TOOL_ID_MAX_LENGTH_CHAR		MF_TOOL_ID_MAX_LENGTH_WCHAR*6
#define MF_TOOL_PW_MAX_LENGTH_WCHAR		23
#define MF_TOOL_PW_MAX_LENGTH_CHAR		MF_TOOL_PW_MAX_LENGTH_WCHAR*6

extern ISobeyDBConnectionPtr g_pSobeyInterface;
// CLogin �Ի���

class CLogin : public CDialog
{
	DECLARE_DYNAMIC(CLogin)

public:
	CLogin(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CLogin();

// �Ի�������
	enum { IDD = IDD_LOGIN };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	char m_cUserID[MF_TOOL_ID_MAX_LENGTH_CHAR+1];
	char m_cUserPW[MF_TOOL_PW_MAX_LENGTH_CHAR+1];

	char m_cWorkingPath[MAX_PATH];
	char m_cConfigPath[MAX_PATH];

	list<STRUCT_CONNECT_CONFIG> m_listConfig;

	CString m_strConnectName;
	char m_cConnectName[MAX_PATH];
	vector<ULONG> m_vecIP;
	vector<USHORT> m_vecPort;

	CLoginNewConnectConfig m_dlgLoginNewConnectConfig;

public:
	CString m_strUserID;
	CString m_strUserPW;
	CComboBox m_cbDatabase;

protected:
	int CMessageBox(LPCTSTR lpText, UINT nType = (MB_OK|MB_SYSTEMMODAL))
	{
		return MessageBox(lpText, 0, nType);
	}

private:
	BOOL ParseConnectConfig(FILE *fp);

public:
	BOOL ParseConnectConfig();

	BOOL IsCharacter(char c);

public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	
	afx_msg void OnCbnSelchangeComboDatabase();
};
