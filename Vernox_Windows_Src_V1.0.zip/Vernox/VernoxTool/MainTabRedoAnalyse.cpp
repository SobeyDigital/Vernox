/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MainTabRedoAnalyse.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "SobeyMemToolDlg.h"
#include "MainTabRedoAnalyse.h"
#include "..\VernoxBaseLib\RecordIterator.h"
//#include "MainTabRedoAnalyse.h"


// CMainTabRedoAnalyse �Ի���
#define PAGESIZE 100

extern int ExceptionHandlerBox(ULONG ulCode, EXCEPTION_POINTERS* lpExceptionPointer);

IMPLEMENT_DYNAMIC(CMainTabRedoAnalyse, CDialog)

CMainTabRedoAnalyse::CMainTabRedoAnalyse(CWnd* pParent /*=NULL*/)
	: CDialog(CMainTabRedoAnalyse::IDD, pParent)
	, m_nPageNo(0)
{
	
}

CMainTabRedoAnalyse::~CMainTabRedoAnalyse()
{
}

void CMainTabRedoAnalyse::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_RICHEDIT_REDO_ANALYSE, m_reRedoAnalyse);
	DDX_Control(pDX, IDC_PAGE, m_editPage);
}


BEGIN_MESSAGE_MAP(CMainTabRedoAnalyse, CDialog)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BTN_PRE, &CMainTabRedoAnalyse::OnBnClickedBtnPre)
	ON_BN_CLICKED(IDC_BTX_NEXT, &CMainTabRedoAnalyse::OnBnClickedBtxNext)
END_MESSAGE_MAP()


// CMainTabRedoAnalyse ��Ϣ��������

int CMainTabRedoAnalyse::RedoAnalyse(char* lpszRedoFilePath)
{
	
	FILE *fp;
	CString strText, strRedo, strTemp;
	char *lpBuffer;
	wchar_t *lpwBuffer;
	int nRet, nBufferSize, nPlanSize, m, n, nCount;
	LONGLONG llFileSize, llLeftByte, llTimestamp;
	LPEXECUTEPLANBSON lpExecutePlan;
	MF_REDOLOGFILEHEAD stFileHead;
	SYSTEMTIME stSysTime;
	FILETIME stLocalFileTime;

	fp = fopen(lpszRedoFilePath, "rb");
	if (NULL == fp)
	{
		strText.Format(_T("�򿪵����ļ�ʧ�ܣ��ļ�·����%s�������룺%d"), lpszRedoFilePath, GetLastError());
		CMessageBox(strText);
		return MF_FAILED;
	}
	if(m_pRedoFilePath[0] == 0)
	{
		memcpy(m_pRedoFilePath, lpszRedoFilePath, MAX_PATH);
	}

	fseek(fp, 0, SEEK_END);
	llFileSize = ftell(fp);
	llLeftByte = llFileSize;
	if (llFileSize < sizeof(MF_REDOLOGFILEHEAD))
	{
		fclose(fp);
		strText.Format(_T("�ļ���С�쳣���ļ���С��%d���ļ�ͷ��С��%d"), llFileSize, sizeof(MF_REDOLOGFILEHEAD));
		CMessageBox(strText);
		return MF_FAILED;
	}

	fseek(fp, 0, SEEK_SET);
	nRet = fread(&stFileHead, 1, sizeof(MF_REDOLOGFILEHEAD), fp);
	if (nRet != sizeof(MF_REDOLOGFILEHEAD))
	{
		fclose(fp);
		strText.Format(_T("��ȡ������־�ļ�ͷʧ�ܣ��������ȣ�%d�����۳��ȣ�%d���ļ��ܳ��ȣ�%d��"), nRet, sizeof(MF_REDOLOGFILEHEAD), llFileSize);
		CMessageBox(strText);
		return MF_FAILED;
	}
	llLeftByte -= sizeof(MF_REDOLOGFILEHEAD);
	if (strncmp(stFileHead.m_lpszFileFlag, "VernoxLog", 9) != 0)
	{
		fclose(fp);
		strText = _T("��֤�ļ�ͷʧ�ܣ��򿪵Ĳ���������־�ļ�");
		CMessageBox(strText);
		return MF_FAILED;
	}

	nBufferSize = 1024*1024;
	lpBuffer	= new char[nBufferSize];
	lpwBuffer	= new wchar_t[nBufferSize];
	memset(lpwBuffer, 0, nBufferSize*sizeof(wchar_t));
	strRedo = _T("");
	nRet = MF_OK;
	
	n = 0;
	m = 0;
	while (llLeftByte > 0)
	{
		nPlanSize = 0;
		nCount = fread(&nPlanSize, 1, sizeof(int), fp);
		if (nCount != sizeof(int) || nPlanSize > llLeftByte || nPlanSize == 0)
		{
			strTemp.Format(_T("��ȡִ�мƻ������쳣���������ȣ�%d�����۳��ȣ�%d��ִ�мƻ����ȣ�%d���ļ�ʣ�೤�ȣ�%d���ļ��ܳ��ȣ�%d��\r\n"), nCount, sizeof(int), nPlanSize, llLeftByte, llFileSize);
			strRedo += strTemp;
			goto RedoAnalyse_End;
		}
		
		n++;
		if(n / PAGESIZE < m_nPageNo - 1)
		{
			fseek(fp, nPlanSize - sizeof(int), SEEK_CUR);
			llLeftByte -= nPlanSize;

			if(llLeftByte <= 0)
			{
				return -1;
			}
			else
			{
				continue;
			}
		}
		m++;
		if(m > PAGESIZE)
		{
			break;
		}

		if(nPlanSize > nBufferSize)
		{
			nBufferSize = nPlanSize;
			delete[] lpBuffer;
			lpBuffer	= new char[nBufferSize];
			delete[] lpwBuffer;
			lpwBuffer	= new wchar_t[nBufferSize];
			memset(lpwBuffer, 0, nBufferSize*sizeof(wchar_t));
		}

		memset(lpBuffer, 0, nBufferSize);
		memcpy(lpBuffer, &nPlanSize, sizeof(int));
		nCount = fread(lpBuffer+sizeof(int), 1, nPlanSize-sizeof(int), fp);
		if (nCount != nPlanSize-sizeof(int))
		{
			strTemp.Format(_T("��ȡִ�мƻ�ʧ�ܣ��������ȣ�%d�����۳��ȣ�%d��ִ�мƻ����ȣ�%d���ļ�ʣ�೤�ȣ�%d���ļ��ܳ��ȣ�%d��\r\n"), nCount, nPlanSize-sizeof(int), nPlanSize, llLeftByte, llFileSize);
			strRedo += strTemp;
			goto RedoAnalyse_End;
		}
		llLeftByte -= nPlanSize;
		
		lpExecutePlan = (LPEXECUTEPLANBSON)lpBuffer;

		if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_UPDATERECORDSET)
		{
			int i, j;
			VARDATA varData;
			LPRECORDHEAD lpRecordHead;
			CRecordIterator stRecordIter;
			char* pFieldName, pValue[32];
			LPXMLFIELDINFO lpXmlFieldInfo;
			LPXMLFIELDBSON lpXmlFieldBson;
			LPBYTE lpPlanAddr, lpFieldValue;
			string strExecuteStep, strValue;
			LPOBJECTNAMEBSON lpObjectNameBson;
			LPUPDATERECORDSETPLANBSON lpUpdateRecordsetPlan;

			lpPlanAddr				= (LPBYTE)lpExecutePlan;
			lpUpdateRecordsetPlan	= (LPUPDATERECORDSETPLANBSON)(lpPlanAddr + lpExecutePlan->m_nCommandOffset);
			lpObjectNameBson		= (LPOBJECTNAMEBSON)(lpPlanAddr + lpUpdateRecordsetPlan->m_nObjectNameOffset);
			lpXmlFieldInfo			= (LPXMLFIELDINFO)(lpPlanAddr + lpUpdateRecordsetPlan->m_nFieldInfoOffset);

			stRecordIter.Inital(lpPlanAddr);
		
			strExecuteStep = "������";
			//��ȡ����
			memcpy(pValue, lpObjectNameBson->m_pObjectName, lpObjectNameBson->m_bLen);
			strExecuteStep += pValue;

			//��ȡ����
			strExecuteStep += ",";
			stRecordIter.Move2FirstRecord();
			for(i = 0; i < lpUpdateRecordsetPlan->m_nExecuteStepNum; i++)
			{
				stRecordIter.NextRecord(lpRecordHead);
				strExecuteStep += " ����";
				itoa(i + 1, pValue, 10);
				strExecuteStep += pValue;
				strExecuteStep += ": ";

				if(lpRecordHead->m_bType == MF_EXECUTE_STEP_INSERTDATA)
				{
					strExecuteStep += "�����¼(";
					sprintf(pValue, "%lld", lpRecordHead->m_nDataID);
					strExecuteStep += pValue;
					strExecuteStep += "){";
				}
				else if(lpRecordHead->m_bType == MF_EXECUTE_STEP_DELETEDATA)
				{
					strExecuteStep += "ɾ����¼(";
					sprintf(pValue, "%lld", lpRecordHead->m_nDataID);
					strExecuteStep += pValue;
					strExecuteStep += ")";
					continue;
				}
				else
				{
					strExecuteStep += "���¼�¼(";
					sprintf(pValue, "%lld", lpRecordHead->m_nDataID);
					strExecuteStep += pValue;
					strExecuteStep += "){";
				}

				lpXmlFieldBson = (LPXMLFIELDBSON)(lpPlanAddr + lpRecordHead->m_nFieldOffset);
				nCount		   = 0;
				for(j = 0; j < lpRecordHead->m_bFieldNum; j++)	
				{
					if(lpXmlFieldBson[j].m_bModify)
					{
						if(nCount != 0)
						{
							strExecuteStep += ",";
						}
						nCount++;

						if(lpXmlFieldBson[j].m_nFieldDataOffset != 0)
						{
							//��ȡ�ֶ���
							pFieldName = (char*)(lpPlanAddr + lpXmlFieldInfo[j].m_nFieldNameOffset);
							strExecuteStep += pFieldName;
							strExecuteStep += ":";
							//��ȡ�ֶ�ֵ
							lpFieldValue = lpPlanAddr + lpXmlFieldBson[j].m_nFieldDataOffset;
							nRet = GetValueFromFieldBuffer(lpXmlFieldInfo[j].m_bFieldType, lpFieldValue, varData);
							if(nRet != MF_OK)
							{
								goto RedoAnalyse_End;
							}

							switch(varData.m_vt)
							{
							case MF_VARDATA_INT:
								itoa(varData.m_nValue, pValue, 10);
								strExecuteStep += pValue;
								break;
							case MF_VARDATA_INT64:
								sprintf(pValue, "%lld", varData.m_llValue);
								strExecuteStep += pValue;
								break;
							case MF_VARDATA_DOUBLE:
								sprintf(pValue, "%.4f", varData.m_dblValue);
								strExecuteStep += pValue;
								break;
							case MF_VARDATA_DATE:
								tm* pTime;
								time_t tTime;

								tTime = ConvertDateToTime(varData.m_dblValue);
								pTime = localtime(&tTime);
								if(pTime == NULL)
								{
									strcpy(pValue, "Error");
								}
								else
								{
									sprintf(pValue, "%d-%02d-%02d %02d:%02d:%02d",pTime->tm_year+1900,pTime->tm_mon+1, pTime->tm_mday, pTime->tm_hour, pTime->tm_min, pTime->tm_sec);
								}
								strExecuteStep += pValue;
								break;		
							case MF_VARDATA_STRING:
								strValue = UTF8ConvertASC(varData.m_lpszValue);
								strExecuteStep += strValue;
								break;
							case MF_VARDATA_BINARY:
								strExecuteStep += (char*)varData.m_lpValue;
								break;
							}
						}
					}
				}
				strExecuteStep += "} ";
			}

			llTimestamp = lpExecutePlan->m_nTimestamp;
			llTimestamp = llTimestamp >> 2;
			FileTimeToLocalFileTime((FILETIME *)&llTimestamp, &stLocalFileTime);
			FileTimeToSystemTime(&stLocalFileTime, &stSysTime);

			nCount = MultiByteToWideChar(CP_ACP, 0, strExecuteStep.c_str(), strExecuteStep.length(), lpwBuffer, nBufferSize);
			lpwBuffer[nCount] = 0;
			strTemp.Format(_T("[%04d-%02d-%02d %02d:%02d:%02d.%03d]	UpdateRecordset %s;\r\n"), 
				stSysTime.wYear, stSysTime.wMonth, stSysTime.wDay, stSysTime.wHour, stSysTime.wMinute, stSysTime.wSecond, stSysTime.wMilliseconds, lpwBuffer);
		}
		else
		{
			llTimestamp = lpExecutePlan->m_nTimestamp;
			llTimestamp = llTimestamp >> 2;
			FileTimeToLocalFileTime((FILETIME *)&llTimestamp, &stLocalFileTime);
			FileTimeToSystemTime(&stLocalFileTime, &stSysTime);

			nCount = MultiByteToWideChar(CP_UTF8, 0, lpBuffer+lpExecutePlan->m_nSqlOffset, lpExecutePlan->m_nSqlLen, lpwBuffer, nBufferSize);
			lpwBuffer[nCount] = 0;
			strTemp.Format(_T("[%04d-%02d-%02d %02d:%02d:%02d.%03d]	%s;\r\n"), 
				stSysTime.wYear, stSysTime.wMonth, stSysTime.wDay, stSysTime.wHour, stSysTime.wMinute, stSysTime.wSecond, stSysTime.wMilliseconds, lpwBuffer);
		}
		strRedo += strTemp;
	}

RedoAnalyse_End:
	m_reRedoAnalyse.SetWindowText(strRedo);
	if (fp != NULL)
	{
		fclose(fp);
		fp = NULL;
	}
	if (lpBuffer != NULL)
	{
		delete[] lpBuffer;
		lpBuffer = NULL;
	}
	if (lpwBuffer != NULL)
	{
		delete[] lpwBuffer;
		lpwBuffer = NULL;
	}
	return nRet;
}

void CMainTabRedoAnalyse::OnCancel()
{
	//CDialog::OnCancel();
}

void CMainTabRedoAnalyse::OnOK()
{
	//CDialog::OnOK();
}

void CMainTabRedoAnalyse::OnSize(UINT nType, int cx, int cy)
{
	CRect rtCtrl, rtClient;
	CDialog::OnSize(nType, cx, cy);

	//�ƶ������ڴ�С
	GetClientRect(rtClient);
	m_reRedoAnalyse.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.right = rtClient.right;
	rtCtrl.bottom = rtClient.bottom;
	m_reRedoAnalyse.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
}


void CMainTabRedoAnalyse::OnBnClickedBtnPre()
{
	int nRet;
	TCHAR lpszBuf[256];
	__try
	{
		if(m_nPageNo == 1)
		{
			CMessageBox(_T("������ʼҳ��"));
			return;
		}
		else
		{
			m_nPageNo--;
		}

		nRet = RedoAnalyse(m_pRedoFilePath);
		if(nRet != MF_OK)
		{
			memset(lpszBuf, 0, sizeof(lpszBuf));
			_stprintf_s(lpszBuf, 256, _T("����ִ�мƻ�ʧ�ܣ������룺%d"), nRet);
			CMessageBox(lpszBuf);
		}

		memset(lpszBuf, 0, sizeof(lpszBuf));
		_stprintf_s(lpszBuf, 256, _T("%d"), m_nPageNo);
		m_editPage.SetWindowText(lpszBuf);
	}
	__except(ExceptionHandlerBox(GetExceptionCode(), GetExceptionInformation()))
	{

	}
}

void CMainTabRedoAnalyse::OnBnClickedBtxNext()
{
	int nRet;
	TCHAR lpszBuf[256];
	__try
	{
		m_nPageNo++;
		nRet = RedoAnalyse(m_pRedoFilePath);
		if(nRet == -1)
		{
			m_nPageNo--;
			CMessageBox(_T("�ѵ�����ĩҳ��"));
		}
		else if(nRet != MF_OK)
		{
			memset(lpszBuf, 0, sizeof(lpszBuf));
			_stprintf_s(lpszBuf, 256, _T("����ִ�мƻ�ʧ�ܣ������룺%d"), nRet);
			CMessageBox(lpszBuf);
		}

		memset(lpszBuf, 0, sizeof(lpszBuf));
		_stprintf_s(lpszBuf, 256, _T("%d"), m_nPageNo);
		m_editPage.SetWindowText(lpszBuf);
	}
	__except(ExceptionHandlerBox(GetExceptionCode(), GetExceptionInformation()))
	{

	}
}

BOOL CMainTabRedoAnalyse::OnInitDialog()
{
	CDialog::OnInitDialog();

	CHARFORMAT cf;
	CString strPage;
	m_reRedoAnalyse.LimitText(-1);
	m_reRedoAnalyse.GetSelectionCharFormat(cf);
	wcscpy(cf.szFaceName ,_T("����"));//��������
	m_reRedoAnalyse.SetSelectionCharFormat(cf);

	m_nPageNo = 1;
	strPage.Format(_T("%d"), m_nPageNo);
	m_editPage.SetWindowText(strPage.GetBuffer());
	memset(m_pRedoFilePath, 0, MAX_PATH);
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}
