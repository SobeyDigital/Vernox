/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "afxwin.h"
#include "afxcmn.h"

#include "MainTabQueryResult.h"
#include "MainTabQueryInfo.h"


// CMainTabQuery �Ի���

class CMainTabQuery : public CDialog
{
	DECLARE_DYNAMIC(CMainTabQuery)

public:
	CMainTabQuery(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMainTabQuery();

// �Ի�������
	enum { IDD = IDD_MAINTAB_QUERY };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	CRichEditCtrl m_reSql;
	CTabCtrl m_tabQuery;

public:
	CMainTabQueryResult m_dlgMainTabQueryResult;
	CMainTabQueryInfo m_dlgMainTabQueryInfo;

	ISobeyDBRecordsetPtr m_rs;
	ISobeyDBRecordset *m_pRs;

	CString m_strPreQuerySql;		//ǰһ��ִ�еĲ�ѯSQL��䣬�����������䲻��¼

public:
	//��edit�ؼ��ж�ȡSQL��䲢ִ��
	void ExecuteSql();
	//ִ��ָ����SQL���
	void ExecuteSql(CString strSql);
	//����ִ����һ�εĲ�ѯ������ˢ�½������������ʾ
	void RedoLastQuery();

	void ShowResultInfo(int nSqlType, LONG lAffectCount, DWORD dwDisplay, MF_EXECUTE_STATISTICS stStatisticsInfo);

	void TabQueryChange(int nIndex);

	void MakeUpper();

	void MakeLower();

public:
	afx_msg void OnTcnSelchangeTabQuery(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnSize(UINT nType, int cx, int cy);
protected:
	virtual void OnCancel();
	virtual void OnOK();
public:
	CStatic m_ctrlSeparator;
	BOOL	m_bSpliting;
	CPoint	m_ptOld;
	int		m_iOffsetY;
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
};
