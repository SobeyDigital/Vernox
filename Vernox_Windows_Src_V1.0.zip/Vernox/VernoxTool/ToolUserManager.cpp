/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// ToolUserManager.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "ToolUserManager.h"


// CToolUserManager �Ի���

IMPLEMENT_DYNAMIC(CToolUserManager, CDialog)

CToolUserManager::CToolUserManager(CWnd* pParent /*=NULL*/)
	: CDialog(CToolUserManager::IDD, pParent)
{
	m_strUserID = _T("");
	m_bIsDBA = FALSE;
	memset(m_bAuth, 0, sizeof(m_bAuth));
	m_bSelIsLog = FALSE;
	m_bEnable = FALSE;
	m_strSelectUserID = _T("");
	m_nType = 0;
}

CToolUserManager::~CToolUserManager()
{
}

void CToolUserManager::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_USER_LIST, m_cbUserList);
}

BOOL CToolUserManager::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_cbUserList.ResetContent();
	
	char* lpSql;
	wchar_t *lpwValue;
	CString strText, strSql;
	int nRet, i;
	ISobeyDBRecordsetPtr rs;
	MF_EXECUTE_STATISTICS stStatisticsInfo;
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));

	strText.Format(_T("��ǰ�û�: %s"), m_strUserID);
	this->SetWindowText(strText);

	strSql.Format(_T("select * from v$user"));
	lpSql = SMT_UnicodeToUTF8(strSql);
	if (lpSql == NULL)
	{
		return FALSE;
	}
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
	nRet = g_pSobeyInterface->GetRecordset(lpSql, &rs, &stStatisticsInfo);
	delete[] lpSql;
	if (nRet != MF_OK)
	{
		return FALSE;
	}

	i = 0;
	rs->MoveFirst();
	while (!rs->eof())
	{
		rs->FieldValue(2, lpwValue);
		strText = lpwValue;
		m_cbUserList.AddString(strText);

		if (m_strUserID == strText)
		{
			rs->FieldValue(4, lpwValue);
			if (_tcsicmp(lpwValue, _T("0")) == 0)
			{
				m_bIsDBA = FALSE;
			} 
			else
			{
				m_bIsDBA = TRUE;
			}
			m_cbUserList.SetCurSel(i);
			SelectUser(m_strUserID);
		}
		i++;
		rs->MoveNext();
	}

	GetDlgItem(IDC_STATIC_TIPS)->ShowWindow(SW_HIDE);

	return TRUE;
}

BEGIN_MESSAGE_MAP(CToolUserManager, CDialog)
	ON_CBN_SELCHANGE(IDC_COMBO_USER_LIST, &CToolUserManager::OnCbnSelchangeComboUserList)
	ON_BN_CLICKED(IDCANCEL, &CToolUserManager::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_BTN_ALTER, &CToolUserManager::OnBnClickedBtnAlter)
	ON_BN_CLICKED(IDC_BTN_ENABLE, &CToolUserManager::OnBnClickedBtnEnable)
	ON_BN_CLICKED(IDC_BTN_DELETE, &CToolUserManager::OnBnClickedBtnDelete)
	ON_BN_CLICKED(IDC_BTN_NEW, &CToolUserManager::OnBnClickedBtnNew)
	ON_BN_CLICKED(IDC_BTN_SAVE, &CToolUserManager::OnBnClickedBtnSave)
	ON_BN_CLICKED(IDC_BTN_CANCEL, &CToolUserManager::OnBnClickedBtnCancel)
	ON_BN_CLICKED(IDC_BTN_ALTER_AUTH, &CToolUserManager::OnBnClickedBtnAlterAuth)
END_MESSAGE_MAP()


// CToolUserManager ��Ϣ��������


void CToolUserManager::SetInitData(CString str)
{
	m_strUserID = str;
}

BOOL CToolUserManager::SelectUser(CString strName)
{
	int nRet;
	char* lpSql;
	wchar_t *lpwValue;
	CString strSql;
	ISobeyDBRecordsetPtr rs;
	MF_EXECUTE_STATISTICS stStatisticsInfo;
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));

	strSql.Format(_T("select * from v$user where username = '%s'"), strName);
	lpSql = SMT_UnicodeToUTF8(strSql);
	if (lpSql == NULL)
	{
		return FALSE;
	}
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
	nRet = g_pSobeyInterface->GetRecordset(lpSql, &rs, &stStatisticsInfo);
	delete[] lpSql;
	if (nRet != MF_OK)
	{
		return FALSE;
	}
	if (rs->GetRowNum() != 1)
	{
		return FALSE;
	}

	rs->MoveFirst();
	rs->FieldValue(1, lpwValue);
	if (_tcsicmp(lpwValue, _T("enable")) == 0)		//�û�״̬
	{
		SetDlgItemText(IDC_STATIC_USER_STATE, _T("�û�״̬������"));
		SetDlgItemText(IDC_BTN_ENABLE, _T("���ø��û�"));
		m_bEnable = TRUE;
	}
	else
	{
		SetDlgItemText(IDC_STATIC_USER_STATE, _T("�û�״̬������"));
		SetDlgItemText(IDC_BTN_ENABLE, _T("���ø��û�"));
		m_bEnable = FALSE;
	}
	rs->FieldValue(4, lpwValue);
	if (_tcsicmp(lpwValue, _T("0")) == 0)
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_DBA))->SetCheck(FALSE);
		m_bAuth[0] = FALSE;
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_DBA))->SetCheck(TRUE);
		m_bAuth[0] = TRUE;
	}
	rs->FieldValue(5, lpwValue);
	if (_tcsicmp(lpwValue, _T("0")) == 0)
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_ALTER_SYSTEM))->SetCheck(FALSE);
		m_bAuth[1] = FALSE;
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_ALTER_SYSTEM))->SetCheck(TRUE);
		m_bAuth[1] = TRUE;
	}
	rs->FieldValue(6, lpwValue);
	if (_tcsicmp(lpwValue, _T("0")) == 0)
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_CREATE_OBJECT))->SetCheck(FALSE);
		m_bAuth[2] = FALSE;
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_CREATE_OBJECT))->SetCheck(TRUE);
		m_bAuth[2] = TRUE;
	}
	rs->FieldValue(7, lpwValue);
	if (_tcsicmp(lpwValue, _T("0")) == 0)
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_ALTER_OBJECT))->SetCheck(FALSE);
		m_bAuth[3] = FALSE;
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_ALTER_OBJECT))->SetCheck(TRUE);
		m_bAuth[3] = TRUE;
	}
	rs->FieldValue(8, lpwValue);
	if (_tcsicmp(lpwValue, _T("0")) == 0)
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_DROP_OBJECT))->SetCheck(FALSE);
		m_bAuth[4] = FALSE;
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_DROP_OBJECT))->SetCheck(TRUE);
		m_bAuth[4] = TRUE;
	}
	rs->FieldValue(9, lpwValue);
	if (_tcsicmp(lpwValue, _T("0")) == 0)
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_CREATE_SEQUENCE))->SetCheck(FALSE);
		m_bAuth[5] = FALSE;
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_CREATE_SEQUENCE))->SetCheck(TRUE);
		m_bAuth[5] = TRUE;
	}
	rs->FieldValue(10, lpwValue);
	if (_tcsicmp(lpwValue, _T("0")) == 0)
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_DROP_SEQUENCE))->SetCheck(FALSE);
		m_bAuth[6] = FALSE;
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTH_DROP_SEQUENCE))->SetCheck(TRUE);
		m_bAuth[6] = TRUE;
	}

	if (strName == m_strUserID)
	{
		m_bSelIsLog = TRUE;
	} 
	else
	{
		m_bSelIsLog = FALSE;
	}
	m_strSelectUserID = strName;

	SetButtonState(FALSE);
	SetControlState(FALSE);
	return TRUE;
}

void CToolUserManager::SetControlState(BOOL bInEdit)
{
	SetDlgItemText(IDC_EDIT_ID, _T(""));
	SetDlgItemText(IDC_EDIT_PW, _T(""));
	SetDlgItemText(IDC_EDIT_PW_CONFIRM, _T(""));

	GetDlgItem(IDC_COMBO_USER_LIST)->EnableWindow(!bInEdit);

	if (m_nType == 0 || m_nType == 1)		//�½��û������޸�����
	{
		GetDlgItem(IDC_EDIT_ID)->EnableWindow(bInEdit);
		GetDlgItem(IDC_EDIT_PW)->EnableWindow(bInEdit);
		GetDlgItem(IDC_EDIT_PW_CONFIRM)->EnableWindow(bInEdit);
		if (bInEdit)
		{
			GetDlgItem(IDC_STATIC_TIPS)->ShowWindow(SW_SHOW);
		} 
		else
		{
			GetDlgItem(IDC_STATIC_TIPS)->ShowWindow(SW_HIDE);
		}
	}
	else
	{
		GetDlgItem(IDC_EDIT_ID)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PW)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PW_CONFIRM)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_TIPS)->ShowWindow(SW_HIDE);
	}
	
	if (m_nType == 2)						//�޸�Ȩ��
	{
		GetDlgItem(IDC_CHECK_AUTH_DBA)->EnableWindow(bInEdit);
		GetDlgItem(IDC_CHECK_AUTH_ALTER_SYSTEM)->EnableWindow(bInEdit);
		GetDlgItem(IDC_CHECK_AUTH_CREATE_OBJECT)->EnableWindow(bInEdit);
		GetDlgItem(IDC_CHECK_AUTH_ALTER_OBJECT)->EnableWindow(bInEdit);
		GetDlgItem(IDC_CHECK_AUTH_DROP_OBJECT)->EnableWindow(bInEdit);
		GetDlgItem(IDC_CHECK_AUTH_CREATE_SEQUENCE)->EnableWindow(bInEdit);
		GetDlgItem(IDC_CHECK_AUTH_DROP_SEQUENCE)->EnableWindow(bInEdit);
	} 
	else
	{
		GetDlgItem(IDC_CHECK_AUTH_DBA)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_AUTH_ALTER_SYSTEM)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_AUTH_CREATE_OBJECT)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_AUTH_ALTER_OBJECT)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_AUTH_DROP_OBJECT)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_AUTH_CREATE_SEQUENCE)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_AUTH_DROP_SEQUENCE)->EnableWindow(FALSE);
	}
}

void CToolUserManager::SetButtonState(BOOL bInEdit)
{
	if (m_bIsDBA)				//��ͨ�û�ֻ���޸�����
	{
		GetDlgItem(IDC_BTN_ALTER)->EnableWindow(!bInEdit);
		if (m_bSelIsLog)			//���ܽ����Լ��������޸��Լ���Ȩ�ޣ�����ɾ���Լ�
		{
			GetDlgItem(IDC_BTN_ALTER_AUTH)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_ENABLE)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_DELETE)->EnableWindow(FALSE);
		} 
		else
		{
			GetDlgItem(IDC_BTN_ALTER_AUTH)->EnableWindow(!bInEdit);
			GetDlgItem(IDC_BTN_ENABLE)->EnableWindow(!bInEdit);
			GetDlgItem(IDC_BTN_DELETE)->EnableWindow(!bInEdit);
		}
		GetDlgItem(IDC_BTN_NEW)->EnableWindow(!bInEdit);
	} 
	else
	{
		if (m_bSelIsLog)		//��ͨ�û�ֻ���޸��Լ�������
		{
			GetDlgItem(IDC_BTN_ALTER)->EnableWindow(!bInEdit);
		} 
		else
		{
			GetDlgItem(IDC_BTN_ALTER)->EnableWindow(FALSE);
		}
		GetDlgItem(IDC_BTN_ALTER_AUTH)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_ENABLE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_DELETE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_NEW)->EnableWindow(FALSE);
	}
	
	GetDlgItem(IDC_BTN_SAVE)->EnableWindow(bInEdit);
	GetDlgItem(IDC_BTN_CANCEL)->EnableWindow(bInEdit);
}

BOOL CToolUserManager::ExecuteSql(CString strSql)
{
	char* lpSql;
	CString strText;
	int nRet, nAffectCount;
	CMemDBRecordset rs;
	MF_EXECUTE_STATISTICS stStatisticsInfo;
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));

	lpSql = SMT_UnicodeToUTF8(strSql);
	if (lpSql == NULL)
	{
		strText.Format(_T("����ת��ʧ�ܣ������룺%d\r\n"), GetLastError());
		CMessageBox(strText);
		return FALSE;
	}
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
	nRet = g_pSobeyInterface->Execute(lpSql, nAffectCount, &stStatisticsInfo);
	delete[] lpSql;
	if (nRet != MF_OK)
	{
		strText.Format(_T("ִ��ʧ�ܣ�����ֵ��%d��%s���������룺%d��%s��\r\n"), nRet, GetErrorWDescription(nRet), stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet));
		CMessageBox(strText);
		return FALSE;
	}
	return TRUE;
}


//////////////////////////////////////////////////////////////////////////

void CToolUserManager::OnCbnSelchangeComboUserList()
{
	CString strName;
	m_cbUserList.GetWindowText(strName);
	SelectUser(strName);
}

void CToolUserManager::OnBnClickedCancel()
{
	OnCancel();
}

void CToolUserManager::OnBnClickedBtnAlter()
{
	m_nType = 0;
	SetButtonState(TRUE);
	SetControlState(TRUE);

	SetDlgItemText(IDC_EDIT_ID, m_strSelectUserID);
	GetDlgItem(IDC_EDIT_ID)->EnableWindow(FALSE);
}

void CToolUserManager::OnBnClickedBtnEnable()
{
	CString strSql;
	if (m_bEnable)
	{
		strSql.Format(_T("alter user %s disable"), m_strSelectUserID);
	} 
	else
	{
		strSql.Format(_T("alter user %s enable"), m_strSelectUserID);
	}
	ExecuteSql(strSql);
	SelectUser(m_strSelectUserID);
}

void CToolUserManager::OnBnClickedBtnDelete()
{
	CString strSql, strText;
	
	strSql.Format(_T("ɾ���û� %s��"), m_strSelectUserID);
	strText.Format(_T("ɾ���û� %s �ɹ���"), m_strSelectUserID);
	if (IDYES == CMessageBox(strSql, MB_YESNO|MB_SYSTEMMODAL))
	{
		strSql.Format(_T("drop user %s"), m_strSelectUserID);
		if (ExecuteSql(strSql))
		{
			m_cbUserList.DeleteString(m_cbUserList.GetCurSel());
			m_cbUserList.SetCurSel(0);
			m_cbUserList.GetWindowText(m_strSelectUserID);
			CMessageBox(strText);
		} 
	}
	SelectUser(m_strSelectUserID);
}

void CToolUserManager::OnBnClickedBtnNew()
{
	m_nType = 1;
	SetButtonState(TRUE);
	SetControlState(TRUE);

	((CButton*)GetDlgItem(IDC_CHECK_AUTH_DBA))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK_AUTH_ALTER_SYSTEM))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK_AUTH_CREATE_OBJECT))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK_AUTH_ALTER_OBJECT))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK_AUTH_DROP_OBJECT))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK_AUTH_CREATE_SEQUENCE))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK_AUTH_DROP_SEQUENCE))->SetCheck(FALSE);
}

void CToolUserManager::OnBnClickedBtnSave()
{
	if (m_nType == 0)		//�޸�����
	{
		CString strSql, strName, strPw, strPw2, strText;
		GetDlgItemText(IDC_EDIT_ID, strName);
		GetDlgItemText(IDC_EDIT_PW, strPw);
		GetDlgItemText(IDC_EDIT_PW_CONFIRM, strPw2);
		if (strPw == _T("") || strPw2 == _T(""))
		{
			CMessageBox(_T("���벻��Ϊ�գ�"));
			return;
		}
		if (strPw != strPw2)
		{
			CMessageBox(_T("������������벻һ�£�"));
			return;
		}
		if (strPw.GetLength() > 23)
		{
			CMessageBox(_T("���벻�ܳ���23λ��"));
			return;
		}
		strSql.Format(_T("alter user %s identified by %s"), strName, strPw);
		if (!ExecuteSql(strSql))
		{
			return;
		}
		strText.Format(_T("�޸��û� %s ����ɹ���"), strName);

		SelectUser(strName);
		CMessageBox(strText);
	} 
	else if (m_nType == 1)			//�����û�
	{
		CString strSql, strName, strPw, strPw2, strText;
		GetDlgItemText(IDC_EDIT_ID, strName);
		GetDlgItemText(IDC_EDIT_PW, strPw);
		GetDlgItemText(IDC_EDIT_PW_CONFIRM, strPw2);
		if (strName == _T(""))
		{
			CMessageBox(_T("�û�������Ϊ�գ�"));
			return;
		}
		if (strPw == _T("") || strPw2 == _T(""))
		{
			CMessageBox(_T("���벻��Ϊ�գ�"));
			return;
		}
		if (strPw != strPw2)
		{
			CMessageBox(_T("������������벻һ�£�"));
			return;
		}
		strSql.Format(_T("create user %s identified by %s"), strName, strPw);
		if (!ExecuteSql(strSql))
		{
			return;
		}

		m_cbUserList.AddString(strName);
		m_cbUserList.SetCurSel(m_cbUserList.GetCount() - 1);
		SelectUser(strName);
		strText.Format(_T("�����û� %s �ɹ���"), strName);
		CMessageBox(strText);
	}
	else if (m_nType == 2)			//�޸�Ȩ��
	{
		BOOL bCheck[7];
		CString strSql, strAddAuth, strDelAuth, strText;


		bCheck[0] = ((CButton *)GetDlgItem(IDC_CHECK_AUTH_DBA))->GetCheck();
		bCheck[1] = ((CButton *)GetDlgItem(IDC_CHECK_AUTH_ALTER_SYSTEM))->GetCheck();
		bCheck[2] = ((CButton *)GetDlgItem(IDC_CHECK_AUTH_CREATE_OBJECT))->GetCheck();
		bCheck[3] = ((CButton *)GetDlgItem(IDC_CHECK_AUTH_ALTER_OBJECT))->GetCheck();
		bCheck[4] = ((CButton *)GetDlgItem(IDC_CHECK_AUTH_DROP_OBJECT))->GetCheck();
		bCheck[5] = ((CButton *)GetDlgItem(IDC_CHECK_AUTH_CREATE_SEQUENCE))->GetCheck();
		bCheck[6] = ((CButton *)GetDlgItem(IDC_CHECK_AUTH_DROP_SEQUENCE))->GetCheck();

		strAddAuth = _T("");
		strDelAuth = _T("");
		if (m_bAuth[0] && !bCheck[0])
		{
			strDelAuth += _T("dba,");
		}
		else if (!m_bAuth[0] && bCheck[0])
		{
			strAddAuth += _T("dba,");
		}
		if (m_bAuth[1] && !bCheck[1])
		{
			strDelAuth += _T("altersystem,");
		}
		else if (!m_bAuth[1] && bCheck[1])
		{
			strAddAuth += _T("altersystem,");
		}
		if (m_bAuth[2] && !bCheck[2])
		{
			strDelAuth += _T("createobject,");
		}
		else if (!m_bAuth[2] && bCheck[2])
		{
			strAddAuth += _T("createobject,");
		}
		if (m_bAuth[3] && !bCheck[3])
		{
			strDelAuth += _T("alterobject,");
		}
		else if (!m_bAuth[3] && bCheck[3])
		{
			strAddAuth += _T("alterobject,");
		}
		if (m_bAuth[4] && !bCheck[4])
		{
			strDelAuth += _T("dropobject,");
		}
		else if (!m_bAuth[4] && bCheck[4])
		{
			strAddAuth += _T("dropobject,");
		}
		if (m_bAuth[5] && !bCheck[5])
		{
			strDelAuth += _T("createsequence,");
		}
		else if (!m_bAuth[5] && bCheck[5])
		{
			strAddAuth += _T("createsequence,");
		}
		if (m_bAuth[6] && !bCheck[6])
		{
			strDelAuth += _T("dropsequence,");
		}
		else if (!m_bAuth[6] && bCheck[6])
		{
			strAddAuth += _T("dropsequence,");
		}

		if (strAddAuth != _T(""))
		{
			strAddAuth.Delete(strAddAuth.GetLength() - 1, 1);		//ȥ��ĩβ��һ������
			strSql.Format(_T("grant %s to %s"), strAddAuth, m_strSelectUserID);
			if (!ExecuteSql(strSql))
			{
				return;
			}
			strText.Format(_T("�޸��û� %s Ȩ�޳ɹ���"), m_strSelectUserID);
		}
		if (strDelAuth != _T(""))
		{
			strDelAuth.Delete(strDelAuth.GetLength() - 1, 1);		//ȥ��ĩβ��һ������
			strSql.Format(_T("revoke %s from %s"), strDelAuth, m_strSelectUserID);
			if (!ExecuteSql(strSql))
			{
				return;
			}
			strText.Format(_T("�޸��û� %s Ȩ�޳ɹ���"), m_strSelectUserID);
		}
		SelectUser(m_strSelectUserID);
		if (strText != _T(""))
		{
			CMessageBox(strText);
		}
	}
}

void CToolUserManager::OnBnClickedBtnCancel()
{
	SelectUser(m_strSelectUserID);
}

void CToolUserManager::OnBnClickedBtnAlterAuth()
{
	m_nType = 2;
	SetButtonState(TRUE);
	SetControlState(TRUE);

	SetDlgItemText(IDC_EDIT_ID, m_strSelectUserID);
}
