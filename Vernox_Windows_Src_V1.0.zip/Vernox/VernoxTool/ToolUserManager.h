/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "afxwin.h"

extern ISobeyDBConnectionPtr g_pSobeyInterface;
// CToolUserManager �Ի���

class CToolUserManager : public CDialog
{
	DECLARE_DYNAMIC(CToolUserManager)

public:
	CToolUserManager(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CToolUserManager();

// �Ի�������
	enum { IDD = IDD_TOOL_USER_MANAGER };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	//��ǰ��¼�û�״̬
	CString m_strUserID;
	BOOL m_bIsDBA;

	//��ǰѡ���û�״̬
	BOOL m_bAuth[7];
	BOOL m_bSelIsLog;		//��ǰѡ���û��Ƿ�Ϊ��¼�û�
	BOOL m_bEnable;
	CString m_strSelectUserID;

	int m_nType;			//��������	0���޸����룬Ȩ�ޣ�1�������û���2���޸�Ȩ��

	CComboBox m_cbUserList;

public:
	int CMessageBox(LPCTSTR lpText, UINT nType = (MB_OK|MB_SYSTEMMODAL))
	{
		return MessageBox(lpText, 0, nType);
	}

	void SetInitData(CString str);

	BOOL SelectUser(CString strName);

	void SetControlState(BOOL bState);

	void SetButtonState(BOOL bState);

	BOOL ExecuteSql(CString strSql);

	
	afx_msg void OnCbnSelchangeComboUserList();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedBtnAlter();
	afx_msg void OnBnClickedBtnEnable();
	afx_msg void OnBnClickedBtnDelete();
	afx_msg void OnBnClickedBtnNew();
	afx_msg void OnBnClickedBtnSave();
	afx_msg void OnBnClickedBtnCancel();
	afx_msg void OnBnClickedBtnAlterAuth();
};
