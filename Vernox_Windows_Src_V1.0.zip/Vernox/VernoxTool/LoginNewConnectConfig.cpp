/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// LoginNewConnectConfig.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "LoginNewConnectConfig.h"


// CLoginNewConnectConfig �Ի���

IMPLEMENT_DYNAMIC(CLoginNewConnectConfig, CDialog)

CLoginNewConnectConfig::CLoginNewConnectConfig(CWnd* pParent /*=NULL*/)
	: CDialog(CLoginNewConnectConfig::IDD, pParent)
{
	memset(m_cWorkingPath, 0, sizeof(m_cWorkingPath));
	memset(m_cConfigPath, 0, sizeof(m_cConfigPath));
	memset(m_cBakConfigPath, 0, sizeof(m_cBakConfigPath));

	GetModuleFileNameA(NULL, m_cWorkingPath, MAX_PATH);
	(strrchr(m_cWorkingPath, '\\'))[0] = 0;
	(strrchr(m_cWorkingPath, '\\'))[1] = 0;
	sprintf(m_cConfigPath, "%sConfig\\Vernox.ini", m_cWorkingPath);
	sprintf(m_cBakConfigPath, "%sConfig\\VernoxBak.ini", m_cWorkingPath);

	m_pListConfig = NULL;
}

CLoginNewConnectConfig::~CLoginNewConnectConfig()
{
}

void CLoginNewConnectConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_DATABASE_NAME, m_editDatabaseName);
	DDX_Control(pDX, IDC_EDIT_HOST, m_editHost);
	DDX_Control(pDX, IDC_EDIT_PORT, m_editPort);
	DDX_Control(pDX, IDC_COMBO_WRITELOG, m_cbWriteLog);
	DDX_Control(pDX, IDC_COMBO_PROTOCOL, m_cbProtocol);
	DDX_Control(pDX, IDC_LIST_ADDRESS, m_listAddress);
	DDX_Control(pDX, IDC_COMBO_CONNECT_CONFIG, m_cbConfig);
	DDX_Control(pDX, IDC_EDIT_CONNECT_CONFIG, m_editConfig);
}

BOOL CLoginNewConnectConfig::OnInitDialog()
{
	CDialog::OnInitDialog();

	if (m_pListConfig == NULL)
	{
		m_cbConfig.AddString(_T("��������"));
		m_cbConfig.SetCurSel(0);
		GetDlgItem(IDOK)->SetWindowText(_T("����������"));
	} 
	else
	{
		m_cbConfig.AddString(_T("��������"));

		TCHAR wcStr[MAX_PATH];
		list<STRUCT_CONNECT_CONFIG>::iterator iter;
		for (iter = m_pListConfig->begin(); iter != m_pListConfig->end(); iter++)
		{
			memset(wcStr, 0, sizeof(wcStr));
			MultiByteToWideChar(CP_ACP, 0, iter->m_cSobeyDB, strlen(iter->m_cSobeyDB)+1, wcStr, MAX_PATH);
			m_cbConfig.AddString(wcStr);
		}
		m_cbConfig.SetCurSel(0);
		GetDlgItem(IDOK)->SetWindowText(_T("����������"));
	}
	m_editConfig.SetWindowText(_T(""));
	m_editDatabaseName.SetWindowText(_T("Vernox"));
	m_editHost.SetWindowText(_T("127.0.0.1"));
	m_editPort.SetWindowText(_T("8000"));
	m_cbWriteLog.AddString(_T("FALSE"));
	m_cbWriteLog.AddString(_T("TRUE"));
	m_cbWriteLog.SetCurSel(0);
	m_cbProtocol.AddString(_T("TCP"));
	m_cbProtocol.AddString(_T("Soap"));
	m_cbProtocol.SetCurSel(0);

	m_listAddress.ResetContent();

	return TRUE;
}


BEGIN_MESSAGE_MAP(CLoginNewConnectConfig, CDialog)
	ON_BN_CLICKED(IDOK, &CLoginNewConnectConfig::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CLoginNewConnectConfig::OnBnClickedCancel)
	ON_BN_CLICKED(ID_BTN_ADDRESS_ADD, &CLoginNewConnectConfig::OnBnClickedBtnAddressAdd)
	ON_BN_CLICKED(ID_BTN_ADDRESS_DELETE, &CLoginNewConnectConfig::OnBnClickedBtnAddressDelete)
	ON_CBN_SELCHANGE(IDC_COMBO_CONNECT_CONFIG, &CLoginNewConnectConfig::OnCbnSelchangeComboConnectConfig)
END_MESSAGE_MAP()


// CLoginNewConnectConfig ��Ϣ��������

void CLoginNewConnectConfig::OnBnClickedOk()
{
	int nCurSel = m_cbConfig.GetCurSel();
	if (nCurSel == 0)
	{
		FILE *fp;
		int nCount, i, nPos;
		CString strText, strValue;
		CString strSobeyDB, strDatabaseName, strHost, strPort, strWriteLog, strProtocol, strAddress;
		char cWriteBuffer[8196];
		STRUCT_ADDRESS stAddr;
		STRUCT_CONNECT_CONFIG st;

		st.m_nStartPos = 0;
		st.m_nEndPos = 0;
		memset(&st.m_cSobeyDB, 0, sizeof(st.m_cSobeyDB));
		memset(&st.m_cDatabaseName, 0, sizeof(st.m_cDatabaseName));
		st.m_vecAddress.clear();
		memset(&stAddr, 0, sizeof(stAddr));
		st.m_vecAddress.push_back(stAddr);
		memset(&cWriteBuffer, 0, sizeof(cWriteBuffer));

		fp = fopen(m_cConfigPath, "rb+");
		if (fp == NULL)
		{
			strText.Format(_T("�����������ļ�ʧ�ܣ��ļ�·����%s�������룺%d��"), m_cConfigPath, GetLastError());
			CMessageBox(strText);
			goto OnBnClickedOk_Add_End;
		}

		nCount = m_listAddress.GetCount();
		if (nCount == 0)
		{
			strText.Format(_T("Address�б�Ϊ�գ�������Address������"));
			CMessageBox(strText);
			goto OnBnClickedOk_Add_End;
		}


		m_editConfig.GetWindowText(strSobeyDB);
		m_editDatabaseName.GetWindowText(strDatabaseName);
		if (strSobeyDB == _T(""))
		{
			strText.Format(_T("��������Ϊ�գ��������������ƣ�"));
			CMessageBox(strText);
			goto OnBnClickedOk_Add_End;
		}
		if (strDatabaseName == _T(""))
		{
			strText.Format(_T("���ݿ���Ϊ�գ����������ݿ�����"));
			CMessageBox(strText);
			goto OnBnClickedOk_Add_End;
		}
		for (i = 0; i < nCount; i++)
		{
			m_listAddress.GetText(i, strValue);

			nPos = strValue.Find(',');
			strHost = strValue.Left(nPos);

			strValue = strValue.Right(strValue.GetLength() - nPos - 1);
			nPos = strValue.Find(',');
			strPort = strValue.Left(nPos);

			strValue = strValue.Right(strValue.GetLength() - nPos - 1);
			nPos = strValue.Find(',');
			strWriteLog = strValue.Left(nPos);

			strProtocol = strValue.Right(strValue.GetLength() - nPos - 1);

			strText.Format(_T("      (ADDRESS = (PROTOCOL = %s)(HOST = %s)(PORT = %s)(WriteLog = %s))\r\n"), strProtocol, strHost, strPort, strWriteLog);
			strAddress += strText;
		}
		strText.Format(_T("\r\n%s =\r\n  (DESCRIPTION =\r\n    (ADDRESS_LIST =\r\n%s    )\r\n    (CONNECT_DATA =\r\n      (DATABASENAME = %s)\r\n    )\r\n  )\r\n"), strSobeyDB, strAddress, strDatabaseName);

		WideCharToMultiByte(CP_ACP, 0, strText, strText.GetLength()+1, cWriteBuffer, 8196, NULL, NULL);

		fseek(fp, 0, SEEK_END);
		fwrite(cWriteBuffer, 1, strlen(cWriteBuffer), fp);

		if (fp != NULL)
		{
			fclose(fp);
		}

		OnOK();
		return;
OnBnClickedOk_Add_End:
		if (fp != NULL)
		{
			fclose(fp);
		}

	}
	else
	{
		int i, nCount, nBufferSize, nTemp, nRet, nFileSize;
		char *lpBuffer;
		FILE *fp, *fpnew;
		CString strText, strValue;
		list<STRUCT_CONNECT_CONFIG>::iterator iter;

		nBufferSize = 0;
		lpBuffer = NULL;
		fp = NULL;
		fpnew = NULL;

		nCount = m_cbConfig.GetCount();

		i = 0;
		for (iter = m_pListConfig->begin(); iter != m_pListConfig->end(); iter++)
		{
			if (i+1 == nCurSel)
			{
				break;
			}
			i++;
		}
		if (i+1 != nCurSel)
		{
			GetDlgItem(IDOK)->EnableWindow(FALSE);
			strText.Format(_T("�����ˣ���ѡ�%d������Ŀ����%d������������������%d��"), nCurSel, nCount, m_pListConfig->size());
			CMessageBox(strText);
			goto OnBnClickedOk_Delete_End;
		}

		fp = fopen(m_cConfigPath, "rb+");
		if (fp == NULL)
		{
			strText.Format(_T("�����������ļ�ʧ�ܣ��ļ�·����%s�������룺%d��"), m_cConfigPath, GetLastError());
			CMessageBox(strText);
			goto OnBnClickedOk_Delete_End;
		}
		fpnew = fopen(m_cBakConfigPath, "wb+");
		if (fpnew == NULL)
		{
			strText.Format(_T("�������������ļ�ʧ�ܣ��ļ�·����%s�������룺%d��"), m_cBakConfigPath, GetLastError());
			CMessageBox(strText);
			goto OnBnClickedOk_Delete_End;
		}

		fseek(fp, 0, SEEK_END);
		nFileSize = ftell(fp);
		fseek(fp, 0, SEEK_SET);

		nBufferSize = iter->m_nStartPos;
		if (nBufferSize > nFileSize)
		{
			strText.Format(_T("��Ҫ��ȡ�Ĵ�С�������ļ����ȣ���ȡ��С��%d���ļ���С��%d��"), nBufferSize, nFileSize);
			CMessageBox(strText);
			goto OnBnClickedOk_Delete_End;
		}
		lpBuffer = new char[nBufferSize];
		if (lpBuffer == NULL)
		{
			strText.Format(_T("�����ڴ�ʧ�ܣ������С��%d�������룺%d��"), nBufferSize, GetLastError());
			CMessageBox(strText);
			goto OnBnClickedOk_Delete_End;
		}
		memset(lpBuffer, 0, nBufferSize);
		nRet = fread(lpBuffer, 1, nBufferSize, fp);
		if (nRet != nBufferSize)
		{
			strText.Format(_T("��ȡ�ļ�����ʧ�ܣ��������ȣ�%d�����۳��ȣ�%d���ļ�·����%s��"), nRet, nBufferSize, m_cConfigPath);
			CMessageBox(strText);
			goto OnBnClickedOk_Delete_End;
		}
		nRet = fwrite(lpBuffer, 1, nBufferSize, fpnew);
		if (nRet != nBufferSize)
		{
			strText.Format(_T("д���ļ�����ʧ�ܣ�д�볤�ȣ�%d�����۳��ȣ�%d���ļ�·����%s��"), nRet, nBufferSize, m_cBakConfigPath);
			CMessageBox(strText);
			goto OnBnClickedOk_Delete_End;
		}

		nTemp = nFileSize - iter->m_nEndPos;
		if (nTemp == 0)
		{
			//ɾ�������һ��
			;
		}
		else
		{
			if (nTemp < 0)
			{
				strText.Format(_T("��Ҫ��ȡ�Ĵ�С�쳣����ȡ��С��%d���ļ���С��%d��"), nTemp, nFileSize);
				CMessageBox(strText);
				goto OnBnClickedOk_Delete_End;
			}

			if (nTemp > nBufferSize)
			{
				delete[] lpBuffer;
				nBufferSize = nTemp;
				lpBuffer = new char[nBufferSize];
				if (lpBuffer == NULL)
				{
					strText.Format(_T("�����ڴ�ʧ�ܣ������С��%d�������룺%d��"), nTemp, GetLastError());
					CMessageBox(strText);
					goto OnBnClickedOk_Delete_End;
				}
			}

			fseek(fp, iter->m_nEndPos, SEEK_SET);
			memset(lpBuffer, 0, nBufferSize);
			nRet = fread(lpBuffer, 1, nTemp, fp);
			if (nRet != nTemp)
			{
				strText.Format(_T("��ȡ�ļ�����ʧ�ܣ��������ȣ�%d�����۳��ȣ�%d���ļ�·����%s��"), nRet, nTemp, m_cConfigPath);
				CMessageBox(strText);
				goto OnBnClickedOk_Delete_End;
			}
			nRet = fwrite(lpBuffer, 1, nTemp, fpnew);
			if (nRet != nTemp)
			{
				strText.Format(_T("д���ļ�����ʧ�ܣ�д�볤�ȣ�%d�����۳��ȣ�%d���ļ�·����%s��"), nRet, nTemp, m_cBakConfigPath);
				CMessageBox(strText);
				goto OnBnClickedOk_Delete_End;
			}
		}

		//ɾ�����ļ�
		//���ļ�������
		if (lpBuffer != NULL)
		{
			delete[] lpBuffer;
			lpBuffer = NULL;
		}
		if (fp != NULL)
		{
			fclose(fp);
			fp = NULL;
		}
		if (fpnew != NULL)
		{
			fclose(fpnew);
			fpnew = NULL;
		}

		nRet = remove(m_cConfigPath);
		if (nRet != 0)
		{
			strText.Format(_T("ɾ������ʧ�ܣ������룺%d���ļ�·����%s��"), GetLastError(), m_cConfigPath);
			CMessageBox(strText);
			goto OnBnClickedOk_Delete_End;
		}

		nRet = rename(m_cBakConfigPath, m_cConfigPath);
		if (nRet != 0)
		{
			strText.Format(_T("�޸��ļ���ʧ�ܣ������룺%d��ԭ�ļ�·����%s�����ļ�·����%s��"), GetLastError(), m_cBakConfigPath, m_cConfigPath);
			CMessageBox(strText);
			goto OnBnClickedOk_Delete_End;
		}

		if (lpBuffer != NULL)
		{
			delete[] lpBuffer;
			lpBuffer = NULL;
		}
		if (fp != NULL)
		{
			fclose(fp);
			fp = NULL;
		}
		if (fpnew != NULL)
		{
			fclose(fpnew);
			fpnew = NULL;
		}

		m_editConfig.GetWindowText(strValue);
		strText.Format(_T("��ɾ���������ã�%s��"), strValue);
		CMessageBox(strText);

		OnOK();
		return;
OnBnClickedOk_Delete_End:
		if (lpBuffer != NULL)
		{
			delete[] lpBuffer;
			lpBuffer = NULL;
		}
		if (fp != NULL)
		{
			fclose(fp);
			fp = NULL;
		}
		if (fpnew != NULL)
		{
			fclose(fpnew);
			fpnew = NULL;
		}
	}
}

void CLoginNewConnectConfig::OnBnClickedCancel()
{
	OnCancel();
}

void CLoginNewConnectConfig::OnBnClickedBtnAddressAdd()
{
	CString strText, strHost, strPort, strWriteLog, strProtocol;
	m_editHost.GetWindowText(strHost);
	m_editPort.GetWindowText(strPort);
	m_cbWriteLog.GetWindowText(strWriteLog);
	m_cbProtocol.GetWindowText(strProtocol);
	if (strHost.IsEmpty() || strPort.IsEmpty() || strWriteLog.IsEmpty() || strProtocol.IsEmpty())
	{
		strText.Format(_T("���ֲ���Ϊ�գ���������д��"));
		CMessageBox(strText);
		return;
	}

	strText.Format(_T("%s,%s,%s,%s"), strHost, strPort, strWriteLog, strProtocol);
	m_listAddress.AddString(strText);
}

void CLoginNewConnectConfig::OnBnClickedBtnAddressDelete()
{
	CString strText;
	int nCurSel = m_listAddress.GetCurSel();
	if (nCurSel < 0)
	{
		return;
	}
	m_listAddress.DeleteString(nCurSel);
}

void CLoginNewConnectConfig::OnCbnSelchangeComboConnectConfig()
{
	char cIpAddress[MAX_PATH];
	TCHAR wcStr[MAX_PATH];
	int nCurSel, nCount, i;
	CString strTemp, strValue;
	list<STRUCT_CONNECT_CONFIG>::iterator iter;

	nCurSel = m_cbConfig.GetCurSel();
	nCount = m_cbConfig.GetCount();
	if (nCurSel == 0)
	{
		GetDlgItem(IDOK)->EnableWindow(TRUE);
		GetDlgItem(IDOK)->SetWindowText(_T("����������"));
		GetDlgItem(IDC_EDIT_CONNECT_CONFIG)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_HOST)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_PORT)->EnableWindow(TRUE);
		GetDlgItem(ID_BTN_ADDRESS_ADD)->EnableWindow(TRUE);
		GetDlgItem(ID_BTN_ADDRESS_DELETE)->EnableWindow(TRUE);
		GetDlgItem(IDC_LIST_ADDRESS)->EnableWindow(TRUE);
		m_listAddress.ResetContent();
		m_editConfig.SetWindowText(_T(""));
		m_editDatabaseName.SetWindowText(_T("Vernox"));
	}
	else
	{
		GetDlgItem(IDOK)->EnableWindow(TRUE);
		GetDlgItem(IDOK)->SetWindowText(_T("ɾ��������"));
		GetDlgItem(IDC_EDIT_CONNECT_CONFIG)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_HOST)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PORT)->EnableWindow(FALSE);
		GetDlgItem(ID_BTN_ADDRESS_ADD)->EnableWindow(FALSE);
		GetDlgItem(ID_BTN_ADDRESS_DELETE)->EnableWindow(FALSE);
		GetDlgItem(IDC_LIST_ADDRESS)->EnableWindow(FALSE);
		m_listAddress.ResetContent();

		i = 0;
		for (iter = m_pListConfig->begin(); iter != m_pListConfig->end(); iter++)
		{
			if (i+1 == nCurSel)
			{
				break;
			}
			i++;
		}
		if (i+1 != nCurSel)
		{
			GetDlgItem(IDOK)->EnableWindow(FALSE);
			strTemp.Format(_T("�����ˣ���ѡ�%d������Ŀ����%d������������������%d��"), nCurSel, nCount, m_pListConfig->size());
			CMessageBox(strTemp);
			return;
		}

		

		memset(wcStr, 0, sizeof(wcStr));
		MultiByteToWideChar(CP_ACP, 0, iter->m_cSobeyDB, strlen(iter->m_cSobeyDB)+1, wcStr, MAX_PATH);
		m_cbConfig.GetWindowText(strValue);
		if (strValue.Compare(wcStr) != 0)
		{
			GetDlgItem(IDOK)->EnableWindow(FALSE);
			strTemp.Format(_T("�����ˣ���ѡ���ã�%s����������������%s��"), strValue, wcStr);
			CMessageBox(strTemp);
			return;
		}
		m_editConfig.SetWindowText(strValue);

		memset(wcStr, 0, sizeof(wcStr));
		MultiByteToWideChar(CP_ACP, 0, iter->m_cDatabaseName, strlen(iter->m_cDatabaseName)+1, wcStr, MAX_PATH);
		m_editDatabaseName.SetWindowText(wcStr);

		for (i = 0; i < iter->m_vecAddress.size(); i++)
		{
			memset(cIpAddress, 0, sizeof(cIpAddress));
			sprintf(cIpAddress, "%s,%s,%s,%s", iter->m_vecAddress[i].m_cHost, iter->m_vecAddress[i].m_cPort, iter->m_vecAddress[i].m_cWriteLog, iter->m_vecAddress[i].m_cProtocol);
			MultiByteToWideChar(CP_ACP, 0, cIpAddress, strlen(cIpAddress)+1, wcStr, MAX_PATH);
			m_listAddress.AddString(wcStr);
		}
	}
}
