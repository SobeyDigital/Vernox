/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "afxwin.h"

extern ISobeyDBConnectionPtr g_pSobeyInterface;
// CMainMenuSheetObjectSelect �Ի���

class CMainMenuSheetObjectSelect : public CDialog
{
	DECLARE_DYNAMIC(CMainMenuSheetObjectSelect)

public:
	CMainMenuSheetObjectSelect(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMainMenuSheetObjectSelect();

// �Ի�������
	enum { IDD = IDD_MAINMENU_SHEET_OBJECT_SELECT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

protected:
	int CMessageBox(LPCTSTR lpText, UINT nType = (MB_OK|MB_SYSTEMMODAL))
	{
		return MessageBox(lpText, 0, nType);
	}

public:
	CListBox m_listboxLeft;
	CListBox m_listboxRight;

	list<CString> m_listObject;
	CString m_strObjectName;
	CString m_strExportFile;
	
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedBtnMoveRight();
	afx_msg void OnBnClickedBtnMoveLeft();
	afx_msg void OnLbnDblclkSheetListboxUnselected();
	afx_msg void OnLbnDblclkSheetListboxSelected();
};
