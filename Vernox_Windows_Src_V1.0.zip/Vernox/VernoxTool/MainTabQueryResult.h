/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "afxcmn.h"
#include "afxwin.h"

extern ISobeyDBConnectionPtr g_pSobeyInterface;
// CMainTabQueryResult �Ի���

class CMainTabQueryResult : public CDialog
{
	DECLARE_DYNAMIC(CMainTabQueryResult)

public:
	CMainTabQueryResult(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMainTabQueryResult();

// �Ի�������
	enum { IDD = IDD_MAINTAB_QUERY_RESULT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_listResult;				//SetItemData�д���ָ��,��տؼ�ʱ��Ҫɾ��ָ����ָ�ڴ�
	CEdit m_editTemp;

	int m_nRow;
	int m_nCol;
	BOOL m_bModifyAllowed;
	CString m_strPreValue;
	ISobeyDBRecordset* m_pRs;

public:
	int CMessageBox(LPCTSTR lpText, UINT nType = (MB_OK|MB_SYSTEMMODAL))
	{
		return MessageBox(lpText, 0, nType);
	}

	void ClearResult();
	int DisplayResult(ISobeyDBRecordset* pRs);

	void ChangeButtonEnable(BOOL bEnable);

public:
	afx_msg void OnNMClickListResult(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnEnKillfocusEditQueryTemp();
	afx_msg void OnBnClickedBtnQuerySave();
	afx_msg void OnBnClickedBtnQueryAddItem();
	afx_msg void OnBnClickedBtnQueryDeleteItem();
	afx_msg void OnSize(UINT nType, int cx, int cy);
protected:
	virtual void OnCancel();
	virtual void OnOK();
};
