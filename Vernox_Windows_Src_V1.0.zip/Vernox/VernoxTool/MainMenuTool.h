/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "ToolUserManager.h"

// CMainMenuTool �Ի���

class CMainMenuTool : public CDialog
{
	DECLARE_DYNAMIC(CMainMenuTool)

public:
	CMainMenuTool(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMainMenuTool();

// �Ի�������
	enum { IDD = IDD_MAINMENU_TOOL };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

public:
	CToolUserManager m_dlgToolUserManager;

protected:
	virtual void OnCancel();
	virtual void OnOK();
public:
	afx_msg void OnBnClickedBtnUserManager();
};
