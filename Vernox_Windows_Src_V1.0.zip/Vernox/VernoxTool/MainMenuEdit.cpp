/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MainMenuEdit.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "SobeyMemToolDlg.h"
//#include "MainMenuEdit.h"


// CMainMenuEdit �Ի���

IMPLEMENT_DYNAMIC(CMainMenuEdit, CDialog)

CMainMenuEdit::CMainMenuEdit(CWnd* pParent /*=NULL*/)
	: CDialog(CMainMenuEdit::IDD, pParent)
{

}

CMainMenuEdit::~CMainMenuEdit()
{
}

void CMainMenuEdit::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMainMenuEdit, CDialog)
	ON_BN_CLICKED(IDC_BTN_ANALYSE_REDO, &CMainMenuEdit::OnBnClickedBtnAnalyseRedo)
END_MESSAGE_MAP()


// CMainMenuEdit ��Ϣ��������

void CMainMenuEdit::OnBnClickedBtnAnalyseRedo()
{
	int nLen;
	TCHAR lptDefaultDir[MAX_PATH];
	CString strText, strImportFile, strDefaultDir, strFilter;

	GetModuleFileName(NULL, lptDefaultDir, MAX_PATH);
	(_tcsrchr(lptDefaultDir, '\\'))[0] = 0;
	(_tcsrchr(lptDefaultDir, '\\'))[1] = 0;
	strDefaultDir.Format(_T("%sData"), lptDefaultDir);
	strFilter = _T("�ļ� (*.log)|*.log|�����ļ� (*.*)|*.*||");

	while(TRUE)
	{
		CFileDialog dlgFile(TRUE, NULL, NULL, OFN_HIDEREADONLY|OFN_READONLY, strFilter);
		dlgFile.GetOFN().lpstrInitialDir = strDefaultDir;  
		if(IDOK == dlgFile.DoModal())
		{
			strImportFile = dlgFile.GetPathName();
			strText.Format(_T("������־�ļ���%s��"), strImportFile);
			if(IDYES == CMessageBox(strText, MB_YESNO|MB_SYSTEMMODAL))
			{
				CSobeyMemToolDlg *pParent;
				pParent = (CSobeyMemToolDlg*)GetParent()->GetParent();
				pParent->CreateNewMainTabPage(MF_TABPAGE_TYPE_REDO_ANALYSE, (void*)(LPCWSTR)strImportFile);
				break;
			}
			else
			{
				nLen = strImportFile.ReverseFind(_T('\\'));
				strDefaultDir = strImportFile.Left(nLen);
				strDefaultDir.Format(_T("%s"),strImportFile.GetBuffer());
			}
		}
		else
		{
			break;
		}
	}
}

void CMainMenuEdit::OnOK()
{
	//CDialog::OnOK();
}

void CMainMenuEdit::OnCancel()
{
	//CDialog::OnCancel();
}