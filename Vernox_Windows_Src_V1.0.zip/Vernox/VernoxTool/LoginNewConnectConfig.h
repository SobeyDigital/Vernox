/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "afxwin.h"


// CLoginNewConnectConfig �Ի���

class CLoginNewConnectConfig : public CDialog
{
	DECLARE_DYNAMIC(CLoginNewConnectConfig)

public:
	CLoginNewConnectConfig(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CLoginNewConnectConfig();

// �Ի�������
	enum { IDD = IDD_LOGIN_CONNECT_CONFIG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	CComboBox m_cbConfig;
	CEdit m_editConfig;
	CEdit m_editDatabaseName;
	CEdit m_editHost;
	CEdit m_editPort;
	CComboBox m_cbWriteLog;
	CComboBox m_cbProtocol;
	CListBox m_listAddress;

	char m_cWorkingPath[MAX_PATH];
	char m_cConfigPath[MAX_PATH];
	char m_cBakConfigPath[MAX_PATH];

	list<STRUCT_CONNECT_CONFIG> *m_pListConfig;

protected:
	int CMessageBox(LPCTSTR lpText, UINT nType = (MB_OK|MB_SYSTEMMODAL))
	{
		return MessageBox(lpText, 0, nType);
	}

public:
	void SetConfigData(list<STRUCT_CONNECT_CONFIG> *pListConfig)
	{
		m_pListConfig = pListConfig;
	}

public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedBtnAddressAdd();
	afx_msg void OnBnClickedBtnAddressDelete();
	afx_msg void OnCbnSelchangeComboConnectConfig();
};
