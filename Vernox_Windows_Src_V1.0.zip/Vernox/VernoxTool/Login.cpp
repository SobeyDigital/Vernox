/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// Login.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "SobeyMemToolDlg.h"


// CLogin �Ի���

IMPLEMENT_DYNAMIC(CLogin, CDialog)

CLogin::CLogin(CWnd* pParent /*=NULL*/)
	: CDialog(CLogin::IDD, pParent)
{
	TCHAR lpszText[256];
	m_strUserID = _T("");
	m_strUserPW = _T("");
	memset(m_cUserID, 0, sizeof(m_cUserID));
	memset(m_cUserPW, 0, sizeof(m_cUserPW));

	m_strConnectName = _T("");
	memset(m_cConnectName, 0, sizeof(m_cConnectName));

	memset(lpszText, 0, sizeof(lpszText));
	GetProfileString(_T("Login"), _T("UserID"), _T("root"), lpszText, 255);
	m_strUserID = lpszText;

	memset(m_cWorkingPath, 0, sizeof(m_cWorkingPath));
	memset(m_cConfigPath, 0, sizeof(m_cConfigPath));

	GetModuleFileNameA(NULL, m_cWorkingPath, MAX_PATH);
	(strrchr(m_cWorkingPath, '\\'))[0] = 0;
	(strrchr(m_cWorkingPath, '\\'))[1] = 0;
	sprintf(m_cConfigPath, "%sConfig\\Vernox.ini", m_cWorkingPath);
}

CLogin::~CLogin()
{
}

void CLogin::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_USER_ID, m_strUserID);
	DDX_Text(pDX, IDC_EDIT_USER_PW, m_strUserPW);
	DDX_Control(pDX, IDC_COMBO_DATABASE, m_cbDatabase);
}

BOOL CLogin::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_listConfig.clear();
	ParseConnectConfig();
	if (m_listConfig.size() == 0)		//д��һ��Ĭ������
	{
		STRUCT_ADDRESS stAddr;
		STRUCT_CONNECT_CONFIG st;
		st.m_nStartPos = 0;
		st.m_nEndPos = 0;
		sprintf(st.m_cSobeyDB, "SOBEYDB");
		sprintf(stAddr.m_cProtocol, "TCP");
		sprintf(stAddr.m_cHost, "127.0.0.1");
		sprintf(stAddr.m_cPort, "8000");
		sprintf(stAddr.m_cWriteLog, "FALSE");
		sprintf(st.m_cDatabaseName, "Vernox");
		st.m_vecAddress.push_back(stAddr);
		m_listConfig.push_back(st);
	}

	//��ʼ���ؼ�
	TCHAR wcStr[MAX_PATH];
	list<STRUCT_CONNECT_CONFIG>::iterator iter;

	m_cbDatabase.ResetContent();
	for (iter = m_listConfig.begin(); iter != m_listConfig.end(); iter++)
	{
		memset(wcStr, 0, sizeof(wcStr));
		MultiByteToWideChar(CP_ACP, 0, (*iter).m_cSobeyDB, strlen((*iter).m_cSobeyDB)+1, wcStr, MAX_PATH);
		m_cbDatabase.AddString(wcStr);
	}
	m_cbDatabase.AddString(_T("�����µ����ݿ�����..."));
	memset(wcStr, 0, sizeof(wcStr));
	GetProfileString(_T("Login"), _T("ServerName"), _T(""), wcStr, 255);
	m_cbDatabase.SelectString(-1, wcStr);
	if(m_cbDatabase.GetCurSel() == -1)
	{
		m_cbDatabase.SetCurSel(0);
	}

	return TRUE;
}


BEGIN_MESSAGE_MAP(CLogin, CDialog)
	ON_BN_CLICKED(IDOK, &CLogin::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CLogin::OnBnClickedCancel)
	ON_CBN_SELCHANGE(IDC_COMBO_DATABASE, &CLogin::OnCbnSelchangeComboDatabase)
END_MESSAGE_MAP()


// CLogin ��Ϣ��������

BOOL CLogin::ParseConnectConfig()
{
	FILE *fp = NULL;
	BOOL bRet = FALSE;
	
	fp = fopen(m_cConfigPath, "rb+");
	if (fp == NULL)
	{
		return FALSE;
	}
	bRet = ParseConnectConfig(fp);
	if (fp != NULL)
	{
		fclose(fp);
	}
	return bRet;
}

BOOL CLogin::ParseConnectConfig(FILE *fp)
{
	BOOL bValue;
	int i, j, nIndex, nLeft, nRight, nEqualSign, nLineLength, nStrLength, nPos;
	char *lpBuffer;
	STRUCT_ADDRESS stAddr;
	STRUCT_CONNECT_CONFIG st;
	char arrayLine[1024];

	lpBuffer = NULL;
	
	m_listConfig.clear();

	j = 0;
	nIndex = 0;
	nLeft = 0;
	nRight = 0;
	nEqualSign = 0;
	bValue = FALSE;
	st.m_nStartPos = 0;
	st.m_nEndPos = 0;
	memset(&st.m_cSobeyDB, 0, sizeof(st.m_cSobeyDB));
	memset(&st.m_cDatabaseName, 0, sizeof(st.m_cDatabaseName));
	st.m_vecAddress.clear();
	memset(&stAddr, 0, sizeof(stAddr));
	st.m_vecAddress.push_back(stAddr);
	while(!feof(fp))
	{
		memset(arrayLine, 0, sizeof(arrayLine));
		if(fgets(arrayLine, 1000, fp))		//��ȡһ��
		{
			nLineLength = strlen(arrayLine);
			i = 0;
			while (i < nLineLength)
			{
				if (arrayLine[i] == ' ' || arrayLine[i] == '\t')
				{
					i++;
					continue;
				}
				if (arrayLine[i] == '#' || arrayLine[i] == '\n' || arrayLine[i] == '\r')		//ע��
				{
					break;
				}
				if (arrayLine[i] == '(')
				{
					nLeft++;
					i++;
					continue;
				}
				if (arrayLine[i] == ')')
				{
					nRight++;
					i++;
					if (nRight == 9)
					{
						if (nLeft == 9 && nEqualSign == 10 && nIndex == 10)		//��ʼ������һ�����ò���
						{
							nPos = ftell(fp);
							st.m_nEndPos = nPos;
							m_listConfig.push_back(st);
							j = 0;
							nIndex = 0;
							nLeft = 0;
							nRight = 0;
							nEqualSign = 0;
							bValue = FALSE;
							st.m_nStartPos = nPos;
							st.m_nEndPos = nPos;
							memset(&st.m_cSobeyDB, 0, sizeof(st.m_cSobeyDB));
							memset(&st.m_cDatabaseName, 0, sizeof(st.m_cDatabaseName));
							st.m_vecAddress.clear();
							memset(&stAddr, 0, sizeof(stAddr));
							st.m_vecAddress.push_back(stAddr);
						}
						else
						{
							return FALSE;
						}
					}
					continue;
				}
				if (arrayLine[i] == '=')
				{
					nEqualSign++;
					i++;
					continue;
				}

				if (!IsCharacter(arrayLine[i]))
				{
					return FALSE;
				}

				if (0 == nIndex)			//��ʶ��
				{
					if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex)
					{
						nStrLength = 0;
						lpBuffer = arrayLine+i;
						while (i < nLineLength)
						{
							if (IsCharacter(arrayLine[i]))
							{
								i++;
								nStrLength++;
								continue;
							}
							memcpy(st.m_cSobeyDB, lpBuffer, nStrLength);
							nIndex++;
							break;
						}
						if (nIndex != 1)
						{
							return FALSE;
						}
					} 
					else
					{
						return FALSE;
					}
				}
				else if (1 == nIndex)			//DESCRIPTION
				{
					if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex)
					{
						nStrLength = 11;
						lpBuffer = arrayLine+i;
						if (i + nStrLength < nLineLength)
						{
							if (_strnicmp(lpBuffer, "DESCRIPTION", nStrLength) == 0)
							{
								nIndex++;
								i = i+nStrLength;
							} 
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					}
					else
					{
						return FALSE;
					}
				}
				else if (2 == nIndex)			//ADDRESS_LIST
				{
					if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex)
					{
						nStrLength = 12;
						lpBuffer = arrayLine+i;
						if (i + nStrLength < nLineLength)
						{
							if (_strnicmp(lpBuffer, "ADDRESS_LIST", nStrLength) == 0)
							{
								nIndex++;
								i = i+nStrLength;
							} 
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					}
					else
					{
						return FALSE;
					}
				}
				else if (3 == nIndex)			//ADDRESS
				{
					if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex)
					{
						nStrLength = 7;
						lpBuffer = arrayLine+i;
						if (i + nStrLength < nLineLength)
						{
							if (_strnicmp(lpBuffer, "ADDRESS", nStrLength) == 0)
							{
								nIndex++;
								i = i+nStrLength;
							} 
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					}
					else
					{
						return FALSE;
					}
				}
				else if (4 == nIndex)			//PROTOCOL
				{
					if (bValue == FALSE)
					{
						if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex)
						{
							nStrLength = 8;
							lpBuffer = arrayLine+i;
							if (i + nStrLength < nLineLength)
							{
								if (_strnicmp(lpBuffer, "PROTOCOL", nStrLength) == 0)
								{
									i = i+nStrLength;
									bValue = TRUE;
								} 
								else
								{
									return FALSE;
								}
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					} 
					else
					{
						if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex+1)
						{
							nStrLength = 0;
							lpBuffer = arrayLine+i;
							while (i < nLineLength)
							{
								if (IsCharacter(arrayLine[i]))
								{
									i++;
									nStrLength++;
									continue;
								}
								memcpy(st.m_vecAddress[j].m_cProtocol, lpBuffer, nStrLength);
								nIndex++;
								bValue = FALSE;
								break;
							}
							if (nIndex != 5)
							{
								return FALSE;
							}
						} 
						else
						{
							return FALSE;
						}
					}
				}
				else if (5 == nIndex)			//HOST
				{
					if (bValue == FALSE)
					{
						if (nLeft == nIndex && nRight == 1 && nEqualSign == nIndex)
						{
							nStrLength = 4;
							lpBuffer = arrayLine+i;
							if (i + nStrLength < nLineLength)
							{
								if (_strnicmp(lpBuffer, "HOST", nStrLength) == 0)
								{
									i = i+nStrLength;
									bValue = TRUE;
								} 
								else
								{
									return FALSE;
								}
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					} 
					else
					{
						if (nLeft == nIndex && nRight == 1 && nEqualSign == nIndex+1)
						{
							nStrLength = 0;
							lpBuffer = arrayLine+i;
							while (i < nLineLength)
							{
								if (IsCharacter(arrayLine[i]))
								{
									i++;
									nStrLength++;
									continue;
								}
								memcpy(st.m_vecAddress[j].m_cHost, lpBuffer, nStrLength);
								nIndex++;
								bValue = FALSE;
								break;
							}
							if (nIndex != 6)
							{
								return FALSE;
							}
						} 
						else
						{
							return FALSE;
						}
					}
				}
				else if (6 == nIndex)			//PORT
				{
					if (bValue == FALSE)
					{
						if (nLeft == nIndex && nRight == 2 && nEqualSign == nIndex)
						{
							nStrLength = 4;
							lpBuffer = arrayLine+i;
							if (i + nStrLength < nLineLength)
							{
								if (_strnicmp(lpBuffer, "PORT", nStrLength) == 0)
								{
									i = i+nStrLength;
									bValue = TRUE;
								} 
								else
								{
									return FALSE;
								}
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					} 
					else
					{
						if (nLeft == nIndex && nRight == 2 && nEqualSign == nIndex+1)
						{
							nStrLength = 0;
							lpBuffer = arrayLine+i;
							while (i < nLineLength)
							{
								if (IsCharacter(arrayLine[i]))
								{
									i++;
									nStrLength++;
									continue;
								}
								memcpy(st.m_vecAddress[j].m_cPort, lpBuffer, nStrLength);
								nIndex++;
								bValue = FALSE;
								break;
							}
							if (nIndex != 7)
							{
								return FALSE;
							}
						} 
						else
						{
							return FALSE;
						}
					}
				}
				else if (7 == nIndex)			//WriteLog
				{
					if (bValue == FALSE)
					{
						if (nLeft == nIndex && nRight == 3 && nEqualSign == nIndex)
						{
							nStrLength = 8;
							lpBuffer = arrayLine+i;
							if (i + nStrLength < nLineLength)
							{
								if (_strnicmp(lpBuffer, "WriteLog", nStrLength) == 0)
								{
									i = i+nStrLength;
									bValue = TRUE;
								} 
								else
								{
									return FALSE;
								}
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					} 
					else
					{
						if (nLeft == nIndex && nRight == 3 && nEqualSign == nIndex+1)
						{
							nStrLength = 0;
							lpBuffer = arrayLine+i;
							while (i < nLineLength)
							{
								if (IsCharacter(arrayLine[i]))
								{
									i++;
									nStrLength++;
									continue;
								}
								memcpy(st.m_vecAddress[j].m_cWriteLog, lpBuffer, nStrLength);
								nIndex++;
								bValue = FALSE;
								break;
							}
							if (nIndex != 8)
							{
								return FALSE;
							}
						} 
						else
						{
							return FALSE;
						}
					}
				}
				else if (8 == nIndex)			//CONNECT_DATA
				{
					if (nLeft == nIndex && nRight == 6 && nEqualSign == nIndex)				//CONNECT_DATA
					{
						nStrLength = 12;
						lpBuffer = arrayLine+i;
						if (i + nStrLength < nLineLength)
						{
							if (_strnicmp(lpBuffer, "CONNECT_DATA", nStrLength) == 0)
							{
								nIndex++;
								i = i+nStrLength;
							} 
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					}
					else if (nLeft == nIndex && nRight == 5 && nEqualSign == nIndex)		//ADDRESS
					{
						nStrLength = 7;
						lpBuffer = arrayLine+i;
						if (i + nStrLength < nLineLength)
						{
							if (_strnicmp(lpBuffer, "ADDRESS", nStrLength) == 0)
							{
								nIndex = 3;
								nLeft = 3;
								nRight = 0;
								nEqualSign = 3;
								j++;
								memset(&stAddr, 0, sizeof(stAddr));
								st.m_vecAddress.push_back(stAddr);
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					}
					else
					{
						return FALSE;
					}
				}
				else if (9 == nIndex)			//DATABASENAME
				{
					if (bValue == FALSE)
					{
						if (nLeft == nIndex && nRight == 6 && nEqualSign == nIndex)
						{
							nStrLength = 12;
							lpBuffer = arrayLine+i;
							if (i + nStrLength < nLineLength)
							{
								if (_strnicmp(lpBuffer, "DATABASENAME", nStrLength) == 0)
								{
									i = i+nStrLength;
									bValue = TRUE;
								} 
								else
								{
									return FALSE;
								}
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					} 
					else
					{
						if (nLeft == nIndex && nRight == 6 && nEqualSign == nIndex+1)
						{
							nStrLength = 0;
							lpBuffer = arrayLine+i;
							while (i < nLineLength)
							{
								if (IsCharacter(arrayLine[i]))
								{
									i++;
									nStrLength++;
									continue;
								}
								memcpy(st.m_cDatabaseName, lpBuffer, nStrLength);
								nIndex++;
								bValue = FALSE;
								break;
							}
							if (nIndex != 10)
							{
								return FALSE;
							}
						} 
						else
						{
							return FALSE;
						}
					}
				}
			}
			Sleep(1);
		}
		else
		{
			break;
		}
	}

	return TRUE;
}

BOOL CLogin::IsCharacter(char c)
{
	if ((c >= 48 && c <= 57) || (c>= 65 && c <= 90) || (c >= 97 && c <= 122) || c == '_' || c == '.' ||  c == '-')		//���֣���д��ĸ��Сд��ĸ���»��ߣ�С���㣬���
	{
		return TRUE;
	} 
	else
	{
		return FALSE;
	}
}

//////////////////////////////////////////////////////////////////////////
//��½
void CLogin::OnBnClickedOk()
{
	UpdateData(TRUE);

	ULONG ulIP;
	int nwLength, nCurSel, nCount, i;
	TCHAR wcStr[MAX_PATH];
	CString strText;
	list<STRUCT_CONNECT_CONFIG>::iterator iter;

	//�������Ӳ���
	nCurSel = m_cbDatabase.GetCurSel();

	i = 0;
	for (iter = m_listConfig.begin(); iter != m_listConfig.end(); iter++)
	{
		if (i == nCurSel)
		{
			break;
		}
		i++;
	}
	if (i != nCurSel)
	{
		return;
	}

	m_vecIP.clear();
	m_vecPort.clear();
	m_strConnectName = iter->m_cSobeyDB;
	memcpy(m_cConnectName, iter->m_cSobeyDB, MAX_PATH);
	nCount = iter->m_vecAddress.size();
	for (i = 0; i < nCount; i++)
	{
		if (stricmp(iter->m_vecAddress[i].m_cProtocol, "TCP") != 0)
		{
			//memset(wcStr, 0, sizeof(wcStr));
			//MultiByteToWideChar(CP_ACP, 0, (*iter).m_cProtocol, strlen((*iter).m_cProtocol)+1, wcStr, MAX_PATH);
			//strText.Format(_T("ֻ֧��TCPЭ�飬��ѡЭ�����ͣ�%s"), wcStr);
			//CMessageBox(strText);
			//return;

			continue;
		}
		ulIP = StringToIpAddress(iter->m_vecAddress[i].m_cHost);
		if (ulIP == INADDR_NONE)
		{
			continue;
		}
		m_vecIP.push_back(ulIP);
		m_vecPort.push_back(atoi(iter->m_vecAddress[i].m_cPort));
	}
	
	//��¼
	nwLength = min(m_strUserID.GetLength(), MF_TOOL_ID_MAX_LENGTH_WCHAR);
	memset(m_cUserID, 0, sizeof(m_cUserID));
	if (0 == nwLength)
	{
		m_cUserID[0] = 0;
	} 
	else
	{
		if (0 == WideCharToMultiByte(CP_UTF8, 0, m_strUserID, nwLength+1, m_cUserID, MF_TOOL_ID_MAX_LENGTH_CHAR, NULL, NULL))
		{
			strText.Format(_T("����ת��ʧ�ܣ������룺%d"), GetLastError());
			CMessageBox(strText);
		}
	}
	
	nwLength = min(m_strUserPW.GetLength(), MF_TOOL_PW_MAX_LENGTH_WCHAR);
	memset(m_cUserPW, 0, sizeof(m_cUserPW));
	if (0 == nwLength)
	{
		m_cUserPW[0] = 0;
	} 
	else
	{
		if (0 == WideCharToMultiByte(CP_UTF8, 0, m_strUserPW, nwLength+1, m_cUserPW, MF_TOOL_PW_MAX_LENGTH_CHAR, NULL, NULL))
		{
			strText.Format(_T("����ת��ʧ�ܣ������룺%d"), GetLastError());
			CMessageBox(strText);
		}
	}
	WriteProfileString(_T("Login"), _T("UserID"), m_strUserID);
	WriteProfileString(_T("Login"), _T("ServerName"), m_strConnectName);

	OnOK();
}

//�˳�
void CLogin::OnBnClickedCancel()
{
	//m_strUserID = _T("");
	//m_strUserPW = _T("");
	//memset(m_cUserID, 0, sizeof(m_cUserID));
	//memset(m_cUserPW, 0, sizeof(m_cUserPW));

	OnCancel();
}

void CLogin::OnCbnSelchangeComboDatabase()
{
	int nCurSel, nCount;
	nCurSel = m_cbDatabase.GetCurSel();
	nCount = m_cbDatabase.GetCount();
	if (nCurSel+1 == nCount)
	{
		m_dlgLoginNewConnectConfig.SetConfigData(&m_listConfig);
		if (IDOK == m_dlgLoginNewConnectConfig.DoModal())
		{
			m_listConfig.clear();
			ParseConnectConfig();
			if (m_listConfig.size() == 0)		//д��һ��Ĭ������
			{
				STRUCT_ADDRESS stAddr;
				STRUCT_CONNECT_CONFIG st;
				st.m_nStartPos = 0;
				st.m_nEndPos = 0;
				sprintf(st.m_cSobeyDB, "SOBEYDB");
				sprintf(stAddr.m_cProtocol, "TCP");
				sprintf(stAddr.m_cHost, "127.0.0.1");
				sprintf(stAddr.m_cPort, "8000");
				sprintf(stAddr.m_cWriteLog, "FALSE");
				sprintf(st.m_cDatabaseName, "Vernox");
				st.m_vecAddress.push_back(stAddr);
				m_listConfig.push_back(st);
			}

			//��ʼ���ؼ�
			TCHAR wcStr[MAX_PATH];
			list<STRUCT_CONNECT_CONFIG>::iterator iter;

			m_cbDatabase.ResetContent();
			for (iter = m_listConfig.begin(); iter != m_listConfig.end(); iter++)
			{
				memset(wcStr, 0, sizeof(wcStr));
				MultiByteToWideChar(CP_ACP, 0, (*iter).m_cSobeyDB, strlen((*iter).m_cSobeyDB)+1, wcStr, MAX_PATH);
				m_cbDatabase.AddString(wcStr);
			}
			m_cbDatabase.AddString(_T("�����µ����ݿ�����..."));
			//m_cbDatabase.SetCurSel(nCurSel);
			m_cbDatabase.SetCurSel(0);
		} 
		else
		{
			m_cbDatabase.SetCurSel(0);
		}
	}
}
