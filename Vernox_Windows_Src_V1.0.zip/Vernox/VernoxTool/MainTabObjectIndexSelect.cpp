/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MainTabObjectIndexSelect.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
//#include "MainTabObjectIndex.h"
#include "MainTabObjectIndexSelect.h"


// CMainTabObjectIndexSelect �Ի���

IMPLEMENT_DYNAMIC(CMainTabObjectIndexSelect, CDialog)

CMainTabObjectIndexSelect::CMainTabObjectIndexSelect(CWnd* pParent /*=NULL*/)
	: CDialog(CMainTabObjectIndexSelect::IDD, pParent)
{
	m_pData = NULL;
	m_nCount = 0;
	m_pListIndex = NULL;
	m_nIndexRowNum = -1;
	m_nIndexColNum = -1;
	m_bComma = TRUE;
}

CMainTabObjectIndexSelect::~CMainTabObjectIndexSelect()
{
}

void CMainTabObjectIndexSelect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LISTBOX_UNSELECTED, m_listboxLeft);
	DDX_Control(pDX, IDC_LISTBOX_SELECTED, m_listboxRight);
}

BOOL CMainTabObjectIndexSelect::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_listboxLeft.ResetContent();
	m_listboxRight.ResetContent();

	if (m_pData == NULL || m_nCount == 0)
	{
		return TRUE;
	}
	for (int i = 0; i < m_nCount; i++)
	{
		m_listboxLeft.AddString(m_pData[i]);
	}
	m_pData = NULL;
	m_nCount = 0;

	return TRUE;
}

BEGIN_MESSAGE_MAP(CMainTabObjectIndexSelect, CDialog)
	ON_BN_CLICKED(IDOK, &CMainTabObjectIndexSelect::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CMainTabObjectIndexSelect::OnBnClickedCancel)
	ON_BN_CLICKED(ID_BTN_MOVE_RIGHT, &CMainTabObjectIndexSelect::OnBnClickedBtnMoveRight)
	ON_BN_CLICKED(ID_BTN_MOVE_LEFT, &CMainTabObjectIndexSelect::OnBnClickedBtnMoveLeft)
	ON_LBN_DBLCLK(IDC_LISTBOX_UNSELECTED, &CMainTabObjectIndexSelect::OnLbnDblclkListboxUnselected)
	ON_LBN_DBLCLK(IDC_LISTBOX_SELECTED, &CMainTabObjectIndexSelect::OnLbnDblclkListboxSelected)
END_MESSAGE_MAP()


// CMainTabObjectIndexSelect ��Ϣ��������

void CMainTabObjectIndexSelect::SetInitData(CString* pstrText, int nCount, CListCtrl* pListIndex, int nIndexRowNum, int nIndexColNum, BOOL bComma)
{
	m_nCount = nCount;
	m_pData = pstrText;
	m_pListIndex = pListIndex;
	m_nIndexRowNum = nIndexRowNum;
	m_nIndexColNum = nIndexColNum;
	m_bComma = bComma;
}


//////////////////////////////////////////////////////////////////////////
void CMainTabObjectIndexSelect::OnBnClickedOk()
{
	CString strText, strValue;;
	int nRowCount;

	strText = _T("");
	nRowCount = m_listboxRight.GetCount();
	if (nRowCount > 0)
	{
		for (int i = 0; i < nRowCount; i++)
		{
			m_listboxRight.GetText(i, strValue);
			strText += strValue;

			if (m_bComma)
			{
				strText += _T(", ");
			} 
			else
			{
				strText += _T(" ");
			}
		}
		if (m_bComma)
		{
			strText = strText.Left(strText.GetLength() - 2);
		} 
		else
		{
			strText = strText.Left(strText.GetLength() - 1);
		}
	}
	else
	{
		strText = _T("");
	}
	

	m_pListIndex->SetItemText(m_nIndexRowNum, m_nIndexColNum, strText);
	OnOK();
}

void CMainTabObjectIndexSelect::OnBnClickedCancel()
{
	OnCancel();
}

void CMainTabObjectIndexSelect::OnBnClickedBtnMoveRight()
{
	CString strText;
	int nCurSel = m_listboxLeft.GetCurSel();
	if (nCurSel < 0)
	{
		return;
	}
	m_listboxLeft.GetText(nCurSel, strText);
	m_listboxLeft.DeleteString(nCurSel);
	m_listboxRight.AddString(strText);
}

void CMainTabObjectIndexSelect::OnBnClickedBtnMoveLeft()
{
	CString strText;
	int nCurSel = m_listboxRight.GetCurSel();
	if (nCurSel < 0)
	{
		return;
	}
	m_listboxRight.GetText(nCurSel, strText);
	m_listboxRight.DeleteString(nCurSel);
	m_listboxLeft.AddString(strText);
}

void CMainTabObjectIndexSelect::OnLbnDblclkListboxUnselected()
{
	OnBnClickedBtnMoveRight();
}

void CMainTabObjectIndexSelect::OnLbnDblclkListboxSelected()
{
	OnBnClickedBtnMoveLeft();
}
