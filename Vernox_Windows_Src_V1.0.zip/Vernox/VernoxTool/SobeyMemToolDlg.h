/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include <afxcmn.h>

#include "Login.h"
#include "MainMenuFile.h"
#include "MainMenuEdit.h"
#include "MainMenuSheet.h"
#include "MainMenuTool.h"

#include "MainTabQuery.h"
#include "MainTabObject.h"
#include "MainTabRedoAnalyse.h"

#include <list>
#include "afxwin.h"
using namespace std;


#define MF_TOOL_BUFFER_SIZE					8192

#define MF_TABPAGE_TYPE_QUERY				1			//�½���ѯ�༭��
#define MF_TABPAGE_TYPE_CREATE_OBJECT		2			//������
#define MF_TABPAGE_TYPE_EDIT_OBJECT			3			//�༭��
#define MF_TABPAGE_TYPE_QUERY_OBJECT		4			//��ѯ������		select * from <object_name>
#define MF_TABPAGE_TYPE_REDO_ANALYSE		5			//����������־����ʾ����ִ�еĲ�����SQL��䣩

extern ISobeyDBConnectionPtr g_pSobeyInterface;
// CSobeyMemToolDlg �Ի���
class CSobeyMemToolDlg : public CDialog
{
// ����
public:
	CSobeyMemToolDlg(CWnd* pParent = NULL);	// ��׼���캯��
	~CSobeyMemToolDlg();

// �Ի�������
	enum { IDD = IDD_SOBEYMEMTOOL_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
	wchar_t m_wBufferDisplay[MF_TOOL_BUFFER_SIZE];		//��ʾ
	char m_cBufferDisplay[MF_TOOL_BUFFER_SIZE];			//��ʾ
	char m_cBufferTrans[MF_TOOL_BUFFER_SIZE];			//����ת��

	int m_nTabCount;
	list<STRUCT_TABPAGE> m_listMainTab;

	list<STRUCT_FILEINFO> m_listFileInfo;

public:
	CLogin m_dlgLogin;
	CMainMenuFile m_dlgMainMenuFile;
	CMainMenuEdit m_dlgMainMenuEdit;
	CMainMenuSheet m_dlgMainMenuSheet;
	CMainMenuTool m_dlgMainMenuTool;

public:
	CTabCtrl m_tabMenu;
	CTabCtrl m_tabMain;
	CTreeCtrl m_treeDB;

	CRect m_rcThis;
	CRect m_rcMenu;
	CRect m_rcMenuTab;

public:
	int CMessageBox(LPCTSTR lpText, UINT nType = (MB_OK|MB_SYSTEMMODAL))
	{
		return MessageBox(lpText, 0, nType);
	}

	void MainMenuDisplay(int nIndex);

	void MainControlVisible(BOOL bVisible);

	void ShowTreeDatabase(LPCTSTR lpDatabaseName);

	void ShowDatabaseStatus(LPCTSTR lpDatabaseName);

	void CreateNewMainTabPage(int nType, void *lpDescribe = NULL);

	void MainTabDisplay(int nIndex);

	void DeleteMainTabItem(STRUCT_TABPAGE st);

public:
	afx_msg void OnBnClickedBtnLogout();
	afx_msg void OnBnClickedBtnExit();
	afx_msg void OnTcnSelchangeTabMenu(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedBtnExecute();
	afx_msg void OnBnClickedBtnRefresh();
	afx_msg void OnNMRClickTabMain(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTcnSelchangeTabMain(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnSize(UINT nType, int cx, int cy);
protected:
	virtual void OnCancel();
	virtual void OnOK();
public:
	afx_msg void OnBnClickedBtnMakeUpper();
	afx_msg void OnBnClickedBtnMakeLower();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	CStatic m_ctrlSeparator;
	BOOL	m_bSpliting;
	CPoint	m_ptOld;
	int		m_iOffsetX;
};
