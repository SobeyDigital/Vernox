/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// CMainTabRedoAnalyse �Ի���

class CMainTabRedoAnalyse : public CDialog
{
	DECLARE_DYNAMIC(CMainTabRedoAnalyse)

public:
	CMainTabRedoAnalyse(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMainTabRedoAnalyse();

// �Ի�������
	enum { IDD = IDD_MAINTAB_REDO };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

protected:
	int CMessageBox(LPCTSTR lpText, UINT nType = (MB_OK|MB_SYSTEMMODAL))
	{
		return MessageBox(lpText, 0, nType);
	}

public:
	int		m_nPageNo;
	CEdit	m_editPage;
	char	m_pRedoFilePath[MAX_PATH];
public:
	int RedoAnalyse(char* lpszRedoFilePath);
protected:
	virtual void OnCancel();
	virtual void OnOK();

public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	afx_msg void OnBnClickedBtnPre();
	afx_msg void OnBnClickedBtxNext();

	CRichEditCtrl m_reRedoAnalyse;
	virtual BOOL OnInitDialog();
};
