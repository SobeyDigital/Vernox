/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "afxcmn.h"
#include "afxwin.h"

class CDlgProgress;
typedef BOOL (CALLBACK *CALLBACK_VERNOXPROGRESS)(CDlgProgress *pProgress, LPCTSTR lpszFileName, list<CString> &listObjectName, LPVOID lpParam);

BOOL VernoxProcessCallback(LPVOID lpParam, char *lpszTitle, int nTotal, int nPos);

// CDlgProgress �Ի���
class CDlgProgress : public CDialog
{
	DECLARE_DYNAMIC(CDlgProgress)

public:
	CDlgProgress(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgProgress();

	CString	m_strTitle;
	CString	m_strFileName;
	list<CString> *m_plistObjectName;
	LPVOID	m_lpParam;
	CALLBACK_VERNOXPROGRESS m_pVernoxProgressCallback;
// �Ի�������
	enum { IDD = IDD_DIALOG_PROGRESS };

protected:
	int		m_nTotal;
	BOOL	m_bCancelFlag;
	HANDLE	m_hCallbackThread;
	char	m_lpTitle[32];
	CProgressCtrl m_ctlProgress;
	CStatic m_staticInfo;

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	int TaskProgressCore();
	static unsigned int WINAPI TaskProgressThread(LPVOID data);

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();

	BOOL SetProcess(char *lpszTitle, int nTotal, int nPos);
	LRESULT OnFinished(WPARAM w, LPARAM l);
protected:
	virtual void OnCancel();
	virtual void OnOK();
public:
};

