/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// stdafx.h : ��׼ϵͳ�����ļ��İ����ļ���
// ���Ǿ���ʹ�õ��������ĵ�
// �ض�����Ŀ�İ����ļ�

#pragma once

#ifndef _SECURE_ATL
#define _SECURE_ATL 1
#endif

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN            // �� Windows ͷ���ų�����ʹ�õ�����
#endif

//����C���Ծ�����Ϣ
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_NONSTDC_NO_DEPRECATE 

#include "targetver.h"

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS      // ĳЩ CString ���캯��������ʽ��

// �ر� MFC ��ĳЩ�����������ɷ��ĺ��Եľ�����Ϣ������
#define _AFX_ALL_WARNINGS

#include <afxwin.h>         // MFC ��������ͱ�׼���
#include <afxext.h>         // MFC ��չ


#include <afxdisp.h>        // MFC �Զ�����



#ifndef _AFX_NO_OLE_SUPPORT
#include <afxdtctl.h>           // MFC �� Internet Explorer 4 �����ؼ���֧��
#endif
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>                     // MFC �� Windows �����ؼ���֧��
#endif // _AFX_NO_AFXCMN_SUPPORT









#ifdef _UNICODE
#if defined _M_IX86
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_IA64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='ia64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_X64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif
#endif




#include "..\VernoxClientLib\DBInterface.h"
#include "..\VernoxBaseLib\CommonBaseAPI.h"

#ifdef _M_X64
	#ifdef DEBUG                          
		#pragma comment(lib, "..\\LibX64\\VernoxClientLibD.lib")
	#else
		#pragma comment(lib, "..\\LibX64\\VernoxClientLib.lib")
	#endif
#else
	#ifdef DEBUG
		#pragma comment(lib, "..\\Lib\\VernoxClientLibD.lib")
	#else
		#pragma comment(lib, "..\\Lib\\VernoxClientLib.lib")					   
	#endif						       
#endif


//////////////////////////////////////////////////////////////////////////
#include <vector>
#include <list>
using namespace std;

typedef struct
{
	LPVOID m_lpTabPage;
	int m_nTabPageType;
	int m_nTabCount;
}STRUCT_TABPAGE, *LPSTRUCT_TABPAGE;

typedef struct
{
	CString m_strFileName;
	int m_nFileType;
}STRUCT_FILEINFO, *LPSTRUCT_FILEINFO;


typedef struct 
{
	char m_cProtocol[MAX_PATH];
	char m_cHost[MAX_PATH];
	char m_cPort[MAX_PATH];
	char m_cWriteLog[MAX_PATH];
}STRUCT_ADDRESS, LPSTRUCT_ADDRESS;


typedef struct 
{
	int m_nStartPos;
	int m_nEndPos;
	char m_cSobeyDB[MAX_PATH];
	char m_cDatabaseName[MAX_PATH];
	vector<STRUCT_ADDRESS> m_vecAddress;
}STRUCT_CONNECT_CONFIG, LPSTRUCT_CONNECT_CONFIG;



char* SMT_UnicodeToUTF8(const wchar_t * lpwData);

wchar_t* SMT_UTF8ToUnicode(const char * lpszData);

int SplitSql(char* lpszBuffer, int nLen, vector<char*>& vecSql);

char* RemoveSpaceFromString(char* lpStr);

int ParseSqlType(char* &lpSql);

ULONG StringToIpAddress(char* lpIpAddress);
