/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MainMenuSheetObjectSelect.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "MainMenuSheetObjectSelect.h"


// CMainMenuSheetObjectSelect �Ի���

IMPLEMENT_DYNAMIC(CMainMenuSheetObjectSelect, CDialog)

CMainMenuSheetObjectSelect::CMainMenuSheetObjectSelect(CWnd* pParent /*=NULL*/)
	: CDialog(CMainMenuSheetObjectSelect::IDD, pParent)
{

}

CMainMenuSheetObjectSelect::~CMainMenuSheetObjectSelect()
{
}

void CMainMenuSheetObjectSelect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SHEET_LISTBOX_UNSELECTED, m_listboxLeft);
	DDX_Control(pDX, IDC_SHEET_LISTBOX_SELECTED, m_listboxRight);
}

BOOL CMainMenuSheetObjectSelect::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_listboxLeft.ResetContent();
	m_listboxRight.ResetContent();
	m_listObject.clear();
	m_strObjectName = _T("");
	m_strExportFile = _T("");

	int nRet;
	char pSql[1024];
	wchar_t *lpwValue;
	CString strObject;
	ISobeyDBRecordsetPtr rs;
	MF_EXECUTE_STATISTICS stStatisticsInfo;

	memset(pSql, 0, sizeof(pSql));

	sprintf(pSql, "select * from v$object");
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
	nRet = g_pSobeyInterface->GetRecordset(pSql, &rs, &stStatisticsInfo);
	if (nRet == MF_OK)
	{
		rs->MoveFirst();
		while (!rs->eof())
		{
			rs->FieldValue(2, lpwValue);
			m_listboxLeft.AddString(lpwValue);
			rs->MoveNext();
		}
	}
	else
	{
		;
	}

	if (m_listboxLeft.GetCount() == 0)
	{
		GetDlgItem(IDOK)->EnableWindow(FALSE);
		GetDlgItem(ID_BTN_SHEET_MOVE_RIGHT)->EnableWindow(FALSE);
		GetDlgItem(ID_BTN_SHEET_MOVE_LEFT)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDOK)->EnableWindow(TRUE);
		GetDlgItem(ID_BTN_SHEET_MOVE_RIGHT)->EnableWindow(TRUE);
		GetDlgItem(ID_BTN_SHEET_MOVE_LEFT)->EnableWindow(TRUE);
	}

	return TRUE;
}

BEGIN_MESSAGE_MAP(CMainMenuSheetObjectSelect, CDialog)
	ON_BN_CLICKED(IDOK, &CMainMenuSheetObjectSelect::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CMainMenuSheetObjectSelect::OnBnClickedCancel)
	ON_BN_CLICKED(ID_BTN_SHEET_MOVE_RIGHT, &CMainMenuSheetObjectSelect::OnBnClickedBtnMoveRight)
	ON_BN_CLICKED(ID_BTN_SHEET_MOVE_LEFT, &CMainMenuSheetObjectSelect::OnBnClickedBtnMoveLeft)
	ON_LBN_DBLCLK(IDC_SHEET_LISTBOX_UNSELECTED, &CMainMenuSheetObjectSelect::OnLbnDblclkSheetListboxUnselected)
	ON_LBN_DBLCLK(IDC_SHEET_LISTBOX_SELECTED, &CMainMenuSheetObjectSelect::OnLbnDblclkSheetListboxSelected)
END_MESSAGE_MAP()


// CMainMenuSheetObjectSelect ��Ϣ��������

void CMainMenuSheetObjectSelect::OnBnClickedOk()
{
	int nCount;
	TCHAR lptDefaultDir[MAX_PATH];
	CString strValue, strText, strDefaultName, strDefaultDir, strFilter;

	m_listObject.clear();
	m_strObjectName = _T("");
	m_strExportFile = _T("");

	nCount = m_listboxRight.GetCount();
	if (nCount <= 0)
	{
		OnCancel();
		return;
	}
	for (int i = 0; i < nCount; i++)
	{
		m_listboxRight.GetText(i, strValue);
		m_listObject.push_back(strValue);
		m_strObjectName += strValue;
		m_strObjectName += _T(",");
	}
	m_strObjectName = m_strObjectName.Left(m_strObjectName.GetLength() - 1);


	GetModuleFileName(NULL, lptDefaultDir, MAX_PATH);
	(_tcsrchr(lptDefaultDir, '\\'))[0] = 0;
	(_tcsrchr(lptDefaultDir, '\\'))[1] = 0;
	strDefaultDir.Format(_T("%sData"), lptDefaultDir);
	strFilter = _T("�ļ� (*.db)|*.db|�����ļ� (*.*)|*.*||");
	strDefaultName.Format(_T("%s.db"), m_strObjectName);
	CFileDialog dlgFile(FALSE, NULL, strDefaultName, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, strFilter);
	dlgFile.GetOFN().lpstrInitialDir = strDefaultDir;  
	if (IDOK == dlgFile.DoModal())
	{
		m_strExportFile = dlgFile.GetPathName();
		strText.Format(_T("��������%s�����ݵ��ļ���%s��"), m_strObjectName, m_strExportFile);
		if (IDYES == CMessageBox(strText, MB_YESNO|MB_SYSTEMMODAL))
		{
			OnOK();
			return;
		}
	}
	OnCancel();
}

void CMainMenuSheetObjectSelect::OnBnClickedCancel()
{
	OnCancel();
}

void CMainMenuSheetObjectSelect::OnBnClickedBtnMoveRight()
{
	CString strText;
	int nCurSel = m_listboxLeft.GetCurSel();
	if (nCurSel < 0)
	{
		return;
	}
	m_listboxLeft.GetText(nCurSel, strText);
	m_listboxLeft.DeleteString(nCurSel);
	m_listboxRight.AddString(strText);
}

void CMainMenuSheetObjectSelect::OnBnClickedBtnMoveLeft()
{
	CString strText;
	int nCurSel = m_listboxRight.GetCurSel();
	if (nCurSel < 0)
	{
		return;
	}
	m_listboxRight.GetText(nCurSel, strText);
	m_listboxRight.DeleteString(nCurSel);
	m_listboxLeft.AddString(strText);
}

void CMainMenuSheetObjectSelect::OnLbnDblclkSheetListboxUnselected()
{
	OnBnClickedBtnMoveRight();
}

void CMainMenuSheetObjectSelect::OnLbnDblclkSheetListboxSelected()
{
	OnBnClickedBtnMoveLeft();
}
