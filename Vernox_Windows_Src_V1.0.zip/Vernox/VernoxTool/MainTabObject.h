/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "afxcmn.h"
#include "afxwin.h"

#include "MainTabObjectField.h"
#include "MainTabObjectIndex.h"

// CMainTabObject �Ի���

class CMainTabObject : public CDialog
{
	DECLARE_DYNAMIC(CMainTabObject)

public:
	CMainTabObject(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMainTabObject();

// �Ի�������
	enum { IDD = IDD_MAINTAB_OBJECT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	CMainTabObjectField m_dlgMainTabObjectField;
	CMainTabObjectIndex m_dlgMainTabObjectIndex;

public:
	CTabCtrl m_tabObject;
	CButton m_btnAddItem;
	CButton m_btnDeleteItem;

	CString m_strObjectName;
	CComboBox m_cbDataFile;
	CEdit m_editObjectResult;

	BOOL m_bExistedObject;
	ISobeyDBRecordsetPtr m_rsField;
	int m_nFieldMaxId;
	ISobeyDBRecordsetPtr m_rsIndex;
	int m_nIndexMaxId;

public:
	void TabObjectChange(int nIndex);

	BOOL CheckInput();

	BOOL CreateCommonObject(BOOL bShowSql = FALSE);

	BOOL OpenExistedObject(CString strObjectName);

	BOOL EditCommonObject(BOOL bShowSql = FALSE);

	BOOL FieldRowCompare(int nListIndex, int nRsIndex);

	void DisableDialog(CString strError);

private:
	BOOL ExecuteSql(CString strSql, BOOL bRemainLastText, BOOL bShowSql);

public:
	afx_msg void OnTcnSelchangeTabObject(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedBtnObjectAddItem();
	afx_msg void OnBnClickedBtnObjectDeleteItem();
	afx_msg void OnBnClickedBtnObjectSave();
	afx_msg void OnBnClickedBtnObjectShowsql();
protected:
	virtual void OnCancel();
	virtual void OnOK();
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
};
