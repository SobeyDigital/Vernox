/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MainTabQueryResult.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
//#include "MainTabQueryResult.h"

#include "MainTabQuery.h"


// CMainTabQueryResult �Ի���

IMPLEMENT_DYNAMIC(CMainTabQueryResult, CDialog)

CMainTabQueryResult::CMainTabQueryResult(CWnd* pParent /*=NULL*/)
	: CDialog(CMainTabQueryResult::IDD, pParent)
{
	m_nRow = 0;
	m_nCol = 0;
	m_bModifyAllowed = FALSE;
	m_strPreValue = _T("");
	m_pRs = NULL;
}

CMainTabQueryResult::~CMainTabQueryResult()
{
}

void CMainTabQueryResult::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_RESULT, m_listResult);
	DDX_Control(pDX, IDC_EDIT_QUERY_TEMP, m_editTemp);
}

BOOL CMainTabQueryResult::OnInitDialog()
{
	CDialog::OnInitDialog();

	//��ʼ���ؼ�
	m_listResult.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_INFOTIP);

	ChangeButtonEnable(FALSE);

	return TRUE;
}

BEGIN_MESSAGE_MAP(CMainTabQueryResult, CDialog)
	ON_NOTIFY(NM_CLICK, IDC_LIST_RESULT, &CMainTabQueryResult::OnNMClickListResult)
	ON_EN_KILLFOCUS(IDC_EDIT_QUERY_TEMP, &CMainTabQueryResult::OnEnKillfocusEditQueryTemp)
	ON_BN_CLICKED(IDC_BTN_QUERY_SAVE, &CMainTabQueryResult::OnBnClickedBtnQuerySave)
	ON_BN_CLICKED(IDC_BTN_QUERY_ADD_ITEM, &CMainTabQueryResult::OnBnClickedBtnQueryAddItem)
	ON_BN_CLICKED(IDC_BTN_QUERY_DELETE_ITEM, &CMainTabQueryResult::OnBnClickedBtnQueryDeleteItem)
	ON_WM_SIZE()
END_MESSAGE_MAP()


// CMainTabQueryResult ��Ϣ��������

void CMainTabQueryResult::ClearResult()
{
	//��ղ��
	int nRowNum, nColNum;
	LONGLONG *pllDataId;
	nRowNum = m_listResult.GetItemCount();
	nColNum = m_listResult.GetHeaderCtrl()->GetItemCount();
	//m_listResult.DeleteAllItems();
	while (nRowNum--)
	{
		pllDataId = (LONGLONG*)m_listResult.GetItemData(0);
		if (pllDataId != NULL)
		{
			delete pllDataId;
		}
		m_listResult.DeleteItem(0);
	}
	while(m_listResult.DeleteColumn(0))
	{
		;
	}

	ChangeButtonEnable(FALSE);
}

int CMainTabQueryResult::DisplayResult(ISobeyDBRecordset* pRs)
{
	m_pRs = pRs;
	ClearResult();

	int i, j, nIndex, nFieldNum;
	LONGLONG *pllDataId;
	wchar_t *lpwValue;

	nFieldNum = pRs->GetFieldNum();
	m_listResult.InsertColumn(0, _T("."), LVCFMT_LEFT, 15);
	for(j = 0;j < nFieldNum;j++)
	{
		m_listResult.InsertColumn(j+1, pRs->FieldName(j), LVCFMT_LEFT, 100);
	}

	i = 0;
	pRs->MoveFirst();
	while (!pRs->eof())
	{
		nIndex = m_listResult.InsertItem(i, _T("."));

		pllDataId = new LONGLONG;
		pRs->GetDataID(*pllDataId);
		m_listResult.SetItemData(nIndex, (DWORD_PTR)pllDataId);
		for(j = 0; j < nFieldNum; j++)
		{
			pRs->FieldValue(j, lpwValue);
			if (lpwValue != NULL)
			{
				m_listResult.SetItemText(nIndex, j+1, lpwValue);
			}
			else
			{
				m_listResult.SetItemText(nIndex, j+1, _T(""));
			}
		}
		i++;
		pRs->MoveNext();
	}
	ChangeButtonEnable(TRUE);

	return 0;
}

void CMainTabQueryResult::ChangeButtonEnable(BOOL bEnable)
{
	GetDlgItem(IDC_BTN_QUERY_SAVE)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_QUERY_ADD_ITEM)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_QUERY_DELETE_ITEM)->EnableWindow(bEnable);
	m_bModifyAllowed = bEnable;
	return;
}

//////////////////////////////////////////////////////////////////////////

void CMainTabQueryResult::OnNMClickListResult(NMHDR *pNMHDR, LRESULT *pResult)
{
	*pResult = 0;
	if (!m_bModifyAllowed)
	{
		return;
	}

	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<NMITEMACTIVATE*>(pNMHDR);

	NM_LISTVIEW* pNMListView=(NM_LISTVIEW*)pNMHDR;
	CRect rc;
	m_nRow = pNMListView->iItem;		//���ѡ�е���  
	m_nCol = pNMListView->iSubItem;		//���ѡ���� 

	if (m_nRow == -1 || m_nCol == 0)
	{
		return;
	}
 
	m_listResult.GetSubItemRect(m_nRow, m_nCol, LVIR_LABEL, rc);		//��������RECT 
	m_editTemp.SetParent(&m_listResult);								//ת������Ϊ�б����е�����
	m_editTemp.MoveWindow(rc);											//�ƶ�Edit��RECT���ڵ�λ�� 
	m_strPreValue = m_listResult.GetItemText(m_nRow, m_nCol);
	m_editTemp.SetWindowText(m_strPreValue);							//���������е�ֵ����Edit�ؼ���  
	m_editTemp.ShowWindow(SW_SHOW);										//��ʾEdit�ؼ�  
	m_editTemp.SetFocus();												//����Edit����
	m_editTemp.ShowCaret();												//��ʾ���
	m_editTemp.SetSel(-1);												//������ƶ������

}

void CMainTabQueryResult::OnEnKillfocusEditQueryTemp()
{
	int nRet;
	LONGLONG *pllDataId;
	CString strTemp, strText;
	m_editTemp.GetWindowText(strTemp);						//�õ��û�������µ�����   
	if (m_strPreValue != strTemp)
	{
		pllDataId = (LONGLONG*)m_listResult.GetItemData(m_nRow);
		if (pllDataId == NULL)
		{
			CMessageBox(_T("DataIdΪ�գ�"));
			return;
		}
		m_pRs->SetCurrentRow(*pllDataId);
		nRet = m_pRs->SetField(m_nCol-1, strTemp.GetBuffer());
		if (nRet == 0)
		{
			m_listResult.SetItemText(m_nRow, m_nCol, strTemp);		//���ñ༭���������
		} 
		else
		{
			strText.Format(_T("�޸����ݳ����������룺%d��%s��"), nRet, GetErrorWDescription(nRet));
			CMessageBox(strText);
		}
	} 
	m_editTemp.ShowWindow(SW_HIDE);							//���ر༭��
}

void CMainTabQueryResult::OnBnClickedBtnQuerySave()
{
	int nRet;
	CString strText;
	MF_EXECUTE_STATISTICS stStatisticsInfo;
	memset(&stStatisticsInfo, 0, sizeof(stStatisticsInfo));
	nRet = g_pSobeyInterface->UpdateRecordset(m_pRs, &stStatisticsInfo);
	if (nRet != MF_OK)
	{
		strText.Format(_T("���½����ʧ�ܣ�����ֵ��%d��%s���������룺%d��%s��"), nRet, GetErrorWDescription(nRet), stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet));
		CMessageBox(strText);
		return;
	}
	else
	{
		DWORD dwClientIme;
		if(stStatisticsInfo.m_llFrequence == 0)
		{
			dwClientIme		 = 0;
		}
		else
		{
			if(stStatisticsInfo.m_llEnd > stStatisticsInfo.m_llStart && stStatisticsInfo.m_llStart != 0)
			{
				dwClientIme		 = (DWORD)(1000000 * (stStatisticsInfo.m_llEnd - stStatisticsInfo.m_llStart) / stStatisticsInfo.m_llFrequence);//���㵽΢����
			}
			else
			{
				dwClientIme		 = 0;
			}
		}
		strText.Format(_T("���³ɹ���\r\n��ʱ��%.3lfs\r\n"), (double)dwClientIme/1000000.0);
		CMessageBox(strText);

		CMainTabQuery *pParent;
		pParent = (CMainTabQuery*)GetParent()->GetParent();
		pParent->RedoLastQuery();
	}
}

void CMainTabQueryResult::OnBnClickedBtnQueryAddItem()
{
	CString strText;
	LONGLONG llDataId, *pllDataId;
	int nRet, nColumnCount;
	nColumnCount = m_listResult.GetItemCount();

	nRet = m_pRs->AddNew(llDataId);
	if (nRet == 0)
	{
		m_listResult.InsertItem(nColumnCount, _T("."));

		pllDataId = new LONGLONG;
		*pllDataId = llDataId;
		m_listResult.SetItemData(nColumnCount, (DWORD_PTR)pllDataId);
	} 
	else
	{
		strText.Format(_T("�������ݳ����������룺%d��%s��"), nRet, GetErrorWDescription(nRet));
		CMessageBox(strText);
	}
}

void CMainTabQueryResult::OnBnClickedBtnQueryDeleteItem()
{
	BOOL bDelete;
	CString strText;
	LONGLONG *pllDataId;
	int i, nRet, nColumnCount;
	nColumnCount = m_listResult.GetItemCount();
	if (nColumnCount <= 0)
	{
		return;
	}

	bDelete = FALSE;
	for (i = nColumnCount - 1; i >= 0; i--) 
	{ 
		if (m_listResult.GetItemState(i, LVIS_SELECTED) == LVIS_SELECTED)		//��i�б�ѡ��
		{
			pllDataId = (LONGLONG*)m_listResult.GetItemData(i);
			if (pllDataId == NULL)
			{
				strText.Format(_T("��%d��DataIdΪ�գ�"), i+1);
				CMessageBox(strText);
				return;
			}
			m_pRs->SetCurrentRow(*pllDataId);
			nRet = m_pRs->Delete();
			if (nRet == 0)
			{
				delete pllDataId;
				m_listResult.DeleteItem(i);
			} 
			else
			{
				strText.Format(_T("��%d��ɾ�����ݳ����������룺%d��%s��"), i+1, nRet, GetErrorWDescription(nRet));
				CMessageBox(strText);
				return;
			}
		}
	}
}

void CMainTabQueryResult::OnSize(UINT nType, int cx, int cy)
{
	CRect rtCtrl, rtClient;
	CDialog::OnSize(nType, cx, cy);

	//�ƶ������ڴ�С
	GetClientRect(rtClient);
	m_listResult.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.right = rtClient.right - 2;
	rtCtrl.bottom = rtClient.bottom - 2;
	m_listResult.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
}

void CMainTabQueryResult::OnCancel()
{
	//CDialog::OnCancel();
}

void CMainTabQueryResult::OnOK()
{
	//CDialog::OnOK();
}
