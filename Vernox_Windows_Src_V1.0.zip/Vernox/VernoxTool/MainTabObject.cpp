/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MainTabObject.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "SobeyMemToolDlg.h"
#include "MainTabObject.h"
//#include "MainTabObject.h"


// CMainTabObject �Ի���

IMPLEMENT_DYNAMIC(CMainTabObject, CDialog)

CMainTabObject::CMainTabObject(CWnd* pParent /*=NULL*/)
	: CDialog(CMainTabObject::IDD, pParent)
{
	m_strObjectName = _T("");
	m_bExistedObject = FALSE;
	m_nFieldMaxId = 0;
	m_nIndexMaxId = 0;
}

CMainTabObject::~CMainTabObject()
{
}

void CMainTabObject::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TAB_OBJECT, m_tabObject);
	DDX_Control(pDX, IDC_BTN_OBJECT_ADD_ITEM, m_btnAddItem);
	DDX_Control(pDX, IDC_BTN_OBJECT_DELETE_ITEM, m_btnDeleteItem);
	DDX_Text(pDX, IDC_EDIT_OBJECT_NAME, m_strObjectName);
	DDX_Control(pDX, IDC_EDIT_OBJETCT_RESULT, m_editObjectResult);
	DDX_Control(pDX, IDC_COMBO_OBJECT_DATAFILE, m_cbDataFile);
}

BOOL CMainTabObject::OnInitDialog()
{
	CDialog::OnInitDialog();

	//��ʼ���ؼ�
	m_tabObject.InsertItem(0, _T("�ֶ�"));
	m_tabObject.InsertItem(1, _T("����"));

	m_dlgMainTabObjectField.Create(IDD_MAINTAB_OBJECT_FILED, GetDlgItem(IDC_TAB_OBJECT));
	m_dlgMainTabObjectIndex.Create(IDD_MAINTAB_OBJECT_INDEX, GetDlgItem(IDC_TAB_OBJECT));

	CRect rs; 
	m_tabObject.GetClientRect(&rs); 
	rs.top += 22; 
	rs.bottom -= 2; 
	rs.left += 2; 
	rs.right -= 2;

	m_dlgMainTabObjectField.MoveWindow(&rs);
	m_dlgMainTabObjectIndex.MoveWindow(&rs);

	TabObjectChange(0);

	//
	int nFileType;
	CString strFile;
	CSobeyMemToolDlg *pParent;
	list<STRUCT_FILEINFO>::iterator iter;
	list<STRUCT_FILEINFO>* plistFileInfo;

	pParent = (CSobeyMemToolDlg*)GetParent()->GetParent();
	plistFileInfo = &(pParent->m_listFileInfo);
	if (plistFileInfo->size() > 0)
	{
		for (iter = plistFileInfo->begin(); iter != plistFileInfo->end(); iter++)
		{
			nFileType = ((STRUCT_FILEINFO)*iter).m_nFileType;
			if (nFileType == MF_SYS_FILETYPE_DATAFILE)
			{
				strFile.Format(_T("DATAFILE '%s'"), ((STRUCT_FILEINFO)*iter).m_strFileName);
			}
			else if (nFileType == MF_SYS_FILETYPE_TREEINDEXFILE)
			{
				strFile.Format(_T("TREEFILE '%s'"), ((STRUCT_FILEINFO)*iter).m_strFileName);
			}
			else if (nFileType == MF_SYS_FILETYPE_KVINDEXFILE)
			{
				strFile.Format(_T("KVFILE '%s'"), ((STRUCT_FILEINFO)*iter).m_strFileName);
			}
			else
			{
				continue;
			}

			if (nFileType == MF_SYS_FILETYPE_DATAFILE)
			{
				m_cbDataFile.AddString(strFile);
			}
		}
	}
	m_cbDataFile.SetCurSel(0);

	return TRUE;
}

BEGIN_MESSAGE_MAP(CMainTabObject, CDialog)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_OBJECT, &CMainTabObject::OnTcnSelchangeTabObject)
	ON_BN_CLICKED(IDC_BTN_OBJECT_ADD_ITEM, &CMainTabObject::OnBnClickedBtnObjectAddItem)
	ON_BN_CLICKED(IDC_BTN_OBJECT_DELETE_ITEM, &CMainTabObject::OnBnClickedBtnObjectDeleteItem)
	ON_BN_CLICKED(IDC_BTN_OBJECT_SAVE, &CMainTabObject::OnBnClickedBtnObjectSave)
	ON_BN_CLICKED(IDC_BTN_OBJECT_SHOWSQL, &CMainTabObject::OnBnClickedBtnObjectShowsql)
	ON_WM_SIZE()
END_MESSAGE_MAP()


// CMainTabObject ��Ϣ��������

void CMainTabObject::TabObjectChange(int nIndex)
{
	m_tabObject.SetCurSel(nIndex);
	switch (nIndex)
	{
	case 0:
		m_dlgMainTabObjectField.ShowWindow(TRUE);
		m_dlgMainTabObjectIndex.ShowWindow(FALSE);

		m_btnAddItem.SetWindowText(_T("�����ֶ�"));
		m_btnDeleteItem.SetWindowText(_T("ɾ���ֶ�"));
		break;
	case 1:
		m_dlgMainTabObjectField.ShowWindow(FALSE);
		m_dlgMainTabObjectIndex.ShowWindow(TRUE);

		m_btnAddItem.SetWindowText(_T("��������"));
		m_btnDeleteItem.SetWindowText(_T("ɾ������"));
		break;
	default:
		break;
	}
}

BOOL CMainTabObject::CheckInput()
{
	//�������
	int i, nCount;
	CString strValue, strText;

	if (m_strObjectName == _T(""))
	{
		m_editObjectResult.SetWindowText(_T("����Ϊ�գ�"));
		return FALSE;
	}

	m_cbDataFile.GetWindowText(strValue);
	if (strValue == _T(""))
	{
		m_editObjectResult.SetWindowText(_T("�洢λ��Ϊ�գ�"));
		return FALSE;
	}


	nCount = m_dlgMainTabObjectField.m_listObject.GetItemCount();
	if (nCount > 0)
	{
		for (i = 0; i < nCount; i++)
		{
			if (m_dlgMainTabObjectField.m_listObject.GetItemText(i, 1) == _T(""))
			{
				if (m_dlgMainTabObjectField.m_listObject.GetItemText(i, 2) == _T("")
					&& m_dlgMainTabObjectField.m_listObject.GetItemText(i, 3) == _T("")
					&& m_dlgMainTabObjectField.m_listObject.GetItemText(i, 4) == _T(""))
				{
					m_dlgMainTabObjectField.m_listObject.DeleteItem(i);
					nCount--;
					i--;
				}
				else
				{
					strText.Format(_T("�ֶ�%d����������!"), i+1);
					m_editObjectResult.SetWindowText(strText);
					return FALSE;
				}
			}
			else
			{
				if (m_dlgMainTabObjectField.m_listObject.GetItemText(i, 2) == _T("") || m_dlgMainTabObjectField.m_listObject.GetItemText(i, 3) == _T(""))
				{
					strText.Format(_T("�ֶ�%d����������!"), i+1);
					m_editObjectResult.SetWindowText(strText);
					return FALSE;
				}
				else
				{
					if (m_dlgMainTabObjectField.m_listObject.GetItemText(i, 4) == _T(""))
					{
						m_dlgMainTabObjectField.m_listObject.SetItemText(i, 4, _T("yes"));
					}
				}
			}
		}

	} 
	else
	{
		m_editObjectResult.SetWindowText(_T("û���ֶΣ�"));
		return FALSE;
	}
	if (nCount == 0)
	{
		m_editObjectResult.SetWindowText(_T("û���ֶΣ�"));
		return FALSE;
	}
	


	nCount = m_dlgMainTabObjectIndex.m_listObject.GetItemCount();
	if (nCount > 0)
	{
		for (i = 0; i < nCount; i++)
		{
			if (m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 1) == _T("")
				&& m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 2) == _T("")
				&& m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 3) == _T("")
				&& m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 4) == _T("")
				&& m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 5) == _T(""))
			{
				//�������Ϊ��
				m_dlgMainTabObjectIndex.m_listObject.DeleteItem(i);
				nCount--;
				i--;
			}
			else if (m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 1) == _T("")
				|| m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 2) == _T("")
				|| m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 3) == _T("")
				|| m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 4) == _T("")
				|| m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 5) == _T(""))
			{
				//ĳЩ��Ϊ��
				strText.Format(_T("����%d����������!"), i+1);
				m_editObjectResult.SetWindowText(strText);
				return FALSE;
			}
			else
			{
				//���������ֵ
				;
			}
		}
	}

	return TRUE;
}

BOOL CMainTabObject::CreateCommonObject(BOOL bShowSql)
{
	int i, nCount;
	CString strSql, strField, strFile;
	CString strName, strName2, strName3, strName4, strName5, strTemp;

	//�ֶ�
	nCount = m_dlgMainTabObjectField.m_listObject.GetItemCount();
	if (nCount > 0)
	{
		strField = _T("");
		for (i = 0; i < nCount; i++)
		{
			strName = m_dlgMainTabObjectField.m_listObject.GetItemText(i, 1);			//�ֶ���
			if (strName == _T(""))
			{
				goto CreateCommonObject_Error;
			}

			strName2 = m_dlgMainTabObjectField.m_listObject.GetItemText(i, 2);			//��������
			if (strName2 == _T(""))
			{
				goto CreateCommonObject_Error;
			}
			if (strName2.CompareNoCase(_T("char")) == 0)
			{
				strName3 = m_dlgMainTabObjectField.m_listObject.GetItemText(i, 3);		//���ݳ���
				if (strName3 == _T(""))
				{
					goto CreateCommonObject_Error;
				}
				strName2 += _T("(");
				strName2 += strName3;
				strName2 += _T(")");
			}

			strName4 = m_dlgMainTabObjectField.m_listObject.GetItemText(i, 4);			//������ֵ��NULL��
			if (strName4.CompareNoCase(_T("yes")) == 0)
			{
				strTemp.Format(_T("%s %s,"), strName, strName2);
			}
			else
			{
				strTemp.Format(_T("%s %s not null,"), strName, strName2);
			}

			strField += strTemp;
		}
	} 
	else
	{
		goto CreateCommonObject_Error;
	}

	m_cbDataFile.GetWindowText(strFile);
	strFile += _T(" ");

	nCount = m_dlgMainTabObjectIndex.m_listObject.GetItemCount();
	if (nCount > 0)
	{
		for (i = 0; i < nCount; i++)
		{
			//����
			strName = m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 1);			//������
			if (strName == _T(""))
			{
				goto CreateCommonObject_Error;
			}

			strName2 = m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 2);			//�ֶ�
			if (strName == _T(""))
			{
				goto CreateCommonObject_Error;
			}

			strName3 = m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 3);			//��������
			if (strName == _T(""))
			{
				goto CreateCommonObject_Error;
			}

			strName4 = m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 4);			//�����ṹ
			if (strName == _T(""))
			{
				goto CreateCommonObject_Error;
			}

			if (strName3.CompareNoCase(_T("primarykey")) == 0)
			{
				strTemp.Format(_T("primary key(%s),"), strName2);
				strName5 = _T("");
			}
			else if (strName3.CompareNoCase(_T("unique")) == 0)
			{
				strTemp = _T("");
				strName5 = _T("unique ");
			}
			else //if (strName3.CompareNoCase(_T("common")) == 0)
			{
				strTemp = _T("");
				strName5 = _T("");
			}
			strField += strTemp;

			if (strName4.CompareNoCase(_T("KV")) == 0)
			{
				strTemp.Format(_T("index %skv %s(%s),"), strName5, strName, strName2);
			}
			else if (strName4.CompareNoCase(_T("BTree")) == 0)
			{
				strTemp.Format(_T("index %stree %s(%s),"), strName5, strName, strName2);
			}
			strField += strTemp;

			//�ļ�
			strTemp = m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 5);
			if (strFile.Find(strTemp) == -1)
			{
				strFile += strTemp;
				strFile += _T(" ");
			}
		}
	}

	strField.Delete(strField.GetLength() - 1, 1);		//ȥ��ĩβ��һ������

	strSql.Format(_T("CREATE OBJECT %s(%s) %s"), m_strObjectName, strField, strFile);
	return ExecuteSql(strSql, FALSE, bShowSql);

CreateCommonObject_Error:
	m_editObjectResult.SetWindowText(_T("error!"));
	return FALSE;
}

BOOL CMainTabObject::ExecuteSql(CString strSql, BOOL bRemainLastText, BOOL bShowSql)
{
	BOOL bResult = FALSE;
	char* lpSql;
	CString strTemp, strText;
	int nRet, nAffectCount;
	MF_EXECUTE_STATISTICS stStatisticsInfo;

	lpSql = NULL;

	if (bRemainLastText)
	{
		m_editObjectResult.GetWindowText(strText);
	}
	else
	{
		strText = _T("");
	}

	lpSql = SMT_UnicodeToUTF8(strSql);
	if (lpSql == NULL)
	{
		strTemp.Format(_T("����ת��ʧ�ܣ������룺%d\r\nSQL��䣺%s\r\n"), GetLastError(), strSql);
		m_editObjectResult.SetWindowText(strText+strTemp);
		return FALSE;
	}

	if (bShowSql)
	{
		memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
		//hr = g_pSobeyInterface->GetExecutePlanInfo(lpSql, &stExecutePlanDesc, &stStatisticsInfo);
		nRet = MF_OK;
		if (nRet != MF_OK)
		{
			bResult = FALSE;

			strTemp.Format(_T("��ʾSQL���\r\nִ��ʧ�ܣ�����ֵ��%d��%s���������룺%d��%s��\r\nSQL��䣺%s\r\n"), nRet, GetErrorWDescription(nRet), stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet), strSql);
			m_editObjectResult.SetWindowText(strText+strTemp);
		}
		else
		{
			bResult = TRUE;
			//��ʾ�����Ϣ
			DWORD dwClientIme;
			if(stStatisticsInfo.m_llFrequence == 0)
			{
				dwClientIme		 = 0;
			}
			else
			{
				if(stStatisticsInfo.m_llEnd > stStatisticsInfo.m_llStart && stStatisticsInfo.m_llStart != 0)
				{
					dwClientIme		 = (DWORD)(1000000 * (stStatisticsInfo.m_llEnd - stStatisticsInfo.m_llStart) / stStatisticsInfo.m_llFrequence);//���㵽΢����
				}
				else
				{
					dwClientIme		 = 0;
				}
			}
			strTemp.Format(_T("��ʾSQL���\r\n��ʱ��%.3lfs\r\nSQL��䣺%s\r\n"), (double)dwClientIme/1000000.0, strSql);
			m_editObjectResult.SetWindowText(strText+strTemp);
		}
	} 
	else
	{
		nAffectCount = 0;
		memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
		nRet = g_pSobeyInterface->Execute(lpSql, nAffectCount, &stStatisticsInfo);
		if (nRet != MF_OK)
		{
			bResult = FALSE;

			strTemp.Format(_T("ִ��ʧ�ܣ�����ֵ��%d��%s���������룺%d��%s��\r\nSQL��䣺%s\r\n"), nRet, GetErrorWDescription(nRet), stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet), strSql);
			m_editObjectResult.SetWindowText(strText+strTemp);
		}
		else
		{
			bResult = TRUE;
			//��ʾ�����Ϣ
			DWORD dwClientIme;
			if(stStatisticsInfo.m_llFrequence == 0)
			{
				dwClientIme		 = 0;
			}
			else
			{
				if(stStatisticsInfo.m_llEnd > stStatisticsInfo.m_llStart && stStatisticsInfo.m_llStart != 0)
				{
					dwClientIme		 = (DWORD)(1000000 * (stStatisticsInfo.m_llEnd - stStatisticsInfo.m_llStart) / stStatisticsInfo.m_llFrequence);//���㵽΢����
				}
				else
				{
					dwClientIme		 = 0;
				}
			}
			strTemp.Format(_T("ִ�гɹ���\r\n�޸ĵļ�¼����%d\r\n��ʱ��%.3lfs\r\nSQL��䣺%s\r\n"), nAffectCount, (double)dwClientIme/1000000.0, strSql);
			m_editObjectResult.SetWindowText(strText+strTemp);
		}
	}

	delete[] lpSql;
	return bResult;
}


BOOL CMainTabObject::OpenExistedObject(CString strObjectName)
{
	char *lpSql;
	wchar_t *lpwValue, *lpwValue1, *lpwValue2;
	int i, nRet;
	CString strTemp, strText;
	ISobeyDBRecordsetPtr rs;
	MF_EXECUTE_STATISTICS stStatisticsInfo;

	lpSql = NULL;

	m_strObjectName = strObjectName;

	//����λ��
	strTemp.Format(_T("select filename, filetype from v$object where objectname = '%s'"), strObjectName);
	lpSql = SMT_UnicodeToUTF8(strTemp);
	if (lpSql == NULL)
	{
		strText.Format(_T("����ת��ʧ�ܣ������룺%d"), GetLastError());
		DisableDialog(strText);
		return FALSE;
	}
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
	nRet = g_pSobeyInterface->GetRecordset(lpSql, &rs, &stStatisticsInfo);
	delete[] lpSql;
	if (nRet != MF_OK)
	{
		strText.Format(_T("ִ��ʧ�ܣ�SQL��䣺%s������ֵ��%d��%s���������룺%d��%s��"), strTemp, nRet, GetErrorWDescription(nRet), stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet));
		DisableDialog(strText);
		return FALSE;
	}
	if (rs->GetRowNum() == 0)
	{
		strText.Format(_T("���ؽ����Ϊ�գ����ҵı������ڣ�SQL��䣺%s"), strTemp);
		DisableDialog(strText);
		return FALSE;
	}
	rs->MoveFirst();
	rs->FieldValue(1, lpwValue1);
	rs->FieldValue(0, lpwValue2);
	strText.Format(_T("%s '%s'"), lpwValue1, lpwValue2);
	if (m_cbDataFile.SelectString(0, strText) < 0)
	{
		strText.Format(_T("δ�ҵ�ָ���ļ���%s"), strTemp);
		DisableDialog(strText);
		return FALSE;
	}
	m_cbDataFile.EnableWindow(FALSE);



	//�ֶ�
	strTemp.Format(_T("select * from v$column where objectname = '%s'"), strObjectName);
	lpSql = SMT_UnicodeToUTF8(strTemp);
	if (lpSql == NULL)
	{
		strText.Format(_T("����ת��ʧ�ܣ������룺%d"), GetLastError());
		DisableDialog(strText);
		return FALSE;
	}
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
	nRet = g_pSobeyInterface->GetRecordset(lpSql, &m_rsField, &stStatisticsInfo);
	delete[] lpSql;
	if (nRet != MF_OK)
	{
		strText.Format(_T("ִ��ʧ�ܣ�SQL��䣺%s������ֵ��%d��%s���������룺%d��%s��"), strTemp, nRet, GetErrorWDescription(nRet), stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet));
		DisableDialog(strText);
		return FALSE;
	}

	m_dlgMainTabObjectField.m_listObject.DeleteAllItems();
	m_nFieldMaxId = m_rsField->GetRowNum();
	m_dlgMainTabObjectField.SetExistedCount(m_nFieldMaxId);

	i = 0;
	m_rsField->MoveFirst();
	while (!m_rsField->eof())
	{
		strTemp.Format(_T("%d"), i+1);
		m_dlgMainTabObjectField.m_listObject.InsertItem(i, strTemp);
		m_rsField->FieldValue(1, lpwValue);
		m_dlgMainTabObjectField.m_listObject.SetItemText(i, 1, lpwValue);		//�ֶ���
		m_rsField->FieldValue(2, lpwValue);
		m_dlgMainTabObjectField.m_listObject.SetItemText(i, 2, lpwValue);		//��������
		m_rsField->FieldValue(3, lpwValue);
		m_dlgMainTabObjectField.m_listObject.SetItemText(i, 3, lpwValue);		//����
		m_rsField->FieldValue(4, lpwValue);
		if (_tcsicmp(lpwValue, _T("yes")) == 0)									//������ֵ��NULL��
		{
			m_dlgMainTabObjectField.m_listObject.SetItemText(i, 4, _T("no"));
		} 
		else
		{
			m_dlgMainTabObjectField.m_listObject.SetItemText(i, 4, _T("yes"));
		}

		i++;
		m_rsField->MoveNext();
	}

	//����
	strTemp.Format(_T("select * from v$index where objectname = '%s'"), strObjectName);
	lpSql = SMT_UnicodeToUTF8(strTemp);
	if (lpSql == NULL)
	{
		strText.Format(_T("����ת��ʧ�ܣ������룺%d"), GetLastError());
		DisableDialog(strText);
		return FALSE;
	}
	memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
	nRet = g_pSobeyInterface->GetRecordset(lpSql, &m_rsIndex, &stStatisticsInfo);
	delete[] lpSql;
	if (nRet != MF_OK)
	{
		strText.Format(_T("ִ��ʧ�ܣ�SQL��䣺%s������ֵ��%d��%s���������룺%d��%s��"), strTemp, nRet, GetErrorWDescription(nRet), stStatisticsInfo.m_nRet, GetErrorWDescription(stStatisticsInfo.m_nRet));
		DisableDialog(strText);
		return FALSE;
	}

	m_dlgMainTabObjectIndex.m_listObject.DeleteAllItems();
	m_nIndexMaxId = m_rsIndex->GetRowNum();
	m_dlgMainTabObjectIndex.SetExistedCount(m_nIndexMaxId);

	i = 0;
	m_rsIndex->MoveFirst();
	while (!m_rsIndex->eof())
	{
		strTemp.Format(_T("%d"), i+1);
		m_dlgMainTabObjectIndex.m_listObject.InsertItem(i, strTemp);
		m_rsIndex->FieldValue(2, lpwValue);
		m_dlgMainTabObjectIndex.m_listObject.SetItemText(i, 1, lpwValue);		//������
		m_rsIndex->FieldValue(3, lpwValue);
		m_dlgMainTabObjectIndex.m_listObject.SetItemText(i, 2, lpwValue);		//�ֶ�
		m_rsIndex->FieldValue(4, lpwValue);
		m_dlgMainTabObjectIndex.m_listObject.SetItemText(i, 3, lpwValue);		//��������
		m_rsIndex->FieldValue(5, lpwValue);
		m_dlgMainTabObjectIndex.m_listObject.SetItemText(i, 4, lpwValue);		//�����ṹ
		m_rsIndex->FieldValue(8, lpwValue1);
		m_rsIndex->FieldValue(7, lpwValue2);
		strTemp.Format(_T("%s '%s'"), lpwValue1, lpwValue2);
		m_dlgMainTabObjectIndex.m_listObject.SetItemText(i, 5, strTemp);		//�洢�ļ�

		i++;
		m_rsIndex->MoveNext();
	}

	m_bExistedObject = TRUE;
	SetDlgItemText(IDC_BTN_OBJECT_SAVE, _T("����Ķ�"));
	((CEdit*)GetDlgItem(IDC_EDIT_OBJECT_NAME))->SetReadOnly(TRUE);
	//m_tabObject.DeleteItem(1);			//��������ҳ��
	UpdateData(FALSE);
	return TRUE;
}


//Ŀǰֻ֧���ֶ�����
BOOL CMainTabObject::EditCommonObject(BOOL bShowSql)
{
	int i, j, nListRows, nRsRows, nListIndex, nRsIndex, nVectorSize;
	CString strValue, strSql, strName, strName2, strName3, strName4, strAddField, strDeleteField;
	vector<CString> vecAddIndex, vecDeleteIndex;
	wchar_t *lpwValue;

	m_editObjectResult.SetWindowText(_T(""));
	//�ֶ�
	strAddField = _T("");
	strDeleteField = _T("");

	nListRows = m_dlgMainTabObjectField.m_listObject.GetItemCount();
	nRsRows = m_rsField->GetRowNum();
	i = 0;
	j = 0;
	while (i < nListRows && j < nRsRows)		//��ԭRecordset�Աȣ��ҵ��޸ĵĲ���
	{
		strValue = m_dlgMainTabObjectField.m_listObject.GetItemText(i, 0);
		nListIndex = _ttoi(strValue);
		nRsIndex = j+1;
		if (nListIndex == nRsIndex)
		{
			//�ݲ�֧���޸�ĳһ��
			i++;
			j++;
			//if (FieldRowCompare(i, j))
			//{
			//	i++;
			//	j++;
			//	continue;
			//}
			//else
			//{
			//	strSql.Format(_T("alter object %s modify"), m_strObjectName);
			//}
		}
		else if (nListIndex > nRsIndex)
		{
			//��j���ѱ�ɾ��
			m_rsField->SetCurrentRow(j);
			m_rsField->FieldValue(1, lpwValue);
			strValue.Format(_T("%s,"), lpwValue);
			strDeleteField += strValue;
			j++;
		}
		else	//nListIndex < nRsIndex
		{
			//��Ӧ�����������
			goto EditCommonObject_RollBack;
		}
	}

	if (i < nListRows)		//&& j == nRsRows
	{
		//��Щ���������ӵ���
		for (; i < nListRows; i++)
		{
			strName = m_dlgMainTabObjectField.m_listObject.GetItemText(i, 1);			//�ֶ���
			strName2 = m_dlgMainTabObjectField.m_listObject.GetItemText(i, 2);			//��������
			if (strName2.CompareNoCase(_T("char")) == 0)
			{
				strName3 = m_dlgMainTabObjectField.m_listObject.GetItemText(i, 3);		//���ݳ���
				strName2 += _T("(");
				strName2 += strName3;
				strName2 += _T(")");
			}
			strName4 = m_dlgMainTabObjectField.m_listObject.GetItemText(i, 4);			//������ֵ��NULL��
			if (strName4.CompareNoCase(_T("yes")) == 0)
			{
				strValue.Format(_T("%s %s,"), strName, strName2);
			}
			else
			{
				strValue.Format(_T("%s %s not null,"), strName, strName2);
			}
			strAddField += strValue;
		}
	}
	else if (j < nRsRows)		//&& i == nListRows
	{
		//��Щ������ɾ������
		for (; j < nRsRows; j++)
		{
			m_rsField->SetCurrentRow(j);
			m_rsField->FieldValue(1, lpwValue);
			strValue.Format(_T("%s,"), lpwValue);
			strDeleteField += strValue;
		}
	}

	//�����ȷ��һ��
	if (i == nListRows && j == nRsRows)
	{
		//��ɾ����������
		if (strDeleteField != _T(""))
		{
			strDeleteField.Delete(strDeleteField.GetLength() - 1, 1);
			strSql.Format(_T("alter object %s drop (%s)"), m_strObjectName, strDeleteField);
			if (!ExecuteSql(strSql, TRUE, bShowSql))
			{
				goto EditCommonObject_RollBack;
			}
		}

		if (strAddField != _T(""))
		{
			strAddField.Delete(strAddField.GetLength() - 1, 1);
			strSql.Format(_T("alter object %s add (%s)"), m_strObjectName, strAddField);
			if (!ExecuteSql(strSql, TRUE, bShowSql))
			{
				goto EditCommonObject_RollBack;
			}
		}
	} 
	else
	{
		goto EditCommonObject_RollBack;
	}

	//����
	vecAddIndex.clear();
	vecDeleteIndex.clear();

	nListRows = m_dlgMainTabObjectIndex.m_listObject.GetItemCount();
	nRsRows = m_rsIndex->GetRowNum();
	i = 0;
	j = 0;
	while (i < nListRows && j < nRsRows)		//��ԭRecordset�Աȣ��ҵ��޸ĵĲ���
	{
		strValue = m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 0);
		nListIndex = _ttoi(strValue);
		nRsIndex = j+1;
		if (nListIndex == nRsIndex)
		{
			//�ݲ�֧���޸�ĳһ��
			i++;
			j++;
			//if (FieldRowCompare(i, j))
			//{
			//	i++;
			//	j++;
			//	continue;
			//}
			//else
			//{
			//	strSql.Format(_T("alter object %s modify"), m_strObjectName);
			//}
		}
		else if (nListIndex > nRsIndex)
		{
			//��j���ѱ�ɾ��
			m_rsIndex->SetCurrentRow(j);
			m_rsIndex->FieldValue(2, lpwValue);
			strSql.Format(_T("alter object %s drop index %s"), m_strObjectName, lpwValue);
			vecDeleteIndex.push_back(strSql);
			j++;
		}
		else	//nListIndex < nRsIndex
		{
			//��Ӧ�����������
			goto EditCommonObject_RollBack;
		}
	}

	if (i < nListRows)		//&& j == nRsRows
	{
		//��Щ���������ӵ���
		for (; i < nListRows; i++)
		{
			strName = m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 1);			//������
			strName2 = m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 2);			//�ֶ�
			strName3 = m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 5);			//�洢�ļ�

			strName4 = m_dlgMainTabObjectIndex.m_listObject.GetItemText(i, 3);			//��������
			if (strName4.CompareNoCase(_T("primarykey")) == 0)
			{
				strName4 = _T("primary key ");
			}
			else if (strName4.CompareNoCase(_T("unique")) == 0)
			{
				strName4 = _T("unique ");
			}
			else //if (strName4.CompareNoCase(_T("common")) == 0)
			{
				strName4 = _T("");
			}

			strSql.Format(_T("alter object %s add index %s%s(%s) %s"), m_strObjectName, strName4, strName, strName2, strName3);
			vecAddIndex.push_back(strSql);
		}
	}
	else if (j < nRsRows)		//&& i == nListRows
	{
		//��Щ������ɾ������
		for (; j < nRsRows; j++)
		{
			m_rsIndex->SetCurrentRow(j);
			m_rsIndex->FieldValue(2, lpwValue);
			strSql.Format(_T("alter object %s drop index %s"), m_strObjectName, lpwValue);
			vecDeleteIndex.push_back(strSql);
		}
	}

	//�����ȷ��һ��
	if (i == nListRows && j == nRsRows)
	{
		//��ɾ����������
		nVectorSize = vecDeleteIndex.size();
		for (int v = 0; v < nVectorSize; v++)
		{
			if (!ExecuteSql(vecDeleteIndex[v], TRUE, bShowSql))
			{
				goto EditCommonObject_RollBack;
			}
		}

		nVectorSize = vecAddIndex.size();
		for (int v = 0; v < nVectorSize; v++)
		{
			if (!ExecuteSql(vecAddIndex[v], TRUE, bShowSql))
			{
				goto EditCommonObject_RollBack;
			}
		}
	} 
	else
	{
		goto EditCommonObject_RollBack;
	}

	vecAddIndex.clear();
	vecDeleteIndex.clear();
	return TRUE;
	
EditCommonObject_RollBack:
	vecAddIndex.clear();
	vecDeleteIndex.clear();
	return FALSE;
}

BOOL CMainTabObject::FieldRowCompare(int nListIndex, int nRsIndex)
{
	wchar_t *lpwValue1, *lpwValue2, *lpwValue3, *lpwValue4;
	m_rsField->SetCurrentRow(nRsIndex);
	m_rsField->FieldValue(1, lpwValue1);
	m_rsField->FieldValue(2, lpwValue2);
	m_rsField->FieldValue(3, lpwValue3);
	m_rsField->FieldValue(4, lpwValue4);
	if ( m_dlgMainTabObjectField.m_listObject.GetItemText(nListIndex, 1).CompareNoCase(lpwValue1) == 0 
		&& m_dlgMainTabObjectField.m_listObject.GetItemText(nListIndex, 2).CompareNoCase(lpwValue2) == 0
		&& m_dlgMainTabObjectField.m_listObject.GetItemText(nListIndex, 3).CompareNoCase(lpwValue3) == 0
		&& m_dlgMainTabObjectField.m_listObject.GetItemText(nListIndex, 4).CompareNoCase(lpwValue4) == 0)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

void CMainTabObject::DisableDialog(CString strError)
{
	m_tabObject.EnableWindow(FALSE);
	m_btnAddItem.EnableWindow(FALSE);
	m_btnDeleteItem.EnableWindow(FALSE);
	m_cbDataFile.EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_OBJECT_NAME)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_OBJECT_SAVE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_OBJECT_SHOWSQL)->EnableWindow(FALSE);

	m_editObjectResult.SetWindowText(strError);
}

//////////////////////////////////////////////////////////////////////////

void CMainTabObject::OnTcnSelchangeTabObject(NMHDR *pNMHDR, LRESULT *pResult)
{
	int nCurSel = m_tabObject.GetCurSel();
	TabObjectChange(nCurSel);

	*pResult = 0;
}

void CMainTabObject::OnBnClickedBtnObjectAddItem()
{
	int nCurSel = m_tabObject.GetCurSel();
	CString strText;
	switch (nCurSel)
	{
	case 0:
		if (m_bExistedObject)
		{
			m_nFieldMaxId++;
			strText.Format(_T("%d"), m_nFieldMaxId);
			m_dlgMainTabObjectField.AddItem(strText);
		} 
		else
		{
			m_dlgMainTabObjectField.AddItem(_T("."));
		}
		break;
	case 1:
		if (m_bExistedObject)
		{
			m_nIndexMaxId++;
			strText.Format(_T("%d"), m_nIndexMaxId);
			m_dlgMainTabObjectIndex.AddItem(strText);
		} 
		else
		{
			m_dlgMainTabObjectIndex.AddItem(_T("."));
		}
		break;
	default:
		break;
	}
}

void CMainTabObject::OnBnClickedBtnObjectDeleteItem()
{
	int nCurSel = m_tabObject.GetCurSel();
	switch (nCurSel)
	{
	case 0:
		m_dlgMainTabObjectField.DeleteItem();
		break;
	case 1:
		m_dlgMainTabObjectIndex.DeleteItem();
		break;
	default:
		break;
	}
}

void CMainTabObject::OnBnClickedBtnObjectSave()
{
	UpdateData(TRUE);

	if (CheckInput())
	{
		if (m_bExistedObject)
		{
			EditCommonObject();
			OpenExistedObject(m_strObjectName);
		} 
		else
		{
			if (CreateCommonObject())
			{
				OpenExistedObject(m_strObjectName);
			}
		}	
	}

	CSobeyMemToolDlg *pParent;
	pParent = (CSobeyMemToolDlg*)GetParent()->GetParent();
	pParent->OnBnClickedBtnRefresh();
}

void CMainTabObject::OnBnClickedBtnObjectShowsql()
{
	UpdateData(TRUE);

	if (CheckInput())
	{
		if (m_bExistedObject)
		{
			EditCommonObject(TRUE);
		}
		else
		{
			CreateCommonObject(TRUE);
		}
	}
}

void CMainTabObject::OnCancel()
{
	//CDialog::OnCancel();
}

void CMainTabObject::OnOK()
{
	//CDialog::OnOK();
}

void CMainTabObject::OnSize(UINT nType, int cx, int cy)
{
	CRect rtCtrl, rtClient;
	CDialog::OnSize(nType, cx, cy);

	//�ƶ������ڴ�С
	GetClientRect(rtClient);
	m_editObjectResult.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.right = rtClient.right;
	m_editObjectResult.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
	m_tabObject.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.right = rtClient.right;
	rtCtrl.bottom = rtClient.bottom;
	m_tabObject.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);

	rtCtrl.top += 22; 
	rtCtrl.bottom -= 2; 
	rtCtrl.left += 2; 
	rtCtrl.right -= 2;

	m_dlgMainTabObjectField.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
	m_dlgMainTabObjectIndex.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
}
