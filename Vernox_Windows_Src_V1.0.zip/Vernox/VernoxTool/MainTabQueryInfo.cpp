/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MainTabQueryInfo.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SobeyMemTool.h"
#include "MainTabQueryInfo.h"


// CMainTabQueryInfo �Ի���

IMPLEMENT_DYNAMIC(CMainTabQueryInfo, CDialog)

CMainTabQueryInfo::CMainTabQueryInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CMainTabQueryInfo::IDD, pParent)
{

}

CMainTabQueryInfo::~CMainTabQueryInfo()
{
}

void CMainTabQueryInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_RESULT_INFO, m_editText);
}


BEGIN_MESSAGE_MAP(CMainTabQueryInfo, CDialog)
	ON_WM_SIZE()
END_MESSAGE_MAP()


// CMainTabQueryInfo ��Ϣ��������

void CMainTabQueryInfo::TextShow(CString strText)
{
	m_editText.SetWindowText(strText);
}

void CMainTabQueryInfo::OnSize(UINT nType, int cx, int cy)
{
	CRect rtCtrl, rtClient;
	CDialog::OnSize(nType, cx, cy);

	//�ƶ������ڴ�С
	GetClientRect(rtClient);
	m_editText.GetWindowRect(rtCtrl);
	ScreenToClient(rtCtrl);
	rtCtrl.right = rtClient.right - 2;
	rtCtrl.bottom = rtClient.bottom - 2;
	m_editText.SetWindowPos(NULL, 0, 0, rtCtrl.Width(), rtCtrl.Height(), SWP_NOMOVE | SWP_NOZORDER);
}

void CMainTabQueryInfo::OnCancel()
{
	//CDialog::OnCancel();
}

void CMainTabQueryInfo::OnOK()
{
	//CDialog::OnOK();
}
