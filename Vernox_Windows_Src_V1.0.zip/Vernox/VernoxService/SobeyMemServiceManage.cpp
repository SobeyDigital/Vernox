﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "SobeyMemServiceManage.h"
#include "../VernoxServiceLib/SystemManage.h"
#include "ReadRedoLog.h"
#include "../VernoxServiceLib/MapSimple.h"
//////////////////////////////////////////////////////////////////////////////////////////////
//								日志定义													//
//																							//
//     日志等级请参见MF_TRACE_LEVEL系列的宏定义，日志错误码建议每条日志都独立一个编码，按此 //
//思路，对于每个函数都会有一个错误码的范围。文件占3位，函数占3位，函数内编码占3位			//
//     此文件的日志错误码定义为301000000～301999000，请按照函数的先后顺序合理申请错误码，当 //
//前使用最大的错误码为：																	//
//																							//
//																				  吴春中	//
//																				  2015-3-11 //
//////////////////////////////////////////////////////////////////////////////////////////////
extern long   						g_lConnectNum;
extern BOOL	  						g_bWriteEfficiencyTrace;
extern int	  						g_nServerParallelMode;
extern CSobeyMemServiceManage*		g_pSobeyMemServiceManage;

#ifdef WIN32
extern CRITICAL_SECTION				g_CritServerParallel;
#else
extern pthread_mutex_t				g_CritServerParallel;
#endif

CSobeyMemServiceManage::CSobeyMemServiceManage(void)
{
	m_pContainerManage = NULL;
	m_pFileBuffer  = NULL;
	memset(m_arrayConfigPath, 0, sizeof(m_arrayConfigPath));
	memset(m_arrayDatabasePath, 0, sizeof(m_arrayDatabasePath));
}

CSobeyMemServiceManage::~CSobeyMemServiceManage(void)
{
	Uninitialize();
}

int CSobeyMemServiceManage::Initialize()
{
	int nRet;
	char lpRedoDir[MAX_PATH], lpBackupRedoFile[MAX_PATH];
	//初始化系统环境，如果失败的话服务就停止
	m_pContainerManage = new CContainerManage;
	nRet = m_pContainerManage->Initialize();
	if(nRet != MF_OK)
	{
		delete m_pContainerManage;
		m_pContainerManage = NULL;
		return nRet;
	}

	//初始化拼音表
	InitPinYinTable();

	//获取配置文件路径
	memset(lpRedoDir, 0, sizeof(lpRedoDir));
	memset(lpBackupRedoFile, 0, sizeof(lpBackupRedoFile));
	GetModuleFileName(NULL, m_arrayConfigPath, MAX_PATH);
#ifdef WIN32	
	(strrchr(m_arrayConfigPath, '\\'))[1] = 0;
	strcat_s(m_arrayConfigPath, MAX_PATH, _T("VernoxConfig.ini"));
#else
	(strrchr(m_arrayConfigPath, '/'))[1] = 0;
	strcat(m_arrayConfigPath, _T("VernoxConfig.ini"));
#endif

#ifdef WIN32
	GetPrivateProfileString("System", "databasepath", "c:\\Vernox\\Data\\Vernox\\", m_arrayDatabasePath, MAX_PATH, m_arrayConfigPath);
	sprintf(lpRedoDir, "%sRedo\\", m_arrayDatabasePath);
#else
	GetPrivateProfileString("System", "databasepath", "/Vernox/Data/Vernox/", m_arrayDatabasePath, MAX_PATH, m_arrayConfigPath);
	sprintf(lpRedoDir, "%sRedo/", m_arrayDatabasePath);
#endif
	CReadRedoLog::SetRedoDir(lpRedoDir);
	sprintf(lpBackupRedoFile, "%sBackupRedo.log", lpRedoDir);
	CSystemManage::instance().InitBackupRedo(lpBackupRedoFile);

	return MF_OK;
}

int CSobeyMemServiceManage::Uninitialize()
{
	if(m_pContainerManage != NULL)
	{
		m_pContainerManage->Uninitialize();
		delete m_pContainerManage;
		m_pContainerManage = NULL;
	}
	
	if(m_pFileBuffer != NULL)
	{
		delete [] m_pFileBuffer;
		m_pFileBuffer = NULL;
	}
	return 0;
}

void CSobeyMemServiceManage::ConvertExecuteStatistics(char *lpszStatistics,const EXECUTESTATISTICSINFO &stExecuteInfo)
{
	MF_EXECUTESTATISTICSINFO stExecuteStatistics;
	memset(&stExecuteStatistics, 0, sizeof(stExecuteStatistics));
	stExecuteStatistics.m_ftStartTime					= stExecuteInfo.m_ftStartTime;
	stExecuteStatistics.m_ftEndTime						= stExecuteInfo.m_ftEndTime;
	stExecuteStatistics.m_liStart.QuadPart				= stExecuteInfo.m_liStart.QuadPart;
	stExecuteStatistics.m_liFrequence.QuadPart			= stExecuteInfo.m_liFrequence.QuadPart;
	stExecuteStatistics.m_liParsePlanStart.QuadPart		= stExecuteInfo.m_liParsePlanStart.QuadPart;
	stExecuteStatistics.m_liPretreatmentStart.QuadPart	= stExecuteInfo.m_liPretreatmentStart.QuadPart;
	stExecuteStatistics.m_liExecuteStart.QuadPart		= stExecuteInfo.m_liExecuteStart.QuadPart;
	stExecuteStatistics.m_liIndexSearchEnd.QuadPart		= stExecuteInfo.m_liIndexSearchEnd.QuadPart;
	stExecuteStatistics.m_liExecuteEnd.QuadPart			= stExecuteInfo.m_liExecuteEnd.QuadPart;
	stExecuteStatistics.m_liWriteLogEnd.QuadPart		= stExecuteInfo.m_liWriteLogEnd.QuadPart;
	stExecuteStatistics.m_liEnd.QuadPart				= stExecuteInfo.m_liEnd.QuadPart;
	stExecuteStatistics.m_lWorkLoad						= stExecuteInfo.m_lWorkLoad;
	QueryPerformanceCounter(&stExecuteStatistics.m_liEnd);
	HexConvertChar((LPBYTE)&stExecuteStatistics, sizeof(stExecuteStatistics), lpszStatistics);
}

int CSobeyMemServiceManage::GetRecordNum(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, int& nRecordNum, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	return m_pContainerManage->GetReocrdNum(stBson, stExecutePlanManager, nRecordNum, lpExecuteInfo);
}
int	CSobeyMemServiceManage::ExportObject(CServiceBson& stBson, char* pObjectName, LPEXPORTPARAM lpExportParam,long long nTimestamp)
{
	if(m_pContainerManage == NULL)
	{
		//系统没初始化起来
		return MF_INNER_SYS_UNINITIALIZE_FAILED;
	}
	else
	{
		lpExportParam->m_nRecordNum = 0;
		return m_pContainerManage->ExportObject(stBson, pObjectName, lpExportParam, nTimestamp);
	}
	return 0;
}

int	CSobeyMemServiceManage::ImportObject(CServiceBson& stBson, char* pObjectName, LPIMPORTPARAM lpImportParam, long long nTimestamp)
{
	if(m_pContainerManage == NULL)
	{
		//系统没初始化起来
		return MF_INNER_SYS_UNINITIALIZE_FAILED;
	}
	else
	{
		return m_pContainerManage->ImportObject(stBson, pObjectName, lpImportParam, nTimestamp);
	}
	return 0;
}

int CSobeyMemServiceManage::GetDatabaseGuid(USHORT & usGuid)
{
	usGuid = CSystemManage::instance().GetDatabaseGuid();
	return MF_OK;
}

int CSobeyMemServiceManage::GetObjectDataNum(char* pObjectName, int& nDataNum)
{
	int nRet;
	LPOBJECTDEF lpObjectInfo;

	nRet = CSystemManage::instance().GetObjectInfo(pObjectName, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	nDataNum = *lpObjectInfo->m_pDataNum;
	return MF_OK;
}

int	CSobeyMemServiceManage::RecoverByRedo()
{
	int nRet;
	BOOL bNeed;
	long long llTimestampFinish;

	bNeed = FALSE;
	nRet = MF_OK;
	llTimestampFinish = CSystemManage::instance().GetLastTimestamp();
	if (llTimestampFinish != 0)
	{
		LPBYTE lpBuffer;
		LONGLONG llTimestamp;
		int nBufferSize, nDataLen, lAffectCount;
		REDOPROCESS stRedoProcess;
		CServiceBson cServiceBson;
		LPEXECUTEPLANBSON lpExecutePlan;
		EXECUTESTATISTICSINFO stExecuteInfo;

		nBufferSize = 2*1024*1024;
		lpBuffer = new BYTE[nBufferSize];
		if (lpBuffer == NULL)
		{
			nRet = MF_FAILED;
			goto RecoverByRedo_Fail;
		}

		llTimestamp = 0;

#ifdef WIN32
		stRedoProcess.m_hFile = INVALID_HANDLE_VALUE;
#else
		stRedoProcess.m_hFile = NULL;
#endif

		if (!CReadRedoLog::InitRedoProcess(&stRedoProcess))
		{
			nRet = MF_REDO_INIT_FAILED;
			goto RecoverByRedo_Fail;
		}

		nRet = CReadRedoLog::SetRedoPointer(&stRedoProcess, lpBuffer, nBufferSize, llTimestampFinish);
		if (nRet != MF_OK)
		{
			if (nRet == MF_REDO_NO_REDO_FILE)
			{
				goto RecoverByRedo_Success;
			}
			else
			{
				goto RecoverByRedo_Fail;
			}
		}
		llTimestamp = llTimestampFinish;

		//读出执行计划
		while(TRUE)
		{
			//检查是否存在更新
			nRet = CReadRedoLog::CheckRedoUpdate(&stRedoProcess);
			if (nRet == MF_CLUSTER_NEW_REDO)
			{
				//打开下一个重作日志
				bNeed = TRUE;
			} 
			else if (nRet == MF_CLUSTER_NO_NEW_REDO)
			{
				//没有新的更新
				//所有重作日志的计划执行完成

				//不需要再检查是否有正在写入的重作日志
				//直接进入下一阶段
				break;
			} 
			else
			{
				//出现错误
				goto RecoverByRedo_Fail;
			}

			//读取所有新的执行计划
			while(TRUE)
			{
				nRet = CReadRedoLog::ReadRedoLog(&stRedoProcess, lpBuffer, nBufferSize, nDataLen);
				if (nRet == MF_CLUSTER_READ_REDO_SUCCEED)
				{
					;
				} 
				else if (nRet == MF_CLUSTER_CURRENT_REDO_FINISH)
				{
					//当前重作日志文件已执行完
					//检查是否有新的更新
					break;
				} 
				else if (nRet == MF_CLUSTER_REDO_LACK_OF_BUFFER)
				{
					//分配新的buffer，重新读取
					if (lpBuffer != NULL)
					{
						delete[] lpBuffer;
						lpBuffer = NULL;
					}
					nBufferSize = nDataLen;
					lpBuffer = new BYTE[nBufferSize];
					if (lpBuffer == NULL)
					{
						nRet = MF_FAILED;
						goto RecoverByRedo_Fail;
					}

					continue;
				} 
				else
				{
					//出现错误
					goto RecoverByRedo_Fail;
				}


				if (nDataLen == 0)
				{
					continue;
				}
				//执行计划
				lpExecutePlan = (LPEXECUTEPLANBSON)lpBuffer;
				lpExecutePlan->m_nCritPos = 0;
				lpExecutePlan->m_bWriteLog = 0;
				memset(lpExecutePlan->m_pCritStack, 0, 20*sizeof(long long));
				memset(&stExecuteInfo, 0, sizeof(stExecuteInfo));
				cServiceBson.Initial(lpBuffer, nBufferSize);
				nRet = SystemRecover(cServiceBson, lAffectCount, &stExecuteInfo);
				if (nRet != MF_OK)
				{
					goto RecoverByRedo_Fail;
				}
			}
		}



RecoverByRedo_Success:
		CReadRedoLog::ReleaseRedoProcess(&stRedoProcess);
		if (lpBuffer != NULL)
		{
			delete[] lpBuffer;
			lpBuffer = NULL;
		}
		if (bNeed)
		{
			Trace(_T("RecoverByRedo"), 0, 301000001, _T("通过重作日志恢复数据完成！"));
		}
		return MF_OK;
RecoverByRedo_Fail:
		CReadRedoLog::ReleaseRedoProcess(&stRedoProcess);
		if (lpBuffer != NULL)
		{
			delete[] lpBuffer;
			lpBuffer = NULL;
		}
		Trace(_T("RecoverByRedo"), 0, 301000002, _T("通过重作日志恢复数据失败，将停止服务，错误码：%d！"), nRet);
		return nRet;
	}
	return nRet;
}

int CSobeyMemServiceManage::TCPExecuteCommand(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(g_nServerParallelMode == 0)
	{		
		nRet = ExecuteCommand(stBson, stExecutePlanManager, lAffectCount, lpExecuteInfo);
	}
	else //if(g_nServerParallelMode == 1)
	{
		CCriticalSectionPtr cs(&g_CritServerParallel);
		nRet = ExecuteCommand(stBson, stExecutePlanManager, lAffectCount, lpExecuteInfo);
	}
	if(nRet != MF_OK)
	{
		WriteTraceLog(_T("ExecuteCommand"), MF_TRACE_LEVEL_WARNING, 301004001, lpExecutePlan, lpExecuteInfo, nRet);
	}

	if(MF_OK != m_pContainerManage->ResourceRelease(stBson, nRet))
	{
		return MF_INNER_SYS_SOURCERELEASE_ERROR;
	}
	return nRet;
}

int CSobeyMemServiceManage::TCPGetRecordset(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(g_nServerParallelMode == 0)
	{		
		nRet = GetRecordset(stBson, stExecutePlanManager, lpBsonRs, nBsonRsSize, lpExecuteInfo);
	}
	else //if(g_nServerParallelMode == 1)
	{
		CCriticalSectionPtr cs(&g_CritServerParallel);
		nRet = GetRecordset(stBson, stExecutePlanManager, lpBsonRs, nBsonRsSize, lpExecuteInfo);
	}
	if(nRet != MF_OK)
	{
		WriteTraceLog(_T("GetRecordset"), MF_TRACE_LEVEL_WARNING, 301005001, lpExecutePlan, lpExecuteInfo, nRet);
	}
	return nRet;
}

int CSobeyMemServiceManage::TCPUpdateRecordset(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(g_nServerParallelMode == 0)
	{		
		nRet = UpdateRecordset(stBson, stExecutePlanManager, lpExecuteInfo);
	}
	else //if(g_nServerParallelMode == 1)
	{
		CCriticalSectionPtr cs(&g_CritServerParallel);
		nRet = UpdateRecordset(stBson, stExecutePlanManager, lpExecuteInfo);
	}
	if(nRet != MF_OK)
	{
		WriteTraceLog(_T("UpdateRecordset"), MF_TRACE_LEVEL_WARNING, 301006001, lpExecutePlan, lpExecuteInfo, nRet);
	}

	if(MF_OK != m_pContainerManage->ResourceRelease(stBson, nRet))
	{
		return MF_INNER_SYS_SOURCERELEASE_ERROR;
	}
	return nRet;
}

void CSobeyMemServiceManage::SetExecuteStatistics(CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	LPEXECUTEPLANBSON lpExecutePlan;
	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	GetSystemTimeAsFileTime(&lpExecuteInfo->m_ftEndTime);
	QueryPerformanceCounter(&lpExecuteInfo->m_liEnd);
	SetExecuteStatistics(lpExecutePlan, lpExecuteInfo);

	if(g_bWriteEfficiencyTrace)
	{
		WriteTraceLog(_T("SetExecuteStatistics"), MF_TRACE_LEVEL_INNER_DEBUG, 301005002, lpExecutePlan, lpExecuteInfo, MF_OK);
	}
	else if(lpExecuteInfo->m_dwTime > 5000000)
	{
		//处理超过5秒钟的，一定要记录下来
		WriteTraceLog(_T("SetExecuteStatistics"), MF_TRACE_LEVEL_WARNING, 301005003, lpExecutePlan, lpExecuteInfo, MF_OK);
	}
}

//执行命令，返回值应该只有错误信息
int CSobeyMemServiceManage::ExecuteCommand(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet, nError;
	LPEXECUTEPLANBSON lpExecutePlan;

	nError = MF_OK;
	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(m_pContainerManage == NULL)
	{
		//系统没初始化起来
		return MF_INNER_SYS_UNINITIALIZE_FAILED;
	}
	else
	{
		//解析执行计划
		long long nTimestamp;
		CSystemTimestampTransactionManage stTransaction;

		//未启用集群功能
		QueryPerformanceCounter(&lpExecuteInfo->m_liParsePlanStart);
		nRet = stExecutePlanManager.AnalysisExecutePlan();
		if(nRet != MF_OK)
		{
			return nRet;
		}
		QueryPerformanceCounter(&lpExecuteInfo->m_liPretreatmentStart);
		//时间戳申请
		nTimestamp = GetSystemTimestamp();

		//开启事务
		stTransaction.StartTransaction(nTimestamp);
		lpExecutePlan->m_nTimestamp = nTimestamp;

		//预处理执行计划
		nRet = g_pSobeyMemServiceManage->Preprocess(stBson, stExecutePlanManager, lpExecuteInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		nRet = m_pContainerManage->ExecuteCommand(stBson, stExecutePlanManager, lAffectCount, lpExecuteInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return 0;
}

void CSobeyMemServiceManage::ResourceAndLockRelease(LPEXECUTEPLANBSON lpExecutePlan, int nRetValue)
{
	CServiceBson stBson;
	int nBufferCacheSize;

	nBufferCacheSize = (lpExecutePlan->m_nTotalDataSize / MF_BUFFERSECTION_SIZE + 1) * MF_BUFFERSECTION_SIZE + MF_BUFFERSECTION_SIZE + MF_TEMPBUFFER_SIZE + MF_RECYCLESECTION_SIZE + MF_RECORDBUFFER_SIZE;		//缓存总大小
	stBson.Initial((LPBYTE)lpExecutePlan, nBufferCacheSize);
	m_pContainerManage->CriticalRelease(stBson);
	m_pContainerManage->ResourceRelease(stBson, nRetValue);
}

int CSobeyMemServiceManage::GetRecordset(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(m_pContainerManage == NULL)
	{
		//系统没初始化起来
		return MF_INNER_SYS_UNINITIALIZE_FAILED;
	}
	else
	{
		//解析执行计划
		if(lpExecutePlan->m_bDBType == MF_DATABASE_MEMDB)
		{
			QueryPerformanceCounter(&lpExecuteInfo->m_liParsePlanStart);
			nRet = stExecutePlanManager.AnalysisExecutePlan();
			QueryPerformanceCounter(&lpExecuteInfo->m_liPretreatmentStart);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		
		//获取时间戳
		lpExecutePlan->m_nTimestamp = GetSystemTimestamp();
		return m_pContainerManage->GetRecordset(stBson, stExecutePlanManager, lpBsonRs, nBsonRsSize, lpExecuteInfo);
	}
	return 0;
}
int CSobeyMemServiceManage::UpdateRecordset(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{

	CServiceBson stBakBson;
	int nRet, nError;
	LPEXECUTEPLANBSON lpExecutePlan;

	nError = MF_OK;
	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	if(m_pContainerManage == NULL)
	{
		//系统没初始化起来
		return MF_INNER_SYS_UNINITIALIZE_FAILED;
	}
	else
	{
		long long nTimestamp;
		CSystemTimestampTransactionManage stTransaction;
		//未启用集群功能
		QueryPerformanceCounter(&lpExecuteInfo->m_liParsePlanStart);
		nRet = stExecutePlanManager.AnalysisExecutePlan();
		if(nRet != MF_OK)
		{
			return nRet;
		}
		QueryPerformanceCounter(&lpExecuteInfo->m_liPretreatmentStart);
		//时间戳申请
		nTimestamp = GetSystemTimestamp();

		//开启事务
		stTransaction.StartTransaction(nTimestamp);
		lpExecutePlan->m_nTimestamp = nTimestamp;

		//预处理执行计划
		nRet = g_pSobeyMemServiceManage->Preprocess(stBson, stExecutePlanManager, lpExecuteInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		nRet = m_pContainerManage->UpdateRecordset(stBson, stExecutePlanManager, lpExecuteInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return 0;
}

int CSobeyMemServiceManage::WriteTraceLog(LPCTSTR szFuncationName, LONG lLogLevel, LONG lLogErrorCode, LPEXECUTEPLANBSON lpExecutePlan, LPEXECUTESTATISTICSINFO lpExecuteInfo, int nRet)
{
	//统一写日志，所有项包括SQL语句在日志中最多只写4KB。
	int nLen;
	char * lpszTemp;
	char lpszText[4096];
	CMFString strSql, strIP;

	nLen = min(4094, lpExecutePlan->m_nSqlLen);
	memset(lpszText, 0, 4096);
	memcpy(lpszText, ((char *)lpExecutePlan) + lpExecutePlan->m_nSqlOffset, nLen);
	lpszTemp = UTF8ConvertAnsi(lpszText);
	if(lpszTemp == NULL)
	{
		return MF_FAILED;
	}
	strSql = lpszTemp;
	delete [] lpszTemp;

	strIP.Format(_T("%d.%d.%d.%d"), FIRST_IPADDRESS(lpExecutePlan->m_dwClientIP), SECOND_IPADDRESS(lpExecutePlan->m_dwClientIP), THIRD_IPADDRESS(lpExecutePlan->m_dwClientIP), FOURTH_IPADDRESS(lpExecutePlan->m_dwClientIP));
	Trace(szFuncationName, lLogLevel, lLogErrorCode, _T("执行时间：%d微秒，IP[%s]，执行结果：%d，SQL[%s]！"), lpExecuteInfo->m_dwTime, strIP.c_str(), nRet, strSql.c_str());
	return MF_OK;
}

int CSobeyMemServiceManage::SetExecuteStatistics(LPEXECUTEPLANBSON lpExecutePlan, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	if(m_pContainerManage != NULL)
	{
		return m_pContainerManage->SetExecuteStatistics(lpExecutePlan, lpExecuteInfo);
	}
	return 0;
}

void CSobeyMemServiceManage::SetSessionInfo(LPSESSIONINFO lpSessionInfo, BOOL bSaop)
{
	if(m_pContainerManage != NULL)
	{
		m_pContainerManage->SetSessionInfo(lpSessionInfo, bSaop);
	}
}

void CSobeyMemServiceManage::RemoveSessionInfo(LPSESSIONINFO &lpSessionInfo, BOOL bSaop)
{
	if(m_pContainerManage != NULL)
	{
		m_pContainerManage->RemoveSessionInfo(lpSessionInfo, bSaop);
	}
}

int CSobeyMemServiceManage::TCPStartTransactionLogic(DWORD dwIP, char * lpszTransactionData, int &lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	QueryPerformanceFrequency(&lpExecuteInfo->m_liFrequence);
	QueryPerformanceCounter(&lpExecuteInfo->m_liStart);
	GetSystemTimeAsFileTime(&lpExecuteInfo->m_ftStartTime);
	nRet = StartTransactionLogic(dwIP, lpszTransactionData, lTransactionID, lpExecuteInfo);
	GetSystemTimeAsFileTime(&lpExecuteInfo->m_ftEndTime);
	QueryPerformanceCounter(&lpExecuteInfo->m_liEnd); 
	lpExecuteInfo->m_dwTime = (DWORD)(1000000 * (lpExecuteInfo->m_liEnd.QuadPart - lpExecuteInfo->m_liStart.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart ); //换算到微秒数
	if(nRet != MF_OK)
	{
		Trace(_T("TCPStartTransactionLogic"), MF_TRACE_LEVEL_WARNING, 301010001, _T("执行时间：%d微秒，IP[%d.%d.%d.%d]，TransactionID：%d，TransactionData[%s]！"), lpExecuteInfo->m_dwTime, FIRST_IPADDRESS(dwIP), SECOND_IPADDRESS(dwIP), THIRD_IPADDRESS(dwIP), FOURTH_IPADDRESS(dwIP), lTransactionID, lpszTransactionData);
	}
	else if(g_bWriteEfficiencyTrace)
	{
		Trace(_T("TCPStartTransactionLogic"), MF_TRACE_LEVEL_INNER_DEBUG, 301010002, _T("执行时间：%d微秒，IP[%d.%d.%d.%d]，TransactionID：%d，TransactionData[%s]！"), lpExecuteInfo->m_dwTime, FIRST_IPADDRESS(dwIP), SECOND_IPADDRESS(dwIP), THIRD_IPADDRESS(dwIP), FOURTH_IPADDRESS(dwIP), lTransactionID, lpszTransactionData);
	}
	else if(lpExecuteInfo->m_dwTime > 5000000)
	{
		//处理超过5秒钟的，一定要记录下来
		Trace(_T("TCPStartTransactionLogic"), MF_TRACE_LEVEL_WARNING, 301010003, _T("执行时间：%d微秒，IP[%d.%d.%d.%d]，TransactionID：%d，TransactionData[%s]！"), lpExecuteInfo->m_dwTime, FIRST_IPADDRESS(dwIP), SECOND_IPADDRESS(dwIP), THIRD_IPADDRESS(dwIP), FOURTH_IPADDRESS(dwIP), lTransactionID, lpszTransactionData);
	}

	return nRet;
}

int CSobeyMemServiceManage::TCPStopTransactionLogic(DWORD dwIP, int lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	QueryPerformanceFrequency(&lpExecuteInfo->m_liFrequence);
	QueryPerformanceCounter(&lpExecuteInfo->m_liStart);
	GetSystemTimeAsFileTime(&lpExecuteInfo->m_ftStartTime);
	nRet = StopTransactionLogic(dwIP, lTransactionID, lpExecuteInfo);
	GetSystemTimeAsFileTime(&lpExecuteInfo->m_ftEndTime);
	QueryPerformanceCounter(&lpExecuteInfo->m_liEnd); 
	lpExecuteInfo->m_dwTime = (DWORD)(1000000 * (lpExecuteInfo->m_liEnd.QuadPart - lpExecuteInfo->m_liStart.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart ); //换算到微秒数
	if(nRet != MF_OK)
	{
		Trace(_T("TCPStopTransactionLogic"), MF_TRACE_LEVEL_WARNING, 301011001, _T("执行时间：%d微秒，IP[%d.%d.%d.%d]，TransactionID：%d"), lpExecuteInfo->m_dwTime, FIRST_IPADDRESS(dwIP), SECOND_IPADDRESS(dwIP), THIRD_IPADDRESS(dwIP), FOURTH_IPADDRESS(dwIP), lTransactionID);
	}
	else if(g_bWriteEfficiencyTrace)
	{
		Trace(_T("TCPStopTransactionLogic"), MF_TRACE_LEVEL_INNER_DEBUG, 301011002, _T("执行时间：%d微秒，IP[%d.%d.%d.%d]，TransactionID：%d"), lpExecuteInfo->m_dwTime, FIRST_IPADDRESS(dwIP), SECOND_IPADDRESS(dwIP), THIRD_IPADDRESS(dwIP), FOURTH_IPADDRESS(dwIP), lTransactionID);
	}
	else if(lpExecuteInfo->m_dwTime > 5000000)
	{
		//处理超过5秒钟的，一定要记录下来
		Trace(_T("TCPStopTransactionLogic"), MF_TRACE_LEVEL_WARNING, 301011003, _T("执行时间：%d微秒，IP[%d.%d.%d.%d]，TransactionID：%d"), lpExecuteInfo->m_dwTime, FIRST_IPADDRESS(dwIP), SECOND_IPADDRESS(dwIP), THIRD_IPADDRESS(dwIP), FOURTH_IPADDRESS(dwIP), lTransactionID);
	}

	return nRet;
}

int CSobeyMemServiceManage::TCPGetExecutePlan(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTEPLANINFO lpExecutePlanInfo, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPOBJECTDEF lpObjectInfo;
	LPEXECUTEPLANBSON lpExecutePlan;
	memset(lpExecutePlanInfo, 0 ,sizeof(EXECUTEPLANINFO));
	
	//解析执行计划
	nRet = stExecutePlanManager.AnalysisExecutePlan();
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	lpExecutePlan->m_nTimestamp = GetSystemTimestamp();

	nRet = CSystemManage::instance().GetObjectInfo(lpExecutePlan->m_nObjectID, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlanInfo->m_bObjectType = lpObjectInfo->m_bObjectType;
	memcpy(lpExecutePlanInfo->m_pObjectName, lpObjectInfo->m_lpszName, 32);

	if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_QUERY)
	{
		int nIndexOffset;
		LPINDEXDEF lpIndexInfo;
		LPSTARTINFO lpStartInfo;
		LPRECURSION lpRecursion;
		LPINDEXEXECUTEPLAN lpIndexPlan;
		LPQUERYEXECUTEPLANBSON lpQueryPlan;
		LPCOMMONCONDITION lpCommonCondition;
		
		nIndexOffset = 0;
		lpQueryPlan  = (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
		lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
		if(lpCommonCondition->m_nConnOffset != 0)
		{
			lpRecursion = (LPRECURSION)stBson.ConvertOffset2Addr(lpCommonCondition->m_nConnOffset);
			lpExecutePlanInfo->m_bDrection		 = lpRecursion->m_bDrection;
			lpExecutePlanInfo->m_bRecursionLevel = lpRecursion->m_bLevel;

			lpStartInfo = (LPSTARTINFO)stBson.ConvertOffset2Addr(lpRecursion->m_nStartCondOffset);

			if(lpStartInfo->m_nIndexOffset != 0)
			{
				nIndexOffset = lpStartInfo->m_nIndexOffset;
			}
		}
		if(lpCommonCondition->m_nIndexOffset != 0)
		{
			nIndexOffset = lpCommonCondition->m_nIndexOffset;
		}
		
		if(nIndexOffset != 0)
		{
			lpIndexPlan = (LPINDEXEXECUTEPLAN)stBson.ConvertOffset2Addr(nIndexOffset);
			nRet = CSystemManage::instance().GetIndexInfo(lpIndexPlan->m_nIndexID, lpIndexInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpExecutePlanInfo->m_bIndexType = lpIndexInfo->m_bIndexType;
			memcpy(lpExecutePlanInfo->m_pIndexName, lpIndexInfo->m_lpszName, 32);
		}

		//获取查询结果
		nRet = GetRecordNum(stBson, stExecutePlanManager, lpExecutePlanInfo->m_nRowNumber, lpExecuteInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

//执行命令，返回值应该只有错误信息
int CSobeyMemServiceManage::StartTransactionLogic(DWORD dwIP, const char * lpszTransactionData, int &lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	if(m_pContainerManage == NULL)
	{
		//系统没初始化起来
		return MF_INNER_SYS_UNINITIALIZE_FAILED;
	}
	else
	{
		return m_pContainerManage->StartTransactionLogic(dwIP, lpszTransactionData, lTransactionID, lpExecuteInfo);
	}
	return 0;
}

//执行命令，返回值应该只有错误信息
int CSobeyMemServiceManage::StopTransactionLogic(DWORD dwIP, int lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	if(m_pContainerManage == NULL)
	{
		//系统没初始化起来
		return MF_INNER_SYS_UNINITIALIZE_FAILED;
	}
	else
	{
		return m_pContainerManage->StopTransactionLogic(dwIP, lTransactionID, lpExecuteInfo);
	}
	return 0;
}

#ifdef WIN32
BOOL  CSobeyMemServiceManage::InitPinYinTable()
{
	HRSRC hRsrc;
	ULONG nSize;
	LPBYTE lpBuffer;
	HGLOBAL hGlobal;
	hRsrc = FindResource(NULL, MAKEINTRESOURCE(IDR_BIN_PINGYIN), _T("BIN"));
	if(hRsrc == NULL)
	{
		Trace(_T("InitPinYinTable"), MF_TRACE_LEVEL_FAILED, 301020001, _T("索贝数据服务加载汉字拼音数据失败，错误码：%d"), GetLastError());
		return FALSE;
	}

	nSize = SizeofResource(NULL, hRsrc); 
	hGlobal = LoadResource(NULL, hRsrc);
	if(hGlobal == NULL)
	{
		Trace(_T("InitPinYinTable"), MF_TRACE_LEVEL_FAILED, 301020002, _T("索贝数据服务加载汉字拼音数据失败，错误码：%d"), GetLastError());
		return FALSE;
	}

	lpBuffer = (LPBYTE)LockResource(hGlobal);
	if(lpBuffer == NULL)
	{
		Trace(_T("InitPinYinTable"), MF_TRACE_LEVEL_FAILED, 301020003, _T("索贝数据服务加载汉字拼音数据失败，错误码：%d"), GetLastError());
		return FALSE;
	}

	if(m_pContainerManage != NULL)
	{
		m_pContainerManage->InitCharCompare(lpBuffer, nSize);
	}
	else
	{
		Trace(_T("InitPinYinTable"), MF_TRACE_LEVEL_FAILED, 301020004, _T("加载拼音表时，发现m_pContainerManage指针为空"));
	}

	UnlockResource(hGlobal);
	FreeResource(hGlobal);
	return TRUE;
}
#else

BOOL  CSobeyMemServiceManage::InitPinYinTable()
{
	FILE* pFile;
	int nFileSize;
	TCHAR lpFilePath[256];

	memset(lpFilePath, 0, 256 * sizeof(TCHAR));
	GetModuleFileName(NULL, lpFilePath, 256);
	(strrchr(lpFilePath, '/'))[0] = 0;
	strcat(lpFilePath, "/PingYinTable.dat");
	pFile = fopen(lpFilePath, "rb");
	if(pFile == NULL)
	{
		Trace(_T("InitPinYinTable"), MF_TRACE_LEVEL_FAILED, 301020001, _T("打开拼音文件失败，错误码：%d，文件路径：%s"), GetLastError(), lpFilePath);
		return FALSE;
	}

	nFileSize = GetFileSize(pFile);
	m_pFileBuffer = new BYTE[nFileSize];
	memset(m_pFileBuffer, 0, nFileSize);
	fread(m_pFileBuffer, 1, nFileSize, pFile);
	if(ferror(pFile))
	{
		Trace(_T("InitPinYinTable"), MF_TRACE_LEVEL_FAILED, 301020002, _T("读取拼音文件失败，错误码：%d"), GetLastError());
		return FALSE;
	}
	if(m_pContainerManage != NULL)
	{
		m_pContainerManage->InitCharCompare(m_pFileBuffer, nFileSize);
	}
	else
	{
		Trace(_T("InitPinYinTable"), MF_TRACE_LEVEL_FAILED, 301020003, _T("读取拼音文件时，发现m_pContainerManage指针为空"));
	}
	return TRUE;
}

#endif

int CSobeyMemServiceManage::SystemRecover(CServiceBson& stBson, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nRet;
	LPOBJECTDEF lpObjectInfo;
	LPEXECUTEPLANBSON lpExecutePlan;
	if(m_pContainerManage == NULL)
	{
		//系统没初始化起来
		return MF_INNER_SYS_UNINITIALIZE_FAILED;
	}
	else
	{
		lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
		nRet = CSystemManage::instance().GetObjectInfo(lpExecutePlan->m_nObjectID, lpObjectInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		stBson.SetObjectInfo(lpObjectInfo);

		nRet = m_pContainerManage->Recover(stBson, lAffectCount, lpExecuteInfo);
		if (nRet == MF_OK)
		{
			return m_pContainerManage->ResourceRelease(stBson, 0);
		}
		else
		{
			m_pContainerManage->ResourceRelease(stBson, nRet);
			return nRet;
		}	
	}
	return MF_OK;
}

int CSobeyMemServiceManage::Preprocess(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	if(m_pContainerManage == NULL)
	{
		//系统没初始化起来
		return MF_INNER_SYS_UNINITIALIZE_FAILED;
	}
	else
	{
		if(g_nServerParallelMode == 0)
		{
			return m_pContainerManage->Preprocess(stBson, stExecutePlanManager, lpExecuteInfo);
		}
		else
		{
			CCriticalSectionPtr cs(&g_CritServerParallel);
			return m_pContainerManage->Preprocess(stBson, stExecutePlanManager, lpExecuteInfo);
		}
	}
	return MF_OK;
}

int CSobeyMemServiceManage::GetUserInfo(char* pUserName, LPUSERINFODEF& lpUserInfo)
{
	return CSystemManage::instance().GetUserInfo(pUserName, lpUserInfo);
}
