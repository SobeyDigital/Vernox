﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define STRICT
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0502
#endif
#define _ATL_APARTMENT_THREADED

//屏蔽C语言警告信息
#define _CRT_SECURE_NO_WARNINGS

#ifdef WIN32
#include <atlbase.h>
#undef _WINDOWS_
#include <afxcoll.h>
#endif

#include "resource.h"

#include <set>
#include <map>
#include <vector>
#include <stack>
#include <queue>

#ifndef WIN32
#include <list>
#include <time.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdarg.h>
#include <pthread.h>
#include <sys/time.h>
#include <semaphore.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <uuid/uuid.h>
#include "../Include/MemDBCommonDef.h"
#include "../VernoxBaseLib/LinuxCommonAPI.h"
#endif

using namespace std;
//You may derive a class from CComModule and use it if you want to override
//something, but do not change the name of _Module

#ifdef WIN32
class CServiceModule : public CComModule
#else
class CServiceModule
#endif
{
public:
	HRESULT RegisterServer(BOOL bRegTypeLib, BOOL bService);
	HRESULT UnregisterServer();
    void Start();
	void ServiceMain(DWORD dwArgc, LPTSTR* lpszArgv);
    void Handler(DWORD dwOpcode);
    void Run();
    BOOL IsInstalled();
    BOOL Install();
    BOOL Uninstall();
	LONG Unlock();
	void LogEvent(LPCTSTR pszFormat, ...);
    void SetServiceStatus(DWORD dwState);
    void SetupAsLocalServer();
#ifdef WIN32
	void Init(_ATL_OBJMAP_ENTRY* p, HINSTANCE h, UINT nServiceNameID, const GUID* plibid = NULL);
#else
	void Init();
#endif

//Implementation
private:
#ifdef WIN32
	static void WINAPI _ServiceMain(DWORD dwArgc, LPTSTR* lpszArgv);
	static void WINAPI _Handler(DWORD dwOpcode);
#endif

// data members
public:
    TCHAR m_szServiceName[256];
	DWORD dwThreadID;
	BOOL m_bService;
	
#ifdef WIN32
	SERVICE_STATUS_HANDLE m_hServiceStatus;
    SERVICE_STATUS m_status;
#endif
};

enum eEventHandles
{
	eStop = 0,
	eSignal = 1,
	eProcess = 1,
	eNewPipe = 1,
	eEventSize
};

extern CServiceModule _Module;
#include <math.h>

#ifdef WIN32
#include <atlcom.h>
#include <afxmt.h>
#include <process.h>
#include <afxtempl.h>
#include <afxdisp.h>
#include <Dbt.h> 
#endif 

class CDataCacheMgr
{
private:
	//内部数据
#ifdef WIN32
	CList<UINT_PTR, UINT_PTR>	m_lsDataPtr;
	CRITICAL_SECTION			m_cs;
#else
	list<UINT_PTR>				m_lsDataPtr;
	pthread_mutex_t				m_cs;
#endif

public:
	CDataCacheMgr(void);
	virtual ~CDataCacheMgr(void);
public:
	//添加一个数据项
	int	AddDataPtr(UINT_PTR lpPtr);
	//获取一个数据项
	UINT_PTR GetDataPtr();
	//获取数据个数
	int GetSize();
};

#ifdef WIN32
#include "comdef.h"
#endif

#include "../Include/SobeyMemServiceExport.h"
#include "../VernoxServiceLib/ExecutePlanManager.h"
#include "../VernoxServiceLib/ServiceBson.h"

#ifdef WIN32
extern int MyExceptionHandler(ULONG ulCode, EXCEPTION_POINTERS* lpExceptionPointer);
#endif


