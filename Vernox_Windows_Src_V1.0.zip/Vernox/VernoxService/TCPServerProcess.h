﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

class CTCPServerProcess
{
protected:
	void ClearSocket();
	BOOL ReceiveBuffer(char *pBuffer, int nSize);
	
	BOOL ExecuteCommand(MF_SERVICE_TCP_COMMAND * pTcpCmd);
	BOOL UpdateRecordset(MF_SERVICE_TCP_COMMAND * pTcpCmd);
	BOOL GetRecordset(MF_SERVICE_TCP_COMMAND * pTcpCmd);

	BOOL GetExecutePlan(MF_SERVICE_TCP_COMMAND * pTcpCmd);

	BOOL StartTransactionLogic(MF_SERVICE_TCP_COMMAND * pTcpCmd);
	BOOL StopTransactionLogic(MF_SERVICE_TCP_COMMAND * pTcpCmd);
	void GetExecuteStatistics(MF_EXECUTESTATISTICSINFO &stExecuteStatistics);

	BOOL ExportObject(MF_SERVICE_TCP_COMMAND * pTcpCmd);
	BOOL ImportObject(MF_SERVICE_TCP_COMMAND * pTcpCmd);
	
	int  GetUserInfo(char* pUserName, LPUSERINFODEF& lpUserInfo);
	BOOL CheckPassword(LPUSERINFODEF lpUserInfo, BYTE* pPassword);

	BOOL UserLogin(MF_SERVICE_TCP_COMMAND * pTcpCmd);
	BOOL UserLogOut(MF_SERVICE_TCP_COMMAND * pTcpCmd);
private:
	LPBYTE m_lpBuffer;
	LPBYTE m_lpAddr;
	SOCKET m_skSocket;
	ULONG  m_ulRemoteIP;
	USHORT m_usPort;
	char   m_strIP[256];
	int    m_nBufferCacheSize;
	int    m_nExecutePlanSize;
	int	   m_nSQLPlanMaxSize;
	int	   m_nRecordsetPlanMaxSize;
	LPEXECUTESTATISTICSINFO m_lpExecuteInfo;
	LPSESSIONINFO			m_lpSessionInfo;
#ifdef WIN32
	HANDLE m_hStopEvent;
#else
	sem_t* m_hStopEvent;
#endif
public:
	CTCPServerProcess(void);
	virtual ~CTCPServerProcess(void);
#ifdef WIN32
	BOOL Run(SOCKET sk, HANDLE hStopEvent, HANDLE hExitProcessEvent, ULONG ulRemoteIP, USHORT usPort);
#else
	BOOL Run(SOCKET sk, sem_t* hStopEvent, sem_t* hExitProcessEvent, ULONG ulRemoteIP, USHORT usPort);
#endif
};
