﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "ReadRedoLog.h"
#include "../VernoxServiceLib/SystemManage.h"

char CReadRedoLog::m_lpFilePath[MAX_PATH] = {0};

void CReadRedoLog::SetRedoDir(char* lpFilePath)
{
	memcpy(m_lpFilePath, lpFilePath, 256);
}

BOOL CReadRedoLog::ReleaseRedoProcess(LPREDOPROCESS pRedoProcess)
{
	if (pRedoProcess->m_hFile != INVALID_HANDLE_VALUE)
	{
	#ifdef WIN32
		CloseHandle(pRedoProcess->m_hFile);
		pRedoProcess->m_hFile = INVALID_HANDLE_VALUE;
	#else
		fclose(pRedoProcess->m_hFile);
		pRedoProcess->m_hFile = NULL;
	#endif
	}
	return TRUE;
}

BOOL CReadRedoLog::InitRedoProcess(LPREDOPROCESS pRedoProcess)
{
	try
	{
	#ifdef WIN32
		if (pRedoProcess->m_hFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(pRedoProcess->m_hFile);
			pRedoProcess->m_hFile = INVALID_HANDLE_VALUE;
		}
	#else
		if (pRedoProcess->m_hFile != NULL)
		{
			fclose(pRedoProcess->m_hFile);
			pRedoProcess->m_hFile = NULL;
		}
	#endif
		pRedoProcess->m_nRedoLogID = 0;
		pRedoProcess->m_dwReadPos = 0;
		pRedoProcess->m_llTimestamp = 0;

		//GetModuleFileName(NULL, pRedoProcess->m_lpRedoDir, 256);
		//(strrchr(pRedoProcess->m_lpRedoDir, '\\'))[1] = 0;
		//strcat_s(pRedoProcess->m_lpRedoDir, 256, _T("Redo\\"));
		memcpy(pRedoProcess->m_lpRedoDir, m_lpFilePath, 256);
	#ifdef WIN32
		_stprintf_s(pRedoProcess->m_lpRedoFilePath, 256, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID);
		_stprintf_s(pRedoProcess->m_lpNextRedoFilePath, 256, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID+1);
	#else
		_stprintf(pRedoProcess->m_lpRedoFilePath, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID);
		_stprintf(pRedoProcess->m_lpNextRedoFilePath, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID+1);
	#endif
	}
	catch (...)
	{
		return FALSE;
	}

	return TRUE;
}

//读出一条执行计划
//		pRedoProcess：	记录已读取的重作日志的位置等信息
//		lpBuffer：		缓存，用于储存读取的数据
//		nBufferSize：	缓存大小
//		nDataLen：		读取的执行计划长度
int CReadRedoLog::ReadRedoLog(LPREDOPROCESS pRedoProcess, LPBYTE lpBuffer, int nBufferSize, int& nDataLen)
{
	int nLen;
	DWORD dwBytesRead, dwSize;
	LPBASEEXECUTEPLANHEAD lpBaseExecutePlanHead;
	dwSize = GetFileSize(pRedoProcess->m_hFile, NULL);
	if (pRedoProcess->m_dwReadPos == dwSize)
	{
		nDataLen = 0;
		return MF_CLUSTER_CURRENT_REDO_FINISH;
	}
	else if (pRedoProcess->m_dwReadPos > dwSize)
	{
		return MF_CLUSTER_REDO_FAILED;
	}

	//读取执行计划长度
#ifdef WIN32
	if (!ReadFile(pRedoProcess->m_hFile, lpBuffer, sizeof(int), &dwBytesRead, NULL))
	{
		return MF_CLUSTER_REDO_FAILED;
	}
#else
	dwBytesRead = fread(lpBuffer, 1, sizeof(int), pRedoProcess->m_hFile);
	if(dwBytesRead != sizeof(int))
	{
		return MF_CLUSTER_REDO_FAILED;
	}
#endif
	nLen = *(int*)lpBuffer;
	if (nLen > nBufferSize)
	{
		//执行计划长度超过缓存大小，则返回重新分配缓存
		nDataLen = nLen;
	#ifdef WIN32
		if (pRedoProcess->m_dwReadPos != SetFilePointer(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, NULL, FILE_BEGIN))	//把文件指针移动回去
		{
			return MF_CLUSTER_REDO_FAILED;
		}
	#else 
		if(fseek(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, SEEK_SET) != 0) //把文件指针移动回去
		{
			return MF_CLUSTER_REDO_FAILED;
		}
	#endif
		return MF_CLUSTER_REDO_LACK_OF_BUFFER;
	}
	else if (nLen <= sizeof(int))
	{
		return MF_CLUSTER_REDO_FAILED;
	}
#ifdef WIN32
	if (!ReadFile(pRedoProcess->m_hFile, lpBuffer + sizeof(int), nLen - sizeof(int), &dwBytesRead, NULL))
	{
		return MF_CLUSTER_REDO_FAILED;
	}
#else
	dwBytesRead = fread(lpBuffer + sizeof(int), 1, nLen - sizeof(int), pRedoProcess->m_hFile);
#endif
	dwBytesRead = dwBytesRead + sizeof(int);
	if (dwBytesRead < nLen)
	{
		//读出的长度不对
		//可能是该条日志只写了一部分，剩余部分还在缓存里面
	#ifdef WIN32
		if(pRedoProcess->m_dwReadPos != SetFilePointer(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, NULL, FILE_BEGIN))	//把文件指针移动回去
		{
			return MF_CLUSTER_REDO_FAILED;
		}
	#else
		if(fseek(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, SEEK_SET) != 0) //把文件指针移动回去
		{
			return MF_CLUSTER_REDO_FAILED;
		}
	#endif
		nDataLen = 0;
		return MF_CLUSTER_CURRENT_REDO_FINISH;
	}
	else if (dwBytesRead > nLen)
	{
		return MF_CLUSTER_REDO_FAILED;
	} 
	else
	{
		lpBaseExecutePlanHead = (LPBASEEXECUTEPLANHEAD)lpBuffer;
		pRedoProcess->m_dwReadPos += nLen;
		pRedoProcess->m_llTimestamp = lpBaseExecutePlanHead->m_nTimestamp;
		nDataLen = nLen;

		return MF_CLUSTER_READ_REDO_SUCCEED;
	}
}

//读出一条执行计划的计划头，这样不需要考虑Buffer不够大的情况
//并将文件指针移到这条执行计划的末尾
int CReadRedoLog::ReadExecutePlanHead(LPREDOPROCESS pRedoProcess, BASEEXECUTEPLANHEAD &stBaseExecutePlanHead)
{
	DWORD dwBytesRead, dwSize;
	dwSize = GetFileSize(pRedoProcess->m_hFile, NULL);
	if (pRedoProcess->m_dwReadPos == dwSize)
	{
		return MF_CLUSTER_CURRENT_REDO_FINISH;
	}
	else if (pRedoProcess->m_dwReadPos > dwSize)
	{
		return MF_CLUSTER_REDO_FAILED;
	}

	//读取执行计划头
#ifdef WIN32
	if (!ReadFile(pRedoProcess->m_hFile, &stBaseExecutePlanHead, sizeof(BASEEXECUTEPLANHEAD), &dwBytesRead, NULL))
	{
		return MF_CLUSTER_REDO_FAILED;
	}
#else
	dwBytesRead = fread(&stBaseExecutePlanHead, 1, sizeof(BASEEXECUTEPLANHEAD), pRedoProcess->m_hFile);
#endif
	if (dwBytesRead != sizeof(BASEEXECUTEPLANHEAD))
	{
		//读出的长度不对
		return MF_CLUSTER_REDO_FAILED;
	}

	pRedoProcess->m_dwReadPos += stBaseExecutePlanHead.m_nTotalDataSize;
	pRedoProcess->m_llTimestamp = stBaseExecutePlanHead.m_nTimestamp;
#ifdef WIN32
	if (pRedoProcess->m_dwReadPos != SetFilePointer(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, NULL, FILE_BEGIN))	//把文件指针移动到这条执行计划末尾
	{
		return MF_CLUSTER_REDO_FAILED;
	}
#else
	if(fseek(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, SEEK_SET) != 0) //把文件指针移动到这条执行计划末尾
	{
		return MF_CLUSTER_REDO_FAILED;
	}
#endif
	return MF_CLUSTER_READ_REDO_SUCCEED;
}


//根据时间戳查找指定记录所在的日志文件编号
int CReadRedoLog::SetRedoID(LPREDOPROCESS pRedoProcess, LPBYTE lpBuffer, int nBufferSize, LONGLONG llTimestamp, int nRedoLogMaxID)
{
	BOOL bNoRedoFile;
	int nRet, nRedoID, nLogFiles;
	BASEEXECUTEPLANHEAD stBaseExecutePlanHead;

	try
	{
		bNoRedoFile = TRUE;
		if (nRedoLogMaxID < 2)
		{
			return 0;
		}
	#ifdef WIN32
		if(pRedoProcess->m_hFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(pRedoProcess->m_hFile);
			pRedoProcess->m_hFile = INVALID_HANDLE_VALUE;
		}
	#else
		if(pRedoProcess->m_hFile != NULL)
		{
			fclose(pRedoProcess->m_hFile);
			pRedoProcess->m_hFile = NULL;
		}
	#endif

		nLogFiles = CSystemManage::instance().GetParameterValue(MF_ACTIVE_LOG_FILES);
		if(nRedoLogMaxID > nLogFiles)
		{
			nRedoID = nRedoLogMaxID - nLogFiles + 1;

		}
		else
		{
			nRedoID = 1;
		}
		for (; nRedoID < nRedoLogMaxID; nRedoID++)
		{
			pRedoProcess->m_nRedoLogID = nRedoID;
		#ifdef WIN32
			_stprintf_s(pRedoProcess->m_lpRedoFilePath, 256, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID);
			nRet = _access_s(pRedoProcess->m_lpRedoFilePath, 0);
		#else
			_stprintf(pRedoProcess->m_lpRedoFilePath, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID);
			nRet = access(pRedoProcess->m_lpRedoFilePath, 0);
		#endif
			if (nRet != 0)
			{
				Trace(_T("SetRedoID"), MF_TRACE_LEVEL_FAILED, 10421001, _T("查找指定的重作日志不存在，文件路径：%s，日志编号：%d，返回值：%d"), 
					pRedoProcess->m_lpRedoFilePath, pRedoProcess->m_nRedoLogID, nRet);
				//不用返回，直接查找下一个日志
				continue;
				//return 0;
			}
			else
			{
				bNoRedoFile = FALSE;
				Sleep(10);
			#ifdef WIN32
				pRedoProcess->m_hFile = ::CreateFile(
					pRedoProcess->m_lpRedoFilePath, 
					GENERIC_READ, 
					FILE_SHARE_READ | FILE_SHARE_WRITE,
					NULL, 
					OPEN_EXISTING, 
					FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, 
					NULL);
				if (pRedoProcess->m_hFile == INVALID_HANDLE_VALUE)
				{
					//打开不成功
					return 0;
				}
				else
				{
					DWORD dwBytesRead;
					MF_REDOLOGFILEHEAD stRedoLogFileHead;
					if (!ReadFile(pRedoProcess->m_hFile, &stRedoLogFileHead, sizeof(MF_REDOLOGFILEHEAD), &dwBytesRead, NULL))
					{
						return 0;
					}
					if (dwBytesRead != sizeof(MF_REDOLOGFILEHEAD))
					{
						//读出的长度不对
						return 0;
					}
					if (stRedoLogFileHead.m_usDatabaseGuid != CSystemManage::instance().GetDatabaseGuid())
					{
						Trace(_T("SetRedoID"), MF_TRACE_LEVEL_FAILED, 10421002, _T("验证数据库UID失败，文件路径：%s，日志内数据库uid：%u，实际数据库uid：%d"), 
							pRedoProcess->m_lpRedoFilePath, stRedoLogFileHead.m_usDatabaseGuid, CSystemManage::instance().GetDatabaseGuid());
						//不用返回，直接查找下一个日志
						continue;
					}
					pRedoProcess->m_dwReadPos = sizeof(MF_REDOLOGFILEHEAD);
				}
			#else
				pRedoProcess->m_hFile = fopen(pRedoProcess->m_lpRedoFilePath, "rb");
				if (pRedoProcess->m_hFile == NULL)
				{
					//打开不成功
					return 0;
				}
				else
				{
					pRedoProcess->m_dwReadPos = sizeof(MF_REDOLOGFILEHEAD);
					if (fseek(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, SEEK_SET) != 0)
					{
						return 0;
					}
				}
			#endif

				//读取日志中第一条记录
				nRet = ReadExecutePlanHead(pRedoProcess, stBaseExecutePlanHead);
				if (nRet != 0)
				{
					return 0;
				}
				if (stBaseExecutePlanHead.m_nTimestamp > llTimestamp)
				{
					if (nRedoID == 1)
					{
						return MF_REDO_TIMESTAMP_LESSTHAN_FIRSTONE;
					} 
					else
					{
						return nRedoID - 1;
					}
				}
				else if (stBaseExecutePlanHead.m_nTimestamp == llTimestamp)
				{
					return nRedoID;
				}
			}
		}
		if (bNoRedoFile)
		{
			return MF_REDO_NO_REDO_FILE;
		} 
		else
		{
			return nRedoID - 1;
		}
	}
	catch (...)
	{
		return 0;
	}

	return 0;
}


//根据时间戳查找指定记录
int CReadRedoLog::SetRedoPointer(LPREDOPROCESS pRedoProcess, LPBYTE lpBuffer, int nBufferSize, LONGLONG llTimestamp)
{
	BOOL bRecover;
	DWORD dwFileSize;
	int nRet, nRedoLogMaxID, nRedoID;
	BASEEXECUTEPLANHEAD stBaseExecutePlanHead;
	try
	{
		nRedoID = 1;
		nRedoLogMaxID = CSystemManage::instance().GetRedoLogMaxID();
		if (nRedoLogMaxID < 2)
		{
			//目前没有重作日志
			return MF_CLUSTER_NO_REDO;
		}

		if (llTimestamp == 0)
		{
			//返回第一条记录
			if(InitRedoProcess(pRedoProcess))
			{
				return MF_OK;
			}
			else
			{
				return MF_REDO_INIT_FAILED;
			}
		}
		else if (llTimestamp < 0)
		{
			//输入的时间戳有误
			return MF_REDO_TIMESTAMP_LESSTHAN_ZERO;
		}
	#ifdef WIN32
		if(pRedoProcess->m_hFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(pRedoProcess->m_hFile);
			pRedoProcess->m_hFile = INVALID_HANDLE_VALUE;
		}
	#else
		if(pRedoProcess->m_hFile != NULL)
		{
			fclose(pRedoProcess->m_hFile);
			pRedoProcess->m_hFile = NULL;
		}
	#endif
		pRedoProcess->m_llTimestamp = llTimestamp;

		nRedoID = SetRedoID(pRedoProcess, lpBuffer, nBufferSize, llTimestamp, nRedoLogMaxID);
		if (nRedoID == MF_REDO_TIMESTAMP_LESSTHAN_FIRSTONE)		//输入的时间戳比日志的第一条记录还早
		{
			//返回第一条记录
			if(InitRedoProcess(pRedoProcess))
			{
				return MF_OK;
			}
			else
			{
				return MF_REDO_INIT_FAILED;
			}
		}
		else if (nRedoID == MF_REDO_NO_REDO_FILE)
		{
			return MF_REDO_NO_REDO_FILE;
		}
		else if (nRedoID <= 0)
		{
			return MF_REDO_REDOID_LESSEQUAL_ZERO;
		}
		else
		{
			int nTryCount = 0;
			bRecover = FALSE;
			while (nRedoID < nRedoLogMaxID)
			{
			#ifdef WIN32
				if(pRedoProcess->m_hFile != INVALID_HANDLE_VALUE)
				{
					CloseHandle(pRedoProcess->m_hFile);
					pRedoProcess->m_hFile = INVALID_HANDLE_VALUE;
				}
			#else
				if(pRedoProcess->m_hFile != NULL)
				{
					fclose(pRedoProcess->m_hFile);
					pRedoProcess->m_hFile = NULL;
				}
			#endif

				pRedoProcess->m_nRedoLogID = nRedoID;
				pRedoProcess->m_llTimestamp = llTimestamp;
			#ifdef WIN32
				_stprintf_s(pRedoProcess->m_lpRedoFilePath, 256, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID);
				_stprintf_s(pRedoProcess->m_lpNextRedoFilePath, 256, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID+1);
				nRet = _access_s(pRedoProcess->m_lpRedoFilePath, 0);
			#else
				_stprintf(pRedoProcess->m_lpRedoFilePath, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID);
				_stprintf(pRedoProcess->m_lpNextRedoFilePath, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID+1);
				nRet = access(pRedoProcess->m_lpRedoFilePath, F_OK);
			#endif
				if (nRet != 0)
				{
					Trace(_T("SetRedoPointer"), MF_TRACE_LEVEL_FAILED, 10422001, _T("查找指定的重作日志不存在，文件路径：%s，日志编号：%d，返回值：%d"), 
						pRedoProcess->m_lpRedoFilePath, pRedoProcess->m_nRedoLogID, nRet);
					return nRet;
				}
				else
				{
					Sleep(10);
				#ifdef WIN32
					pRedoProcess->m_hFile = ::CreateFile(
						pRedoProcess->m_lpRedoFilePath, 
						GENERIC_READ, 
						FILE_SHARE_READ | FILE_SHARE_WRITE,
						NULL, 
						OPEN_EXISTING, 
						FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, 
						NULL);
					if(pRedoProcess->m_hFile == INVALID_HANDLE_VALUE)
					{
						//打开不成功
						return GetLastError();
					}
					else
					{
						DWORD dwBytesRead;
						MF_REDOLOGFILEHEAD stRedoLogFileHead;
						if (!ReadFile(pRedoProcess->m_hFile, &stRedoLogFileHead, sizeof(MF_REDOLOGFILEHEAD), &dwBytesRead, NULL))
						{
							return GetLastError();
						}
						if (dwBytesRead != sizeof(MF_REDOLOGFILEHEAD))
						{
							//读出的长度不对
							return MF_REDO_READ_SIZE_NOT_EQUAL;
						}
						if (stRedoLogFileHead.m_usDatabaseGuid != CSystemManage::instance().GetDatabaseGuid())
						{
							Trace(_T("SetRedoPointer"), MF_TRACE_LEVEL_FAILED, 10422002, _T("验证数据库UID失败，文件路径：%s，日志内数据库uid：%u，实际数据库uid：%d"), 
								pRedoProcess->m_lpRedoFilePath, stRedoLogFileHead.m_usDatabaseGuid, CSystemManage::instance().GetDatabaseGuid());
							return MF_REDO_CHECK_GUID_FAIL;
						}
						pRedoProcess->m_dwReadPos = sizeof(MF_REDOLOGFILEHEAD);
					}
				#else
					pRedoProcess->m_hFile = fopen(pRedoProcess->m_lpRedoFilePath, "rb");
					if(pRedoProcess->m_hFile == NULL)
					{
						//打开不成功
						return GetLastError();
					}
					else
					{
						pRedoProcess->m_dwReadPos = sizeof(MF_REDOLOGFILEHEAD);
						if(fseek(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, SEEK_SET) != 0)
						{
							return GetLastError();
						}
					}
				#endif
				

					dwFileSize = GetFileSize(pRedoProcess->m_hFile, NULL);
					while(pRedoProcess->m_dwReadPos < dwFileSize)
					{
						nRet = ReadExecutePlanHead(pRedoProcess, stBaseExecutePlanHead);
						if (nRet != 0)
						{
							return nRet;
						}
						if(stBaseExecutePlanHead.m_nTimestamp > llTimestamp)
						{
							bRecover = TRUE;
						}
						if (stBaseExecutePlanHead.m_nTimestamp == llTimestamp)
						{
							pRedoProcess->m_llTimestamp = llTimestamp;
							return MF_OK;
						}
					}
					
				}
				if(!bRecover)
				{
					return MF_OK;
				}
				//没有找到指定的时间戳
				//则在前后的日志文件中再找一次
				if (nTryCount == 0)
				{
					//查找前一个日志文件
					nTryCount++;
					if (nRedoID == 1)
					{
						nTryCount++;
						nRedoID = nRedoID + 1;
						if (nRedoID >= nRedoLogMaxID)
						{
							return MF_REDO_TIMESTAMP_NOT_FOUND;
						}
					} 
					else		//nRedoID > 1
					{
						nRedoID = nRedoID - 1;
					}
				} 
				else if (nTryCount == 1)
				{
					//查找后一个日志文件
					nTryCount++;
					nRedoID = nRedoID + 2;
					if (nRedoID >= nRedoLogMaxID)
					{
						return MF_REDO_TIMESTAMP_NOT_FOUND;
					}
				} 
				else
				{
					//还是没有找到
					return MF_REDO_TIMESTAMP_NOT_FOUND;
				}
			}//while (nRedoID < nRedoLogMaxID)
			Trace(_T("SetRedoPointer"), MF_TRACE_LEVEL_FAILED, 10422099, _T("SetRedoPointer异常：当前日志编号：%d，最大日志编号：%d"), nRedoID, nRedoLogMaxID);
			return MF_FAILED;
		}
	}
	catch (...)
	{
		return MF_FAILED;
	}
}

//检查是否存在新的重作日志
#ifdef WIN32
int CReadRedoLog::OpenRedoNew(LPREDOPROCESS pRedoProcess)
{
	DWORD dwFilePos;
	int nRet, nErrorCount;
	nErrorCount = 0;

	nRet = _access_s(pRedoProcess->m_lpNextRedoFilePath, 0);
	if (nRet == 0)		//文件存在
	{
		Sleep(10);
		if (pRedoProcess->m_hFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(pRedoProcess->m_hFile);
			pRedoProcess->m_hFile = INVALID_HANDLE_VALUE;
		}

		pRedoProcess->m_nRedoLogID++;
		_stprintf_s(pRedoProcess->m_lpRedoFilePath, 256, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID);
		_stprintf_s(pRedoProcess->m_lpNextRedoFilePath, 256, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID+1);

		pRedoProcess->m_hFile = ::CreateFile(
			pRedoProcess->m_lpRedoFilePath, 
			GENERIC_READ, 
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL, 
			OPEN_EXISTING, 
			FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, 
			NULL);
		if (pRedoProcess->m_hFile == INVALID_HANDLE_VALUE)
		{
			//打开不成功
			return MF_CLUSTER_REDO_FAILED;
		}
		else
		{
			pRedoProcess->m_dwReadPos = sizeof(MF_REDOLOGFILEHEAD);
			dwFilePos = SetFilePointer(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, NULL, FILE_BEGIN);
			if (dwFilePos != pRedoProcess->m_dwReadPos)
			{
				while(TRUE)
				{
					//重复尝试10次
					Sleep(10);
					nErrorCount++;

					dwFilePos = SetFilePointer(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, NULL, FILE_BEGIN);
					if (dwFilePos == pRedoProcess->m_dwReadPos)
					{
						break;
					}
					if (nErrorCount > 10)
					{
						CloseHandle(pRedoProcess->m_hFile);
						pRedoProcess->m_hFile = INVALID_HANDLE_VALUE;
						return MF_CLUSTER_REDO_FAILED;
					}
				}
			}

			dwFilePos = SetFilePointer(pRedoProcess->m_hFile, 0, NULL, FILE_BEGIN);
			if (dwFilePos != 0)
			{
				return MF_CLUSTER_REDO_FAILED;
			}
			DWORD dwBytesRead;
			MF_REDOLOGFILEHEAD stRedoLogFileHead;
			if (!ReadFile(pRedoProcess->m_hFile, &stRedoLogFileHead, sizeof(MF_REDOLOGFILEHEAD), &dwBytesRead, NULL))
			{
				return MF_CLUSTER_REDO_FAILED;
			}
			if (dwBytesRead != sizeof(MF_REDOLOGFILEHEAD))
			{
				//读出的长度不对
				return MF_CLUSTER_REDO_FAILED;
			}
			if (stRedoLogFileHead.m_usDatabaseGuid != CSystemManage::instance().GetDatabaseGuid())
			{
				Trace(_T("OpenRedoNew"), MF_TRACE_LEVEL_FAILED, 10422005, _T("验证数据库UID失败，文件路径：%s，日志内数据库uid：%u，实际数据库uid：%d"), 
					pRedoProcess->m_lpRedoFilePath, stRedoLogFileHead.m_usDatabaseGuid, CSystemManage::instance().GetDatabaseGuid());
				return MF_CLUSTER_REDO_FAILED;
			}
			pRedoProcess->m_dwReadPos = sizeof(MF_REDOLOGFILEHEAD);
		}
	} 
	else
	{
		return MF_CLUSTER_NO_NEW_REDO;
	}

	return MF_CLUSTER_NEW_REDO;
}
#else
int CReadRedoLog::OpenRedoNew(LPREDOPROCESS pRedoProcess)
{
	int nRet, nErrorCount;
	nErrorCount = 0;

	nRet = access(pRedoProcess->m_lpNextRedoFilePath, F_OK);
	if (nRet == 0)		//文件存在
	{
		Sleep(10);
		if (pRedoProcess->m_hFile != NULL)
		{
			fclose(pRedoProcess->m_hFile);
			pRedoProcess->m_hFile = NULL;
		}

		pRedoProcess->m_nRedoLogID++;
		_stprintf(pRedoProcess->m_lpRedoFilePath, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID);
		_stprintf(pRedoProcess->m_lpNextRedoFilePath, _T("%s%s%d.log"), pRedoProcess->m_lpRedoDir, _T("REDO"), pRedoProcess->m_nRedoLogID+1);

		pRedoProcess->m_hFile = fopen(pRedoProcess->m_lpRedoFilePath, "rb");
		if (pRedoProcess->m_hFile == NULL)
		{
			//打开不成功
			return MF_CLUSTER_REDO_FAILED;
		}
		else
		{
			pRedoProcess->m_dwReadPos = sizeof(MF_REDOLOGFILEHEAD);
			if(fseek(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, SEEK_SET) != 0)
			{
				while(TRUE)
				{
					//重复尝试10次
					Sleep(10);
					nErrorCount++;

					if(fseek(pRedoProcess->m_hFile, pRedoProcess->m_dwReadPos, SEEK_SET) == 0)
					{
						break;
					}
					if (nErrorCount > 10)
					{
						fclose(pRedoProcess->m_hFile);
						pRedoProcess->m_hFile = NULL;
						return MF_CLUSTER_REDO_FAILED;
					}
				}
			}
		}
	}
	else
	{
		return MF_CLUSTER_NO_NEW_REDO;
	}

	return MF_CLUSTER_NEW_REDO;
}
#endif

//检查重作日志是否存在更新
int CReadRedoLog::CheckRedoUpdate(LPREDOPROCESS pRedoProcess)
{
	DWORD dwSize;

#ifdef WIN32
	if (pRedoProcess->m_hFile == INVALID_HANDLE_VALUE)
	{
		return OpenRedoNew(pRedoProcess);
	} 
#else
	if (pRedoProcess->m_hFile == NULL)
	{
		return OpenRedoNew(pRedoProcess);
	}
#endif
	else
	{
		dwSize = GetFileSize(pRedoProcess->m_hFile, NULL);
		if (pRedoProcess->m_dwReadPos > dwSize)
		{
			return MF_CLUSTER_REDO_FAILED;
		}
		else if (pRedoProcess->m_dwReadPos == dwSize)
		{
			return OpenRedoNew(pRedoProcess);
		}
		else
		{
			//当前文件存在更新
			return MF_CLUSTER_NEW_REDO;
		}
	}

	return MF_CLUSTER_REDO_FAILED;
}

int CReadRedoLog::GetLastTimestamp(LONGLONG &llTimestamp)
{
	REDOPROCESS stRedoProcess;
	DWORD dwFileSize;
	int nRet, nRedoLogMaxID, nRedoID;
	BASEEXECUTEPLANHEAD stBaseExecutePlanHead;
	memset(&stRedoProcess, 0, sizeof(stRedoProcess));
	try
	{
		nRedoLogMaxID = CSystemManage::instance().GetRedoLogMaxID();
		if (nRedoLogMaxID < 2)
		{
			//目前没有重作日志
			llTimestamp = 0;
			return MF_OK;
		}
		nRedoID = nRedoLogMaxID - 1;
		if (!CReadRedoLog::InitRedoProcess(&stRedoProcess))
		{
			return MF_REDO_INIT_FAILED;
		}

		stRedoProcess.m_nRedoLogID = nRedoID;
		stRedoProcess.m_llTimestamp = 0;
	#ifdef WIN32
		_stprintf_s(stRedoProcess.m_lpRedoFilePath, 256, _T("%s%s%d.log"), stRedoProcess.m_lpRedoDir, _T("REDO"), stRedoProcess.m_nRedoLogID);
		_stprintf_s(stRedoProcess.m_lpNextRedoFilePath, 256, _T("%s%s%d.log"), stRedoProcess.m_lpRedoDir, _T("REDO"), stRedoProcess.m_nRedoLogID+1);
		nRet = _access_s(stRedoProcess.m_lpRedoFilePath, 0);
	#else
		_stprintf(stRedoProcess.m_lpRedoFilePath, _T("%s%s%d.log"), stRedoProcess.m_lpRedoDir, _T("REDO"), stRedoProcess.m_nRedoLogID);
		_stprintf(stRedoProcess.m_lpNextRedoFilePath, _T("%s%s%d.log"), stRedoProcess.m_lpRedoDir, _T("REDO"), stRedoProcess.m_nRedoLogID+1);
		nRet = access(stRedoProcess.m_lpRedoFilePath, F_OK);
	#endif
		if (nRet != 0)
		{
			Trace(_T("GetLastTimestamp"), MF_TRACE_LEVEL_FAILED, 10423001, _T("查找指定的重作日志不存在，文件路径：%s，日志编号：%d，返回值：%d"), 
				stRedoProcess.m_lpRedoFilePath, stRedoProcess.m_nRedoLogID, nRet);
			return GetLastError();
		}
		else
		{
			Sleep(10);
		#ifdef WIN32
			stRedoProcess.m_hFile = ::CreateFile(
				stRedoProcess.m_lpRedoFilePath, 
				GENERIC_READ, 
				FILE_SHARE_READ | FILE_SHARE_WRITE,
				NULL, 
				OPEN_EXISTING, 
				FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, 
				NULL);
			if (stRedoProcess.m_hFile == INVALID_HANDLE_VALUE)
			{
				//打开不成功
				return GetLastError();
			}
			else
			{
				DWORD dwBytesRead;
				MF_REDOLOGFILEHEAD stRedoLogFileHead;
				if (!ReadFile(stRedoProcess.m_hFile, &stRedoLogFileHead, sizeof(MF_REDOLOGFILEHEAD), &dwBytesRead, NULL))
				{
					return GetLastError();
				}
				if (dwBytesRead != sizeof(MF_REDOLOGFILEHEAD))
				{
					//读出的长度不对
					return MF_REDO_READ_SIZE_NOT_EQUAL;
				}
				if (stRedoLogFileHead.m_usDatabaseGuid != CSystemManage::instance().GetDatabaseGuid())
				{
					Trace(_T("GetLastTimestamp"), MF_TRACE_LEVEL_FAILED, 10423002, _T("验证数据库UID失败，文件路径：%s，日志内数据库uid：%u，实际数据库uid：%d"), 
						stRedoProcess.m_lpRedoFilePath, stRedoLogFileHead.m_usDatabaseGuid, CSystemManage::instance().GetDatabaseGuid());
					return MF_REDO_CHECK_GUID_FAIL;
				}
				stRedoProcess.m_dwReadPos = sizeof(MF_REDOLOGFILEHEAD);
			}
		#else
			stRedoProcess.m_hFile = fopen(stRedoProcess.m_lpRedoFilePath, "rb");
			if (stRedoProcess.m_hFile == NULL)
			{
				//打开不成功
				return GetLastError();
			}
			else
			{
				stRedoProcess.m_dwReadPos = sizeof(MF_REDOLOGFILEHEAD);
				if(fseek(stRedoProcess.m_hFile, stRedoProcess.m_dwReadPos, SEEK_SET) != 0)
				{
					return GetLastError();
				}
			}
		#endif
			dwFileSize = GetFileSize(stRedoProcess.m_hFile, NULL);
			while(stRedoProcess.m_dwReadPos < dwFileSize)
			{
				nRet = ReadExecutePlanHead(&stRedoProcess, stBaseExecutePlanHead);
				if (nRet != 0)
				{
					return nRet;
				}
				if (stRedoProcess.m_dwReadPos == dwFileSize)
				{
					llTimestamp = stBaseExecutePlanHead.m_nTimestamp;
					return MF_OK;
				}
			}
			Trace(_T("GetLastTimestamp"), MF_TRACE_LEVEL_FAILED, 10423003, _T("读取日志长度异常，文件路径：%s，日志编号：%d，日志大小：%d，读取位置：%d"), 
				stRedoProcess.m_lpRedoFilePath, stRedoProcess.m_nRedoLogID, dwFileSize, stRedoProcess.m_dwReadPos);
		}
	}
	catch (...)
	{
		return MF_FAILED;
	}
	return MF_FAILED;;
}

long long CReadRedoLog::RedoGetFileSize(FILE *fp)
{
	long long llPointer, llSize;
	llPointer = ftell(fp);
	fseek(fp, 0, SEEK_END);
	llSize = ftell(fp);
	fseek(fp, llPointer, SEEK_SET);
	return llSize;
}
