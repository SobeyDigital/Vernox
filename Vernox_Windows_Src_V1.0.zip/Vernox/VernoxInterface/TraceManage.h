/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

class CTraceManage
{
private:
	int	  												m_nNum;
	HANDLE												m_hFile;
	LPTSTR												m_lpTraceDir;		//��־Ŀ¼�ļ���
	LPTSTR												m_lpszBuf;
	HANDLE												m_hStopEvent;
	BOOL												m_bWriteDirect;
	CRITICAL_SECTION									m_cs;
	CList<CString *, CString *>							m_lsTraceLog;
private:
	CTraceManage();
	CTraceManage(const CTraceManage &);
	CTraceManage & operator = (const CTraceManage &);
	virtual ~CTraceManage(void);
	static CTraceManage * m_pSinstance;

	static long ReadRegKeyValue(LPCTSTR lszpValueName, long dwDefault, LPCTSTR lpszSubKey);
	static BOOL ReadRegKeyValue(LPCTSTR lszpValueName, LPCTSTR lpszDefault, LPCTSTR lpszSubKey, LPTSTR lpText);
	static BOOL GetOPSystemInfo(LPTSTR lpInfo);
	static BOOL GetMachineInfo(LPTSTR lpInfo);

	BOOL CheckLogFile();
	BOOL LogFileManage(LPCTSTR pFileName);

	void AddTrace(CString * lpszTrace);
	CString * GetTrace();

	HANDLE m_hWriteTraceThread;
	static unsigned int __stdcall WriteTraceThread(LPVOID lpParam);
public:
	static CTraceManage & instance();
	static void DestoryInstance();
	BOOL WriteLog(LPCTSTR szFuncationName, LONG dwThreadID, DWORD dwLevel, DWORD dwErrorCode, LPCTSTR szText);
};
