/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "resource.h"       // ������
#include "SobeyMemInterface_i.h"

#include "..\Include\SobeyMemBaseExport.h"

// CMemDBInterface
class ATL_NO_VTABLE CMemDBInterface :
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CMemDBInterface, &CLSID_DBInterface>,
	public IDispatchImpl<IDBInterface, &IID_IDBInterface, &LIBID_VernoxInterfaceLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
protected:
	typedef struct 
	{
		char m_cProtocol[MAX_PATH];
		char m_cHost[MAX_PATH];
		char m_cPort[MAX_PATH];
		char m_cWriteLog[MAX_PATH];
	}STRUCT_ADDRESS, LPSTRUCT_ADDRESS;

	typedef struct 
	{
		char m_cSobeyDB[MAX_PATH];
		char m_cDatabaseName[MAX_PATH];
		vector<STRUCT_ADDRESS> m_vecAddress;
	}STRUCT_CONNECT_CONFIG;

	typedef struct
	{
		ULONG			m_ulIP;
		USHORT			m_usPort;
		int				m_nSessionNum;
	}CONNECTINFO, *LPCONNECTINFO;

protected:
	BOOL				m_bStatic;						//��̬���ӻ��Ƕ�̬����
	int					m_nConnectNum;					//��ǰ��������
	int					m_nNodeNum;						//�ڵ�����
	CONNECTINFO			m_lpConnectInfo[10];			//��Ⱥ����
	CRITICAL_SECTION	m_csInterFace;
	BOOL				m_bOpenFlag;
	int					m_lInterfaceType;
	int					m_lWriteEfficiencyLog;
	//ͨ��TCP��ʽ��Ҫ�Ĳ���
	ULONG				m_uServiceTCPIP;
	USHORT				m_uServiceTCPPort;
	SOCKET				m_skSocket;
	BYTE				m_bRandomFactor;
	char				m_pUserName[24];
	char				m_pPassword[24];

	void Close();
	BYTE CreateRandomFactor();
	int UserLogin();
	HRESULT UserLogOut(int& nRetValue);
	int ConnectToService(BOOL bRetry);
	int OpenDatabase(BOOL bRetry);
	void GetSocketInfo(ULONG &ulIP, USHORT &usPort);
	int Connect(BOOL bRetry);
	char* ConvertToUTF8(const wchar_t * strData);
	CString ConvertString(const char * lpszData);
	void ConvertBSTR(const char * lpszData, CComBSTR &bstrRs);
	BOOL IsCharacter(char c);
	BOOL ParseConnectConfig(char *lpServerName, STRUCT_CONNECT_CONFIG &stConfig);
	BOOL ParseConnectConfig(char *lpServerName, FILE * fp, STRUCT_CONNECT_CONFIG &stConfig);
	HRESULT OpenCore(char * lpszServerName, char * lpszUserName, char * lpszPassword);

	HRESULT ConvertToRecordset(wchar_t * lpszXml, _Recordset ** ppRs);
	HRESULT ConvertFromRecordset(_Recordset * pRs, CComBSTR &btrXml);

	void ClearSocket();
	BOOL ReceiveBuffer(char *pBuffer, int nSize);

	HRESULT TCPExecuteCommand(BSTR bstrCmd, LONG* plAffectCount);
	HRESULT TCPGetRecordset(BSTR bstrSql, _Recordset ** ppRs);
	HRESULT TCPUpdateRecordset(_Recordset * pRs);
	HRESULT TCPStartTransactionLogic(BSTR bstrTransactionData, LONG* plTransactionID);
	HRESULT TCPStopTransactionLogic(LONG lTransactionID);

	HRESULT ExecuteCommandCore(BSTR bstrCmd, LONG* plAffectCount);
	HRESULT GetRecordsetCore(BSTR bstrSql, _Recordset ** ppRs);
	HRESULT UpdateRecordsetCore(_Recordset * pRs);
	HRESULT StartTransactionLogicCore(BSTR bstrTransactionData, LONG* plTransactionID);
	HRESULT StopTransactionLogicCore(LONG lTransactionID);
public:
	CMemDBInterface();
	~CMemDBInterface();

DECLARE_REGISTRY_RESOURCEID(IDR_MEMDBINTERFACE)


BEGIN_COM_MAP(CMemDBInterface)
	COM_INTERFACE_ENTRY(IDBInterface)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()



	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
		if(m_skSocket != INVALID_SOCKET)
		{
			closesocket(m_skSocket);
			m_skSocket = INVALID_SOCKET;
		}
	}

public:
	STDMETHOD(ExecuteCommand)(BSTR bstrCmd, LONG* plAffectCount);
	STDMETHOD(GetRecordset)(BSTR bstrSql, _Recordset ** ppRs);
	STDMETHOD(UpdateRecordset)(_Recordset * pRs);
	STDMETHOD(Open)(BSTR bstrServer, BSTR bstrUser, BSTR bstrPassword);
	STDMETHOD(StartTransactionLogic)(BSTR bstrTransactionData, LONG* plTransactionID);
	STDMETHOD(StopTransactionLogic)(LONG lTransactionID);
};

OBJECT_ENTRY_AUTO(__uuidof(DBInterface), CMemDBInterface)
