// dllmain.h : ģ�����������

class CSobeyMemInterfaceModule : public CAtlDllModuleT< CSobeyMemInterfaceModule >
{
public :
	DECLARE_LIBID(LIBID_VernoxInterfaceLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_SOBEYMEMINTERFACE, "{7900F04D-B9FB-451A-AA90-1BEC63268648}")
};

extern class CSobeyMemInterfaceModule _AtlModule;
