// dllmain.cpp : DllMain ��ʵ�֡�

#include "stdafx.h"
#include "resource.h"
#include "SobeyMemInterface_i.h"
#include "dllmain.h"

HINSTANCE g_hVernoxInstance = NULL;
CSobeyMemInterfaceModule _AtlModule;
class CSobeyMemInterfaceApp : public CWinApp
{
public:

// ��д
	virtual BOOL InitInstance();
	virtual int ExitInstance();

	DECLARE_MESSAGE_MAP()
};

BEGIN_MESSAGE_MAP(CSobeyMemInterfaceApp, CWinApp)
END_MESSAGE_MAP()

CSobeyMemInterfaceApp theApp;
BOOL CSobeyMemInterfaceApp::InitInstance()
{
	g_hVernoxInstance = m_hInstance;
	InitTraceSystem();
	return CWinApp::InitInstance();
}

int CSobeyMemInterfaceApp::ExitInstance()
{
	ExitTraceSystem();
	return CWinApp::ExitInstance();
}
