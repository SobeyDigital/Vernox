/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "afxcmn.h"
#include "afxwin.h"

class CServerStatusManage;

// CSobeyMemDBConfigurationDlg �Ի���
class CSobeyMemDBConfigurationDlg : public CDialog
{
// ����
public:
	CSobeyMemDBConfigurationDlg(CWnd* pParent = NULL);	// ��׼���캯��
	virtual ~CSobeyMemDBConfigurationDlg();

// �Ի�������
	enum { IDD = IDD_SOBEYMEMDBCONFIGURATION_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:			//��Ա����
	CString		m_strEditDatabaseName;
	BYTE		m_bFileNO;
	int			m_nRow;
	int			m_nCol;
	int			m_nProgress;
	long long	m_nTotalSize;
	TCHAR		m_lpBaseDir[MAX_PATH];
	TCHAR		m_lpWorkingDir[MAX_PATH];
	TCHAR		m_lpDataFileDir[MAX_PATH];
	TCHAR		m_lpDatabaseDir[MAX_PATH];
	TCHAR		m_lpConfigFilePath[MAX_PATH];
	LPBYTE		m_lpFileAddr;
	BOOL		m_bExit;
	LPSYSTEMFILEHEAD m_lpSystemFileHead;
	CServerStatusManage * m_pServerStatusManage;
public:			//�ؼ�����
	CEdit		m_Edit;
	CListCtrl	m_ListCtrl;
	CListBox	m_listboxDatabase;
	COLORREF	m_colorBackground;
protected:
	int CMessageBox(LPCTSTR lpText, UINT nType = (MB_OK|MB_SYSTEMMODAL))
	{
		return MessageBox(lpText, 0, nType);
	}

	static void CheckServiceStatusThread(LPVOID lpParam);

protected:		//�Զ��幦�ܺ���
	BOOL CreateNewDatabase();

	void DeleteDatabase();

	int DeleteDirectory(LPCTSTR lpFilePath);

	void CloseDatabase();

	void StartDatabase();

	//�������Ƿ�����
	BOOL SobeyMemCheckService(LPCTSTR lpServiceName);

	//��װ��������
	int SobeyMemInstallService(LPCTSTR lpServiceName);

	//ɾ��������ͣ����
	int SobeyMemDeleteService(LPCTSTR lpServiceName, int nMode = 0);

	//����ϵͳ�ļ�  ��λ��BYTE
	int CreateSystemDataFile(LONGLONG llSystemFileSize);

	//�������ݿ�Ψһ��ʶ
	USHORT CreateDatabaseGuid();

	//���������ļ�  ��λ��MB
	int CreateDataFile(int nDataFileSize, int nTreeFileSize, int nKVFileSize);
	
	//����ϵͳ����
	int CreateSystemObject(int nSysObjectID, long long nTimestamp);

	//����Ȩ��
	int AddAuthority(MF_AUTHORITY_ID bAuthorityID, char* pAuthorityName, TCHAR* pDescribe, long nTimestamp);

	//��ȡ�����ļ�ϵͳ����
	void ReadSysConfigParam(LPSYSTEMFILEHEAD lpSystemFileHead, LONGLONG llSystemFileSize);

	//��ʾ���е����ݿ�
	void ShowDatabases(LPCTSTR lpDataPath);

	//����״̬��ɫ�л�
	void ServiceChangeColor(BOOL bRunning);
	void StorageChangeColor(BOOL bRunning);

	//�����־û�����
	int SobeyMemStorgeInstallService();
	//�����ڴ����
	int SobeyMemServiceInstallService();

	static void StartServiceThread(LPVOID data);
	void StartServiceCore();
	static void CreateDatabaseThread(LPVOID data);
	void CreateDatabaseCore();
protected:
	virtual void OnCancel();
	virtual void OnOK();
public:
	afx_msg void OnNMDblclkList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnEnKillfocusEdit();
	afx_msg void OnBnClickedBtnCreateDatabase();
	afx_msg void OnBnClickedBtnDeleteDatabase();
	afx_msg void OnBnClickedBtnStartDatabase();
	afx_msg void OnBnClickedBtnCloseDatabase();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	CProgressCtrl m_ctlProgress;
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
