﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "stdafx.h"
#include "LogManager.h"

#define		LOGBUFFER_SIZE		512			//开辟1K的Buffer，减少平常的内存分配与释放

CLogManager * CLogManager::m_pSinstance = NULL;
CRITICAL_SECTION g_CritTrace;

class CCriticalSectionPtr
{
public:
	CCriticalSectionPtr(LPCRITICAL_SECTION lp);
	virtual ~CCriticalSectionPtr(void);
private:
	LPCRITICAL_SECTION m_lpcs;
};

#ifdef WIN32
CCriticalSectionPtr::CCriticalSectionPtr(LPCRITICAL_SECTION lp)
{
	EnterCriticalSection(lp);
	m_lpcs = lp;
}

CCriticalSectionPtr::~CCriticalSectionPtr(void)
{
	LeaveCriticalSection(m_lpcs);
}
#endif

void Trace0(LPCTSTR szFuncationName, LONG  lLogLevel, LONG lLogErrorCode, LPCTSTR szLog)
{
	CCriticalSectionPtr cs(&g_CritTrace);
	try
	{
		CLogManager::instance().WriteLog(szFuncationName, GetCurrentThreadId(), lLogLevel, lLogErrorCode, szLog);
	}
	catch(...)
	{
		#ifdef WIN32
		OutputDebugString(_T("索贝内存存储服务出现异常失败!\r\n"));
		#endif
	}
}

void Trace(LPCTSTR szFuncationName, LONG  lLogLevel, LONG lLogErrorCode, const char *fmt, ... )
{
	CCriticalSectionPtr cs(&g_CritTrace);
	try
	{
		int nChars;
		TCHAR lpBuffer[20480];
		va_list args;
		va_start(args, fmt);
	#ifdef WIN32	
		nChars = _vsnprintf_s(lpBuffer, 20480, _TRUNCATE, fmt, args);
	#else
		nChars = vsnprintf(lpBuffer, 20480, fmt, args);
	#endif
		lpBuffer[20479] = 0;
		va_end(args);
		CLogManager::instance().WriteLog(szFuncationName, GetCurrentThreadId(), lLogLevel, lLogErrorCode, lpBuffer);
	}
	catch(...)
	{
		#ifdef WIN32
		OutputDebugString(_T("索贝内存存储服务出现异常失败!\r\n"));
		#endif
	}
}

void ExitLogSystem()
{
	CLogManager::DestoryInstance();
}

void InitLogSystem()
{
	CLogManager::instance().Init();
}

void SetLogSystemFileHead(LPSYSTEMFILEHEAD	pMemoryFileHead)
{
	CLogManager::instance().SetSystemFileHead(pMemoryFileHead);
}

CLogManager & CLogManager::instance()
{
	if(NULL == m_pSinstance)
	{
		m_pSinstance = new CLogManager;
	}
	return *m_pSinstance;
}

void CLogManager::DestoryInstance()
{
	if(m_pSinstance != NULL)
	{
		delete m_pSinstance;
		m_pSinstance = NULL;
	}
}

CLogManager::CLogManager(void)
{
#ifdef WIN32
	m_nNum				= 0;
	m_hFile				= INVALID_HANDLE_VALUE;
	m_lpszBuf			= new TCHAR[LOGBUFFER_SIZE];
	m_pTraceFileAddr	= NULL;
	m_hTraceFile		= NULL;
	m_hTraceEvent		= NULL;
	m_pLogFileAddr		= NULL;
	m_hLogFile			= NULL;
	m_hLogEvent			= NULL;
	m_bExit				= false;
	m_lpTraceDir		= NULL;
	m_lpRedoDir			= NULL;
	m_pMemoryFileHead	= NULL;
#else
	m_nNum				= 0;
	m_pFile				= NULL;
	m_lpszBuf			= new TCHAR[LOGBUFFER_SIZE];
	m_pTraceFileAddr	= NULL;
	m_pLogFileAddr		= NULL;
	m_bExit				= false;
	m_lpTraceDir		= NULL;
	m_lpRedoDir			= NULL;
	m_pMemoryFileHead	= NULL;

	m_pTraceEvent		= NULL;
	m_pLogEvent			= NULL;

	m_nTraceShmid		= 0;
	m_nLogShmid			= 0;
#endif
}

CLogManager::~CLogManager(void)
{
	if(m_lpszBuf)
	{
		delete m_lpszBuf;
		m_lpszBuf = NULL;
	}
	if(m_lpTraceDir)
	{
		delete m_lpTraceDir;
		m_lpTraceDir = NULL;
	}
	if(m_lpRedoDir)
	{
		delete m_lpRedoDir;
		m_lpRedoDir = NULL;
	}

#ifdef WIN32
	if(m_hFile != INVALID_HANDLE_VALUE && m_hFile != NULL)
	{
		::CloseHandle(m_hFile);
		m_hFile = INVALID_HANDLE_VALUE;
	}
	if(m_pTraceFileAddr != NULL)
	{
		::UnmapViewOfFile(m_pTraceFileAddr);
		m_pTraceFileAddr = NULL;
	}
	if(m_hTraceFile != NULL)
	{
		::CloseHandle(m_hTraceFile);
		m_hTraceFile = NULL;
	}
	if(m_hTraceEvent != NULL)
	{
		::CloseHandle(m_hTraceEvent);
		m_hTraceEvent = NULL;
	}

	if(m_pLogFileAddr != NULL)
	{
		::UnmapViewOfFile(m_pLogFileAddr);
		m_pLogFileAddr = NULL;
	}
	if(m_hLogFile != NULL)
	{
		::CloseHandle(m_hLogFile);
		m_hLogFile = NULL;
	}
	if(m_hLogEvent != NULL)
	{
		::CloseHandle(m_hLogEvent);
		m_hLogEvent = NULL;
	}
	if (m_hWriteTraceThread != NULL)
	{
		::CloseHandle(m_hWriteTraceThread);
		m_hWriteTraceThread = NULL;
	}
	if (m_hWriteLogThread != NULL)
	{
		::CloseHandle(m_hWriteLogThread);
		m_hWriteLogThread = NULL;
	}
#else
	if(m_pFile != NULL)
	{
		fclose(m_pFile);
		m_pFile = NULL;
	}
	if(m_pTraceFileAddr != NULL)
	{
		CShareMemory::ShMemDetach(m_pTraceFileAddr);
		m_pTraceFileAddr = NULL;
	}
	if(m_nTraceShmid > 0)
	{
		CShareMemory::DestoryShareMemory(m_nTraceShmid);
		m_nTraceShmid = 0;
	}

	if(m_pLogFileAddr != NULL)
	{
		CShareMemory::ShMemDetach(m_pLogFileAddr);
		m_pLogFileAddr = NULL;
	}
	if(m_nLogShmid > 0)
	{
		CShareMemory::DestoryShareMemory(m_nLogShmid);
		m_nLogShmid = 0;
	}
#endif
}

BOOL CLogManager::Init()
{
#ifdef WIN32
	TCHAR lpConfigPath[MAX_PATH], lpDatabasePath[MAX_PATH];
	PSECURITY_DESCRIPTOR pSecDescriptor = NULL;

	memset(lpConfigPath, 0, MAX_PATH * sizeof(TCHAR));
	GetModuleFileName(NULL, lpConfigPath, MAX_PATH);
	(strrchr(lpConfigPath, '\\'))[1] = 0;
	strcat_s(lpConfigPath, MAX_PATH, _T("VernoxConfig.ini"));

	memset(lpDatabasePath, 0, sizeof(lpDatabasePath));
	GetPrivateProfileString(_T("System"), _T("databasepath"), _T("c:\\Vernox\\Data\\Vernox\\"), lpDatabasePath, MAX_PATH, lpConfigPath);

	int nLength = strlen(lpDatabasePath);
	m_lpTraceDir = new TCHAR[nLength + 10];
	memset(m_lpTraceDir, 0, (nLength + 10)*sizeof(TCHAR));
	sprintf(m_lpTraceDir, "%sLog\\", lpDatabasePath);
	if(_taccess(m_lpTraceDir,0) == -1)
	{
		::CreateDirectory(m_lpTraceDir, NULL);
	}

	m_lpRedoDir = new TCHAR[nLength + 10];
	memset(m_lpRedoDir, 0, (nLength + 10)*sizeof(TCHAR));
	sprintf(m_lpRedoDir, "%sRedo\\", lpDatabasePath);
	if(_taccess(m_lpRedoDir,0) == -1)
	{
		::CreateDirectory(m_lpRedoDir, NULL);
	}

	if(!InitLogEnvironment(pSecDescriptor))
	{
		LocalFree(pSecDescriptor);
		return FALSE;
	}
	LocalFree(pSecDescriptor);

	return TRUE;
#else
	TCHAR lpConfigPath[MAX_PATH], lpDatabasePath[MAX_PATH];

	memset(lpConfigPath, 0, MAX_PATH * sizeof(TCHAR));
	GetModuleFileName(NULL, lpConfigPath, MAX_PATH);
	(strrchr(lpConfigPath, '/'))[1] = 0;
	strcat(lpConfigPath, _T("VernoxConfig.ini"));

	memset(lpDatabasePath, 0, sizeof(lpDatabasePath));
	GetPrivateProfileString(_T("System"), _T("databasepath"), _T("/Vernox/Data/Vernox/"), lpDatabasePath, MAX_PATH, lpConfigPath);

	int nLength = strlen(lpDatabasePath);
	m_lpTraceDir = new TCHAR[nLength + 10];
	memset(m_lpTraceDir, 0, (nLength + 10)*sizeof(TCHAR));
	sprintf(m_lpTraceDir, "%sLog/", lpDatabasePath);
	if(_taccess(m_lpTraceDir,0) == -1)
	{
		CreateDirectory(m_lpTraceDir, NULL);
	}

	m_lpRedoDir = new TCHAR[nLength + 10];
	memset(m_lpRedoDir, 0, (nLength + 10)*sizeof(TCHAR));
	sprintf(m_lpRedoDir, "%sRedo/", lpDatabasePath);
	if(_taccess(m_lpRedoDir,0) == -1)
	{
		CreateDirectory(m_lpRedoDir, NULL);
	}

	if(!InitLogEnvironment())
	{
		return false;
	}
	return true;
#endif
}

#ifdef WIN32
BOOL CLogManager::InitLogEnvironment(PSECURITY_DESCRIPTOR &pSecDescriptor)
{
	BOOL bInited;
	SECURITY_ATTRIBUTES attr;
	pSecDescriptor = (PSECURITY_DESCRIPTOR)LocalAlloc(LMEM_FIXED, SECURITY_DESCRIPTOR_MIN_LENGTH);
	if(!pSecDescriptor)
	{
		Trace(_T("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000001 , _T("分配安全描述信息失败，错误码：%d"), GetLastError());
		return FALSE;
	}
	if(!InitializeSecurityDescriptor(pSecDescriptor, SECURITY_DESCRIPTOR_REVISION))
	{
		Trace(_T("InitLogEnvironment"), 0, 20000002 , _T("初始化安全描述信息失败，错误码：%d"), GetLastError());
		return FALSE;
	}
	if(!SetSecurityDescriptorDacl(pSecDescriptor, TRUE, NULL, FALSE))
	{
		Trace(_T("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000003 , _T("设置安全描述信息失败，错误码：%d"), GetLastError());
		return FALSE;
	}
	attr.bInheritHandle = FALSE;
	attr.lpSecurityDescriptor = pSecDescriptor;
	attr.nLength = sizeof(SECURITY_ATTRIBUTES);

	m_hTraceEvent = CreateEvent(&attr, FALSE, FALSE, MF_TRACE_FILE_TRACEEVENT);
	if(m_hTraceEvent == NULL)
	{
		Trace(_T("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000011 , _T("创建事件失败，错误码：%d，事件名：%s"), GetLastError(), MF_TRACE_FILE_TRACEEVENT);
		return FALSE;
	}

	//创建内存
	bInited		 = FALSE;
	m_hTraceFile = CreateFileMapping(INVALID_HANDLE_VALUE, &attr, PAGE_READWRITE | SEC_COMMIT, 0, MF_TRACE_FILE_SIZE, MF_TRACE_FILE_TRACENAME);
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		bInited = TRUE;
	}
	else if(m_hTraceFile == NULL)
	{
		Trace(_T("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000012 , _T("打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%d"),
			GetLastError(), MF_TRACE_FILE_TRACENAME, MF_TRACE_FILE_SIZE);
		return FALSE;
	}

	m_pTraceFileAddr = (char*)MapViewOfFile(m_hTraceFile, FILE_MAP_READ|FILE_MAP_WRITE, 0, 0, 0);
	if (m_pTraceFileAddr == NULL)
	{
		Trace(_T("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000013 , _T("内存文件映射内存失败，错误码：%d，内存文件：%s"),	GetLastError(), MF_TRACE_FILE_TRACENAME);
		return FALSE;
	}

	if(!bInited)
	{
		LPFILE_TRACEMEMFILEHEAD pTraceFileHead;
		pTraceFileHead						= (LPFILE_TRACEMEMFILEHEAD)m_pTraceFileAddr;
		pTraceFileHead->m_nDataFlag			= MAKEHEADFLAG('S','B','M','T');
		pTraceFileHead->m_nFileTotalSize	= MF_TRACE_FILE_SIZE;
		pTraceFileHead->m_nFileHeaderSize	= sizeof(FILE_TRACEMEMFILEHEAD);
		pTraceFileHead->m_bFileType			= 1;
		pTraceFileHead->m_bWriteFinishFlag	= 0;
		pTraceFileHead->m_bReserved[0]		= 0;
		pTraceFileHead->m_bReserved[1]		= 0;
		pTraceFileHead->m_nWritePos			= pTraceFileHead->m_nFileHeaderSize;
		pTraceFileHead->m_nReadPos			= pTraceFileHead->m_nFileHeaderSize;
	}

	m_hLogEvent = CreateEvent(&attr, FALSE, FALSE, MF_TRACE_FILE_LOGEVENT);
	if(m_hLogEvent == NULL)
	{
		Trace(_T("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000021 , _T("创建事件失败，错误码：%d，事件名：%s"), GetLastError(), MF_TRACE_FILE_TRACEEVENT);
		return FALSE;
	}
	else if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		bInited = TRUE;
	}

	//创建内存
	bInited	   = FALSE;
	m_hLogFile = CreateFileMapping(INVALID_HANDLE_VALUE, &attr, PAGE_READWRITE | SEC_COMMIT, 0, MF_TRACE_FILE_SIZE, MF_TRACE_FILE_LOGNAME);
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		bInited = TRUE;
	}
	else if(m_hLogFile == NULL)
	{
		Trace(_T("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000022 , _T("打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%d"),
			GetLastError(), MF_TRACE_FILE_LOGNAME, MF_TRACE_FILE_SIZE);
		return FALSE;
	}


	m_pLogFileAddr = (char*)MapViewOfFile(m_hLogFile, FILE_MAP_READ|FILE_MAP_WRITE, 0, 0, 0);
	if (m_pLogFileAddr == NULL)
	{
		Trace(_T("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000023 , _T("内存文件映射内存失败，错误码：%d，内存文件：%s"),	GetLastError(), MF_TRACE_FILE_LOGNAME);
		return FALSE;
	}
	if(!bInited)
	{
		LPFILE_TRACEMEMFILEHEAD pTraceFileHead;
		pTraceFileHead						= (LPFILE_TRACEMEMFILEHEAD)m_pLogFileAddr;
		pTraceFileHead->m_nDataFlag			= MAKEHEADFLAG('S','B','M','T');
		pTraceFileHead->m_nFileTotalSize	= MF_TRACE_FILE_SIZE;
		pTraceFileHead->m_nFileHeaderSize	= sizeof(FILE_TRACEMEMFILEHEAD);
		pTraceFileHead->m_bFileType			= 2;
		pTraceFileHead->m_bWriteFinishFlag	= 0;
		pTraceFileHead->m_bReserved[0]		= 0;
		pTraceFileHead->m_bReserved[1]		= 0;
		pTraceFileHead->m_nWritePos			= pTraceFileHead->m_nFileHeaderSize;
		pTraceFileHead->m_nReadPos			= pTraceFileHead->m_nFileHeaderSize;
	}

	m_hWriteLogThread = NULL;
	m_hWriteTraceThread = NULL;

	return TRUE;
}
#else
BOOL CLogManager::InitLogEnvironment()
{
	BOOL bInited;
	m_pTraceEvent = sem_open(MF_TRACE_FILE_TRACEEVENT, O_CREAT, 0644, 1);
	if(m_pTraceEvent == SEM_FAILED)
	{
		Trace(("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000011 , ("创建事件失败，错误码：%d，事件名：%s"), GetLastError(), MF_TRACE_FILE_TRACEEVENT);
		return false;
	}

	//创建内存
	bInited = false;
	m_nTraceShmid = CShareMemory::CreateShareMemory(MF_TRACE_FILE_TRACE_KEY, MF_TRACE_FILE_SIZE, NULL);
	if(GetLastError() == EEXIST)
	{
		bInited = true;
	}
	else if(m_nTraceShmid == -1)
	{
		Trace(("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000012 , ("打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%d"),
				GetLastError(), MF_TRACE_FILE_TRACENAME, MF_TRACE_FILE_SIZE);
		return false;
	}

	m_pTraceFileAddr = (char*)CShareMemory::ShMemAttach(m_nTraceShmid);
	if (m_pTraceFileAddr == NULL)
	{
		Trace(("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000013 , ("内存文件映射内存失败，错误码：%d，内存文件：%s"),
				GetLastError(), MF_TRACE_FILE_TRACENAME);
		return false;
	}

	if(!bInited)
	{
		LPFILE_TRACEMEMFILEHEAD pTraceFileHead;
		pTraceFileHead								= (LPFILE_TRACEMEMFILEHEAD)m_pTraceFileAddr;
		pTraceFileHead->m_nDataFlag			= MAKEHEADFLAG('S','B','M','T');
		pTraceFileHead->m_nFileTotalSize		= MF_TRACE_FILE_SIZE;
		pTraceFileHead->m_nFileHeaderSize	= sizeof(FILE_TRACEMEMFILEHEAD);
		pTraceFileHead->m_bFileType			= 1;
		pTraceFileHead->m_bWriteFinishFlag	= 0;
		pTraceFileHead->m_bReserved[0]		= 0;
		pTraceFileHead->m_bReserved[1]		= 0;
		pTraceFileHead->m_nWritePos			= pTraceFileHead->m_nFileHeaderSize;
		pTraceFileHead->m_nReadPos				= pTraceFileHead->m_nFileHeaderSize;
	}

	m_pLogEvent = sem_open(MF_TRACE_FILE_LOGEVENT, O_CREAT, 0644, 1);
	if(m_pLogEvent == SEM_FAILED)
	{
		Trace(("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000021 , ("创建事件失败，错误码：%d，事件名：%s"), GetLastError(), MF_TRACE_FILE_TRACEEVENT);
		return false;
	}

	//创建内存
	bInited	   = false;
	m_nLogShmid = CShareMemory::CreateShareMemory(MF_TRACE_FILE_LOG_KEY, MF_TRACE_FILE_SIZE, NULL);
	if(GetLastError() == EEXIST)
	{
		bInited = true;
	}
	else if(m_nLogShmid == -1)
	{
		Trace(("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000022 , ("打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%d"),
				GetLastError(), MF_TRACE_FILE_LOGNAME, MF_TRACE_FILE_SIZE);
		return false;
	}

	m_pLogFileAddr = (char*)CShareMemory::ShMemAttach(m_nLogShmid);
	if (m_pLogFileAddr == NULL)
	{
		Trace(("InitLogEnvironment"), MF_TRACE_LEVEL_FAILED, 20000023 , ("内存文件映射内存失败，错误码：%d，内存文件：%s"),
				GetLastError(), MF_TRACE_FILE_LOGNAME);
		return false;
	}

	if(!bInited)
	{
		LPFILE_TRACEMEMFILEHEAD pTraceFileHead;
		pTraceFileHead						= (LPFILE_TRACEMEMFILEHEAD)m_pLogFileAddr;
		pTraceFileHead->m_nDataFlag			= MAKEHEADFLAG('S','B','M','T');
		pTraceFileHead->m_nFileTotalSize	= MF_TRACE_FILE_SIZE;
		pTraceFileHead->m_nFileHeaderSize	= sizeof(FILE_TRACEMEMFILEHEAD);
		pTraceFileHead->m_bFileType			= 2;
		pTraceFileHead->m_bWriteFinishFlag	= 0;
		pTraceFileHead->m_bReserved[0]		= 0;
		pTraceFileHead->m_bReserved[1]		= 0;
		pTraceFileHead->m_nWritePos			= pTraceFileHead->m_nFileHeaderSize;
		pTraceFileHead->m_nReadPos			= pTraceFileHead->m_nFileHeaderSize;
	}

	return true;
}
#endif

BOOL CLogManager::GetOPSystemInfo(LPTSTR lpInfo)
{
#ifdef WIN32
	TCHAR lpText[256];
	OSVERSIONINFOEX   osvi;
	BOOL   bOsVersionInfoEx;
	memset(lpText, 0, 256*sizeof(TCHAR));
	ZeroMemory(&osvi,   sizeof(OSVERSIONINFOEX));   
	osvi.dwOSVersionInfoSize   =   sizeof(OSVERSIONINFOEX);
	if(!(bOsVersionInfoEx = GetVersionEx((OSVERSIONINFO*)&osvi)))   
	{   
		osvi.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);   
		if(!GetVersionEx((OSVERSIONINFO*)&osvi))   
			return FALSE;   
	}

	switch(osvi.dwPlatformId)
	{   
	case VER_PLATFORM_WIN32_NT:
		if(osvi.dwMajorVersion <= 4)
		{
			if(osvi.wSuiteMask == VER_NT_WORKSTATION)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows NT Workstation "));
			else if(osvi.wSuiteMask == VER_NT_SERVER)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows NT Server "));
			else
				_tcscpy_s(lpText, 256, _T("Microsoft Windows NT "));
		}
		else if(osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 0)
		{
			if(osvi.wProductType == VER_NT_WORKSTATION)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 2000 Professional "));
			else if(osvi.wProductType == VER_NT_SERVER)
			{
				if((osvi.wSuiteMask & VER_SUITE_DATACENTER) == VER_SUITE_DATACENTER)
					_tcscpy_s(lpText, 256, _T("Microsoft Windows 2000 Datacenter Server "));
				else if((osvi.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
					_tcscpy_s(lpText, 256, _T("Microsoft Windows 2000 Advanced Server "));
				else
					_tcscpy_s(lpText, 256, _T("Microsoft Windows 2000 Server "));
			}
		}
		else if(osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 1)
		{
			if((osvi.wSuiteMask & VER_SUITE_PERSONAL) == VER_SUITE_PERSONAL)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows XP Home Edition "));
			else
				_tcscpy_s(lpText, 256, _T("Microsoft Windows XP Professional "));
		}
		else if(osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 2)
		{
			if((osvi.wSuiteMask & VER_SUITE_DATACENTER) == VER_SUITE_DATACENTER)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 2003 Datacenter Edition "));
			else if((osvi.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 2003 Enterprise Edition "));
			else if((osvi.wSuiteMask & VER_SUITE_BLADE) == VER_SUITE_BLADE)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 2003 Web Edition "));
			else
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 2003 Standard Edition "));
		}
		else if(osvi.dwMajorVersion == 6)
		{
			if(osvi.dwMinorVersion == 0)
			{
				if(osvi.wProductType == VER_NT_WORKSTATION)
					_tcscpy_s(lpText, 256, _T("Microsoft Windows Vista "));
				else
					_tcscpy_s(lpText, 256, _T("Microsoft Windows Server 2008 "));
			}
			else if(osvi.dwMinorVersion == 1)
			{
				if(osvi.wProductType == VER_NT_WORKSTATION)
					_tcscpy_s(lpText, 256, _T("Microsoft Windows 7 "));
				else
					_tcscpy_s(lpText, 256, _T("Microsoft Windows Server 2008 R2 "));
			}
			else if(osvi.dwMinorVersion == 2)
			{
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 8 "));
				//_stprintf_s(lpText, 256, _T("Microsoft Windows 8(%d,%d) [P:%d, S:%d, B:%d] "), osvi.dwMajorVersion, osvi.dwMinorVersion, osvi.wProductType, osvi.wSuiteMask, osvi.dwBuildNumber);
			}
			else if(osvi.dwMinorVersion == 3)
			{
				if(osvi.wProductType == VER_NT_WORKSTATION)
					_tcscpy_s(lpText, 256, _T("Microsoft Windows 8.1 "));
				else
					_tcscpy_s(lpText, 256, _T("Microsoft Windows Server 2012 "));
			}
			else
			{
				_stprintf_s(lpText, 256, _T("Microsoft Windows (%d,%d) "), osvi.dwMajorVersion, osvi.dwMinorVersion);
			}
		}
		else
		{
			_stprintf_s(lpText, 256, _T("Microsoft Windows NT(%d,%d) "), osvi.dwMajorVersion, osvi.dwMinorVersion);
		}
		break;
	case	VER_PLATFORM_WIN32_WINDOWS:
		if(osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 0)
		{
			if(osvi.szCSDVersion[1] == 'C' || osvi.szCSDVersion[1] == 'B')
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 95 OSR2 "));
			else
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 95 "));
		}
		else if(osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 10)
		{
			if(osvi.szCSDVersion[1] == 'A')
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 98 SE "));
			else
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 98 "));
		}
		else if(osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 90)
		{
			_tcscpy_s(lpText, 256, _T("Microsoft Windows Me "));
		}
		else
		{
			_stprintf_s(lpText, 256, _T("Microsoft Windows(%d,%d) "), osvi.dwMajorVersion, osvi.dwMinorVersion);
		}
		break;
	case 3:
		if(osvi.dwMajorVersion == 1 && osvi.dwMinorVersion == 0)
		{
			_tcscpy_s(lpText, 256, _T("Microsoft Windows CE 1.0 "));
		}
		else if(osvi.dwMajorVersion == 2 && osvi.dwMinorVersion == 0)
		{
			_tcscpy_s(lpText, 256, _T("Microsoft Windows CE 2.0 "));
		}
		else if(osvi.dwMajorVersion == 2 && osvi.dwMinorVersion == 1)
		{
			_tcscpy_s(lpText, 256, _T("Microsoft Windows CE 2.1 "));
		}
		else if(osvi.dwMajorVersion == 3 && osvi.dwMinorVersion == 0)
		{
			_tcscpy_s(lpText, 256, _T("Microsoft Windows CE 3.0 "));
		}
		else
		{
			_stprintf_s(lpText, 256, _T("Microsoft Windows CE(%d,%d) "), osvi.dwMajorVersion, osvi.dwMinorVersion);
		}
		break;
	default:
		_stprintf_s(lpText, 256, _T("Microsoft Unknown Windows(%d,%d) "), osvi.dwMajorVersion, osvi.dwMinorVersion);
		break;
	}
	_stprintf_s(lpInfo, 256, _T("%s%s (%d,%d)"), lpText, osvi.szCSDVersion,osvi.wServicePackMajor,osvi.dwBuildNumber&0xFFFF);
	return TRUE;
#else
	return true;
#endif
}

int CLogManager::ReadRegKeyValue(LPCTSTR lszpValueName, int dwDefault, LPCTSTR lpszSubKey)
{
#ifdef WIN32
	HKEY hKey;
	DWORD dwData,dwLen,dwRegType;
	try
	{
		HKEY hRetValKey  = NULL;
		hKey = HKEY_LOCAL_MACHINE;
		dwLen = 0;
		dwData = dwDefault;
		if(ERROR_SUCCESS == RegOpenKeyEx(hKey,lpszSubKey,0,KEY_READ,&hRetValKey))
		{
			dwRegType = REG_DWORD;
			dwLen = sizeof(dwData);
			if(ERROR_SUCCESS != RegQueryValueEx(hRetValKey,
				lszpValueName,
				0,
				&dwRegType,
				(LPBYTE)(&dwData),
				&dwLen))
			{
				dwData = dwDefault;
			}
		}
		if(hRetValKey)
			RegCloseKey(hRetValKey);
	}
	catch(...)
	{
	}
	return dwData;
#else
	return 0;
#endif
}

BOOL CLogManager::ReadRegKeyValue(LPCTSTR lszpValueName, LPCTSTR lpszDefault, LPCTSTR lpszSubKey, LPTSTR lpText)
{
#ifdef WIN32
	HKEY hKey;
	HKEY hKeyRetVal;
	DWORD dwRegType,dwDataLength;
	try
	{
		hKey = HKEY_LOCAL_MACHINE;
		if(ERROR_SUCCESS == RegOpenKeyEx(hKey,lpszSubKey,0,KEY_READ,&hKeyRetVal))
		{
			dwRegType = REG_SZ;
			memset(lpText,0,256*sizeof(TCHAR));
			dwDataLength = 255;
			if(ERROR_SUCCESS != RegQueryValueEx(hKeyRetVal,
				lszpValueName,
				0,
				&dwRegType,
				(LPBYTE)(lpText),
				&dwDataLength))
			{
				_tcscpy_s(lpText, 256, lpszDefault);
			}
		}
		else
		{
			_tcscpy_s(lpText, 256, lpszDefault);
		}

		if(hKeyRetVal)
			RegCloseKey(hKeyRetVal);
	}
	catch(...)
	{
	}
	return TRUE;
#else
	return true;
#endif
}


BOOL CLogManager::GetMachineInfo(LPTSTR lpInfo)
{
#ifdef WIN32
	TCHAR lpszCPU[256];
	int	   lFrequency;
	SYSTEM_INFO   sysInfo;
	MEMORYSTATUS   memoryStatus;

	GetSystemInfo(&sysInfo);
	lFrequency = ReadRegKeyValue(_T("~MHz"),0L,_T("Hardware\\Description\\System\\CentralProcessor\\0"));
	ReadRegKeyValue(_T("ProcessorNameString"),_T(""),_T("Hardware\\Description\\System\\CentralProcessor\\0"), lpszCPU);

	memset   (&memoryStatus, 0, sizeof(MEMORYSTATUS));
	memoryStatus.dwLength = sizeof(MEMORYSTATUS);
	GlobalMemoryStatus(&memoryStatus);
	_stprintf_s(lpInfo, 256, _T("%s(%d×%d MHZ)\r\nPhysical memory:%dMB,Available physical memory:%dMB,Total memory:%dMB,Available memory:%dMB"), lpszCPU, sysInfo.dwNumberOfProcessors, lFrequency, memoryStatus.dwTotalPhys >> 20, memoryStatus.dwAvailPhys >> 20, memoryStatus.dwTotalPageFile >> 20, memoryStatus.dwAvailPageFile >> 20);

	return TRUE;
#else
	struct utsname uts;
	struct sysinfo sys;
	uname(&uts);
	sysinfo(&sys);
	_stprintf(lpInfo, ("Nodename: %s\r\nSystem: %s\r\nHardware: %s\r\nVersion: %s, %s\r\nToalRam: %luMB, FreeRam: %luMB\r\n"),
			uts.nodename, uts.sysname, uts.machine, uts.release, uts.version, sys.totalram>>20, sys.freeram>>20);

	return true;
#endif
}

BOOL CLogManager::CheckLogFile()
{
#ifdef WIN32
	if(m_hFile != INVALID_HANDLE_VALUE && m_hFile != NULL)
	{
		return TRUE;
	}
	else
	{
		int i;
		SYSTEMTIME st;
		TCHAR lpFilePath[256];
		//先清理一下多余的日志文件
		LogFileManage(_T("VernoxStorage*.log"));

		//把日志文件路径放到服务所在文件夹
		memset(lpFilePath, 0, 256 * sizeof(TCHAR));
		GetLocalTime(&st);
		_stprintf_s(lpFilePath, 256,_T("%s%s%04d%02d%02d%02d%02d%02d.log"), m_lpTraceDir, _T("VernoxStorage"),st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
		for(i = 0; i < 5;i++)
		{
			m_hFile = ::CreateFile(
				lpFilePath, 
				GENERIC_WRITE, 
				FILE_SHARE_READ | FILE_SHARE_WRITE, 
				NULL, 
				OPEN_ALWAYS, 
				FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, 
				HANDLE(NULL));
			if (INVALID_HANDLE_VALUE == m_hFile)
			{
				Sleep(10);
				continue;
			}
			break;
		}

		if(INVALID_HANDLE_VALUE != m_hFile)
		{
			DWORD dwSize,dwValue;
			dwValue = 0;
			dwSize = GetFileSize(m_hFile, NULL);
			if(dwSize==0)
			{
				//EF BB BF
				//char tcFileHead[4],lpMachineInfo[256], lpSystemInfo[256];
				/*ANSI 不用写文件头
				tcFileHead[0] = 0XEF;
				tcFileHead[1] = 0XBB;
				tcFileHead[2] = 0XBF;
				//tcFileHead=0xfeff;//UNICODE文件开头标志
				if(!WriteFile(m_hFile,&tcFileHead,3,&dwValue,NULL))
				{
					CloseHandle(m_hFile);
					return FALSE;
				}*/
				char lpMachineInfo[256], lpSystemInfo[256];

				//写入文件头
				memset(lpMachineInfo, 0, sizeof(lpMachineInfo));
				memset(lpSystemInfo, 0, sizeof(lpSystemInfo));
				GetMachineInfo(lpMachineInfo);
				GetOPSystemInfo(lpSystemInfo);

				//写入日志的格式化文件头信息
				_stprintf_s(m_lpszBuf, LOGBUFFER_SIZE,_T("Machine Info:%s\r\nOperating system Info:%s\r\n\r\n"),lpMachineInfo, lpSystemInfo);
				WriteFile(m_hFile, m_lpszBuf, _tcslen(m_lpszBuf), &dwValue, NULL);

				_tcscpy_s(m_lpszBuf, LOGBUFFER_SIZE, _T("Timestamp               Thread	Level    Code     FuncationName		Description"));
				WriteFile(m_hFile, m_lpszBuf, _tcslen(m_lpszBuf), &dwValue, NULL);
			}
			else
			{
				SetFilePointer(m_hFile, 0, NULL, FILE_END);
			}
		}
		return TRUE;
	}
	return FALSE;
#else
	if(m_pFile != NULL)
	{
		return true;
	}
	else
	{
		int i;
		struct tm *st;
		time_t currTime;
		TCHAR lpFilePath[256];
		//先清理一下多余的日志文件
		LogFileManage(("VernoxStorage"));

		//把日志文件路径放到服务所在文件夹
		memset(lpFilePath, 0, 256 * sizeof(TCHAR));
		currTime = time(NULL);
		st = localtime(&currTime);
		sprintf(lpFilePath, ("%s%s%04d%02d%02d%02d%02d%02d.log"), m_lpTraceDir, ("VernoxStorage"),
				st->tm_year+1900, st->tm_mon+1, st->tm_mday, st->tm_hour, st->tm_min, st->tm_sec);
		for(i = 0; i < 5;i++)
		{
			m_pFile = fopen(lpFilePath, "ab+");
			if (m_pFile == NULL)
			{
				usleep(10000);
				continue;
			}
			break;
		}

		if(m_pFile != NULL)
		{
			DWORD dwSize,dwValue;
			dwValue = 0;
			dwSize = GetFileSize(m_pFile, NULL);
			if(dwSize==0)
			{
				//EF BB BF
				//char tcFileHead[4],lpMachineInfo[256], lpSystemInfo[256];
				/*ANSI 不用写文件头
				tcFileHead[0] = 0XEF;
				tcFileHead[1] = 0XBB;
				tcFileHead[2] = 0XBF;
				//tcFileHead=0xfeff;//UNICODE文件开头标志
				if(!WriteFile(m_hFile,&tcFileHead,3,&dwValue,NULL))
				{
					CloseHandle(m_hFile);
					return false;
				}*/
				char lpMachineInfo[256], lpSystemInfo[256];

				//写入文件头
				memset(lpMachineInfo, 0, sizeof(lpMachineInfo));
				memset(lpSystemInfo, 0, sizeof(lpSystemInfo));
				GetMachineInfo(lpMachineInfo);

				//写入日志的格式化文件头信息
				_stprintf(m_lpszBuf,("%s\r\n\r\n"), lpMachineInfo);
				fwrite(m_lpszBuf, sizeof(TCHAR), _tcslen(m_lpszBuf), m_pFile);

				_tcscpy(m_lpszBuf, ("Timestamp Thread Level Code FuncationName Description"));
				fwrite(m_lpszBuf, sizeof(TCHAR), _tcslen(m_lpszBuf), m_pFile);
			}
			else
			{
				fseek(m_pFile, 0, SEEK_END);
			}
		}
		return true;
	}
	return false;
#endif
}

BOOL CLogManager::WriteLog(LPCTSTR szFuncationName, LONG dwThreadID, DWORD dwLevel, DWORD dwErrorCode, LPCTSTR szText)
{
#ifdef WIN32
	SYSTEMTIME	st;
	DWORD dwWriteLen, dwSize;
	try
	{
		CheckLogFile();
		if(m_hFile != INVALID_HANDLE_VALUE && m_hFile != NULL)
		{
			GetLocalTime(&st);
			if(dwThreadID == 0)
				dwThreadID = GetCurrentThreadId();
			_stprintf_s(m_lpszBuf, LOGBUFFER_SIZE,_T("\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d	% 2d   % 10d %s "),
				st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
				dwThreadID, dwLevel, dwErrorCode, szFuncationName);
			if(!WriteFile(m_hFile, m_lpszBuf, _tcslen(m_lpszBuf)*sizeof(TCHAR), &dwWriteLen, NULL))
			{
				::CloseHandle(m_hFile);
				m_hFile = INVALID_HANDLE_VALUE;
				return FALSE;
			}
			WriteFile(m_hFile, szText, _tcslen(szText)*sizeof(TCHAR), &dwWriteLen, NULL);
			dwSize = GetFileSize(m_hFile, NULL) ;
			if(m_pMemoryFileHead != NULL)
			{
				if(dwSize > m_pMemoryFileHead->m_nWriteTraceMaxSize)
				{
					::CloseHandle(m_hFile);
					m_hFile = INVALID_HANDLE_VALUE;
				}
			}
		}
	}
	catch (...)
	{
		::CloseHandle(m_hFile);
		m_hFile = INVALID_HANDLE_VALUE;
	}
	return TRUE;
#else
	DWORD dwSize;
	struct tm *st;
	struct timeval currTime;
	try
	{
		CheckLogFile();
		if(m_pFile != NULL)
		{
			gettimeofday(&currTime, 0);
			st = localtime(&currTime.tv_sec);
			if(dwThreadID == 0)
				dwThreadID = gettid();
			_stprintf(m_lpszBuf, ("\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d	% 2d   % 10d %s "),
					st->tm_year+1900, st->tm_mon+1, st->tm_mday, st->tm_hour, st->tm_min, st->tm_sec, (int)(currTime.tv_usec/1000),
					(int)dwThreadID, (int)dwLevel, (int)dwErrorCode, szFuncationName);
			if(_tcslen(m_lpszBuf) != fwrite(m_lpszBuf, sizeof(TCHAR), _tcslen(m_lpszBuf), m_pFile))
			{
				fclose(m_pFile);
				m_pFile = NULL;
				return false;
			}
			fwrite(szText, sizeof(TCHAR), _tcslen(szText), m_pFile);
			dwSize = GetFileSize(m_pFile);
			if(m_pMemoryFileHead != NULL)
			{
				if((int)dwSize > m_pMemoryFileHead->m_nWriteTraceMaxSize)
				{
					fclose(m_pFile);
					m_pFile = NULL;
				}
			}
		}
	}
	catch (...)
	{
		fclose(m_pFile);
		m_pFile = NULL;
	}
	return true;
#endif
}

BOOL CLogManager::LogFileManage(LPCTSTR pFileName)
{
#ifdef WIN32
	int nIndex, n;
	TCHAR lpFilePath[256];
	//把日志文件路径放到服务所在文件夹
	memset(lpFilePath, 0, 256 * sizeof(TCHAR));
	n = 0;
	_tcscpy_s(lpFilePath, 256, m_lpTraceDir);
	nIndex = _tcslen(lpFilePath);

	while(TRUE)
	{
		int nCount;
		BOOL bFind;
		DWORD nFileSize;
		HANDLE hFilefirst;
		FILETIME ftCreationTime;
		WIN32_FIND_DATA stFindFileData;

		_tcscpy_s(&lpFilePath[nIndex], 256 - nIndex, pFileName);
		bFind  = TRUE;
		hFilefirst = FindFirstFile(lpFilePath,&stFindFileData);
		if(hFilefirst == INVALID_HANDLE_VALUE)
		{
			return FALSE;
		}

		//使用当前时间作为初始创建时间
		GetSystemTimeAsFileTime(&ftCreationTime);

		nCount = 0;
		nFileSize = 0;
		while(bFind)
		{
			if((stFindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != FILE_ATTRIBUTE_DIRECTORY && bFind)
			{
				nCount++;
				nFileSize += stFindFileData.nFileSizeLow;
				if(stFindFileData.ftCreationTime.dwHighDateTime < ftCreationTime.dwHighDateTime || (stFindFileData.ftCreationTime.dwHighDateTime == ftCreationTime.dwHighDateTime && stFindFileData.ftCreationTime.dwLowDateTime < ftCreationTime.dwLowDateTime))
				{
					ftCreationTime = stFindFileData.ftCreationTime;
					_tcscpy_s(&lpFilePath[nIndex], 256 - nIndex, stFindFileData.cFileName);
				}
			}
			bFind = FindNextFile(hFilefirst,&stFindFileData);
		}
		FindClose(hFilefirst);

		//日志文件数量超过50个的只保留50个，空间超过的600MB的，也只保留600MB以内的
		if(nCount > 49 || nFileSize > 600*1024*1024)
		{
			n++;
			if(n > 10) //每次最多删除10个文件
			{
				return TRUE;
			}
			DeleteFile(lpFilePath);
		}
		else
		{
			return TRUE;
		}
	}

	return TRUE;
#else
	int nDirLength, nNameLength, n;
	TCHAR lpDirPath[256];
	TCHAR lpFilePath[256];
	//把日志文件路径放到服务所在文件夹
	memset(lpDirPath, 0, 256*sizeof(TCHAR));
	n = 0;
	_tcscpy(lpDirPath, m_lpTraceDir);
	nDirLength = _tcslen(lpDirPath);
	nNameLength = _tcslen(pFileName);
	memcpy(lpFilePath, lpDirPath, 256*sizeof(TCHAR));

	while(true)
	{
		int nCount;
		DWORD nFileSize;
		time_t tCreationTime;

		DIR *pDir;
		struct dirent *pEntry;
		struct stat stFileData;

		pDir = opendir(lpDirPath);
		if(pDir == NULL)
		{
			return false;
		}

		//使用当前时间作为初始创建时间
		tCreationTime = time(NULL);

		nCount = 0;
		nFileSize = 0;
		//找到创建时间最早的日志文件，优先删除
		while( (pEntry = readdir(pDir)) != NULL )
		{
			if(strcmp(".", pEntry->d_name) == 0 || strcmp("..", pEntry->d_name) == 0)
			{
				continue;
			}
			if(strncmp(pEntry->d_name, pFileName, nNameLength) != 0)
			{
				continue;
			}
			stat(pEntry->d_name, &stFileData);
			if(S_ISDIR(stFileData.st_mode))
			{

				continue;
			}
			nCount++;
			nFileSize += stFileData.st_size;

			if(stFileData.st_ctime < tCreationTime)
			{
				tCreationTime = stFileData.st_ctime;
				_tcscpy_s(&lpFilePath[nDirLength], 256-nDirLength, pEntry->d_name);
			}
		}
		closedir(pDir);


		//日志文件数量超过50个的只保留50个，空间超过的600MB的，也只保留600MB以内的
		if(nCount > 49 || nFileSize > 600*1024*1024)
		{
			n++;
			if(n > 10) //每次最多删除10个文件
			{
				return true;
			}
			remove(lpFilePath);
		}
		else
		{
			return true;
		}
	}

	return true;
#endif
}


#ifdef WIN32
unsigned int __stdcall CLogManager::WriteTraceThread(LPVOID lpParam)
{
	DWORD dwSize;
	char* lpFileAddr;
	TCHAR lpFilePath[256];
	CLogManager *pLogManager;
	HANDLE hTraceEvent, hFile;
	int i, nWritePos, nDelayTime;
	LPFILE_TRACEMEMFILEHEAD pTraceFileHead;

	Sleep(50);
	hFile			= INVALID_HANDLE_VALUE;
	pLogManager		= (CLogManager *)lpParam;
	pTraceFileHead	= (LPFILE_TRACEMEMFILEHEAD)pLogManager->m_pTraceFileAddr;
	hTraceEvent		= pLogManager->m_hTraceEvent;
	lpFileAddr		= pLogManager->m_pTraceFileAddr;
	nDelayTime		= pLogManager->m_pMemoryFileHead->m_nWriteTraceDelayTime * 1000;

	Trace0(_T("WriteTraceThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20010001 , _T("日志Writer线程启动！"));
	while(TRUE)
	{
		//等待时间，如果有必要就可以立即启动
		WaitForSingleObject(hTraceEvent, nDelayTime);
		try
		{
			//如果读写的位置相同，则表示没有需要写入的日志
			if(pTraceFileHead->m_nReadPos == pTraceFileHead->m_nWritePos)
			{
				//判断退出标志
				if(pLogManager->m_bExit)
				{
					break;
				}
				continue;
			}
			else
			{
				if(pTraceFileHead->m_nWritePos > MF_TRACE_FILE_SIZE || pTraceFileHead->m_nReadPos > MF_TRACE_FILE_SIZE)
				{
					Trace(_T("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010002, _T("日志线程检查到内存数据异常，nWritePos：%d、nReadPos：%d、nFileHeaderSize：%d、nFileTotalSize：%d"),
						pTraceFileHead->m_nWritePos, pTraceFileHead->m_nReadPos, pTraceFileHead->m_nFileHeaderSize, pTraceFileHead->m_nFileTotalSize);
					if(pTraceFileHead->m_nWritePos > MF_TRACE_FILE_SIZE)
					{
						pTraceFileHead->m_nWritePos = pTraceFileHead->m_nFileHeaderSize;
					}
					if(pTraceFileHead->m_nReadPos > MF_TRACE_FILE_SIZE)
					{
						pTraceFileHead->m_nReadPos = pTraceFileHead->m_nFileHeaderSize;
					}
				}

				if(hFile == INVALID_HANDLE_VALUE)
				{
					SYSTEMTIME st;
					pLogManager->LogFileManage(_T("VernoxService*.log"));
					memset(lpFilePath, 0, 256 * sizeof(TCHAR));
					GetLocalTime(&st);
					_stprintf_s(lpFilePath, 256,_T("%s%s%04d%02d%02d%02d%02d%02d.log"), pLogManager->m_lpTraceDir, _T("VernoxService"),st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
					for(i = 0; i < 5;i++)
					{
						hFile = ::CreateFile(
							lpFilePath, 
							GENERIC_WRITE, 
							FILE_SHARE_READ | FILE_SHARE_WRITE, 
							NULL, 
							OPEN_ALWAYS, 
							FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, 
							HANDLE(NULL));
						if (INVALID_HANDLE_VALUE == hFile)
						{
							Sleep(10);
							continue;
						}
						break;
					}

					if(INVALID_HANDLE_VALUE == hFile)
					{
						Trace(_T("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010003, _T("日志线程打开日志文件失败，文件路径：%s"), lpFilePath);
						continue;
					}

					dwSize = GetFileSize(hFile, NULL);
					if(dwSize==0)
					{
						//char tcFileHead[4],lpMachineInfo[256], lpSystemInfo[256], lpszBuf[512];
						/*tcFileHead[0] = 0XEF;
						tcFileHead[1] = 0XBB;
						tcFileHead[2] = 0XBF;
						//tcFileHead=0xfeff;//UNICODE文件开头标志
						WriteFile(hFile,&tcFileHead,3,&dwWrite,NULL);*/
						char lpMachineInfo[256], lpSystemInfo[256], lpszBuf[512];

						//写入文件头
						memset(lpMachineInfo, 0, sizeof(lpMachineInfo));
						memset(lpSystemInfo, 0, sizeof(lpSystemInfo));
						GetMachineInfo(lpMachineInfo);
						GetOPSystemInfo(lpSystemInfo);

						//写入日志的格式化文件头信息
						_stprintf_s(lpszBuf, LOGBUFFER_SIZE,_T("Machine Info:%s\r\nOperating system Info:%s\r\n\r\n"),lpMachineInfo, lpSystemInfo);
						WriteFile(hFile, lpszBuf, _tcslen(lpszBuf), &dwSize, NULL);

						_tcscpy_s(lpszBuf, LOGBUFFER_SIZE, _T("Timestamp               Thread	Level    Code     FuncationName		Description"));
						WriteFile(hFile, lpszBuf, _tcslen(lpszBuf), &dwSize, NULL);
					}
					else
					{
						SetFilePointer(hFile, 0, NULL, FILE_END);
					}
				}

				//开始写日志数据到文件中
				dwSize    = 0;
				nWritePos = pTraceFileHead->m_nWritePos;
				if(pTraceFileHead->m_nReadPos < nWritePos)
				{
					//直接写之间的内存到文件即可
					if(!WriteFile(hFile, lpFileAddr + pTraceFileHead->m_nReadPos, nWritePos - pTraceFileHead->m_nReadPos, &dwSize, NULL))
					{
						Trace(_T("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010004, _T("重做日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nWritePos：%d、dwWrite：%d"),
							lpFilePath, GetLastError(), pTraceFileHead->m_nReadPos, nWritePos, dwSize);
						CloseHandle(hFile);
						hFile = INVALID_HANDLE_VALUE;
					}
					else
					{
						//修改写入位置
						pTraceFileHead->m_nReadPos = nWritePos;
					}
				}
				else
				{
					//写入最后一段
					if(!WriteFile(hFile, lpFileAddr + pTraceFileHead->m_nReadPos, pTraceFileHead->m_nFileTotalSize - pTraceFileHead->m_nReadPos, &dwSize, NULL))
					{
						Trace(_T("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010005, _T("日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nFileTotalSize：%d、dwWrite：%d"),
							lpFilePath, GetLastError(), pTraceFileHead->m_nReadPos, pTraceFileHead->m_nFileTotalSize, dwSize);
						CloseHandle(hFile);
						hFile = INVALID_HANDLE_VALUE;
					}
					else
					{
						//再写入最开始的部分
						if(!WriteFile(hFile, lpFileAddr + pTraceFileHead->m_nFileHeaderSize, nWritePos - pTraceFileHead->m_nFileHeaderSize, &dwSize, NULL))
						{
							Trace(_T("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010006, _T("日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nWritePos：%d、nFileHeaderSize：%d、dwWrite：%d"),
								lpFilePath, GetLastError(), pTraceFileHead->m_nReadPos, nWritePos, pTraceFileHead->m_nFileHeaderSize, dwSize);
							CloseHandle(hFile);
							hFile = INVALID_HANDLE_VALUE;
							pTraceFileHead->m_nReadPos = pTraceFileHead->m_nFileHeaderSize;
						}
						else
						{
							//修改写入位置
							pTraceFileHead->m_nReadPos = nWritePos;
						}
					}

					if(hFile != INVALID_HANDLE_VALUE)
					{
						dwSize = GetFileSize(hFile, NULL);
						if(pLogManager->m_pMemoryFileHead != NULL)
						{
							if(dwSize > pLogManager->m_pMemoryFileHead->m_nWriteTraceMaxSize)
							{
								Trace(_T("WriteTraceThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20010007, _T("日志线程检查到日志写入已经达到设定值，切换日志文件！文件路径：%s，大小：%d"), lpFilePath, dwSize);
								CloseHandle(hFile);
								hFile = INVALID_HANDLE_VALUE;
							}
						}
					}
				}

				//判断退出标志
				if(pLogManager->m_bExit)
				{
					break;
				}
			}
		}
		catch(...)
		{
			Trace(_T("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010099, _T("重做日志线程出现异常错误！文件路径：%s，错误码：%d"), lpFilePath, GetLastError());
			CloseHandle(hFile);
			hFile = INVALID_HANDLE_VALUE;
		}
	}

	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(hFile);
		hFile = INVALID_HANDLE_VALUE;
	}
	Trace0(_T("WriteTraceThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20010100 , _T("日志Writer线程结束！"));
	//_endthreadex(NULL);
	return 0;
}
#else
void* CLogManager::WriteTraceThread(LPVOID lpParam)
{
	char* lpFileAddr;
	sem_t* pTraceEvent;
	TCHAR lpFilePath[256];
	CLogManager *pLogManager;
	DWORD dwSize, dwWriteSize;
	int i, nWritePos, nDelayTime;
	LPFILE_TRACEMEMFILEHEAD pTraceFileHead;
	FILE	*pFile;

	Sleep(50);
	pFile			= NULL;
	pLogManager		= (CLogManager *)lpParam;
	pTraceFileHead	= (LPFILE_TRACEMEMFILEHEAD)pLogManager->m_pTraceFileAddr;
	pTraceEvent		= pLogManager->m_pTraceEvent;
	lpFileAddr		= pLogManager->m_pTraceFileAddr;
	nDelayTime		= pLogManager->m_pMemoryFileHead->m_nWriteTraceDelayTime * 1000;

	Trace0(("WriteTraceThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20010001 , ("日志Writer线程启动！"));
	while(true)
	{
		//等待时间，如果有必要就可以立即启动
		WaitForSingleObject(pTraceEvent, nDelayTime);
		try
		{
			//如果读写的位置相同，则表示没有需要写入的日志
			if(pTraceFileHead->m_nReadPos == pTraceFileHead->m_nWritePos)
			{
				//判断退出标志
				if(pLogManager->m_bExit)
				{
					break;
				}
				continue;
			}
			else
			{
				if(pTraceFileHead->m_nWritePos > MF_TRACE_FILE_SIZE || pTraceFileHead->m_nReadPos > MF_TRACE_FILE_SIZE)
				{
					Trace(_T("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010002, _T("日志线程检查到内存数据异常，nWritePos：%d、nReadPos：%d、nFileHeaderSize：%d、nFileTotalSize：%d"),
						pTraceFileHead->m_nWritePos, pTraceFileHead->m_nReadPos, pTraceFileHead->m_nFileHeaderSize, pTraceFileHead->m_nFileTotalSize);
					if(pTraceFileHead->m_nWritePos > MF_TRACE_FILE_SIZE)
					{
						pTraceFileHead->m_nWritePos = pTraceFileHead->m_nFileHeaderSize;
					}
					if(pTraceFileHead->m_nReadPos > MF_TRACE_FILE_SIZE)
					{
						pTraceFileHead->m_nReadPos = pTraceFileHead->m_nFileHeaderSize;
					}
				}

				if(pFile == NULL)
				{
					struct tm *st;
					time_t currTime;
					pLogManager->LogFileManage(("VernoxService*"));
					memset(lpFilePath, 0, 256 * sizeof(TCHAR));
					currTime = time(NULL);
					st = localtime(&currTime);
					_stprintf(lpFilePath, ("%s%s%04d%02d%02d%02d%02d%02d.log"), pLogManager->m_lpTraceDir, ("VernoxService"),
							st->tm_year+1900, st->tm_mon+1, st->tm_mday, st->tm_hour, st->tm_min, st->tm_sec);
					for(i = 0; i < 5;i++)
					{
						pFile = fopen(lpFilePath, "wb+");
						if (pFile == NULL)
						{
							Sleep(10);
							continue;
						}
						break;
					}

					if(pFile == NULL)
					{
						Trace(("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010003, ("日志线程打开日志文件失败，文件路径：%s"), lpFilePath);
						continue;
					}

					dwSize = GetFileSize(pFile);
					if(dwSize==0)
					{
						//char tcFileHead[4],lpMachineInfo[256], lpSystemInfo[256], lpszBuf[512];
						/*tcFileHead[0] = 0XEF;
						tcFileHead[1] = 0XBB;
						tcFileHead[2] = 0XBF;
						//tcFileHead=0xfeff;//UNICODE文件开头标志
						WriteFile(hFile,&tcFileHead,3,&dwWrite,NULL);*/
						char lpMachineInfo[256], lpSystemInfo[256], lpszBuf[512];

						//写入文件头
						memset(lpMachineInfo, 0, sizeof(lpMachineInfo));
						memset(lpSystemInfo, 0, sizeof(lpSystemInfo));
						GetMachineInfo(lpMachineInfo);
						//GetOPSystemInfo(lpSystemInfo);

						//写入日志的格式化文件头信息
						//_stprintf(lpszBuf, ("Machine Info:%s\r\nOperating system Info:%s\r\n\r\n"),lpMachineInfo, lpSystemInfo);
						_stprintf(lpszBuf, ("%s\r\n\r\n"), lpMachineInfo);
						fwrite(lpszBuf, sizeof(char), _tcslen(lpszBuf), pFile);

						_tcscpy(lpszBuf, ("Timestamp               Thread	Level    Code     FuncationName		Description"));
						fwrite(lpszBuf, sizeof(char), _tcslen(lpszBuf), pFile);
					}
					else
					{
						fseek(pFile, 0, SEEK_END);
					}
				}

				//开始写日志数据到文件中
				dwSize    = 0;
				dwWriteSize = 0;
				nWritePos = pTraceFileHead->m_nWritePos;
				if(pTraceFileHead->m_nReadPos < nWritePos)
				{
					//直接写之间的内存到文件即可
					dwWriteSize = nWritePos - pTraceFileHead->m_nReadPos;
					if(dwWriteSize != fwrite(lpFileAddr + pTraceFileHead->m_nReadPos, 1, dwWriteSize, pFile))
					{
						Trace(("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010004, ("重做日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nWritePos：%d、dwWrite：%d"),
								lpFilePath, GetLastError(), pTraceFileHead->m_nReadPos, nWritePos, dwSize);
						fclose(pFile);
						pFile = NULL;
					}
					else
					{
						//修改写入位置
						pTraceFileHead->m_nReadPos = nWritePos;
					}
				}
				else
				{
					//写入最后一段
					dwWriteSize = pTraceFileHead->m_nFileTotalSize - pTraceFileHead->m_nReadPos;
					if(dwWriteSize != fwrite(lpFileAddr + pTraceFileHead->m_nReadPos, 1, dwWriteSize, pFile))
					{
						Trace(("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010005, ("日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nFileTotalSize：%d、dwWrite：%d"),
								lpFilePath, GetLastError(), pTraceFileHead->m_nReadPos, pTraceFileHead->m_nFileTotalSize, dwSize);
						fclose(pFile);
						pFile = NULL;
					}
					else
					{
						//再写入最开始的部分
						dwWriteSize = nWritePos - pTraceFileHead->m_nFileHeaderSize;
						if(dwWriteSize != fwrite(lpFileAddr + pTraceFileHead->m_nFileHeaderSize, 1, dwWriteSize, pFile))
						{
							Trace(("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010006, ("日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nWritePos：%d、nFileHeaderSize：%d、dwWrite：%d"),
									lpFilePath, GetLastError(), pTraceFileHead->m_nReadPos, nWritePos, pTraceFileHead->m_nFileHeaderSize, dwSize);
							fclose(pFile);
							pFile = NULL;
							pTraceFileHead->m_nReadPos = pTraceFileHead->m_nFileHeaderSize;
						}
						else
						{
							//修改写入位置
							pTraceFileHead->m_nReadPos = nWritePos;
						}
					}

					if(pFile != NULL)
					{
						dwSize = GetFileSize(pFile);
						if(pLogManager->m_pMemoryFileHead != NULL)
						{
							if((int)dwSize > pLogManager->m_pMemoryFileHead->m_nWriteTraceMaxSize)
							{
								Trace(("WriteTraceThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20010007, ("日志线程检查到日志写入已经达到设定值，切换日志文件！文件路径：%s，大小：%d"), lpFilePath, dwSize);
								fclose(pFile);
								pFile = NULL;
							}
						}
					}
				}
				if(pFile != NULL)
				{
					fflush(pFile);
				}
				//判断退出标志
				if(pLogManager->m_bExit)
				{
					break;
				}
			}
		}
		catch(...)
		{
			Trace(("WriteTraceThread"), MF_TRACE_LEVEL_FAILED, 20010099, ("重做日志线程出现异常错误！文件路径：%s，错误码：%d"), lpFilePath, GetLastError());
			fclose(pFile);
			pFile = NULL;
		}
	}

	if(pFile != NULL)
	{
		fclose(pFile);
		pFile = NULL;
	}
	Trace0(("WriteTraceThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20010100 , ("日志Writer线程结束！"));
	//_endthreadex(NULL);
	return 0;
}
#endif

#ifdef WIN32
unsigned int __stdcall CLogManager::WriteLogThread(LPVOID lpParam)
{
	DWORD dwSize;
	char* lpFileAddr;
	TCHAR lpFilePath[256];
	HANDLE hLogEvent, hFile;
	CLogManager *pLogManager;
	int i, nWritePos, nDelayTime, nActiveLogFiles;
	LPFILE_TRACEMEMFILEHEAD pLogFileHead;

	Sleep(50);
	memset(lpFilePath, 0, 256 * sizeof(TCHAR));
	hFile			= INVALID_HANDLE_VALUE;
	pLogManager		= (CLogManager *)lpParam;
	pLogFileHead	= (LPFILE_TRACEMEMFILEHEAD)pLogManager->m_pLogFileAddr;
	hLogEvent		= pLogManager->m_hLogEvent;
	lpFileAddr		= pLogManager->m_pLogFileAddr;
	nDelayTime		= pLogManager->m_pMemoryFileHead->m_nWriteUndoDelayTime * 1000;
	nActiveLogFiles = pLogManager->m_pMemoryFileHead->m_nActiveLogFiles;
	if (nActiveLogFiles < 20)
	{
		Trace(_T("WriteLogThread"), MF_TRACE_LEVEL_WARNING, 20011001, _T("设置的活动重做日志数量小于最小值（20），已强制更改为最小值（20）。设置值为：%d"), nActiveLogFiles);
		nActiveLogFiles = 20;
	}

	Trace0(_T("WriteLogThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20011002, _T("重做日志Writer线程启动！"));
	while(TRUE)
	{
		//等待时间，如果有必要就可以立即启动
		WaitForSingleObject(hLogEvent, nDelayTime);
		try
		{
			//如果读写的位置相同，则表示没有需要写入的日志
			if(pLogFileHead->m_nReadPos == pLogFileHead->m_nWritePos)
			{
				//判断退出标志
				if(pLogManager->m_bExit)
				{
					break;
				}
				continue;
			}
			else
			{
				//检查数据有效性
				if(pLogFileHead->m_nWritePos > MF_TRACE_FILE_SIZE || pLogFileHead->m_nReadPos > MF_TRACE_FILE_SIZE)
				{
					Trace(_T("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011003, _T("重做日志线程检查到内存数据异常，nWritePos：%d、nReadPos：%d、nFileHeaderSize：%d、nFileTotalSize：%d"), 
						pLogFileHead->m_nWritePos, pLogFileHead->m_nReadPos, pLogFileHead->m_nFileHeaderSize, pLogFileHead->m_nFileTotalSize);

					if(pLogFileHead->m_nWritePos > MF_TRACE_FILE_SIZE)
					{
						pLogFileHead->m_nWritePos = pLogFileHead->m_nFileHeaderSize;
					}
					if(pLogFileHead->m_nReadPos > MF_TRACE_FILE_SIZE)
					{
						pLogFileHead->m_nReadPos = pLogFileHead->m_nFileHeaderSize;
					}
				}
				if(hFile == INVALID_HANDLE_VALUE)
				{
					MF_REDOLOGFILEHEAD stRedoLogFileHead;
					memset(&stRedoLogFileHead, 0, sizeof(MF_REDOLOGFILEHEAD));
					if(pLogManager->m_pMemoryFileHead == NULL)
					{
						Trace0(_T("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011004, _T("系统文件内存头指针为空，无法写重做日志！"));
						continue;
					}
					else
					{
						stRedoLogFileHead.m_usDatabaseGuid = pLogManager->m_pMemoryFileHead->m_usDatabaseGuid;
						stRedoLogFileHead.m_nSequenceNO = pLogManager->m_pMemoryFileHead->m_nRedoLogMaxID;
						if (stRedoLogFileHead.m_nSequenceNO > nActiveLogFiles)
						{
							_stprintf_s(lpFilePath, 256,_T("%s%s%d.log"), pLogManager->m_lpRedoDir, _T("REDO"), stRedoLogFileHead.m_nSequenceNO - nActiveLogFiles);
							if (::DeleteFile(lpFilePath))
							{
								Trace(_T("WriteLogThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20011005, _T("删除重做日志文件：%s"), lpFilePath);
							} 
							else
							{
								Trace(_T("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011006, _T("删除重做日志文件失败，错误码：%d，文件路径：%s"), GetLastError(), lpFilePath);
							}
						}
						pLogManager->m_pMemoryFileHead->m_nRedoLogMaxID++;

						strcpy_s(stRedoLogFileHead.m_lpszFileFlag, 14, "VernoxLog");
						stRedoLogFileHead.m_nVersion	= 1;
						GetSystemTimeAsFileTime(&stRedoLogFileHead.m_ftCreateTime);

						memset(lpFilePath, 0, 256 * sizeof(TCHAR));
						_stprintf_s(lpFilePath, 256,_T("%s%s%d.log"), pLogManager->m_lpRedoDir, _T("REDO"), stRedoLogFileHead.m_nSequenceNO);
						for(i = 0; i < 100;i++)
						{
							hFile = ::CreateFile(
								lpFilePath, 
								GENERIC_WRITE, 
								FILE_SHARE_READ | FILE_SHARE_WRITE, 
								NULL, 
								CREATE_ALWAYS, 
								FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, 
								HANDLE(NULL));
							if (INVALID_HANDLE_VALUE == hFile)
							{
								Sleep(10);
								continue;
							}
							break;
						}

						if(INVALID_HANDLE_VALUE == hFile)
						{
							Trace(_T("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011007, _T("重做日志线程打开日志文件失败，可能会造成数据服务被卡死，文件路径：%s"), lpFilePath);
							continue;
						}

						dwSize = GetFileSize(hFile, NULL);
						if(dwSize==0)
						{
							//写入文件标识头
							WriteFile(hFile, &stRedoLogFileHead, sizeof(stRedoLogFileHead), &dwSize, NULL);
						}
						else
						{
							SetFilePointer(hFile, 0, NULL, FILE_END);
						}
					}
				}

				//开始写日志数据到文件中
				dwSize    = 0;
				nWritePos = pLogFileHead->m_nWritePos;
				if(pLogFileHead->m_nReadPos < nWritePos)
				{
					//直接写之间的内存到文件即可
					if(!WriteFile(hFile, lpFileAddr + pLogFileHead->m_nReadPos, nWritePos - pLogFileHead->m_nReadPos, &dwSize, NULL))
					{
						Trace(_T("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011008, _T("重做日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nWritePos：%d、dwWrite：%d"),
							lpFilePath, GetLastError(), pLogFileHead->m_nReadPos, nWritePos, dwSize);
						CloseHandle(hFile);
						hFile = INVALID_HANDLE_VALUE;
					}
					else
					{
						//修改写入位置
						pLogFileHead->m_nReadPos = nWritePos;
					}
				}
				else
				{
					//写入最后一段
					if(!WriteFile(hFile, lpFileAddr + pLogFileHead->m_nReadPos, pLogFileHead->m_nFileTotalSize - pLogFileHead->m_nReadPos, &dwSize, NULL))
					{
						Trace(_T("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011009, _T("重做日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nFileTotalSize：%d、dwWrite：%d"),
							lpFilePath, GetLastError(), pLogFileHead->m_nReadPos, pLogFileHead->m_nFileTotalSize, dwSize);
						CloseHandle(hFile);
						hFile = INVALID_HANDLE_VALUE;
					}
					else
					{
						//再写入最开始的部分
						if(!WriteFile(hFile, lpFileAddr + pLogFileHead->m_nFileHeaderSize, nWritePos - pLogFileHead->m_nFileHeaderSize, &dwSize, NULL))
						{
							Trace(_T("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 200110010, _T("重做日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nWritePos：%d、nFileHeaderSize：%d、dwWrite：%d"),
								lpFilePath, GetLastError(), pLogFileHead->m_nReadPos, nWritePos, pLogFileHead->m_nFileHeaderSize, dwSize);
							CloseHandle(hFile);
							hFile = INVALID_HANDLE_VALUE;
							pLogFileHead->m_nReadPos = pLogFileHead->m_nFileHeaderSize;
						}
						else
						{
							//修改写入位置
							pLogFileHead->m_nReadPos = nWritePos;
						}
					}

					if(hFile != INVALID_HANDLE_VALUE && pLogFileHead->m_bWriteFinishFlag == 0)
					{
						dwSize = GetFileSize(hFile, NULL);
						if(pLogManager->m_pMemoryFileHead != NULL)
						{
							if(dwSize > pLogManager->m_pMemoryFileHead->m_nWriteUndoMaxSize)
							{
								Trace(_T("WriteLogThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 200110011, _T("重做日志线程检查到日志写入已经达到设定值，切换日志文件！文件路径：%s，大小：%d"), lpFilePath, dwSize);
								CloseHandle(hFile);
								hFile = INVALID_HANDLE_VALUE;
							}
						}
					}
				}

				//判断退出标志
				if(pLogManager->m_bExit)
				{
					break;
				}
			}
		}
		catch(...)
		{
			Trace(_T("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011099, _T("重做日志线程出现异常错误！文件路径：%s，错误码：%d"), lpFilePath, GetLastError());
			CloseHandle(hFile);
			hFile = INVALID_HANDLE_VALUE;
		}
	}

	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(hFile);
		hFile = INVALID_HANDLE_VALUE;
	}
	Trace0(_T("WriteLogThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20011100 , _T("重做日志Writer线程结束！"));
	//_endthreadex(NULL);
	return 0;
}
#else
void* CLogManager::WriteLogThread(LPVOID lpParam)
{
	char* lpFileAddr;
	sem_t* pLogEvent;
	TCHAR lpFilePath[256];
	CLogManager *pLogManager;
	DWORD dwSize, dwWriteSize;
	int i, nWritePos, nDelayTime;
	LPFILE_TRACEMEMFILEHEAD pLogFileHead;
	FILE* pFile;

	Sleep(50);
	memset(lpFilePath, 0, 256 * sizeof(TCHAR));
	pFile				= NULL;
	pLogManager		= (CLogManager *)lpParam;
	pLogFileHead	= (LPFILE_TRACEMEMFILEHEAD)pLogManager->m_pLogFileAddr;
	pLogEvent		= pLogManager->m_pLogEvent;
	lpFileAddr		= pLogManager->m_pLogFileAddr;
	nDelayTime		= pLogManager->m_pMemoryFileHead->m_nWriteUndoDelayTime * 1000;

	Trace0(("WriteLogThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20011001 , ("重做日志Writer线程启动！"));
	while(true)
	{
		//等待时间，如果有必要就可以立即启动
		WaitForSingleObject(pLogEvent, nDelayTime);
		try
		{
			//如果读写的位置相同，则表示没有需要写入的日志
			if(pLogFileHead->m_nReadPos == pLogFileHead->m_nWritePos)
			{
				//判断退出标志
				if(pLogManager->m_bExit)
				{
					break;
				}
				continue;
			}
			else
			{
				//检查数据有效性
				if(pLogFileHead->m_nWritePos > MF_TRACE_FILE_SIZE || pLogFileHead->m_nReadPos > MF_TRACE_FILE_SIZE)
				{
					Trace(("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011002, ("重做日志线程检查到内存数据异常，nWritePos：%d、nReadPos：%d、nFileHeaderSize：%d、nFileTotalSize：%d"),
							pLogFileHead->m_nWritePos, pLogFileHead->m_nReadPos, pLogFileHead->m_nFileHeaderSize, pLogFileHead->m_nFileTotalSize);

					if(pLogFileHead->m_nWritePos > MF_TRACE_FILE_SIZE)
					{
						pLogFileHead->m_nWritePos = pLogFileHead->m_nFileHeaderSize;
					}
					if(pLogFileHead->m_nReadPos > MF_TRACE_FILE_SIZE)
					{
						pLogFileHead->m_nReadPos = pLogFileHead->m_nFileHeaderSize;
					}
				}
				if(pFile == NULL)
				{
					MF_REDOLOGFILEHEAD stRedoLogFileHead;
					memset(&stRedoLogFileHead, 0, sizeof(MF_REDOLOGFILEHEAD));
					if(pLogManager->m_pMemoryFileHead == NULL)
					{
						Trace0(("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011003, ("系统文件内存头指针为空，无法写重做日志！"));
						continue;
					}
					else
					{
						stRedoLogFileHead.m_nSequenceNO = pLogManager->m_pMemoryFileHead->m_nRedoLogMaxID;
						pLogManager->m_pMemoryFileHead->m_nRedoLogMaxID++;

						strcpy(stRedoLogFileHead.m_lpszFileFlag, "VernoxLog");
						stRedoLogFileHead.m_nVersion	= 1;
						GetSystemTimeAsFileTime(&stRedoLogFileHead.m_ftCreateTime);

						memset(lpFilePath, 0, 256 * sizeof(TCHAR));
						_stprintf(lpFilePath, ("%s%s%d.log"), pLogManager->m_lpRedoDir, ("REDO"), stRedoLogFileHead.m_nSequenceNO);
						for(i = 0; i < 100;i++)
						{
							pFile = fopen(lpFilePath, "wb+");
							if (pFile == NULL)
							{
								Sleep(10);
								continue;
							}
							break;
						}

						if(pFile == NULL)
						{
							Trace(("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011004, ("重做日志线程打开日志文件失败，可能会造成数据服务被卡死，文件路径：%s"), lpFilePath);
							continue;
						}

						dwSize = GetFileSize(pFile);
						if(dwSize==0)
						{
							//写入文件标识头
							fwrite(&stRedoLogFileHead, 1, sizeof(stRedoLogFileHead), pFile);
						}
						else
						{
							fseek(pFile, 0, SEEK_END);
						}
					}
				}

				//开始写日志数据到文件中
				dwSize    = 0;
				dwWriteSize = 0;
				nWritePos = pLogFileHead->m_nWritePos;
				if(pLogFileHead->m_nReadPos < nWritePos)
				{
					//直接写之间的内存到文件即可
					dwWriteSize = nWritePos - pLogFileHead->m_nReadPos;
					if(dwWriteSize != fwrite(lpFileAddr + pLogFileHead->m_nReadPos, 1, dwWriteSize, pFile))
					{
						Trace(("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011005, ("重做日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nWritePos：%d、dwWrite：%d"),
								lpFilePath, GetLastError(), pLogFileHead->m_nReadPos, nWritePos, dwSize);
						fclose(pFile);
						pFile = NULL;
					}
					else
					{
						//修改写入位置
						pLogFileHead->m_nReadPos = nWritePos;
					}
				}
				else
				{
					//写入最后一段
					dwWriteSize = pLogFileHead->m_nFileTotalSize - pLogFileHead->m_nReadPos;
					if(dwWriteSize != fwrite(lpFileAddr + pLogFileHead->m_nReadPos, 1, dwWriteSize, pFile))
					{
						Trace(("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011006, ("重做日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nFileTotalSize：%d、dwWrite：%d"),
								lpFilePath, GetLastError(), pLogFileHead->m_nReadPos, pLogFileHead->m_nFileTotalSize, dwSize);
						fclose(pFile);
						pFile = NULL;
					}
					else
					{
						//再写入最开始的部分
						dwWriteSize = nWritePos - pLogFileHead->m_nFileHeaderSize;
						if(dwWriteSize != fwrite(lpFileAddr + pLogFileHead->m_nFileHeaderSize, 1, dwWriteSize, pFile))
						{
							Trace(("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011007, ("重做日志线程写入数据失败！文件路径：%s，错误码：%d，nReadPos：%d、nWritePos：%d、nFileHeaderSize：%d、dwWrite：%d"),
									lpFilePath, GetLastError(), pLogFileHead->m_nReadPos, nWritePos, pLogFileHead->m_nFileHeaderSize, dwSize);
							fclose(pFile);
							pFile = NULL;
							pLogFileHead->m_nReadPos = pLogFileHead->m_nFileHeaderSize;
						}
						else
						{
							//修改写入位置
							pLogFileHead->m_nReadPos = nWritePos;
						}
					}

					if(pFile != NULL && pLogFileHead->m_bWriteFinishFlag == 0)
					{
						dwSize = GetFileSize(pFile);
						if(pLogManager->m_pMemoryFileHead != NULL)
						{
							if((int)dwSize > pLogManager->m_pMemoryFileHead->m_nWriteUndoMaxSize)
							{
								Trace(("WriteLogThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20011008, ("重做日志线程检查到日志写入已经达到设定值，切换日志文件！文件路径：%s，大小：%d"), lpFilePath, dwSize);
								fclose(pFile);
								pFile = NULL;
							}
						}
					}
				}
				if(pFile != NULL)
				{
					fflush(pFile);
				}
				//判断退出标志
				if(pLogManager->m_bExit)
				{
					break;
				}
			}
		}
		catch(...)
		{
			Trace(("WriteLogThread"), MF_TRACE_LEVEL_FAILED, 20011099, ("重做日志线程出现异常错误！文件路径：%s，错误码：%d"), lpFilePath, GetLastError());
			fclose(pFile);
			pFile = NULL;
		}
	}

	if(pFile != NULL)
	{
		fclose(pFile);
		pFile = NULL;
	}
	Trace0(("WriteLogThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 20011100 , ("重做日志Writer线程结束！"));
	//_endthreadex(NULL);
	return 0;
}
#endif
