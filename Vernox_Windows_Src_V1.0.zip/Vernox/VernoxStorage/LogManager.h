﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "stdafx.h"
#ifdef WIN32
#include "MemDBCommonDef.h"
#endif

class CLogManager
{
private:
	int	  												m_nNum;
#ifdef WIN32
	HANDLE												m_hFile;
#else
	FILE*												m_pFile;
#endif
	LPTSTR												m_lpTraceDir;		//日志目录文件夹
	LPTSTR												m_lpRedoDir;		//重做日志文件夹
	LPTSTR												m_lpszBuf;

	char*												m_pTraceFileAddr;	//日志内存文件指针
#ifdef WIN32
	HANDLE												m_hTraceFile;		//日志内存文件句柄
	HANDLE												m_hTraceEvent;		//当空间写满40%时设置此事件，否则按照每3秒写一次的方式进行；
#else
	int													m_nTraceShmid;		//日志共享内存id
	sem_t*												m_pTraceEvent;		//当空间写满40%时设置此事件，否则按照每3秒写一次的方式进行；
#endif

	char*												m_pLogFileAddr;		//修改日志内存文件指针
#ifdef WIN32
	HANDLE												m_hLogFile;			//修改日志内存文件句柄
	HANDLE												m_hLogEvent;		//当空间写满40%时设置此事件，否则按照每3秒写一次的方式进行；
#else
	int													m_nLogShmid;		//修改日志共享内存id
	sem_t*												m_pLogEvent;		//当空间写满40%时设置此事件，否则按照每3秒写一次的方式进行；
#endif
	
	LPSYSTEMFILEHEAD									m_pMemoryFileHead;	//系统头文件的头数据块

	BOOL												m_bExit;			//软件退出
	friend	void InitLogSystem();
	friend  void SetLogSystemFileHead(LPSYSTEMFILEHEAD	pMemoryFileHead);
private:
	CLogManager();
	CLogManager(const CLogManager &);
	CLogManager & operator = (const CLogManager &);
	virtual ~CLogManager(void);
	static CLogManager * m_pSinstance;

	BOOL Init();
#ifdef WIN32
	BOOL InitLogEnvironment(PSECURITY_DESCRIPTOR &pSecDescriptor);
#else
	BOOL InitLogEnvironment();
#endif
	BOOL CheckLogFile();
	BOOL LogFileManage(LPCTSTR pFileName);
	void SetSystemFileHead(LPSYSTEMFILEHEAD	pMemoryFileHead)
	{
		m_pMemoryFileHead = pMemoryFileHead;
		if(m_pMemoryFileHead == NULL)
		{
			Sleep(10);
			//让后台写日志的线程先退出
			m_bExit = true;
#ifdef WIN32
			SetEvent(m_hLogEvent);
			SetEvent(m_hTraceEvent);
#else
			sem_post(m_pTraceEvent);
			sem_post(m_pLogEvent);
#endif
			Sleep(10);
			Sleep(10);
		}
		else
		{
			//创建对应线程
#ifdef WIN32
			m_hWriteTraceThread = (HANDLE)_beginthreadex(NULL, 0, WriteTraceThread, this, 0, NULL);
			m_hWriteLogThread = (HANDLE)_beginthreadex(NULL, 0, WriteLogThread, this, 0, NULL);
#else
			pthread_create(&m_thWriteTraceThread, NULL, WriteTraceThread, this);
			pthread_create(&m_thWriteLogThread, NULL, WriteLogThread, this);
#endif
		}
	}
	static BOOL GetMachineInfo(LPTSTR lpInfo);
	static BOOL GetOPSystemInfo(LPTSTR lpInfo);
	static BOOL ReadRegKeyValue(LPCTSTR lszpValueName, LPCTSTR lpszDefault, LPCTSTR lpszSubKey, LPTSTR lpText);
	static int ReadRegKeyValue(LPCTSTR lszpValueName, int dwDefault, LPCTSTR lpszSubKey);

#ifdef WIN32
	HANDLE m_hWriteTraceThread;
	HANDLE m_hWriteLogThread;
	static unsigned int __stdcall WriteTraceThread(LPVOID lpParam);
	static unsigned int __stdcall WriteLogThread(LPVOID lpParam);
#else
	pthread_t	m_thWriteTraceThread;
	pthread_t	m_thWriteLogThread;
	static void* WriteTraceThread(LPVOID lpParam);
	static void* WriteLogThread(LPVOID lpParam);
#endif
public:
	static CLogManager & instance();
	static void DestoryInstance();
	BOOL WriteLog(LPCTSTR szFuncationName, LONG dwThreadID, DWORD dwLevel, DWORD dwErrorCode, LPCTSTR szText);
};
