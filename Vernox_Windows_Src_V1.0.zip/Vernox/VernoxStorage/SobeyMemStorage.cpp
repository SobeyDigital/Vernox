﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// SobeyMemStorage.cpp : WinMain 的实现

#include "stdafx.h"
  
#ifdef WIN32
#include "resource.h"
#include "SobeyMemStorage_i.h"
#include <stdio.h>
#include "MemDBCommonDef.h"
#include <winsock2.h>
#pragma comment(lib,"ws2_32.lib")
#else
#include "Resource.h"
#include <cstdlib>
#include <signal.h>
static bool g_bEixt;

void stopsignal(int signalnum)
{
	g_bEixt = true;
}
#endif

#ifdef WIN32
extern int MyExceptionHandler(ULONG ulCode, EXCEPTION_POINTERS* lpExceptionPointer);
#endif
extern void InitLogSystem();
extern void ExitLogSystem();
extern void SetLogSystemFileHead(LPSYSTEMFILEHEAD	pMemoryFileHead);
extern void Trace0(LPCTSTR szFuncationName, LONG  lLogLevel, LONG lLogErrorCode, LPCTSTR szLog);
extern void Trace(LPCTSTR szFuncationName, LONG  lLogLevel, LONG lLogErrorCode, const char *fmt, ... );

#ifdef WIN32
typedef struct stu_FILEINFO
{
	HANDLE			m_hMemoryFile;						//内存文件句柄
	HANDLE			m_hFile;							//物理文件句柄
	char*			m_pFileAddr;						//内存文件映射地址
	char			m_lpszFilePath[256];				//物理文件路径
	char			m_lpszMemFileName[64];				//内存文件名
	char			m_bFileNo;                          //文件编号
	char			m_bFileType;                        //文件类型，1：系统文件、2：数据文件、3：B树索引文件、4：KV索引文件
	long long		m_nTimestamp;						//上次保存时的时间戳
	LARGE_INTEGER	m_liFileSize;						//文件大小
	long long *		m_pLoadSize;						//文件加载大小指针
	USHORT			m_usDatabaseGuid;					//数据库唯一标识
	stu_FILEINFO *	m_pNext;							//下一个文件
}FILEINFO, *LPFILEINFO;
#else
typedef struct stu_FILEINFO
{
	int				m_nShmId;						//内存文件句柄
	FILE*			m_pFile;						//物理文件句柄
	char*			m_pFileAddr;					//内存文件映射地址
	TCHAR			m_lpszFilePath[256];			//物理文件路径
	TCHAR			m_lpszMemFileName[64];			//内存文件名
	char			m_bFileNo;                    	//文件编号
	char			m_bFileType;                  	//文件类型，1：系统文件、2：数据文件、3：B树索引文件、4：KV索引文件
	long long		m_nTimestamp;					//上次保存时的时间戳
	LARGE_INTEGER	m_liFileSize;					//文件大小
	long long *		m_pLoadSize;						//文件加载大小指针
	USHORT			m_usDatabaseGuid;				//数据库唯一标识
	stu_FILEINFO *	m_pNext;						//下一个文件
}FILEINFO, *LPFILEINFO;
#endif

extern CRITICAL_SECTION g_CritTrace;

#ifdef WIN32
class CSobeyMemStorageModule : public CAtlServiceModuleT< CSobeyMemStorageModule, IDS_SERVICENAME >
#else
class CSobeyMemStorageModule 
#endif
{
protected:
#ifdef WIN32
	HANDLE					m_hEvent;
#else
	sem_t* 					m_pEvent;
#endif
	LPSYSTEMFILEHEAD		m_pMemoryFileHead;
	LPFILEINFO				m_lpSystemFileInfo;			//系统文件
	LPFILEINFO				m_pStorageInfo;				//数据文件
	
	char*					m_pSaveBlockBuffer;			//共用内存空间，暂定大小8MB，与系统文件大小相同。用于保存数据时临时存放block数据
	int						m_nSaveBlockBufferSize;		//开辟内存空间大小，8*1024*1024
	char					m_cConfigPath[MAX_PATH];
	
private:
	char*	m_pStorageMemFileAddr;
#ifdef WIN32
	HANDLE	m_hStorageMemFileFile;
#else
	int 	m_nStorageMemFileShmId;
#endif
	LPSTORAGEMEMHEAD m_pStorageMemFileHead;

public:
	//获取系统文件路径
	BOOL GetSystemFilePath(TCHAR lpFilePath[], TCHAR lpMemFileName[]);

	//初始化环境数据
	HRESULT InitSysEnvironment();

	//读取配置文件系统参数
	void ReadSysConfigParam(LPSYSTEMFILEHEAD lpMemoryFileHead);

	//服务退出时，写入配置文件系统参数
	void WriteSysConfigParam(LPSYSTEMFILEHEAD lpMemoryFileHead);

	//加载文件到内存
	HRESULT LoadFile();

	//保存修改数据
	HRESULT SaveChange2File(BOOL bForce, int &nRedoLogMaxID);

	//保存指定文件的修改信息
	HRESULT SaveChange2File(LPFILEINFO pFileInfo, long long nEndTimestamp, BOOL bForce);

	//服务退出前释放所有资源
	HRESULT FreeData();

	//创建文件夹路径
	BOOL MakeDir(LPCTSTR lpszFilePath);

	//加载文件到内存
	BOOL LoadMemDBFileData(LPSYSTEMBLOCKHEAD lpSystemBlockHead);

	//文件命令执行
	HRESULT FileCMD();

	//文件命令执行
	BOOL MemFileCMD(LPSYSTEMBLOCKHEAD lpSystemBlockHead, char bFileCMD);

	//添加文件命令
	HRESULT NewFile(LPFILEINFO pFileInfo);

	//保存成新文件
	HRESULT SaveNewFile(LPFILEINFO pFileInfo);

	//把所有内存数据保存到文件，bNewFile表示是否需要重新打开一个新文件
	HRESULT Save2File(LPFILEINFO pFileInfo, BOOL bNewFile = FALSE);

	//修改文件大小命令
	HRESULT ChangeFileSize(LPFILEINFO pFileInfo, long long nFileSize);

	//转换UTF8到ASCII
	void ConvertToAcp(char * lpSrc, char *lpDes);

#ifdef WIN32
public :
	DECLARE_LIBID(LIBID_SobeyMemStorageLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_SOBEYMEMSTORAGE, "{0A3E12AE-ABD9-49D7-924D-04DC3B15F97C}")
	HRESULT InitializeSecurity() throw()
	{
		m_hEvent		= NULL;
		m_pStorageInfo  = NULL;
		// TODO : 调用 CoInitializeSecurity 并为服务提供适当的 
		// 安全设置
		// 建议 - PKT 级别的身份验证、
		// RPC_C_IMP_LEVEL_IDENTIFY 的模拟级别
		// 以及适当的非 NULL 安全说明符。
		return CoInitializeSecurity( NULL, -1, NULL, NULL, RPC_C_AUTHN_LEVEL_NONE,RPC_C_IMP_LEVEL_IDENTIFY, NULL, EOAC_NONE, NULL );
		//return S_OK;
	}
	
	HRESULT PreMessageLoop(int nShowCmd)
	{
		InitLogSystem();
		Trace0(_T("SobeyMemStorage"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10000000, _T("索贝内存存储服务启动开始......"));
		HRESULT hr = __super::PreMessageLoop(nShowCmd);  
		if (SUCCEEDED(hr)) 
		{  
			SECURITY_ATTRIBUTES attr;
			PSECURITY_DESCRIPTOR pSec;
			pSec = (PSECURITY_DESCRIPTOR)LocalAlloc(LMEM_FIXED, SECURITY_DESCRIPTOR_MIN_LENGTH);
			if(!pSec)
			{
				Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020010, _T("分配安全描述信息失败，错误码：%d"), GetLastError());
				return E_FAIL;
			}
			if(!InitializeSecurityDescriptor(pSec, SECURITY_DESCRIPTOR_REVISION))
			{
				LocalFree(pSec);
				Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020011, _T("初始化安全描述信息失败，错误码：%d"), GetLastError());
				return E_FAIL;
			}
			if(!SetSecurityDescriptorDacl(pSec, TRUE, NULL, FALSE))
			{
				LocalFree(pSec);
				Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020012, _T("设置安全描述信息失败，错误码：%d"), GetLastError());
				return E_FAIL;
			}
			attr.bInheritHandle = FALSE;
			attr.lpSecurityDescriptor = pSec;
			attr.nLength = sizeof(SECURITY_ATTRIBUTES);

			m_hEvent = ::CreateMutex(&attr, FALSE, _T("Global\\SobeyMemorySvc"));
			if(GetLastError() == ERROR_ALREADY_EXISTS)
			{
				::CloseHandle(m_hEvent);
				m_hEvent = NULL;
				LocalFree(pSec);
				Trace0(_T("PreMessageLoop"), MF_TRACE_LEVEL_ERROR, 10000002, _T("索贝内存存储服务检测到相同的服务正在运行，程序退出运行!"));
				return E_FAIL;
			}
			LocalFree(pSec);
		}  
		return hr; 
	}
	HRESULT PostMessageLoop();
	HRESULT RegisterAppId(bool bService = false); 
#else
public:
	HRESULT PreMessageLoop()
	{
		g_bEixt = FALSE;
	
		m_pEvent = NULL;
		m_pStorageInfo = NULL;
	
		InitLogSystem();
		Trace0(_T("SobeyMemStorage"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10000000 , _T("索贝内存存储服务启动开始......"));
	
		m_pEvent = sem_open("Global\\SobeyMemorySvc", O_CREAT, 0644, 1);
		if(m_pEvent == SEM_FAILED)
		{
			Trace0(_T("PreMessageLoop"), MF_TRACE_LEVEL_ERROR, 10000002 , _T("索贝内存存储服务检测到相同的服务正在运行，程序退出运行!"));
			m_pEvent = NULL;
			return E_FAIL;
		}
	
		return S_OK;
	}
	HRESULT PostMessageLoop();
#endif
};

#ifdef WIN32
CSobeyMemStorageModule _AtlModule;

//
extern "C" int WINAPI _tWinMain(HINSTANCE /*hInstance*/, HINSTANCE /*hPrevInstance*/, 
                                LPTSTR /*lpCmdLine*/, int nShowCmd)
{
	::InitializeCriticalSection(&g_CritTrace);
   return _AtlModule.WinMain(nShowCmd);
}

HRESULT CSobeyMemStorageModule::RegisterAppId(bool bService)
{  
	HRESULT hr = S_OK;  
	BOOL res = __super::RegisterAppId(bService); 
	if (bService) 
	{  
		if (IsInstalled()) 
		{  
			SC_HANDLE hSCM = ::OpenSCManagerW(NULL, NULL, SERVICE_CHANGE_CONFIG); 
			SC_HANDLE hService = NULL; 
			if (hSCM == NULL)  
				hr = AtlHresultFromLastError(); 
			else 
			{  
				hService = ::OpenService(hSCM, m_szServiceName, SERVICE_CHANGE_CONFIG); 
				if (hService != NULL) 
				{  
					::ChangeServiceConfig(hService, SERVICE_NO_CHANGE,  
						SERVICE_AUTO_START,//修改服务为自动启动
						NULL, NULL, NULL, NULL, NULL, NULL, NULL,  
						m_szServiceName); //通过修改资源IDS_SERVICENAME修改服务的显示名字
					SERVICE_DESCRIPTION Description; 
					TCHAR szDescription[256]; 
					ZeroMemory(szDescription, 256*sizeof(TCHAR)); 
					ZeroMemory(&Description, sizeof(SERVICE_DESCRIPTION));  
					lstrcpy(szDescription, _T("索贝内存数据存储服务")); 
					Description.lpDescription = szDescription;  
					::ChangeServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION, &Description);  
					::CloseServiceHandle(hService); 
				} 
				else 
					hr = AtlHresultFromLastError();  
				::CloseServiceHandle(hSCM);
			} 
		} 
	} 
	return hr; 
}
#else
int main()
{
	CSobeyMemStorageModule stuModule;

	signal(SIGTERM, stopsignal);
	signal(SIGINT, stopsignal);
	stuModule.PreMessageLoop();
	stuModule.PostMessageLoop();
	return 0;
}
#endif

void CSobeyMemStorageModule::ConvertToAcp(char * lpSrc, char *lpDes)
{
#ifdef WIN32
	wchar_t lpTemp[256];
	memset(lpTemp, 0, sizeof(lpTemp));
	MultiByteToWideChar(CP_UTF8, NULL, lpSrc, (int)strlen(lpSrc), lpTemp, 256);
	WideCharToMultiByte(CP_ACP, 0, lpTemp, wcslen(lpTemp), lpDes, 256, NULL, NULL);
#else
	memcpy(lpDes, lpSrc, (int)strlen(lpSrc));
#endif
}

HRESULT CSobeyMemStorageModule::PostMessageLoop()
{
#ifdef WIN32
	HRESULT hr;
	DWORD dwTimeStart, dwStart, dwEnd, nSpan;
	int nTimeIndex, nSaveChangeCount, nPersistenceIntervals, nRedoLogMaxID;
	//初始化COM环境
	hr = CoInitialize(NULL);
	if(FAILED(hr))
	{
		Trace0(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010001, _T("索贝内存存储服务初始化COM环境失败！"));
		return hr;
	}
	hr = __super::PostMessageLoop();  
	if (SUCCEEDED(hr)) 
	{
		hr = InitSysEnvironment();
		if(FAILED(hr))
		{
			Trace0(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010002, _T("索贝内存存储服务加载配置环境失败！"));
			FreeData();
			return hr;
		}

		//设置系统数据块头，程序共享
		SetLogSystemFileHead(m_pMemoryFileHead);
		hr = LoadFile();
		if(FAILED(hr))
		{
			Trace0(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010003, _T("索贝内存存储服务加载文件到内存失败！"));
			FreeData();
			return hr;
		}
		nRedoLogMaxID = m_pMemoryFileHead->m_nRedoLogMaxID;
		m_pMemoryFileHead->m_bStatus = 0;
		if (m_bService)
			SetServiceStatus(SERVICE_RUNNING);

		nPersistenceIntervals = m_pMemoryFileHead->m_nPersistenceIntervals * 1000;
		if (nPersistenceIntervals == 0)
		{
			Trace0(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010004, _T("持久化时间间隔为0！"));
			FreeData();
			return E_FAIL;
		}
		nTimeIndex		= 0;
		dwTimeStart		= GetTickCount();
		nSaveChangeCount= 0;
		//每3秒调一次保存改变的数据块
		while((m_bService && m_status.dwCurrentState >= SERVICE_RUNNING) || !m_bService)
		{
			__try
			{
				//先判断是否有文件命令需要执行
				if(m_pMemoryFileHead->m_bFileCMD == 1)
				{
					hr = FileCMD();
					if(FAILED(hr))
					{
						Trace0(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010009, _T("索贝内存文件服务执行文件命令失败！"));
					}
					m_pMemoryFileHead->m_bFileCMD = 32;
					hr = SaveChange2File(FALSE, nRedoLogMaxID);
					if(FAILED(hr))
					{
						Trace(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010010, _T("索贝内存文件服务保存内存修改到文件失败！"));
					}
				}
				if(nTimeIndex >= 30)
				{
					nSaveChangeCount++;
					dwStart = GetTickCount();
					hr = SaveChange2File(FALSE, nRedoLogMaxID);
					//保存文件失败应该是下次继续处理，保持不退出的模式
					if(FAILED(hr))
					{
						Trace(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010011, _T("索贝内存文件服务保存内存修改到文件失败，当前累计保存次数：%d！"), nSaveChangeCount);
					}
					dwEnd = GetTickCount();
					if(dwEnd > dwStart)
					{
						nSpan = dwEnd - dwStart;
						nTimeIndex = (int)(nSpan/100);
						dwTimeStart = dwStart;
					}
					else
					{
						nTimeIndex = 1;
						dwTimeStart = dwStart;
					}
				}
				else
				{
					nTimeIndex++;
					Sleep(100);
					dwEnd = GetTickCount();
					if(dwEnd > dwTimeStart)
					{
						//如果总的耗时超过3秒则直接推动下次进行数据改变的保存
						if(dwEnd - dwTimeStart >= (UINT)nPersistenceIntervals)
						{
							nTimeIndex = 30;
						}
					}
					else
					{
						//如果出现时间跳变我们就直接按照时间到了处理，理论上49.71天出现一次溢出。
						nTimeIndex = 30;
					}
				}
			}
			__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
			{
				FreeData();
				Trace0(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010012, _T("索贝内存存储服务写入数据时异常！"));
				return E_FAIL;
			}
		}
	}
	Sleep(10);
	SetLogSystemFileHead(NULL);
	SaveChange2File(FALSE, nRedoLogMaxID);	
	Sleep(10);
	FreeData();
	//卸载COM环境
	CoUninitialize();
	::DeleteCriticalSection(&g_CritTrace);
	return S_OK;
#else
	HRESULT hr;
	timeval tStart, tEnd;
	DWORD dwTimeStart, dwStart, dwEnd, nSpan;
	int nTimeIndex, nSaveChangeCount, nPersistenceIntervals, nRedoLogMaxID;

	hr = InitSysEnvironment();
	if(FAILED(hr))
	{
		Trace0(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010002 , _T("索贝内存存储服务加载配置环境失败！"));
		Sleep(10000);
		FreeData();
		return hr;
	}
	//设置系统数据块头，程序共享
	SetLogSystemFileHead(m_pMemoryFileHead);
	hr = LoadFile();
	if(FAILED(hr))
	{
		Trace0(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010003 , _T("索贝内存存储服务加载文件到内存失败！"));
		Sleep(10000);
		FreeData();
		return hr;
	}

	nRedoLogMaxID = m_pMemoryFileHead->m_nRedoLogMaxID;
	m_pMemoryFileHead->m_bStatus = 0;

	nPersistenceIntervals = m_pMemoryFileHead->m_nPersistenceIntervals * 1000;
	if (nPersistenceIntervals == 0)
	{
		Trace0(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010004, _T("持久化时间间隔为0！"));
		FreeData();
		return E_FAIL;
	}
	nTimeIndex		= 0;
	gettimeofday(&tStart, NULL);
	dwTimeStart = tStart.tv_sec*1000 + tStart.tv_usec/1000;
	nSaveChangeCount= 0;
	//
	FILE* fpStorageStart = NULL;
	fpStorageStart = fopen("/StorageStart", "w");
	if(fpStorageStart != NULL)
	{
		fclose(fpStorageStart);
		fpStorageStart = NULL;
	}
	//每3秒调一次保存改变的数据块
	while(!g_bEixt)
	{
		try
		{
			//先判断是否有文件命令需要执行
			if(m_pMemoryFileHead->m_bFileCMD == 1)
			{
				hr = FileCMD();
				if(FAILED(hr))
				{
					Trace0(_T("PostMessageLoop"),MF_TRACE_LEVEL_FAILED, 10010009, _T("索贝内存文件服务执行文件命令失败！"));
				}
				m_pMemoryFileHead->m_bFileCMD = 32;
				hr = SaveChange2File(FALSE, nRedoLogMaxID);
				if(FAILED(hr))
				{
					Trace(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010010, _T("索贝内存文件服务保存内存修改到文件失败！"));
				}
			}
			if(nTimeIndex >= 30)
			{
				nSaveChangeCount++;
				gettimeofday(&tStart, NULL);
				dwStart = tStart.tv_sec*1000 + tStart.tv_usec/1000;
				hr = SaveChange2File(false, nRedoLogMaxID);
				//保存文件失败应该是下次继续处理，保持不退出的模式
				if(FAILED(hr))
				{
					Trace(_T("PostMessageLoop"),MF_TRACE_LEVEL_FAILED, 10010011, _T("索贝内存文件服务保存内存修改到文件失败，当前累计保存次数：%d！"), nSaveChangeCount);
				}
				gettimeofday(&tEnd, NULL);
				dwEnd = tEnd.tv_sec*1000 + tEnd.tv_usec/1000;
				if(dwEnd > dwStart)
				{
					nSpan = dwEnd - dwStart;
					nTimeIndex = (int)(nSpan/100);
					dwTimeStart = dwStart;
				}
				else
				{
					nTimeIndex = 1;
					dwTimeStart = dwStart;
				}
			}
			else
			{
				nTimeIndex++;
				Sleep(100);
				gettimeofday(&tEnd, NULL);
				dwEnd = tEnd.tv_sec*1000 + tEnd.tv_usec/1000;
				if(dwEnd > dwTimeStart)
				{
					//如果总的耗时超过3秒则直接推动下次进行数据改变的保存
					if(dwEnd - dwTimeStart >= (UINT)nPersistenceIntervals)
					{
						nTimeIndex = 30;
					}
				}
				else
				{
					//如果出现时间跳变我们就直接按照时间到了处理，理论上49.71天出现一次溢出。
					nTimeIndex = 30;
				}
			}
		}
		catch(...)
		{
			Trace0(_T("PostMessageLoop"), MF_TRACE_LEVEL_FAILED, 10010012, _T("索贝内存存储服务写入数据时异常！"));
			FreeData();
			return E_FAIL;
		}
	}

	Sleep(300);
	SetLogSystemFileHead(NULL);
	Sleep(300);
	SaveChange2File(false, nRedoLogMaxID);
	Sleep(300);
	FreeData();

	return S_OK;
#endif
}


BOOL CSobeyMemStorageModule::GetSystemFilePath(TCHAR lpFilePath[], TCHAR lpMemFileName[])
{
	TCHAR lpDefaultFilePath[MAX_PATH], lpConfigFilePath[MAX_PATH], lpStrParamValue[MAX_PATH];
	memset(lpDefaultFilePath, 0, MAX_PATH * sizeof(TCHAR));
	memset(lpConfigFilePath, 0, MAX_PATH * sizeof(TCHAR));
	memset(lpStrParamValue, 0, MAX_PATH * sizeof(TCHAR));

#ifdef WIN32
	//默认把系统文件路径放到服务所在文件夹
	GetModuleFileName(NULL, lpDefaultFilePath, 256);
	(strrchr(lpDefaultFilePath, '\\'))[0] = 0;
	(strrchr(lpDefaultFilePath, '\\'))[1] = 0;
	strcat_s(lpDefaultFilePath, 256, _T("Data\\Vernox\\"));

	GetModuleFileName(NULL, lpConfigFilePath, 256);
	(strrchr(lpConfigFilePath, '\\'))[1] = 0;
	strcat_s(lpConfigFilePath, 256, _T("VernoxConfig.ini"));

	GetPrivateProfileString("System", "databasepath", lpDefaultFilePath, lpFilePath, MAX_PATH, lpConfigFilePath);
	GetPrivateProfileString("System", "systemfile", "System.dbf", lpStrParamValue, MAX_PATH, lpConfigFilePath);
	strcat_s(lpFilePath, 256, lpStrParamValue);

	//默认一个系统文件的内存文件名
	memset(lpMemFileName, 0, 64 * sizeof(TCHAR));
	_tcscpy_s(lpMemFileName, 64, _T("Global\\MemDBSysFile"));
#else
	//默认把系统文件路径放到服务所在文件夹
	GetModuleFileName(NULL, lpDefaultFilePath, 256);
	(strrchr(lpDefaultFilePath, '/'))[0] = 0;
	(strrchr(lpDefaultFilePath, '/'))[1] = 0;
	strcat(lpDefaultFilePath, _T("Data/Vernox/"));

	GetModuleFileName(NULL, lpConfigFilePath, 256);
	(strrchr(lpConfigFilePath, '/'))[1] = 0;
	strcat(lpConfigFilePath, _T("VernoxConfig.ini"));

	GetPrivateProfileString("System", "databasepath", lpDefaultFilePath, lpFilePath, MAX_PATH, lpConfigFilePath);
	GetPrivateProfileString("System", "systemfile", "System.dbf", lpStrParamValue, MAX_PATH, lpConfigFilePath);
	strcat(lpFilePath, lpStrParamValue);

	//默认一个系统文件的内存文件名
	memset(lpMemFileName, 0, 64 * sizeof(TCHAR));
	_tcscpy(lpMemFileName, _T("Global\\MemDBSysFile"));
#endif
	return TRUE;
}

//读取配置文件系统参数
//只读取可以修改的参数
void CSobeyMemStorageModule::ReadSysConfigParam(LPSYSTEMFILEHEAD lpMemoryFileHead)
{
	DWORD dwSize = MAX_PATH;
	int nParamValue;
	const TCHAR* lpAppName = "System";
	TCHAR lpStrParamValue[MAX_PATH];

	memset(lpStrParamValue, 0, MAX_PATH * sizeof(TCHAR));

	nParamValue = GetPrivateProfileInt(lpAppName, _T("soapprocesses"), 20, m_cConfigPath);
	GetPrivateProfileString(lpAppName, _T("standbyip"), _T(""), lpStrParamValue, dwSize, m_cConfigPath);

	GetPrivateProfileString(lpAppName, _T("databasename"), _T("Vernox"), lpMemoryFileHead->m_cDatabaseName, dwSize, m_cConfigPath);
#ifdef WIN32
	GetPrivateProfileString(lpAppName, _T("databasepath"), _T("c:\\Vernox\\Data\\Vernox\\"), lpMemoryFileHead->m_cDatabasePath, dwSize, m_cConfigPath);
#else
	GetPrivateProfileString(lpAppName, _T("databasepath"), _T("/Vernox/Data/Vernox/"), lpMemoryFileHead->m_cDatabasePath, dwSize, m_cConfigPath);
#endif
	lpMemoryFileHead->m_nServicePort				= GetPrivateProfileInt(lpAppName, _T("soapport"), 8080, m_cConfigPath);						//SERVICE_PORT ：Web Service的监听端口，默认为8080；
	lpMemoryFileHead->m_nServiceWorkers				= GetPrivateProfileInt(lpAppName, _T("processes"), 500, m_cConfigPath);						//SERVICE_WORKERS： Web Service的服务线程数量，默认为10；
	GetPrivateProfileString(lpAppName, _T("listenip"), _T("0.0.0.0"), lpStrParamValue, dwSize, m_cConfigPath);
	lpMemoryFileHead->m_nTCPListenIP				= ntohl(inet_addr(lpStrParamValue));														//TCP_LISTEN_IP：TCP监听IP地址，默认为0，表示不绑定网卡；
	lpMemoryFileHead->m_nTCPListenPort				= GetPrivateProfileInt(lpAppName, _T("listenport"), 8000, m_cConfigPath);					//TCP_LISTEN_PORT：TCP监听端口，默认为8000；

	lpMemoryFileHead->m_nServerCaseSensitive		= GetPrivateProfileInt(lpAppName, _T("charcomparenocase"), 0, m_cConfigPath);				//SERVER_CASE_SENSITIVE：字符串大小写是否敏感，0为不敏感、1为敏感，默认为0；
	//暂定范围8MB~1.99GB
	lpMemoryFileHead->m_nMemoryTemporarySize		= GetPrivateProfileInt(lpAppName, _T("temporaryareasize"), 256, m_cConfigPath);				//MEMORY_TEMPORARY_SIZE：临时内存大小(大量数据检索使用)，单位为MB，默认48
	if (lpMemoryFileHead->m_nMemoryTemporarySize < 8 || lpMemoryFileHead->m_nMemoryTemporarySize > 2047)
	{
		lpMemoryFileHead->m_nMemoryTemporarySize = 256;
	}
	lpMemoryFileHead->m_nMemoryTemporarySize = lpMemoryFileHead->m_nMemoryTemporarySize*1024*1024;
	//暂定范围8MB~1.99GB
	lpMemoryFileHead->m_nMemoryUndoSize				= GetPrivateProfileInt(lpAppName, _T("undoareasize"), 256, m_cConfigPath);					//MEMORY_UNDO_SIZE：重做内存大小，用于数据回滚或一致性读取使用，默认48MB；
	if (lpMemoryFileHead->m_nMemoryUndoSize < 8 || lpMemoryFileHead->m_nMemoryUndoSize > 2047)
	{
		lpMemoryFileHead->m_nMemoryUndoSize = 256;
	}
	lpMemoryFileHead->m_nMemoryUndoSize = lpMemoryFileHead->m_nMemoryUndoSize*1024*1024;
	//暂定范围1MB~128MB
	lpMemoryFileHead->m_nMemoryProcessSize			= GetPrivateProfileInt(lpAppName, _T("processprivatearea"), 2, m_cConfigPath);				//MEMORY_PROCESS_SIZE：处理线程私有内存大小，处理与客户端通讯，默认2MB；
	if (lpMemoryFileHead->m_nMemoryProcessSize < 1 || lpMemoryFileHead->m_nMemoryProcessSize > 128)
	{
		lpMemoryFileHead->m_nMemoryProcessSize = 2;
	}
	lpMemoryFileHead->m_nMemoryProcessSize = lpMemoryFileHead->m_nMemoryProcessSize*1024*1024;

	lpMemoryFileHead->m_nActiveLogFiles				= GetPrivateProfileInt(lpAppName, _T("activelogfiles"), 20, m_cConfigPath);					//ACTIVE_LOG_FILES：活动重做日志数量，默认20
	lpMemoryFileHead->m_nPersistenceIntervals		= GetPrivateProfileInt(lpAppName, _T("persistenceintervals"), 3, m_cConfigPath);			//PERSISTENCE_INTERVALS：持久化时间间隔（单位：秒），按照事务完成进行持久化处理，默认3
}

void CSobeyMemStorageModule::WriteSysConfigParam(LPSYSTEMFILEHEAD lpMemoryFileHead)
{
	DWORD dwSize = MAX_PATH;
	TCHAR* lpStr;
	const TCHAR* lpAppName = "System";
	TCHAR lpStrParamValue[MAX_PATH];

	memset(lpStrParamValue, 0, MAX_PATH * sizeof(TCHAR));

#ifdef WIN32
	lpStr = strrchr(m_lpSystemFileInfo->m_lpszFilePath, '\\') + 1;
#else
	lpStr = strrchr(m_lpSystemFileInfo->m_lpszFilePath, '/') + 1;
#endif
	WritePrivateProfileString("System", "systemfile", lpStr, m_cConfigPath);

	//WritePrivateProfileString(lpAppName, _T("soapprocesses"), _T("20"), m_cConfigPath);
	//WritePrivateProfileString(lpAppName, _T("standbyip"), _T(""), m_cConfigPath);

	WritePrivateProfileString(lpAppName, _T("databasename"), lpMemoryFileHead->m_cDatabaseName, m_cConfigPath);
	WritePrivateProfileString(lpAppName, _T("databasepath"), lpMemoryFileHead->m_cDatabasePath, m_cConfigPath);
	sprintf(lpStrParamValue, _T("%d"), lpMemoryFileHead->m_nServicePort);
	WritePrivateProfileString(lpAppName, _T("soapport"), lpStrParamValue, m_cConfigPath);							//SERVICE_PORT ：Web Service的监听端口，默认为8080；
	sprintf(lpStrParamValue, _T("%d"), lpMemoryFileHead->m_nServiceWorkers);
	WritePrivateProfileString(lpAppName, _T("processes"), lpStrParamValue, m_cConfigPath);						//SERVICE_WORKERS： Web Service的服务线程数量，默认为10；
	sprintf(lpStrParamValue, _T("%d.%d.%d.%d"), 
		FIRST_IPADDRESS(lpMemoryFileHead->m_nTCPListenIP), SECOND_IPADDRESS(lpMemoryFileHead->m_nTCPListenIP), THIRD_IPADDRESS(lpMemoryFileHead->m_nTCPListenIP), FOURTH_IPADDRESS(lpMemoryFileHead->m_nTCPListenIP));
	WritePrivateProfileString(lpAppName, _T("listenip"), lpStrParamValue, m_cConfigPath);											//TCP_LISTEN_IP：TCP监听IP地址，默认为0，表示不绑定网卡；
	sprintf(lpStrParamValue, _T("%d"), lpMemoryFileHead->m_nTCPListenPort);
	WritePrivateProfileString(lpAppName, _T("listenport"), lpStrParamValue, m_cConfigPath);						//TCP_LISTEN_PORT：TCP监听端口，默认为8000；

	sprintf(lpStrParamValue, _T("%d"), lpMemoryFileHead->m_nServerCaseSensitive);
	WritePrivateProfileString(lpAppName, _T("charcomparenocase"), lpStrParamValue, m_cConfigPath);					//SERVER_CASE_SENSITIVE：字符串大小写是否敏感，0为不敏感、1为敏感，默认为0；
	sprintf(lpStrParamValue, _T("%d"), lpMemoryFileHead->m_nMemoryTemporarySize/1024/1024);
	WritePrivateProfileString(lpAppName, _T("temporaryareasize"), lpStrParamValue, m_cConfigPath);					//MEMORY_TEMPORARY_SIZE：临时内存大小(大量数据检索使用)，单位为MB，默认48
	sprintf(lpStrParamValue, _T("%d"), lpMemoryFileHead->m_nMemoryUndoSize/1024/1024);
	WritePrivateProfileString(lpAppName, _T("undoareasize"), lpStrParamValue, m_cConfigPath);				//MEMORY_UNDO_SIZE：重做内存大小，用于数据回滚或一致性读取使用，默认48MB；
	sprintf(lpStrParamValue, _T("%d"), lpMemoryFileHead->m_nMemoryProcessSize/1024/1024);
	WritePrivateProfileString(lpAppName, _T("processprivatearea"), lpStrParamValue, m_cConfigPath);			//MEMORY_PROCESS_SIZE：处理线程私有内存大小，处理与客户端通讯，默认2MB ；

	sprintf(lpStrParamValue, _T("%d"), lpMemoryFileHead->m_nActiveLogFiles);
	WritePrivateProfileString(lpAppName, _T("activelogfiles"), lpStrParamValue, m_cConfigPath);					//ACTIVE_LOG_FILES：活动重做日志数量，默认20
	sprintf(lpStrParamValue, _T("%d"), lpMemoryFileHead->m_nPersistenceIntervals);
	WritePrivateProfileString(lpAppName, _T("persistenceintervals"), lpStrParamValue, m_cConfigPath);				//PERSISTENCE_INTERVALS：持久化时间间隔（单位：秒），按照事务完成进行持久化处理，默认3
}

//初始化系统管理类
HRESULT CSobeyMemStorageModule::InitSysEnvironment()
{
#ifdef WIN32
	HANDLE hFile;
	int i,nBufferSize;
	SECURITY_ATTRIBUTES attr;
	PSECURITY_DESCRIPTOR pSec;
#else
	FILE* pFile;
	key_t nShmKey;
	int i, nBufferSize, nRet;
#endif
	BOOL bExists;
	long long nPos, nDataOffset;
	LARGE_INTEGER liTotalFileSize;
	char* lpMapFileBuffer, *lpBuffer;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPBASEFILEBLOCKMAP lpBaseFileBlockMap;
	DWORD dwError, dwBufSize, dwReadBufferSize;
	//初始化系统文件信息

	nBufferSize = 1024*1024;
	dwReadBufferSize = 8*1024*1024;
	lpBuffer = new char[nBufferSize];//分配1MB内存；
	memset(lpBuffer, 0, nBufferSize);

	m_nSaveBlockBufferSize = 8*1024*1024;
	m_pSaveBlockBuffer = new char[m_nSaveBlockBufferSize];		//分配1MB内存；
	memset(m_pSaveBlockBuffer, 0, m_nSaveBlockBufferSize);

	memset(m_cConfigPath, 0, sizeof(m_cConfigPath));
	//获取配置文件路径
	GetModuleFileName(NULL, m_cConfigPath, 256);
#ifdef WIN32
	(strrchr(m_cConfigPath, '\\'))[1] = 0;
	strcat_s(m_cConfigPath, 256, _T("VernoxConfig.ini"));
#else
	(strrchr(m_cConfigPath, '/'))[1] = 0;
	strcat(m_cConfigPath, _T("VernoxConfig.ini"));
#endif


	m_lpSystemFileInfo = new FILEINFO;
	memset(m_lpSystemFileInfo, 0, sizeof(FILEINFO));
	GetSystemFilePath(m_lpSystemFileInfo->m_lpszFilePath, m_lpSystemFileInfo->m_lpszMemFileName);
	m_lpSystemFileInfo->m_bFileType = MF_SYS_FILETYPE_SYSFILE;
	m_lpSystemFileInfo->m_bFileNo = 1;
	m_lpSystemFileInfo->m_pLoadSize = NULL;

	//首先访问文件是否存在
	i = 0;
	lpMapFileBuffer = NULL;
#ifdef WIN32
	hFile = INVALID_HANDLE_VALUE;
#else
	pFile = NULL;
#endif
	memset(&liTotalFileSize, 0, sizeof(liTotalFileSize));

	//先打开实际文件
	while (TRUE)
	{
#ifdef WIN32
		hFile = CreateFile(m_lpSystemFileInfo->m_lpszFilePath, 
			GENERIC_READ|GENERIC_WRITE, 
			FILE_SHARE_READ, 
			NULL, 
			OPEN_EXISTING, 
			FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN, 
			NULL);
		if (hFile != INVALID_HANDLE_VALUE)
		{
			GetFileSizeEx(hFile, &liTotalFileSize);
			m_lpSystemFileInfo->m_liFileSize.QuadPart = liTotalFileSize.QuadPart;
			break;
		}
#else
		if (!_taccess(m_lpSystemFileInfo->m_lpszFilePath, F_OK)) 
		{
			pFile = fopen(m_lpSystemFileInfo->m_lpszFilePath, "rb+");
			liTotalFileSize.QuadPart = GetFileSize(pFile);
			m_lpSystemFileInfo->m_liFileSize.QuadPart = liTotalFileSize.QuadPart;
			break;
		}
#endif
		dwError = GetLastError();
		i++;
		if (i < 5)
		{
			::Sleep(20);
			continue;
		}
		else
		{
			Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020001, _T("系统文件不存在，文件路径：%s"), m_lpSystemFileInfo->m_lpszFilePath);
			return E_FAIL;
		} 
	}
	delete[] lpBuffer;
	lpBuffer = NULL;

#ifdef WIN32
	pSec = (PSECURITY_DESCRIPTOR)LocalAlloc(LMEM_FIXED, SECURITY_DESCRIPTOR_MIN_LENGTH);
	if(!pSec)
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020010, _T("分配安全描述信息失败，错误码：%d"), GetLastError());
		return E_FAIL;
	}
	if(!InitializeSecurityDescriptor(pSec, SECURITY_DESCRIPTOR_REVISION))
	{
		LocalFree(pSec);
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020011, _T("初始化安全描述信息失败，错误码：%d"), GetLastError());
		return E_FAIL;
	}
	if(!SetSecurityDescriptorDacl(pSec, TRUE, NULL, FALSE))
	{
		LocalFree(pSec);
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020012, _T("设置安全描述信息失败，错误码：%d"), GetLastError());
		return E_FAIL;
	}
	attr.bInheritHandle = FALSE;
	attr.lpSecurityDescriptor = pSec;
	attr.nLength = sizeof(SECURITY_ATTRIBUTES);

	//创建内存
	bExists = FALSE;
	m_lpSystemFileInfo->m_hMemoryFile = CreateFileMapping(INVALID_HANDLE_VALUE, &attr, PAGE_READWRITE | SEC_COMMIT, m_lpSystemFileInfo->m_liFileSize.HighPart, m_lpSystemFileInfo->m_liFileSize.LowPart, m_lpSystemFileInfo->m_lpszMemFileName);
	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020013, _T("内存文件映射时发现文件已经存在，系统认为是服务重启导致，并按照此逻辑处理，错误码：%d，内存文件：%s"),	GetLastError(), m_lpSystemFileInfo->m_lpszMemFileName);
		bExists = TRUE;
	}
	else if(m_lpSystemFileInfo->m_hMemoryFile == NULL)
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020014, _T("打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%I64d"),
			GetLastError(), m_lpSystemFileInfo->m_lpszMemFileName, m_lpSystemFileInfo->m_liFileSize.QuadPart);
		LocalFree(pSec); 
		return E_FAIL;
	}
	LocalFree(pSec); 

	lpMapFileBuffer = (char*)MapViewOfFile(m_lpSystemFileInfo->m_hMemoryFile, FILE_MAP_READ|FILE_MAP_WRITE, 0, 0, 0);
	if (lpMapFileBuffer == NULL)
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020015, _T("内存文件映射内存失败，错误码：%d，内存文件：%s"),	GetLastError(), m_lpSystemFileInfo->m_lpszMemFileName);
		return E_FAIL;
	}

	m_pMemoryFileHead = (LPSYSTEMFILEHEAD)lpMapFileBuffer;
	if(!bExists)
	{
		dwBufSize = 0;
		m_pMemoryFileHead->m_bStatus = 1;
		//读取本地文件数据上传到内存中
		for(nPos = 0; nPos < m_lpSystemFileInfo->m_liFileSize.QuadPart;nPos += dwBufSize)
		{
			if(m_lpSystemFileInfo->m_liFileSize.QuadPart - nPos >= dwReadBufferSize)
			{
				if(!ReadFile(hFile, lpMapFileBuffer+nPos, dwReadBufferSize, &dwBufSize, NULL))
				{
					Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020021, _T("从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%I64d，读取大小：%d"),
						GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, nPos, dwReadBufferSize);
					return E_FAIL;
				}
				if(nPos == 0)
				{
					m_pMemoryFileHead->m_bStatus = 1;
				}
			}
			else
			{
				if(!ReadFile(hFile, lpMapFileBuffer+nPos, (DWORD)(m_lpSystemFileInfo->m_liFileSize.QuadPart - nPos), &dwBufSize, NULL))
				{
					Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020022, _T("从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%I64d，读取大小：%d"),
						GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, nPos, (DWORD)(m_lpSystemFileInfo->m_liFileSize.QuadPart - nPos));
					return E_FAIL;
				}
				if(nPos == 0)
				{
					m_pMemoryFileHead->m_bStatus = 1;
				}
			}

			//表示没读到数据，按道理不应该呀。
			if(dwBufSize == 0)
			{
				Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020023, _T("从物理文件读取数据时返回读取长度为0，错误码：%d，路径：%s，读取位置：%I64d"),	GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, nPos);
				return E_FAIL;
			}
		}
	}
	else
	{
		SYSTEMFILEHEAD stMemoryFileHead;
		dwReadBufferSize = sizeof(stMemoryFileHead);
		memset(&stMemoryFileHead, 0, sizeof(stMemoryFileHead));
		if (0 != SetFilePointer(hFile, 0, NULL, FILE_BEGIN))
		{
			Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020024, _T("设置物理文件读取位置失败，错误码：%d，路径：%s，读取位置：0"),
				GetLastError(), m_lpSystemFileInfo->m_lpszFilePath);
			return E_FAIL;
		}
		
		if(!ReadFile(hFile, &stMemoryFileHead, dwReadBufferSize, &dwBufSize, NULL))
		{
			Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020025, _T("从物理文件读取文件头数据失败，错误码：%d，路径：%s，读取位置：0，读取大小：%d"),
				GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, dwReadBufferSize);
			return E_FAIL;
		}
		if (dwReadBufferSize != dwBufSize)
		{
			Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020026, _T("从物理文件读取文件头大小不对，错误码：%d，路径：%s，理论大小：%d，读取大小：%d"),
				GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, dwReadBufferSize, dwBufSize);
			return E_FAIL;
		}

		m_pMemoryFileHead = (LPSYSTEMFILEHEAD)lpMapFileBuffer;
		if (m_pMemoryFileHead->m_nBeginTimestamp == stMemoryFileHead.m_nBeginTimestamp && m_pMemoryFileHead->m_nEndTimestamp >= stMemoryFileHead.m_nEndTimestamp)
		{
			m_pMemoryFileHead->m_bStatus = 1;
			//正常
			;
		} 
		else
		{
			Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020027, _T("校验内存文件与物理文件的时间戳错误，内存文件时间戳：begin: %lld，end: %lld，物理文件时间戳：begin: %lld，end: %lld"),
				m_pMemoryFileHead->m_nBeginTimestamp, m_pMemoryFileHead->m_nEndTimestamp, stMemoryFileHead.m_nBeginTimestamp, stMemoryFileHead.m_nEndTimestamp);
			return E_FAIL;
		}
	}
#else
	//创建内存
	bExists = false;
	nShmKey = MF_MEMFILE_BASEKEY + m_lpSystemFileInfo->m_bFileNo;
	m_lpSystemFileInfo->m_nShmId = CShareMemory::CreateShareMemory(nShmKey,m_lpSystemFileInfo->m_liFileSize.QuadPart, NULL);
	if (GetLastError() == EEXIST)
	{
		Trace(_T("InitSysEnvironment"),MF_TRACE_LEVEL_FAILED, 10020013, _T("内存文件映射时发现文件已经存在，系统认为是服务重启导致，并按照此逻辑处理，错误码：%d，内存文件：%s"),
			GetLastError(), m_lpSystemFileInfo->m_lpszMemFileName);
		bExists = true;
	}
	else if (m_lpSystemFileInfo->m_nShmId == -1) 
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020014,_T("打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%lld"),
				 GetLastError(), m_lpSystemFileInfo->m_lpszMemFileName,m_lpSystemFileInfo->m_liFileSize.QuadPart);
		return E_FAIL;
	}

	lpMapFileBuffer = (char*) CShareMemory::ShMemAttach(m_lpSystemFileInfo->m_nShmId);
	if (lpMapFileBuffer == NULL) 
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020015,_T("打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%lld"), 
				GetLastError(),m_lpSystemFileInfo->m_lpszMemFileName);
		return E_FAIL;
	}

	m_pMemoryFileHead = (LPSYSTEMFILEHEAD)lpMapFileBuffer;
	if (!bExists) 
	{
		dwBufSize = 0;
		//读取本地文件数据上传到内存中
		m_pMemoryFileHead->m_bStatus = 1;
		fseek(pFile, 0, SEEK_SET);
		for (nPos = 0; nPos < m_lpSystemFileInfo->m_liFileSize.QuadPart; nPos+= dwBufSize)
		{
			if (m_lpSystemFileInfo->m_liFileSize.QuadPart - nPos >= (int)dwReadBufferSize) 
			{
				dwBufSize = fread(lpMapFileBuffer + nPos, sizeof(char), dwReadBufferSize, pFile);
				if (ferror(pFile)) 
				{
					Trace( _T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020021, _T("从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%I64d，读取大小：%d"), GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, nPos, dwReadBufferSize);
					return E_FAIL;
				}
				if(nPos == 0)
				{
					m_pMemoryFileHead->m_bStatus = 1;
				}
			}
			else
			{		
				dwBufSize = fread(lpMapFileBuffer + nPos, sizeof(char),(DWORD) (m_lpSystemFileInfo->m_liFileSize.QuadPart- nPos), pFile);
				if (ferror(pFile)) 
				{
					Trace( _T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020022, _T("从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%I64d，读取大小：%d"),
					          GetLastError(), m_lpSystemFileInfo->m_lpszFilePath,nPos,(DWORD) (m_lpSystemFileInfo->m_liFileSize.QuadPart- nPos));
					return E_FAIL;
				}
				if(nPos == 0)
				{
					m_pMemoryFileHead->m_bStatus = 1;
				}
			}

			//表示没读到数据，按道理不应该呀。
			if (dwBufSize == 0) 
			{
				Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED,10020023,_T("从物理文件读取数据时返回读取长度为0，错误码：%d，路径：%s，读取位置：%I64d"),
						GetLastError(), m_lpSystemFileInfo->m_lpszFilePath,nPos);
				return E_FAIL;
			}
		}
	}
	else
	{
		SYSTEMFILEHEAD stMemoryFileHead;
		dwReadBufferSize = sizeof(stMemoryFileHead);
		memset(&stMemoryFileHead, 0, sizeof(stMemoryFileHead));
		fseek(pFile, 0, SEEK_SET);
		
		dwBufSize = fread(&stMemoryFileHead, sizeof(char), dwReadBufferSize, pFile);
		if (ferror(pFile)) 
		{
			Trace( _T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020025, _T("从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%lld，读取大小：%d"), GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, 0, dwReadBufferSize);
			return E_FAIL;
		}		
		if (dwReadBufferSize != dwBufSize)
		{
			Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020026, _T("从物理文件读取文件头大小不对，错误码：%d，路径：%s，理论大小：%d，读取大小：%d"),
				GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, dwReadBufferSize, dwBufSize);
			return E_FAIL;
		}

		m_pMemoryFileHead = (LPSYSTEMFILEHEAD)lpMapFileBuffer;
		if (m_pMemoryFileHead->m_nBeginTimestamp == stMemoryFileHead.m_nBeginTimestamp && m_pMemoryFileHead->m_nEndTimestamp >= stMemoryFileHead.m_nEndTimestamp)
		{
			m_pMemoryFileHead->m_bStatus = 1;
			//正常
			;
		} 
		else
		{
			Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020027, _T("校验内存文件与物理文件的时间戳错误，内存文件时间戳：begin: %lld，end: %lld，物理文件时间戳：begin: %lld，end: %lld"),
				m_pMemoryFileHead->m_nBeginTimestamp, m_pMemoryFileHead->m_nEndTimestamp, stMemoryFileHead.m_nBeginTimestamp, stMemoryFileHead.m_nEndTimestamp);
			return E_FAIL;
		}
	}
#endif

	m_lpSystemFileInfo->m_pFileAddr	= lpMapFileBuffer;
#ifdef WIN32
	m_lpSystemFileInfo->m_hFile	= hFile;
#else
	m_lpSystemFileInfo->m_pFile = pFile;
#endif
	m_lpSystemFileInfo->m_nTimestamp = m_pMemoryFileHead->m_nBeginTimestamp;

	//检查文件头信息是否正确
	if (m_pMemoryFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'S', 'F'))
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020030, _T("系统文件的头数据不正确，校验码：%d[%d]"), m_pMemoryFileHead->m_nDataFlag, MAKEHEADFLAG('S', 'B', 'S', 'F'));
		return E_FAIL;
	}

	//读取系统配置参数
	ReadSysConfigParam(m_pMemoryFileHead);

	//加载文件数据
	if (m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nID == MF_SYS_OBJECTTYPE_FILE)
	{
		//读取文件数据信息
		nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFullBlockMapOffset;
		while (nDataOffset != 0)
		{
			lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(lpMapFileBuffer + nDataOffset);
			lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(lpMapFileBuffer + lpBaseFileBlockMap->m_nBlockOffset);
			if (!LoadMemDBFileData(lpSystemBlockHead))
			{
				Trace0(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020031, _T("加载系统文件中的内存文件数据失败"));
				return E_FAIL;
			}
			nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
		}

		nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFreeBlockMapOffset;
		while (nDataOffset != 0)
		{
			lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(lpMapFileBuffer + nDataOffset);
			lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(lpMapFileBuffer + lpBaseFileBlockMap->m_nBlockOffset);
			if (!LoadMemDBFileData(lpSystemBlockHead))
			{
				Trace0(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020032, _T("加载系统文件中的内存文件数据失败"));
				return E_FAIL;
			}
			nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
		}
	}

	//////////////////////////////////////////////////////////////////////////
#ifdef WIN32
	pSec = (PSECURITY_DESCRIPTOR)LocalAlloc(LMEM_FIXED, SECURITY_DESCRIPTOR_MIN_LENGTH);
	if(!pSec)
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020040, _T("分配安全描述信息失败，错误码：%d"), GetLastError());
		return E_FAIL;
	}
	if(!InitializeSecurityDescriptor(pSec, SECURITY_DESCRIPTOR_REVISION))
	{
		LocalFree(pSec);
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020041, _T("初始化安全描述信息失败，错误码：%d"), GetLastError());
		return E_FAIL;
	}
	if(!SetSecurityDescriptorDacl(pSec, TRUE, NULL, FALSE))
	{
		LocalFree(pSec);
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020042, _T("设置安全描述信息失败，错误码：%d"), GetLastError());
		return E_FAIL;
	}
	attr.bInheritHandle = FALSE;
	attr.lpSecurityDescriptor = pSec;
	attr.nLength = sizeof(SECURITY_ATTRIBUTES);

	bExists		 = FALSE;
	m_hStorageMemFileFile = CreateFileMapping(INVALID_HANDLE_VALUE, &attr, PAGE_READWRITE | SEC_COMMIT, 0, MF_STORAGEMEM_FILE_SIZE, MF_STORAGEMEM_FILE_NAME);
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020044, _T("内存文件映射时发现文件已经存在，系统认为是服务重启导致，并按照此逻辑处理，错误码：%d，内存文件：%s"),	GetLastError(), MF_STORAGEMEM_FILE_NAME);
		bExists = TRUE;
	}
	else if(m_hStorageMemFileFile == NULL)
	{
		LocalFree(pSec); 
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020043, _T("打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%d"),
			GetLastError(), MF_STORAGEMEM_FILE_NAME, MF_STORAGEMEM_FILE_SIZE);
		return E_FAIL;
	}

	m_pStorageMemFileAddr = (char*)MapViewOfFile(m_hStorageMemFileFile, FILE_MAP_READ|FILE_MAP_WRITE, 0, 0, 0);
	if (m_pStorageMemFileAddr == NULL)
	{
		LocalFree(pSec); 
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020045, _T("内存文件映射内存失败，错误码：%d，内存文件：%s"),	GetLastError(), MF_STORAGEMEM_FILE_NAME);
		return E_FAIL;
	}

	LocalFree(pSec);
#else
	bExists = FALSE;
	m_nStorageMemFileShmId = CShareMemory::CreateShareMemory(MF_STORAGEMEM_FILE_KEY, MF_STORAGEMEM_FILE_SIZE, NULL);
	if (GetLastError() == EEXIST) 
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020044, _T("内存文件映射时发现文件已经存在，系统认为是服务重启导致，并按照此逻辑处理，错误码：%d，内存文件：%s"), GetLastError(), MF_STORAGEMEM_FILE_NAME);
		bExists = true;
	} 
	else if (m_nStorageMemFileShmId == -1)
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020043,
				_T("打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%d"), GetLastError(),
				MF_STORAGEMEM_FILE_NAME, MF_STORAGEMEM_FILE_SIZE);
		return E_FAIL;
	}

	m_pStorageMemFileAddr = (char*) CShareMemory::ShMemAttach(m_nStorageMemFileShmId);
	if (m_pStorageMemFileAddr == NULL) 
	{
		Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_FAILED, 10020045,
				_T("内存文件映射内存失败，错误码：%d，内存文件：%s"), GetLastError(),
				MF_STORAGEMEM_FILE_NAME);
		return E_FAIL;
	}
#endif

	m_pStorageMemFileHead = (LPSTORAGEMEMHEAD)m_pStorageMemFileAddr;
	if (!bExists)
	{
		m_pStorageMemFileHead->m_nFileTotalSize = MF_STORAGEMEM_FILE_SIZE;
		m_pStorageMemFileHead->m_nFileHeaderSize = sizeof(STORAGEMEMHEAD);
		m_pStorageMemFileHead->m_nBakBlockOffset = m_pStorageMemFileHead->m_nFileHeaderSize;
		m_pStorageMemFileHead->m_nBakFileHeadOffset = m_pStorageMemFileHead->m_nBakBlockOffset + MF_STORAGEMEM_BLOCK_SIZE;
		m_pStorageMemFileHead->m_nObjectNo = 0;
		m_pStorageMemFileHead->m_nBlockNo = 0;
		m_pStorageMemFileHead->m_nCycleTime = 10;
		m_pStorageMemFileHead->m_nResult = 0;
		m_pStorageMemFileHead->m_nTimestamp = 0;
		m_pStorageMemFileHead->m_nMapSize = 0;
		m_pStorageMemFileHead->m_bCommandType = MF_STORAGEMEM_COMMAND_NO;
		m_pStorageMemFileHead->m_bClusterCommandType = MF_STORAGEMEM_COMMAND_NO;
		m_pStorageMemFileHead->m_bFileNo = 0;
		m_pStorageMemFileHead->m_bServer = 0;
		m_pStorageMemFileHead->m_bReserved = 0;
	}

	//////////////////////////////////////////////////////////////////////////
	//加载成功
	Trace(_T("InitSysEnvironment"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10020099, _T("加载系统文件成功，路径：%s，文件大小：%I64d"), m_lpSystemFileInfo->m_lpszFilePath, m_lpSystemFileInfo->m_liFileSize.QuadPart);
	return S_OK;
}

//考虑所有数据都为定长数据，这样就不需要其他的数据开销
BOOL CSobeyMemStorageModule::LoadMemDBFileData(LPSYSTEMBLOCKHEAD lpSystemBlockHead)
{
	int i;
	LPFILEINFO lpFileInfo;
	LPFILE_MEMDBFILEINFO lpFileMemDBFileInfo;
	if (lpSystemBlockHead->m_nObjectID != MF_SYS_OBJECTTYPE_FILE)
	{
		//按道理不应该出现这种情况
		Trace(_T("LoadMemDBFileData"), MF_TRACE_LEVEL_FAILED, 10030001, _T("数据块的对象表示不正确，需要值：%d，实际值：%d"), MF_SYS_OBJECTTYPE_FILE, lpSystemBlockHead->m_nObjectID);
		return FALSE;
	}
	if(lpSystemBlockHead->m_nBlockDataStructSize != sizeof(FILE_MEMDBFILEINFO))
	{
		//结构体发生变化了？
		Trace(_T("LoadMemDBFileData"), MF_TRACE_LEVEL_FAILED, 10030002, _T("数据块的结构体大小发生改变，系统目前值：%d，记录值：%d"), sizeof(FILE_MEMDBFILEINFO), lpSystemBlockHead->m_nBlockDataStructSize);
		return FALSE;
	}
	//直接把定长数据转换成结构体
	lpFileMemDBFileInfo = (LPFILE_MEMDBFILEINFO)(((char*)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
	for (i = 0; i < lpSystemBlockHead->m_nDataNum; i++)
	{
		if (lpFileMemDBFileInfo[i].m_bDropFlag == 1)
		{
			//忽略删除文件的加载和管理
			continue;
		}
		lpFileInfo = new FILEINFO;
		memset(lpFileInfo, 0, sizeof(FILEINFO));
#ifdef WIN32
		memset(lpFileInfo->m_lpszFilePath, 0, sizeof(lpFileInfo->m_lpszFilePath));
		ConvertToAcp(lpFileMemDBFileInfo[i].m_lpszFilePath, lpFileInfo->m_lpszFilePath);
#else
		memcpy(lpFileInfo->m_lpszFilePath, lpFileMemDBFileInfo[i].m_lpszFilePath, 256*sizeof(char));
#endif
		memcpy(lpFileInfo->m_lpszMemFileName, lpFileMemDBFileInfo[i].m_lpszMemFileName, 64*sizeof(char));
		lpFileInfo->m_bFileNo	= lpFileMemDBFileInfo[i].m_bFileNo;
		lpFileInfo->m_bFileType	= lpFileMemDBFileInfo[i].m_bFileType;
		lpFileInfo->m_liFileSize.QuadPart = lpFileMemDBFileInfo[i].m_nFileSize;
		lpFileInfo->m_pLoadSize			  = &lpFileMemDBFileInfo[i].m_nLoadSize;
		lpFileMemDBFileInfo[i].m_nLoadSize = 0;
		lpFileInfo->m_pNext		= m_pStorageInfo;
		m_pStorageInfo			= lpFileInfo;
		Trace(_T("LoadMemDBFileData"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10030010, _T("读取到数据文件，文件路径：%s，文件大小：%I64d"), lpFileInfo->m_lpszFilePath, lpFileInfo->m_liFileSize.QuadPart);
	}

	return TRUE;
}

BOOL CSobeyMemStorageModule::MakeDir(LPCTSTR lpszFilePath)
{
	int n;
	if (_tcslen(lpszFilePath) == 0)
		return FALSE;
	if (_taccess(lpszFilePath, 0) != -1)
	{
		return TRUE;
	}
	else
	{
		TCHAR lpszPath[256];
		memset(lpszPath, 0, sizeof(lpszPath));

		_tcscpy(lpszPath, lpszFilePath);

		for (n = 0; lpszPath[n] != 0; n++)
		{
			if ((lpszPath[n] != _T('\\') && lpszPath[n] != _T('/')) || n < 4)
			{
				continue;
			}
			else
			{
				lpszPath[n] = 0;
				if (_taccess(lpszPath, 0) == -1)
				{
					Sleep(10);
					if (_taccess(lpszPath, 0) == -1)
					{
						::CreateDirectory(lpszPath, NULL);
						if (_taccess(lpszPath, 0) == -1)
						{
							Sleep(10);
							::CreateDirectory(lpszPath, NULL);
						}
					}
				}
#ifdef WIN32
				lpszPath[n] = _T('\\');
#else
				lpszPath[n] = _T('/');
#endif
			}
		}
	}
	return TRUE;
}


//加载文件到内存
HRESULT CSobeyMemStorageModule::LoadFile()
{
#ifdef WIN32
	int nIndex;
	BOOL bExists;
	long long nPos;
	char* lpMapFileBuffer;
	LPFILEINFO	pFileInfo;
	SECURITY_ATTRIBUTES attr;
	LPBASEFILEHEAD lpFileHead;
	PSECURITY_DESCRIPTOR pSec;
	LARGE_INTEGER liTotalFileSize;
	HANDLE hMemoryProvider, hFile;
	DWORD dwError, dwBufSize, dwReadBufferSize;

	try
	{
		dwReadBufferSize = 8 * 1024 * 1024;
		for(pFileInfo = m_pStorageInfo; pFileInfo != NULL; pFileInfo = pFileInfo->m_pNext)
		{
			nIndex = 0;
			lpMapFileBuffer = NULL;
			hFile = INVALID_HANDLE_VALUE;
			hMemoryProvider = NULL;
			memset(&liTotalFileSize, 0, sizeof(liTotalFileSize));

			//先打开实际文件
			while(TRUE)
			{
				hFile = CreateFile(pFileInfo->m_lpszFilePath, 
					GENERIC_READ|GENERIC_WRITE, 
					FILE_SHARE_READ,  
					NULL, 
					OPEN_EXISTING, 
					FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN, 
					NULL);
				if (hFile != INVALID_HANDLE_VALUE)
				{
					GetFileSizeEx(hFile, &liTotalFileSize);
					if(pFileInfo->m_liFileSize.QuadPart != liTotalFileSize.QuadPart)
					{
						//文件大小怎么不对呢？
						Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040001, _T("文件大小出现异常，系统文件记录的文件大小为：%I64d，而实际获取到的文件大小为：%I64d，文件路径：%s"), pFileInfo->m_liFileSize.QuadPart, liTotalFileSize.QuadPart, pFileInfo->m_lpszFilePath);
						return E_FAIL;
					}
					//如果有故障的情况下用此方式来强行启动
					//pFileInfo->m_liFileSize.QuadPart = liTotalFileSize.QuadPart;
					break;
				}
				dwError = ::GetLastError();
				nIndex++;
				if (nIndex < 5)
				{
					::Sleep(20);
					continue;
				}
				else
				{
					//写入失败
					Trace(_T("LoadFile"), 0, 10040002, _T("打开文件失败，错误码：%d，路径：%s"), GetLastError(), pFileInfo->m_lpszFilePath);
					return E_FAIL;
				}
			}

			pSec = (PSECURITY_DESCRIPTOR)LocalAlloc(LMEM_FIXED, SECURITY_DESCRIPTOR_MIN_LENGTH);
			if(!pSec)
			{
				Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040003, _T("分配安全描述信息失败，错误码：%d"), GetLastError());
				return E_FAIL;
			}
			if(!InitializeSecurityDescriptor(pSec, SECURITY_DESCRIPTOR_REVISION))
			{
				LocalFree(pSec);
				Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040004, _T("初始化安全描述信息失败，错误码：%d"), GetLastError());
				return E_FAIL;
			}
			if(!SetSecurityDescriptorDacl(pSec, TRUE, NULL, FALSE))
			{
				LocalFree(pSec);
				Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040005, _T("设置安全描述信息失败，错误码：%d"), GetLastError());
				return E_FAIL;
			}
			attr.bInheritHandle = FALSE;
			attr.lpSecurityDescriptor = pSec;
			attr.nLength = sizeof(SECURITY_ATTRIBUTES);

			//创建内存
			bExists = FALSE;
			hMemoryProvider = CreateFileMapping(INVALID_HANDLE_VALUE, &attr, PAGE_READWRITE | SEC_COMMIT, pFileInfo->m_liFileSize.HighPart, pFileInfo->m_liFileSize.LowPart, pFileInfo->m_lpszMemFileName);
			if (GetLastError() == ERROR_ALREADY_EXISTS)
			{
				Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040006, _T("内存文件映射时发现文件已经存在，系统认为是服务重启导致，并按照此逻辑处理，错误码：%d，内存文件：%s"),
					GetLastError(), pFileInfo->m_lpszMemFileName);
				bExists = TRUE;
			}
			else if (hMemoryProvider == NULL)
			{
				Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040007, _T("打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%I64d"),
					GetLastError(), pFileInfo->m_lpszMemFileName, pFileInfo->m_liFileSize.QuadPart);
				::CloseHandle(hFile);
				LocalFree(pSec); 
				return E_FAIL;
			}
			LocalFree(pSec); 

			lpMapFileBuffer = (char*)MapViewOfFile(hMemoryProvider, FILE_MAP_READ|FILE_MAP_WRITE, 0, 0, 0);
			if (lpMapFileBuffer == NULL)
			{
				Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040008, _T("内存文件映射内存失败，错误码：%d，内存文件：%s"),	GetLastError(), pFileInfo->m_lpszMemFileName);
				::CloseHandle(hMemoryProvider);
				::CloseHandle(hFile);
				return E_FAIL;
			}

			//如果数据文件已经存在时，就不用重新加载数据
			if(!bExists)
			{
				dwBufSize = 0;
				//读取本地文件数据上传到内存中
				for(nPos = 0; nPos < pFileInfo->m_liFileSize.QuadPart;nPos += dwBufSize)
				{
					*pFileInfo->m_pLoadSize = nPos;
					if(pFileInfo->m_liFileSize.QuadPart - nPos >= dwReadBufferSize)
					{
						if(!ReadFile(hFile, lpMapFileBuffer+nPos, dwReadBufferSize, &dwBufSize, NULL))
						{
							Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040010, _T("从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%I64d，读取大小：%d"),
								GetLastError(), pFileInfo->m_lpszFilePath, nPos, dwReadBufferSize);
							//读取文件失败
							::UnmapViewOfFile(lpMapFileBuffer);
							::CloseHandle(hMemoryProvider);
							::CloseHandle(hFile);
							return E_FAIL;
						}
					}
					else
					{
						if(!ReadFile(hFile, lpMapFileBuffer+nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos), &dwBufSize, NULL))
						{
							Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040011, _T("从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%I64d，读取大小：%d"),
								GetLastError(), pFileInfo->m_lpszFilePath, nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos));
							//读取文件失败
							::UnmapViewOfFile(lpMapFileBuffer);
							::CloseHandle(hMemoryProvider);
							::CloseHandle(hFile);
							return E_FAIL;
						}
					}

					//表示没读到数据，按道理不应该呀。
					if(dwBufSize == 0)
					{
						Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040012, _T("从物理文件读取数据时返回读取长度为0，错误码：%d，路径：%s，读取位置：%I64d"),	GetLastError(), pFileInfo->m_lpszFilePath, nPos);
						::UnmapViewOfFile(lpMapFileBuffer);
						::CloseHandle(hMemoryProvider);
						::CloseHandle(hFile);
						return E_FAIL;
					}
				}
				*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart;
			}

			lpFileHead = (LPBASEFILEHEAD)lpMapFileBuffer;
			if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_DATAFILE)
			{
				if(lpFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'D', 'F'))
				{
					Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040013, _T("从数据文件中读取到的数据内容中的头信息不正确，文件校验码：%d[%d]，路径：%s"), lpFileHead->m_nDataFlag, MAKEHEADFLAG('S', 'B', 'D', 'F'), pFileInfo->m_lpszFilePath);
					::UnmapViewOfFile(lpMapFileBuffer);
					::CloseHandle(hMemoryProvider);
					::CloseHandle(hFile);
					return E_FAIL;
				}
			}
			else if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_TREEINDEXFILE)
			{
				if(lpFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'B', 'F'))
				{
					Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040014, _T("从B树索引文件中读取到的数据内容中的头信息不正确，文件校验码：%d[%d]，路径：%s"), lpFileHead->m_nDataFlag, MAKEHEADFLAG('S', 'B', 'B', 'F'), pFileInfo->m_lpszFilePath);
					::UnmapViewOfFile(lpMapFileBuffer);
					::CloseHandle(hMemoryProvider);
					::CloseHandle(hFile);
					return E_FAIL;
				}
			}
			else if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_KVINDEXFILE)
			{
				if(lpFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'H', 'F'))
				{
					Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040015, _T("从KV索引文件中读取到的数据内容中的头信息不正确，文件校验码：%d[%d]，路径：%s"), lpFileHead->m_nDataFlag, MAKEHEADFLAG('S', 'B', 'H', 'F'), pFileInfo->m_lpszFilePath);
					::UnmapViewOfFile(lpMapFileBuffer);
					::CloseHandle(hMemoryProvider);
					::CloseHandle(hFile);
					return E_FAIL;
				}
			}
			if(lpFileHead->m_bFileNo != pFileInfo->m_bFileNo)
			{
				Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040016, _T("文件头信息中记录的文件编号与系统文件中的不一致，文件编号：%d[%d]，路径：%s"), lpFileHead->m_bFileNo, pFileInfo->m_bFileNo, MAKEHEADFLAG('S', 'B', 'H', 'F'), pFileInfo->m_lpszFilePath);
				::UnmapViewOfFile(lpMapFileBuffer);
				::CloseHandle(hMemoryProvider);
				::CloseHandle(hFile);
				return E_FAIL;
			}
			//如果有故障的情况下用此方式来强行启动
			//lpFileHead->m_nFileTotalSize = pFileInfo->m_liFileSize.QuadPart;
			pFileInfo->m_hFile		 = hFile;
			pFileInfo->m_hMemoryFile = hMemoryProvider;
			pFileInfo->m_pFileAddr	 = lpMapFileBuffer;
			pFileInfo->m_nTimestamp  = m_pMemoryFileHead->m_nBeginTimestamp;
		}
	}
	catch(...)
	{
		Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040099, _T("加载物理文件到内存时出现异常，错误码：%d"),	GetLastError());
		if(lpMapFileBuffer)
		{
			::UnmapViewOfFile(lpMapFileBuffer);
			lpMapFileBuffer = NULL;
		}
		if(hMemoryProvider)
		{
			::CloseHandle(hMemoryProvider);
			hMemoryProvider = NULL;
		}
		if(hFile != INVALID_HANDLE_VALUE)
		{
			::CloseHandle(hFile);
			hFile = NULL;
		}
	}
	return S_OK;
#else
	int nIndex;
	FILE* pFile;
	BOOL bExists;
	key_t nShmKey;
	long long nPos;
	LPFILEINFO pFileInfo;
	char* lpMapFileBuffer;
	LPBASEFILEHEAD lpFileHead;
	LARGE_INTEGER liTotalFileSize;
	DWORD dwError, dwBufSize, dwReadBufferSize;

	try 
	{
		dwReadBufferSize = 8 * 1024 * 1024;
		for (pFileInfo = m_pStorageInfo; pFileInfo != NULL; pFileInfo = pFileInfo->m_pNext) 
		{
			nIndex = 0;
			lpMapFileBuffer = NULL;
			pFile = NULL;
			memset(&liTotalFileSize, 0, sizeof(liTotalFileSize));

			//先打开实际文件
			while (TRUE) 
			{
				pFile = fopen(pFileInfo->m_lpszFilePath, "rb+");
				if (pFile != NULL)
			 	{
					liTotalFileSize.QuadPart = GetFileSize(pFile);
					if (pFileInfo->m_liFileSize.QuadPart != liTotalFileSize.QuadPart) 
					{
						//文件大小怎么不对呢？
						Trace(  _T("LoadFile"),
								MF_TRACE_LEVEL_FAILED,
								10040001,
								_T("文件大小出现异常，系统文件记录的文件大小为：%I64d，而实际获取到的文件大小为：%I64d，文件路径：%s"),
								pFileInfo->m_liFileSize.QuadPart,
								liTotalFileSize.QuadPart,
								pFileInfo->m_lpszFilePath);
						return E_FAIL;
					}
					//如果有故障的情况下用此方式来强行启动
					//pFileInfo->m_liFileSize.QuadPart = liTotalFileSize.QuadPart;
					break;
				}
				dwError = ::GetLastError();
				nIndex++;
				if (nIndex < 5) 
				{
					::Sleep(20);
					continue;
				} 
				else 
				{
					//写入失败
					Trace(_T("LoadFile"), 0, 10040002,
							_T("打开文件失败，错误码：%d，路径：%s"), GetLastError(),
							pFileInfo->m_lpszFilePath);
					return E_FAIL;
				}
			}

			//创建内存
			bExists = FALSE;
			nShmKey = MF_MEMFILE_BASEKEY + pFileInfo->m_bFileNo;
			pFileInfo->m_nShmId = CShareMemory::CreateShareMemory(nShmKey, pFileInfo->m_liFileSize.QuadPart, NULL);
			if (GetLastError() == EEXIST)
			{
				Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040006, _T("内存文件映射时发现文件已经存在，系统认为是服务重启导致，并按照此逻辑处理，错误码：%d，内存文件：%s"),GetLastError(), pFileInfo->m_lpszMemFileName);
				bExists = true;
			} 
			else if (pFileInfo->m_nShmId == -1)
			{
				Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040007,
						_T("打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%lld"),
						GetLastError(), pFileInfo->m_lpszMemFileName,
						pFileInfo->m_liFileSize.QuadPart);
				fclose(pFile);
				return E_FAIL;
			}
			lpMapFileBuffer = (char*) CShareMemory::ShMemAttach(pFileInfo->m_nShmId);
			if (lpMapFileBuffer == NULL) 
			{
				Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040008,
						_T("内存文件映射内存失败，错误码：%d，内存文件：%s"), GetLastError(),
						pFileInfo->m_lpszMemFileName);
				fclose(pFile);
				CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
				pFileInfo->m_nShmId = 0;
				return E_FAIL;
			}

			//如果数据文件已经存在时，就不用重新加载数据
		    if(!bExists) 
			{
				dwBufSize = 0;
				//读取本地文件数据上传到内存中
				for (nPos = 0; nPos < pFileInfo->m_liFileSize.QuadPart; nPos += dwBufSize) 
				{
					*pFileInfo->m_pLoadSize = nPos;
					if (pFileInfo->m_liFileSize.QuadPart - nPos >= dwReadBufferSize) 
					{
						dwBufSize = fread(lpMapFileBuffer + nPos, sizeof(char), dwReadBufferSize, pFile);
						if (ferror(pFile)) 
						{
							Trace(  _T("LoadFile"),
									MF_TRACE_LEVEL_FAILED,
									10040010,
									_T("从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%I64d，读取大小：%d"),
									GetLastError(), pFileInfo->m_lpszFilePath,
									nPos, dwReadBufferSize);
							//读取文件失败
							CShareMemory::ShMemDetach(lpMapFileBuffer);
							CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
							pFileInfo->m_nShmId = 0;
							fclose(pFile);
							return E_FAIL;
						}
					} 
					else 
					{
						dwBufSize = fread(lpMapFileBuffer + nPos, sizeof(char),(DWORD) (pFileInfo->m_liFileSize.QuadPart- nPos), pFile);
						if (ferror(pFile)) 
						{
							Trace(  _T("LoadFile"),
									MF_TRACE_LEVEL_FAILED,
									10040011,
									_T("从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%lld，读取大小：%d"),
									GetLastError(), pFileInfo->m_lpszFilePath,
									nPos,
									(DWORD) (pFileInfo->m_liFileSize.QuadPart- nPos));
							//读取文件失败
							CShareMemory::ShMemDetach(lpMapFileBuffer);
							CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
							pFileInfo->m_nShmId = 0;
							fclose(pFile);
							return E_FAIL;
						}
					}

					//表示没读到数据，按道理不应该呀。
					if (dwBufSize == 0) 
					{
						Trace(  _T("LoadFile"),
								MF_TRACE_LEVEL_FAILED,
								10040012,
								_T("从物理文件读取数据时返回读取长度为0，错误码：%d，路径：%s，读取位置：%lld"),
								GetLastError(), pFileInfo->m_lpszFilePath, nPos);
						CShareMemory::ShMemDetach(lpMapFileBuffer);
						CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
						pFileInfo->m_nShmId = 0;
						fclose(pFile);
						return E_FAIL;
					}
				}
				*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart;
			}

			lpFileHead = (LPBASEFILEHEAD) lpMapFileBuffer;
			if (pFileInfo->m_bFileType == MF_SYS_FILETYPE_DATAFILE) 
			{
				if (lpFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'D', 'F')) 
				{
					Trace( _T("LoadFile"),
							MF_TRACE_LEVEL_FAILED,
							10040013,
							_T("从数据文件中读取到的数据内容中的头信息不正确，文件校验码：%d[%d]，路径：%s"),
							lpFileHead->m_nDataFlag,
							MAKEHEADFLAG('S', 'B', 'D', 'F'),
							pFileInfo->m_lpszFilePath);
					CShareMemory::ShMemDetach(lpMapFileBuffer);
					CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
					pFileInfo->m_nShmId = 0;
					fclose(pFile);
					return E_FAIL;
				}
			} 
			else if (pFileInfo->m_bFileType == MF_SYS_FILETYPE_TREEINDEXFILE) 
			{
				if(lpFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'B', 'F'))
				{
					Trace( _T("LoadFile"),
							MF_TRACE_LEVEL_FAILED,
							10040014,
							_T("从B树索引文件中读取到的数据内容中的头信息不正确，文件校验码：%d[%d]，路径：%s"),
							lpFileHead->m_nDataFlag,
							MAKEHEADFLAG('S', 'B', 'B', 'F'),
							pFileInfo->m_lpszFilePath);
					CShareMemory::ShMemDetach(lpMapFileBuffer);
					CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
					pFileInfo->m_nShmId = 0;
					fclose(pFile);
					return E_FAIL;
				}
			} 
			else if (pFileInfo->m_bFileType == MF_SYS_FILETYPE_KVINDEXFILE) 
			{
				if (lpFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'H', 'F')) 
				{
					Trace( _T("LoadFile"),
							MF_TRACE_LEVEL_FAILED,
							10040015,
							_T("从KV索引文件中读取到的数据内容中的头信息不正确，文件校验码：%d[%d]，路径：%s"),
							lpFileHead->m_nDataFlag,
							MAKEHEADFLAG('S', 'B', 'H', 'F'),
							pFileInfo->m_lpszFilePath);
					CShareMemory::ShMemDetach(lpMapFileBuffer);
					CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
					pFileInfo->m_nShmId = 0;
					fclose(pFile);
					return E_FAIL;
				}
			}
			if (lpFileHead->m_bFileNo != pFileInfo->m_bFileNo)
			{
				Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040016,
						_T("文件头信息中记录的文件编号与系统文件中的不一致，文件编号：%d[%d]，路径：%s"),
						lpFileHead->m_bFileNo, pFileInfo->m_bFileNo,
						MAKEHEADFLAG('S', 'B', 'H', 'F'),
						pFileInfo->m_lpszFilePath);
				CShareMemory::ShMemDetach(lpMapFileBuffer);
				CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
				pFileInfo->m_nShmId = 0;
				fclose(pFile);
				return E_FAIL;
			}
			//如果有故障的情况下用此方式来强行启动
			//lpFileHead->m_nFileTotalSize = pFileInfo->m_liFileSize.QuadPart;
			pFileInfo->m_pFileAddr = lpMapFileBuffer;
			pFileInfo->m_pFile = pFile;
		}
	} 
	catch (...) 
	{
		Trace(_T("LoadFile"), MF_TRACE_LEVEL_FAILED, 10040099, _T("加载物理文件到内存时出现异常，错误码：%d"), GetLastError());
		if (lpMapFileBuffer != NULL) 
		{
			CShareMemory::ShMemDetach(lpMapFileBuffer);
			lpMapFileBuffer = NULL;
		}
		if (pFileInfo->m_nShmId > 0) 
		{
			CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
			pFileInfo->m_nShmId = 0;
		}
		if (pFile != NULL) 
		{
			fclose(pFile);
			pFile = NULL;
		}
	}
	return S_OK;
#endif
}

//初始化系统管理类
HRESULT CSobeyMemStorageModule::FileCMD()
{
	HRESULT hr;
	long long nDataOffset;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPBASEFILEBLOCKMAP lpBaseFileBlockMap;

	//执行文件数据命令
	if (m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nID == MF_SYS_OBJECTTYPE_FILE)
	{
		//读取文件数据信息
		nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFullBlockMapOffset;
		while (nDataOffset != 0)
		{
			lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_lpSystemFileInfo->m_pFileAddr + nDataOffset);
			lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_lpSystemFileInfo->m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			hr = MemFileCMD(lpSystemBlockHead, m_pMemoryFileHead->m_bFileCMD);
			if (hr != S_OK)
			{
				Trace0(_T("FileCMD"), MF_TRACE_LEVEL_FAILED, 10050001, _T("加载系统文件中的内存文件数据失败"));
				return hr;
			}
			nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
		}

		nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFreeBlockMapOffset;
		while (nDataOffset != 0)
		{
			lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_lpSystemFileInfo->m_pFileAddr + nDataOffset);
			lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_lpSystemFileInfo->m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			hr = MemFileCMD(lpSystemBlockHead, m_pMemoryFileHead->m_bFileCMD);
			if (hr != S_OK)
			{
				Trace0(_T("FileCMD"), MF_TRACE_LEVEL_FAILED, 10050002, _T("加载系统文件中的内存文件数据失败"));
				return hr;
			}
			nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
		}
	}
	return S_OK;
}

//文件命令执行
BOOL CSobeyMemStorageModule::MemFileCMD(LPSYSTEMBLOCKHEAD lpSystemBlockHead, char bFileCMD)
{
	int i;
	HRESULT hr;
	BOOL bFind;
	LPFILEINFO lpFileInfo;
	LPFILE_MEMDBFILEINFO lpFileMemDBFileInfo;
	if (lpSystemBlockHead->m_nObjectID != MF_SYS_OBJECTTYPE_FILE)
	{
		//按道理不应该出现这种情况
		Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060001, _T("数据块的对象表示不正确，需要值：%d，实际值：%d"), MF_SYS_OBJECTTYPE_FILE, lpSystemBlockHead->m_nObjectID);
		return FALSE;
	}
	if (lpSystemBlockHead->m_nBlockDataStructSize != sizeof(FILE_MEMDBFILEINFO))
	{
		//结构体发生变化了？
		Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060002, _T("数据块的结构体大小发生改变，系统目前值：%d，记录值：%d"), sizeof(FILE_MEMDBFILEINFO), lpSystemBlockHead->m_nBlockDataStructSize);
		return FALSE;
	}
	//直接把定长数据转换成结构体
	lpFileMemDBFileInfo = (LPFILE_MEMDBFILEINFO)(((char*)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
	for(i = 0;i < lpSystemBlockHead->m_nDataNum; i++)
	{
		if(lpFileMemDBFileInfo[i].m_bFileCMD == MF_SYS_FILECMD_NONE)//无需任何处理
		{
		}
		else if(lpFileMemDBFileInfo[i].m_bFileCMD == MF_SYS_FILECMD_NEWFILE)//新建内存数据文件
		{
			//先查一遍，是否存在相同的内存文件
			for(lpFileInfo = m_pStorageInfo;lpFileInfo != NULL;lpFileInfo = lpFileInfo->m_pNext)
			{
				if(lpFileInfo->m_bFileNo == lpFileMemDBFileInfo[i].m_bFileNo)
				{
					//文件编号重复
					lpFileMemDBFileInfo[i].m_bFileCMD = 255;	//文件编号重复
					Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060011, _T("收到新建内存文件的指令，但发现文件编号出现重复，系统拒绝执行，文件编号：%d，原文件路径：%s，新文件路径：%s"),
						lpFileInfo->m_bFileNo, lpFileInfo->m_lpszFilePath, lpFileMemDBFileInfo[i].m_lpszFilePath);
					break;
				}
				else if(_tcsicmp(lpFileInfo->m_lpszFilePath, lpFileMemDBFileInfo[i].m_lpszFilePath) == 0)
				{
					//文件路径重复
					Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060012, _T("收到新建内存文件的指令，但发现文件路径出现重复，系统拒绝执行，文件路径：%s，原文件编号：%d，新文件编号：%d"),
						lpFileInfo->m_lpszFilePath, lpFileInfo->m_bFileNo, lpFileMemDBFileInfo[i].m_bFileNo);
					lpFileMemDBFileInfo[i].m_bFileCMD = 254;	//文件路径重复
					break;
				}
				else if(_tcsicmp(lpFileInfo->m_lpszMemFileName, lpFileMemDBFileInfo[i].m_lpszMemFileName) == 0)
				{
					//内存文件名重复
					Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060013, _T("收到新建内存文件的指令，但发现内存文件名出现重复，系统拒绝执行，内存文件名：%s，原文件编号：%d，新文件编号：%d"),
						lpFileInfo->m_lpszMemFileName, lpFileInfo->m_bFileNo, lpFileMemDBFileInfo[i].m_bFileNo);
					lpFileMemDBFileInfo[i].m_bFileCMD = 253;	//内存文件名重复
					break;
				}
			}

			if(lpFileMemDBFileInfo[i].m_bFileCMD == MF_SYS_FILECMD_NEWFILE)
			{
				lpFileInfo = new FILEINFO;
				memset(lpFileInfo, 0, sizeof(FILEINFO));
#ifdef WIN32
				memset(lpFileInfo->m_lpszFilePath, 0, sizeof(lpFileInfo->m_lpszFilePath));
				ConvertToAcp(lpFileMemDBFileInfo[i].m_lpszFilePath, lpFileInfo->m_lpszFilePath);
#else
				memcpy(lpFileInfo->m_lpszFilePath, lpFileMemDBFileInfo[i].m_lpszFilePath, 256*sizeof(char));
#endif
				memcpy(lpFileInfo->m_lpszMemFileName, lpFileMemDBFileInfo[i].m_lpszMemFileName, 64*sizeof(char));
				lpFileMemDBFileInfo[i].m_nLoadSize = 0;
				lpFileInfo->m_bFileNo	= lpFileMemDBFileInfo[i].m_bFileNo;
				lpFileInfo->m_bFileType	= lpFileMemDBFileInfo[i].m_bFileType;
				lpFileInfo->m_liFileSize.QuadPart	= lpFileMemDBFileInfo[i].m_nFileSize;
				lpFileInfo->m_pLoadSize = &lpFileMemDBFileInfo[i].m_nLoadSize;
				lpFileInfo->m_pNext		= NULL;
				lpFileInfo->m_usDatabaseGuid = m_pMemoryFileHead->m_usDatabaseGuid;
				hr = NewFile(lpFileInfo);
				if(SUCCEEDED(hr))
				{
					lpFileMemDBFileInfo[i].m_bFileCMD = 0;	//表示完成处理
					lpFileInfo->m_pNext		= m_pStorageInfo;
					m_pStorageInfo			= lpFileInfo;
				}
				else
				{
					Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060013, _T("收到新建内存文件的指令，系统执行新建内存文件时失败，文件编号：%d，文件路径：%s，内存文件名：%s"),
						lpFileInfo->m_bFileNo, lpFileInfo->m_lpszFilePath, lpFileInfo->m_lpszMemFileName);
					lpFileMemDBFileInfo[i].m_bFileCMD = 252;	//表示新建文件失败
					delete lpFileInfo;
				}
			}
		}
		else if(lpFileMemDBFileInfo[i].m_bFileCMD == MF_SYS_FILECMD_CHANGEFILEPATH)//修改内存数据文件路径
		{
			//先查一遍，是否存在相同的物理文件
			for(lpFileInfo = m_pStorageInfo;lpFileInfo != NULL;lpFileInfo = lpFileInfo->m_pNext)
			{
				if(lpFileInfo->m_bFileNo == lpFileMemDBFileInfo[i].m_bFileNo)
				{
					continue;
				}
				else if(_tcsicmp(lpFileInfo->m_lpszFilePath, lpFileMemDBFileInfo[i].m_lpszFilePath) == 0)
				{
					//文件路径重复
					Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060021, _T("收到修改物理文件路径的指令，但发现文件路径出现重复，系统拒绝执行，文件路径：%s，原文件编号：%d，新文件编号：%d"),
						lpFileInfo->m_lpszFilePath, lpFileInfo->m_bFileNo, lpFileMemDBFileInfo[i].m_bFileNo);
					lpFileMemDBFileInfo[i].m_bFileCMD = 254;	//文件路径重复
					break;
				}
			}
			//查找修改的文件实例
			bFind = false;
			for(lpFileInfo = m_pStorageInfo;lpFileInfo != NULL;lpFileInfo = lpFileInfo->m_pNext)
			{
				if(lpFileInfo->m_bFileNo == lpFileMemDBFileInfo[i].m_bFileNo)
				{
					bFind = true;
					break;
				}
			}

			//没找到
			if(!bFind)
			{
				Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060022, _T("收到修改物理文件路径的指令，但没找到指定文件信息，系统拒绝执行，原文件编号：%d，文件路径：%s，内存文件名：%s"),
					lpFileInfo->m_bFileNo, lpFileInfo->m_lpszFilePath, lpFileInfo->m_lpszMemFileName);
				lpFileMemDBFileInfo[i].m_bFileCMD = 251;	//没找到需要修改物理文件路径的原文件实例
			}
			if(lpFileMemDBFileInfo[i].m_bFileCMD == MF_SYS_FILECMD_CHANGEFILEPATH)
			{
#ifdef WIN32
				::CloseHandle(lpFileInfo->m_hFile);
				lpFileInfo->m_hFile = INVALID_HANDLE_VALUE;
#else
				fclose(lpFileInfo->m_pFile);
				lpFileInfo->m_pFile = NULL;
#endif
#ifdef WIN32
				memset(lpFileInfo->m_lpszFilePath, 0, sizeof(lpFileInfo->m_lpszFilePath));
				ConvertToAcp(lpFileMemDBFileInfo[i].m_lpszFilePath, lpFileInfo->m_lpszFilePath);
#else
				memcpy(lpFileInfo->m_lpszFilePath, lpFileMemDBFileInfo[i].m_lpszFilePath, 256*sizeof(char));
#endif
				hr = Save2File(lpFileInfo, true);
				if(SUCCEEDED(hr))
				{
					lpFileMemDBFileInfo[i].m_bFileCMD = 0;	//表示完成处理
				}
				else
				{
					//写入失败
					Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060023, _T("收到修改物理文件路径的指令，执行写入新文件失败，文件路径：%s，内存文件名：%s"), lpFileInfo->m_lpszFilePath, lpFileInfo->m_lpszMemFileName);
					lpFileMemDBFileInfo[i].m_bFileCMD = 250;	//修改失败
				}
			}
		}
		else if(lpFileMemDBFileInfo[i].m_bFileCMD == MF_SYS_FILECMD_CHANGEFILESIZE)//修改内存数据文件大小
		{
			//查找修改的文件实例
			bFind = false;
			for(lpFileInfo = m_pStorageInfo;lpFileInfo != NULL;lpFileInfo = lpFileInfo->m_pNext)
			{
				if(lpFileInfo->m_bFileNo == lpFileMemDBFileInfo[i].m_bFileNo)
				{
					bFind = true;
					break;
				}
			}

			if(!bFind)
			{
				//没找到就直接失败
				Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060031, _T("收到修改物理文件路径的指令，但没找到指定文件信息，系统拒绝执行，原文件编号：%d，文件路径：%s，内存文件名：%s"),
					lpFileInfo->m_bFileNo, lpFileInfo->m_lpszFilePath, lpFileInfo->m_lpszMemFileName);
				lpFileMemDBFileInfo[i].m_bFileCMD = 251;	//没找到需要修改物理文件路径的原文件实例
			}
			else
			{
				hr = ChangeFileSize(lpFileInfo, lpFileMemDBFileInfo[i].m_nFileSize);
				if(SUCCEEDED(hr))
				{
					lpFileMemDBFileInfo[i].m_bFileCMD = 0;	//表示完成处理
				}
				else
				{
					//写入失败
					Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060032, _T("收到修改物理文件路径的指令，执行写入新文件失败，文件路径：%s，内存文件名：%s"), lpFileInfo->m_lpszFilePath, lpFileInfo->m_lpszMemFileName);
					lpFileMemDBFileInfo[i].m_bFileCMD = 249;	//修改失败
				}
			}
		}
		else if(lpFileMemDBFileInfo[i].m_bFileCMD == MF_SYS_FILECMD_DROPFILE)//删除内存数据文件
		{
			//查找修改的文件实例
			LPFILEINFO lpPreFileInfo = NULL;
			bFind = false;
			for(lpFileInfo = m_pStorageInfo;lpFileInfo != NULL;lpFileInfo = lpFileInfo->m_pNext)
			{
				if(lpFileInfo->m_bFileNo == lpFileMemDBFileInfo[i].m_bFileNo)
				{
					bFind = true;
					break;
				}
				lpPreFileInfo = lpFileInfo;
			}

			if(!bFind)
			{
				//没找到就直接失败
				Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060041, _T("收到删除物理文件路径的指令，但没找到指定文件信息，系统拒绝执行，原文件编号：%d，文件路径：%s，内存文件名：%s"),
					lpFileInfo->m_bFileNo, lpFileInfo->m_lpszFilePath, lpFileInfo->m_lpszMemFileName);
				lpFileMemDBFileInfo[i].m_bFileCMD = 251;	//没找到需要修改物理文件路径的原文件实例
			}
			else
			{
				//首先改变数据链
				if(lpPreFileInfo == NULL)
				{
					m_pStorageInfo = lpFileInfo->m_pNext;
				}
				else
				{
					lpPreFileInfo->m_pNext = lpFileInfo->m_pNext;
				}

				//先把数据保存了
				//SaveChange2File(lpFileInfo, m_pMemoryFileHead->m_nEndTimestamp, true);

				//删除对应的内存数据
	#ifdef WIN32
				::UnmapViewOfFile(lpFileInfo->m_pFileAddr);
				::CloseHandle(lpFileInfo->m_hMemoryFile);
				::CloseHandle(lpFileInfo->m_hFile);

				if (!DeleteFile(lpFileInfo->m_lpszFilePath))
				{
					Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060042, 
						_T("收到删除物理文件路径的指令，但删除磁盘文件不成功，错误吗：%d，原文件编号：%d，文件路径：%s，内存文件名：%s"),
						GetLastError(), lpFileInfo->m_bFileNo, lpFileInfo->m_lpszFilePath, lpFileInfo->m_lpszMemFileName);
				}
				else
				{
					Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10060043, _T("删除磁盘文件成功，原文件编号：%d，文件路径：%s，内存文件名：%s"),
						lpFileInfo->m_bFileNo, lpFileInfo->m_lpszFilePath, lpFileInfo->m_lpszMemFileName);
				}
	#else
				CShareMemory::ShMemDetach(lpFileInfo->m_pFileAddr);
				if (MF_OK != remove(lpFileInfo->m_lpszFilePath))
				{
					Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_FAILED, 10060042,
							_T("收到删除物理文件路径的指令，但删除磁盘文件不成功，错误吗：%d，原文件编号：%d，文件路径：%s，内存文件名：%s"),
							GetLastError(), lpFileInfo->m_bFileNo, lpFileInfo->m_lpszFilePath, lpFileInfo->m_lpszMemFileName);
				}
				else
				{
					Trace(_T("MemFileCMD"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10060043, _T("删除磁盘文件成功，原文件编号：%d，文件路径：%s，内存文件名：%s"),
						lpFileInfo->m_bFileNo, lpFileInfo->m_lpszFilePath, lpFileInfo->m_lpszMemFileName);
				}
	#endif

				delete lpFileInfo;
				lpFileMemDBFileInfo[i].m_bFileCMD = 0;	//表示完成处理
			}
		}
	}
	return S_OK;
}


//添加文件命令
HRESULT CSobeyMemStorageModule::NewFile(LPFILEINFO pFileInfo)
{
#ifdef WIN32
	long long nPos;
	int nIndex, nBufferSize;
	SECURITY_ATTRIBUTES attr;
	LPBASEFILEHEAD lpFileHead;
	PSECURITY_DESCRIPTOR pSec;
	LARGE_INTEGER liTotalFileSize;
	HANDLE hMemoryProvider, hFile;
	char *lpMapFileBuffer, *lpBuffer;
	DWORD dwBufSize, dwReadBufferSize;

	try
	{
		nBufferSize = 8*1024*1024;
		if(pFileInfo->m_liFileSize.QuadPart < nBufferSize)
		{
			nBufferSize = pFileInfo->m_liFileSize.QuadPart;
		}
		dwReadBufferSize = 8 * 1024 * 1024;
		lpBuffer = new char[nBufferSize];//分配1MB内存；
		nIndex = 0;
		lpMapFileBuffer = NULL;
		hFile = INVALID_HANDLE_VALUE;
		hMemoryProvider = NULL;
		memset(&liTotalFileSize, 0, sizeof(liTotalFileSize));

		//先打开实际文件
		while(TRUE)
		{
			hFile = CreateFile(pFileInfo->m_lpszFilePath, 
				GENERIC_READ|GENERIC_WRITE, 
				FILE_SHARE_READ, 
				NULL, 
				OPEN_EXISTING, 
				FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN, 
				NULL);
			if (hFile != INVALID_HANDLE_VALUE)
			{
				GetFileSizeEx(hFile, &liTotalFileSize);
				::CloseHandle(hFile);
				Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070001, _T("执行添加文件命令时，由于文件存在所以新建文件失败，路径：%s"), pFileInfo->m_lpszFilePath);
				delete [] lpBuffer;
				return E_FAIL;
			}
			else
			{
				//先检查并创建对应的文件夹
				MakeDir(pFileInfo->m_lpszFilePath);
				//需要新建此文件
				hFile = CreateFile(pFileInfo->m_lpszFilePath, 
					GENERIC_READ|GENERIC_WRITE, 
					FILE_SHARE_READ, 
					NULL, 
					CREATE_NEW, 
					FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN, 
					NULL);
				if (hFile == INVALID_HANDLE_VALUE)
				{
					//新建文件也失败
					Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070002, _T("执行添加文件命令时，创建并打开文件失败，错误码：%d，路径：%s"), GetLastError(), pFileInfo->m_lpszFilePath);
					delete [] lpBuffer;
					return E_FAIL;
				}

				memset(lpBuffer, 0, nBufferSize);
				//写入文件头
				lpFileHead = (LPBASEFILEHEAD)lpBuffer;
				if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_DATAFILE)
				{
					lpFileHead->m_nDataFlag = MAKEHEADFLAG('S', 'B', 'D', 'F');
				}
				else if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_TREEINDEXFILE)
				{
					lpFileHead->m_nDataFlag = MAKEHEADFLAG('S', 'B', 'B', 'F');
				}
				else if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_KVINDEXFILE)
				{
					lpFileHead->m_nDataFlag = MAKEHEADFLAG('S', 'B', 'H', 'F');
				}
				lpFileHead->m_bFileNo = pFileInfo->m_bFileNo;
				lpFileHead->m_usDatabaseGuid = m_pMemoryFileHead->m_usDatabaseGuid;
				lpFileHead->m_nFileTotalSize = pFileInfo->m_liFileSize.QuadPart;
				if(!WriteFile(hFile, lpBuffer, nBufferSize, &dwBufSize, NULL))
				{
					//写入失败
					Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070003, _T("执行添加文件命令时，新建文件后写入第一块数据失败，错误码：%d，路径：%s"), GetLastError(), pFileInfo->m_lpszFilePath);
					::CloseHandle(hFile);
					delete [] lpBuffer;
					return E_FAIL;
				}

				//写入初始文件数据
				memset(lpBuffer, 0, nBufferSize);
				for(nPos = dwBufSize; nPos < pFileInfo->m_liFileSize.QuadPart;nPos += dwBufSize)
				{
					*pFileInfo->m_pLoadSize = nPos;
					if(pFileInfo->m_liFileSize.QuadPart - nPos > nBufferSize)
					{
						if(!WriteFile(hFile, lpBuffer, nBufferSize, &dwBufSize, NULL))
						{
							//写入失败
							Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070004, _T("执行添加文件命令时，新建文件后写入数据失败，错误码：%d，路径：%s，写入位置：%I64d，写入大小：%d"),
								GetLastError(), pFileInfo->m_lpszFilePath, nPos, nBufferSize);
							delete [] lpBuffer;
							return E_FAIL;
						}
					}
					else
					{
						if(!WriteFile(hFile, lpBuffer, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos), &dwBufSize, NULL))
						{
							//写入失败
							Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070005, _T("执行添加文件命令时，新建文件后写入数据失败，错误码：%d，路径：%s，写入位置：%I64d，写入大小：%d"),
								GetLastError(), pFileInfo->m_lpszFilePath, nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos));
							delete [] lpBuffer;
							return E_FAIL;
						}
					}
					FlushFileBuffers(hFile);
				}
				::SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
				break;
			}
		}

		delete [] lpBuffer;
		lpBuffer = NULL;
		pSec = (PSECURITY_DESCRIPTOR)LocalAlloc(LMEM_FIXED, SECURITY_DESCRIPTOR_MIN_LENGTH);
		if(!pSec)
		{
			Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070011, _T("分配安全描述信息失败，错误码：%d"), GetLastError());
			return E_FAIL;
		}
		if(!InitializeSecurityDescriptor(pSec, SECURITY_DESCRIPTOR_REVISION))
		{
			LocalFree(pSec);
			Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070012, _T("初始化安全描述信息失败，错误码：%d"), GetLastError());
			return E_FAIL;
		}
		if(!SetSecurityDescriptorDacl(pSec, TRUE, NULL, FALSE))
		{
			LocalFree(pSec);
			Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070013, _T("设置安全描述信息失败，错误码：%d"), GetLastError());
			return E_FAIL;
		}
		attr.bInheritHandle = FALSE;
		attr.lpSecurityDescriptor = pSec;
		attr.nLength = sizeof(SECURITY_ATTRIBUTES);

		//创建内存
		hMemoryProvider = CreateFileMapping(INVALID_HANDLE_VALUE, &attr, PAGE_READWRITE | SEC_COMMIT, pFileInfo->m_liFileSize.HighPart, pFileInfo->m_liFileSize.LowPart, pFileInfo->m_lpszMemFileName);
		LocalFree(pSec); 
		if (hMemoryProvider == NULL || GetLastError() == ERROR_ALREADY_EXISTS)
		{
			Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070014, _T("执行添加文件命令时，打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%I64d"),
				GetLastError(), pFileInfo->m_lpszMemFileName, pFileInfo->m_liFileSize.QuadPart);
			::CloseHandle(hFile);
			return E_FAIL;
		}

		lpMapFileBuffer = (char*)MapViewOfFile(hMemoryProvider, FILE_MAP_READ|FILE_MAP_WRITE, 0, 0, 0);
		if (lpMapFileBuffer == NULL)
		{
			Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070015, _T("执行添加文件命令时，内存文件映射内存失败，错误码：%d，内存文件：%s"),	GetLastError(), pFileInfo->m_lpszMemFileName);
			::CloseHandle(hMemoryProvider);
			::CloseHandle(hFile);
			return E_FAIL;
		}

		dwBufSize = 0;
		//既然是新文件，所以就读取第一个1MB的数据就可以了。
		memset(lpMapFileBuffer, 0, pFileInfo->m_liFileSize.QuadPart);
		ReadFile(hFile, lpMapFileBuffer, nBufferSize, &dwBufSize, NULL);
		//读取本地文件数据上传到内存中
		/*for(nPos = 0; nPos < pFileInfo->m_liFileSize.QuadPart;nPos += dwBufSize)
		{
			if(pFileInfo->m_liFileSize.QuadPart - nPos >= dwReadBufferSize)
			{
				if(!ReadFile(hFile, lpMapFileBuffer+nPos, dwReadBufferSize, &dwBufSize, NULL))
				{
					Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070021, _T("执行添加文件命令时，从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%I64d，读取大小：%d"),
						GetLastError(), pFileInfo->m_lpszFilePath, nPos, dwReadBufferSize);
					//读取文件失败
					::UnmapViewOfFile(lpMapFileBuffer);
					::CloseHandle(hMemoryProvider);
					::CloseHandle(hFile);
					return E_FAIL;
				}
			}
			else
			{
				if(!ReadFile(hFile, lpMapFileBuffer+nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos), &dwBufSize, NULL))
				{
					Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070022, _T("执行添加文件命令时，从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%I64d，读取大小：%d"),
						GetLastError(), pFileInfo->m_lpszFilePath, nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos));
					//读取文件失败
					::UnmapViewOfFile(lpMapFileBuffer);
					::CloseHandle(hMemoryProvider);
					::CloseHandle(hFile);
					return E_FAIL;
				}
			}

			//表示没读到数据，按道理不应该呀。
			if(dwBufSize == 0)
			{
				Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070023, _T("执行添加文件命令时，从物理文件读取数据时返回读取长度为0，错误码：%d，路径：%s，读取位置：%I64d"),	GetLastError(), pFileInfo->m_lpszFilePath, nPos);
				::UnmapViewOfFile(lpMapFileBuffer);
				::CloseHandle(hMemoryProvider);
				::CloseHandle(hFile);
				return E_FAIL;
			}
		}*/

		*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart;
		pFileInfo->m_hFile = hFile;
		pFileInfo->m_hMemoryFile = hMemoryProvider;
		pFileInfo->m_pFileAddr = lpMapFileBuffer;
		Trace(_T("NewFile"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10070098, _T("成功添加新文件，文件路径：%s，文件大小：%I64d"), pFileInfo->m_lpszFilePath, pFileInfo->m_liFileSize.QuadPart);
	}
	catch(...)
	{
		Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070099, _T("添加新文件时出现异常，错误码：%d，路径：%s"),	GetLastError(), pFileInfo->m_lpszFilePath);
		if(lpMapFileBuffer)
		{
			::UnmapViewOfFile(lpMapFileBuffer);
			lpMapFileBuffer = NULL;
		}
		if(hMemoryProvider)
		{
			::CloseHandle(hMemoryProvider);
			hMemoryProvider = NULL;
		}
		if(hFile != INVALID_HANDLE_VALUE)
		{
			::CloseHandle(hFile);
			hFile = NULL;
		}
		return E_FAIL;
	}

	return S_OK;
#else
	FILE* pFile;
	key_t nShmKey;
	long long nPos;
	int nIndex, nBufferSize;
	LPBASEFILEHEAD lpFileHead;
	LARGE_INTEGER liTotalFileSize;
	char *lpMapFileBuffer, *lpBuffer;
	DWORD dwBufSize, dwReadBufferSize;

	try
	{
		nBufferSize = 8*1024*1024;
		if(pFileInfo->m_liFileSize.QuadPart < nBufferSize)
		{
			nBufferSize = pFileInfo->m_liFileSize.QuadPart;
		}
		dwReadBufferSize = 8 * 1024 * 1024;
		lpBuffer = new char[nBufferSize];//分配1MB内存；
		nIndex = 0;
		lpMapFileBuffer = NULL;
		pFile = NULL;
		memset(&liTotalFileSize, 0, sizeof(liTotalFileSize));

		//先打开实际文件
		while(true)
		{
			if(_taccess(pFileInfo->m_lpszFilePath, F_OK) == 0)
			{
				pFile = fopen(pFileInfo->m_lpszFilePath, "rb");
				if(pFile != NULL)
				{
					liTotalFileSize.QuadPart = GetFileSize(pFile);
					fclose(pFile);
				}
				Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070001 , _T("执行添加文件命令时，由于文件存在所以新建文件失败，路径：%s"), pFileInfo->m_lpszFilePath);
				delete [] lpBuffer;
				return E_FAIL;
			}
			else
			{
				//先检查并创建对应的文件夹
				MakeDir(pFileInfo->m_lpszFilePath);
				//需要新建此文件
				pFile = fopen(pFileInfo->m_lpszFilePath, "wb+");
				if(pFile == NULL)
				{
					//新建文件也失败
					Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070002 , _T("执行添加文件命令时，创建并打开文件失败，错误码：%d，路径：%s"), GetLastError(), pFileInfo->m_lpszFilePath);
					delete [] lpBuffer;
					return E_FAIL;
				}

				memset(lpBuffer, 0, nBufferSize);
				//写入文件头
				lpFileHead = (LPBASEFILEHEAD)lpBuffer;
				if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_DATAFILE)
				{
					lpFileHead->m_nDataFlag = MAKEHEADFLAG('S', 'B', 'D', 'F');
				}
				else if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_TREEINDEXFILE)
				{
					lpFileHead->m_nDataFlag = MAKEHEADFLAG('S', 'B', 'B', 'F');
				}
				else if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_KVINDEXFILE)
				{
					lpFileHead->m_nDataFlag = MAKEHEADFLAG('S', 'B', 'H', 'F');
				}
				lpFileHead->m_bFileNo = pFileInfo->m_bFileNo;
				lpFileHead->m_nFileTotalSize = pFileInfo->m_liFileSize.QuadPart;
				fseek(pFile, 0, SEEK_SET);
				dwBufSize = fwrite(lpBuffer, sizeof(char), nBufferSize, pFile);
				if(ferror(pFile))
				{
					//写入失败
					Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070003 , _T("执行添加文件命令时，新建文件后写入第一块数据失败，错误码：%d，路径：%s"), GetLastError(), pFileInfo->m_lpszFilePath);
					fclose(pFile);
					delete [] lpBuffer;
					return E_FAIL;
				}

				//写入初始文件数据
				memset(lpBuffer, 0, nBufferSize);
				for(nPos = dwBufSize; nPos < pFileInfo->m_liFileSize.QuadPart;nPos += dwBufSize)
				{
					*pFileInfo->m_pLoadSize = nPos;
					if(pFileInfo->m_liFileSize.QuadPart - nPos > nBufferSize)
					{
						dwBufSize = fwrite(lpBuffer, sizeof(char), nBufferSize, pFile);
						if(ferror(pFile))
						{
							//写入失败
							Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070004 , _T("执行添加文件命令时，新建文件后写入数据失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
									GetLastError(), pFileInfo->m_lpszFilePath, nPos, nBufferSize);
							fclose(pFile);
							delete [] lpBuffer;
							return E_FAIL;
						}
					}
					else
					{
						dwBufSize = fwrite(lpBuffer, sizeof(char), (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos), pFile);
						if(ferror(pFile))
						{
							//写入失败
							Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070005 , _T("执行添加文件命令时，新建文件后写入数据失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
									GetLastError(), pFileInfo->m_lpszFilePath, nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos));
							fclose(pFile);
							delete [] lpBuffer;
							return E_FAIL;
						}
					}
				}
				fflush(pFile);
				break;
			}
		}

		delete [] lpBuffer;
		lpBuffer = NULL;
		//创建内存
		nShmKey = MF_MEMFILE_BASEKEY + pFileInfo->m_bFileNo;
		pFileInfo->m_nShmId = CShareMemory::CreateShareMemory(nShmKey, pFileInfo->m_liFileSize.QuadPart, NULL);
		if(pFileInfo->m_nShmId == -1 || GetLastError() == EEXIST)
		{
			Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070014 , _T("执行添加文件命令时，打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%lld"),
					GetLastError(), pFileInfo->m_lpszMemFileName, pFileInfo->m_liFileSize.QuadPart);
			fclose(pFile);
			return E_FAIL;
		}
		lpMapFileBuffer = (char*)CShareMemory::ShMemAttach(pFileInfo->m_nShmId);
		if (lpMapFileBuffer == NULL)
		{
			Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070015 , _T("执行添加文件命令时，内存文件映射内存失败，错误码：%d，内存文件：%s"),	GetLastError(), pFileInfo->m_lpszMemFileName);
			fclose(pFile);
			CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
			pFileInfo->m_nShmId = 0;
			return E_FAIL;
		}

		dwBufSize = 0;
		fseek(pFile, 0, SEEK_SET);
		//既然是新文件，所以就读取第一个1MB的数据就可以了。
		memset(lpMapFileBuffer, 0, pFileInfo->m_liFileSize.QuadPart);
		fread(lpMapFileBuffer, sizeof(char), nBufferSize, pFile);
		//读取本地文件数据上传到内存中
		/*for(nPos = 0; nPos < pFileInfo->m_liFileSize.QuadPart;nPos += dwBufSize)
		{
			if(pFileInfo->m_liFileSize.QuadPart - nPos >= (int)dwReadBufferSize)
			{
				dwBufSize = fread(lpMapFileBuffer+nPos, sizeof(char), dwReadBufferSize, pFile);
				if(ferror(pFile))
				{
					Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070021 , _T("执行添加文件命令时，从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%lld，读取大小：%d"),
							GetLastError(), pFileInfo->m_lpszFilePath, nPos, dwReadBufferSize);
					//读取文件失败
					CShareMemory::ShMemDetach(lpMapFileBuffer);
					CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
					pFileInfo->m_nShmId = 0;
					fclose(pFile);
					return E_FAIL;
				}
			}
			else
			{
				dwBufSize = fread(lpMapFileBuffer+nPos, sizeof(char), (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos), pFile);
				if(ferror(pFile))
				{
					Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070022 , _T("执行添加文件命令时，从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%lld，读取大小：%d"),
							GetLastError(), pFileInfo->m_lpszFilePath, nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos));
					//读取文件失败
					CShareMemory::ShMemDetach(lpMapFileBuffer);
					CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
					pFileInfo->m_nShmId = 0;
					fclose(pFile);
					return E_FAIL;
				}
			}

			//表示没读到数据，按道理不应该呀。
			if(dwBufSize == 0)
			{
				Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070023 , _T("执行添加文件命令时，从物理文件读取数据时返回读取长度为0，错误码：%d，路径：%s，读取位置：%lld"),	GetLastError(), pFileInfo->m_lpszFilePath, nPos);
				CShareMemory::ShMemDetach(lpMapFileBuffer);
				CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
				pFileInfo->m_nShmId = 0;
				fclose(pFile);
				return E_FAIL;
			}
		}*/
		*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart;
		pFileInfo->m_pFile 	  = pFile;
		pFileInfo->m_pFileAddr = lpMapFileBuffer;
		Trace(_T("NewFile"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10070098 , _T("成功添加新文件，文件路径：%s，文件大小：%lld"), pFileInfo->m_lpszFilePath, pFileInfo->m_liFileSize.QuadPart);
	}
	catch(...)
	{
		Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070099 , _T("添加新文件时出现异常，错误码：%d，路径：%s"),	GetLastError(), pFileInfo->m_lpszFilePath);
		if(lpMapFileBuffer)
		{
			CShareMemory::ShMemDetach(lpMapFileBuffer);
			lpMapFileBuffer = NULL;
		}
		if(pFileInfo->m_nShmId > 0)
		{
			CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
			pFileInfo->m_nShmId = 0;
		}
		if(pFile != NULL)
		{
			fclose(pFile);
			pFile = NULL;
		}
		return E_FAIL;
	}

	return S_OK;
#endif
}

//保存修改数据
HRESULT CSobeyMemStorageModule::Save2File(LPFILEINFO pFileInfo, BOOL bNewFile)
{
#ifdef WIN32
	long long nPos;
	HANDLE hFile;
	DWORD dwBufSize, dwBufferSize;

	try
	{
		hFile = NULL;
		if(bNewFile)
		{
			int nIndex;
			nIndex = 0;
			hFile = INVALID_HANDLE_VALUE;
			//先打开实际文件
			while(TRUE)
			{
				hFile = CreateFile(pFileInfo->m_lpszFilePath, 
					GENERIC_READ|GENERIC_WRITE, 
					FILE_SHARE_READ, 
					NULL, 
					OPEN_EXISTING, 
					FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN, 
					NULL);
				if (hFile != INVALID_HANDLE_VALUE)
				{
					Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080001, _T("执行修改物理文件路径命令时，由于文件存在所以失败，路径：%s"), pFileInfo->m_lpszFilePath);
					return E_FAIL;
				}
				else
				{
					//先检查并创建对应的文件夹
					MakeDir(pFileInfo->m_lpszFilePath);
					//需要新建此文件
					hFile = CreateFile(pFileInfo->m_lpszFilePath, 
						GENERIC_READ|GENERIC_WRITE, 
						FILE_SHARE_READ, 
						NULL, 
						CREATE_NEW, 
						FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN, 
						NULL);
					if (hFile == INVALID_HANDLE_VALUE)
					{
						//新建文件也失败
						Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080002, _T("执行修改物理文件路径命令时，新建并打开文件失败，错误码：%d，路径：%s"), GetLastError(), pFileInfo->m_lpszFilePath);
						return E_FAIL;
					}
					break;
				}
			}
		}
		else
		{
			hFile = pFileInfo->m_hFile;
		}
		if (hFile == INVALID_HANDLE_VALUE)
		{
			//新建文件也失败
			Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080003, _T("把内存数据写入物理文件时，发现文件句柄为无效值，路径：%s"), pFileInfo->m_lpszFilePath);
			return E_FAIL;
		}
		if(pFileInfo->m_pFileAddr == NULL)
		{
			//新建文件也失败
			Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080004, _T("把内存数据写入物理文件时，发现内存指针为空值，路径：%s"), pFileInfo->m_lpszFilePath);
			return E_FAIL;
		}

		dwBufSize = 0;
		dwBufferSize = 8 * 1024 * 1024;
		::SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
		for(nPos = 0; nPos < pFileInfo->m_liFileSize.QuadPart;nPos += dwBufSize)
		{
			if(bNewFile)
			{
				*pFileInfo->m_pLoadSize = nPos;
			}

			if(pFileInfo->m_liFileSize.QuadPart - nPos > dwBufferSize)
			{
				if(!WriteFile(hFile, pFileInfo->m_pFileAddr + nPos, dwBufferSize, &dwBufSize, NULL))
				{
					//写入失败
					Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080011, _T("把内存数据写入物理文件失败，错误码：%d，路径：%s，写入位置：%I64d，写入大小：%d"),
						GetLastError(), pFileInfo->m_lpszFilePath, nPos, dwBufferSize);
					if(bNewFile) ::CloseHandle(hFile);
					return E_FAIL;
				}
			}
			else
			{
				if(!WriteFile(hFile, pFileInfo->m_pFileAddr + nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos), &dwBufSize, NULL))
				{
					//写入失败
					Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080012, _T("把内存数据写入物理文件失败，错误码：%d，路径：%s，写入位置：%I64d，写入大小：%d"),
						GetLastError(), pFileInfo->m_lpszFilePath, nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos));
					if(bNewFile) ::CloseHandle(hFile);
					return E_FAIL;
				}
			}
		}
		if(bNewFile)
		{
			*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart;
		}
		FlushFileBuffers(hFile);
	}
	catch(...)
	{
		Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080099, _T("把内存数据写入物理文件时出现异常，错误码：%d，路径：%s"), GetLastError(), pFileInfo->m_lpszFilePath);
		if(bNewFile) ::CloseHandle(hFile);
		return E_FAIL;
	}
	if(bNewFile)
	{
		if(pFileInfo->m_hFile != NULL && pFileInfo->m_hFile != INVALID_HANDLE_VALUE)
		{
			::CloseHandle(pFileInfo->m_hFile);
			pFileInfo->m_hFile = NULL;
		}
		pFileInfo->m_hFile = hFile;
		Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070098, _T("文件路径修改成功，文件路径：%s，文件大小：%I64d"), pFileInfo->m_lpszFilePath, pFileInfo->m_liFileSize.QuadPart);
	}
	return S_OK;
#else
	FILE* pFile;
	long long nPos;
	DWORD dwBufSize, dwBufferSize;

	try
	{
		pFile = NULL;
		if(bNewFile)
		{
			int nIndex;
			nIndex = 0;
			//先打开实际文件
			while(true)
			{

				if(_taccess(pFileInfo->m_lpszFilePath, F_OK))
				{
					Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080001 , _T("执行修改物理文件路径命令时，由于文件存在所以失败，路径：%s"), pFileInfo->m_lpszFilePath);
					return E_FAIL;
				}
				else
				{
					//先检查并创建对应的文件夹
					MakeDir(pFileInfo->m_lpszFilePath);
					//需要新建此文件
					pFile = fopen(pFileInfo->m_lpszFilePath, "wb+");
					if (pFile == NULL)
					{
						//新建文件也失败
						Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080002 , _T("执行修改物理文件路径命令时，新建并打开文件失败，错误码：%d，路径：%s"), GetLastError(), pFileInfo->m_lpszFilePath);
						return E_FAIL;
					}
					break;
				}
			}
		}
		else
		{
			pFile = pFileInfo->m_pFile;
		}
		if (pFile == NULL)
		{
			//新建文件也失败
			Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080003 , _T("把内存数据写入物理文件时，发现文件句柄为无效值，路径：%s"), pFileInfo->m_lpszFilePath);
			return E_FAIL;
		}
		if(pFileInfo->m_pFileAddr == NULL)
		{
			//新建文件也失败
			Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080004 , _T("把内存数据写入物理文件时，发现内存指针为空值，路径：%s"), pFileInfo->m_lpszFilePath);
			return E_FAIL;
		}

		dwBufSize = 0;
		dwBufferSize = 8 * 1024 * 1024;
		fseek(pFile, 0, SEEK_SET);
		for(nPos = 0; nPos < pFileInfo->m_liFileSize.QuadPart; nPos += dwBufSize)
		{
			if(bNewFile)
			{
				*pFileInfo->m_pLoadSize = nPos;
			}
			if(pFileInfo->m_liFileSize.QuadPart - nPos > (int)dwBufferSize)
			{
				dwBufSize = fwrite(pFileInfo->m_pFileAddr + nPos, sizeof(char), dwBufferSize, pFile);
				if(ferror(pFile))
				{
					//写入失败
					Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080011 , _T("把内存数据写入物理文件失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
							GetLastError(), pFileInfo->m_lpszFilePath, nPos, dwBufferSize);
					return E_FAIL;
				}
			}
			else
			{
				dwBufSize = fwrite(pFileInfo->m_pFileAddr + nPos, sizeof(char), (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos), pFile);
				if(ferror(pFile))
				{
					//写入失败
					Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080012 , _T("把内存数据写入物理文件失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
							GetLastError(), pFileInfo->m_lpszFilePath, nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos));
					return E_FAIL;
				}
			}
		}
		if(bNewFile)
		{
			*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart;
		}
		fflush(pFile);
	}
	catch(...)
	{
		Trace(_T("Save2File"), MF_TRACE_LEVEL_FAILED, 10080099 , _T("把内存数据写入物理文件时出现异常，错误码：%d，路径：%s"), GetLastError(), pFileInfo->m_lpszFilePath);
		return E_FAIL;
	}
	if(bNewFile)
	{
		if(pFileInfo->m_pFile != NULL)
		{
			pFileInfo->m_pFile = NULL;
		}
		pFileInfo->m_pFile = pFile;
		Trace(_T("NewFile"), MF_TRACE_LEVEL_FAILED, 10070098 , _T("文件路径修改成功，文件路径：%s，文件大小：%lld"), pFileInfo->m_lpszFilePath, pFileInfo->m_liFileSize.QuadPart);
	}
	return S_OK;
#endif
}

//服务推出前释放所有资源
HRESULT CSobeyMemStorageModule::FreeData()
{
	LPFILEINFO	pFileInfo, pNext;
	try
	{
		//保存系统配置参数
		WriteSysConfigParam(m_pMemoryFileHead);
		//释放普通文件
		pFileInfo = m_pStorageInfo;
		m_pStorageInfo = NULL;
		while(pFileInfo)
		{
			pNext = pFileInfo->m_pNext;
#ifdef WIN32
			FlushFileBuffers(pFileInfo->m_hFile);
			::UnmapViewOfFile(pFileInfo->m_pFileAddr);
			::CloseHandle(pFileInfo->m_hMemoryFile);
			::CloseHandle(pFileInfo->m_hFile);
#else
			fflush(pFileInfo->m_pFile);
			CShareMemory::ShMemDetach(pFileInfo->m_pFileAddr);
			CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
			fclose(pFileInfo->m_pFile);
#endif
			delete pFileInfo;
			pFileInfo = pNext;
		}

		if (m_lpSystemFileInfo)
		{
			m_pMemoryFileHead = NULL;
#ifdef WIN32
			FlushFileBuffers(m_lpSystemFileInfo->m_hFile);
			::UnmapViewOfFile(m_lpSystemFileInfo->m_pFileAddr);
			::CloseHandle(m_lpSystemFileInfo->m_hMemoryFile);
			::CloseHandle(m_lpSystemFileInfo->m_hFile);
#else
			fflush(m_lpSystemFileInfo->m_pFile);
			CShareMemory::ShMemDetach(m_lpSystemFileInfo->m_pFileAddr);
			CShareMemory::DestoryShareMemory(m_lpSystemFileInfo->m_nShmId);
			fclose(m_lpSystemFileInfo->m_pFile);
#endif
			delete m_lpSystemFileInfo;
			m_lpSystemFileInfo = NULL;
		}

		if (m_pSaveBlockBuffer != NULL)
		{
			delete[] m_pSaveBlockBuffer;
		}

#ifdef WIN32
		if(m_pStorageMemFileAddr != NULL)
		{
			::UnmapViewOfFile(m_pStorageMemFileAddr);
			m_pStorageMemFileAddr = NULL;
		}
		if(m_hStorageMemFileFile != NULL)
		{
			::CloseHandle(m_hStorageMemFileFile);
			m_hStorageMemFileFile = NULL;
		}
#else
		if(m_pStorageMemFileAddr != NULL)
		{
			CShareMemory::ShMemDetach(m_pStorageMemFileAddr);
			m_pStorageMemFileAddr = NULL;
		}
		if(m_nStorageMemFileShmId > 0)
		{
			CShareMemory::DestoryShareMemory(m_nStorageMemFileShmId);
			m_nStorageMemFileShmId = 0;
		}
#endif
	}
	catch(...)
	{
		Trace(_T("FreeData"), MF_TRACE_LEVEL_FAILED, 10090099, _T("服务退出时出现异常失败，错误码：%d"),	GetLastError());
		return E_FAIL;
	}
	Trace0(_T("SobeyMemStorage"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10000001, _T("索贝内存存储服务停止"));
#ifdef WIN32
	::CloseHandle(m_hEvent);
	m_hEvent = NULL;
#else
	sem_close(m_pEvent);
	m_pEvent = NULL;
#endif
	ExitLogSystem();
	return S_OK;
}

//////////////////////////////////////////////////////////////////////////
//函数：SaveChange2File
//说明：保存修改数据
//参数：
//	bForce = False		判断数据是否更新，保存更新的数据。没有更新则不保存
//	bForce = True		保存所有数据
//返回值：
//////////////////////////////////////////////////////////////////////////
HRESULT CSobeyMemStorageModule::SaveChange2File(BOOL bForce, int &nRedoLogMaxID)
{
	HRESULT hr;
	HRESULT hresult;
	LPFILEINFO pFileInfo;
	long long nEndTimestamp;
	DWORD dwSizeToWrite, dwSizeWritten;
	LARGE_INTEGER liMovePos, liNewFilePos;
	try
	{
		nEndTimestamp = m_pMemoryFileHead->m_nEndTimestamp; //此项数据会随时改变，所以先记到一个变量中
		if(m_pMemoryFileHead->m_nBeginTimestamp < nEndTimestamp || bForce)
		{
			//首先保存系统文件
			hr = SaveChange2File(m_lpSystemFileInfo, nEndTimestamp, bForce);
			hresult = hr;

			//然后再保存普通文件
			for(pFileInfo = m_pStorageInfo; pFileInfo != NULL; pFileInfo = pFileInfo->m_pNext)
			{
				hr = SaveChange2File(pFileInfo, nEndTimestamp, bForce);
				if (!SUCCEEDED(hresult))
				{
					hresult = E_FAIL;
				}
			}
		}
		else
		{
			hresult = S_OK;
		}

		//没有失败情况，就修改时间戳，保证下次保存的数据量会更小
		if(hresult == S_OK)
		{
			if (m_pMemoryFileHead->m_nBeginTimestamp == nEndTimestamp && m_pMemoryFileHead->m_nRedoLogMaxID == nRedoLogMaxID)
			{
				;
			} 
			else
			{
				nRedoLogMaxID = m_pMemoryFileHead->m_nRedoLogMaxID;
				m_pMemoryFileHead->m_nBeginTimestamp = nEndTimestamp;
				//需要将修改后的时间戳也写入到磁盘中
				liMovePos.QuadPart = (LPBYTE)&m_pMemoryFileHead->m_nFileFreeSize - (LPBYTE)m_pMemoryFileHead;
				dwSizeToWrite = (LPBYTE)&m_pMemoryFileHead->m_cDatabaseName - (LPBYTE)&m_pMemoryFileHead->m_nFileFreeSize;
#ifdef WIN32
				if(!::SetFilePointerEx(m_lpSystemFileInfo->m_hFile, liMovePos, &liNewFilePos, FILE_BEGIN))
				{
					Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10110001, _T("设置物理文件位置失败，错误码：%d，路径：%s，位置：%d"), GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, liMovePos.QuadPart);
					return E_FAIL;
				}
				//取出来确认一下位置是否正确
				if(liMovePos.QuadPart != liNewFilePos.QuadPart)
				{
					//定位的位置不正确
					Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10110002, _T("设置物理文件位置不正确，错误码：%d，路径：%s，设置位置：%d，返回位置：%I64d"), GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, liMovePos.QuadPart, liNewFilePos.QuadPart);
					return E_FAIL;
				}
				//实际写入数据
				if(!WriteFile(m_lpSystemFileInfo->m_hFile, &m_pMemoryFileHead->m_nFileFreeSize, dwSizeToWrite, &dwSizeWritten, NULL))
				{
					//写入失败
					Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10110003, _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：%d，写入大小：%d"),	GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, liMovePos.QuadPart, dwSizeToWrite);
					return E_FAIL;
				}
#else
				if(MF_OK != fseek(m_lpSystemFileInfo->m_pFile, liMovePos.QuadPart, SEEK_SET))
				{
					Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10110001, _T("设置物理文件位置失败，错误码：%d，路径：%s，位置：%d"), GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, liMovePos.QuadPart);
					return E_FAIL;
				}
				//取出来确认一下位置是否正确
				if(liMovePos.QuadPart != ftell(m_lpSystemFileInfo->m_pFile))
				{
					//定位的位置不正确
					Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10110002, _T("设置物理文件位置不正确，错误码：%d，路径：%s，设置位置：%d，返回位置：%I64d"), GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, liMovePos.QuadPart, liNewFilePos.QuadPart);
					return E_FAIL;
				}
	
				dwSizeWritten = fwrite(&m_pMemoryFileHead->m_nFileFreeSize, sizeof(char), dwSizeToWrite, m_lpSystemFileInfo->m_pFile);
				if(ferror(m_lpSystemFileInfo->m_pFile))
				{
					//写入失败
					Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10110003, _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：%d，写入大小：%d"),	GetLastError(), m_lpSystemFileInfo->m_lpszFilePath, liMovePos.QuadPart, dwSizeToWrite);
					return E_FAIL;
				}
#endif
			}
		}
	}
	catch(...)
	{
		Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10110099, _T("从内存写入到物理文件出现异常失败，错误码：%d"),	GetLastError());
	}

	return S_OK;
}

//修改文件大小命令
HRESULT CSobeyMemStorageModule::ChangeFileSize(LPFILEINFO pFileInfo, long long nFileSize)
{
#ifdef WIN32
	HRESULT hr;
	long long nPos;
	int nBufferSize;
	HANDLE hMemoryProvider;
	SECURITY_ATTRIBUTES attr;
	PSECURITY_DESCRIPTOR pSec;
	LARGE_INTEGER liTotalFileSize;
	LPBASEFILEHEAD lpBaseFileHead;
	char* lpMapFileBuffer, *lpBuffer;
	DWORD dwBufSize, dwReadBufferSize;

	try
	{
		nBufferSize = 1024*1024;
		dwReadBufferSize = 8 * 1024 * 1024;
		lpBuffer = new char[nBufferSize];//分配1MB内存；
		hr = SaveChange2File(pFileInfo, m_pMemoryFileHead->m_nEndTimestamp, TRUE);
		if(FAILED(hr))
		{
			delete [] lpBuffer;
			return hr;
		}
		dwBufSize = 0;
		lpMapFileBuffer = pFileInfo->m_pFileAddr;
		if(lpMapFileBuffer == NULL)
		{
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120001, _T("修改文件大小时发现内存指针为空，文件路径：%s"),	pFileInfo->m_lpszFilePath);
			delete [] lpBuffer;
			return E_FAIL;
		}

		lpBaseFileHead = (LPBASEFILEHEAD)lpMapFileBuffer;
		lpBaseFileHead->m_nFileTotalSize = nFileSize;
		//写入初始文件数据，目前只考虑增大的情况
		::SetFilePointer(pFileInfo->m_hFile, 0, NULL, FILE_END);
		memset(lpBuffer, 0, nBufferSize);
		for(nPos = pFileInfo->m_liFileSize.QuadPart; nPos < nFileSize;nPos += dwBufSize)
		{
			*pFileInfo->m_pLoadSize = nPos/2;
			if(nFileSize > nBufferSize)
			{
				if(!WriteFile(pFileInfo->m_hFile, lpBuffer, nBufferSize, &dwBufSize, NULL))
				{
					//写入失败
					Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120002, _T("执行添加文件命令时，新建文件后写入数据失败，错误码：%d，路径：%s，写入位置：%I64d，写入大小：%d"),
						GetLastError(), pFileInfo->m_lpszFilePath, nPos, nBufferSize);
					delete [] lpBuffer;
					return E_FAIL;
				}
			}
			else
			{
				if(!WriteFile(pFileInfo->m_hFile, lpBuffer, (DWORD)(nFileSize - nPos), &dwBufSize, NULL))
				{
					//写入失败
					Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120003, _T("执行添加文件命令时，新建文件后写入数据失败，错误码：%d，路径：%s，写入位置：%I64d，写入大小：%d"),
						GetLastError(), pFileInfo->m_lpszFilePath, nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos));
					delete [] lpBuffer;
					return E_FAIL;
				}
			}
		}
		*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart/2;
		delete [] lpBuffer;
		lpBuffer = NULL;
		FlushFileBuffers(pFileInfo->m_hFile);
		GetFileSizeEx(pFileInfo->m_hFile, &liTotalFileSize);
		if(nFileSize != liTotalFileSize.QuadPart)
		{
			//文件大小怎么不对呢？
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120004, _T("文件大小出现异常，需要增长到的文件大小为：%I64d，而实际获取到的文件大小为：%I64d，文件路径：%s"),nFileSize, liTotalFileSize.QuadPart, pFileInfo->m_lpszFilePath);
			return E_FAIL;
		}
		::SetFilePointer(pFileInfo->m_hFile, 0, NULL, FILE_BEGIN);
		//首先保存一下文件头信息，包括头结构体和BLOCKMAP信息
		if(!WriteFile(pFileInfo->m_hFile, lpBaseFileHead, lpBaseFileHead->m_nFileHeaderSize, &dwBufSize, NULL))
		{
			//写入失败
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120005, _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：0，写入大小：%d"),	GetLastError(), pFileInfo->m_lpszFilePath, lpBaseFileHead->m_nFileHeaderSize);
			return E_FAIL;
		}
		pFileInfo->m_liFileSize.QuadPart = liTotalFileSize.QuadPart;
		::SetFilePointer(pFileInfo->m_hFile, 0, NULL, FILE_BEGIN);

		//关闭内存文件
		::UnmapViewOfFile(pFileInfo->m_pFileAddr);
		::CloseHandle(pFileInfo->m_hMemoryFile);
		pFileInfo->m_pFileAddr = NULL;
		pFileInfo->m_hMemoryFile = NULL;

		Sleep(200);

		//重新打开内存句柄
		pSec = (PSECURITY_DESCRIPTOR)LocalAlloc(LMEM_FIXED, SECURITY_DESCRIPTOR_MIN_LENGTH);
		if(!pSec)
		{
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120011, _T("分配安全描述信息失败，错误码：%d"), GetLastError());
			return E_FAIL;
		}
		if(!InitializeSecurityDescriptor(pSec, SECURITY_DESCRIPTOR_REVISION))
		{
			LocalFree(pSec);
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120012, _T("初始化安全描述信息失败，错误码：%d"), GetLastError());
			return E_FAIL;
		}
		if(!SetSecurityDescriptorDacl(pSec, TRUE, NULL, FALSE))
		{
			LocalFree(pSec);
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120013, _T("设置安全描述信息失败，错误码：%d"), GetLastError());
			return E_FAIL;
		}
		attr.bInheritHandle = FALSE;
		attr.lpSecurityDescriptor = pSec;
		attr.nLength = sizeof(SECURITY_ATTRIBUTES);

		//创建内存
		hMemoryProvider = CreateFileMapping(INVALID_HANDLE_VALUE, &attr, PAGE_READWRITE | SEC_COMMIT, pFileInfo->m_liFileSize.HighPart, pFileInfo->m_liFileSize.LowPart, pFileInfo->m_lpszMemFileName);
		LocalFree(pSec); 
		if (hMemoryProvider == NULL || GetLastError() == ERROR_ALREADY_EXISTS)
		{
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120014, _T("执行添加文件命令时，打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%I64d"),
				GetLastError(), pFileInfo->m_lpszMemFileName, pFileInfo->m_liFileSize.QuadPart);
			::CloseHandle(pFileInfo->m_hFile);
			pFileInfo->m_hFile = NULL;
			return E_FAIL;
		}

		lpMapFileBuffer = (char*)MapViewOfFile(hMemoryProvider, FILE_MAP_READ|FILE_MAP_WRITE, 0, 0, 0);
		if (lpMapFileBuffer == NULL)
		{
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120015, _T("执行添加文件命令时，内存文件映射内存失败，错误码：%d，内存文件：%s"),	GetLastError(), pFileInfo->m_lpszMemFileName);
			::CloseHandle(hMemoryProvider);
			::CloseHandle(pFileInfo->m_hFile);
			pFileInfo->m_hFile = NULL;
			return E_FAIL;
		}

		dwBufSize = 0;
		//读取本地文件数据上传到内存中
		for(nPos = 0; nPos < pFileInfo->m_liFileSize.QuadPart;nPos += dwBufSize)
		{
			*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart/2 + nPos/2;
			if(pFileInfo->m_liFileSize.QuadPart - nPos >= dwReadBufferSize)
			{
				if(!ReadFile(pFileInfo->m_hFile, lpMapFileBuffer+nPos, dwReadBufferSize, &dwBufSize, NULL))
				{
					Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120021, _T("执行添加文件命令时，从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%I64d，读取大小：%d"),
						GetLastError(), pFileInfo->m_lpszFilePath, nPos, dwReadBufferSize);
					//读取文件失败
					::UnmapViewOfFile(lpMapFileBuffer);
					::CloseHandle(hMemoryProvider);
					::CloseHandle(pFileInfo->m_hFile);
					pFileInfo->m_hFile = NULL;
					return E_FAIL;
				}
			}
			else
			{
				if(!ReadFile(pFileInfo->m_hFile, lpMapFileBuffer+nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos), &dwBufSize, NULL))
				{
					Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120022, _T("执行添加文件命令时，从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%I64d，读取大小：%d"),
						GetLastError(), pFileInfo->m_lpszFilePath, nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos));
					//读取文件失败
					::UnmapViewOfFile(lpMapFileBuffer);
					::CloseHandle(hMemoryProvider);
					::CloseHandle(pFileInfo->m_hFile);
					pFileInfo->m_hFile = NULL;
					return E_FAIL;
				}
			}

			//表示没读到数据，按道理不应该呀。
			if(dwBufSize == 0)
			{
				Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120023, _T("执行添加文件命令时，从物理文件读取数据时返回读取长度为0，错误码：%d，路径：%s，读取位置：%I64d"),	GetLastError(), pFileInfo->m_lpszFilePath, nPos);
				::UnmapViewOfFile(lpMapFileBuffer);
				::CloseHandle(hMemoryProvider);
				::CloseHandle(pFileInfo->m_hFile);
				pFileInfo->m_hFile = NULL;
				return E_FAIL;
			}
		}

		*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart;
		pFileInfo->m_hMemoryFile = hMemoryProvider;
		pFileInfo->m_pFileAddr = lpMapFileBuffer;
		Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10120098, _T("成功修改文件大小，文件路径：%s，文件大小：%I64d"), pFileInfo->m_lpszFilePath, pFileInfo->m_liFileSize.QuadPart);
	}
	catch(...)
	{
		Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120099, _T("添加新文件时出现异常，错误码：%d，路径：%s"),	GetLastError(), pFileInfo->m_lpszFilePath);
		if(lpMapFileBuffer)
		{
			::UnmapViewOfFile(lpMapFileBuffer);
			lpMapFileBuffer = NULL;
		}
		if(hMemoryProvider)
		{
			::CloseHandle(hMemoryProvider);
			hMemoryProvider = NULL;
		}
		if(pFileInfo->m_hFile != INVALID_HANDLE_VALUE)
		{
			::CloseHandle(pFileInfo->m_hFile);
			pFileInfo->m_hFile = NULL;
		}
		return E_FAIL;
	}

	return S_OK;
#else
	HRESULT hr;
	key_t nShmKey;
	long long nPos;
	int nBufferSize;
	LARGE_INTEGER liTotalFileSize;
	LPBASEFILEHEAD lpBaseFileHead;
	char* lpMapFileBuffer, *lpBuffer;
	DWORD dwBufSize, dwReadBufferSize;

	try
	{
		nBufferSize = 1024*1024;
		dwReadBufferSize = 8 * 1024 * 1024;
		lpBuffer = new char[nBufferSize];//分配1MB内存；
		hr = SaveChange2File(pFileInfo, m_pMemoryFileHead->m_nEndTimestamp, true);
		if(FAILED(hr))
		{
			delete [] lpBuffer;
			return hr;
		}
		dwBufSize = 0;
		lpMapFileBuffer = pFileInfo->m_pFileAddr;
		if(lpMapFileBuffer == NULL)
		{
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120001 , _T("修改文件大小时发现内存指针为空，文件路径：%s"),	pFileInfo->m_lpszFilePath);
			delete [] lpBuffer;
			return E_FAIL;
		}

		lpBaseFileHead = (LPBASEFILEHEAD) lpMapFileBuffer;
		lpBaseFileHead->m_nFileTotalSize = nFileSize;
		//写入初始文件数据，目前只考虑增大的情况
		fseek(pFileInfo->m_pFile, 0, SEEK_END);
		memset(lpBuffer, 0, nBufferSize);
		for(nPos = pFileInfo->m_liFileSize.QuadPart; nPos < nFileSize;nPos += dwBufSize)
		{
			*pFileInfo->m_pLoadSize = nPos/2;
			if(nFileSize > nBufferSize)
			{
				dwBufSize = fwrite(lpBuffer, sizeof(char), nBufferSize, pFileInfo->m_pFile);
				if(ferror(pFileInfo->m_pFile))
				{
					//写入失败
					Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120002 , _T("执行添加文件命令时，新建文件后写入数据失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
							GetLastError(), pFileInfo->m_lpszFilePath, nPos, nBufferSize);
					delete [] lpBuffer;
					return E_FAIL;
				}
			}
			else
			{
				dwBufSize = fwrite(lpBuffer, sizeof(char), (DWORD)(nFileSize - nPos), pFileInfo->m_pFile);
				if(ferror(pFileInfo->m_pFile))
				{
					//写入失败
					Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120003 , _T("执行添加文件命令时，新建文件后写入数据失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
							GetLastError(), pFileInfo->m_lpszFilePath, nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos));
					delete [] lpBuffer;
					return E_FAIL;
				}
			}
		}
		*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart/2;
		delete[] lpBuffer;
		lpBuffer = NULL;
		fflush(pFileInfo->m_pFile);
		liTotalFileSize.QuadPart = ftell(pFileInfo->m_pFile);
		if(nFileSize != liTotalFileSize.QuadPart)
		{
			//文件大小怎么不对呢？
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120004 , _T("文件大小出现异常，需要增长到的文件大小为：%lld，而实际获取到的文件大小为：%lld，文件路径：%s"),nFileSize, liTotalFileSize.QuadPart, pFileInfo->m_lpszFilePath);
			return E_FAIL;
		}
		fseek(pFileInfo->m_pFile, 0, SEEK_SET);
		//首先保存一下文件头信息，包括头结构体和BLOCKMAP信息
		dwBufSize = fwrite(lpBaseFileHead, sizeof(char), lpBaseFileHead->m_nFileHeaderSize, pFileInfo->m_pFile);
		if(ferror(pFileInfo->m_pFile))
		{
			//写入失败
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120005 , _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：0，写入大小：%d"),	GetLastError(), pFileInfo->m_lpszFilePath, lpBaseFileHead->m_nFileHeaderSize);
			return E_FAIL;
		}
		pFileInfo->m_liFileSize.QuadPart = liTotalFileSize.QuadPart;
		fseek(pFileInfo->m_pFile, 0, SEEK_SET);

		//关闭内存文件
		CShareMemory::ShMemDetach(pFileInfo->m_pFileAddr);
		CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
		pFileInfo->m_pFileAddr = NULL;
		pFileInfo->m_nShmId = 0;

		Sleep(200);

		//创建内存
		nShmKey = MF_MEMFILE_BASEKEY + pFileInfo->m_bFileNo;
		pFileInfo->m_nShmId = CShareMemory::CreateShareMemory(nShmKey, pFileInfo->m_liFileSize.QuadPart, NULL);
		if(pFileInfo->m_nShmId == -1 || GetLastError() == EEXIST)
		{
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120014 , _T("执行添加文件命令时，打开内存文件失败，错误码：%d，内存文件：%s，文件大小：%lld"),
					GetLastError(), pFileInfo->m_lpszMemFileName, pFileInfo->m_liFileSize.QuadPart);
			fclose(pFileInfo->m_pFile);
			pFileInfo->m_pFile = NULL;
			return E_FAIL;
		}

		lpMapFileBuffer = (char*)CShareMemory::ShMemAttach(pFileInfo->m_nShmId);
		if (lpMapFileBuffer == NULL)
		{
			Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120015 , _T("执行添加文件命令时，内存文件映射内存失败，错误码：%d，内存文件：%s"),	GetLastError(), pFileInfo->m_lpszMemFileName);
			CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
			pFileInfo->m_nShmId = 0;
			fclose(pFileInfo->m_pFile);
			pFileInfo->m_pFile = NULL;
			return E_FAIL;
		}

		dwBufSize = 0;
		fseek(pFileInfo->m_pFile, 0, SEEK_SET);
		//读取本地文件数据上传到内存中
		for(nPos = 0; nPos < pFileInfo->m_liFileSize.QuadPart;nPos += dwBufSize)
		{
			*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart/2 + nPos/2;
			if(pFileInfo->m_liFileSize.QuadPart - nPos >= (int)dwReadBufferSize)
			{
				dwBufSize = fread(lpMapFileBuffer+nPos, sizeof(char), dwReadBufferSize, pFileInfo->m_pFile);
				if(ferror(pFileInfo->m_pFile))
				{
					Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120021 , _T("执行添加文件命令时，从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%lld，读取大小：%d"),
							GetLastError(), pFileInfo->m_lpszFilePath, nPos, dwReadBufferSize);
					//读取文件失败
					CShareMemory::ShMemDetach(lpMapFileBuffer);
					CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
					pFileInfo->m_nShmId = 0;
					fclose(pFileInfo->m_pFile);
					pFileInfo->m_pFile = NULL;
					return E_FAIL;
				}
			}
			else
			{
				dwBufSize = fread(lpMapFileBuffer+nPos, sizeof(char), (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos), pFileInfo->m_pFile);
				if(ferror(pFileInfo->m_pFile))
				{
					Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120022 , _T("执行添加文件命令时，从物理文件读取数据失败，错误码：%d，路径：%s，读取位置：%lld，读取大小：%d"),
							GetLastError(), pFileInfo->m_lpszFilePath, nPos, (DWORD)(pFileInfo->m_liFileSize.QuadPart - nPos));
					//读取文件失败
					CShareMemory::ShMemDetach(lpMapFileBuffer);
					CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
					pFileInfo->m_nShmId = 0;
					fclose(pFileInfo->m_pFile);
					pFileInfo->m_pFile = NULL;
					return E_FAIL;
				}
			}

			//表示没读到数据，按道理不应该呀。
			if(dwBufSize == 0)
			{
				Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120023 , _T("执行添加文件命令时，从物理文件读取数据时返回读取长度为0，错误码：%d，路径：%s，读取位置：%lld"),	GetLastError(), pFileInfo->m_lpszFilePath, nPos);
				CShareMemory::ShMemDetach(lpMapFileBuffer);
				CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
				pFileInfo->m_nShmId = 0;
				fclose(pFileInfo->m_pFile);
				pFileInfo->m_pFile = NULL;
				return E_FAIL;
			}
		}

		*pFileInfo->m_pLoadSize = pFileInfo->m_liFileSize.QuadPart;
		pFileInfo->m_pFileAddr = lpMapFileBuffer;
		Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10120098 , _T("成功修改文件大小，文件路径：%s，文件大小：%lld"), pFileInfo->m_lpszFilePath, pFileInfo->m_liFileSize.QuadPart);
	}
	catch(...)
	{
		Trace(_T("ChangeFileSize"), MF_TRACE_LEVEL_FAILED, 10120099 , _T("添加新文件时出现异常，错误码：%d，路径：%s"),	GetLastError(), pFileInfo->m_lpszFilePath);
		if(lpMapFileBuffer)
		{
			CShareMemory::ShMemDetach(lpMapFileBuffer);
			lpMapFileBuffer = NULL;
		}
		if(pFileInfo->m_nShmId > 0)
		{
			CShareMemory::DestoryShareMemory(pFileInfo->m_nShmId);
			pFileInfo->m_nShmId = 0;
		}
		if(pFileInfo->m_pFile != NULL)
		{
			fclose(pFileInfo->m_pFile);
			pFileInfo->m_pFile = NULL;
		}
		return E_FAIL;
	}

	return S_OK;
#endif
}


//////////////////////////////////////////////////////////////////////////
//函数：SaveChange2File
//说明：
//	保存修改数据
//	出现数据块被其他进程占用等情况时，会跳过该数据块的保存，待下一次保存。
//参数：
//	bForce = False		判断数据是否更新，保存更新的数据。没有更新则不保存
//	bForce = True		保存所有数据
//	pFileInfo			需保存文件
//	nEndTimestamp		时间戳，用于判断数据是否需要保存
//返回值：
//	S_OK				保存完成
//	S_FALSE				部分数据未保存，不更新File上的时间戳
//	E_FAIL				出现严重错误，保存失败
//////////////////////////////////////////////////////////////////////////
HRESULT CSobeyMemStorageModule::SaveChange2File(LPFILEINFO pFileInfo, long long nEndTimestamp, BOOL bForce)
{
	HRESULT hr;
	BOOL bStart;
	char* lpMapFileBuffer;
	int nIndex, nFlag, i, nCount;
	LPBASEFILEHEAD lpBaseFileHead;
	DWORD dwBufSize, dwHeadBufferSize;
	LPBASEFILEOBJECTDEF lpBaseFileObject;
	LPBASEFILEBLOCKMAP lpBaseFileBlockMap;
	LARGE_INTEGER liMovePos, liNewFilePos;
	long long nMapBlockOffset, nMapSize, nNextOffset;
	LPBASEBLOCKHEAD lpBaseBlockHead, lpTmpBaseBlockHead;
	LPBASEFILEBLOCKMAPHEAD lpSlaveBaseFileBlockMapHead, lpMasterBaseFileBlockMapHead;

	hr = S_OK;
	try
	{
		dwHeadBufferSize = 0;
		dwBufSize = 0;
		lpMapFileBuffer = pFileInfo->m_pFileAddr;
		if(lpMapFileBuffer == NULL)
		{
			Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100000, _T("保存修改文件修改时发现内存指针为空，文件路径：%s"),	pFileInfo->m_lpszFilePath);
			return S_FALSE;
		}


		lpBaseFileHead = (LPBASEFILEHEAD)lpMapFileBuffer;

		//首先判断文件头的校验信息
		if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_SYSFILE)
		{
			if(lpBaseFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'S', 'F'))
			{
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100001, _T("保存修改系统文件修改时发现内存头标识不正确，已经拒绝写入磁盘，文件路径：%s，校验码：%d[%d]"),	pFileInfo->m_lpszFilePath, lpBaseFileHead->m_nDataFlag, MAKEHEADFLAG('S', 'B', 'S', 'F'));
				return E_FAIL;
			}
		}
		else if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_DATAFILE)
		{
			if(lpBaseFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'D', 'F'))
			{
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100002, _T("保存修改数据文件修改时发现内存头标识不正确，已经拒绝写入磁盘，文件路径：%s，校验码：%d[%d]"),	pFileInfo->m_lpszFilePath, lpBaseFileHead->m_nDataFlag, MAKEHEADFLAG('S', 'B', 'D', 'F'));
				return E_FAIL;
			}
		}
		else if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_TREEINDEXFILE)
		{
			if(lpBaseFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'B', 'F'))
			{
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100003, _T("保存修改B树索引文件修改时发现内存头标识不正确，已经拒绝写入磁盘，文件路径：%s，校验码：%d[%d]"),	pFileInfo->m_lpszFilePath, lpBaseFileHead->m_nDataFlag, MAKEHEADFLAG('S', 'B', 'B', 'F'));
				return E_FAIL;
			}
		}
		else if(pFileInfo->m_bFileType == MF_SYS_FILETYPE_KVINDEXFILE)
		{
			if(lpBaseFileHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'H', 'F'))
			{
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100004, _T("保存修改KV索引文件修改时发现内存头标识不正确，已经拒绝写入磁盘，文件路径：%s，校验码：%d[%d]"),	pFileInfo->m_lpszFilePath, lpBaseFileHead->m_nDataFlag, MAKEHEADFLAG('S', 'B', 'H', 'F'));
				return E_FAIL;
			}
		}

		//首先判断是否有更新
		if(pFileInfo->m_nTimestamp >= lpBaseFileHead->m_nTimestamp && !bForce)
		{
			return S_OK;
		}

		//校验一下结构体大小有没有改变，有没有数据库
		if(lpBaseFileHead->m_nBlockMapStructSize != sizeof(BASEFILEBLOCKMAP))
		{
			//出错了，目前先不管
			Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100005, _T("发现m_nBlockMapStructSize的值不正确，文件路径：%s，实际记录值：%d，正确值：%d"), pFileInfo->m_lpszFilePath, lpBaseFileHead->m_nBlockMapStructSize, sizeof(BASEFILEBLOCKMAP));
			return E_FAIL;
		}

		if (lpBaseFileHead->m_nBlockMapStartOffset == 0)
		{
			Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100005, _T("发现m_nBlockMapStartOffset的值不正确，文件路径：%s，实际记录值：%d，正确值：%d"), pFileInfo->m_lpszFilePath, lpBaseFileHead->m_nBlockMapStartOffset, lpBaseFileHead->m_nFileHeaderSize);
			return E_FAIL;
		}

		//首先备份一下文件头和映射表
		//先校验
		if(m_pStorageMemFileHead->m_nFileTotalSize != MF_STORAGEMEM_FILE_SIZE)
		{
			//文件头被破坏
			Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100010, _T("检查到通讯内存空间的大小异常，返回大小：%d，实际大小：%d"),
				m_pStorageMemFileHead->m_nFileTotalSize, MF_STORAGEMEM_FILE_SIZE);
			return E_FAIL;
		}
		if(m_pStorageMemFileHead->m_bCommandType != MF_STORAGEMEM_COMMAND_NO)
		{
			//操作标志位异常
			Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100011, _T("检查到操作标志位异常，返回值：%d，正确值：%d"),
				m_pStorageMemFileHead->m_bCommandType, MF_STORAGEMEM_COMMAND_NO);
			return E_FAIL;
		}

		if (m_pStorageMemFileHead->m_bServer == 1)
		{
			m_pStorageMemFileHead->m_nResult = 0;
			m_pStorageMemFileHead->m_bFileNo = lpBaseFileHead->m_bFileNo;
			m_pStorageMemFileHead->m_nMapSize = (lpBaseFileHead->m_nBlockStartOffset - lpBaseFileHead->m_nBlockMapStartOffset)/2;
			m_pStorageMemFileHead->m_bCommandType = MF_STORAGEMEM_COMMAND_COPYMAP;
			nCount = 0;
			while(true)
			{
				Sleep(m_pStorageMemFileHead->m_nCycleTime);
				if (m_pStorageMemFileHead->m_bCommandType == MF_STORAGEMEM_COMMAND_NO)
				{
					break;
				}
				nCount++;
				if (nCount > 10)
				{
					m_pStorageMemFileHead->m_nResult = MF_FLASHBACK_TIMEOUT;

					m_pStorageMemFileHead->m_bCommandType = MF_STORAGEMEM_COMMAND_NO;
					m_pStorageMemFileHead->m_bServer = 0;
					break;
				}
				Sleep(100);
			}
			if(m_pStorageMemFileHead->m_nResult == MF_OK)
			{
				nMapSize = (lpBaseFileHead->m_nBlockStartOffset - lpBaseFileHead->m_nBlockMapStartOffset)/2;

				//备份成功了，将文件头指针指向备份文件头地址
				//失败则使用原地址
				lpBaseFileHead = (LPBASEFILEHEAD)(m_pStorageMemFileAddr + m_pStorageMemFileHead->m_nBakFileHeadOffset);
			}
			else if (m_pStorageMemFileHead->m_nResult == MF_FLASHBACK_TIMEOUT)
			{
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100012, _T("备份映射表超时，Server可能已关闭，Server重启之前将直接采用主映射表数据进行持久化，可能保存到错误数据，错误码：%d，文件编号：%d"), 
					m_pStorageMemFileHead->m_nResult, m_pStorageMemFileHead->m_bFileNo);
				nMapSize = 0;
			}
			else
			{
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100013, _T("备份映射表失败，将直接采用主映射表数据进行持久化，可能保存到错误数据，错误码：%d，文件编号：%d"), 
					m_pStorageMemFileHead->m_nResult, m_pStorageMemFileHead->m_bFileNo);
				nMapSize = 0;
			}
		}
		else
		{
			nMapSize = 0;
		}

#pragma region 保存文件头信息
#ifdef WIN32
		//首先保存一下文件头信息，包括头结构体和BLOCKMAP信息
		liMovePos.QuadPart = 0;
		dwHeadBufferSize = lpBaseFileHead->m_nFileHeaderSize;
		if(!::SetFilePointerEx(pFileInfo->m_hFile, liMovePos, &liNewFilePos, FILE_BEGIN))
		{
			Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100006, _T("设置物理文件位置失败，错误码：%d，路径：%s，位置：%d"), GetLastError(), pFileInfo->m_lpszFilePath, 0);
			return E_FAIL;
		}

		//取出来确认一下位置是否正确
		if(0 != liNewFilePos.QuadPart)
		{
			//定位的位置不正确
			Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100007, _T("设置物理文件位置不正确，错误码：%d，路径：%s，设置位置：%d，返回位置：%lld"), GetLastError(), pFileInfo->m_lpszFilePath, 0, liNewFilePos.QuadPart);
			return E_FAIL;
		}
		//实际写入文件头数据
		if(!WriteFile(pFileInfo->m_hFile, lpBaseFileHead, dwHeadBufferSize, &dwBufSize, NULL))
		{
			//写入失败
			Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100008, _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：%d，写入大小：%d"),	GetLastError(), pFileInfo->m_lpszFilePath, 0, dwHeadBufferSize);
			return E_FAIL;
		}
#else
		//首先保存一下文件头信息，包括头结构体和BLOCKMAP信息
		liMovePos.QuadPart = 0;
		dwHeadBufferSize = lpBaseFileHead->m_nFileHeaderSize;
		if(MF_OK != fseek(pFileInfo->m_pFile, 0, SEEK_SET))
		{
			Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100006, _T("设置物理文件位置失败，错误码：%d，路径：%s，位置：%d"), GetLastError(), pFileInfo->m_lpszFilePath, 0);
			return E_FAIL;
		}

		//取出来确认一下位置是否正确
		if(0 != ftell(pFileInfo->m_pFile))
		{
			//定位的位置不正确
			Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100007 , _T("设置物理文件位置不正确，错误码：%d，路径：%s，设置位置：%d，返回位置：%lld"), GetLastError(), pFileInfo->m_lpszFilePath, 0, ftell(pFileInfo->m_pFile));
			return E_FAIL;
		}

		//实际写入文件头数据
		dwBufSize = fwrite(lpBaseFileHead, sizeof(char), dwHeadBufferSize, pFileInfo->m_pFile);
		if(ferror(pFileInfo->m_pFile))
		{
			//写入失败
			Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100008, _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：%d，写入大小：%d"),	GetLastError(), pFileInfo->m_lpszFilePath, 0, dwHeadBufferSize);
			return E_FAIL;
		}
#endif

		//所有对象里都没有数据时，块数也为零
		//新增对象时需要保存文件头
		if(lpBaseFileHead->m_nBlockNum == 0)
		{
			return S_OK;
		}
#pragma endregion


#pragma region 保存映射表信息
		
		//映射表大小。同一个文件内所有映射表大小应该一样
		lpMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(lpMapFileBuffer + lpBaseFileHead->m_nBlockMapStartOffset);
		//nMapSize = (lpBaseFileHead->m_nBlockStartOffset - lpBaseFileHead->m_nBlockMapStartOffset)/2;

		//进入备份映射表区
		lpSlaveBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(lpMapFileBuffer + lpBaseFileHead->m_nBlockMapStartOffset + nMapSize);
		//写入位置为主映射表位置
		nMapBlockOffset = lpBaseFileHead->m_nBlockMapStartOffset;

		while (true)
		{
			//写入映射表数据
			//映射表实际使用大小
			dwHeadBufferSize = sizeof(BASEFILEBLOCKMAPHEAD) + lpBaseFileHead->m_nBlockMapStructSize*(lpSlaveBaseFileBlockMapHead->m_nBlockMapNum - 1);

#ifdef WIN32
			//写文件，写入位置为主映射表位置
			liNewFilePos.QuadPart		 = 0;
			liMovePos.QuadPart			 = nMapBlockOffset;
			if(!::SetFilePointerEx(pFileInfo->m_hFile, liMovePos, &liNewFilePos, FILE_BEGIN))
			{
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100014, _T("设置物理文件位置失败，错误码：%d，路径：%s，位置：%lld"),
					GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart);
				return E_FAIL;
			}
			//取出来确认一下位置是否正确
			if(liMovePos.QuadPart != liNewFilePos.QuadPart)
			{
				//定位的位置不正确
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100015, _T("设置物理文件位置不正确，错误码：%d，路径：%s，设置位置：%lld，返回位置：%lld"),
					GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart, liNewFilePos.QuadPart);
				return E_FAIL;
			}

			if(!WriteFile(pFileInfo->m_hFile, lpSlaveBaseFileBlockMapHead, dwHeadBufferSize, &dwBufSize, NULL))
			{
				//写入失败
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100016, _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
					GetLastError(), pFileInfo->m_lpszFilePath, lpMasterBaseFileBlockMapHead, dwHeadBufferSize);
				return E_FAIL;
			}
#else
			//写文件，写入位置为主映射表位置
			liMovePos.QuadPart = nMapBlockOffset;
			if(MF_OK != fseek(pFileInfo->m_pFile, liMovePos.QuadPart, SEEK_SET))
			{
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100014, _T("设置物理文件位置失败，错误码：%d，路径：%s，位置：%lld"),
					GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart);
				return E_FAIL;
			}
			//取出来确认一下位置是否正确
			if(liMovePos.QuadPart != ftell(pFileInfo->m_pFile))
			{
				//定位的位置不正确
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100015, _T("设置物理文件位置不正确，错误码：%d，路径：%s，设置位置：%lld，返回位置：%lld"),
						GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart, ftell(pFileInfo->m_pFile));
				return E_FAIL;
			}

			dwBufSize = fwrite(lpSlaveBaseFileBlockMapHead, sizeof(char), dwHeadBufferSize, pFileInfo->m_pFile);
			if(ferror(pFileInfo->m_pFile))
			{
				//写入失败
				Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100016, _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
					GetLastError(), pFileInfo->m_lpszFilePath, lpMasterBaseFileBlockMapHead, dwHeadBufferSize);
				return E_FAIL;
			}
#endif

			if(lpSlaveBaseFileBlockMapHead->m_nNextBlockMapOffset == 0)
			{
				break;
			}
			else
			{
				//指向下一个映射表区
				nMapBlockOffset = lpSlaveBaseFileBlockMapHead->m_nNextBlockMapOffset;
				//写入位置指向主映射表
				lpMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(lpMapFileBuffer + nMapBlockOffset);
				//读入位置指向备映射表
				lpSlaveBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(lpMapFileBuffer + nMapBlockOffset + nMapSize);
			}
		}
#pragma endregion



#pragma region 保存块信息
		if (lpBaseFileHead->m_nDataFlag == MAKEHEADFLAG('S', 'B', 'S', 'F') || lpBaseFileHead->m_nDataFlag == MAKEHEADFLAG('S', 'B', 'D', 'F'))
		{
#pragma region 保存系统文件，数据文件块数据
			lpBaseFileObject = lpBaseFileHead->m_stuObjectDef;
			for(i = 0; i < 2; i++)
			{
				//判断object是否更新
				for(nIndex = 0; nIndex < MAX_OBJECT_NUM; nIndex++)
				{
					if(lpBaseFileObject[nIndex].m_nID != 0)
					{
						//存在未保存的数据
						if(lpBaseFileObject[nIndex].m_nFinishedTimestamp > lpBaseFileObject[nIndex].m_nPersistentTimestamp || bForce)
						{
							nFlag = 2;
							bStart = true;
							//遍历满块链表或者空块链表找到一个块的映射结点
							while(nFlag > 0)
							{
								if(!bStart)
								{
									if(lpBaseFileBlockMap->m_nNextOffset == 0)
									{
										bStart = true;
										nFlag--;
										continue;
									}
									else
									{
										nNextOffset = lpBaseFileBlockMap->m_nNextOffset;
										lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(lpMapFileBuffer + nNextOffset + nMapSize);
										if(nNextOffset == lpBaseFileBlockMap->m_nNextOffset)
										{
											Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100019, _T("块链表出现自己引用自己的情况(nBlockNo:%d)！"), lpBaseFileBlockMap->m_nBlockNo);
											bStart = true;
											nFlag--;
											continue;
										}
									}
								}
								else
								{
									bStart = false;
									if(nFlag == 2)
									{
										if(lpBaseFileObject[nIndex].m_nFullBlockMapOffset == 0)
										{
											bStart = true;
											nFlag--;
											continue;
										}
										lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(lpMapFileBuffer + lpBaseFileObject[nIndex].m_nFullBlockMapOffset + nMapSize);
									}
									else if(nFlag == 1)
									{
										if(lpBaseFileObject[nIndex].m_nFreeBlockMapOffset == 0)
										{
											bStart = true;
											nFlag--;
											continue;
										}
										lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(lpMapFileBuffer + lpBaseFileObject[nIndex].m_nFreeBlockMapOffset + nMapSize);
									}
									else	//应该不会运行到这里
									{
										Trace0(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100020, _T("保存Object段代码异常"));
										return E_FAIL;
									}
								}

								//首先做一下简单的有效性判断
								if(lpBaseFileBlockMap->m_nBlockOffset >= pFileInfo->m_liFileSize.QuadPart)
								{
									Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100021, _T("检查到块的偏移超出文件尺寸，路径：%s，块号：%d，块偏移位置%lld"), 
										pFileInfo->m_lpszFilePath, lpBaseFileBlockMap->m_nBlockNo, lpBaseFileBlockMap->m_nBlockOffset);
									return E_FAIL;
								}

								lpBaseBlockHead = (LPBASEBLOCKHEAD)(lpMapFileBuffer + lpBaseFileBlockMap->m_nBlockOffset);

								//首先做一下简单的有效性判断
								if(lpBaseFileBlockMap->m_nBlockOffset + lpBaseBlockHead->m_nBlockSize >= pFileInfo->m_liFileSize.QuadPart)
								{
									Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100022, _T("检查到块的偏移超出文件尺寸，路径：%s，块号：%d，块偏移位置%lld，块大小%lld"), 
										pFileInfo->m_lpszFilePath, lpBaseFileBlockMap->m_nBlockNo, lpBaseFileBlockMap->m_nBlockOffset, lpBaseBlockHead->m_nBlockSize);
									return E_FAIL;
								}

								//判断块数据是否已经损坏
								if(lpBaseBlockHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'D', 'B'))
								{
									//为了解决并行的问题，先等一下再看看这项数据是不是已经恢复了
									Sleep(10);
									if(lpBaseBlockHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'D', 'B'))
									{
										Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100023, _T("检查到块的头信息损坏，校验数据：%d [%d]，路径：%s，块号：%d(%d)，块偏移位置%lld"),
											lpBaseBlockHead->m_nDataFlag, MAKEHEADFLAG('S', 'B', 'D', 'B'), pFileInfo->m_lpszFilePath, lpBaseBlockHead->m_nBlockNo, lpBaseFileBlockMap->m_nBlockNo, lpBaseFileBlockMap->m_nBlockOffset);
										return E_FAIL;
									}
								}

								//已经保存过的点
								if(m_pMemoryFileHead->m_nBeginTimestamp >= lpBaseBlockHead->m_nTimestamp && lpBaseBlockHead->m_bSaveFlag == 1 && !bForce)
								{
									continue;
								}
								else
								{
									//将block中数据复制到缓存中
									//判断块大小是否超过开辟的内存空间大小
									if(lpBaseBlockHead->m_nBlockSize > m_nSaveBlockBufferSize)
									{
										//应该不会出这种错误
										Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100024, _T("检查到块的大小超出开辟的缓存空间大小，块大小：%I，缓存空间大小：%I，块号：%d，块偏移位置%lld"),
											lpBaseBlockHead->m_nBlockSize, m_nSaveBlockBufferSize, lpBaseBlockHead->m_nBlockNo, lpBaseFileBlockMap->m_nBlockOffset);
										return E_FAIL;
									}

									lpTmpBaseBlockHead = lpBaseBlockHead;
									memcpy(m_pSaveBlockBuffer, lpBaseBlockHead, lpBaseBlockHead->m_nBlockSize);
									lpBaseBlockHead = (LPBASEBLOCKHEAD)m_pSaveBlockBuffer;

									//判断缓存中数据是否有效
									//系统文件内的数据先直接存
									//数据文件内的数据可调用闪回
									if(lpBaseFileHead->m_nDataFlag == MAKEHEADFLAG('S', 'B', 'D', 'F') && lpBaseBlockHead->m_nTimestamp > nEndTimestamp)
									{
										//当前文件为数据文件
										//服务正在运行
										//////当前块长时间未保存 时，调用闪回
										//每次需要保存都强制调用闪回，闪回失败则直接保存内存里的数据
										if (m_pStorageMemFileHead->m_bServer == 1/* && lpBaseBlockHead->m_nTimestamp - m_pMemoryFileHead->m_nBeginTimestamp > 24000000000*/)		//10min?
										{
											//先校验一下
											if(m_pStorageMemFileHead->m_nFileTotalSize != MF_STORAGEMEM_FILE_SIZE)
											{
												//文件头被破坏
												Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100025, _T("检查到通讯内存空间的大小异常，返回大小：%d，实际大小：%d"),
													m_pStorageMemFileHead->m_nFileTotalSize, MF_STORAGEMEM_FILE_SIZE);
												return E_FAIL;
											}
											if(m_pStorageMemFileHead->m_bCommandType != MF_STORAGEMEM_COMMAND_NO)
											{
												//闪回标志位异常
												Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100026, _T("检查到操作标志位异常，返回值：%d，正确值：%d"),
													m_pStorageMemFileHead->m_bCommandType, MF_STORAGEMEM_COMMAND_NO);
												return E_FAIL;
											}
											m_pStorageMemFileHead->m_nResult		= 0;
											m_pStorageMemFileHead->m_bFileNo		= lpBaseFileHead->m_bFileNo;
											m_pStorageMemFileHead->m_nObjectNo		= lpBaseFileObject[nIndex].m_nID;
											m_pStorageMemFileHead->m_nBlockNo		= lpBaseBlockHead->m_nBlockNo;
											m_pStorageMemFileHead->m_nTimestamp		= nEndTimestamp;
											m_pStorageMemFileHead->m_bCommandType	= MF_STORAGEMEM_COMMAND_FLASHBACK;
											nCount = 0;
											while(true)
											{
												Sleep(m_pStorageMemFileHead->m_nCycleTime);
												if (m_pStorageMemFileHead->m_bCommandType == MF_STORAGEMEM_COMMAND_NO)
												{
													break;
												}
												nCount++;
												if (nCount > 10)
												{
													m_pStorageMemFileHead->m_nResult = MF_FLASHBACK_TIMEOUT;

													m_pStorageMemFileHead->m_bCommandType = MF_STORAGEMEM_COMMAND_NO;
													m_pStorageMemFileHead->m_bServer = 0;
													break;
												}
												Sleep(100);
											}
											if(m_pStorageMemFileHead->m_nResult == MF_OK)
											{
												lpBaseBlockHead = (LPBASEBLOCKHEAD)(m_pStorageMemFileAddr + m_pStorageMemFileHead->m_nBakBlockOffset);
											}
											else if (m_pStorageMemFileHead->m_nResult == MF_FLASHBACK_TIMEOUT)
											{
												//运行闪回等待超时，可能是应该连接已断开
												Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100027,
													_T("闪回调用超时，Server可能已关闭，Server重启之前将直接采用主内存空间数据进行持久化，可能保存到错误数据，错误码：%d，文件编号：%d，对象编号：%d，块编号：%d"), 
													m_pStorageMemFileHead->m_nResult, m_pStorageMemFileHead->m_bFileNo, m_pStorageMemFileHead->m_nObjectNo, m_pStorageMemFileHead->m_nBlockNo);
											}
											else
											{
												//闪回运行不成功
												//将数据直接写入文件保存
												Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100028, _T("闪回运行不成功，将直接采用主内存空间数据进行持久化，可能保存到错误数据，错误码：%d，文件编号：%d，对象编号：%d，块编号：%d"), 
													m_pStorageMemFileHead->m_nResult, m_pStorageMemFileHead->m_bFileNo, m_pStorageMemFileHead->m_nObjectNo, m_pStorageMemFileHead->m_nBlockNo);
												//	hr = S_FALSE;
												//	continue;
											}
										}
										else
										{
											//跳过，等待下一次保存
											//hr = S_FALSE;
											//continue;

											//不能跳过，退出时Server先于Storage关闭
											//直接将内存中的数据保存下来
										}
									}

#ifdef WIN32
									//写文件
									liNewFilePos.QuadPart		 = 0;
									liMovePos.QuadPart			 = lpBaseFileBlockMap->m_nBlockOffset;
									lpBaseBlockHead->m_bSaveFlag = 1;
									if(!::SetFilePointerEx(pFileInfo->m_hFile, liMovePos, &liNewFilePos, FILE_BEGIN))
									{
										Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100029, _T("设置物理文件位置失败，错误码：%d，路径：%s，位置：%lld"),
											GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart);
										return E_FAIL;
									}
									//取出来确认一下位置是否正确
									if(liMovePos.QuadPart != liNewFilePos.QuadPart)
									{
										//定位的位置不正确
										Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100030, _T("设置物理文件位置不正确，错误码：%d，路径：%s，设置位置：%lld，返回位置：%lld"),
											GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart, liNewFilePos.QuadPart);
										return E_FAIL;
									}

									//实际写入块数据
									if(!WriteFile(pFileInfo->m_hFile, lpBaseBlockHead, lpBaseBlockHead->m_nBlockSize, &dwBufSize, NULL))
									{
										//写入失败
										Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100031, _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
											GetLastError(), pFileInfo->m_lpszFilePath, lpBaseFileBlockMap->m_nBlockOffset, lpBaseBlockHead->m_nBlockSize);
										return E_FAIL;
									}
#else
									//写文件
									liMovePos.QuadPart			  = lpBaseFileBlockMap->m_nBlockOffset;
									lpBaseBlockHead->m_bSaveFlag = 1;
									if(MF_OK != fseek(pFileInfo->m_pFile, liMovePos.QuadPart, SEEK_SET))
									{
										Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100029, _T("设置物理文件位置失败，错误码：%d，路径：%s，位置：%lld"),
											GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart);
										return E_FAIL;
									}
									//取出来确认一下位置是否正确
									if(liMovePos.QuadPart != ftell(pFileInfo->m_pFile))
									{
										//定位的位置不正确
										Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100030, _T("设置物理文件位置不正确，错误码：%d，路径：%s，设置位置：%lld，返回位置：%lld"),
												GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart, ftell(pFileInfo->m_pFile));
										return E_FAIL;
									}

									//实际写入块数据
									dwBufSize = fwrite(lpBaseBlockHead, sizeof(char), lpBaseBlockHead->m_nBlockSize, pFileInfo->m_pFile);
									if(ferror(pFileInfo->m_pFile))
									{
										//写入失败
										Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100031, _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
											GetLastError(), pFileInfo->m_lpszFilePath, lpBaseFileBlockMap->m_nBlockOffset, lpBaseBlockHead->m_nBlockSize);
										return E_FAIL;
									}
#endif
								}

							}
							//end while
							lpBaseFileObject[nIndex].m_nPersistentTimestamp = nEndTimestamp;
						}
						//end if (lpBaseFileObject[nIndex].m_nFinishedTimestamp > lpBaseFileObject[nIndex].m_nPersistentTimestamp)
					}
					//end if (lpBaseFileObject[nIndex].m_nID != 0)
				}
				//持久化关系表
				if(lpBaseFileHead->m_nDataFlag == MAKEHEADFLAG('S', 'B', 'D', 'F'))
				{
					LPBASEDATAFILEHEAD lpBaseDataFileHead;
					
					lpBaseDataFileHead = (LPBASEDATAFILEHEAD)lpBaseFileHead;
					lpBaseFileObject   = lpBaseDataFileHead->m_stFileRelationData;
				}
				else
				{
					break;
				}
			}
#pragma endregion
		} 
		else if (lpBaseFileHead->m_nDataFlag == MAKEHEADFLAG('S', 'B', 'B', 'F') || lpBaseFileHead->m_nDataFlag == MAKEHEADFLAG('S', 'B', 'H', 'F'))
		{
#pragma region 保存树索引文件，KV索引文件块数据
			//通过映射表遍历所有块
			//从备映射表中读取数据
			lpSlaveBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(lpMapFileBuffer + lpBaseFileHead->m_nBlockMapStartOffset + nMapSize);
			while (true)
			{
				//查找第一个MAP位置，指向备映射表
				lpBaseFileBlockMap = lpSlaveBaseFileBlockMapHead->m_pBlockMap;
				for(nIndex = 0; nIndex < lpSlaveBaseFileBlockMapHead->m_nBlockMapNum; nIndex++)
				{
					//首先做一下简单的有效性判断
					if(lpBaseFileBlockMap[nIndex].m_nBlockOffset >= pFileInfo->m_liFileSize.QuadPart)
					{
						Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100040, _T("检查到块的偏移超出文件尺寸，路径：%s，块号：%d，块偏移位置%lld"),
							pFileInfo->m_lpszFilePath, nIndex+1, lpBaseFileBlockMap[nIndex].m_nBlockOffset);
						return E_FAIL;
					}

					lpBaseBlockHead = (LPBASEBLOCKHEAD)(lpMapFileBuffer + lpBaseFileBlockMap[nIndex].m_nBlockOffset);
					//首先做一下简单的有效性判断
					if(lpBaseFileBlockMap[nIndex].m_nBlockOffset + lpBaseBlockHead->m_nBlockSize >= pFileInfo->m_liFileSize.QuadPart)
					{
						Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100041, _T("检查到块的偏移超出文件尺寸，路径：%s，块号：%d，块偏移位置%lld，块大小%lld"),
							pFileInfo->m_lpszFilePath, nIndex+1, lpBaseFileBlockMap[nIndex].m_nBlockOffset, lpBaseBlockHead->m_nBlockSize);
						return E_FAIL;
					}

					//判断块数据是否已经损坏
					if(lpBaseBlockHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'D', 'B'))
					{
						//为了解决并行的问题，先等一下再看看这项数据是不是已经恢复了
						Sleep(10);
						if(lpBaseBlockHead->m_nDataFlag != MAKEHEADFLAG('S', 'B', 'D', 'B'))
						{
							Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100042, _T("检查到块的头信息损坏，校验数据：%d [%d]，路径：%s，块号：%d(%d)，块偏移位置%lld"),
								lpBaseBlockHead->m_nDataFlag, MAKEHEADFLAG('S', 'B', 'D', 'B'), pFileInfo->m_lpszFilePath, nIndex+1,lpBaseFileBlockMap[nIndex].m_nBlockNo, lpBaseFileBlockMap[nIndex].m_nBlockOffset);
							return E_FAIL;
						}
					}

					//已经保存过的点
					if(m_pMemoryFileHead->m_nBeginTimestamp >= lpBaseBlockHead->m_nTimestamp && lpBaseBlockHead->m_bSaveFlag == 1 && !bForce)
					{
						continue;
					}
					//属于下次保存的范围
					else if(lpBaseBlockHead->m_nTimestamp > nEndTimestamp && !bForce)
					{
						//频繁更新可能出现该块一直未保存的情况
						//索引文件暂不考虑这种情况
						continue;
					}
					else
					{
#ifdef WIN32
						//写文件
						liNewFilePos.QuadPart		 = 0;
						liMovePos.QuadPart			 = lpBaseFileBlockMap[nIndex].m_nBlockOffset;
						lpBaseBlockHead->m_bSaveFlag = 1;
						if(!::SetFilePointerEx(pFileInfo->m_hFile, liMovePos, &liNewFilePos, FILE_BEGIN))
						{
							Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100043, _T("设置物理文件位置失败，错误码：%d，路径：%s，位置：%lld"),
								GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart);
							return E_FAIL;
						}
						//取出来确认一下位置是否正确
						if(liMovePos.QuadPart != liNewFilePos.QuadPart)
						{
							//定位的位置不正确
							Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100044, _T("设置物理文件位置不正确，错误码：%d，路径：%s，设置位置：%lld，返回位置：%lld"),
								GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart, liNewFilePos.QuadPart);
							return E_FAIL;
						}

						//实际写入块数据
						if(!WriteFile(pFileInfo->m_hFile, lpBaseBlockHead, lpBaseBlockHead->m_nBlockSize, &dwBufSize, NULL))
						{
							//写入失败
							Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100045, _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
								GetLastError(), pFileInfo->m_lpszFilePath, lpBaseFileBlockMap[nIndex].m_nBlockOffset, lpBaseBlockHead->m_nBlockSize);
							return E_FAIL;
						}
#else
						//写文件
						liMovePos.QuadPart			  = lpBaseFileBlockMap[nIndex].m_nBlockOffset;
						lpBaseBlockHead->m_bSaveFlag = 1;
						if(MF_OK != fseek(pFileInfo->m_pFile, liMovePos.QuadPart, SEEK_SET))
						{
							Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100043, _T("设置物理文件位置失败，错误码：%d，路径：%s，位置：%lld"),
								GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart);
							return E_FAIL;
						}
						//取出来确认一下位置是否正确
						if(liMovePos.QuadPart != ftell(pFileInfo->m_pFile))
						{
							//定位的位置不正确
							Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100044, _T("设置物理文件位置不正确，错误码：%d，路径：%s，设置位置：%lld，返回位置：%lld"),
								GetLastError(), pFileInfo->m_lpszFilePath, liMovePos.QuadPart, ftell(pFileInfo->m_pFile));
							return E_FAIL;
						}

						//实际写入块数据
						dwBufSize = fwrite(lpBaseBlockHead, sizeof(char), lpBaseBlockHead->m_nBlockSize, pFileInfo->m_pFile);
						if(ferror(pFileInfo->m_pFile))
						{
							//写入失败
							Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100045, _T("从内存写入到物理文件失败，错误码：%d，路径：%s，写入位置：%lld，写入大小：%d"),
								GetLastError(), pFileInfo->m_lpszFilePath, lpBaseFileBlockMap[nIndex].m_nBlockOffset, lpBaseBlockHead->m_nBlockSize);
							return E_FAIL;
						}
#endif
					}
				}
				if(lpSlaveBaseFileBlockMapHead->m_nNextBlockMapOffset == 0)
				{
					break;
				}
				else
				{
					lpSlaveBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(lpMapFileBuffer + lpSlaveBaseFileBlockMapHead->m_nNextBlockMapOffset + nMapSize);

				}
			}
#pragma endregion
		}
		else
		{
			//应该不会出现这种情况
			//Trace()
			return E_FAIL;
		}


		
#pragma endregion

#ifdef WIN32
		FlushFileBuffers(pFileInfo->m_hFile);
#else
		fflush(pFileInfo->m_pFile);
#endif
		pFileInfo->m_nTimestamp = nEndTimestamp;
	}
	catch(...)
	{
		Trace(_T("SaveChange2File"), MF_TRACE_LEVEL_FAILED, 10100099 , _T("从内存写入到物理文件出现异常失败，错误码：%d，文件路径：%s"),	GetLastError(), pFileInfo->m_lpszFilePath);
		return E_FAIL;
	}

	return hr;
}
