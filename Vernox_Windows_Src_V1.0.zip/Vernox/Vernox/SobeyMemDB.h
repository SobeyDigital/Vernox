﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#define MF_CONSOLE_ID_MAX_LENGTH_WCHAR		23
#define MF_CONSOLE_ID_MAX_LENGTH_CHAR		MF_CONSOLE_ID_MAX_LENGTH_WCHAR*6
#define MF_CONSOLE_PW_MAX_LENGTH_WCHAR		23
#define MF_CONSOLE_PW_MAX_LENGTH_CHAR		MF_CONSOLE_PW_MAX_LENGTH_WCHAR*6
#define MF_CONSOLE_READBUFFER_SIZE_WCHAR	8192											//缓存大小
#define MF_CONSOLE_READBUFFER_SIZE_CHAR		MF_CONSOLE_READBUFFER_SIZE_WCHAR*6				//用于将wchar(Unicode)转为char(UTF8)。UTF8单个字符最长为6个字节，这个缓存直接设置大点保证不会溢出

//自定义结构体
typedef struct
{
	TCHAR m_wcUserID[MF_CONSOLE_ID_MAX_LENGTH_WCHAR+1];
	TCHAR m_wcPassword[MF_CONSOLE_ID_MAX_LENGTH_WCHAR+1];
	char m_cUserID[MF_CONSOLE_ID_MAX_LENGTH_CHAR+1];
	char m_cPassword[MF_CONSOLE_PW_MAX_LENGTH_CHAR+1];
}MF_CONSOLE_LOGIN_USERINFO, LPMF_CONSOLE_LOGIN_USERINFO;

typedef struct
{
	BOOL m_bUserID;
	BOOL m_bPassWord;
}MF_CONSOLE_LOGIN_OPTION, LPMF_CONSOLE_LOGIN_OPTION;

//自定义函数

//解析

//解析输入参数
int ParseLoginCommad(int argc, TCHAR* argv[]);

//判断输入字符串是否符合格式
BOOL IsLoginOption(TCHAR* lpStr);

//判断是否为退出命令
BOOL IsQuit(TCHAR* lpCommand);

//判断是否为帮助命令
BOOL IsHelp(TCHAR* lpCommand);

//显示结果
void DisplayResult(LONG lAffectCount, CMemDBRecordset& stRs, EXECUTEPLANDESCRIBE stExecutePlanInfo, MF_EXECUTE_STATISTICS stStatisticsInfo);

//输出指定长度的连续符号
void ShowNCharacters(int nCount, BYTE bChar);

//字符编码转换
char* UnicodeToANSI(const wchar_t * lpwData);

wchar_t* ANSIToUnicode(const char * lpData);