﻿// stdafx.h : 标准系统包含文件的包含文件，
// 或是经常使用但不常更改的
// 特定于项目的包含文件
//

#pragma once
//屏蔽C语言警告信息
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_NON_CONFORMING_SWPRINTFS

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <iostream>
#include <string.h>
#include <conio.h>
#include <wchar.h>
#include "..\VernoxClientLib\DBInterface.h"
using namespace std;



// TODO: 在此处引用程序需要的其他头文件
#ifdef _M_X64
	#ifdef DEBUG                          
		#pragma comment(lib, "..\\LibX64\\VernoxClientLibD.lib")
	#else
		#pragma comment(lib, "..\\LibX64\\VernoxClientLib.lib")
	#endif
#else
	#ifdef DEBUG
		#pragma comment(lib, "..\\Lib\\VernoxClientLibD.lib")
	#else
		#pragma comment(lib, "..\\Lib\\VernoxClientLib.lib")					   
	#endif						       
#endif