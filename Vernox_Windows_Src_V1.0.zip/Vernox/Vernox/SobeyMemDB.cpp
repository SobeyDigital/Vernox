﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "stdafx.h"
#include "SobeyMemDB.h"

MF_CONSOLE_LOGIN_USERINFO g_stuUserInfo;
MF_CONSOLE_LOGIN_OPTION g_stuOption;

TCHAR g_wcReadBuffer[MF_CONSOLE_READBUFFER_SIZE_WCHAR];
char g_cReadBuffer[MF_CONSOLE_READBUFFER_SIZE_CHAR];


int _tmain(int argc, _TCHAR* argv[])
{
	int nRet, nLength, nAffectCount;
	CMemDBRecordset stRs;
	ULONG ulIP;
	USHORT usPort;
	EXECUTEPLANDESCRIBE stExecutePlanDesc;
	MF_EXECUTE_STATISTICS stStatisticsInfo;
	CDBInterface* pSobeyInterface = NULL;
	
	pSobeyInterface = new CDBInterface;
	memset(g_wcReadBuffer, 0, sizeof(g_wcReadBuffer));
	memset(g_cReadBuffer, 0, sizeof(g_cReadBuffer));


	setlocale(LC_ALL, "");

	//解析登陆参数
	memset(&g_stuUserInfo, 0, sizeof(MF_CONSOLE_LOGIN_USERINFO));
	memset(&g_stuOption, 0, sizeof(MF_CONSOLE_LOGIN_OPTION));
	nRet = ParseLoginCommad(argc-1, &argv[1]);
	if (nRet != 0)
	{
		_tprintf(_T("Error\n"));
		goto SobeyMemDB_main_Release;
	}

	//验证用户名密码
	ulIP = ntohl(inet_addr("127.0.0.1"));
	usPort = 8000;
	if (g_stuOption.m_bUserID == FALSE || g_stuOption.m_bPassWord == FALSE)
	{
		_tprintf(_T("Error\n"));
		goto SobeyMemDB_main_Release;
	}
	nRet = pSobeyInterface->OpenWithAddress(g_stuUserInfo.m_cUserID, g_stuUserInfo.m_cPassword, ulIP, usPort);
	if (nRet != MF_OK)
	{
		_tprintf(_T("登陆失败，错误码：%d\n"), nRet);
		goto SobeyMemDB_main_Release;
	}


	while (TRUE)
	{
		_tprintf(_T("Vernox> "));
		wcin.getline(g_wcReadBuffer, MF_CONSOLE_READBUFFER_SIZE_WCHAR, _T('\n'));		//默认以回车结束
		//解析命令语句
		nLength = _tcslen(g_wcReadBuffer);
		if (nLength == 0)
		{
			continue;
		} 
		else if (nLength < 0 || nLength >= MF_CONSOLE_READBUFFER_SIZE_WCHAR)
		{
			_tprintf(_T("读入字符串长度异常，字符串长度：%d，允许最大长度：%d\n"), nLength, MF_CONSOLE_READBUFFER_SIZE_WCHAR-1);
			goto SobeyMemDB_main_Release;
		} 

		if (IsQuit(g_wcReadBuffer))
		{
			//退出
			break;
		} 
		else if (IsHelp(g_wcReadBuffer))
		{
			//显示帮助信息
			_tprintf(_T("help!\n"));
		}
		else if (g_wcReadBuffer[0] == _T('@'))
		{
			TCHAR* lpFilePath = NULL;
			FILE* hFile = NULL;
			char* pBuffer = NULL;
			LONGLONG llBufferSize, llReadSize;
			int nSqlCount, i;
			vector<char*> vecSql;
			llBufferSize = 0;
			llReadSize = 0;
			nSqlCount = 0;
			i = 0;

			if (nLength <= 1)
			{
				_tprintf(_T("无法解析输入的指令：%s\n"), g_wcReadBuffer);
				goto SobeyMemDB_main_Read_File;
			}
		
			lpFilePath = &(g_wcReadBuffer[1]);
			if (_taccess(lpFilePath, 0) != 0)
			{
				_tprintf(_T("指定文件不存在，文件路径：%s\n"), lpFilePath);
				goto SobeyMemDB_main_Read_File;
			}

			//转换到UTF8编码
			WideCharToMultiByte(CP_UTF8, 0, lpFilePath, nLength, g_cReadBuffer, MF_CONSOLE_READBUFFER_SIZE_CHAR, NULL, NULL);
			hFile = fopen(g_cReadBuffer, "rb");
			if (hFile == NULL)
			{
				_tprintf(_T("无法打开指定文件，错误码：%d，文件路径：%s\n"), GetLastError(), lpFilePath);
				goto SobeyMemDB_main_Read_File;
			}

			fseek(hFile, 0, SEEK_END);
			llBufferSize = ftell(hFile);
			fseek(hFile, 0, SEEK_SET);
			if (llBufferSize <= 0)
			{
				_tprintf(_T("文件大小为零，文件大小：%lld\n"), llBufferSize);
				goto SobeyMemDB_main_Read_File;
			}
			
			pBuffer = new char[llBufferSize];
			if (pBuffer == NULL)
			{
				_tprintf(_T("申请内存失败，错误码：%d，申请大小：%lld\n"), GetLastError(), llBufferSize);
				goto SobeyMemDB_main_Read_File;
			}

			llReadSize = fread(pBuffer, 1, llBufferSize, hFile);
			if (llReadSize == 0)
			{
				_tprintf(_T("读取文件数据失败，错误码：%d，读取到的数据大小：%lld，文件大小：%lld\n"), GetLastError(), llReadSize, llBufferSize);
				goto SobeyMemDB_main_Read_File;
			}
			if (llReadSize != llBufferSize)
			{
				_tprintf(_T("读取文件数据异常，错误码：%d，读取到的数据大小：%lld，文件大小：%lld\n"), GetLastError(), llReadSize, llBufferSize);
				goto SobeyMemDB_main_Read_File;
			}

			//分析文件数据内容
			//拆分SQL语句并依次执行
			vecSql.clear();
			nRet = pSobeyInterface->SplitSql(pBuffer, llReadSize, vecSql);
			if (nRet != MF_OK)
			{
				_tprintf(_T("拆分SQL语句失败，请检查文件内容，文件路径：%s\n"), lpFilePath);
				goto SobeyMemDB_main_Read_File;
			}
			else
			{
				nSqlCount = vecSql.size();
				if (nSqlCount == 0)
				{
					_tprintf(_T("拆分SQL语句失败，返回0条结果，文件路径：%s\n"), lpFilePath);
				}
				else
				{
					i = 0;
					while (TRUE)
					{
						nAffectCount = 0;
						memset(&stExecutePlanDesc, 0, sizeof(EXECUTEPLANINFO));
						memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
						nRet = pSobeyInterface->SqlQuery(vecSql[i], nAffectCount, stRs, &stExecutePlanDesc, &stStatisticsInfo);
						if (nRet == MF_OK || nRet == MF_PARSECMD_EMPTY_STRING)
						{
							//成功不显示结果
							i++;
							if (i == nSqlCount)
							{
								_tprintf(_T("执行全部%d条SQL语句成功！\r\n"), i);
								break;
							}
						} 
						else
						{
							//_tprintf(_T("执行第%d条SQL语句失败，错误码：%d\r\nSQL语句：%s\r\n"), i+1, stStatisticsInfo.m_nRet, vecSql[i]);
							printf("执行第%d条SQL语句失败，返回值：%d，错误码：%d\r\nSQL语句：%s\r\n", i+1, nRet, stStatisticsInfo.m_nRet, vecSql[i]);
							break;
						}
					}
				}
			}

SobeyMemDB_main_Read_File:
			if (pBuffer != NULL)
			{
				delete[] pBuffer;
			}
			if (hFile != NULL)
			{
				fclose(hFile);
			}
		}
		else
		{
			//转换到UTF8编码
			WideCharToMultiByte(CP_UTF8, 0, g_wcReadBuffer, nLength+1, g_cReadBuffer, MF_CONSOLE_READBUFFER_SIZE_CHAR, NULL, NULL);

			//将SQL命令发给Server端
			nAffectCount = 0;
			memset(&stExecutePlanDesc, 0, sizeof(EXECUTEPLANINFO));
			memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
			nRet = pSobeyInterface->SqlQuery(g_cReadBuffer, nAffectCount, stRs, &stExecutePlanDesc, &stStatisticsInfo);
			if (nRet != MF_OK)
			{
				_tprintf(_T("执行失败，返回值：%d，错误码：%d\nSQL语句：%s\n"), nRet, stStatisticsInfo.m_nRet, g_wcReadBuffer);
			}
			else
			{
				//显示执行结果
				DisplayResult(nAffectCount, stRs, stExecutePlanDesc, stStatisticsInfo);
			}
		}

		//Sleep(1);
	}

	nRet = pSobeyInterface->UserLogOut(nRet);

SobeyMemDB_main_Release:
	if (pSobeyInterface != NULL)
	{
		delete pSobeyInterface;
	}
	return 0;
}

//解析输入参数
int ParseLoginCommad(int argc, TCHAR* argv[])
{
	if (argc < 1)
	{
		_tprintf(_T("Error\n"));
		return 1;
	}
	if (argv == NULL)
	{
		_tprintf(_T("Error\n"));
		return 1;
	}

	int nCount, nLength;
	TCHAR* lpStr;
	BOOL bEnterPassWord = FALSE;

	nCount = argc;
	for (int i = 0; i < nCount; i++)
	{
		lpStr = argv[i];
		nLength = _tcslen(lpStr);
		if (nLength < 2)
		{
			_tprintf(_T("Error\n"));
			return 1;
		}
		if (_tcsnicmp(lpStr, _T("-u"), 2) == 0)					//ID
		{
			if (nLength == 2)									//判断命令选项和命令值之间是否包括空格
			{
				i++;
				if (i >= nCount)
				{
					_tprintf(_T("Error\n"));
					return 1;
				}
				lpStr = argv[i];
				nLength = min(_tcslen(lpStr), MF_CONSOLE_ID_MAX_LENGTH_WCHAR);
				memcpy(g_stuUserInfo.m_wcUserID, lpStr, nLength*sizeof(TCHAR));

				g_stuOption.m_bUserID = TRUE;
			} 
			else
			{
				lpStr = argv[i] + 2;
				nLength = min(_tcslen(lpStr), MF_CONSOLE_ID_MAX_LENGTH_WCHAR);
				memcpy(g_stuUserInfo.m_wcUserID, lpStr, nLength*sizeof(TCHAR));

				g_stuOption.m_bUserID = TRUE;
			}
		} 
		else if (_tcsnicmp(lpStr, _T("-p"), 2) == 0)			//PW
		{
			if (nLength == 2)									//判断命令选项和命令值之间是否包括空格
			{
				i++;
				if (i >= nCount)								//-p 为最后一个字段，则说明没有在命令行中直接键入密码，需要再输入密码。
				{
					bEnterPassWord = TRUE;
				}
				else											//-p 不为最后一个字段。判断后一个字段是否为允许的命令选项。
				{
					if (IsLoginOption(argv[i]))					//后一个字段是命令选项，则说明没有在命令行中直接键入密码，需要再输入密码。
					{
						bEnterPassWord = TRUE;
						i--;
					} 
					else										//后一个字段不是命令选项，则后一个字段为输入的密码。
					{
						bEnterPassWord = FALSE;

						lpStr = argv[i];
						nLength = min(_tcslen(lpStr), MF_CONSOLE_PW_MAX_LENGTH_WCHAR);
						memcpy(g_stuUserInfo.m_wcPassword, lpStr, nLength*sizeof(TCHAR));

						g_stuOption.m_bPassWord = TRUE;
					}
				}
			} 
			else
			{
				bEnterPassWord = FALSE;

				lpStr = argv[i] + 2;
				nLength = min(_tcslen(lpStr), MF_CONSOLE_PW_MAX_LENGTH_WCHAR);
				memcpy(g_stuUserInfo.m_wcPassword, lpStr, nLength*sizeof(TCHAR));

				g_stuOption.m_bPassWord = TRUE;
			}
		} 
		else
		{
			_tprintf(_T("Error\n"));
			return 1;
		}
	}

	if (bEnterPassWord)
	{
		_tprintf(_T("Enter password: "));

		TCHAR ch;
		int i = 0;
		while( (ch=_gettch()) != '\r' )	//以回车结束
		{
			if(ch != '\b')				//不是退格就录入
			{
				if (i >= MF_CONSOLE_PW_MAX_LENGTH_WCHAR)
				{
					continue;
				}
				g_stuUserInfo.m_wcPassword[i]=ch;
				_puttchar('*');			//输出*号
				i++;
			}
			else
			{
				if (i <= 0)
				{
					continue;
				}
				_tprintf(_T("\b \b"));
				//_puttchar('\b');			//这里是删除一个，我们通过输出退格符 /b，回退一格，
				//_puttchar(' ');			//再显示空格符把刚才的*给盖住，
				//_puttchar('\b');			//然后再回退一格等待录入。
				i--;
			}
		}
		_tprintf(_T("\n"));
		g_stuUserInfo.m_wcPassword[i] = '\0';
		_tprintf(_T("%s\n"), g_stuUserInfo.m_wcPassword);			//这里改成其他提示信息

		g_stuOption.m_bPassWord = TRUE;
	} 
	else
	{
		_tprintf(_T("Warning: Using a password on the command line interface can be insecure.\n"));
	}

	//转换为UTF8编码
	WideCharToMultiByte(CP_UTF8, 0, g_stuUserInfo.m_wcUserID, MF_CONSOLE_ID_MAX_LENGTH_WCHAR, g_stuUserInfo.m_cUserID, MF_CONSOLE_ID_MAX_LENGTH_CHAR, NULL, NULL);
	WideCharToMultiByte(CP_UTF8, 0, g_stuUserInfo.m_wcPassword, MF_CONSOLE_PW_MAX_LENGTH_WCHAR, g_stuUserInfo.m_cPassword, MF_CONSOLE_PW_MAX_LENGTH_CHAR, NULL, NULL);

	return 0;
}

//判断输入字符串是否符合格式
BOOL IsLoginOption(TCHAR* lpStr)
{
	if (lpStr == NULL)
	{
		return FALSE;
	}
	int nLength = _tcslen(lpStr);

	if (_tcsnicmp(lpStr, _T("-u"), 2) == 0)					//ID
	{
		return TRUE;
	} 
	else if (_tcsnicmp(lpStr, _T("-p"), 2) == 0)			//PW
	{
		return TRUE;
	} 
	else
	{
		return FALSE;
	}
	return FALSE;
}


//判断是否为退出命令
BOOL IsQuit(TCHAR* lpCommand)
{
	if (lpCommand == NULL)
	{
		return TRUE;		//不应该存在这样的情况。这里返回TRUE让程序直接退出
	}

	if (_tcsicmp(lpCommand, _T("\\q")) == 0 || _tcsicmp(lpCommand, _T("quit")) == 0 || _tcsicmp(lpCommand, _T("exit")) == 0)
	{
		return TRUE;
	} 
	else
	{
		return FALSE;
	}
}

//判断是否为帮助命令
BOOL IsHelp(TCHAR* lpCommand)
{
	if (lpCommand == NULL)
	{
		return FALSE;
	}

	if (_tcsicmp(lpCommand, _T("\\h")) == 0 || _tcsicmp(lpCommand, _T("help")) == 0)
	{
		return TRUE;
	} 
	else
	{
		return FALSE;
	}
}


//显示结果
//记录中有中文字符时，宽度计算不正确，可能对齐有问题
void DisplayResult(LONG lAffectCount, CMemDBRecordset& stRs, EXECUTEPLANDESCRIBE stExecutePlanInfo, MF_EXECUTE_STATISTICS stStatisticsInfo)
{
	if (stStatisticsInfo.m_nSqlType == 0)
	{
		int nFieldWidth[8], nCount, i;
		TCHAR strFormat[100];

		nFieldWidth[0] = max(6, _tcslen(stExecutePlanInfo.m_pObjectName));
		nFieldWidth[1] = 8;
		nFieldWidth[2] = max(6, _tcslen(stExecutePlanInfo.m_pIndexName));
		nFieldWidth[3] = 8;
		nFieldWidth[4] = 8;
		nFieldWidth[5] = 8;
		nFieldWidth[6] = 8;
		nFieldWidth[7] = max(8, _tcslen(stExecutePlanInfo.m_pDescribe));

		//分割线
		for (i = 0; i < 8; i++)
		{
			_tprintf(_T("+"));
			nCount = nFieldWidth[i] + 2;
			ShowNCharacters(nCount, '-');
		}
		_tprintf(_T("+\n"));

		//第一行：列名
		_tprintf(_T("|"));
		_tprintf(_T(" 对象名 "));
		nCount = nFieldWidth[0] - 6;
		ShowNCharacters(nCount, ' ');

		_tprintf(_T("|"));
		_tprintf(_T(" 对象类型 "));
		nCount = nFieldWidth[1] - 8;
		ShowNCharacters(nCount, ' ');

		_tprintf(_T("|"));
		_tprintf(_T(" 索引名 "));
		nCount = nFieldWidth[2] - 6;
		ShowNCharacters(nCount, ' ');

		_tprintf(_T("|"));
		_tprintf(_T(" 索引类型 "));
		nCount = nFieldWidth[3] - 8;
		ShowNCharacters(nCount, ' ');

		_tprintf(_T("|"));
		_tprintf(_T(" 递归方向 "));
		nCount = nFieldWidth[4] - 8;
		ShowNCharacters(nCount, ' ');

		_tprintf(_T("|"));
		_tprintf(_T(" 递归深度 "));
		nCount = nFieldWidth[5] - 8;
		ShowNCharacters(nCount, ' ');

		_tprintf(_T("|"));
		_tprintf(_T(" 记录数量 "));
		nCount = nFieldWidth[6] - 8;
		ShowNCharacters(nCount, ' ');

		_tprintf(_T("|"));
		_tprintf(_T(" 描述信息 "));
		nCount = nFieldWidth[7] - 8;
		ShowNCharacters(nCount, ' ');
		_tprintf(_T("|\n"));

		//分割线
		for (i = 0; i < 8; i++)
		{
			_tprintf(_T("+"));
			nCount = nFieldWidth[i] + 2;
			ShowNCharacters(nCount, '-');
		}
		_tprintf(_T("+\n"));

		//第二行：值
		_tprintf(_T("|"));
		_stprintf(strFormat, _T(" %% -%ds "), nFieldWidth[0]);
		_tprintf(strFormat, stExecutePlanInfo.m_pObjectName);

		_tprintf(_T("|"));
		_stprintf(strFormat, _T(" %% %dd "), nFieldWidth[1]);
		_tprintf(strFormat, stExecutePlanInfo.m_bObjectType);

		_tprintf(_T("|"));
		_stprintf(strFormat, _T(" %% -%ds "), nFieldWidth[2]);
		_tprintf(strFormat, stExecutePlanInfo.m_pIndexName);

		_tprintf(_T("|"));
		_stprintf(strFormat, _T(" %% %dd "), nFieldWidth[3]);
		_tprintf(strFormat, stExecutePlanInfo.m_bIndexType);

		_tprintf(_T("|"));
		_stprintf(strFormat, _T(" %% %dd "), nFieldWidth[4]);
		_tprintf(strFormat, stExecutePlanInfo.m_bDrection);

		_tprintf(_T("|"));
		_stprintf(strFormat, _T(" %% %dd "), nFieldWidth[5]);
		_tprintf(strFormat, stExecutePlanInfo.m_bRecursionLevel);

		_tprintf(_T("|"));
		_stprintf(strFormat, _T(" %% %dd "), nFieldWidth[6]);
		_tprintf(strFormat, stExecutePlanInfo.m_nRowNumber);

		_tprintf(_T("|"));
		_stprintf(strFormat, _T(" %% -%ds "), nFieldWidth[7]);
		_tprintf(strFormat, stExecutePlanInfo.m_pDescribe);
		_tprintf(_T("|\n"));

		//分割线
		for (i = 0; i < 8; i++)
		{
			_tprintf(_T("+"));
			nCount = nFieldWidth[i] + 2;
			ShowNCharacters(nCount, '-');
		}
		_tprintf(_T("+\n"));
	}
	else if (stStatisticsInfo.m_nSqlType == 1)
	{
		int i, j, nCount, nFieldNum, nRowNum, nFieldWidth[256], nLength;
		TCHAR strFormat[100];
		LPRECORD lpRecord;

		memset(nFieldWidth, 0, sizeof(nFieldWidth));

		nRowNum = stRs.GetRowNum();
		nFieldNum = stRs.GetFieldNum();
		if (nFieldNum > 256)
		{
			_tprintf(_T("Error\n"));
			return;
		}
		//各字段显示宽度
		for (i = 0; i < nFieldNum; i++)
		{
			nFieldWidth[i] = _tcslen(stRs.FieldName(i));
		}
		for (j = 0; j < nRowNum; j++)
		{
			lpRecord = stRs.GetRow(j);
			for (i = 0; i < nFieldNum; i++)
			{
				if(lpRecord->FieldStr(i) != NULL)
				{
					nLength = _tcslen(lpRecord->FieldStr(i));
				}
				else
				{
					nLength = 0;
				}
				if (nFieldWidth[i] < nLength)
				{
					nFieldWidth[i] = nLength;
				}
			}
		}

		//分割线
		for (i = 0; i < nFieldNum; i++)
		{
			_tprintf(_T("+"));
			nCount = nFieldWidth[i] + 2;
			ShowNCharacters(nCount, '-');
		}
		_tprintf(_T("+\n"));

		//第一行：列名
		for (i = 0; i < nFieldNum; i++)
		{
			_tprintf(_T("|"));
			_stprintf(strFormat, _T(" %% -%ds "), nFieldWidth[i]);
			_tprintf(strFormat, stRs.FieldName(i));
		}
		_tprintf(_T("|\n"));

		//分割线
		for (i = 0; i < nFieldNum; i++)
		{
			_tprintf(_T("+"));
			nCount = nFieldWidth[i] + 2;
			ShowNCharacters(nCount, '-');
		}
		_tprintf(_T("+\n"));

		//值
		for (j = 0; j < nRowNum; j++)
		{
			lpRecord = stRs.GetRow(j);
			for (i = 0; i < nFieldNum; i++)
			{
				_tprintf(_T("|"));
				_stprintf(strFormat, _T(" %% -%ds "), nFieldWidth[i]);
				if(lpRecord->FieldStr(i) != NULL)
				{
					_tprintf(strFormat, lpRecord->FieldStr(i));
				}
				else
				{
					_tprintf(strFormat, _T(""));
				}
			}
			_tprintf(_T("|\n"));
		}

		//分割线
		for (i = 0; i < nFieldNum; i++)
		{
			_tprintf(_T("+"));
			nCount = nFieldWidth[i] + 2;
			ShowNCharacters(nCount, '-');
		}
		_tprintf(_T("+\n"));
		_tprintf(_T("记录数：%d，"), nRowNum);
	}
	else if (stStatisticsInfo.m_nSqlType == 2 || stStatisticsInfo.m_nSqlType == 3)
	{
		_tprintf(_T("修改的记录数：%d，"), lAffectCount);
	}
	else
	{
		_tprintf(_T("DisplayError，SQL语句类型错误：%d\n"), stStatisticsInfo.m_nSqlType);
		return;
	}
	
	DWORD dwClientIme;
	if(stStatisticsInfo.m_llFrequence == 0)
	{
		dwClientIme		 = 0;
	}
	else
	{
		if(stStatisticsInfo.m_llEnd > stStatisticsInfo.m_llStart && stStatisticsInfo.m_llStart != 0)
		{
			dwClientIme		 = (DWORD)(1000000 * (stStatisticsInfo.m_llEnd - stStatisticsInfo.m_llStart) / stStatisticsInfo.m_llFrequence);//换算到微秒数
		}
		else
		{
			dwClientIme		 = 0;
		}
	}
	_tprintf(_T("耗时：%.3lfs\n"), (double)dwClientIme/1000000.0);
}

//输出指定长度的连续符号
void ShowNCharacters(int nCount, BYTE bChar)
{
	while (nCount > 0)
	{
		putchar(bChar);
		nCount--;
	}
}

char* UnicodeToANSI(const wchar_t * lpwData)
{
	int nLength, nwLength;
	char *lpData;

	nLength = 0;
	nwLength = 0;
	lpData = NULL;

	if(lpwData == NULL)
	{
		return NULL;
	}
	nwLength = (int)wcslen(lpwData)+1;

	nLength = WideCharToMultiByte(CP_ACP, 0, lpwData,  nwLength, NULL, NULL, NULL, NULL);
	lpData = new char[nLength];
	if(lpData == NULL)
	{
		return NULL;
	}
	memset(lpData, 0, nLength);

	WideCharToMultiByte(CP_ACP, 0, lpwData, nwLength, lpData, nLength, NULL, NULL);
	return lpData;
}

wchar_t* ANSIToUnicode(const char * lpData)
{
	int nLength, nwLength;
	wchar_t *lpwData;

	nLength = 0;
	nwLength = 0;
	lpwData = NULL;

	if(lpData == NULL)
	{
		return NULL;
	}
	nLength = (int)strlen(lpData)+1;

	nwLength = MultiByteToWideChar(CP_ACP, 0, lpData, nLength, NULL, NULL);
	lpwData = new wchar_t[nwLength];
	if(lpwData == NULL)
	{
		return NULL;
	}
	memset(lpwData, 0, nwLength*sizeof(wchar_t));

	MultiByteToWideChar(CP_ACP, 0, lpData, nLength, lpwData, nwLength);
	return lpwData;
}