﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
// Setup.cpp : 定义控制台应用程序的入口点。
//

#include "Setup.h"

char g_lpBaseFilePath[MAX_PATH];
char g_lpWorkingPath[MAX_PATH];
char g_lpDataFilePath[MAX_PATH];
char g_lpDatabasePath[MAX_PATH];
char g_lpConfigPath[MAX_PATH];

int _tmain(int argc, _TCHAR* argv[])
{
	int nRet, nType, nLength, nReadSize;
	char cReadBuffer[SOBEYDB_LINUX_SETUP_BUFFER_SIZE];

	char cDatabaseName[SOBEYDB_LINUX_SETUP_VALUE_LENGTH];
	char cDataFileSize[SOBEYDB_LINUX_SETUP_VALUE_LENGTH];
	char cTreeFileSize[SOBEYDB_LINUX_SETUP_VALUE_LENGTH];
	char cKVFileSize[SOBEYDB_LINUX_SETUP_VALUE_LENGTH];
	char cHostIP[SOBEYDB_LINUX_SETUP_VALUE_LENGTH];

	memset(cReadBuffer, 0, sizeof(cReadBuffer));
	memset(g_lpBaseFilePath, 0, sizeof(g_lpBaseFilePath));
	memset(g_lpWorkingPath, 0, sizeof(g_lpWorkingPath));
	memset(g_lpDataFilePath, 0, sizeof(g_lpDataFilePath));
	memset(g_lpDatabasePath, 0, sizeof(g_lpDatabasePath));
	memset(g_lpConfigPath, 0, sizeof(g_lpConfigPath));

	//获取文件路径
	GetModuleFileName(NULL, g_lpBaseFilePath, MAX_PATH);
	(strrchr(g_lpBaseFilePath, '/'))[1] = 0;
	memcpy(g_lpWorkingPath, g_lpBaseFilePath, MAX_PATH);									/*g_lpWorkingPath			..\Vernox\Bin\*/
	(strrchr(g_lpBaseFilePath, '/'))[0] = 0;
	(strrchr(g_lpBaseFilePath, '/'))[1] = 0;													/*g_lpBaseFilePath		..\Vernox\*/
	sprintf(g_lpDataFilePath, "%sData/", g_lpBaseFilePath);								/*g_lpDataFilePath		..\Vernox\Data\*/
	sprintf(g_lpDatabasePath, "%sData/Vernox/", g_lpBaseFilePath);						/*g_lpDatabasePath		..\Vernox\Data\Vernox\*/

	sprintf(g_lpConfigPath, "%sVernoxConfig.ini", g_lpWorkingPath);





Main_Begin:
	printf("安装方式：1  --主节点；0  --退出程序\n");
	do 
	{
		printf(">> 选择安装方式： ");

		cin.getline(cReadBuffer, SOBEYDB_LINUX_SETUP_BUFFER_SIZE, '\n');
		if (strcasecmp(cReadBuffer, "0") == 0)
		{
			goto Main_Exit;
		}
		else if (strcasecmp(cReadBuffer, "1") == 0)
		{
			nType = 1;
			printf("已选择安装方式：1\n");
			break;
		}
		else
		{
			printf("输入参数错误，请重新选择！\n");
			continue;
		}
	} while (TRUE);

	if (nType == 1)
	{
		//printf("请输入新建的数据库名称，输入\\q退出程序\n");
		//printf(">> 数据库名： ");
		//cin.getline(cReadBuffer, SOBEYDB_LINUX_SETUP_BUFFER_SIZE, '\n');
		//if (strncasecmp(cReadBuffer, "\\q", 2) == 0)
		//{
		//	goto Main_Exit;
		//} 
		//else
		//{
		//	nLength = min(SOBEYDB_LINUX_SETUP_VALUE_LENGTH-1, strlen(cReadBuffer));
		//	memset(cDatabaseName, 0, sizeof(cDatabaseName));
		//	memcpy(cDatabaseName, cReadBuffer, nLength);
		//}
		memset(cDatabaseName, 0, sizeof(cDatabaseName));
		sprintf(cDatabaseName, "Vernox");
		sprintf(g_lpDatabasePath, "%s%s/", g_lpDataFilePath, cDatabaseName);

		printf("请输入数据文件大小（单位MB），输入\\q退出程序\n");
		printf(">> 数据文件（DataFile）大小： ");
		cin.getline(cReadBuffer, SOBEYDB_LINUX_SETUP_BUFFER_SIZE, '\n');
		if (strncasecmp(cReadBuffer, "\\q", 2) == 0)
		{
			goto Main_Exit;
		} 
		else
		{
			nReadSize = strlen(cReadBuffer);
			nLength = min(SOBEYDB_LINUX_SETUP_VALUE_LENGTH-1, nReadSize);
			memset(cDataFileSize, 0, sizeof(cDataFileSize));
			memcpy(cDataFileSize, cReadBuffer, nLength);
		}

		printf("请输入Tree文件大小（单位MB），输入\\q退出程序\n");
		printf(">> Tree文件（TreeFile）大小： ");
		cin.getline(cReadBuffer, SOBEYDB_LINUX_SETUP_BUFFER_SIZE, '\n');
		if (strncasecmp(cReadBuffer, "\\q", 2) == 0)
		{
			goto Main_Exit;
		} 
		else
		{
			nReadSize = strlen(cReadBuffer);
			nLength = min(SOBEYDB_LINUX_SETUP_VALUE_LENGTH-1, nReadSize);
			memset(cTreeFileSize, 0, sizeof(cTreeFileSize));
			memcpy(cTreeFileSize, cReadBuffer, nLength);
		}

		printf("请输入KV文件大小（单位MB），输入\\q退出程序\n");
		printf(">> KV文件（KVFile）大小： ");
		cin.getline(cReadBuffer, SOBEYDB_LINUX_SETUP_BUFFER_SIZE, '\n');
		if (strncasecmp(cReadBuffer, "\\q", 2) == 0)
		{
			goto Main_Exit;
		} 
		else
		{
			nReadSize = strlen(cReadBuffer);
			nLength = min(SOBEYDB_LINUX_SETUP_VALUE_LENGTH-1, nReadSize);
			memset(cKVFileSize, 0, sizeof(cKVFileSize));
			memcpy(cKVFileSize, cReadBuffer, nLength);
		}

		printf("数据库名：%s，数据文件大小：%s MB，Tree文件大小：%s MB，KV文件大小：%s MB\n数据库路径：%s\n",
				cDatabaseName, cDataFileSize, cTreeFileSize, cKVFileSize, g_lpDatabasePath);
		printf("确认按照以上参数创建数据库？  yes  --确定，no  --取消并退出程序，re  --取消并重新输入参数\n");
		while (TRUE)
		{
			printf(">> 确认创建数据库： ");
			cin.getline(cReadBuffer, SOBEYDB_LINUX_SETUP_BUFFER_SIZE, '\n');
			if (strncasecmp(cReadBuffer, "yes", 3) == 0)
			{
				break;
			}
			else if (strncasecmp(cReadBuffer, "no", 2) == 0)
			{
				goto Main_Exit;
			}
			else if (strncasecmp(cReadBuffer, "re", 2) == 0)
			{
				goto Main_Begin;
			}
			else
			{
				printf("输入参数错误，请重新选择！\n");
			}
		}

		//创建数据库
		if(_taccess(g_lpDatabasePath, 0) != 0)
		{
			CreateDirectory(g_lpDatabasePath, NULL);

			//创建系统文件
			nRet = CreateSystemDataFile(8*1024*1024);
			if (nRet == 0)
			{
				printf("创建数据库服务系统文件成功！\n");
			}
			else
			{
				printf("创建数据库服务系统文件失败，错误码：%d\n", nRet);
				goto Main_Exit;
			}
		}
		else
		{
			printf("创建数据库失败，数据库已存在，数据库路径：%s\n", g_lpDatabasePath);
			goto Main_Exit;
		}
		printf("启动服务...\n");

		//启动服务
		remove("/ServiceStart");
		remove("/StorageStart");

		WritePrivateProfileString("Config", "cluster", "0", g_lpConfigPath);
		sighandler_t oldhandler;
		oldhandler = signal(SIGCHLD, SIG_DFL);
		nRet = system("service vernoxstorage start");
		signal(SIGCHLD, oldhandler);
		if (nRet != 0)
		{
			printf("启动服务vernoxstorage失败，错误码：%d\n", nRet);
			goto Main_Exit;
		}

		printf("启动服务Storage.");
		while(true)
		{
			Sleep(1000);
			if(access("/StorageStart", 0) == 0)
			{
				break;
			}
			printf(".");
		}
		printf("\n");

		oldhandler = signal(SIGCHLD, SIG_DFL);
		nRet = system("service vernoxservice start");
		signal(SIGCHLD, oldhandler);
		if (nRet != 0)
		{
			printf("启动服务vernoxservice失败，错误码：%d\n", nRet);
			goto Main_Exit;
		}

		printf("启动服务Service.");
		while(true)
		{
			Sleep(1000);
			if(access("/ServiceStart", 0) == 0)
			{
				break;
			}
			printf(".");
		}
		printf("\n");
		printf("启动服务成功！\n");

		remove("/ServiceStart");
		remove("/StorageStart");

		printf("创建数据文件...\n");

		//创建数据文件
		nRet = CreateDataFile(cDataFileSize, cTreeFileSize, cKVFileSize);
		//nRet = CreateDataFile("8", "8", "8");
		if (nRet == 0)
		{
			printf("创建数据库服务数据文件成功！\n");
		}
		else
		{
			printf("创建数据库服务数据文件失败，错误码：%d\n", nRet);
			goto Main_Exit;
		}
		//printf("创建数据库服务成功！\n");
	} 
	else
	{
		goto Main_Exit;
	}


	printf("创建数据库服务成功！安装程序退出...\n");
	return 0;

Main_Exit:
	printf("创建数据库服务失败！安装程序退出...\n");
	return 0;
}

////////////////////////////////////////////////////////////////////////////////

int CreateSystemDataFile(LONGLONG llSystemFileSize)
{
	FILE *fp;
	LONGLONG nPos;
	LPBYTE lpBuffer;
	long long nTimestamp;
	int nBufferSize, nRet;
	TCHAR lpFilePath[MAX_PATH];
	LPSYSTEMFILEHEAD lpSystemFileHead;

	memset(lpFilePath, 0, MAX_PATH * sizeof(TCHAR));

	nBufferSize = 8*1024*1024;
	lpBuffer = new BYTE[nBufferSize];
	memset(lpBuffer, 0, nBufferSize);


	//需要新建此文件
	sprintf(lpFilePath, "%sSystem.dbf", g_lpDatabasePath);
	if(_taccess(lpFilePath, 0) == 0)
	{
		printf("数据库服务系统文件已存在！文件路径：%s！\n", lpFilePath);
		return 1;
	}
	fp = fopen(lpFilePath, "w+");
	if (fp == NULL)
	{
		//新建文件失败
		delete[] lpBuffer;
		printf("创建数据库服务系统文件失败！文件路径：%s，错误码：%d！\n", lpFilePath, GetLastError());
		return GetLastError();
	}

	//写入文件头
	lpSystemFileHead = (LPSYSTEMFILEHEAD)lpBuffer;
	ReadSysConfigParam(lpSystemFileHead, llSystemFileSize);

	GetSystemTimeAsFileTime((LPFILETIME)&nTimestamp);
	nRet = CreateSystemObject(lpBuffer, MF_SYS_OBJECTTYPE_DUAL, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = CreateSystemObject(lpBuffer, MF_SYS_OBJECTTYPE_FILE, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = CreateSystemObject(lpBuffer, MF_SYS_OBJECTTYPE_OBJECT, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = CreateSystemObject(lpBuffer, MF_SYS_OBJECTTYPE_INDEX, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = CreateSystemObject(lpBuffer, MF_SYS_OBJECTTYPE_SEQUENCE, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = CreateSystemObject(lpBuffer, MF_SYS_OBJECTTYPE_STATISTICS, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = CreateSystemObject(lpBuffer, MF_SYS_OBJECTTYPE_SESSION, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = CreateSystemObject(lpBuffer, MF_SYS_OBJECTTYPE_SOAPSERVER, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = CreateSystemObject(lpBuffer, MF_SYS_OBJECTTYPE_USERINFO, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = CreateSystemObject(lpBuffer, MF_SYS_OBJECTTYPE_AUTHORITY, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(fwrite(lpBuffer, 1, nBufferSize, fp) != nBufferSize)
	{
		//写入失败
		delete[] lpBuffer;
		return GetLastError();
	}

	//写入初始文件数据
	memset(lpBuffer, 0, nBufferSize);
	for(nPos = nBufferSize; nPos < llSystemFileSize; nPos += nBufferSize)
	{
		if(llSystemFileSize - nPos > nBufferSize)
		{
			if(fwrite(lpBuffer, 1, nBufferSize, fp) != nBufferSize)
			{
				//写入失败
				delete[] lpBuffer;
				return GetLastError();
			}
		}
		else
		{
			if(fwrite(lpBuffer, 1, llSystemFileSize - nPos, fp) != llSystemFileSize - nPos)
			{
				//写入失败
				delete[] lpBuffer;
				return GetLastError();
			}
		}
	}

	fclose(fp);
	delete[] lpBuffer;
	return MF_OK;
}

int CreateDataFile(char* lpDataFileSize, char* lpTreeFileSize, char* lpKVFileSize)
{
	USHORT usPort;
	ULONG ulIP, ulHost;
	char pStrSql[1024];
	CDBInterface sobeyIF;
	int nRet, nAffectCount;
	MF_EXECUTE_STATISTICS stStatisticsInfo;

	usPort = 8000;
	ulHost = ntohl(inet_addr("127.0.0.1"));

	nRet = sobeyIF.OpenWithAddress("root", "", ulHost, usPort);
	if (nRet != MF_OK)
	{
		printf("连接服务器失败，IP地址： 127.0.0.1:%d\n", usPort);
		return nRet;
	}


	memset(pStrSql, 0, sizeof(pStrSql));
	if (strcmp(lpDataFileSize, "0") != 0)
	{
		memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
		sprintf(pStrSql, "ALTER SYSTEM ADD DATAFILE '%sDBDataFile.dbf' MEMFILE 'MemDBDataFile' %sMB", g_lpDatabasePath, lpDataFileSize);
		nRet = sobeyIF.ExecuteCommand(pStrSql, nAffectCount, &stStatisticsInfo);
		if (nRet != MF_OK)
		{
			printf("创建文件失败，返回值：%d，错误码：%d，SQL语句：%s\n", nRet, stStatisticsInfo.m_nRet, pStrSql);
			return nRet;
		}
	}
	
	if (strcmp(lpTreeFileSize, "0") != 0)
	{
		memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
		sprintf(pStrSql, "ALTER SYSTEM ADD TREEFILE '%sDBTreeFile.dbf' MEMFILE 'MemDBTreeFile' %sMB", g_lpDatabasePath, lpTreeFileSize);
		nRet = sobeyIF.ExecuteCommand(pStrSql, nAffectCount, &stStatisticsInfo);
		if (nRet != MF_OK)
		{
			printf("创建文件失败，返回值：%d，错误码：%d，SQL语句：%s\n", nRet, stStatisticsInfo.m_nRet, pStrSql);
			return nRet;
		}
	}
	
	if (strcmp(lpKVFileSize, "0") != 0)
	{
		memset(&stStatisticsInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
		sprintf(pStrSql, "ALTER SYSTEM ADD KVFILE '%sDBKVFile.dbf' MEMFILE 'MemDBKVFile' %sMB", g_lpDatabasePath, lpKVFileSize);
		nRet = sobeyIF.ExecuteCommand(pStrSql, nAffectCount, &stStatisticsInfo);
		if (nRet != MF_OK)
		{
			printf("创建文件失败，返回值：%d，错误码：%d，SQL语句：%s\n", nRet, stStatisticsInfo.m_nRet, pStrSql);
			return nRet;
		}
	}

	return MF_OK;
}

//创建系统对象
int CreateSystemObject(LPBYTE lpFileAddr, int nSysObjectID, long long nTimestamp)
{
	long long nDataOffset;
	LPSYSTEMFILEHEAD lpSystemFileHead;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPBASEFILEBLOCKMAP lpBaseFileBlockMap;
	LPBASEFILEBLOCKMAPHEAD lpBaseFileBlockMapHead;

	lpSystemFileHead = (LPSYSTEMFILEHEAD)lpFileAddr;

	if(lpSystemFileHead->m_stuFileObjectData[nSysObjectID].m_nID == 0)
	{
		//获取空闲块，用于插入系统数据
		lpSystemFileHead->m_stuFileObjectData[nSysObjectID].m_nID	= nSysObjectID;
		lpSystemFileHead->m_stuFileObjectData[nSysObjectID].m_nFinishedTimestamp = 0;
		if(lpSystemFileHead->m_stuFileObjectData[nSysObjectID].m_nFreeBlockMapOffset == 0)
		{
			//分配新块
			if(nSysObjectID > 0 && nSysObjectID < 100)
			{
				//分配新的空闲块
				//首先检查一下是否分配了第一个块
				if(lpSystemFileHead->m_nBlockNum == 0)
				{
					//初始化应该初始化的一些参数
					lpSystemFileHead->m_nBlockMapStructSize	= sizeof(BASEFILEBLOCKMAP);
					lpSystemFileHead->m_nBlockMapStartOffset	= lpSystemFileHead->m_nFileHeaderSize;			//放在头结构体之后
					//修改
					lpSystemFileHead->m_nFileFreePos			= MF_SYS_BLOCKSIZE;							//从256KB的位置开始写数据，前面256KB保留给文件头使用吧，按道理此文件可以扩展到接近4GB左右，按经验完全使用不完
					lpSystemFileHead->m_nFileFreeSize			= lpSystemFileHead->m_nFileTotalSize - lpSystemFileHead->m_nFileFreePos;
					lpBaseFileBlockMapHead						= (LPBASEFILEBLOCKMAPHEAD)(lpFileAddr + lpSystemFileHead->m_nBlockMapStartOffset);
					memset(lpBaseFileBlockMapHead, 0, sizeof(BASEFILEBLOCKMAPHEAD));
				}

				//首先判断是否有空块，如果有就直接使用空块
				if(lpSystemFileHead->m_nFreeBlockOffset != 0)
				{
					printf("新建系统对象时，系统文件中存在空块！\n");
					return MF_INNER_SYS_OBJECTMAP_DATAERROR;
				}
				else
				{
					//首先判断空间是否够
					if(lpSystemFileHead->m_nFileFreePos + MF_SYS_BLOCKSIZE > lpSystemFileHead->m_nFileTotalSize)
					{
						//剩余空间不够
						printf("分配数据块时，发现剩余空间不够，文件大小：%lld，当前空余位置：%lld，需要分配的空间大小为：%d\n", lpSystemFileHead->m_nFileTotalSize, lpSystemFileHead->m_nFileFreePos, MF_SYS_BLOCKSIZE);
						return MF_INNER_ALLOWBLOCK_NOENOUGHSPACE;
					}

					//分配一块空间出来
					lpBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(lpFileAddr + lpSystemFileHead->m_nBlockMapStartOffset);
					lpBaseFileBlockMap	= &lpBaseFileBlockMapHead->m_pBlockMap[lpBaseFileBlockMapHead->m_nBlockMapNum];
					nDataOffset			= lpSystemFileHead->m_nBlockMapStartOffset + sizeof(BASEFILEBLOCKMAPHEAD) + (lpBaseFileBlockMapHead->m_nBlockMapNum - 1)*sizeof(BASEFILEBLOCKMAP);

					//填充块映射表数据，修改相应的指针
					lpBaseFileBlockMap->m_nBlockOffset		= lpSystemFileHead->m_nFileFreePos;
					lpBaseFileBlockMap->m_nBlockNo			= lpSystemFileHead->m_nInnerMaxNo;
					lpSystemFileHead->m_nInnerMaxNo++;
					lpSystemFileHead->m_nFileFreePos		= lpSystemFileHead->m_nFileFreePos + MF_SYS_BLOCKSIZE;
					lpSystemFileHead->m_nFileFreeSize		= lpSystemFileHead->m_nFileTotalSize - lpSystemFileHead->m_nFileFreePos;

					//填充数据库结构体
					lpSystemBlockHead						= (LPSYSTEMBLOCKHEAD)(lpFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
					lpSystemBlockHead->m_nDataFlag			= MAKEHEADFLAG('S','B','D','B');
					lpSystemBlockHead->m_nBlockNo			= lpBaseFileBlockMap->m_nBlockNo;
					lpSystemBlockHead->m_nBlockSize			= MF_SYS_BLOCKSIZE;
					lpSystemBlockHead->m_nBlockHeadSize		= sizeof(SYSTEMBLOCKHEAD);
					lpSystemBlockHead->m_bStatus			= 0;
					lpSystemBlockHead->m_bFileNo			= lpSystemFileHead->m_bFileNo;
					lpSystemBlockHead->m_nObjectID			= nSysObjectID;
					lpSystemBlockHead->m_nInnerMaxNo		= 0;
					lpSystemBlockHead->m_nDataInsertOffset	= lpSystemBlockHead->m_nBlockHeadSize;
					lpSystemBlockHead->m_nVarDataInsertOffset= MF_SYS_BLOCKSIZE;
					lpSystemBlockHead->m_nDataNum			= 0;
					if(nSysObjectID == MF_SYS_OBJECTTYPE_FILE)
					{
						lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_MEMDBFILEINFO);
					}
					else if(nSysObjectID == MF_SYS_OBJECTTYPE_OBJECT)
					{
						lpSystemBlockHead->m_nBlockDataStructSize = sizeof(SYSTEMBLOCKDATASTRUCT);
					}
					else if(nSysObjectID == MF_SYS_OBJECTTYPE_INDEX)
					{
						lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_INDEXDEF);
					}
					else if(nSysObjectID == MF_SYS_OBJECTTYPE_SEQUENCE)
					{
						lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_SEQUENCEDEF);
					}
					else if(nSysObjectID == MF_SYS_OBJECTTYPE_USERINFO)
					{
						lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_USERINFO);
					}
					else if(nSysObjectID == MF_SYS_OBJECTTYPE_AUTHORITY)
					{
						lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_AUTHORITY);
					}
					else
					{
						//目前还未考虑，暂时统一成定长数据
						lpSystemBlockHead->m_nBlockDataStructSize = sizeof(SYSTEMBLOCKDATASTRUCT);
					}

					//加入到链表中
					lpBaseFileBlockMap->m_nNextOffset = lpSystemFileHead->m_stuFileObjectData[nSysObjectID].m_nFreeBlockMapOffset;
					lpSystemFileHead->m_stuFileObjectData[nSysObjectID].m_nFreeBlockMapOffset = nDataOffset;
					lpBaseFileBlockMapHead->m_nBlockMapNum++;
					lpSystemFileHead->m_nBlockNum++;

					lpSystemBlockHead->m_bSaveFlag		= 0;
					lpSystemBlockHead->m_nTimestamp		= nTimestamp;
					lpSystemFileHead->m_nTimestamp	= nTimestamp;

					Sleep(1);
				}
			}
			if(nSysObjectID == MF_SYS_OBJECTTYPE_USERINFO)
			{
				LPFILE_USERINFO lpFileUser;
				if(lpSystemBlockHead == NULL)
				{
					printf("添加ROOT用户时失败，未发现合适的块！\n");
					return MF_INNER_POINTER_NULL;
				}
				else if((int)sizeof(LPFILE_USERINFO) >= lpSystemBlockHead->m_nVarDataInsertOffset - lpSystemBlockHead->m_nDataInsertOffset)
				{
					//空间不足，按道理不应该，因为分配时就判断了的，这里再做一下二次判断以防漏网之鱼
					printf("添加ROOT用户时失败，块内空间不足！\n");
					return MF_FAILED;
				}
				else
				{
					lpFileUser								= (LPFILE_USERINFO)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nDataInsertOffset);
					lpFileUser->m_nInnerNo					= lpSystemBlockHead->m_nInnerMaxNo;								
					lpFileUser->m_nUserID					= MakeDataID(MF_SYS_FILETYPE_SYSFILE, lpSystemBlockHead->m_nBlockNo, lpFileUser->m_nInnerNo);
					lpFileUser->m_bStatus					= 1;
					memcpy(lpFileUser->m_pUserName, "root", 32);
					memset(lpFileUser->m_pPassword, 0, 32);
					lpFileUser->m_bAuthorityID[MF_AUTHORITY_DBA] = 1;
			
					lpSystemBlockHead->m_nDataInsertOffset	+= lpSystemBlockHead->m_nBlockDataStructSize;
					lpSystemBlockHead->m_nDataNum++;
					lpSystemBlockHead->m_nInnerMaxNo++;

					lpSystemBlockHead->m_nTimestamp = nTimestamp;
				}
			}
			else if(nSysObjectID == MF_SYS_OBJECTTYPE_AUTHORITY)
			{
				//为权限表分配空间存放权限
				int nRet;
				nRet = AddAuthority(lpFileAddr, MF_AUTHORITY_DBA, "DBA", "管理员权限", nTimestamp);
				if(nRet != MF_OK)
				{
					printf("创建系统对象时，添加权限失败，权限名：DBA！\n");
					return nRet;
				}
				nRet = AddAuthority(lpFileAddr, MF_AUTHORITY_ALTERSYSTEM, "ALTERSYSTEM", "系统修改权限", nTimestamp);
				if(nRet != MF_OK)
				{
					printf("创建系统对象时，添加权限失败，权限名：ALTERSYSTEM！\n");
					return nRet;
				}
				nRet = AddAuthority(lpFileAddr, MF_AUTHORITY_CREATEOBJECT, "CREATEOBJECT", "创建对象表权限", nTimestamp);
				if(nRet != MF_OK)
				{
					printf("创建系统对象时，添加权限失败，权限名：CREATEOBJECT！\n");
					return nRet;
				}
				nRet = AddAuthority(lpFileAddr, MF_AUTHORITY_ALTEROBJECT, "ALTEROBJECT", "修改对象表权限", nTimestamp);
				if(nRet != MF_OK)
				{
					printf("创建系统对象时，添加权限失败，权限名：ALTEROBJECT！\n");
					return nRet;
				}
				nRet = AddAuthority(lpFileAddr, MF_AUTHORITY_DROPOBJECT, "DROPOBJECT", "删除对象表权限", nTimestamp);
				if(nRet != MF_OK)
				{
					printf("创建系统对象时，添加权限失败，权限名：DROPOBJECT！\n");
					return nRet;
				}
				nRet = AddAuthority(lpFileAddr, MF_AUTHORITY_CREATESEQUENCE, "CREATESEQUENCE", "创建序列权限", nTimestamp);
				if(nRet != MF_OK)
				{
					printf("创建系统对象时，添加权限失败，权限名：CREATESEQUENCE！\n");
					return nRet;
				}
				nRet = AddAuthority(lpFileAddr, MF_AUTHORITY_DROPSEQUENCE, "DROPSEQUENCE", "删除序列权限", nTimestamp);
				if(nRet != MF_OK)
				{
					printf("创建系统对象时，添加权限失败，权限名：DROPSEQUENCE！\n");
					return nRet;
				}
			}	
		}
		else
		{
			printf("创建系统对象时，新建对象已存在块！\n");
			return MF_INNER_SYS_OBJECTMAP_DATAERROR;
		}
	}
	else
	{
		//错误
		printf("创建系统对象时，对应的对象被使用，对象ID为：%d\n", nSysObjectID);
		return MF_INNER_SYS_OBJECTMAP_DATAERROR;
	}

	return MF_OK;
}

int AddAuthority(LPBYTE lpFileAddr, MF_AUTHORITY_ID bAuthorityID, const char* pAuthorityName, const char* pDescribe, long nTimestamp)
{
	long long nDataOffset;
	LPSYSTEMFILEHEAD lpSystemFileHead;
	LPFILE_AUTHORITY lpFileAuthority;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPBASEFILEBLOCKMAP lpBaseFileBlockMap;
	int nVarLength, nActualVarLen;

	lpSystemFileHead = (LPSYSTEMFILEHEAD)lpFileAddr;
	try
	{
		//计算变长数据分配长度，并处理成32的整数倍
		nActualVarLen  = sizeof(FILE_AUTHORITY);
		nVarLength	   = nActualVarLen + sizeof(SYSTEMBLOCKVARDATASTRUCT);

		//获取一块空闲块
		if(lpSystemFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_AUTHORITY].m_nID == MF_SYS_OBJECTTYPE_AUTHORITY)
		{
			//获取空闲块，用于插入系统数据
			lpSystemFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_AUTHORITY].m_nFinishedTimestamp = 0;
			nDataOffset = lpSystemFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_AUTHORITY].m_nFreeBlockMapOffset;

			lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(lpFileAddr + nDataOffset);
			lpSystemBlockHead  = (LPSYSTEMBLOCKHEAD)(lpFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			//检查空余空间，是否够
			if(lpSystemBlockHead->m_nVarDataInsertOffset - lpSystemBlockHead->m_nDataInsertOffset <= nVarLength + (int)sizeof(SYSTEMBLOCKDATASTRUCT))
			{
				printf("添加权限时，发现返回的数据库剩余空间不够，权限名：%s\n", pAuthorityName);
			}
		}
		else
		{
			printf("添加权限时，发现权限对象为空，权限名：%s\n", pAuthorityName);
		}

		//先保存User数据信息
		lpFileAuthority						    = (LPFILE_AUTHORITY)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nDataInsertOffset);
		lpFileAuthority->m_bAuthorityID			= bAuthorityID;
		memcpy(lpFileAuthority->m_pAuthorityName, pAuthorityName, 32);
		memcpy(lpFileAuthority->m_pAuthorityDesc, pDescribe, strlen(pDescribe));

		lpSystemBlockHead->m_nDataInsertOffset	+= lpSystemBlockHead->m_nBlockDataStructSize;
		lpSystemBlockHead->m_nDataNum++;
	}
	catch (...)
	{
		printf("添加权限时，出现未知异常，权限名：%s，错误码：%d\n", pAuthorityName, GetLastError());
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

//读取配置文件系统参数
//配置文件为gbk编码
//
//[Init]			初始化参数。因集群的关系，暂不允许修改
//[System]			系统参数。可以修改，每次启动服务时重新载入
void ReadSysConfigParam(LPSYSTEMFILEHEAD lpSystemFileHead, LONGLONG llSystemFileSize)
{
	UINT nParamValue;
	DWORD dwSize = MAX_PATH;
	const char* lpAppName = "System";
	char lpStrParamValue[MAX_PATH], lpFilePath[MAX_PATH];

	memset(lpFilePath, 0, MAX_PATH * sizeof(TCHAR));
	memset(lpStrParamValue, 0, MAX_PATH * sizeof(TCHAR));

	//获取配置文件路径
	GetModuleFileName(NULL, lpFilePath, MAX_PATH);
	(strrchr(lpFilePath, '/'))[1] = 0;
	strcat(lpFilePath, "VernoxConfig.ini");

	nParamValue = GetPrivateProfileInt(lpAppName, "soapprocesses", 20, lpFilePath);
	GetPrivateProfileString(lpAppName, "standbyip", "", lpStrParamValue, dwSize, lpFilePath);

	lpSystemFileHead->m_nDataFlag					= MAKEHEADFLAG('S', 'B', 'S', 'F');
	lpSystemFileHead->m_bFileNo						= 1;					//文件编号
	lpSystemFileHead->m_nTimestamp					= 0;					//文件保存的时间戳
	lpSystemFileHead->m_bStatus						= 0;					//内存文件数据锁定状态
	lpSystemFileHead->m_nFileTotalSize				= llSystemFileSize;			//文件大小
	lpSystemFileHead->m_nFileHeaderSize				= sizeof(SYSTEMFILEHEAD);							//文件头大小
	lpSystemFileHead->m_nBlockNum					= 0;												//块个数
	lpSystemFileHead->m_nBlockMapStructSize			= sizeof(BASEFILEBLOCKMAP);							//映射表中单个表项的大小
	lpSystemFileHead->m_nBlockMapStartOffset		= lpSystemFileHead->m_nFileHeaderSize;				//映射表首地址偏移，位于文件头后
	lpSystemFileHead->m_nBlockStartOffset			= 256*1024;//从256KB的位置开始写数据。块的起始地址
	lpSystemFileHead->m_nFileFreePos				= 256*1024;//从256KB的位置开始写数据。空闲空间首地址，新文件时即为块的起始位置
	lpSystemFileHead->m_nFileFreeSize				= lpSystemFileHead->m_nFileTotalSize - lpSystemFileHead->m_nFileFreePos;	//空闲空间首地址。文件大小减去空闲空间首地址
	lpSystemFileHead->m_nInnerMaxNo					= 1;		//块编号最大值，用于插入时。
	lpSystemFileHead->m_nObjectMaxID				= 100;		//对象最大ID，用于添加新OBJECT或索引时使用，前面100为系统预留，所以此值初始值为100
	lpSystemFileHead->m_nRedoLogMaxID				= 1;
	lpSystemFileHead->m_bFileMaxNo					= 2;		//文件编号最大值，用于新加数据文件使用，注意编号为1的表示系统文件
	lpSystemFileHead->m_bSysTimeChange				= 0;		//系统时间变化，0表示完全正常，1表示时间大幅度向后改变，2、表示时间向前改变
	lpSystemFileHead->m_bFileCMD					= 0;		//发生SobeyMemStorage.exe进程请求立即执行新建文件的请求，0：表示无任何处理，1：内存文件处理请求（具体新建数据在本文件内部的文件数据中），32：完成内存文件的处理请求，服务进程收到此状态后修改为0
	lpSystemFileHead->m_bReservedByte				= 10;
	lpSystemFileHead->m_nBeginTimestamp				= 0;		//文件修改的开始时间戳（由SobeyMemStorage.exe程序修改），最后一次保存文件后设置此值相当于告诉写文件进程，需要关注的最小时间戳
	lpSystemFileHead->m_nEndTimestamp				= 0;		//文件修改的结束时间戳（由本进程负责维护和修改），每完成一个修改事务的时间戳就写入此值（每次写入时负责检查是否还有小于此时间戳的修改事务，如果有就不填写，放置数据漏写），也是SobeyMemStorage.exe程序写入磁盘的最大时间戳
	lpSystemFileHead->m_nFreeBlockOffset			= 0;

	GetPrivateProfileString(lpAppName, "databasename", "Vernox", lpSystemFileHead->m_cDatabaseName, dwSize, lpFilePath);
	GetPrivateProfileString(lpAppName, "databasepath", "/Vernox/Data/Vernox/", lpSystemFileHead->m_cDatabasePath, dwSize, lpFilePath);
	lpSystemFileHead->m_nServicePort				= GetPrivateProfileInt(lpAppName, "soapport", 8080, lpFilePath);						//SERVICE_PORT ：Web Service的监听端口，默认为8080；
	lpSystemFileHead->m_nServiceWorkers				= GetPrivateProfileInt(lpAppName, "processes", 500, lpFilePath);						//SERVICE_WORKERS： Web Service的服务线程数量，默认为10；
	GetPrivateProfileString(lpAppName, "listenip", "0.0.0.0", lpStrParamValue, dwSize, lpFilePath);
	lpSystemFileHead->m_nTCPListenIP				= ntohl(inet_addr(lpStrParamValue));																	//TCP_LISTEN_IP：TCP监听IP地址，默认为0，表示不绑定网卡；
	lpSystemFileHead->m_nTCPListenPort				= GetPrivateProfileInt(lpAppName, _T("listenport"), 8000, lpFilePath);						//TCP_LISTEN_PORT：TCP监听端口，默认为8000；
	lpSystemFileHead->m_nTCPTimeout					= 60;                   //TCP_TIMEOUT ：TCP发送及接收数据超时时间，默认为60秒；
	lpSystemFileHead->m_nServerTraceLevel			= 10;                   //SERVER_TRACE_LEVEL：系统日志等级，默认为10；
	lpSystemFileHead->m_nServerEfficiencyTrace		= 0;					//SERVER_EFFICIENCY_TRACE：系统效率日志，默认为0；
	lpSystemFileHead->m_nServerParallelMode			= 0;                    //SERVER_PARALLELMODE：并行模式，0：读写互不影响，1：串行方式执行；
	lpSystemFileHead->m_nServerWriteUndoMode		= 1;                    //SERVER_WRITE_UNDOMODE ：写重做日志模式(默认为1)，0：不写，1：写
	lpSystemFileHead->m_nServerExecuteTimeMonitor	= 100;                  //SERVER_EXECUTETIME_MONITOR：执行时间监控，用于改善SQL性能，默认100毫秒
	lpSystemFileHead->m_nServerCaseSensitive		= GetPrivateProfileInt(lpAppName, _T("charcomparenocase"), 0, lpFilePath);					//SERVER_CASE_SENSITIVE：字符串大小写是否敏感，0为不敏感、1为敏感，默认为0；
	lpSystemFileHead->m_nMemoryTemporarySize		= GetPrivateProfileInt(lpAppName, _T("temporaryareasize"), 200, lpFilePath);				//MEMORY_TEMPORARY_SIZE：临时内存大小(大量数据检索使用)，单位为MB，默认48
	lpSystemFileHead->m_nMemoryUndoSize				= GetPrivateProfileInt(lpAppName, _T("undoareasize"), 400, lpFilePath);						//MEMORY_UNDO_SIZE：重做内存大小，用于数据回滚或一致性读取使用，默认48MB；
	lpSystemFileHead->m_nMemoryProcessSize			= GetPrivateProfileInt(lpAppName, _T("processprivatearea"), 2, lpFilePath)*1024*1024;		//MEMORY_PROCESS_SIZE：处理线程私有内存大小，处理与客户端通讯，默认256KB ；
	lpSystemFileHead->m_nMemoryPlanRemainSize		= 10*1024;              //MEMORY_PLAN_REMAINSIZE：执行计划空间大小，默认10KB；
	lpSystemFileHead->m_nMemorySQLPlanMaxSize		= 10*1024*1024;         //MEMORY_SQLPLAN_MAXSIZE：SQL执行计划最大大小，默认10MB；
	lpSystemFileHead->m_nMemoryRecordsetPlanMaxSize	= 500*1024*1024;        //MEMORY_RECORDSETPLAN_MAXSIZE：结果集执行计划最大大小，默认500MB；
	lpSystemFileHead->m_nWriteFileDelayTime			= 3;                    //WRITE_FILE_DELAY_TIME：写文件延迟时间，默认为3秒；
	lpSystemFileHead->m_nWriteUndoDelayTime			= 3;                    //WRITE_UNDO_DELAY_TIME：写重做日志文件延迟时间，默认为3秒；
	lpSystemFileHead->m_nWriteTraceDelayTime		= 3;                    //WRITE_TRACE_DELAY_TIME：写日志文件延迟时间，默认为3秒；
	lpSystemFileHead->m_nWriteUndoMaxSize			= 50*1024*1024;         //WRITE_UNDO_MAX_SIZE ：重做日志文件大小
	lpSystemFileHead->m_nWriteTraceMaxSize			= 50*1024*1024;         //WRITE_TRACE_MAX_SIZE ：操作日志文件大小
	lpSystemFileHead->m_nBlockDataSize				= 1*1024*1024;          //BLOCK_DATA_SIZE：数据块的大小，默认为1MB；
	lpSystemFileHead->m_nBlockBTreeIndexSize		= 32*1024;              //BLOCK_BTREE_INDEX_SIZE：B树索引块大小，默认为32KB；
	lpSystemFileHead->m_nBlockBTreeDataSize			= 32*1024;              //BLOCK_BTREE_DATA_SIZE：B树数据块大小，默认为32KB(必需为索引块的整数倍)；
	lpSystemFileHead->m_nBlockHashIndexSize			= 256*1024;             //BLOCK_HASH_INDEX_SIZE：HASH索引块大小，默认为256KB；
	lpSystemFileHead->m_nBlockHashIndexChainMaxSize	= 8;                    //BLOCK_HASH_INDEX_CHAIN_MAXSIZE：哈希索引链最大长度，超过此长度就自动增加哈希的基础槽位长度，默认为8；
	lpSystemFileHead->m_nBlockHashIndexExpandRatio	= 4;                    //BLOCK_HASH_INDEX_EXPAND_RATIO：哈希索引的基础槽位膨胀率，默认为4；
	lpSystemFileHead->m_nBlockUsedRatio				= 80;                   //BLOCK_USED_RATIO ：数据块使用率，达到此值表示块已经写满，默认为80；
	lpSystemFileHead->m_nBlockInsertMaxUseRatio		= 90;					//BLOCK_INSERT_MAXUSE_RATIO：插入数据最大使用率，超过此值不允许继续插入，默认为90；
	lpSystemFileHead->m_nBlockFreeRatio				= 40;                   //BLOCK_FREE_RATIO ：数据块剩余率，删除数据后剩余数据率低于此值可再用，默认为40；
	lpSystemFileHead->m_nBlockReorganizeRatio		= 80;                   //BLOCK_REORGANIZE_RATIO ：数据块整理率，达到此值时引起块内整理预判，默认为80；
	lpSystemFileHead->m_nBlockRecycleRatio			= 10;                   //BLOCK_RECYCLE_RATIO：数据块回收率，达到此值时进行数据整理重组，默认为10；
	lpSystemFileHead->m_nBlockIndexDivideMode		= 1;                    //BLOCK_INDEX_DIVIDE_MODE ：索引分裂方式，1：表示按照一半的方式进行分裂，2：表示按照九比一的比率分裂，3：表示按照一比九的比率分裂；
	lpSystemFileHead->m_nObjectTransactionMaxNum    = 4;					//OBJECT_TRANSACTION_MAXNUM:对象支持的最大事务数
	lpSystemFileHead->m_nTransactionLogicSlotCount	= 100;				    //TRANSACTION_LOGIC_SLOT_COUNT:短事务锁槽位数量，默认100
	lpSystemFileHead->m_nTransactionLogicTimeout	= 60;				    //TRANSACTION_LOGIC_TIMEOUT:短事务锁有效时间，单位为秒，默认60秒
	lpSystemFileHead->m_nActiveLogFiles				= GetPrivateProfileInt(lpAppName, "activelogfiles", 20, lpFilePath);					//ACTIVE_LOG_FILES：活动重做日志数量，默认20
	lpSystemFileHead->m_nPersistenceIntervals		= GetPrivateProfileInt(lpAppName, "persistenceintervals", 3, lpFilePath);				//PERSISTENCE_INTERVALS：持久化时间间隔（单位：秒），按照事务完成进行持久化处理，默认3

	memset(lpSystemFileHead->m_bReservedParameter, 0, sizeof(lpSystemFileHead->m_bReservedParameter));         //保留参数
}
