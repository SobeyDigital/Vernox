﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#define SOBEYDB_LINUX_SETUP_BUFFER_SIZE		8196
#define SOBEYDB_LINUX_SETUP_VALUE_LENGTH	32

#ifndef MAX_PATH
#define MAX_PATH	260
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <arpa/inet.h>
#include <signal.h>
using namespace std;

#include "../Include/MemDBCommonDef.h"
#include "../VernoxBaseLib/LinuxCommonAPI.h"
#include "../VernoxClientLib/DBInterface.h"
#include "../VernoxBaseLib/ServerStatusManage.h"


////////////////////////////////////////////////////////////////////////////////


//创建系统文件  单位：BYTE
int CreateSystemDataFile(LONGLONG llSystemFileSize);

//创建数据文件  单位：MB
int CreateDataFile(char* lpDataFileSize, char* lpTreeFileSize, char* lpKVFileSize);
	
//创建系统对象
int CreateSystemObject(LPBYTE lpFileAddr, int nSysObjectID, long long nTimestamp);

//添加权限
int AddAuthority(LPBYTE lpFileAddr, MF_AUTHORITY_ID bAuthorityID, const char* pAuthorityName, const char* pDescribe, long nTimestamp);

//读取配置文件系统参数
void ReadSysConfigParam(LPSYSTEMFILEHEAD lpSystemFileHead, LONGLONG llSystemFileSize);


////////////////////////////////////////////////////////////////////////////////
#pragma pack(1)
typedef struct 
{
	int	 m_nInnerNo;						//数据内部编号(新插入数据的编号 = 最大编号+1)
	BYTE m_bLockStatus;						//数据锁定状态
	BYTE m_bReserved[3];					//保留数据
	int m_nVarDataOffset;					//变长数据偏移量，使用此值加上块开始指针m_pBlockAddr，即可得到实际位置，为0表示数据已经无效了
	int m_nVarDataLength;					//变长数据实际大小
	long long m_nRollbackDataID;			//回滚区数据ID
}SYSTEMBLOCKDATASTRUCT, *LPSYSTEMBLOCKDATASTRUCT;

//变长数据结构体，除放置数据以外，会额外开销20字节，一条数据可能存在多条变长数据，他们之间的关系使用m_nNextOffset来做串联，最后一个块的m_nNextOffset值为0。
typedef struct 
{
	int	m_nDataFlag;						//数据标志，目前定为‘SBBV’
	int m_nInnerNo;							//数据内部编号，可用于数据重建恢复
	int m_nDataLength;						//变长数据长度，目前以32的倍数进行内存分配，以防止频繁分配导致无谓的开销
	int m_nActualLength;					//数据实际长度
	int m_nNextOffset;						//下级数据偏移量，使用此值加上块开始指针m_pBlockAddr，即可得到实际位置，为0表示没有后续数据块
	BYTE m_pDataContent[1];					//数据内容,首地址
}SYSTEMBLOCKVARDATASTRUCT, *LPSYSTEMBLOCKVARDATASTRUCT;
#pragma pack()
