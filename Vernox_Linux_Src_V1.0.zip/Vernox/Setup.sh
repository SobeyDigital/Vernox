#!/bin/bash

# Created on: 2017.2.27

mkdir /Vernox/
mkdir /Vernox/Bin/
mkdir /Vernox/Data/
mkdir /Vernox/Lib/

cp -i ./Bin/* /Vernox/Bin/
cp -i ./Lib/* /Vernox/Lib/

cp -i ./Script/vernoxstorage /etc/init.d/
cp -i ./Script/vernoxservice /etc/init.d/

chmod +x /Vernox/Bin/Setup /Vernox/Bin/Vernox /Vernox/Bin/VernoxStorage /Vernox/Bin/VernoxService /etc/init.d/vernoxstorage /etc/init.d/vernoxservice

systemctl stop firewalld.service
systemctl disable firewalld.service

/Vernox/Bin/Setup


