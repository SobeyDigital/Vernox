﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "BaseBlock.h"

class CMemoryBTreeFile;
class CMemoryMultiKeyBlock : public CBaseBlock
{
protected:
	#pragma pack(1)
	//关键字块结构体
	typedef struct 
	{
		int		m_nDataFlag;						//数据标志，目前数据块为‘SBDB’
		int		m_nBlockNo;							//块号(新插入块的编号 = 最大块号+1)
		long long m_nTimestamp;						//时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
		int		m_nBlockSize;						//块大小
		int		m_nBlockHeadSize;					//块头大小
		BYTE	m_bStatus;							//数据锁定状态，一般修改单条数据不需要整块锁，但如果整块进行整理时就必须进行锁定，防止其他读取或者修改操作出现错乱
		BYTE	m_bFileNo;							//文件编号
		BYTE    m_bSaveFlag;                        //数据库保存标志，防止单纯按照时间戳判断出现误判
		BYTE	m_bThreadNum;						//共享线程数
		
		int		m_nIndex;							//索引ID
		int     m_nDataSize;						//定长数据大小
		int		m_nDataInsertOffset;				//数据偏移
		int     m_nKeyInsertOffset;					//关键字偏移
													//m_nDataOffset和m_nKeyOffset之间的空间是现有空闲空间
		int		m_nDataNum;							//现有数据条数
	}BLOCKHEAD, *LPBLOCKHEAD;
	#pragma pack()
protected:
	CMemoryBTreeFile* m_pIndexFile;					//文件指针
	LPBYTE			m_lpBlockAddr;					//块指针(由构造函数进行初始化)
	LPBYTE			m_pBlockBody;					//块体指针m_pBlockBody = m_pBlockAddr + BLOCKHEAD.m_nBlockHeadSize;
	LPBLOCKHEAD		m_lpBlockHead;					//块头指针m_pBlockHead = (LPBLOCKHEAD)m_pBlockAddr;
	BYTE			m_bKeyNum;						//关键字字段数
protected:
	/************************************************************************
		功能说明:
			分配空间
	************************************************************************/
	LPBYTE AllocData(int nDataSize, long long& nOffset);

	/************************************************************************
		功能说明:
			创建后缀数据
	************************************************************************/
	void BuildSuffixArray(int* pArray, int* pArrayLen, char* pStr, int nStrLen);
public:
	CMemoryMultiKeyBlock();
	~CMemoryMultiKeyBlock();

public:
	/************************************************************************
		功能说明:
			写入数据
	************************************************************************/
	int WriteData(LPBYTE lpDataAddr, LPMULTIINDEX lpMultiIndex, int nKeyLen, long long llKeyOffset, long long nDataID);

	/************************************************************************
		功能说明：
			计算空闲区与块总大小的比例
	************************************************************************/
	virtual double RaitoStat();

	/************************************************************************
		功能说明：
			判断插入数据后，块是否会满
	************************************************************************/
	virtual BOOL IsFull(int nSize, double nRatio = 0.001);
	
	/************************************************************************
		功能说明：
			设置块指针
	************************************************************************/
	virtual void SetBlockAddr(CBaseMemoryFile* pFilePtr, LPBYTE pBlockAddr);

	/************************************************************************
		功能说明:
			初始化新建块
	************************************************************************/
	virtual void InitialBlock(int nIndexID);

	/************************************************************************
		功能说明:
			写入关键字
	************************************************************************/
	int InsertKey(LPEXECUTEPLANBSON lpExecutePlan, LPINDEXINFO lpIndexInfo, long long nTimestamp);

	/************************************************************************
		功能说明：
			删除关键字
	************************************************************************/
	int DeleteKey(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);

	/************************************************************************
		功能说明：
			获取关键字Buffer
	************************************************************************/
	int GetKeyBuffer(LPINDEXINFO lpIndexInfo, long long& llKeyBufferOffset, int& nBufferLen);

	/************************************************************************
		功能说明：
			设置关键字字段值
	************************************************************************/
	inline void SetKeyNum(BYTE bKeyNum)
	{
		m_bKeyNum = bKeyNum;
	}
};