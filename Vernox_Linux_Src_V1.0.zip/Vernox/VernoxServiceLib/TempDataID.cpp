﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "TempDataID.h"
#define MAX_DATA_NUM 100
CTempDataID::CTempDataID(CServiceBson* pServiceBson)
{
	m_bUnique			= TRUE;
	m_nDataIDNum		= 0;
	m_nCurrentIndex		= 0;
	m_nFirstIndex		= 0;
	m_pServiceBson  	= pServiceBson;
	m_pDataIDArray		= NULL;
}

CTempDataID::~CTempDataID(void)
{
}

int CTempDataID::push_back(long long nDataID)
{
	int nRet;
	BOOL bFind;
	UINT nOffset;
	LPBYTE lpAddr;
	
	if(m_pDataIDArray == NULL)
	{
		nRet = m_pServiceBson->AllocFromTempBuffer(MAX_DATA_NUM*sizeof(long long), lpAddr, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		m_pDataIDArray = (long long*)lpAddr;
	}	

	if(m_nDataIDNum > MAX_DATA_NUM)
	{
		return MF_COMMON_MAX_DATANUM;
	}

	if(m_bUnique)
	{
		nRet = m_stMapDataID.Set(nDataID, bFind);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		else if(bFind)
		{
			return MF_OK;
		}
	}
	m_pDataIDArray[m_nDataIDNum] = 	nDataID;
	m_nDataIDNum++;
	return MF_OK;
}

void CTempDataID::clear()
{
	CDataIDContainer::clear();

	m_nDataIDNum = 0;
}

//移动到DataID的起始位置
void CTempDataID::MoveFirst()
{
	m_nCurrentIndex = m_nFirstIndex;
}

//下一条DataID
int CTempDataID::NextDataID(long long& nDataID) 
{
	if(m_nCurrentIndex >= m_nDataIDNum)
	{
		nDataID = 0;
	}
	else
	{
		nDataID = m_pDataIDArray[m_nCurrentIndex];
		m_nCurrentIndex++;
	}
	return MF_OK;
}

//弹出DataID
long long CTempDataID::PopDataID()
{
	long long nDataID;
	
	nDataID = m_pDataIDArray[m_nFirstIndex];
	
	m_nFirstIndex++;
	m_nDataIDNum--;
	return nDataID;
}