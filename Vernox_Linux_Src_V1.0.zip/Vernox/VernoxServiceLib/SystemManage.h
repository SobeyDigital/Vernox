﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include <map>
#include "ServiceCommonDef.h"
#include "MapSimple.h"
#include "DataIDContainer.h"
using namespace std;

class CCharCompare;
class CServiceBson;
class CMemoryPageManager;
class CMemoryRollBackBlock;
class CDataIDContainer;
class CExecutePlanManager;
//系统文件专门独立定义一个文件来管理
//包含：OBJECT定义（以及列、索引），序列定义，文件管理等等
class CSystemManage
{
private:
	//防止此类被非法构造成对象或者复制
	CSystemManage(const CSystemManage&);
	CSystemManage& operator = (const CSystemManage&);
	CSystemManage(void);
	virtual ~CSystemManage(void);
	static CSystemManage *m_pSinstance;
	static FILE* m_pCommonTraceFile;		//句柄
	friend void Trace0(LPCSTR szFuncationName, LONG lLogLevel, LONG lLogErrorCode, LPCSTR szLog);
	friend int GetSystemParameterValue(MF_PARAMETER_TYPE nParameterName);
	friend int CharCompare(const char *pSrc, int nSrcLen, const char *pDet, int nDesLen, BOOL bMatch);
	friend int CharFind(const char *pSrc, const int nSrcLen, const char *pPat, const int nPatLen);
	friend void FreeSystemTemporaryMemory(LPBYTE lpBuf);
	void Init();
	void Release();

private:
#pragma pack(1)
	//定长数据结构
	typedef struct 
	{
		int	 m_nInnerNo;						//数据内部编号(新插入数据的编号 = 最大编号+1)
		BYTE m_bLockStatus;						//数据锁定状态
		BYTE m_bReserved[3];					//保留数据
		int m_nVarDataOffset;					//变长数据偏移量，使用此值加上块开始指针m_pBlockAddr，即可得到实际位置，为0表示数据已经无效了
		int m_nVarDataLength;					//变长数据实际大小
		long long m_nRollbackDataID;			//回滚区数据ID
	}SYSTEMBLOCKDATASTRUCT, *LPSYSTEMBLOCKDATASTRUCT;

	//变长数据结构体，除放置数据以外，会额外开销20字节，一条数据可能存在多条变长数据，他们之间的关系使用m_nNextOffset来做串联，最后一个块的m_nNextOffset值为0。
	typedef struct 
	{
		int	m_nDataFlag;						//数据标志，目前定为‘SBBV’
		int m_nInnerNo;							//数据内部编号，可用于数据重建恢复
		int m_nDataLength;						//变长数据长度，目前以32的倍数进行内存分配，以防止频繁分配导致无谓的开销
		int m_nActualLength;					//数据实际长度
		int m_nNextOffset;						//下级数据偏移量，使用此值加上块开始指针m_pBlockAddr，即可得到实际位置，为0表示没有后续数据块
		BYTE m_pDataContent[1];					//数据内容,首地址
	}SYSTEMBLOCKVARDATASTRUCT, *LPSYSTEMBLOCKVARDATASTRUCT;

	//内存中缓存序列定义
	typedef struct
	{
		long long m_nDataID;									//数据ID
		TCHAR   m_lpszName[32];									//序列名称，系统外部来访问均用此名称
		long long m_nCurrentVal;								//序列当前值
		long long m_nCacheEndVal;								//序列结束值
		int     m_nIncrementBy;									//序列增长步序
		BOOL	m_bMaxValError;									//序列最大值错误
	}SEQUENCEDEF, *LPSEQUENCEDEF;

	//段时间事务定义
	typedef struct stu_LogicTransaction
	{
		int    m_lTransactionID;								//事务ID
		char    m_lpszTransactionData[100];						//事务数据
		long long m_nStartTime;									//开始时间
		stu_LogicTransaction * m_pNext;							//下一个数据链表
	}LOGICTRANSACTION, *LPLOGICTRANSACTION;
#pragma pack()
protected:
	LPBYTE												m_pFileAddr;		//内存文件体指针(文件指针+文件头大小)
	LPSYSTEMFILEHEAD									m_pMemoryFileHead;	//内存映射文件头(m_pMemoryFileHead = (MemoryFileHead*)m_pFileAddr)
	MFID												m_nMemoryShmId;		//句柄
	CMapString											m_mapSequence;      //缓存序列定义数据Map，放置LPSEQUENCEDEF数据
	LPMEMDBFILEDEF										m_arMemDBFile[256];	//缓存内存文件定义数组
	CMapSimple											m_mapObject;
	CMapString											m_mapName2Object;   //缓存序列定义数据Map，放置LPOBJECTDEF数据，此对象只管指针，不管LPOBJECTDEF的分配和释放
	CMapSimple											m_mapIndex;		    //缓存内存索引定义数据MAP，此对象只管指针，不管LPOBJECTDEF的分配和释放，管理释放就放到m_mapObject中
	CMapSimple											m_mapBlock;			//缓存块号和块内存对应地址
	CMapSimple											m_mapSession;		//TCP会话数据Map
	CMapSimple											m_mapSoapServer;	//Soap服务数据Map
	CMapSimple											m_mapUserInfo;		//用户ID到用户数据的映射
	CMapString											m_mapName2UserInfo; //用户名到用户信息的映射
	CMapSimple											m_mapAuthority;		//权限ID到权限信息的映射
	CMapString											m_mapName2Authority;//权限名到权限信息的映射

	LPBYTE												m_pTraceFileAddr;	//日志内存文件指针
	LPFILE_TRACEMEMFILEHEAD								m_pTraceFileHead;	//日志内存文件头
	MFID												m_nTraceShmId;		//日志内存内存id
	EVENTTYPE											m_hTraceEvent;		//当空间写满40%时设置此事件，否则按照每3秒写一次的方式进行；
	LPTSTR												m_lpszTraceBuf;		//用于写日志的头部信息格式化使用
	LPBYTE												m_pLogFileAddr;		//修改日志内存文件指针
	LPFILE_TRACEMEMFILEHEAD								m_pLogFileHead;		//日志内存文件头
	MFID												m_nLogShmId;		//修改日志内存id
	EVENTTYPE											m_hLogEvent;		//当空间写满40%时设置此事件，否则按照每3秒写一次的方式进行；

	LPSQLEXECUTESTATISTICSINFO							m_pExecuteStatistics;		//SQL执行统计信息头指针
	LPWORKLOADSTATISTICSINFO							m_lpWorkloadStatistics;		//工作量统计信息指针
	LPWORKLOADSTATISTICSINFO							m_lpLatestWorkloadStatistics;	//最新统计信息
	int													m_nLatestWorkloadPos;			//取值范围，0~1439

	int													m_nTransactionLogicSlotCount;
	long long											m_nTransactionLogicTimeout;
	LPLOGICTRANSACTION									m_pLogicTransaction;		//按字符串内容建立的HASH数组
	map<int, LPLOGICTRANSACTION>						m_mapLogicTransaction;		//按ID建立的HASH数组
	LONG												m_lTransactionID;			//事务ID，累加方式

	LPTEMPORARYMEMHEAD									m_pTemporaryMemory; 		//临时内存头
	MFID												m_nTemporaryMemShmId;		//临时内存文件ID
	CMemoryRollBackBlock*								m_pRollBackMemory;
	CCharCompare*										m_pCharCompare;				//字符串操作函数
	CMemoryPageManager*									m_pPageManager;

	CRITICAL_SECTION	m_critSysDBFile;				//系统文件临界区，用于块分配、系统初始化的锁
	CRITICAL_SECTION	m_critSequence;					//序列临界区，用于序列的操作
	CRITICAL_SECTION	m_critFile;						//文件临界区，用于文件的操作
	CRITICAL_SECTION	m_critObject;					//对象临界区，用于文件的操作
	CRITICAL_SECTION	m_critUser;						//用户临界区，用于文件的操作
	CRITICAL_SECTION	m_critAuthority;				//权限临界区，用于文件的操作
	CRITICAL_SECTION	m_critTrace;					//日志临界区，用于日志的操作
	CRITICAL_SECTION	m_critLog;						//重做日志临界区
	CRITICAL_SECTION	m_critSession;					//会话数据临界区
	CRITICAL_SECTION	m_critStatistics;				//统计临界区，用于执行统计
	CRITICAL_SECTION	m_critTemporaryMemory;			//临时内存临界区，用于分配回收等
	CRITICAL_SECTION	m_critLogicTransaction;			//逻辑事务临界区，用于逻辑事务的处理
	CRITICAL_SECTION	m_critBlock;					//块临界区，用于块的修改
	CRITICAL_SECTION	m_critDataObject;				//数据对象临界区，用于对象的修改
	CRITICAL_SECTION	m_critIndex;					//索引临界区，用于索引的修改该
	CRITICAL_SECTION	m_critNode;						//结点临界区
	CRITICAL_SECTION	m_critMS;						//主备通信临界区
	CRITICAL_SECTION	m_critRoot;						//根节点临界区

	CRITICAL_SECTION	m_critDataFile;					//数据文件临界区
	CRITICAL_SECTION	m_critDataFileBlockMap;			//数据文件块映射表临界区
	
	CRITICAL_SECTION	m_critBTreeFile;				//B树索引文件临界区
	CRITICAL_SECTION	m_critBTreeFileBlockMap;		//B树索引文件块映射表临界区
	CRITICAL_SECTION	m_critBTreeRoot;				//B树索引文件根节点临界区

	CRITICAL_SECTION	m_critKVFile;					//KV索引文件临界区
	CRITICAL_SECTION	m_critKVFileHashTable;			//KV索引文件块映射表临界区
	CRITICAL_SECTION	m_critKVRoot;					//KV索引文件根节点临界区

	CRITICAL_SECTION	m_critPreprocess;				//预处理临界区
	CRITICAL_SECTION	m_critWorkload;					//工作量临界区

	LPBYTE		m_lpStorageMemFileAddr;
	MFID		m_nStorageMemFileShmId;
	THREADTYPE 	m_thMemStorageThread;

#ifdef WIN32
	HANDLE		m_hBlockLockEvent;					    //块锁等待事件
	HANDLE		m_hObjectLockEvent;					    //块对象等待事件
	HANDLE		m_hIndexLockEvent;					    //块索引等待事件
#else
	sem_t*		m_hBlockLockEvent;
	sem_t*		m_hObjectLockEvent;
	sem_t*		m_hIndexLockEvent;
#endif

#ifdef WIN32
	static unsigned int __stdcall MemStorageThread(LPVOID lpParam);
#else
	static void* MemStorageThread(LPVOID lpParam);
#endif
	bool 		m_bExit;

	FILE		*m_pBackupRedoFile;

public:
	LPSTORAGEMEMHEAD m_pStorageMemFileHead;
	int ReLoadSysObject();
	//获取Storage已经保存过的时间戳
	long long GetLastTimestamp();
	//获取数据库唯一标识
	USHORT GetDatabaseGuid();
	//获取内存文件数据锁定状态
	BYTE GetMemFileStatus();
	//立即写日志
	void SetWriteRedoEvent();

protected:
	static void WriteTraceLog(LPCSTR szFuncationName, LONG dwThreadID, DWORD dwLevel, DWORD dwErrorCode, LPCSTR szText);
	int CopyExecuteStatistics(LPSQLEXECUTESTATISTICSINFO lpNode, LPEXECUTESTATISTICSINFO lpExecuteInfo, LPEXECUTEPLANBSON lpExecutePlan, BOOL bNew);

	int LoadMemDBFileData(LPSYSTEMBLOCKHEAD lpSystemBlockHead);
	int LoadObjectData(LPSYSTEMBLOCKHEAD lpSystemBlockHead);
	int LoadIndexData(LPSYSTEMBLOCKHEAD lpSystemBlockHead);
	int LoadSequenceData(LPSYSTEMBLOCKHEAD lpSystemBlockHead);
	int LoadUserData(LPSYSTEMBLOCKHEAD lpSystemBlockHead);
	int LoadAuthorityData(LPSYSTEMBLOCKHEAD lpSystemBlockHead);
	int GetSystemFreeBlock(long long nTimestamp, int nSysObjectID, int nFreeSpace, LPSYSTEMBLOCKHEAD &lpSystemBlockHead);
	int ConvertDataID2Offset(long long nDataID, int &nOffset, LPSYSTEMBLOCKHEAD &lpSystemBlockHead);

	//分配对象空间
	int AllocFileData(BYTE bFileNo, int nID, int nBlockSize, MF_SYS_INDEXTYPE bType, int nDataNum);
	//删除对象或者素材后回收对应文件空间
	int RecycleFileData(LPEXECUTEPLANBSON lpExecutePlan, BYTE bFileNo, int nID);

	//打开内存文件，初始化相关信息
	int OpenMemDBFile(LPMEMDBFILEDEF lpMemDBFileDef);
	//关闭内存文件，释放对应内存
	int CloseMemDBFile(LPMEMDBFILEDEF lpMemDBFileDef);

	//生成内存文件名
	int CreateMemDBFileName(LPCTSTR lpszMemFileName, string &strMemFileName);
	//比较是否和文件路径名和内存文件名相同
	BOOL CmpMemDBFileName(LPCTSTR lpszMemFileName, LPMEMDBFILEDEF lpszDBFilePath);

	//对象索引排序，按照索引推荐使用顺序进行排序
	int SortObjectIndex(LPOBJECTDEF lpObject);

	//写入重做日志内存，如果太大就实行分段写入
	void WriteLogBuffer(LPBYTE lpData, int &nPos, int nLen);

	BOOL CheckTemporaryMem();
	LPBYTE AllocTemporaryMemCore(UINT nSize, int &nErrorNo);

	void SetTimestamp(LPSYSTEMBLOCKHEAD lpBlockHead, long long nTimestamp)
	{
		lpBlockHead->m_bSaveFlag		= 0;
		lpBlockHead->m_nTimestamp		= nTimestamp;
		m_pMemoryFileHead->m_nTimestamp	= nTimestamp;
	}
	
	void SetObjectTimestamp(int nObjectID, long long nTimestamp)
	{
		int i;
		for(i = 0; i < MAX_OBJECT_NUM; i++)
		{
			if(m_pMemoryFileHead->m_stuFileObjectData[i].m_nID == nObjectID)
			{
				m_pMemoryFileHead->m_stuFileObjectData[i].m_nFinishedTimestamp = nTimestamp;
				break;
			}
		}
	}
	//给对象加互斥锁
	BOOL SetObjectMutexLock(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo);

	//给对象加共享锁
	BOOL SetObjectShareLock(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo);
	
	//给对象加无锁
	BOOL SetObjectNullLock(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo);

	//给块加互斥锁
	BOOL SetBlockLockMutex(LPEXECUTEPLANBSON lpExecutePlan, LPBASEBLOCKHEAD lpBlockHead);
	
	//设置索引锁的状态
	BOOL SetIndexLockStatus(LPEXECUTEPLANBSON lpExecutePlan, LPINDEXDEF lpIndexInfo, long long nTimestamp, MF_LOCK_STATUS_TYPE bStatus);

public:
	//获取单实例指针
	static CSystemManage & instance();
	//销毁单实例数据
	static void DestoryInstance();

	//初始化系统管理类
	int InitData();
	//释放资源
	int FreeData();

	//系统维护操作函数----数据文件维护类
	int AddMemDBFile(long long nTimestamp, LPCTSTR lpszFilePath, LPCTSTR lpszMemFileName, BYTE bFileType, long long nFileSize);
	int AlterMemDBFilePath(long long nTimestamp, BYTE bFileNo, LPCTSTR lpszOldFilePath, LPCTSTR lpszNewFilePath);
	int AlterMemDBFileSize(long long nTimestamp, BYTE bFileNo, LPCTSTR lpszFilePath, long long nFileSize);
	int DropMemDBFile(long long nTimestamp, LPCTSTR lpszFilePath);
	int ModifyMemDBFile(CServiceBson& stBson, long long nTimestamp, LPFILE_MEMDBFILEINFOBSON lpDBFileBson);

	//系统维护操作函数----对象类
	int AddObject(CServiceBson& stBson, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp, LPOBJECTDEFBSON lpObject, LPCTSTR lpszObjectDBFilePath, LPCTSTR lpszIndexDBFilePath, LPCTSTR lpszKVDBFilePath);
	int DropObject(LPEXECUTEPLANBSON lpExecutePlan, LPCTSTR lpszObjectName);
	int AlterObjectAddField(CServiceBson& stBson, long long nTimestamp, LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson);
	int AlterObjectDropField(CServiceBson& stBson, long long nTimestamp, LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson);
	int AlterObjectAddIndex(CServiceBson& stBson, long long nTimestamp, LPFILE_INDEXDEFBSON lpAddIndexBson);
	int AlterObjectDropIndex(LPEXECUTEPLANBSON lpExecutePlan, int lObjectID, LPFILE_INDEXDEFBSON lpIndexBson);

	//系统维护操作函数----序列类
	int AddSequence(long long nTimestamp, LPCTSTR lpszName, long long nCurrentVal, int nIncrementBy = 1, long long nMinVal = 1, long long nMaxVal = 0X7FFFFFFFFFFFFFFF, BYTE bCycleFlag = 0, BYTE bCacheFlag = 20);
	int DropSequence(long long nTimestamp, LPCTSTR lpszName);
	
	//系统维护操作函数----用户类
	int AddUser(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp);
	int DropUser(char* pUserName, long long nTimestamp);
	int AlterUserChangePassword(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp);
	int AlterUserAddAuthority(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp);
	int AlterUserDropAuthority(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp);
	int AlterUserDisable(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp);
	int AlterUserEnable(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp);

	int GetMemoryFileInstance(BYTE bFileNo, IVirtualMemoryFile* &pVMF);
	int InitSysObject();
public:
	//用户常规操作函数----序列
	int GetSequenceNextVal(LPCTSTR lpszName, long long &nVal);
	int GetSequenceCurrentVal(LPCTSTR lpszName, long long &nVal);
	//判断序列是否存在
	BOOL CheckSequenctExit(LPCTSTR lpszName);
	//用户常规操作函数
	int GetObjectInfo(LPCTSTR lpszObjectName, LPOBJECTDEF &lpObjectInfo);
	int GetObjectInfo(int ObjectID, LPOBJECTDEF &lpObjectInfo);
	
	//查找对象
	BOOL FindObject(LPCTSTR lpszObjectName);

	int GetUserInfo(LPCTSTR lpszUserName, LPUSERINFODEF &lpUserInfoDef);
	int GetUserInfo(long long nUserID, LPUSERINFODEF &lpUserInfoDef);
	
	int GetAuthority(MF_AUTHORITY_ID bAuthorityID, LPAUTHORITYINFO &lpAuthority);
	int GetAuthority(LPCTSTR lpszAuthorityName, LPAUTHORITYINFO &lpAuthority);

	int GetIndexInfo(int IndexID, LPINDEXDEF &lpIndexInfo);

	int GetMemDBFileInfoByNo(BYTE bFileNo, LPMEMDBFILEDEF &lpMemDBFileDef);
	int GetMemDBFileInfo(LPCTSTR lpszFilePath, LPMEMDBFILEDEF &lpMemDBFileDef);
	int GetMemDBFileInfoByMem(LPCTSTR lpszMemFileName, LPMEMDBFILEDEF &lpMemDBFileDef);

	void SetSessionInfo(LPSESSIONINFO lpSessionInfo, BOOL bSaop);
	void RemoveSessionInfo(LPSESSIONINFO &lpSessionInfo, BOOL bSaop);
	//获取全局系统参数值
	int GetParameterValue(MF_PARAMETER_TYPE nParameterName);
	//设置全局系统参数值
	int SetParameterValue(MF_PARAMETER_TYPE nParameterName, int nParameterValue);
	//获取系统参数指针
	int GetSystemParameter(const char *pStr);

	//分配临时空间
	LPBYTE AllocTemporaryMem(UINT nSize);

	//分配临时空间
	void FreeTemporaryMem(LPBYTE lpBuf);

	//开始一个短事务锁
	int  StartTransactionLogic(DWORD dwIP, const char * lpszTransactionData, int &lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	//结束一个短事务锁
	int	 StopTransactionLogic(DWORD dwIP, int lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo);

	//将字段类型ID转换为字段类型字符串
	int ConvertTypeIDtoString(MF_SYS_FIELDTYPE bFieldType, char* &pType);

public:
	//系统操作日志类
	BOOL TraceLog(LPCSTR szFuncationName, LONG dwThreadID, DWORD dwLevel, DWORD dwErrorCode, LPCSTR szText);

	//数据修改类日志，可用于数据重演
	BOOL WriteLog(CServiceBson& stBson, CExecutePlanManager& stExecuteManager);

	BOOL ExecuteWrite(LPBYTE lpData, int nLen);

	//重做日志备份，用于集群同步时暂存重做日志
	BOOL WriteBackupRedo(CServiceBson& stBson, CExecutePlanManager& stExecuteManager);

	BOOL WriteBackupRedo(LPBYTE lpData, int nLen);

	BOOL InitBackupRedo(const char* lpFilePath);

	//添加每分钟执行信息统计
	BOOL SetWorkloadStatistics(long long llExecuteBeginTime, long long llExecuteEndTime, long long nExecuteTime, int nMinExecuteTime, int nMaxExecuteTime, int nQueryCount, int nUpdateCount);

	//添加SQL执行信息统计
	int SetExecuteStatistics(LPEXECUTESTATISTICSINFO lpExecuteInfo, LPEXECUTEPLANBSON lpExecutePlan);
	
	//获取系统DUAL表的信息
	int GetDualData(CServiceBson& stBson, CSysRecordContainer& stRecordContainer);

	//获取系统对象表的所有信息
	int GetVObjectData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer);

	//获取系统索引表的所有信息
	int GetVIndexData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer);
	
	//获取系统字段表的所有信息
	int GetVColumnData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer);

	//获取系统字段表的所有信息
	int GetVSequenceData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer);

	//获取系统文件表的所有信息
	int GetVDataFileData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer);

	//获取统计视图表的所有信息
	int GetVStatisticsData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer);

	//获取会话信息
	int GetVSessionData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer);

	//获取Soap服务信息
	int GetVSoapServerData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer);

	//获取用户信息
	int GetVUserData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer);

	//获取用户信息
	int GetVAuthority(CServiceBson &stBson, CSysRecordContainer& stRecordContainer);

	//负载信息
	int GetVWorkLoad(CServiceBson &stBson, CSysRecordContainer& stRecordContainer);

	//将数据写入回滚区
	long long InsertRollBackData(LPBYTE& lpData, int nLen, long long nTimestamp, long long nPreRollbackDataID);

	//获取回滚区数据
	int GetRollBackData(long long nRollBackVarDataID, long long nTimestamp, LPBYTE &lpVarDataAddr, int &nLen);

	//判断回滚区数据是否合法
	int CheckValidRollBackData(long long nRollBackVarDataID, long long nTimestamp);

	//字符串相关函数
	//初始化汉字拼音库
	void InitCharCompare(LPBYTE lpBuffer, int nSize);
	//两个字符串从开始进行比较，不处理%和_的匹配
	int CharCompare(const char * pSrc, int nSrcLen, const char * pDet, int nDesLen, BOOL bMatch);
	//子串查找，支持%和_的匹配处理
	int CharFind(const char *pSrc, const int nSrcLen, const char *pPat, const int nPatLen);
	
	//获取Session的数量
	int GetSeccionNum();

	//获取最新统计信息
	inline LPWORKLOADSTATISTICSINFO GetLatestWorkLoad()
	{
		return m_lpLatestWorkloadStatistics;
	}

	//获取文件路径
	void GetFilePath(MF_SYS_FILETYPE bFileType, LPCTSTR& lpFilePath);
public:
	//备份事务链表
	int SetTransactionLine(CServiceBson& stBson, long long nTimestamp, UINT& nTransactionOffset, int& nTransactionNum);
	//判断事务是否结束
	BOOL CheckTransactionFinish(long long nTimestamp);

	//判断是否还有活动事务
	BOOL CheckTransactionActive();

public:
	//给对象加锁
	BOOL SetObjectLock(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, BYTE bLockType, DWORD dwMilliseconds);
	//给块加锁
	int LockBlock(LPEXECUTEPLANBSON lpExecutePlan, LPBASEBLOCKHEAD lpBlockHead,  DWORD dwMilliseconds);
	//给对象加锁
 	int LockObject(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, int nBlockNum, LPBLOCKINFO lpBlockInfo, DWORD dwMilliseconds);
	
	//给对象上锁
	int LockObject(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, MF_LOCK_STATUS_TYPE bLockType, DWORD dwMilliseconds);
	
	//给索引加锁
	int LockIndex(LPEXECUTEPLANBSON lpExecutePlan, LPINDEXDEF lpIndexInfo, MF_LOCK_STATUS_TYPE bStatus, DWORD dwMilliseconds, long long nTimestamp);
	//给块解锁
	void UnLockBlock(LPEXECUTEPLANBSON lpExecutePlan, LPBASEBLOCKHEAD lpBlockHead);
	//给块加锁
	void UnLockBlock(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, int nBlockNum, LPBLOCKINFO lpBlockInfo);
	//给对象解锁
	void UnLockObject(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, int nBlockNum, LPBLOCKINFO lpBlockInfo);
	//给索引解锁
	void UnLockIndex(LPEXECUTEPLANBSON lpExecutePlan, LPINDEXDEF lpIndexInfo);
	
	//获取数据文件临界区
	CRITICAL_SECTION* GetDataFileCritical()
	{
		return &m_critDataFile;
	}	
	
	//获取数据文件块映射表临界区
	CRITICAL_SECTION* GetDataFileBlockMapCritical()
	{
		return &m_critDataFileBlockMap;
	}	

	//获取B树索引文件临界区
	CRITICAL_SECTION* GetBTreeFileCritical()
	{
		return &m_critBTreeFile;
	}	
	
	//获取B树索引文件块映射表临界区
	CRITICAL_SECTION* GetBTreeFileBlockMapCritical()
	{
		return &m_critBTreeFileBlockMap;
	}	
	
	//获取B树索引根节点临界区
	CRITICAL_SECTION* GetBTreeRootCritical()
	{
		return &m_critBTreeRoot;
	}	
	
	//获取KV索引文件临界区
	CRITICAL_SECTION* GetKVFileCritical()
	{
		return &m_critKVFile;
	}	

	//获取KV索引文件块映射表临界区
	CRITICAL_SECTION* GetKVFileHashTableCritical()
	{
		return &m_critKVFileHashTable;
	}	

	//获取KV索引根节点临界区
	CRITICAL_SECTION* GetKVRootCritical()
	{
		return &m_critKVRoot;
	}

	//获取KV索引根节点临界区
	CRITICAL_SECTION* GetPreprocessCritical()
	{
		return &m_critPreprocess;
	}

	//获取块临界区
	CRITICAL_SECTION* GetBlockCritical()
	{
		return &m_critBlock;
	}

public:
	//获取对象映射表
	CMapSimple* GetObjectMap()
	{
		return &m_mapObject;
	}

public:
	//闪回
	int  FlashBack(BYTE bFileNo, int nBlockNo, LPBYTE& lpBuffer, long long nTimestamp);
public:
	int  Paging(long long nBufferNo, CDataIDContainer* pDataIDContainer, int nPageDataNum);
	int  GetPage(long long nBufferNo, int nPageNo, int nPageDataNum, CDataIDContainer* pDataIDContainer);

public:
	int GetRedoLogMaxID()
	{
		return m_pMemoryFileHead->m_nRedoLogMaxID;
	}

	//清理数据文件
	void ClearDataFile();
};


