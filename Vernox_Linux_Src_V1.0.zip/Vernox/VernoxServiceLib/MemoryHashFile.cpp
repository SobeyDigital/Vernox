﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryFile.h"
#include "MemoryHashFile.h"
#include "MemoryHashIndex.h"
#include "MemoryHashInt.h"
#include "MemoryHashChar.h"
#include "Expression.h"
#include "Check.h"
#define DEF_HASHBLOCK_SIZE (256*1024)

CMemoryHashFile::CMemoryHashFile(void)
{
	
}


CMemoryHashFile::~CMemoryHashFile(void)
{
}

/************************************************************************
		功能说明：
			初始化哈希文件管理类，让整个实例是可执行的
		参数说明：
			pFileAddr：内存文件数据块的首地址指针，需要记录在m_pFileAddr变量中
		特别说明：
			同时还需要把m_lpHashFileHead成员变量也初始化出来，便于后续的写入和读取操作；
			注意，对于新内存文件是由另一个进程来实现的。
************************************************************************/
int CMemoryHashFile::SetFileAddr(LPBYTE lpFileAddr)
{
	UINT nMaxBlockMapNum, nBlockMapSize;
	LPBASEFILEBLOCKMAPHEAD lpBlockMapHead;
	long long nFileFreeSize, nBlockMapOffset;
	int i, nBlockNo, nFileHeadSize, nBlockMapStructSize;

	m_lpFileAddr = lpFileAddr;									//初始化文件首地址指针
	m_lpMemoryFileHead = (LPFILEHEAD)m_lpFileAddr;				//获得文件头指针

	//判断映射表是否为空，如果不为空则遍历映射表创建CMap对象
	if(m_lpMemoryFileHead->m_nBlockMapStartOffset == 0)
	{
		nFileHeadSize		= (sizeof(FILEHEAD) / DEF_HASHBLOCK_SIZE + 1) * DEF_HASHBLOCK_SIZE;
		nBlockMapStructSize = sizeof(BASEFILEBLOCKMAP);
		nMaxBlockMapNum		= (int)(m_lpMemoryFileHead->m_nFileTotalSize - DEF_HASHBLOCK_SIZE) / DEF_HASHBLOCK_SIZE;
		nBlockMapSize		= nMaxBlockMapNum * nBlockMapStructSize;
		nBlockMapSize		= ((sizeof(BASEFILEBLOCKMAPHEAD) + nBlockMapSize) / DEF_HASHBLOCK_SIZE + 1) * DEF_HASHBLOCK_SIZE;
		nFileFreeSize		= m_lpMemoryFileHead->m_nFileTotalSize - nFileHeadSize - nBlockMapSize * 2;			//主备两张表

		m_mapIndex.Initialize(nMaxBlockMapNum);

		lpBlockMapHead								= (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + nFileHeadSize);
		lpBlockMapHead->m_nBlockMapNum				= 0;
		lpBlockMapHead->m_nNextBlockMapOffset		= 0;
		m_lpBlockMapTail							= lpBlockMapHead;
		
		m_lpMemoryFileHead->m_nBlockNum				= 0;
		m_lpMemoryFileHead->m_nFreeBlockMapOffset	= 0;						
		m_lpMemoryFileHead->m_nInnerMaxNo			= 1;
		m_lpMemoryFileHead->m_nTimestamp			= GetSystemTimestamp();
		m_lpMemoryFileHead->m_nFileHeaderSize		= nFileHeadSize;
		m_lpMemoryFileHead->m_nBlockMapStructSize	= nBlockMapStructSize;
		m_lpMemoryFileHead->m_nFileFreeSize			= nFileFreeSize;
		m_lpMemoryFileHead->m_nBlockMapSize		    = nBlockMapSize;
		m_lpMemoryFileHead->m_nMaxBlockMapNum		= nMaxBlockMapNum;
		m_lpMemoryFileHead->m_nBlockMapStartOffset  = nFileHeadSize;
		m_lpMemoryFileHead->m_nFileFreeMemoryOffset	= nFileHeadSize + nBlockMapSize * 2;
		m_lpMemoryFileHead->m_nBlockStartOffset		= nFileHeadSize + nBlockMapSize * 2;
	}
	else
	{
		//遍历映射表创建CMap对象
		//注意：1.映射表表项的总个数=块的总个数 
		//		2.映射表表项按照块分配的先后顺序有序存放
		m_mapIndex.Initialize(m_lpMemoryFileHead->m_nMaxBlockMapNum);
		nBlockMapOffset = m_lpMemoryFileHead->m_nBlockMapStartOffset;
		while(nBlockMapOffset)
		{
			lpBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + nBlockMapOffset);
			for(i = 0; i < lpBlockMapHead->m_nBlockMapNum; i++)
			{
				nBlockNo = lpBlockMapHead->m_pBlockMap[i].m_nBlockNo;
				m_mapIndex.Set(nBlockNo, m_lpFileAddr + lpBlockMapHead->m_pBlockMap[i].m_nBlockOffset);
			}
			nBlockMapOffset = lpBlockMapHead->m_nNextBlockMapOffset;
		}
		m_lpBlockMapTail = lpBlockMapHead;
	}

	return MF_OK;
}

/************************************************************************
		功能说明：
			从空闲区队列中分配一块内存空间
		参数说明：
			lpExecutePlan：执行计划
			nBlockNo:块编号
			nObjdectID:ObjectID
			nBlockSize:内存块大小
			nTimestamp：时间戳
		特别说明:
			分配的内存空间可能用于插入新的索引项，也可能会用于创建HashTable
		分配步骤：
			分配步骤：
			1.从文件级的空块链表栈中寻找是否具有合适的空块，如果有则从空块链表栈中分配一个空块
			2.如果空块链表栈中没有合适的块，则从空闲区中分配
************************************************************************/
int CMemoryHashFile::AllocBlock(LPEXECUTEPLANBSON lpExecutePlan, int& nBlockNo, int nObjdectID, int nBlockSize, long long nTimestamp)
{
	long long nFreeBlockOffset;
	LPBASEFILEBLOCKMAP lpBlockMap;
	int nRet, nBlockMapPos, nBlockMapSize;
  	
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetKVFileCritical(), lpExecutePlan);
	//1.从文件级的空块链表栈中寻找是否具有合适的空块，如果有则从空块链表栈中分配一个空块
  	if(m_lpMemoryFileHead->m_nFreeBlockMapOffset && nBlockSize == DEF_HASHBLOCK_SIZE)
  	{
  		lpBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + m_lpMemoryFileHead->m_nFreeBlockMapOffset);		
  		m_lpMemoryFileHead->m_nFreeBlockMapOffset = lpBlockMap->m_nNextOffset;					
  		nBlockNo = lpBlockMap->m_nBlockNo;
		//初始化新块块头
		nRet = InitialBlock(nBlockNo, nBlockSize, nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		return MF_OK;																	
  	}	

	//2.如果空块链表栈中没有合适的块，则从空闲区中分配
	if(m_lpMemoryFileHead->m_nFileFreeSize <= nBlockSize || m_lpMemoryFileHead->m_nFileFreeMemoryOffset + nBlockSize > m_lpMemoryFileHead->m_nFileTotalSize)
	{
		return MF_KVINDEX_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;										//如果空间不足返回
	}
	else
	{
		//如果有空闲空间，则从空闲区中分配一个块
		nFreeBlockOffset = m_lpMemoryFileHead->m_nFileFreeMemoryOffset;							//记录新分配的空块的偏移
		m_lpMemoryFileHead->m_nFileFreeMemoryOffset += nBlockSize;								//修改空闲区首地址偏移(注意：块是从后往前分配的)		
		m_lpMemoryFileHead->m_nFileFreeSize -= nBlockSize;										//修改空闲区大小

		//为映射表结点赋值
		nBlockNo = m_lpMemoryFileHead->m_nInnerMaxNo;
		nBlockMapPos = m_lpBlockMapTail->m_nBlockMapNum;
		m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nBlockNo		= nBlockNo;
		m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nBlockOffset	= nFreeBlockOffset;
		m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nNextOffset	= 0;
		m_lpBlockMapTail->m_nBlockMapNum++;
		
		//分配了新块之后，需要将这个块加入m_mapMemoryBlock
		m_mapIndex.Set(nBlockNo, m_lpFileAddr + nFreeBlockOffset);
		m_lpMemoryFileHead->m_nInnerMaxNo++;			//递增最大块号
		m_lpMemoryFileHead->m_nBlockNum++;				//递增块个数
	
		//初始化新块块头
		nRet = InitialBlock(nBlockNo, nBlockSize, nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	
	//3.判断映射表中是否还可以插入结点
	if(m_lpBlockMapTail->m_nBlockMapNum >= m_lpMemoryFileHead->m_nMaxBlockMapNum)
	{
		nBlockMapSize = m_lpMemoryFileHead->m_nBlockMapSize;
		//此时说明映射表空间不足,则需要在文件中分配一个块映射表
		if(m_lpMemoryFileHead->m_nFileFreeSize <= nBlockMapSize || m_lpMemoryFileHead->m_nFileFreeMemoryOffset + nBlockMapSize > m_lpMemoryFileHead->m_nFileTotalSize)
		{
			//说明该内存文件已经没有空间进行块的移动，块满
			return MF_BTREEINDEX_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;						    
		}
		m_lpBlockMapTail->m_nNextBlockMapOffset		= m_lpMemoryFileHead->m_nFileFreeMemoryOffset;
		m_lpMemoryFileHead->m_nFileFreeSize			-= nBlockMapSize;							
		m_lpMemoryFileHead->m_nFileFreeMemoryOffset += nBlockMapSize;
		m_lpBlockMapTail	= (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset);
		memset(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset, 0, nBlockMapSize);	 
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			释放内存块(清空),并把块号添加到空块队列中
		参数说明：
			lpExecutePlan：执行计划
			nBlockNo:内存块编号
			nTimestamp：时间戳
************************************************************************/
int CMemoryHashFile::FreeBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo, long long nTimestamp)
{	
	LPBASEBLOCKHEAD lpBlockHead;
	LPBASEFILEBLOCKMAP lpFreeBlockMap;
	LPBASEFILEBLOCKMAPHEAD lpFreeBlockMapHead;
	int i, nBlockNum, nBlockMapPos, nBlockMapSize;
	long long nBlockMapHeadOffset, nBlockMapOffset, nBlockOffset;

	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetKVFileCritical(), lpExecutePlan);
	//1.找到nBlockNo所在的结点映射表
	lpFreeBlockMap		= NULL;
	nBlockMapHeadOffset = m_lpMemoryFileHead->m_nBlockMapStartOffset;
	while(nBlockMapHeadOffset)
	{
		lpFreeBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + nBlockMapHeadOffset);
		for(i = 0; i < lpFreeBlockMapHead->m_nBlockMapNum; i++)
		{
			if(lpFreeBlockMapHead->m_pBlockMap[i].m_nBlockNo == nBlockNo)
			{
				lpFreeBlockMap  = &lpFreeBlockMapHead->m_pBlockMap[i];
				nBlockMapOffset = (LPBYTE)lpFreeBlockMap - m_lpFileAddr;
				break;
			}
		}
		if(lpFreeBlockMap == NULL)
		{
			nBlockMapHeadOffset = lpFreeBlockMapHead->m_nNextBlockMapOffset;
		}
		else
		{
			break;
		}
	}
	
	//2.计算当前需要回收的块相当于多少个大小为DEF_HASHBLOCK_SIZE的基本块
	lpBlockHead = (LPBASEBLOCKHEAD)ConvertBlockNotoAddr(nBlockNo);
	if(lpBlockHead == NULL)
	{
		return MF_FAILED;
	}
	nBlockOffset = (LPBYTE)lpBlockHead - m_lpFileAddr;	
	nBlockNum    = lpBlockHead->m_nBlockSize / DEF_HASHBLOCK_SIZE;
	
	//3.回收快
	for(i = 0; i < nBlockNum; i++)
	{
		if(i != 0)
		{
			//为拆分后的新数据块创建映射结点
			nBlockNo		= m_lpMemoryFileHead->m_nInnerMaxNo;
			nBlockMapPos	= m_lpBlockMapTail->m_nBlockMapNum;
			lpFreeBlockMap	= &m_lpBlockMapTail->m_pBlockMap[nBlockMapPos];
			lpFreeBlockMap->m_nBlockNo = nBlockNo;
			lpFreeBlockMap->m_nBlockOffset = nBlockOffset;
			lpFreeBlockMap->m_nNextOffset = 0;

			//分配了新块之后，需要将这个块加入m_mapMemoryBlock
			m_mapIndex.Set(nBlockNo, m_lpFileAddr + nBlockOffset);
			m_lpBlockMapTail->m_nBlockMapNum++;
			m_lpMemoryFileHead->m_nInnerMaxNo++;				//递增最大块号
			m_lpMemoryFileHead->m_nBlockNum++;					//递增块个数
		
			nBlockMapOffset = (LPBYTE)lpFreeBlockMap - m_lpFileAddr;
			InitialBlock(nBlockNo, DEF_HASHBLOCK_SIZE, nTimestamp);
			
			//判断映射表中是否还可以插入结点
			if(m_lpBlockMapTail->m_nBlockMapNum >= m_lpMemoryFileHead->m_nMaxBlockMapNum)
			{
				nBlockMapSize = m_lpMemoryFileHead->m_nBlockMapSize;
				if(m_lpMemoryFileHead->m_nFileFreeSize <= nBlockMapSize || m_lpMemoryFileHead->m_nFileFreeMemoryOffset + nBlockMapSize > m_lpMemoryFileHead->m_nFileTotalSize)
				{
					return MF_BTREEINDEX_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;						    
				}
				m_lpBlockMapTail->m_nNextBlockMapOffset = m_lpMemoryFileHead->m_nFileFreeMemoryOffset;
				m_lpMemoryFileHead->m_nFileFreeSize -= nBlockMapSize;							
				m_lpMemoryFileHead->m_nFileFreeMemoryOffset += nBlockMapSize;
				m_lpBlockMapTail	= (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset);
				memset(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset, 0, nBlockMapSize);	 
			}
		}
		else
		{
			//重置原始块大小
			InitialBlock(nBlockNo, DEF_HASHBLOCK_SIZE, nTimestamp);
		}
		//将该内存块对应的映射表结点放入空块链表(插头法)
		lpFreeBlockMap->m_nNextOffset = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
		m_lpMemoryFileHead->m_nFreeBlockMapOffset = nBlockMapOffset;

		nBlockOffset +=  DEF_HASHBLOCK_SIZE;
	}
	m_lpMemoryFileHead->m_nTimestamp = nTimestamp;
	return MF_OK;
}

/************************************************************************
		功能说明：
			修改根结点
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			nBlockNo：新根节点的块号
************************************************************************/
int CMemoryHashFile::RootUpdate(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nBlockNo)
{
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetKVRootCritical(), lpExecutePlan);
	//在m_RootMap中寻找nIndexID对应的Root结构体
	for(int i = 0; i< MAX_OBJECT_NUM; i++)
	{
		if(nIndexID == m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID)
		{
			 m_lpMemoryFileHead->m_stRootMap[i].m_nBlockNo = nBlockNo;
			 return MF_OK;
		}
	}
	return MF_KVINDEX_INVALIDBLOCKNO_ERROR;
}
/************************************************************************
		功能说明：
			删除根结点
		参数说明：
			nIndexID：索引ID
************************************************************************/
int CMemoryHashFile::RootDelete(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID)
{
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetKVRootCritical(), lpExecutePlan);
	//在m_RootMap中寻找nIndexID对应的Root结构体
	for(int i = 0; i< MAX_OBJECT_NUM; i++)
	{
		if(nIndexID == m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID)
		{
			m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID = 0;
			m_lpMemoryFileHead->m_stRootMap[i].m_nBlockNo = 0;
			return MF_OK;
		}
	}
	return MF_KVINDEX_INVALIDBLOCKNO_ERROR;
}

/************************************************************************
		功能说明：
			获得根节点
		参数说明：
			lpExecutePlan：执行计划
			nRootNo：根结点块号
			nIndexID：索引ID
************************************************************************/
int CMemoryHashFile::GetRootNo(LPEXECUTEPLANBSON lpExecutePlan, int& nRootNo, int nIndexID)
{
	int i;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetKVRootCritical(), lpExecutePlan);
	//根据nIndexID值在ROOT中找到索引的根结点块号
	nRootNo = 0;
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID == nIndexID)
		{
			nRootNo = m_lpMemoryFileHead->m_stRootMap[i].m_nBlockNo;	
			return MF_OK;
		}
	}
	return MF_BTREEINDEX_INVALIDINXEXID_ERROR;
}

/************************************************************************
		功能说明：
			初始化块头基础信息
		参数说明：
			nBlockNo：块编号
			nBlockSize：块大小
			nTimestamp：时间戳
************************************************************************/
int CMemoryHashFile::InitialBlock(int nBlockNo, int nBlockSize, long long nTimestamp)
{
	LPBYTE pBlock;
	LPBASEBLOCKHEAD lpBaseBlockHead;

	pBlock = ConvertBlockNotoAddr(nBlockNo);
	if(pBlock == NULL)
	{
		return MF_KVINDEX_INVALIDBLOCKNO_ERROR;
	}
	memset(pBlock, 0, nBlockSize);

	lpBaseBlockHead = (LPBASEBLOCKHEAD)pBlock;
	lpBaseBlockHead->m_nDataFlag	= MAKEHEADFLAG('S','B','D','B');
	lpBaseBlockHead->m_nBlockNo		= nBlockNo;
	lpBaseBlockHead->m_nTimestamp	= nTimestamp;
	lpBaseBlockHead->m_nBlockSize	= nBlockSize;	
	lpBaseBlockHead->m_bStatus		= 0;
	lpBaseBlockHead->m_bFileNo		= m_lpMemoryFileHead->m_bFileNo;
	lpBaseBlockHead->m_bSaveFlag	= 0;
	lpBaseBlockHead->m_bThreadNum	= 0;

	return MF_OK;
}
/************************************************************************
	功能说明：
		初始化哈希表头
	参数说明：
		lpExecutePlan：执行计划
		nIndexID：索引ID
		nKeyLen：关键字长度
************************************************************************/
int CMemoryHashFile::InitialHashBlock(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nKeyLen)
{
	LPBYTE lpRoot;
	int nRet, nRootNo;
	CMemoryHashIndex stHashIndex;
	
	//根据nIndexID在Root数组中找到哈希表的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	lpRoot = ConvertBlockNotoAddr(nRootNo);
	if(NULL == lpRoot)
	{
		return MF_KVINDEX_INVALIDROOTNO_ERROR;		//没有找到ROOTNO对应的根节点
	}

	//创建CMmemroyHashIndex对象，并调用InsertIndex进行插入操作
	stHashIndex.SetHashTableAddr(lpRoot, nIndexID, this);
	stHashIndex.InitialHashBlock(NULL, nKeyLen);
	
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取Hash索引节点大小
	参数说明：
		bFieldType：字段类型
		bDataLen：定长字段长度
************************************************************************/
int CMemoryHashFile::GetHashIndexNodeSize(BYTE bFieldType, BYTE bDataLen)
{
	int nLen;
	if(bFieldType == MF_SYS_FIELDTYPE_CHAR)
	{
		nLen = 2*sizeof(long long) + sizeof(int) + bDataLen;
	}
	else
	{
		nLen = 3*sizeof(long long);
	}	
	return nLen;
}	

/************************************************************************
		功能说明：
			根据块号获得块在内存中的实际地址
		参数说明：
			nBlockNo:块号
		返回值说明：
			转换出来的地址，如果为NULL表示转换失败
************************************************************************/
LPBYTE CMemoryHashFile::ConvertBlockNotoAddr(int nBlockNo)
{
	LPBYTE pBlock;								
	pBlock = (LPBYTE)m_mapIndex.Get(nBlockNo);

	return pBlock;
}

/************************************************************************
		功能说明：
			获取HB树根节点DataID
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			nDataID:根节点DataID
************************************************************************/
int CMemoryHashFile::GetHBTreeRoot(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, long long& nDataID)
{
	LPBYTE lpRoot;
	int nRet, nRootNo;
	CMemoryHashIndex stHashIndex;
	
	//根据nIndexID在Root数组中找到哈希表的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	lpRoot = ConvertBlockNotoAddr(nRootNo);
	if(NULL == lpRoot)
	{
		return MF_KVINDEX_INVALIDROOTNO_ERROR;		//没有找到ROOTNO对应的根节点
	}

	//创建CMmemroyHashIndex对象，并调用InsertIndex进行插入操作
	stHashIndex.SetHashTableAddr(lpRoot, nIndexID, this);
	nDataID = stHashIndex.GetHBTreeRoot(lpExecutePlan);
	
	return MF_OK;
}

/************************************************************************
	功能说明：
		设置HB树根节点DataID
	参数说明：
		nIndexID：索引ID
		nDataID：根节点数据ID
		nTimestamp：时间戳
************************************************************************/
int CMemoryHashFile::SetHBTreeRoot(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, long long nDataID)
{
	LPBYTE pRoot;
	int nRet, nRootNo;
	CMemoryHashIndex stHashIndex;
	
	//根据nIndexID在Root数组中找到哈希表的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	pRoot = ConvertBlockNotoAddr(nRootNo);
	if(NULL == pRoot)
	{
		return MF_KVINDEX_INVALIDROOTNO_ERROR;		//没有找到ROOTNO对应的根节点
	}

	//创建CMmemroyHashIndex对象，并调用InsertIndex进行插入操作
	stHashIndex.SetHashTableAddr(pRoot, nIndexID, this);
	stHashIndex.SetHBTreeRoot(lpExecutePlan, nDataID, lpExecutePlan->m_nTimestamp);

	return MF_OK;
}

/************************************************************************
		功能说明：
			创建根节点
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			nHashNodeSize：Hash节点大小
			nRootNo：根节点编号
			nTimestamp：时间戳
************************************************************************/
int CMemoryHashFile::CreateRoot(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nHashNodeSize, int& nRootNo, long long nTimestamp)
{
	int i, nRet;
	LPBYTE lpRoot;
	CMemoryHashIndex stHashIndex;

	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetKVRootCritical(), lpExecutePlan);
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID == 0)
		{
			m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID = nIndexID;
			nRet = AllocBlock(lpExecutePlan, nRootNo, nIndexID, DEF_HASHBLOCK_SIZE, nTimestamp);				//为该Object创建一个根结点
			if(nRet != MF_OK)
			{
				return nRet;
			}
			m_lpMemoryFileHead->m_stRootMap[i].m_nBlockNo = nRootNo;
			
			lpRoot = ConvertBlockNotoAddr(nRootNo);
			if(NULL == lpRoot)
			{
				return MF_KVINDEX_INVALIDROOTNO_ERROR;		//没有找到ROOTNO对应的根节点
			}

			//创建CMmemroyHashIndex对象，并调用InsertIndex进行插入操作
			stHashIndex.SetHashTableAddr(lpRoot, nIndexID, this);
			stHashIndex.InitialHashBlock(NULL, nHashNodeSize);
			return MF_OK;
		}
	}
	return MF_COMMON_MAX_INDEX;
}
/************************************************************************
		功能说明：
			根据key值在索引块中插入一个新的索引项
		参数说明：
			lpIndexInfo:索引信息
			nObjectID：对象ID
			lpExecutePlan：执行计划
			nTimestamp：时间戳
		特别说明:
			根据nIndexID值在ROOT中找到哈希表的入口地址，然后调用哈希类的相关函数进行插入
************************************************************************/
int CMemoryHashFile::InsertIndex(LPINDEXINFO lpIndexInfo, int nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	LPBYTE pRoot;
	BYTE bFieldNo;
	LPOBJECTDEF lpObjectInfo;
	int nRet, nRootNo, nHashIndexNodeSize;

	nRet = CSystemManage::instance().GetObjectInfo(nObjectID, lpObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	//根据nIndexID在Root数组中找到哈希表的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, lpIndexInfo->m_nIndexID);
	if(nRet == MF_BTREEINDEX_INVALIDINXEXID_ERROR)
	{
		//创建跟节点
		bFieldNo = lpIndexInfo->m_bFieldNo[0];
		nHashIndexNodeSize = GetHashIndexNodeSize(lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType, lpObjectInfo->m_lpField[bFieldNo - 1].m_bCharLen + 1);
		nRet = CreateRoot(lpExecutePlan, lpIndexInfo->m_nIndexID, nHashIndexNodeSize, nRootNo, nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	pRoot = ConvertBlockNotoAddr(nRootNo);
	if(NULL == pRoot)
	{
		//没有找到ROOTNO对应的根节点
		return MF_KVINDEX_INVALIDROOTNO_ERROR;		
	}
	switch(lpIndexInfo->m_bIndexType)
	{
	case MF_SYS_INDEXTYPE_KV_INT:
	case MF_SYS_INDEXTYPE_KV_BIGINT:
	case MF_SYS_INDEXTYPE_HB_INT:
		{
			CMemoryHashInt stHashIndex;
			stHashIndex.SetHashTableAddr(pRoot, lpIndexInfo->m_nIndexID, this);
			nRet = stHashIndex.InsertIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	case MF_SYS_INDEXTYPE_KV_CHAR:
	case MF_SYS_INDEXTYPE_HB_CHAR:
		{
			CMemoryHashChar stHashIndex;
			stHashIndex.SetHashTableAddr(pRoot, lpIndexInfo->m_nIndexID, this);
			nRet = stHashIndex.InsertIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	default:
		return MF_KVINDEX_INVALIDINDEXTYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			根据key值在索引块中删除一个新的索引项
		参数说明：
			lpIndexInfo:索引信息
			nObjectID：对象ID
			lpExecutePlan：执行计划
			nTimestamp:时间戳
		特别说明:
			根据nIndexID值在ROOT中找到哈希表的入口地址，然后调用哈希类的相关函数进行删除
************************************************************************/
int CMemoryHashFile::DeleteIndex(LPINDEXINFO lpIndexInfo,LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	LPBYTE pRoot;
	int nRet, nRootNo;

	//根据nIndexID在Root数组中找到哈希表的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, lpIndexInfo->m_nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pRoot = ConvertBlockNotoAddr(nRootNo);
	if(NULL == pRoot)
	{
		//没有找到ROOTNO对应的根节点
		return MF_KVINDEX_INVALIDROOTNO_ERROR;		
	}
	switch(lpIndexInfo->m_bIndexType)
	{
	case MF_SYS_INDEXTYPE_KV_INT:
	case MF_SYS_INDEXTYPE_KV_BIGINT:
	case MF_SYS_INDEXTYPE_HB_INT:
		{
			CMemoryHashInt stHashIndex;
			stHashIndex.SetHashTableAddr(pRoot, lpIndexInfo->m_nIndexID, this);
			nRet = stHashIndex.DeleteIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	case MF_SYS_INDEXTYPE_KV_CHAR:
	case MF_SYS_INDEXTYPE_HB_CHAR:
		{
			CMemoryHashChar stHashIndex;
			stHashIndex.SetHashTableAddr(pRoot, lpIndexInfo->m_nIndexID, this);
			nRet = stHashIndex.DeleteIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	default:
		return MF_KVINDEX_INVALIDINDEXTYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		根据key值在索引块中更新一条索引项
	参数列表：
		lpIndexInfo:索引信息
		nObjectID：对象ID
		lpExecutePlan：执行计划
		nTimestamp:时间戳
	特别说明：
		关于pOldKeyType参数：因为可能会出现对于空字段的更新操作，所以如果字段为空就不能进行删除操作
************************************************************************/
int CMemoryHashFile::UpdateIndex(LPINDEXINFO lpIndexInfo, int nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	int nRet;
	if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_vt != MF_SYS_FIELDTYPE_NULL)
	{
		nRet = DeleteIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_vt != MF_SYS_FIELDTYPE_NULL)
	{
		nRet = InsertIndex(lpIndexInfo, nObjectID, lpExecutePlan, nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			根据关键字，获取数据ID
		参数说明：
			lpIndexInfo:索引信息
			pDataIDContainer:DataID容器
		返回值说明:
			如果找到对应的key则返回其数据ID，否则返回0
		特别说明：
			根据nIndexID值在ROOT中找到哈希表的入口地址，然后调用哈希类的相关函数进行查询
************************************************************************/
int CMemoryHashFile::GetDataID(LPINDEXINFO lpIndexInfo, CDataIDContainer* pDataIDContainer)
{
	LPBYTE pRoot;
	int nRet, nRootNo;
	LPINDEXDEF lpIndex;
	LPEXECUTEPLANBSON lpExecutePlan;
	CSystemLockStateManage stIndexLock;
	
	lpExecutePlan = (LPEXECUTEPLANBSON)lpIndexInfo->m_pBson->GetBuffer();
	
	//给索引加锁
	nRet = CSystemManage::instance().GetIndexInfo(lpIndexInfo->m_nIndexID, lpIndex);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	stIndexLock.Inital(MF_LOCK_INDEX, lpExecutePlan, lpIndex);
	nRet = stIndexLock.Lock(MF_LOCK_STATUS_MUTEX, MF_LOCK_OUTOFTIME, lpExecutePlan->m_nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//根据nIndexID在Root数组中找到哈希表的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, lpIndexInfo->m_nIndexID);
	if(nRet == MF_KVINDEX_INVALIDBLOCKNO_ERROR)
	{
		return MF_OK;
	}
	else if(nRet != MF_OK)
	{
		return nRet;
	}
	pRoot = ConvertBlockNotoAddr(nRootNo);
	if(NULL == pRoot)
	{
		return MF_KVINDEX_INVALIDROOTNO_ERROR;		//没有找到ROOTNO对应的根节点
	}
	
	switch(lpIndexInfo->m_bIndexType)
	{
	case MF_SYS_INDEXTYPE_KV_BIGINT:
	case MF_SYS_INDEXTYPE_KV_INT:
	case MF_SYS_INDEXTYPE_HB_INT:
		{
			CMemoryHashInt stHashIndex;
			stHashIndex.SetHashTableAddr(pRoot, lpIndexInfo->m_nIndexID, this);
			nRet = stHashIndex.GetDataID(lpIndexInfo, pDataIDContainer);
		}
		break;
	case MF_SYS_INDEXTYPE_KV_CHAR:
	case MF_SYS_INDEXTYPE_HB_CHAR:
		{
			CMemoryHashChar stHashIndex;
			stHashIndex.SetHashTableAddr(pRoot, lpIndexInfo->m_nIndexID, this);
			nRet = stHashIndex.GetDataID(lpIndexInfo, pDataIDContainer);
		}
		break;
	default:
		return MF_KVINDEX_INVALIDINDEXTYPE_ERROR;
	}
	return MF_OK;
}	

/************************************************************************
		功能说明：
			为某字段创建索引
		参数说明：
			nIndexID：对象ID
			nIndexID：索引ID
			nFieldNo：字段编号
************************************************************************/	
int CMemoryHashFile::CreateIndex(CServiceBson& stBson, int nObjectID, int nIndexID, BYTE bFieldNo)
{
	Check stCheck;
	BYTE bLinkType;
	VARDATA varData;
	long long nDataID;
	CMemoryFile* pFile;
	INDEXINFO stIndexInfo;
	QUERYINFO stQueryInfo;
	LPINDEXDEF lpIndexInfo;
	LPOBJECTDEF lpObjectInfo;
	CExpression stExpression;
	RECORDDATAINFO stRecordInfo;
	LPEXECUTEPLANBSON lpExecutePlan;
	IVirtualMemoryFile* pIVirtualMemoryFile;
	long long* lpTransactionArray, nBlockMapOffset;
	int nRet, nRootNo, nHashIndexNodeSize, nInnerDataNo;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpTransactionArray = (long long*)stBson.GetPtrFromTempBuffer(lpExecutePlan->m_nTransactionOffset);
	TRANSACTIONARRAY stTransactionArray(lpExecutePlan->m_nTransactionNum, lpTransactionArray);

	lpObjectInfo  = stBson.GetObjectInfo();
	nRet = CSystemManage::instance().GetIndexInfo(nIndexID, lpIndexInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	while(lpIndexInfo)
	{
		if(bFieldNo == lpIndexInfo->m_bFieldNo[0])
		{
			break;
		}
		lpIndexInfo = lpIndexInfo->m_pNext;
	}
	
	//1.创建根结点
	nHashIndexNodeSize = GetHashIndexNodeSize(lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType, lpObjectInfo->m_lpField[bFieldNo - 1].m_bCharLen + 1);
	nRet = CreateRoot(lpExecutePlan, lpIndexInfo->m_nIndexID, nHashIndexNodeSize, nRootNo, lpExecutePlan->m_nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//2.根据ObjectID对相应的表进行全表遍历
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pIVirtualMemoryFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pIVirtualMemoryFile;

	stQueryInfo.m_nTimestamp			= lpExecutePlan->m_nTimestamp;
	stQueryInfo.m_lpObjectInfo			= lpObjectInfo;
	stQueryInfo.m_lpTransactionArray	= &stTransactionArray;
	
	bLinkType		= 0;
	nBlockMapOffset = 0;
	nInnerDataNo	= 0;
	stCheck.Initial(&stBson, &stQueryInfo);
	stExpression.Initial(&stBson, lpObjectInfo);

	stRecordInfo.m_nTimestamp         = lpExecutePlan->m_nTimestamp;
	stRecordInfo.m_lpTransactionArray = &stTransactionArray;
	//2.全表遍历获取记录并创建索引
	while(TRUE)
	{
		nRet = pFile->GetNextDataID(lpExecutePlan, lpObjectInfo->m_nObjectID, FALSE, bLinkType, nBlockMapOffset, nInnerDataNo, nDataID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(nDataID == 0)
		{
			break;
		}
		if(stCheck.CheckRecordValid(nDataID))
		{
			stRecordInfo.m_nDataID	= nDataID;
			nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(stRecordInfo.m_lpRecordBuffer == NULL)
			{
				continue;
			}
			nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varData);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			//插入索引项
			stIndexInfo.m_pBson      = &stBson;
			stIndexInfo.m_bIndexType = lpIndexInfo->m_bIndexType;
			stIndexInfo.m_nIndexID   = nIndexID;
			stIndexInfo.m_nDataID    = nDataID;
			stIndexInfo.m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.SetData(varData); 
			nRet = InsertIndex(&stIndexInfo, lpExecutePlan->m_nObjectID, lpExecutePlan, lpExecutePlan->m_nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}

	return MF_OK;
}

/************************************************************************
		功能说明：
			删除索引
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
************************************************************************/
int CMemoryHashFile::DropObject(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID)
{
	LPBYTE pRoot;
	int nRet, nRootNo;
	LPINDEXDEF lpIndexInfo;
	
	//根据nIndexID在Root数组中找到哈希表的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pRoot = ConvertBlockNotoAddr(nRootNo);
	if(NULL == pRoot)
	{
		return MF_KVINDEX_INVALIDROOTNO_ERROR;		//没有找到ROOTNO对应的根节点
	}

	nRet = CSystemManage::instance().GetIndexInfo(nIndexID, lpIndexInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(lpIndexInfo->m_bIndexType == MF_SYS_INDEXTYPE_KV_INT || lpIndexInfo->m_bIndexType == MF_SYS_INDEXTYPE_KV_BIGINT)
	{	
		CMemoryHashInt stHashIndex;
		stHashIndex.SetHashTableAddr(pRoot,nIndexID,this);
		stHashIndex.DropObject(lpExecutePlan, nIndexID, lpExecutePlan->m_nTimestamp);	
		RootDelete(lpExecutePlan, nIndexID);		//删根节点
	}
	else if(lpIndexInfo->m_bIndexType == MF_SYS_INDEXTYPE_KV_CHAR)
	{
		CMemoryHashChar stCharHashIndex;
		stCharHashIndex.SetHashTableAddr(pRoot,nIndexID,this);
		stCharHashIndex.DropObject(lpExecutePlan, nIndexID, lpExecutePlan->m_nTimestamp);	
		RootDelete(lpExecutePlan, nIndexID);		//删根节点
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取文件的空间信息
		参数说明：
			lpExecutePlan：执行计划
			nFileTotalSize：文件总大小
			nFileUseSize：用户使用空间
			nFileFreeSize：剩余空间
************************************************************************/
int CMemoryHashFile::GetFileSpace(LPEXECUTEPLANBSON lpExecutePlan, long long &nFileTotalSize, long long &nFileUseSize, long long &nFileFreeSize)
{
	LPBASEBLOCKHEAD lpBlockHead;
	long long nFreeBlockMapOffset;
	LPBASEFILEBLOCKMAP lpBlockMap;

	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetKVRootCritical(), lpExecutePlan);
	nFileTotalSize = m_lpMemoryFileHead->m_nFileTotalSize;
	nFileFreeSize  = m_lpMemoryFileHead->m_nFileFreeSize;
	
	nFreeBlockMapOffset = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
	while(nFreeBlockMapOffset)
	{
		lpBlockMap  = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nFreeBlockMapOffset);
		lpBlockHead = (LPBASEBLOCKHEAD)(m_lpFileAddr + lpBlockMap->m_nBlockOffset);
		nFileFreeSize += lpBlockHead->m_nBlockSize;
		nFreeBlockMapOffset = lpBlockMap->m_nNextOffset;
	}
	
	nFileUseSize   = nFileTotalSize - nFileFreeSize;
	return MF_OK;
}

/************************************************************************
		功能说明:
			设置对象信息
		参数说明：
			lpExecutePlan:执行计划
			nIndexID：对象ID
			nDataNum：记录数
************************************************************************/
void CMemoryHashFile::SetObjectData(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, long long nDataNum)
{
	int i;

	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetKVFileCritical(), lpExecutePlan);
	try
	{
		for(i = 0; i < MAX_OBJECT_NUM; i++)
		{
			if(m_lpMemoryFileHead->m_stFileObjectData[i].m_nID == nIndexID)
			{
				m_lpMemoryFileHead->m_stFileObjectData[i].m_nFinishedTimestamp = lpExecutePlan->m_nTimestamp;
				m_lpMemoryFileHead->m_stFileObjectData[i].m_nRecordNum += nDataNum;
			}
		}
	}
	catch (...)
	{
		Trace("CMemoryHashFile::SetObjectData", MF_TRACE_LEVEL_FAILED, 130001001, "设置对象信息异常，错误码：%d", GetLastError());
	}
}

/************************************************************************
		功能说明：
			备份文件数据
		参数说明：
			lpBuffer：文件头Buffer
			nBufferSize：Buffer大小
************************************************************************/
int CMemoryHashFile::BackUpFileData(LPBYTE lpBuffer, int nBufferSize)
{
	//上锁
	int nHeadBufferSize;
	LPBASEFILEBLOCKMAPHEAD lpMasterBaseFileBlockMapHead, lpSlaveBaseFileBlockMapHead;

	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetKVFileCritical(), NULL);
	if(m_lpMemoryFileHead->m_nFileHeaderSize > nBufferSize)
	{
		return MF_FLASHBACK_INVALID_BUFFER_SIZE;
	}
	else
	{
		//先备份文件头
		memcpy(lpBuffer, m_lpFileAddr, m_lpMemoryFileHead->m_nFileHeaderSize);
	}
	

	lpMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nBlockMapStartOffset);
	lpSlaveBaseFileBlockMapHead  = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nBlockMapStartOffset + m_lpMemoryFileHead->m_nBlockMapSize);
	while(TRUE)
	{
		nHeadBufferSize = sizeof(BASEFILEBLOCKMAPHEAD) + m_lpMemoryFileHead->m_nBlockMapStructSize*(lpMasterBaseFileBlockMapHead->m_nBlockMapNum - 1);

		//检测映射表大小
		if (nHeadBufferSize > (DWORD)m_lpMemoryFileHead->m_nBlockMapSize)
		{
			return MF_FLASHBACK_INVALID_MAP_SIZE;
		}

		memcpy((LPBYTE)lpSlaveBaseFileBlockMapHead, (LPBYTE)lpMasterBaseFileBlockMapHead, m_lpMemoryFileHead->m_nBlockMapSize);
		if(lpMasterBaseFileBlockMapHead->m_nNextBlockMapOffset != 0)
		{
			lpMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + lpMasterBaseFileBlockMapHead->m_nNextBlockMapOffset);
			lpMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + lpMasterBaseFileBlockMapHead->m_nNextBlockMapOffset + m_lpMemoryFileHead->m_nBlockMapSize);
		}
		else
		{
			break;
		}
	}
	return MF_OK;
}