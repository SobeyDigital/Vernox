﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

class CBaseBlock
{
public:
	CBaseBlock(void);
	~CBaseBlock(void);

public:
	/************************************************************************
		功能说明：
			计算空闲区与块总大小的比例
	************************************************************************/
	virtual double RaitoStat() = 0;

	/************************************************************************
		功能说明：
			判断插入数据后，块是否会满
	************************************************************************/
	virtual BOOL IsFull(int nSize, double nRatio = 0.1) = 0;

	/************************************************************************
		功能说明：
			初始化数据块管理类，让整个实例是可执行的
	************************************************************************/
	virtual void SetBlockAddr(CBaseMemoryFile* pFilePtr, LPBYTE pBlockAddr) = 0;

	/************************************************************************
		功能说明：
			 创建一个内存块，并初始化m_pBlockAddr、m_pBlockHead成员变量
	************************************************************************/
	virtual void InitialBlock(int nID) = 0;
	
	/************************************************************************
		功能说明：
			 插入关键字
	************************************************************************/
	virtual int InsertKey(LPEXECUTEPLANBSON lpExecutePlan, LPINDEXINFO lpIndexInfo, long long nTimestamp){return 0;}

	/************************************************************************
		功能说明：
			修改时间戳
	************************************************************************/
	virtual void TimestampUpdate(LPEXECUTEPLANBSON lpExecutePlan, LPBASEBLOCKHEAD lpBlockHead, long long llTimestamp);
};
