﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#define MF_CHARACTER_SIZE			0X51B0	//汉字的UNICODE开始编码为4E00，结束编码为9FA5，实际总数量为51A6

class CCharCompare
{
	#pragma pack(1)
	typedef struct
	{
		WORD m_cUniNum;
		char m_lpPingyin[6];
	}PINYINDATA;
	#pragma pack()
private:
	CCharCompare(void);
	virtual ~CCharCompare(void);
	friend class CSystemManage;

	SHORT	   * m_pCharacterPinYinSortTable;
	int		     m_nKMPNextSize;
	SHORT	   * m_pKMPNextTable;
	int		   * m_pCharacterCount;
	int		   GetUnicode(const char *cSrc);
	//void	   GetNextval(const char* p, const int nPLen, SHORT *pNext, int nCaseSensitive);
public:
	//初始化汉字拼音库
	void	   InitPinYin(LPBYTE lpBuffer, int nSize);
	//两个字符串从开始进行比较，不处理%和_的匹配
	int        Compare(const char * pSrcData, int nSrcLen, const char * pDes, int nDesLen, int nCaseSensitive, BOOL bMatch);
	int		   Find(const char *pSrc, int nSrcLen, const char *pPat, int nPatLen, int nCaseSensitive);

private:
	//构建KMP算法NEXT表
	int BuildNext(const char* pPat, SHORT *pNext, int nPatLen, int nCaseSensitive);
	//KMP算法进行字符串匹配
	int Match(const char *pSrc, int nSrcLen, const char *pPat, SHORT *pNext, int *pCount, int nPatLen, int nCaseSensitive, BOOL bPercent, BOOL bUnderLine);
	//字符比较
	int CompareChar(const char * pSrc, int nSrcLen, const char * pDes, int nDesLen, int nCaseSensitive);
	//字符匹配
	int CompareMatch(const char * pSrcData, int nSrcLen, const char * pDes, int nDesLen, int nCaseSensitive);
};

//子串查找
int	SubStringFind(const char *pSrc, int nSrcLen, const char *pPat, int nPatLen, int nCaseSensitive);
