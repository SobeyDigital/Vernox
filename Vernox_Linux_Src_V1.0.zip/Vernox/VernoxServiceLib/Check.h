﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include "MemoryFile.h"
#include "Expression.h"
#include "MapSimple.h"
class Check
{
public:
	Check();
	~Check(void);
protected:
	CMemoryFile*		m_pMemoryFile;
	CServiceBson*       m_pBson;
	CExpression			m_stExpression;
	long long			m_nTimestamp;
	TRANSACTIONARRAY*	m_lpTransactionArray;
	LPOBJECTDEF		    m_lpObjectInfo;
	UINT				m_nWhereOffset;
protected:
	//比较运算
	int Compare(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen, LPCOMPAREEXPBSON lpCompareExp, BOOL& bResult);
	int Compare(LPRECORDDATAINFO lpRecordInfo, LPCOMPAREEXPBSON lpCompareExp, BOOL& bResult);

	//用于系统表
	int Compare(LPSINGLERECORD lpDataArray, LPCOMPAREEXPBSON lpCompareExp, BOOL& bResult);

public:
	int Initial(CServiceBson* pBson, LPQUERYINFO lpQueryInfo);
	
	//用于普通表
	int CheckValid(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen, LPBASECONDITIONBSON lpCondition, BOOL& bValid);
	int CheckValid(LPRECORDDATAINFO lpRecordInfo, LPBASECONDITIONBSON lpCondition, BOOL& bValid);

	//用于系统表
	int CheckValid(LPSINGLERECORD lpDataArray, LPBASECONDITIONBSON lpCondition, BOOL& bValid);

	virtual BOOL CheckRecordValid(long long nDataID);
	virtual BOOL CheckRecordValid(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen);
};

class CheckHBTreeIndex : public Check
{
public:
	CheckHBTreeIndex(void);
	~CheckHBTreeIndex(void);
private:
	INDEXINFO			m_stIndexInfo;
	CDataIDContainer    *m_pStartDataID;

	LPQUERYINFO		    m_lpQueryInfo;

	CMapTemporaryDataID m_stSuccessHash;
	CMapTemporaryDataID m_stFailedHash;

protected:
	int CheckDownID(CServiceBson& stBson, long long nDataID, int nLevel, BOOL& bFind);

public:
	int Initial(CServiceBson* pBson, LPQUERYINFO lpQueryInfo, CDataIDContainer* pDataIDContainer);
	virtual BOOL CheckRecordValid(long long nDataID);
};

