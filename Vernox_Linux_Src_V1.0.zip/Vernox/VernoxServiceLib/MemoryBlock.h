﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                    内存块管理类                                                                               //
//                                                                                                                                               //
//    实现内存文件里面的块数据管理，实现真正数据的增、删、查、改操作，在内存数据库中管理的数据最小单位为条，而这里加入块的逻辑是为了隔离内存管理 //
//和索引等之间的关系，块内的内存不管如何变化也不会影响到索引对条的引用关系。另外由于内存块是存在于文件中实现数据持久化，所以就会出现重启程序后， //
//内存的对应管理，我们这里所有的地方都是用相对于块首地址的偏移量来实现。程序重新初始化，只需要改变块地址，而其他所有数据的关系就自然恢复。       //
//    目前定义每一个块在做Insert操作时，最多可用到80%的空间，剩余的主要应对修改可能使用更大的空间。而删除操作只有当使用空间降到40%以下时才能重新 //
//接受插入操作，这样可简单的提高插入找块的效率，也可避免不必要的跨块数据保存。当前数据块的使用方式为，头部为数据块总体信息结构体，接下来是一个定 //
//长的数据保存区，然后实际数据上都从尾部开始保存，每次分配的空间安装32字节倍数进行空间分配，减少频繁分配造成数据读取很慢，管理也很复杂的问题；同 //
//样也可解决定长数据区究竟留多大空间的问题。                                                                                                     //
//                                                                                                                                               //
//                                                                                                                            吴春中、张浩阳     //
//                                                                                                                            2014年7月          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma once
#include "stdafx.h"
#include "TimestampManage.h"
#include "CommonAPI.h"
#include "BaseBlock.h"
#include "Expression.h"
#define RELATION_TYPE BYTE
#define RELATION	  1
#define IN_RELATION	  2

class CMemoryFile;
class CMemoryBlock : public CBaseBlock
{
private:
	#pragma pack(1)
	/************************************************************************
	 单条数据结构：定长数据+变长数据(数据会以这样的结构存放在内存中) 
	************************************************************************/
	//定长数据结构
	typedef struct 
	{
		int	 m_nInnerNo;							//数据内部编号(新插入数据的编号 = 最大编号+1)
		BYTE m_bLockStatus;							//数据锁定状态
		BYTE m_bDataStatus;							//记录状态
		int  m_nVarDataOffset;						//变长数据偏移量，使用此值加上块开始指针m_pBlockAddr，即可得到实际位置，为0表示数据已经无效了
		int  m_nVarDataLength;						//变长数据实际大小
		long long m_nNextDataID;					//如果发生了行迁移改值为迁移后的DataID值，如果没有发生行迁移改值为回滚区的ID值,在DataID复用时作为下一个空定长数据的偏移
		long long m_nTimestamp;						//时间戳
	}BLOCKDATASTRUCT, *LPBLOCKDATASTRUCT;

	//变长数据结构体，除放置数据以外，会额外开销20字节，一条数据可能存在多条变长数据，他们之间的关系使用m_nNextOffset来做串联，最后一个块的m_nNextOffset值为0。
	typedef struct 
	{
		int	m_nDataFlag;							//数据标志，目前定为‘SBBV’
		int m_nDataLength;							//变长数据长度，目前以32的倍数进行内存分配，以防止频繁分配导致无谓的开销
		int m_nActualLength;						//数据实际长度
		int m_nNextOffset;							//下级数据偏移量，使用此值加上块开始指针m_pBlockAddr，即可得到实际位置，为0表示没有后续数据块
		BYTE m_lpDataContent[1];					//数据内容,首地址
	}BLOCKVARDATASTRUCT, *LPBLOCKVARDATASTRUCT;

	//Block头，直接为块的开始位置存放的数据，描述块内数据信息
	typedef struct 
	{
		int		m_nDataFlag;						//数据标志，目前数据块为‘SBDB’
		int		m_nBlockNo;							//块号(新插入块的编号 = 最大块号+1)
		long long m_nTimestamp;						//时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
		int		m_nBlockSize;						//块大小
		int		m_nBlockHeadSize;					//块头大小
		BYTE	m_bDataStatus;						//数据锁定状态，一般修改单条数据不需要整块锁，但如果整块进行整理时就必须进行锁定，防止其他读取或者修改操作出现错乱
		BYTE	m_bFileNo;							//文件编号
		BYTE    m_bSaveFlag;                        //数据库保存标志，防止单纯按照时间戳判断出现误判
		BYTE	m_bThreadNum;						//保留数据

		int		m_nObjectID;						//数据对象ID，相当于数据库的表	
		int		m_nBlockDataStructSize;				//定长数据结构体大小
		int		m_nInnerMaxNo;						//块内编号最大值，用于插入时
		int		m_nDataInsertOffset;				//定长数据插入位置偏移
		int		m_nVarDataInsertOffset;				//变长数据插入位置偏移
		int		m_nDataNum;							//现有定长数据条数
		int		m_nFreeDataOffset;					//空闲定长数据偏移，用于实现DataID复用
		int		m_nRecyclableSpaceSize;				//可回收空间大小
		int		m_nReserved[3];						//保留字段
	}BLOCKHEAD, *LPBLOCKHEAD;
	#pragma pack()
private:
	
	LPBYTE m_lpBlockAddr;							//块指针(由构造函数进行初始化)
	LPBYTE m_lpBlockBody;							//块体指针m_pBlockBody = m_pBlockAddr + BLOCKHEAD.m_nBlockHeadSize
	LPBLOCKHEAD m_lpBlockHead;						//块头指针(m_pBlockHead = (LPBLOCKHEAD*)m_pBlockAddr)
	CMemoryFile* m_pFile;							//文件对象指针
private:
	//防止此类被非法构造成对象或者复制
	CMemoryBlock(const CMemoryBlock&);
	CMemoryBlock& operator = (const CMemoryBlock&);

private:
	/************************************************************************
		功能说明：
			实现二分法
	************************************************************************/
	short BinarySearch(short nInnerNo);

	/************************************************************************
		功能说明：
			将nDataID转换成定长数据的地址指针
	************************************************************************/
	LPBYTE ConvertDataIDtoDataAddr(long long nDataID);		

	/************************************************************************
		功能说明：
			在变长数据头部增加一条数据块
	************************************************************************/
	virtual int AllocBlockVarData(int nSize, int& nAllocSize);

	/************************************************************************
		功能说明：
			在内存空间中分配一个定长数据空间和变长数据空间(在插入一条新数据的时候使用)
	************************************************************************/
	virtual LPBYTE AllocBlockNewData(int nSize, long long nDataID);

	///////////////////////////////////获取数据的相关函数///////////////////////////////////////
	/************************************************************************
		功能说明：
			获取变长数据
	************************************************************************/
	int GetVarData(LPBLOCKDATASTRUCT lpDataAddr, LPRECORDDATAINFO lpRecordData, LPBLOCKVARDATASTRUCT& pVarDataAddr, int &nNextOffset);

public:
	CMemoryBlock();
	//析构函数
	~CMemoryBlock(void);

public:
	///////////////////////////////////内联函数///////////////////////////////////////
	/************************************************************************
		功能说明：
			获取块中的ObjectID
	************************************************************************/
	inline int GetObjectID()
	{
		return m_lpBlockHead->m_nObjectID;
	}
	
	/************************************************************************
		功能说明：
			获取块的大小
	************************************************************************/
	inline int GetBlockSize()
	{
		return m_lpBlockHead->m_nBlockSize;
	}
	
	/************************************************************************
		功能说明：
			获取块的空闲区
	************************************************************************/
	inline int GetBlockFreeSize()
	{
		return m_lpBlockHead->m_nVarDataInsertOffset - m_lpBlockHead->m_nDataInsertOffset;
	}

	/************************************************************************
		功能说明：
			获取块的编号
	************************************************************************/
	inline int GetBlockNo()
	{
		return m_lpBlockHead->m_nBlockNo;
	}

	/************************************************************************
		功能说明：
			获取块的地址
	************************************************************************/
	inline LPBYTE GetBlockAddr()
	{
		return m_lpBlockAddr;
	}

public:
	///////////////////////////////////数据备份恢复相关函数///////////////////////////////////////
	/************************************************************************
		功能说明：
			数据备份
	************************************************************************/
	int DataBackup(long long nDataID, long long nTimestamp);

	/************************************************************************
		功能说明：
			获取回滚区中的数据，以条为单位
	************************************************************************/
	int GetRollBackData(long long nDataID, int& nDataLen, LPBYTE& pData, long long nTimestamp);

	/************************************************************************
		功能说明：
			提供给Update的回滚		
	************************************************************************/
	int UpdateRollBack(long long nDataID, long long nTimestamp);

	/************************************************************************
		功能说明：
			提供给Delete的回滚
	************************************************************************/
	int DeleteRollBack(long long nDataID, long long nTimestamp);

	/************************************************************************
		功能说明：
			提供给Insert的回滚
	************************************************************************/
	int InsertRollBack(long long nDataID, long long nTimestamp);

public:
	///////////////////////////////////基本函数///////////////////////////////////////
	/************************************************************************
		功能说明：
			锁定块
	************************************************************************/
	int LockBlock(LPEXECUTEPLANBSON lpExecutePlan, DWORD dwMilliseconds);
	int LockBlock(LPEXECUTEPLANBSON lpExecutePlan, long long& nDataID, DWORD dwMilliseconds);

	/************************************************************************
		功能说明：
			解锁块
	************************************************************************/
	void UnLockBlock(LPEXECUTEPLANBSON lpExecutePlan);

	/************************************************************************
		功能说明：
			计算可回收区域的总大小，用于块内整理预判
	************************************************************************/
	double FreeMemoryStat();

	/************************************************************************
		功能说明：
			计算空闲区与块总大小的比例
	************************************************************************/
	double RaitoStat();

	/************************************************************************
		功能说明：
			判断插入数据后，块是否会满
	************************************************************************/
	BOOL IsFull(int nSize, double nRatio = 0.05);

	/************************************************************************
		功能说明：
			初始化数据块管理类，让整个实例是可执行的
	************************************************************************/
	virtual void SetBlockAddr(CBaseMemoryFile* pFilePtr, LPBYTE pBlockAddr);

	/************************************************************************
		功能说明：
			 创建一个内存块，并初始化m_pBlockAddr、m_pBlockHead成员变量
	************************************************************************/
	virtual void InitialBlock(int nObjectID);
	
	/************************************************************************
		功能说明：
			用于进行数据块内存整理。
	************************************************************************/
	int MergeMemory();	

	/************************************************************************
		功能说明：
			分配数据ID
	************************************************************************/
	void AllocDataID(LPRECORDHEAD lpRecordHead);

	/************************************************************************
		功能说明：
			从InnerNo中获取轮数
	************************************************************************/
	inline int GetRoundFromInnerNo(int nInnerNo)
	{
		return (int)(nInnerNo >> 16);
	}

	/************************************************************************
		功能说明：
			创建MakeInnerNo
	************************************************************************/
	inline int MakeInnerNo(int nRound, int nInnerNo)
	{
		return (int)(nRound << 16 | (short)nInnerNo);
	}

	/************************************************************************
		功能说明：
			获取最大内部编号
	************************************************************************/
	void GetMaxInnerNo(int& nInnerNo);

	/************************************************************************
		功能说明：
			清理文件数据
	************************************************************************/
	void ClearBlockData();

public:
	///////////////////////////////////增删改函数///////////////////////////////////////
	/************************************************************************
		功能说明：
			将定长数据写入内存
	************************************************************************/
	int RemoveData(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo, long long& nDataID);

	/************************************************************************
		功能说明：
			将定长数据写入内存
	************************************************************************/
	int InsertData(LPRECORDDATAINFO lpRecordInfo, LPRECORDHEAD lpRecordHead);

	/************************************************************************
		功能说明：
			修改数据
	************************************************************************/
	int UpdateData(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo);

	/************************************************************************
		功能说明：
			从内存文件中删除数据
	************************************************************************/
	int DeleteData(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo);

public:
	/************************************************************************
		功能说明：
			获取块中的所有数据条数
	************************************************************************/
	int GetDataNum(LPTRANSACTIONARRAY lpTransactionArray, long long nTimestamp);
	
	/************************************************************************
		功能说明：
			判断数据是否可见
	************************************************************************/
	BOOL CheckDataVisiable(LPTRANSACTIONARRAY lpTransactionArray, long long nDataID, long long nTimestamp);

	/************************************************************************
		功能说明：
			更新时间戳
	************************************************************************/
	void TimestampUpdate(long long nTimestamp)
	{
		if(m_lpBlockHead->m_nTimestamp != nTimestamp)
		{
			m_lpBlockHead->m_bSaveFlag   = 0;
			m_lpBlockHead->m_nTimestamp  = nTimestamp;
		}
	}
	
	/************************************************************************
		功能说明：
			闪回
	************************************************************************/
	int FlashBack(LPBYTE pBuffer, long long nTimestamp);

	/************************************************************************
		功能说明：
			获取下一个DataID
	************************************************************************/
	int GetNextDataID(int& nDataNo, long long& nDataID);

	/************************************************************************
		功能说明：
			获取记录指针
	************************************************************************/
	int GetRecordBuffer(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo);

	/************************************************************************
		功能说明：
			获取记录指针
	************************************************************************/
	int GetRecordPtr(LPRECORDDATAINFO lpRecordInfo);
	
	/************************************************************************
		功能说明：
			获取记录值
	************************************************************************/
	int GetRecordFieldValue(CServiceBson* pBson, CExpression* pExpression, LPRECORDDATAINFO lpRecordInfo, BYTE bFieldNo, VARDATA& varResult);

	/************************************************************************
		功能说明：
			导出表
	************************************************************************/
	int ExportObject(CServiceBson& stBson, int nObjectID, long long nTimestamp, LPTRANSACTIONARRAY lpTransactionArray, int& nInnerDataNo, int& nRecordNum, BOOL& bFinish);
	
	/************************************************************************
		功能说明：
			获取记录数量
	************************************************************************/
	int GetRecordNum();
};
