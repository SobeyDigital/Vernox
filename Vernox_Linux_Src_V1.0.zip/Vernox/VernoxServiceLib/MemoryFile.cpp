﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "FunctionManager.h"
#include "MemoryHashFile.h"
#include "Check.h"
#include "MemoryBlock.h"
#include "CommonAPI.h"
#include "TimestampManage.h"
#include "MemoryFile.h"

#define MAX_FREELINK_LEN 16
#define FREEBLOCK_THRESHOLD 0.1
CMemoryFile::CMemoryFile(void)
{

}

CMemoryFile::~CMemoryFile(void)
{
	int nID;
	LPVOID lpPos, lpValue;
	CMemoryBlock* pBlock;
	
	//释放m_mapMemoryBlock中Block对象指针
	lpPos = m_mapMemoryBlock.GetHeadPosition();
	while(lpPos != NULL)
	{
		m_mapMemoryBlock.GetNext(lpPos, nID, lpValue);
		if(lpValue != NULL)
		{
			pBlock = (CMemoryBlock*)lpValue;

			delete pBlock;
			pBlock = NULL;
		}
	}
}

/************************************************************************
		功能说明：
			初始化内存文件管理类，让整个实例是可执行的
		参数说明：
			pFileAddr：内存文件数据块的首地址指针，需要记录在m_pFileAddr变量中
		特别说明：
			同时还需要把m_pMemoryFileHead成员变量也初始化出来，便于后续的写入和读取操作；同时需要根据文件头记录的BASEFILEBLOCKMAP数据，初始化每一个Block类实例，同时完善m_mapMemoryBlock变量数据。
			注意，对于新建内存文件是由另一个进程(服务进程)来实现的。
************************************************************************/
int CMemoryFile::SetFileAddr(LPBYTE pFileAddr)
{
	CMemoryBlock* pBlock;
	LPBASEFILEBLOCKMAPHEAD lpBlockMapHead;
	long long nFileFreeSize, nBlockMapOffset;
	UINT nMaxBlockMapNum, nMapNum, nBlockMapSize;
	int i, nBlockNo, nFileHeadSize, nBlockMapStructSize, nBlockMapHeadSize;

	//初始化文件指针和文件头指针
	m_lpFileAddr			= pFileAddr;
	m_lpMemoryFileHead		= (LPFILEHEAD)pFileAddr;
	nMapNum					= (int)m_lpMemoryFileHead->m_nFileTotalSize / DEF_BLOCK_SIZE;
	m_mapMemoryBlock.Initialize(nMapNum);
	
	//判断映射表是否为空，如果不为空则遍历映射表创建CMap对象，如果空则说明是一个新创建的内存文件，那么需要初始化文件头
	if(m_lpMemoryFileHead->m_nBlockMapStartOffset == 0)
	{
		nBlockMapHeadSize	= sizeof(BASEFILEBLOCKMAPHEAD);
		nFileHeadSize		= sizeof(FILEHEAD);
		nBlockMapStructSize = sizeof(BASEFILEBLOCKMAP);
		nMaxBlockMapNum		= (UINT)((m_lpMemoryFileHead->m_nFileTotalSize - nFileHeadSize) / DEF_BLOCK_SIZE);
		nBlockMapSize		= nMaxBlockMapNum * nBlockMapStructSize;
		nBlockMapSize		= ((sizeof(BASEFILEBLOCKMAPHEAD) + nBlockMapSize) / DEF_BLOCK_SIZE + 1) * DEF_BLOCK_SIZE;	
		nFileFreeSize		= m_lpMemoryFileHead->m_nFileTotalSize - nFileHeadSize - nBlockMapSize*2;				//主备两张表

		lpBlockMapHead									= (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + nFileHeadSize);
		lpBlockMapHead->m_nBlockMapNum					= 0;
		lpBlockMapHead->m_nNextBlockMapOffset			= 0;
		m_lpBlockMapTail								= lpBlockMapHead;

		m_lpMemoryFileHead->m_nBlockNum					= 0;
		m_lpMemoryFileHead->m_nFreeBlockMapOffset		= 0;
		m_lpMemoryFileHead->m_nInnerMaxNo				= 1;
		m_lpMemoryFileHead->m_nTimestamp				= GetSystemTimestamp();
		m_lpMemoryFileHead->m_nFileHeaderSize			= nFileHeadSize;
		m_lpMemoryFileHead->m_nBlockMapStructSize		= nBlockMapStructSize;
		m_lpMemoryFileHead->m_nFileFreeSize				= nFileFreeSize;
		m_lpMemoryFileHead->m_nBlockMapSize				= nBlockMapSize;
		m_lpMemoryFileHead->m_nMaxBlockMapNum			= nMaxBlockMapNum;
		m_lpMemoryFileHead->m_nBlockMapStartOffset		= nFileHeadSize;
		m_lpMemoryFileHead->m_nFileFreeMemoryOffset		= nFileHeadSize + nBlockMapSize*2;				
		m_lpMemoryFileHead->m_nBlockStartOffset			= nFileHeadSize + nBlockMapSize*2;
	}
	else
	{
		//遍历映射表创建CMap对象
		//注意：1.映射表表项的总个数=块的总个数 
		//		2.映射表表项按照块分配的先后顺序有序存放
		nBlockMapOffset = m_lpMemoryFileHead->m_nBlockMapStartOffset;
		while(nBlockMapOffset)
		{
			lpBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + nBlockMapOffset);
			for(i = 0; i < lpBlockMapHead->m_nBlockMapNum; i++)
			{
				pBlock = new CMemoryBlock;	
				nBlockNo = lpBlockMapHead->m_pBlockMap[i].m_nBlockNo;
				pBlock->SetBlockAddr(this, m_lpFileAddr + lpBlockMapHead->m_pBlockMap[i].m_nBlockOffset);
				m_mapMemoryBlock.Set(nBlockNo, pBlock);
			}
			nBlockMapOffset = lpBlockMapHead->m_nNextBlockMapOffset;
		}
		m_lpBlockMapTail = lpBlockMapHead;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取起始块的偏移
		参数说明：
			lpExecutePlan：执行计划
			nObjectID：对象ID
			bLinkType：链表类型
			bRelation：是否为关系表
			nBlockMapOffset：块映射表偏移
************************************************************************/
int CMemoryFile::GetStartBlockMapOffset(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, LINK_TYPE bLinkType, BOOL bRelation, long long& nBlockMapOffset)
{
	int nRet;
	LPBASEFILEOBJECTDEF lpObjectDef;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileBlockMapCritical(), lpExecutePlan);

	//获取链表的起始位置
	nRet = GetFileObject(nObjectID, lpObjectDef, bRelation);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(bLinkType == FREE_LINK)
	{
		nBlockMapOffset = lpObjectDef->m_nFreeBlockMapOffset;
	}
	else if(bLinkType == FULL_LINK)
	{
		nBlockMapOffset = lpObjectDef->m_nFullBlockMapOffset;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取当前块的下一个块的偏移
		参数说明：
			lpExecutePlan：执行计划
			nBlockMapOffset：块映射表偏移
************************************************************************/
void CMemoryFile::GetNextBlockMapOffset(LPEXECUTEPLANBSON lpExecutePlan, long long& nBlockMapOffset)
{
	LPBASEFILEBLOCKMAP lpBlockMap;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileBlockMapCritical(), lpExecutePlan);
	lpBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nBlockMapOffset);

	nBlockMapOffset = lpBlockMap->m_nNextOffset;
}

/************************************************************************
	功能说明：
		从满块或空块链表上获取一个块对象
	参数说明：
		lpExecutePlan：执行计划
		nObjectID：对象ID
		lpLinkInfo：链表信息
		pBlock：指针
************************************************************************/
int CMemoryFile::GetBlockFromLink(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, LPLINKINFO lpLinkInfo, CMemoryBlock* &pBlock)
{
	int nRet, nTimeOut;
	LPBASEFILEBLOCKMAP lpBlockMap;
	LPBASEFILEOBJECTDEF lpObjectDef;
	map<int, CMemoryBlock*>::iterator iter;
	
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileBlockMapCritical(), lpExecutePlan);
	while(TRUE)
	{
		if(lpLinkInfo->m_bStart)
		{
			lpLinkInfo->m_bStart = FALSE;
			//获取链表的起始位置
			nRet = GetFileObject(nObjectID, lpObjectDef, lpLinkInfo->m_bRelationObject);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			
			if(lpLinkInfo->m_bLikType == FREE_LINK)
			{
				lpLinkInfo->m_nBlockMapOffset = lpObjectDef->m_nFreeBlockMapOffset;
			}
			else if(lpLinkInfo->m_bLikType == FULL_LINK)
			{
				lpLinkInfo->m_nBlockMapOffset = lpObjectDef->m_nFullBlockMapOffset;
			}

			if(lpLinkInfo->m_nBlockMapOffset == 0)
			{
				pBlock = NULL;
				return MF_OK;
			}
		}
		else if(lpLinkInfo->m_nBlockMapOffset == 0)
		{
			pBlock = NULL;
			return MF_OK;
		}

		lpBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + lpLinkInfo->m_nBlockMapOffset);
		lpLinkInfo->m_nBlockNo = lpBlockMap->m_nBlockNo;
	
		pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(lpBlockMap->m_nBlockNo);
		if(pBlock == NULL)
		{
			return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
		}
		
		if(lpLinkInfo->m_bLock)
		{
			if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_INSERT)
			{
				nTimeOut = 0;
			}
			else
			{
				nTimeOut = MF_LOCK_OUTOFTIME;
			}
			nRet = pBlock->LockBlock(lpExecutePlan, nTimeOut);
			if(nRet != MF_OK)
			{
				lpLinkInfo->m_nBlockMapOffset = lpBlockMap->m_nNextOffset;
				continue;
			}
		}

		lpLinkInfo->m_nBlockMapOffset = lpBlockMap->m_nNextOffset;
		break;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			在链表中查找nBlockNo对应的块
		参数说明：
			lpExecutePlan：执行计划
			blinkType：链表类型
			bObjectType：对象类型
			nBlockNo：块编号
************************************************************************/
BOOL CMemoryFile::FindBlockInLink(LPEXECUTEPLANBSON lpExecutePlan , int nObjectID, LINK_TYPE blinkType, MF_OBJECT_TYPE bObjectType, int nBlockNo)
{
	int nRet;
	BOOL bRelationObject;
	long long nBlockMapOffset;
	LPBASEFILEBLOCKMAP lpBlockMap;
	LPBASEFILEOBJECTDEF lpObjectDef;

	bRelationObject = FALSE;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileBlockMapCritical(), lpExecutePlan);
	nRet = GetFileObject(nObjectID, lpObjectDef, bRelationObject);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(blinkType == FREE_LINK)
	{
		nBlockMapOffset = lpObjectDef->m_nFreeBlockMapOffset;
	}
	else if(blinkType == FULL_LINK)
	{
		nBlockMapOffset = lpObjectDef->m_nFullBlockMapOffset;
	}
	while(nBlockMapOffset)
	{
		lpBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nBlockMapOffset);
		if(nBlockNo == lpBlockMap->m_nBlockNo)
		{
			return TRUE;
		}
		nBlockMapOffset = lpBlockMap->m_nNextOffset;
	}
	return FALSE;
}

/************************************************************************
		功能说明：
			将内部数据ID转换成块类的实例指针
		参数说明：
			nDataID:内部数据ID
		特别说明：
			DataID中包括块号、文件编号、块内编号。需要校验文件编号是否正确，然后再分离出具体的块编号，然后通过m_mapMemoryBlock成员变量转换成实际可执行的类实例指针。
************************************************************************/
CMemoryBlock* CMemoryFile::ConvertDataIDtoBlockObject(long long nDataID)
{
	BYTE nFileNo;
	int nBlockNo;
	CMemoryBlock* pBlock;
	map<int, CMemoryBlock*>::iterator iter;

	nFileNo  = GetFileNoFromDataID(nDataID);		//获取文件编号
	nBlockNo = GetBlockNoFromDataID(nDataID);		//获取块编号
	//校验文件编号
	if(nFileNo != m_lpMemoryFileHead->m_bFileNo)	
	{
		return NULL;								//文件编号校验失败
	}

	//根据块号在CMap中查找对应的指针
	pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(nBlockNo);
	return pBlock;
}

/************************************************************************
		功能说明：
			根据对象ID获取一个Object数据
		参数说明：
			nObjectID：对象ID
			lpFileObject：文件对象
			bRelationObject：是否是关系对象
		注意：
			使用该函数之前必须加锁
************************************************************************/
int CMemoryFile::GetFileObject(int nObjectID, LPBASEFILEOBJECTDEF& lpFileObject, BOOL bRelationObject)
{		
	int nPos;		
	LPBASEFILEOBJECTDEF lpObjectDef;
	
	if(bRelationObject)
	{
		lpObjectDef = m_lpMemoryFileHead->m_stFileRelationData;
	}
	else
	{
		lpObjectDef = m_lpMemoryFileHead->m_stFileObjectData;
	}
	//遍历FILEOBJECTDEF数组，找到nObjectID所对应的FILEOBJECTDEF结构体
	for(nPos = 0; nPos < MAX_OBJECT_NUM; nPos++)
	{
		if(nObjectID == lpObjectDef[nPos].m_nID)
		{
			lpFileObject = &lpObjectDef[nPos];
			return MF_OK;
		}
	}
	return MF_MEMORYFILE_GETFILEOBJECT_NOOBJECTMATHC_ERROR;
}

/************************************************************************
		功能说明：
			分配空间并创建内存块
		参数说明：
			lpExecutePlan：执行计划
			nBlockNo：块编号
			nBlockSize：内存块大小
		特别说明：
			分配步骤：bRelationObject
			1.从文件级的空块链表栈中寻找是否具有合适的空块，如果有则从空块链表栈中分配一个空块
			2.如果空块链表栈中没有合适的块，则从空闲区中分配
			3.因为该操作只在资源分配时调用，所以不需要加锁
************************************************************************/
int CMemoryFile::AllocBlock(LPEXECUTEPLANBSON lpExecutePlan, int& nBlockNo, int nBlockSize)
{
	LPBYTE lpNewBlockAddr;
	LPBLOCKINFO lpBlockInfo;
	CMemoryBlock *pBlock, *pNewBlock;	
	int nRet, i, nBlockMapPos, nBlockMapSize;		
	LPBASEFILEBLOCKMAP lpCurrentFreeBlockMap, lpPreFreeBlockMap;
	long long nFreeBlockOffset, nFreeBlockMapOffset, nBlockMapOffset;

	lpCurrentFreeBlockMap = NULL;
	lpPreFreeBlockMap	  = NULL;
	lpBlockInfo			  = (LPBLOCKINFO)((LPBYTE)lpExecutePlan + lpExecutePlan->m_stSourceInfo.m_nBlockOffset);
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileCritical(), lpExecutePlan);
	//1.从文件级的空块链表栈中寻找是否具有合适的空块，如果有则从空块链表栈中分配一个空块
	nFreeBlockMapOffset   = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
	while(nFreeBlockMapOffset)
	{	
		//遍历空块链表找到一个空块对应的映射结点
		lpCurrentFreeBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nFreeBlockMapOffset);			//获得映射结点指针
		pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(lpCurrentFreeBlockMap->m_nBlockNo);
		if(pBlock == NULL)
		{
			return MF_MEMORYFILE_INSERTDATA_INVALIDMEMORYMAP_ERROR;
		}

		if(pBlock->GetBlockSize() == nBlockSize)													//判断空块大小是否满足需求
		{
			//尝试锁定该块
			nRet = pBlock->LockBlock(lpExecutePlan, MF_LOCK_OUTOFTIME);
			if(nRet == MF_OK)
			{
				pBlock->TimestampUpdate(lpExecutePlan->m_nTimestamp);
				pBlock->InitialBlock(lpExecutePlan->m_nObjectID);

				nBlockNo = lpCurrentFreeBlockMap->m_nBlockNo;
				for(i = 0; i < MF_MAX_BLOCKINFO_NUM; i++)
				{
					if(lpBlockInfo[i].m_nBlockNo == nBlockNo)
					{
						lpBlockInfo = &lpBlockInfo[i];
						break;
					}
				}
				if(i == MF_MAX_BLOCKINFO_NUM)
				{
					return MF_COMMON_INVALID_EXECUTEBLOCKNUM;	
				}
				lpBlockInfo->m_nBlockNo    = nBlockNo;
				lpBlockInfo->m_nBlockSize  = nBlockSize;
				lpBlockInfo->m_bSource     = MF_SOURCE_FROM_FREEBLOCK;
				lpBlockInfo->m_bAlloc      = 1;
				lpBlockInfo->m_bObjectType = lpExecutePlan->m_bObjectType;

				//将该块从空块链表中删除
				if(lpPreFreeBlockMap == NULL)
				{
					m_lpMemoryFileHead->m_nFreeBlockMapOffset = lpCurrentFreeBlockMap->m_nNextOffset;
				}
				else
				{
					lpPreFreeBlockMap->m_nNextOffset = lpCurrentFreeBlockMap->m_nNextOffset;
				}
				nBlockMapOffset = nFreeBlockMapOffset;
				
				//将该块插入到可插块链表(插头法)
				nRet = InsertMapStruct(lpExecutePlan, lpExecutePlan->m_nObjectID, lpExecutePlan->m_bObjectType, FREE_LINK, nBlockMapOffset);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				return MF_OK;
			}
		}
		else																					
		{
			lpPreFreeBlockMap   = lpCurrentFreeBlockMap;
			nFreeBlockMapOffset = lpCurrentFreeBlockMap->m_nNextOffset;
		}
	}

	//2.如果空块链表栈里面没有可回收的块，则从空闲区中分配
	if(m_lpMemoryFileHead->m_nFileFreeSize <= nBlockSize || m_lpMemoryFileHead->m_nFileFreeMemoryOffset + nBlockSize > m_lpMemoryFileHead->m_nFileTotalSize)
	{
		//如果空闲区不够大，则分配失败
		return MF_MEMORYFILE_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;
	}
	else
	{
		//如果有空闲空间，则从空闲区中分配一个块
		//1.分配块
		pNewBlock = new CMemoryBlock;
		nFreeBlockOffset = m_lpMemoryFileHead->m_nFileFreeMemoryOffset;			//记录新分配的空块的偏移
		m_lpMemoryFileHead->m_nFileFreeMemoryOffset += nBlockSize;				//修改空闲区首地址偏移(注意：块是从后往前分配的)		
		m_lpMemoryFileHead->m_nFileFreeSize -= nBlockSize;						//修改空闲区大小

		//2.初始化块头
		lpNewBlockAddr = m_lpFileAddr + nFreeBlockOffset;
		pNewBlock->SetBlockAddr(this, lpNewBlockAddr);							

		InitialBlock(lpNewBlockAddr, m_lpMemoryFileHead->m_nInnerMaxNo, nBlockSize, m_lpMemoryFileHead->m_bFileNo, lpExecutePlan->m_nTimestamp);
		pNewBlock->InitialBlock(lpExecutePlan->m_nObjectID);
		nRet = pNewBlock->LockBlock(lpExecutePlan, MF_LOCK_OUTOFTIME);
		if(nRet != MF_OK)
		{
			return MF_MEMORYFILE_ALLOCBLOCK_LOCKNEWBLOCK_ERROR;
		}

		//3.将新分配的空闲块的相关信息写入映射表
		//为映射表结点赋值
		nBlockNo = m_lpMemoryFileHead->m_nInnerMaxNo;
		for(i = 0; i < MF_MAX_BLOCKINFO_NUM; i++)
		{
			if(lpBlockInfo[i].m_nBlockNo == nBlockNo)
			{
				lpBlockInfo = &lpBlockInfo[i];
				break;
			}
		}
		if(i == MF_MAX_BLOCKINFO_NUM)
		{
			return MF_COMMON_INVALID_EXECUTEBLOCKNUM;	
		}
		lpBlockInfo->m_nBlockNo    = nBlockNo;									//直接放在映射表结点的最后
		lpBlockInfo->m_nBlockSize  = nBlockSize;
		lpBlockInfo->m_bSource     = MF_SOURCE_FROM_FREEMEMORY;
		lpBlockInfo->m_bAlloc      = 1;
		lpBlockInfo->m_bObjectType = lpExecutePlan->m_bObjectType;

		nBlockMapPos = m_lpBlockMapTail->m_nBlockMapNum;
		m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nBlockNo		= m_lpMemoryFileHead->m_nInnerMaxNo;
		m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nBlockOffset	= nFreeBlockOffset;
		m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nNextOffset	= 0;
		m_lpBlockMapTail->m_nBlockMapNum++;
		nBlockMapOffset = (LPBYTE)(&m_lpBlockMapTail->m_pBlockMap[nBlockMapPos]) - m_lpFileAddr;
		//分配了新块之后，需要将这个块加入m_mapMemoryBlock
		m_mapMemoryBlock.Set(m_lpMemoryFileHead->m_nInnerMaxNo, pNewBlock);
		m_lpMemoryFileHead->m_nInnerMaxNo++;									//递增最大块号
		m_lpMemoryFileHead->m_nBlockNum++;										//递增块个数

		//判断映射表中是否还可以插入结点(相当于是一个预判)
		if(m_lpBlockMapTail->m_nBlockMapNum >= m_lpMemoryFileHead->m_nMaxBlockMapNum)
		{
			nBlockMapSize = m_lpMemoryFileHead->m_nBlockMapSize;
			//此时说明映射表空间不足,则需要在文件中分配一个块映射表
			if(m_lpMemoryFileHead->m_nFileFreeSize <= nBlockMapSize || m_lpMemoryFileHead->m_nFileFreeMemoryOffset + nBlockMapSize > m_lpMemoryFileHead->m_nFileTotalSize)
			{
				return MF_MEMORYFILE_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;			//说明该内存文件已经没有空间进行块的移动，文件满
			}

			m_lpBlockMapTail->m_nNextBlockMapOffset		= m_lpMemoryFileHead->m_nFileFreeMemoryOffset;
			m_lpMemoryFileHead->m_nFileFreeSize			-= nBlockMapSize;							
			m_lpMemoryFileHead->m_nFileFreeMemoryOffset += nBlockMapSize;
			m_lpBlockMapTail							= (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset);
			memset(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset, 0, nBlockMapSize);	
		}

		//将该块插入到可插块链表(插头法)
		nRet = InsertMapStruct(lpExecutePlan, lpExecutePlan->m_nObjectID, lpExecutePlan->m_bObjectType, FREE_LINK, nBlockMapOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

int CMemoryFile::AllocBlock(LPEXECUTEPLANBSON lpExecutePlan, BLOCKINFO& stBlockInfo)
{
	LPBYTE lpNewBlockAddr;
	CMemoryBlock *pNewBlock, *pBlock;
	LPBASEFILEBLOCKMAPHEAD lpBlockMapHead;
	int nRet, nBlockMapNo, nBlockMapPos, i, nBlockMapSize;
	LPBASEFILEBLOCKMAP lpCurrentFreeBlockMap, lpPreFreeBlockMap;
	long long nFreeBlockOffset, nBlockMapOffset, nFreeBlockMapOffset;
	
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileCritical(), lpExecutePlan);
	if(stBlockInfo.m_bSource == MF_SOURCE_FROM_EXISTBLOCK)
	{	
		//原始块是一个已经存在的块，则需要遍历lpFileObject的空闲块链表，判断是否存在对应编号的块
		if(FindBlockInLink(lpExecutePlan, lpExecutePlan->m_nObjectID, FREE_LINK, stBlockInfo.m_bObjectType, stBlockInfo.m_nBlockNo))
		{
			return MF_OK;
		}
		else
		{
			return MF_MEMORYFILE_ALLOCBLOCK_NULLPOINTBLOCK_ERROR;
		}
	}
	else if(stBlockInfo.m_bSource == MF_SOURCE_FROM_FREEBLOCK)
	{
		//判断是否已经存在该编号对应的块
		if(FindBlockInLink(lpExecutePlan, lpExecutePlan->m_nObjectID, FREE_LINK, stBlockInfo.m_bObjectType, stBlockInfo.m_nBlockNo))
		{
			return MF_MEMORYFILE_ALLOCBLOCK_INVALDRESOURCETYPE_ERROR;
		}
		nFreeBlockMapOffset = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
		while(nFreeBlockMapOffset)
		{	
			//遍历空块链表找到一个空块对应的映射结点
			lpCurrentFreeBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nFreeBlockMapOffset);				//获得映射结点指针
			lpPreFreeBlockMap     = NULL;
			if(lpCurrentFreeBlockMap->m_nBlockNo == stBlockInfo.m_nBlockNo)
			{
				pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(stBlockInfo.m_nBlockNo);
				if(pBlock == NULL)
				{
					return MF_MEMORYFILE_INSERTDATA_INVALIDMEMORYMAP_ERROR;
				}

				if(pBlock->GetBlockSize() == stBlockInfo.m_nBlockSize)										//判断空块大小是否满足需求
				{
					pBlock->TimestampUpdate(lpExecutePlan->m_nTimestamp);
					pBlock->InitialBlock(lpExecutePlan->m_nObjectID);

					//将该块从空块链表中删除
					if(lpPreFreeBlockMap == NULL)
					{
						m_lpMemoryFileHead->m_nFreeBlockMapOffset = lpCurrentFreeBlockMap->m_nNextOffset;
					}
					else
					{
						lpPreFreeBlockMap->m_nNextOffset		  = lpCurrentFreeBlockMap->m_nNextOffset;
					}
					nBlockMapOffset = nFreeBlockMapOffset;
					
					//将该块插入到可插块链表(插头法)
					nRet = InsertMapStruct(lpExecutePlan, lpExecutePlan->m_nObjectID, lpExecutePlan->m_bObjectType, FREE_LINK, nBlockMapOffset);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					return MF_OK;
				}
				else
				{
					return MF_MEMORYFILE_ALLOCBLOCK_NULLPOINTBLOCK_ERROR;
				}
			}
			else
			{
				lpPreFreeBlockMap   = lpCurrentFreeBlockMap;
				nFreeBlockMapOffset = lpCurrentFreeBlockMap->m_nNextOffset;
			}
			//块不存在返回错误
			return MF_MEMORYFILE_ALLOCBLOCK_NULLPOINTBLOCK_ERROR;
		}
	}
	else if(stBlockInfo.m_bSource == MF_SOURCE_FROM_FREEMEMORY)
	{
		//从空闲区分配指定块
		//判断是否已经存在该编号对应的块
		if(FindBlockInLink(lpExecutePlan, lpExecutePlan->m_nObjectID, FREE_LINK, stBlockInfo.m_bObjectType, stBlockInfo.m_nBlockNo))
		{
			return MF_MEMORYFILE_ALLOCBLOCK_INVALDRESOURCETYPE_ERROR;
		}

		//1.获取nBlockNo对应映射表的位置
		lpBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nBlockMapStartOffset);
		if(lpBlockMapHead->m_nBlockMapNum == 0)
		{
			nBlockMapPos = 0;
			nBlockMapNo  = 1;
		}
		else
		{
			nBlockMapPos = stBlockInfo.m_nBlockNo % m_lpMemoryFileHead->m_nMaxBlockMapNum;
			if(nBlockMapPos)
			{
				nBlockMapNo  = stBlockInfo.m_nBlockNo / m_lpMemoryFileHead->m_nMaxBlockMapNum + 1;
			}
			else
			{
				nBlockMapNo  = stBlockInfo.m_nBlockNo / m_lpMemoryFileHead->m_nMaxBlockMapNum;
			}
		}

		//2.判断nBlockMapNo对应的映射表片段是否存在，若不存在则需要分配一个映射表片段
		for(i = 0; i < nBlockMapNo - 1; i++)
		{
			if(lpBlockMapHead->m_nNextBlockMapOffset)
			{
				lpBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + lpBlockMapHead->m_nNextBlockMapOffset);
				if(lpBlockMapHead->m_pBlockMap[nBlockMapPos].m_nBlockOffset != 0)
				{
					//已经分配了块
					return MF_MEMORYFILE_ALLOCBLOCK_NULLPOINTBLOCK_ERROR;
				}
			}
			else
			{
				//在文件中分配一个块映射表
				nBlockMapSize = m_lpMemoryFileHead->m_nBlockMapSize;
				if(m_lpMemoryFileHead->m_nFileFreeSize <= nBlockMapSize || m_lpMemoryFileHead->m_nFileFreeMemoryOffset + nBlockMapSize > m_lpMemoryFileHead->m_nFileTotalSize)
				{
					return MF_MEMORYFILE_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;					
				}

				lpBlockMapHead->m_nNextBlockMapOffset	= m_lpMemoryFileHead->m_nFileFreeMemoryOffset;
				m_lpMemoryFileHead->m_nFileFreeSize		-= nBlockMapSize;							
				m_lpMemoryFileHead->m_nFileFreeMemoryOffset += nBlockMapSize;
				lpBlockMapHead	 = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset);
				m_lpBlockMapTail = lpBlockMapHead;
				memset(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset, 0, nBlockMapSize);	
			}
		}

		//3.分配块
		if(m_lpMemoryFileHead->m_nFileFreeSize <= stBlockInfo.m_nBlockSize || m_lpMemoryFileHead->m_nFileFreeMemoryOffset + stBlockInfo.m_nBlockSize > m_lpMemoryFileHead->m_nFileTotalSize)
		{
			//如果空闲区不够大，则分配失败
			return MF_MEMORYFILE_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;
		}
		else
		{
			//如果有空闲空间，则从空闲区中分配一个块
			//1.分配块
			pNewBlock = new CMemoryBlock;
			nFreeBlockOffset = m_lpMemoryFileHead->m_nFileFreeMemoryOffset;							//记录新分配的空块的偏移
			m_lpMemoryFileHead->m_nFileFreeMemoryOffset += stBlockInfo.m_nBlockSize;				//修改空闲区首地址偏移(注意：块是从后往前分配的)		
			m_lpMemoryFileHead->m_nFileFreeSize -= stBlockInfo.m_nBlockSize;						//修改空闲区大小

			//2.初始化块头
			lpNewBlockAddr = m_lpFileAddr + nFreeBlockOffset;
			pNewBlock->SetBlockAddr(this, lpNewBlockAddr);						
			InitialBlock(lpNewBlockAddr, stBlockInfo.m_nBlockNo, stBlockInfo.m_nBlockSize, m_lpMemoryFileHead->m_bFileNo, lpExecutePlan->m_nTimestamp);	
			pNewBlock->InitialBlock(lpExecutePlan->m_nObjectID);
			//3.将新分配的空闲块的相关信息写入映射表
			//为映射表结点赋值
			lpBlockMapHead->m_pBlockMap[nBlockMapPos].m_nBlockNo     = stBlockInfo.m_nBlockNo;
			lpBlockMapHead->m_pBlockMap[nBlockMapPos].m_nBlockOffset = nFreeBlockOffset;
			lpBlockMapHead->m_pBlockMap[nBlockMapPos].m_nNextOffset  = 0;
			lpBlockMapHead->m_nBlockMapNum++;
			nBlockMapOffset = (LPBYTE)(&lpBlockMapHead->m_pBlockMap[nBlockMapPos]) - m_lpFileAddr;
			//分配了新块之后，需要将这个块加入m_mapMemoryBlock
			m_mapMemoryBlock.Set(stBlockInfo.m_nBlockNo, pNewBlock);
			m_lpMemoryFileHead->m_nBlockNum++;			

			if(m_lpMemoryFileHead->m_nInnerMaxNo <= stBlockInfo.m_nBlockNo)
			{
				m_lpMemoryFileHead->m_nInnerMaxNo = stBlockInfo.m_nBlockNo + 1;
			}

			//将该块插入到可插块链表(插头法)
			nRet = InsertMapStruct(lpExecutePlan, lpExecutePlan->m_nObjectID, lpExecutePlan->m_bObjectType, FREE_LINK, nBlockMapOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}
	else
	{
		return MF_MEMORYFILE_ALLOCNEWDATA_NOENOUGHMEMORY_ERROR;
	}
	return MF_OK;
}

int CMemoryFile::AllocBlock(int nObjectID, BYTE bObjectType, int nBlockSize, long long nTimestamp, int& nBlockNo)
{
	LPBYTE lpNewBlockAddr;
	CMemoryBlock *pBlock, *pNewBlock;	
	int nRet, nBlockMapPos, nBlockMapSize;		
	LPBASEFILEBLOCKMAP lpCurrentFreeBlockMap, lpPreFreeBlockMap;
	long long nFreeBlockOffset, nFreeBlockMapOffset, nBlockMapOffset;

	lpCurrentFreeBlockMap = NULL;
	lpPreFreeBlockMap	  = NULL;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileCritical(), NULL);
	//1.从文件级的空块链表栈中寻找是否具有合适的空块，如果有则从空块链表栈中分配一个空块
	nFreeBlockMapOffset   = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
	while(nFreeBlockMapOffset)
	{	
		//遍历空块链表找到一个空块对应的映射结点
		lpCurrentFreeBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nFreeBlockMapOffset);			//获得映射结点指针
		pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(lpCurrentFreeBlockMap->m_nBlockNo);
		if(pBlock == NULL)
		{
			return MF_MEMORYFILE_INSERTDATA_INVALIDMEMORYMAP_ERROR;
		}

		if(pBlock->GetBlockSize() == nBlockSize)													//判断空块大小是否满足需求
		{
			pBlock->TimestampUpdate(nTimestamp);
			pBlock->InitialBlock(nObjectID);
			nBlockNo = lpCurrentFreeBlockMap->m_nBlockNo;
			
			//将该块从空块链表中删除
			if(lpPreFreeBlockMap == NULL)
			{
				m_lpMemoryFileHead->m_nFreeBlockMapOffset = lpCurrentFreeBlockMap->m_nNextOffset;
			}
			else
			{
				lpPreFreeBlockMap->m_nNextOffset = lpCurrentFreeBlockMap->m_nNextOffset;
			}
			nBlockMapOffset = nFreeBlockMapOffset;

			//将该块插入到可插块链表(插头法)
			nRet = InsertMapStruct(NULL, nObjectID, bObjectType, FREE_LINK, nBlockMapOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			return MF_OK;
		}
		else																					
		{
			lpPreFreeBlockMap   = lpCurrentFreeBlockMap;
			nFreeBlockMapOffset = lpCurrentFreeBlockMap->m_nNextOffset;
		}
	}

	//2.如果空块链表栈里面没有可回收的块，则从空闲区中分配
	if(m_lpMemoryFileHead->m_nFileFreeSize <= nBlockSize || m_lpMemoryFileHead->m_nFileFreeMemoryOffset + nBlockSize > m_lpMemoryFileHead->m_nFileTotalSize)
	{
		//如果空闲区不够大，则分配失败
		return MF_MEMORYFILE_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;
	}
	else
	{
		//如果有空闲空间，则从空闲区中分配一个块
		//1.分配块
		pNewBlock = new CMemoryBlock;
		nFreeBlockOffset = m_lpMemoryFileHead->m_nFileFreeMemoryOffset;			//记录新分配的空块的偏移
		m_lpMemoryFileHead->m_nFileFreeMemoryOffset += nBlockSize;				//修改空闲区首地址偏移(注意：块是从后往前分配的)		
		m_lpMemoryFileHead->m_nFileFreeSize -= nBlockSize;						//修改空闲区大小

		//2.初始化块头
		lpNewBlockAddr = m_lpFileAddr + nFreeBlockOffset;
		pNewBlock->SetBlockAddr(this, lpNewBlockAddr);							

		InitialBlock(lpNewBlockAddr, m_lpMemoryFileHead->m_nInnerMaxNo, nBlockSize, m_lpMemoryFileHead->m_bFileNo, nTimestamp);
		pNewBlock->InitialBlock(nObjectID);
		
		//3.将新分配的空闲块的相关信息写入映射表
		//为映射表结点赋值
		nBlockNo	 = m_lpMemoryFileHead->m_nInnerMaxNo;
		nBlockMapPos = m_lpBlockMapTail->m_nBlockMapNum;
		m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nBlockNo		= m_lpMemoryFileHead->m_nInnerMaxNo;
		m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nBlockOffset	= nFreeBlockOffset;
		m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nNextOffset	= 0;
		m_lpBlockMapTail->m_nBlockMapNum++;
		nBlockMapOffset = (LPBYTE)(&m_lpBlockMapTail->m_pBlockMap[nBlockMapPos]) - m_lpFileAddr;
		//分配了新块之后，需要将这个块加入m_mapMemoryBlock
		m_mapMemoryBlock.Set(m_lpMemoryFileHead->m_nInnerMaxNo, pNewBlock);
		m_lpMemoryFileHead->m_nInnerMaxNo++;									//递增最大块号
		m_lpMemoryFileHead->m_nBlockNum++;										//递增块个数

		//判断映射表中是否还可以插入结点(相当于是一个预判)
		if(m_lpBlockMapTail->m_nBlockMapNum >= m_lpMemoryFileHead->m_nMaxBlockMapNum)
		{
			nBlockMapSize = m_lpMemoryFileHead->m_nBlockMapSize;
			//此时说明映射表空间不足,则需要在文件中分配一个块映射表
			if(m_lpMemoryFileHead->m_nFileFreeSize <= nBlockMapSize || m_lpMemoryFileHead->m_nFileFreeMemoryOffset + nBlockMapSize > m_lpMemoryFileHead->m_nFileTotalSize)
			{
				return MF_MEMORYFILE_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;			//说明该内存文件已经没有空间进行块的移动，文件满
			}

			m_lpBlockMapTail->m_nNextBlockMapOffset		= m_lpMemoryFileHead->m_nFileFreeMemoryOffset;
			m_lpMemoryFileHead->m_nFileFreeSize			-= nBlockMapSize;							
			m_lpMemoryFileHead->m_nFileFreeMemoryOffset += nBlockMapSize;
			m_lpBlockMapTail							= (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset);
			memset(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset, 0, nBlockMapSize);	
		}

		//将该块插入到可插块链表(插头法)
		nRet = InsertMapStruct(NULL, nObjectID, bObjectType, FREE_LINK, nBlockMapOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			行迁移
		参数说明：
			stBson：BSON对象
			lpRecordInfo：记录信息
			nNextDataID：下一个数据ID
************************************************************************/
int CMemoryFile::RecordRemove(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo, long long& nNextDataID)
{
	LINKINFO stLinkInfo;
	CMemoryBlock *pBlock;
	LPEXECUTEPLANBSON lpExecutePlan;
	map<int, CMemoryBlock*>::iterator iter;
	int	nRet, nRecordLen, nBlockFreeSize, nDataSize, nBlockSize, nBlockNo;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	nRecordLen = lpRecordInfo->m_nRecordLen;
	nDataSize  = 52 + (nRecordLen / 32 + 1) * 32;								//计算记录实际所占空间的大小（52为变长数据+定长数据的总长度）
	
	//1.遍历可插链表获取块进行插入
	memset(&stLinkInfo, 0, sizeof(LINKINFO));
	stLinkInfo.m_bLikType = FREE_LINK;
	stLinkInfo.m_bLock    = TRUE;
	stLinkInfo.m_bStart   = TRUE;
	stLinkInfo.m_bRelationObject = FALSE;

	while(TRUE)
	{
		nRet = GetBlockFromLink(lpExecutePlan, lpExecutePlan->m_nObjectID, &stLinkInfo, pBlock);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(pBlock == NULL)
		{
			break;
		}
		nBlockFreeSize = (int)(pBlock->GetBlockFreeSize() - pBlock->GetBlockSize()*FREEBLOCK_THRESHOLD);	//预留20%的空间
		if(nBlockFreeSize >= nDataSize)								
		{
			//锁定成功将改记录迁移到新快
			nRet = pBlock->RemoveData(stBson, lpRecordInfo, nNextDataID);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			if(pBlock->RaitoStat() <= FREEBLOCK_THRESHOLD)
			{
				nRet = MoveMapStruct(lpExecutePlan, lpExecutePlan->m_nObjectID, lpExecutePlan->m_bObjectType, stLinkInfo.m_nBlockNo, FREE_LINK);
				if(nRet != MF_OK)
				{
					pBlock->UnLockBlock(lpExecutePlan);
					return nRet;
				}
			}
			pBlock->UnLockBlock(lpExecutePlan);
			return MF_OK;
		}
		else
		{
			//解锁块
			pBlock->UnLockBlock(lpExecutePlan);
		}
	}

	//2.如果在可插链表上没有发现合适的块，分配新块将记录插入
	if(nDataSize > DEF_BLOCK_SIZE)
	{
		nBlockSize = (nDataSize / 1024 + 1) * 1024;
	}
	else
	{
		nBlockSize = DEF_BLOCK_SIZE;
	}

	nRet = AllocBlock(lpExecutePlan, nBlockNo, nBlockSize);							
	if(nRet != MF_OK)
	{
		return nRet;
	}

	pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(nBlockNo);
	if(pBlock == NULL)
	{
		return MF_MEMORYFILE_GETBLOCKPTR_BLOCKNO_ERROR;
	}
	nRet = pBlock->RemoveData(stBson, lpRecordInfo, nNextDataID);	
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(pBlock->RaitoStat() <= FREEBLOCK_THRESHOLD)
	{
		//将该块移动到满块链表
		nRet = MoveMapStruct(lpExecutePlan, lpExecutePlan->m_nObjectID, lpExecutePlan->m_bObjectType, nBlockNo, FREE_LINK);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//解锁块
	pBlock->UnLockBlock(lpExecutePlan);
	return MF_OK;
}

/************************************************************************
		功能说明：
			将一个映射表结点插入一个链表(头插法)
		参数说明：
			lpExecutePlan：执行计划
			nObjectID：对象ID
			bObjectType：对象类型
			bLinkType：链表类型
			nBlockMapOffset：块映射表偏移
************************************************************************/
int CMemoryFile::InsertMapStruct(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, BYTE bObjectType, MF_OBJECT_TYPE bLinkType, long long nBlockMapOffset)
{
	int nRet;
	BYTE bFreeLinkLen;
	long long nOffset;
	CMemoryBlock* pBlock;
	BOOL bRelationObject;
	long long *pNextOffset;
	LPBASEFILEOBJECTDEF lpFileObject;
	LPBASEFILEBLOCKMAP lpBlockMap, lpPreBlockMap;

	bRelationObject = FALSE;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileBlockMapCritical(), lpExecutePlan);
	nRet = GetFileObject(nObjectID, lpFileObject, bRelationObject);										
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nBlockMapOffset);
	lpBlockMap->m_nNextOffset = 0;

	if(lpFileObject->m_nFreeBlockMapOffset == nBlockMapOffset)
	{
		return MF_MEMORYFILE_INSERTMAPSTRUCT_ERROR;
	}
	
	//用插尾法将结点插入链表
	if(bLinkType == FREE_LINK)
	{
		//用插尾法将结点插入链表
		bFreeLinkLen  = 0;
		nOffset		  = lpFileObject->m_nFreeBlockMapOffset;
		pNextOffset   = &lpFileObject->m_nFreeBlockMapOffset;
		lpPreBlockMap = NULL;

		while(nOffset)
		{
			lpBlockMap	= (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nOffset);
			nOffset		= lpBlockMap->m_nNextOffset;
			pNextOffset = &lpBlockMap->m_nNextOffset;
			bFreeLinkLen++;
		}
		*pNextOffset= nBlockMapOffset;

		if(bFreeLinkLen > MAX_FREELINK_LEN)
		{
			nOffset = lpFileObject->m_nFreeBlockMapOffset;
			while(nOffset)
			{
				lpBlockMap	= (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nOffset);
				pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(lpBlockMap->m_nBlockNo);
				if(pBlock == NULL)
				{
					return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
				}

				if(pBlock->RaitoStat() < FREEBLOCK_THRESHOLD*2)
				{
					//从空块链表中删除
					if(lpPreBlockMap == NULL)
					{
						lpFileObject->m_nFreeBlockMapOffset = lpBlockMap->m_nNextOffset;
					}
					else
					{
						lpPreBlockMap->m_nNextOffset		= lpBlockMap->m_nNextOffset;
					}

					//插入满块链表
					nOffset								= lpBlockMap->m_nNextOffset;
					lpBlockMap->m_nNextOffset		    = lpFileObject->m_nFullBlockMapOffset;
					lpFileObject->m_nFullBlockMapOffset = nBlockMapOffset;
				}
				else
				{
					nOffset		  = lpBlockMap->m_nNextOffset;
					pNextOffset   = &lpBlockMap->m_nNextOffset;
					lpPreBlockMap = lpBlockMap;
				}
			}
		}
	}
	else if(bLinkType == FULL_LINK)
	{
		//插头
		lpBlockMap->m_nNextOffset = lpFileObject->m_nFullBlockMapOffset;
		lpFileObject->m_nFullBlockMapOffset = nBlockMapOffset;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		将一个映射表结点移动到满\空块链表
	参数说明：
		lpExecutePlan：执行计划
		nObjectID：对象ID
		bObjectType：对象类型
		nBlockNo：块编号
		bSrcLinkType：原始链表类型
************************************************************************/
int CMemoryFile::MoveMapStruct(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, BYTE bObjectType, int nBlockNo, LINK_TYPE bSrcLinkType)
{
	int nRet;
	BOOL bRelationObject;
	LPBASEFILEOBJECTDEF lpFileObject;
	LPBASEFILEBLOCKMAP lpSrcBlockMap, lpPreBlockMap;
	long long nSrcOffset, nPreOffset, nDestOffset, *pSrcLinkHead, *pDestLinkHead, nOffset;

	bRelationObject = FALSE;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileBlockMapCritical(), lpExecutePlan);
	nRet = GetFileObject(nObjectID, lpFileObject, bRelationObject);										
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//1.获取块在原始节点中的位置
	if(bSrcLinkType == FREE_LINK)
	{
		nSrcOffset	  = lpFileObject->m_nFreeBlockMapOffset;
		nDestOffset	  = lpFileObject->m_nFullBlockMapOffset;

		pSrcLinkHead  = &lpFileObject->m_nFreeBlockMapOffset;
		pDestLinkHead = &lpFileObject->m_nFullBlockMapOffset;
	}
	else if(bSrcLinkType == FULL_LINK)
	{
		nSrcOffset	  = lpFileObject->m_nFullBlockMapOffset;
		nDestOffset   = lpFileObject->m_nFreeBlockMapOffset;

		pSrcLinkHead  = &lpFileObject->m_nFullBlockMapOffset;
		pDestLinkHead = &lpFileObject->m_nFreeBlockMapOffset;
	}
	if(0 == nSrcOffset)
	{
		//链表起始偏移错误
		Trace(_T("MoveMapStruct"), 0, 100001011, _T("错误！线程：%d，移动块：%d，错误码：%d"), GetCurrentThreadId(), nBlockNo, MF_MEMORYFILE_FINDMAPSTRUCT_INVALIDLIST_ERROR);
		return MF_MEMORYFILE_FINDMAPSTRUCT_INVALIDLIST_ERROR;			    
	}

	//遍历链表，寻找与nBlockNo相同的表项
	nPreOffset = nSrcOffset;
	while(nSrcOffset)
	{
		lpSrcBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nSrcOffset);
		if(lpSrcBlockMap->m_nBlockNo == nBlockNo)
		{
			break;
		}
		nPreOffset	= nSrcOffset;
		nSrcOffset	= lpSrcBlockMap->m_nNextOffset;
	}
	if(0 == nSrcOffset)
	{
		//未找到当前映射表结点
		Trace(_T("MoveMapStruct"), 0, 100001012, _T("错误！线程：%d，移动块：%d，错误码：%d"), GetCurrentThreadId(), nBlockNo, MF_MEMORYFILE_FINDMAPSTRUCT_NOBLOCKMATCH_ERROR);
		return MF_MEMORYFILE_FINDMAPSTRUCT_NOBLOCKMATCH_ERROR;					
	}

	//2.将块从原始链表中删除
	lpPreBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nPreOffset);
	if(nSrcOffset == nPreOffset)
	{
		//表示该块号对应的映射表结点在链表的开始位置
		//将该内存块从链表中移除
		*pSrcLinkHead = lpSrcBlockMap->m_nNextOffset;
	}
	else if(0 == lpSrcBlockMap->m_nNextOffset)
	{
		//表示该块号对应的映射表结点在链表的最后位置
		//将该内存块从链表中移除
		lpPreBlockMap->m_nNextOffset = 0;
	}
	else
	{
		//表示该块号对应的映射表结点在满块链表的中间位置
		//将该内存块从链表中移除
		lpPreBlockMap->m_nNextOffset = lpSrcBlockMap->m_nNextOffset;
	}
	
	//3.将块插入目标链表(插尾法)
	if(*pDestLinkHead == nSrcOffset)
	{
		return MF_MEMORYFILE_MOVEMAPSTRUCT_ERROR;
	}
	lpSrcBlockMap->m_nNextOffset = 0;
	
	nOffset = *pDestLinkHead;
	if(nOffset == 0)
	{
		*pDestLinkHead = nSrcOffset;
	}
	else
	{
		while(nOffset)
		{
			lpPreBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nOffset);
			nOffset		  = lpPreBlockMap->m_nNextOffset;
		}
		lpPreBlockMap->m_nNextOffset = nSrcOffset;
	}

	return MF_OK;
}

/************************************************************************
		功能说明：
			解锁块
		参数说明：
			lpExecutePlan：执行计划
			nBlockNo:块编号
************************************************************************/
int CMemoryFile::UnlockBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo)
{
	CMemoryBlock* pBlock;
	pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(nBlockNo);
	if(pBlock == NULL)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}
	pBlock->UnLockBlock(lpExecutePlan);
	return MF_OK;
}
/************************************************************************
		功能说明：
			锁定块
		参数说明：
			lpExecutePlan：执行计划
			nBlockNo:块编号
			dwMilliseconds：超时时间
************************************************************************/
int CMemoryFile::LockBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo, DWORD dwMilliseconds)
{
	int nRet;
	CMemoryBlock* pBlock;

	pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(nBlockNo);
	if(pBlock == NULL)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}
	
	nRet = pBlock->LockBlock(lpExecutePlan, dwMilliseconds);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			锁定块
		参数说明：
			lpExecutePlan：执行计划
			nDataID：数据ID
			dwMilliseconds：锁定时间
************************************************************************/
int CMemoryFile::LockBlock(LPEXECUTEPLANBSON lpExecutePlan, long long& nDataID, DWORD dwMilliseconds)
{
	int nRet, nBlockNo;
	CMemoryBlock* pBlock;

	nBlockNo = GetBlockNoFromDataID(nDataID);
	pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(nBlockNo);
	if(pBlock == NULL)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}
	
	nRet = pBlock->LockBlock(lpExecutePlan, dwMilliseconds);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			提供给Update的RollBack函数
		参数说明：
			lpExecutePlan：执行计划
			nDataID：数据ID
************************************************************************/
int CMemoryFile::UpdateRollBack(LPEXECUTEPLANBSON lpExecutePlan, long long nDataID)
{
	CMemoryBlock* pBlock;
	BOOL bFreePre, bFreeAfter;
	int nRet, nBlockNo, nObjectID;

	//1.根据DataID获得块对象指针，块编号和ObjectID
	pBlock = ConvertDataIDtoBlockObject(nDataID);					//根据DataID获得块对象指针
	if(NULL == pBlock)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}

	nBlockNo = GetBlockNoFromDataID(nDataID);						//根据DataID获得块编号
	nObjectID = pBlock->GetObjectID();								//获取ObjectID

	//2.如果块地址有效，则调用块级的UpdateData函数执行更新操作
	bFreePre = pBlock->RaitoStat() > FREEBLOCK_THRESHOLD;							//修改前块是否为可插块
	nRet = pBlock->UpdateRollBack(nDataID, lpExecutePlan->m_nTimestamp);		
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//3.修改完成后，判断是否需要将块移动到满块链表
	//修改完成后，数据有可能会增长，如果数据增长，也有可能会填满该块，那么就需要将块移动到满块队列(当然修改也可能发生在原本就位于满块队列中的块中)
	//注意：修改也可能造成数据缩短，对于数据缩短所空闲出来的空间，统一进行整理，所以这里并不判断是否需要将块从满块队列放入空块队列

	bFreeAfter = pBlock->RaitoStat() <= FREEBLOCK_THRESHOLD;						
	if(bFreePre && bFreeAfter)												
	{
		//如果修改前是一个可插块，而修改后是一个满块，则应该将该块对应的映射结点从可查块链表移动至满块链表
		nRet = MoveMapStruct(lpExecutePlan, lpExecutePlan->m_nObjectID, lpExecutePlan->m_bObjectType, nBlockNo, FREE_LINK);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			提供给Delete的回滚
		参数说明：
			nDataID：数据ID
			nTimestamp：时间戳
************************************************************************/
int CMemoryFile::DeleteRollBack(long long nDataID, long long nTimestamp)
{
	int nRet;
	CMemoryBlock* pBlock;
	//1.根据DataID获得块对象指针
	pBlock = ConvertDataIDtoBlockObject(nDataID);					//根据DataID获得块对象指针
	if(NULL == pBlock)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}

	//2.回滚
	nRet = pBlock->DeleteRollBack(nDataID, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			提供给Insert的回滚
		参数说明：
			nDataID：数据ID
			nTimestamp：时间戳
		特别说明：
			由于块级别不支持单条数据的内存回收，所以删除操作是无法回收内存的，对于内存的回收只有通过块整理来进行
			所以，如果数据插入失败，那么通过回滚是不能回收内存的
************************************************************************/
int CMemoryFile::InsertRollBack(long long nDataID, long long nTimestamp)
{
	int nRet;
	CMemoryBlock* pBlock;
	
	//1.根据DataID获得块对象指针
	pBlock = ConvertDataIDtoBlockObject(nDataID);					//根据DataID获得块对象指针
	if(NULL == pBlock)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}
	//2.回滚
	nRet = pBlock->InsertRollBack(nDataID, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	return MF_OK;
}  

/************************************************************************
		 功能说明：
			创建对象信息
		 参数说明：
			lpExecutePlan：执行计划
			nObjectID：对象ID
			bObjectType：对象类型
			nTimestamp：时间戳
************************************************************************/
int CMemoryFile::CreateObject(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, BYTE bObjectType, long long nTimestamp)
{
	int i;
	BOOL bFind;
	LPBASEFILEOBJECTDEF lpObjectDef;

	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileCritical(), lpExecutePlan);
	bFind = FALSE;
	lpObjectDef = m_lpMemoryFileHead->m_stFileObjectData;
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(lpObjectDef[i].m_nID == 0)
		{
			bFind = TRUE;
			memset(&lpObjectDef[i], 0, sizeof(BASEFILEOBJECTDEF));
			lpObjectDef[i].m_nID = nObjectID;
			break;
		}
	}
	if(!bFind)
	{
		return MF_INNER_SYS_FULLOBJECT_ERROR;
	}
	
	m_lpMemoryFileHead->m_nTimestamp = nTimestamp;
	return MF_OK;
}

/************************************************************************
	功能说明：
		获取某Object的所有记录数
	参数说明：
		lpExecutePlan：执行计划
		lpObjectInfo：对象信息
		lpTransactionArray:事务数组
		nDataNum：记录数
************************************************************************/
int CMemoryFile::GetObjectDataNum(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, LPTRANSACTIONARRAY lpTransactionArray, int& nDataNum)
{
	int nRet,nTempNum;
	LINKINFO stLinkInfo;
	CMemoryBlock* pBlock;

	memset(&stLinkInfo, 0, sizeof(LINKINFO));
	nDataNum = 0;
	//1.遍历满块链表
	stLinkInfo.m_bStart   = TRUE;
	stLinkInfo.m_bLikType = FULL_LINK; 
	stLinkInfo.m_bRelationObject = FALSE;
	while(TRUE)
	{
		nRet = GetBlockFromLink(lpExecutePlan, lpExecutePlan->m_nObjectID, &stLinkInfo, pBlock);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(pBlock == NULL)
		{
			break;
		}
		nTempNum = pBlock->GetDataNum(lpTransactionArray, lpExecutePlan->m_nTimestamp);
		nDataNum += nTempNum;
	}

	//2.遍历可插块链表
	stLinkInfo.m_bStart   = TRUE;
	stLinkInfo.m_bLikType = FREE_LINK; 
	while(TRUE)
	{
		nRet = GetBlockFromLink(lpExecutePlan, lpExecutePlan->m_nObjectID, &stLinkInfo, pBlock);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(pBlock == NULL)
		{
			break;
		}
		nTempNum = pBlock->GetDataNum(lpTransactionArray, lpExecutePlan->m_nTimestamp);
		nDataNum += nTempNum;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取对象记录数量
		参数说明：
			nObjectID：对象ID
			bObjectType：对象类型
		特别说明：
			该函数只被系统级的LoadObjectData函数调用，所以不需要加锁
************************************************************************/
long long* CMemoryFile::GetObjectDataPtr(int nObjectID, MF_OBJECT_TYPE bObjectType)
{
	int i;
	LPBASEFILEOBJECTDEF lpObjectDef;
	lpObjectDef = m_lpMemoryFileHead->m_stFileObjectData;

	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(lpObjectDef[i].m_nID == nObjectID)
		{
			return &lpObjectDef[i].m_nRecordNum;
		}
	}
	return NULL;
}

/************************************************************************
		功能说明：
			将记录与即将插入的位置进行绑定
		参数说明：
			stExecutePlanManager：执行计划对象
			nRecordNum：记录数
			arBlockInfo：arBlockInfo数组
		特别说明：
			在执行插入操作时，首先调用该函数，数据将被插入到那些块中，然后锁定这些块，最后再进行插入
			并且，插入操作将被限制到这些块中
***********************************************************************/
int CMemoryFile::BindDataID(CExecutePlanManager& stExecutePlanManager, int nRecordNum, LPBLOCKINFO arBlockInfo)
{
	UINT nAddrID;
	LINKINFO stLinkInfo;
	CMemoryBlock *pBlock;
	LPBLOCKINFO lpBlockInfo;
	LPRECORDHEAD lpRecordHead;
	LPEXECUTEPLANBSON lpExecutePlan;
	int	nRet, nBlockNo, i, j, n, nRecordLen, nBlockFreeSize, nDataSize, nBlockSize;

	lpExecutePlan = stExecutePlanManager.GetExecutePlan();
	lpBlockInfo   = (LPBLOCKINFO)((LPBYTE)lpExecutePlan + lpExecutePlan->m_stSourceInfo.m_nBlockOffset);
	//开始遍历可插块链表，寻找一个可以供数据插入的块
	memset(&stLinkInfo, 0, sizeof(LINKINFO));
	stLinkInfo.m_bRelationObject = FALSE;
	stLinkInfo.m_bStart			 = TRUE;
	stLinkInfo.m_bLock			 = TRUE;
	stLinkInfo.m_bLikType		 = FREE_LINK;

	stExecutePlanManager.Move2FirstRecord();
	do 
	{
		nRet = stExecutePlanManager.NextRecord(nAddrID, lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}while(nAddrID && lpRecordHead->m_bType != MF_EXECUTE_STEP_INSERTDATA);
	
	for(i = 0; i < nRecordNum;)
	{
		nRecordLen = lpRecordHead->m_nRecordLen;
		nDataSize  = 100 + (nRecordLen / 32 + 1) * 32;

		nRet = GetBlockFromLink(lpExecutePlan, lpExecutePlan->m_nObjectID, &stLinkInfo, pBlock);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(pBlock == NULL)
		{
			//分配新块将数据插入
			if(nDataSize > DEF_BLOCK_SIZE)
			{
				nBlockSize = (nDataSize / 1024 + 1) * 1024;
			}
			else
			{
				nBlockSize = DEF_BLOCK_SIZE;
			}
			
			nRet = AllocBlock(lpExecutePlan, nBlockNo, nBlockSize);							
			if(nRet != MF_OK)
			{
				return nRet;
			}
			
			//获取当前块的指针
			pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(nBlockNo);
			if(pBlock == NULL)
			{
				return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
			}
			//获取块空闲区大小
			nBlockFreeSize = (int)(pBlock->GetBlockFreeSize() - pBlock->GetBlockSize()*0.05);
			for(n = 0; n < 20; n++)
			{
				if(arBlockInfo[n].m_nBlockNo == nBlockNo)
				{
					arBlockInfo[n].m_nBlockSize = nBlockFreeSize - nDataSize;
					break;
				}
				else if(arBlockInfo[n].m_nBlockNo == 0)
				{
					arBlockInfo[n].m_nBlockNo	= nBlockNo;
					arBlockInfo[n].m_nBlockSize = nBlockFreeSize - nDataSize;
					break;
				}
			}
			if(n == 20)
			{
				Trace(_T("CMemoryFile::BindDataID"), 0, 30002001, _T("绑定DataID时，由于块数量众多，导致空间不足"));
				return MF_FAILED;
			}

			//为记录绑定DataID
			pBlock->AllocDataID(lpRecordHead);

			//切换到下一条记录
			nRet = stExecutePlanManager.NextRecord(nAddrID, lpRecordHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			i++;

			//从链表头开始遍历
			stLinkInfo.m_bStart	 = TRUE;
			continue;
		}
		else 
		{
			nBlockNo = stLinkInfo.m_nBlockNo;
			for(n = 0; n < 20; n++)
			{
				if(arBlockInfo[n].m_nBlockNo == nBlockNo)
				{
					break;
				}
				else if(arBlockInfo[n].m_nBlockNo == 0)
				{
					break;
				}
			}
			if(n == 20)
			{
				Trace(_T("CMemoryFile::BindDataID"), 0, 30002002, _T("绑定DataID时，由于块数量众多，导致空间不足"));
				return MF_FAILED;
			}

			if(arBlockInfo[n].m_nBlockNo != 0)
			{
				//如果arBlockInfo中存在块，则说明该块已经上锁，直接判断其是否有足够的空间进行数据插入
				nBlockFreeSize = arBlockInfo[n].m_nBlockSize;			
				if(nBlockFreeSize >= nDataSize)
				{
					pBlock->AllocDataID(lpRecordHead);

					nBlockFreeSize -= nDataSize;
					arBlockInfo[n].m_nBlockSize = nBlockFreeSize;

					nRet = stExecutePlanManager.NextRecord(nAddrID, lpRecordHead);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					i++;

					//从链表头开始遍历
					stLinkInfo.m_bStart = TRUE;
					continue;
				}
			}
			else
			{
				nBlockFreeSize = (int)(pBlock->GetBlockFreeSize() - pBlock->GetBlockSize()*0.05);					
				if(nBlockFreeSize >= nDataSize)
				{
					for(j = 0; j < MF_MAX_BLOCKINFO_NUM; j++)
					{
						//在GetBlockFromLink函数内已经对块进行了加锁操作，所以lpBlockInfo数组中一定会有记录
						if(lpBlockInfo[j].m_nBlockNo == nBlockNo)
						{
							break;
						}
					}
					if(j == MF_MAX_BLOCKINFO_NUM)
					{
						return MF_COMMON_INVALID_EXECUTEBLOCKNUM;	
					}

					lpBlockInfo[j].m_bSource    = MF_SOURCE_FROM_EXISTBLOCK;
					lpBlockInfo[j].m_nBlockSize = pBlock->GetBlockSize();
					lpBlockInfo[j].m_bAlloc     = 1;
					lpBlockInfo[j].m_bObjectType= lpExecutePlan->m_bObjectType;

					pBlock->AllocDataID(lpRecordHead);
				
					nBlockFreeSize -= nDataSize;
					
					arBlockInfo[n].m_nBlockNo	= nBlockNo;
					arBlockInfo[n].m_nBlockSize = nBlockFreeSize;
					
					nRet = stExecutePlanManager.NextRecord(nAddrID, lpRecordHead);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					i++;
					
					//从链表头开始遍历
					stLinkInfo.m_bStart = TRUE;
					continue;
				}
				else
				{
					pBlock->UnLockBlock(lpExecutePlan);
				}
			}
		}		
	}
	return MF_OK;
}
/************************************************************************
		功能说明：
			将数据写入内存
		参数说明：
			stBson:Bson对象
			lpBaseParam:公共参数
			lpStep：执行步骤
		特别说明：
			插入步骤如下：
			1.根据nObjectID获得对应的Object
			2.遍历该Object的可插链表，得到链表中某可插块的指针
			3.用块指针调用块级别的Insert操作进行插入操作
			4.块级的insert操作会判断是否有足够的空间进行插入操作，如果空间不够则插入失败，返回False，此时文件级继续遍历可插链表
			5.如果可插链表中没有空闲区足够大的块来插入数据，则分配一个新块来进行数据插入
			6.数据插入完成后，根据块内空闲区的大小判断是否需要将该块的映射表结点移到满块链表中
***********************************************************************/
int CMemoryFile::InsertData(CServiceBson& stBson, LPBASESTEPPARAM lpBaseParam, LPEXECUTESTEP lpStep)
{
	BOOL bFreeLink;
	CMemoryBlock* pBlock;
	LPBYTE lpData, lpAddr;
	int nRet, nBlockNo, nLen;
	LPRECORDHEAD lpRecordHead;
	RECORDDATAINFO stRecordInfo;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	nRet = stBson.ConvertAddrID2Addr((UINT)lpStep->m_nParam1, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpRecordHead = (LPRECORDHEAD)lpAddr;
	
	lpData	 = (LPBYTE)lpBaseParam->m_lpRecordBuffer;
	nLen	 = lpRecordHead->m_nRecordLen;
	nBlockNo = GetBlockNoFromDataID(lpRecordHead->m_nDataID);

	//1.根据DataID获得块对象指针
	pBlock = ConvertDataIDtoBlockObject(lpRecordHead->m_nDataID);					
	if(NULL == pBlock)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}
	if(pBlock->IsFull(nLen))
	{
		return MF_MEMORYFILE_INSERTDATA_NOENOUGHMEMORY_ERROR;
	}

	//判断插入前块是否在空块链表中
	bFreeLink = FindBlockInLink(lpExecutePlan, lpExecutePlan->m_nObjectID, FREE_LINK, lpExecutePlan->m_bObjectType, nBlockNo);
		
	stRecordInfo.m_bRecordType		= lpBaseParam->m_bRecordType;
	stRecordInfo.m_lpRecordBuffer   = lpData;
	stRecordInfo.m_nRecordLen		= nLen;
	stRecordInfo.m_nTimestamp		= lpBaseParam->m_nTimestamp;
	nRet = pBlock->InsertData(&stRecordInfo, lpRecordHead);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//2.插入成功，则计算插入后块空闲区的大小和块总大小的比例
	if(bFreeLink && pBlock->RaitoStat() <= FREEBLOCK_THRESHOLD)
	{
		if(pBlock->FreeMemoryStat() > 0.4)
		{
			//整理块
			nRet = pBlock->MergeMemory();
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else
		{
			//将块从空块链表移动到满块链表
			nRet = MoveMapStruct(lpExecutePlan, lpExecutePlan->m_nObjectID, lpExecutePlan->m_bObjectType, nBlockNo, FREE_LINK);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}
	return MF_OK;
}

int CMemoryFile::InsertData(int nObjectID, MF_OBJECT_TYPE bObjectType, LPBYTE lpBuffer, int nLen, long long nTimestamp, long long& nDataID)
{
	BOOL bFreeLink;
	LINKINFO stLinkInfo;
	CMemoryBlock* pBlock;
	RECORDHEAD stRecordHead;
	RECORDDATAINFO stRecordInfo;
	int nRet, nDataSize, nBlockNo, nBlockFreeSize, nBlockSize;

	nDataSize  = 100 + (nLen / 32 + 1) * 32;
	stLinkInfo.m_bRelationObject = FALSE;
	stLinkInfo.m_bStart		 = TRUE;
	stLinkInfo.m_bLock		 = FALSE;
	stLinkInfo.m_bLikType	 = FREE_LINK;
	while(TRUE)
	{
		nRet = GetBlockFromLink(NULL, nObjectID, &stLinkInfo, pBlock);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(pBlock != NULL)
		{
			nBlockNo = stLinkInfo.m_nBlockNo;
			nBlockFreeSize = pBlock->GetBlockFreeSize();					
			if(nBlockFreeSize > nDataSize)
			{
				break;
			}
		}
		else
		{
			break;
		}
	}
	
	if(pBlock == NULL)
	{
		//分配新块将数据插入
		if(nDataSize > DEF_BLOCK_SIZE)
		{
			nBlockSize = (nDataSize / 1024 + 1) * 1024;
		}
		else
		{
			nBlockSize = DEF_BLOCK_SIZE;
		}

		nRet = AllocBlock(nObjectID, bObjectType, nBlockSize, nTimestamp, nBlockNo);							
		if(nRet != MF_OK)
		{
			return nRet;
		}

		//获取当前块的指针
		pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(nBlockNo);
		if(pBlock == NULL)
		{
			return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
		}
	}
	//判断插入前块是否在空块链表中
	bFreeLink = FindBlockInLink(NULL, nObjectID, FREE_LINK, bObjectType, nBlockNo);

	pBlock->AllocDataID(&stRecordHead);
	stRecordInfo.m_lpRecordBuffer = lpBuffer;
	stRecordInfo.m_nRecordLen	  = nLen;
	nRet = pBlock->InsertData(&stRecordInfo, &stRecordHead);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nDataID = stRecordHead.m_nDataID;

	//2.插入成功，则计算插入后块空闲区的大小和块总大小的比例
	if(bFreeLink && pBlock->RaitoStat() <= FREEBLOCK_THRESHOLD/32)
	{
		if(pBlock->FreeMemoryStat() > 0.4)
		{
			//整理块
			nRet = pBlock->MergeMemory();
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else
		{
			//将块从空块链表移动到满块链表
			nRet = MoveMapStruct(NULL, nObjectID, bObjectType, nBlockNo, FREE_LINK);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}
	return MF_OK;
}
/************************************************************************
		功能说明：
			修改内存文件的对应数据
		参数说明：
			stBson:Bson对象
			lpBaseParam:公共参数
			lpStep：执行步骤
		特别说明：
			更新步骤如下：
			1.根据DataID获得块对象指针，块编号和ObjectID
			2.调用块级的UpdateData函数执行更新操作
			3.修改完成后，判断是否需要将块移动到满块链表
************************************************************************/
int CMemoryFile::UpdateData(CServiceBson& stBson, LPBASESTEPPARAM lpBaseParam, LPEXECUTESTEP lpStep)
{
	long long nDataID;
	CMemoryBlock* pBlock;
	LPBYTE lpData, lpAddr;
	int nRet, nBlockNo, nLen;
	LPRECORDHEAD lpRecordHead;
	BOOL bFreePre, bFreeAfter;
	RECORDDATAINFO stRecordInfo;
	LPEXECUTEPLANBSON lpExecutePlan;
	lpExecutePlan= (LPEXECUTEPLANBSON)stBson.GetBuffer();

	nRet = stBson.ConvertAddrID2Addr((UINT)lpStep->m_nParam1, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpRecordHead = (LPRECORDHEAD)lpAddr;
	nLen		 = lpRecordHead->m_nRecordLen;
	lpData		 = (LPBYTE)lpBaseParam->m_lpRecordBuffer;

	nDataID		= lpRecordHead->m_nDataID;
	nBlockNo	= GetBlockNoFromDataID(nDataID);

	//1.根据DataID获得块对象指针，块编号和ObjectID
	pBlock = ConvertDataIDtoBlockObject(nDataID);					//根据DataID获得块对象指针
	if(NULL == pBlock)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}
 	nBlockNo = GetBlockNoFromDataID(nDataID);						//根据DataID获得块编号

 	//2.如果块地址有效，则调用块级的UpdateData函数执行更新操作
	bFreePre = pBlock->RaitoStat() > FREEBLOCK_THRESHOLD;							//修改前块是否为可插块
	
	stRecordInfo.m_bRecordType		= lpBaseParam->m_bRecordType;
	stRecordInfo.m_nDataID			= nDataID;
	stRecordInfo.m_lpRecordBuffer	= lpData;
	stRecordInfo.m_nRecordLen		= nLen;
	stRecordInfo.m_nTimestamp		= lpBaseParam->m_nTimestamp;
	nRet = pBlock->UpdateData(stBson, &stRecordInfo);		
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//3.修改完成后，判断是否需要将块移动到满块链表
	//修改完成后，数据有可能会增长，如果数据增长，也有可能会填满该块，那么就需要将块移动到满块队列(当然修改也可能发生在原本就位于满块队列中的块中)
	//注意：修改也可能造成数据缩短，对于数据缩短所空闲出来的空间，统一进行整理，所以这里并不判断是否需要将块从满块队列放入空块队列
	bFreeAfter = pBlock->RaitoStat() <= FREEBLOCK_THRESHOLD;						
	if(bFreePre && bFreeAfter)													
	{
		//如果修改前是一个可插块，而修改后是一个满块，则应该将该块对应的映射结点从可查块链表移动至满块链表
		nRet = MoveMapStruct(lpExecutePlan, lpExecutePlan->m_nObjectID, lpExecutePlan->m_bObjectType, nBlockNo, FREE_LINK);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;	
}
/************************************************************************
		功能说明：
			从内存文件中删除对应数据
		参数说明：
			stBson:Bson对象
			lpBaseParam:公共参数
			lpStep：执行步骤
		特别说明：
			1.根据nDataID得到块对象的指针
			2.调用块级的DeleteData函数进行数据删除
************************************************************************/
int CMemoryFile::DeleteData(CServiceBson& stBson, LPBASESTEPPARAM lpBaseParam, LPEXECUTESTEP lpStep)
{
	int nRet;
	LPBYTE lpAddr;
	long long nDataID;
	CMemoryBlock* pBlock;
	LPRECORDHEAD lpRecordHead;
	RECORDDATAINFO stRecordInfo;

	nRet = stBson.ConvertAddrID2Addr((UINT)lpStep->m_nParam1, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpRecordHead = (LPRECORDHEAD)lpAddr;
	nDataID		 = lpRecordHead->m_nDataID;
	//1.根据nDataID得到块对象的指针
 	pBlock = ConvertDataIDtoBlockObject(nDataID);		
	if(NULL == pBlock)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}
	
	//2.调用块级的DeleteData函数进行数据删除
	stRecordInfo.m_nDataID    = nDataID;
	stRecordInfo.m_nTimestamp = lpBaseParam->m_nTimestamp;
	nRet = pBlock->DeleteData(stBson, &stRecordInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;			
}

int CMemoryFile::DeleteData(CServiceBson& stBson, long long nDataID)
{
	int nRet, nBlockNo;
	CMemoryBlock* pBlock;
	RECORDDATAINFO stRecordInfo;
	LPEXECUTEPLANBSON lpExecutePlan;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();

	//锁定待删除的块
	nRet = LockBlock(lpExecutePlan, nDataID, MF_LOCK_OUTOFTIME);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	nBlockNo = GetBlockNoFromDataID(nDataID);
	//获取待删除的块
	pBlock = ConvertDataIDtoBlockObject(nDataID);		
	if(NULL == pBlock)
	{
		UnlockBlock(lpExecutePlan, nBlockNo);
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}

	//删除记录
	stRecordInfo.m_nDataID    = nDataID;
	stRecordInfo.m_nTimestamp = lpExecutePlan->m_nTimestamp;
	nRet = pBlock->DeleteData(stBson, &stRecordInfo);
	if(nRet != MF_OK)
	{
		UnlockBlock(lpExecutePlan, nBlockNo);
		return nRet;
	}
	
	UnlockBlock(lpExecutePlan, nBlockNo);
	return MF_OK;
}
/************************************************************************
		功能说明：
			用于进行数据块内存整理。
		参数说明：
			lpExecutePlan：执行计划
************************************************************************/
int CMemoryFile::MergeMemory(LPEXECUTEPLANBSON lpExecutePlan)
{
	CMemoryBlock* pBlock;
	int i, nRet, nBlockNum;
	LPBLOCKINFO lpBlockInfo;

	nBlockNum   = lpExecutePlan->m_stSourceInfo.m_nBlockNoNum;
	lpBlockInfo = (LPBLOCKINFO)((LPBYTE)lpExecutePlan + lpExecutePlan->m_stSourceInfo.m_nBlockOffset);
	for(i = 0; i < nBlockNum; i++)
	{
		pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(lpBlockInfo[i].m_nBlockNo);
		if(pBlock == NULL)
		{
			return NULL;
		}

		if(pBlock->RaitoStat() <= FREEBLOCK_THRESHOLD && pBlock->FreeMemoryStat() > 0.4)
		{
			nRet = pBlock->MergeMemory();
			if(nRet != MF_OK)
			{
				return nRet;
			}

			//如果整理后空闲空间>0.4则将块从满块链表移动到可插块链表
			nRet = MoveMapStruct(lpExecutePlan, lpExecutePlan->m_nObjectID, lpExecutePlan->m_bObjectType, lpBlockInfo[i].m_nBlockNo, FULL_LINK);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}
	return MF_OK; 
}

/************************************************************************
		功能说明：
			删除对象
		参数说明：
			lpExecutePlan：执行计划
			nObjectID：对象ID
			bRelationObject：是否是关系对象
************************************************************************/
int CMemoryFile::DropObject(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID)
{
	int nRet, i;
	LPOBJECTDEF lpObject;
	LPBASEFILEOBJECTDEF lpObjectInfo;
	LPBASEFILEBLOCKMAP lpFileBlockMap;
	long long nBlockMapOffset, nNextOffset;
	

	nRet = CSystemManage::instance().GetObjectInfo(nObjectID, lpObject);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	CExecutePlanCriticalPtr critBlockMap(CSystemManage::instance().GetDataFileBlockMapCritical(), lpExecutePlan);
	CExecutePlanCriticalPtr critDataFileMap(CSystemManage::instance().GetDataFileCritical(), lpExecutePlan);

	//1.根据nObjectID获得ObjectInfo
	nRet = GetFileObject(nObjectID, lpObjectInfo, FALSE);
	if(nRet != MF_OK)
	{
		//空表，直接返回
		return MF_OK;
	}

	//2.遍历满块链表，回收满块链表中的块
	nBlockMapOffset = lpObjectInfo->m_nFullBlockMapOffset;
	while(nBlockMapOffset)
	{	
		lpFileBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nBlockMapOffset);
		nNextOffset   = lpFileBlockMap->m_nNextOffset;

		lpFileBlockMap->m_nNextOffset = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
		m_lpMemoryFileHead->m_nFreeBlockMapOffset = nBlockMapOffset;

		nBlockMapOffset = nNextOffset;
	}

	//3.遍历可插块链表，回收可插块链表中的块
	nBlockMapOffset = lpObjectInfo->m_nFreeBlockMapOffset;
	while(nBlockMapOffset)
	{
		lpFileBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nBlockMapOffset);
		nNextOffset   = lpFileBlockMap->m_nNextOffset;

		lpFileBlockMap->m_nNextOffset = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
		m_lpMemoryFileHead->m_nFreeBlockMapOffset = nBlockMapOffset;

		nBlockMapOffset = nNextOffset;
	}

	//4.将ObjectID从链表中删除
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(nObjectID == m_lpMemoryFileHead->m_stFileObjectData[i].m_nID)
		{
			m_lpMemoryFileHead->m_stFileObjectData[i].m_nID = 0;
			m_lpMemoryFileHead->m_stFileObjectData[i].m_nFreeBlockMapOffset = 0;
			m_lpMemoryFileHead->m_stFileObjectData[i].m_nFullBlockMapOffset = 0;
			break;
		}
	}

	return MF_OK;
}

/************************************************************************
		功能说明：
			获取文件的空间信息
		参数说明：	
			lpExecutePlan：执行计划
			nFileTotalSize：文件总大小
			nFileUseSize：用户使用空间
			nFileFreeSize：剩余空间
************************************************************************/
int CMemoryFile::GetFileSpace(LPEXECUTEPLANBSON lpExecutePlan, long long &nFileTotalSize, long long &nFileUseSize, long long &nFileFreeSize)
{
	LPBASEBLOCKHEAD lpBlockHead;
	long long nFreeBlockMapOffset;
	LPBASEFILEBLOCKMAP lpBlockMap;

	CExecutePlanCriticalPtr critDataFileMap(CSystemManage::instance().GetDataFileCritical(), lpExecutePlan);
	nFileTotalSize = m_lpMemoryFileHead->m_nFileTotalSize;
	nFileFreeSize  = m_lpMemoryFileHead->m_nFileFreeSize;

	nFreeBlockMapOffset = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
	while(nFreeBlockMapOffset)
	{
		lpBlockMap  = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nFreeBlockMapOffset);
		lpBlockHead = (LPBASEBLOCKHEAD)(m_lpFileAddr + lpBlockMap->m_nBlockOffset);
		nFileFreeSize += lpBlockHead->m_nBlockSize;
		nFreeBlockMapOffset = lpBlockMap->m_nNextOffset;
	}

	nFileUseSize   = nFileTotalSize - nFileFreeSize;
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取块空闲空间大小
		参数说明：
			nBlockNo：块编号
			nFreeSize：空闲空间大小
************************************************************************/
int CMemoryFile::GetBlockFreeSize(int nBlockNo, int& nFreeSize)
{
	CMemoryBlock* pBlock;

	pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(nBlockNo);
	if(pBlock == NULL)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}

	nFreeSize = pBlock->GetBlockFreeSize();
	return MF_OK;
}

/************************************************************************
		功能说明:
			设置对象信息
		参数说明：
			nObjectID：对象ID
			lpExecutePlan：执行计划
			bObjectType：对象类型
			nInsertDataNum：插入记录数
			nDeleteDataNum：删除记录数
			nTimestamp：时间戳
************************************************************************/
void CMemoryFile::SetObjectData(int nObjectID, LPEXECUTEPLANBSON lpExecutePlan, MF_OBJECT_TYPE bObjectType, long long nInsertDataNum, long long nDeleteDataNum, long long nTimestamp)
{
	int i;
	LPBASEFILEOBJECTDEF lpBaseFileObject;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetDataFileCritical(), lpExecutePlan);

	lpBaseFileObject = m_lpMemoryFileHead->m_stFileObjectData;
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(lpBaseFileObject[i].m_nID == nObjectID)
		{
			lpBaseFileObject[i].m_nFinishedTimestamp = nTimestamp;
			lpBaseFileObject[i].m_nRecordNum += nInsertDataNum;
			lpBaseFileObject[i].m_nRecordNum -= nDeleteDataNum;
			break;
		}
	}
}

/************************************************************************
	功能说明：
		数据备份
	参数说明：
		nDataID：数据ID
		nTimestamp：时间戳
************************************************************************/
int CMemoryFile::DataBackUp(long long nDataID, long long nTimestamp)
{
	CMemoryBlock* pBlock;
	pBlock = ConvertDataIDtoBlockObject(nDataID);		
	if(pBlock == NULL)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;		//转换失败
	}
	return pBlock->DataBackup(nDataID, nTimestamp);
}

/************************************************************************
	功能说明：
		闪回
	参数说明：
		nBlockNo：块编号
		pBuffer：块Buffer
		nTimestamp：时间戳
************************************************************************/
int CMemoryFile::FlashBack(int nBlockNo, LPBYTE &lpBuffer, long long nTimestamp)
{
	CMemoryBlock* pBlock;

	pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(nBlockNo);
	if(pBlock == NULL)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}
	return pBlock->FlashBack(lpBuffer, nTimestamp);
}

/************************************************************************
		功能说明：
			清理文件数据
************************************************************************/
void CMemoryFile::ClearDataFile()
{
	int i, j;
	CMemoryBlock* pBlock;
	EXECUTEPLANBSON stExecutePlan;
	LPBASEFILEOBJECTDEF lpObjectInfo;
	LPBASEFILEBLOCKMAP lpFileBlockMap;
	long long nBlockMapOffset, nNextOffset;

	CExecutePlanCriticalPtr critBlockMap(CSystemManage::instance().GetDataFileBlockMapCritical(), &stExecutePlan);
	
	//判断文件中是否存在活动事务
	if(CSystemManage::instance().CheckTransactionFinish(m_lpMemoryFileHead->m_nTimestamp))
	{
		return;
	}
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		lpObjectInfo = &m_lpMemoryFileHead->m_stFileObjectData[i];
		for(j = 0; j < 2; j++)
		{
			//遍历满块链表，进行块数据清理
			nBlockMapOffset = lpObjectInfo->m_nFullBlockMapOffset;
			while(nBlockMapOffset)
			{	
				lpFileBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nBlockMapOffset);
				nNextOffset    = lpFileBlockMap->m_nNextOffset;

				pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(lpFileBlockMap->m_nBlockNo);
				if(pBlock == NULL)
				{
					Trace(_T("ClearDataFile"), 0, 30001001, _T("清理文件时，发现满块链表上有数据块未找到，块编号%d"), lpFileBlockMap->m_nBlockNo);
					nBlockMapOffset = nNextOffset;
					continue;
				}
				pBlock->ClearBlockData();

				nBlockMapOffset = nNextOffset;
			}

			//遍历可插块链表，进行块数据清理
			nBlockMapOffset = lpObjectInfo->m_nFreeBlockMapOffset;
			while(nBlockMapOffset)
			{
				lpFileBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nBlockMapOffset);
				nNextOffset    = lpFileBlockMap->m_nNextOffset;

				pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(lpFileBlockMap->m_nBlockNo);
				if(pBlock == NULL)
				{
					Trace(_T("ClearDataFile"), 0, 30001002, _T("清理文件时，发现空块链表上有数据块未找到，块编号%d"), lpFileBlockMap->m_nBlockNo);
					nBlockMapOffset = nNextOffset;
					continue;
				}
				pBlock->ClearBlockData();

				nBlockMapOffset = nNextOffset;
			}

			//图数据库
			lpObjectInfo = &m_lpMemoryFileHead->m_stFileRelationData[i];
		}
	}
}

/************************************************************************
		功能说明：
			下一条记录Buffer（用于全表遍历）
		参数说明：
			lpExecutePlan：执行计划
			nObjectID：对象ID
			bRelation：是否为关系表
			bLikType：块链表类型
			nBlockMapOffset：块映射表偏移
			nInnerDataNo：记录编号
			nDataID：记录ID
		特别说明：
			根据当前记录的DataID返回表中下一条记录的DataID
************************************************************************/
int CMemoryFile::GetNextDataID(LPEXECUTEPLANBSON lpExecutePlan, int nObjectID, BOOL bRelation, LINK_TYPE& bLikType, long long& nBlockMapOffset, int& nInnerDataNo, long long& nDataID)
{
	int nRet, nBlockNo;
	CMemoryBlock* pBlock;
	LPBASEFILEBLOCKMAP lpBlockMap;

	if(nBlockMapOffset == 0)
	{
GETFIRSTBLOCK:
		if(bLikType == 0)
		{
			bLikType = FULL_LINK;
		}
		else if(bLikType == FULL_LINK)
		{
			bLikType = FREE_LINK;
		}
		else 
		{
			nDataID = 0;
			return MF_OK;
		}

		//获取该Object对应的第一条记录
		nRet = GetStartBlockMapOffset(lpExecutePlan, nObjectID, bLikType, bRelation, nBlockMapOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(nBlockMapOffset == 0)
		{
			goto GETFIRSTBLOCK;
		}
	}

	lpBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nBlockMapOffset);
	nBlockNo   = lpBlockMap->m_nBlockNo;
	pBlock	   = (CMemoryBlock*)m_mapMemoryBlock.Get(nBlockNo);
	if(pBlock == NULL)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
	}
	nRet = pBlock->GetNextDataID(nInnerDataNo, nDataID);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(nInnerDataNo == 0)
	{
		//切换到下一个块
		GetNextBlockMapOffset(lpExecutePlan, nBlockMapOffset);
	}

	return MF_OK;
}
/************************************************************************
		功能说明：
			获取记录Buffer
		参数说明：
			stBson：BSON对象，提供缓存空间
			lpRecordInfo：记录信息
************************************************************************/
int CMemoryFile::GetRecordBuffer(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo)
{
	CMemoryBlock* pBlock;
	//1.根据nDataID获得对应的Block
	pBlock = ConvertDataIDtoBlockObject(lpRecordInfo->m_nDataID);		
	if(pBlock == NULL)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;		//转换失败
	}

	//调用块级函数获取块指针
	return pBlock->GetRecordBuffer(stBson, lpRecordInfo);
}

/************************************************************************
		功能说明：
			获取记录指针
		参数说明：
			lpRecordInfo：记录信息
************************************************************************/
int CMemoryFile::GetRecordPtr(LPRECORDDATAINFO lpRecordInfo)
{
	CMemoryBlock* pBlock;
	//1.根据nDataID获得对应的Block
	pBlock = ConvertDataIDtoBlockObject(lpRecordInfo->m_nDataID);		
	if(pBlock == NULL)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;		//转换失败
	}

	//调用块级函数获取块指针
	return pBlock->GetRecordPtr(lpRecordInfo);
}

/************************************************************************
		功能说明：
			获取记录中的字段值
		参数说明：
			stBson：BSON对象提供缓存空间
			pExpression：表达式类
			lpRecordInfo：记录信息
			bFieldNo：字段编号
			varResult：字段值
************************************************************************/
int CMemoryFile::GetRecordFieldValue(CServiceBson* pBson, CExpression* pExpression, LPRECORDDATAINFO lpRecordInfo, BYTE bFieldNo, VARDATA& varResult)
{
	CMemoryBlock* pBlock;
	//1.根据nDataID获得对应的Block
	pBlock = ConvertDataIDtoBlockObject(lpRecordInfo->m_nDataID);		
	if(pBlock == NULL)
	{
		return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;		//转换失败
	}

	//调用块级函数获取块指针
	return pBlock->GetRecordFieldValue(pBson, pExpression, lpRecordInfo, bFieldNo, varResult);
}

/************************************************************************
		功能说明：
			导出表
		参数说明：
			stBson：Bson对象
			nObjectID：对象ID
			lpExportParam：导出参数
			nTimestamp：时间戳
			lpTransactionArray：事务数组
************************************************************************/
int CMemoryFile::ExportObject(CServiceBson& stBson, int nObjectID, LPEXPORTPARAM lpExportParam, long long nTimestamp, LPTRANSACTIONARRAY lpTransactionArray)
{
	BOOL bFinish;
	int nRet, nBlockNo;
	CMemoryBlock* pBlock;
	LPBASEFILEBLOCKMAP lpBlockMap;

	if(lpExportParam->m_nBlockMapOffset == 0)
	{
GETFIRSTBLOCK:
		if(lpExportParam->m_bLikType == 0)
		{
			lpExportParam->m_bLikType = FULL_LINK;
		}
		else if(lpExportParam->m_bLikType == FULL_LINK)
		{
			lpExportParam->m_bLikType = FREE_LINK;
		}
		else 
		{
			lpExportParam->m_bComplete = TRUE;
			return MF_OK;
		}

		//获取该Object对应的第一个块
		nRet = GetStartBlockMapOffset(NULL, nObjectID, lpExportParam->m_bLikType, lpExportParam->m_bRelation, lpExportParam->m_nBlockMapOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpExportParam->m_nBlockMapOffset == 0)
		{
			goto GETFIRSTBLOCK;
		}
	}

	while(TRUE)
	{
		lpBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + lpExportParam->m_nBlockMapOffset);
		nBlockNo   = lpBlockMap->m_nBlockNo;
		pBlock	   = (CMemoryBlock*)m_mapMemoryBlock.Get(nBlockNo);
		if(pBlock == NULL)
		{
			return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
		}

		bFinish = FALSE;
		nRet = pBlock->ExportObject(stBson, nObjectID, nTimestamp, lpTransactionArray, lpExportParam->m_nInnerDataPos, lpExportParam->m_nRecordNum, bFinish);
		if(nRet != MF_OK)
		{
			if(nRet == MF_PARSECMD_EXECUTEPALN_LACKSPACE_ERROR)
			{
				//Buffer空间不足
				return MF_OK;
			}
			else
			{
				return nRet;
			}
		}
		if(bFinish)
		{
			//切换到下一个块
			lpExportParam->m_nInnerDataPos = 0;
			GetNextBlockMapOffset(NULL, lpExportParam->m_nBlockMapOffset);
			if(lpExportParam->m_nBlockMapOffset == 0)
			{
				goto GETFIRSTBLOCK;
			}
		}
	}

	return MF_OK;
}

/************************************************************************
		功能说明：
			获取记录数量
************************************************************************/
long long CMemoryFile::GetRecordNum()
{
	int i;
	long long nRecordNum;
	CMemoryBlock* pBlock;
	LPBASEFILEOBJECTDEF lpObjectInfo;
	LPBASEFILEBLOCKMAP lpFileBlockMap;
	long long nBlockMapOffset, nNextOffset;

	nRecordNum = 0;
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		lpObjectInfo = &m_lpMemoryFileHead->m_stFileObjectData[i];
		
		//遍历满块链表，进行块数据清理
		nBlockMapOffset = lpObjectInfo->m_nFullBlockMapOffset;
		while(nBlockMapOffset)
		{	
			lpFileBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nBlockMapOffset);
			nNextOffset    = lpFileBlockMap->m_nNextOffset;

			pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(lpFileBlockMap->m_nBlockNo);
			if(pBlock == NULL)
			{
				continue;
			}

			nRecordNum += pBlock->GetRecordNum();
			nBlockMapOffset = nNextOffset;
		}

		//遍历可插块链表，进行块数据清理
		nBlockMapOffset = lpObjectInfo->m_nFreeBlockMapOffset;
		while(nBlockMapOffset)
		{
			lpFileBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nBlockMapOffset);
			nNextOffset    = lpFileBlockMap->m_nNextOffset;

			pBlock = (CMemoryBlock*)m_mapMemoryBlock.Get(lpFileBlockMap->m_nBlockNo);
			if(pBlock == NULL)
			{
				continue;
			}
			
			nRecordNum += pBlock->GetRecordNum();
			nBlockMapOffset = nNextOffset;
		}
	}

	return nRecordNum;
}

/************************************************************************
		功能说明：
			备份文件数据
		参数说明：
			lpBuffer：文件头Buffer
			nBufferSize：Buffer大小
************************************************************************/
int CMemoryFile::BackUpFileData(LPBYTE lpBuffer, int nBufferSize)
{
	//上锁
	int nHeadBufferSize;
	LPBASEFILEBLOCKMAPHEAD lpMasterBaseFileBlockMapHead, lpSlaveBaseFileBlockMapHead;

	CExecutePlanCriticalPtr csFile(CSystemManage::instance().GetDataFileCritical(), NULL);
	CExecutePlanCriticalPtr csMap(CSystemManage::instance().GetDataFileBlockMapCritical(), NULL);
	if(m_lpMemoryFileHead->m_nFileHeaderSize > nBufferSize)
	{
		return MF_FLASHBACK_INVALID_BUFFER_SIZE;
	}
	else
	{
		//先备份文件头
		memcpy(lpBuffer, m_lpFileAddr, m_lpMemoryFileHead->m_nFileHeaderSize);
	}
	

	lpMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nBlockMapStartOffset);
	lpSlaveBaseFileBlockMapHead  = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nBlockMapStartOffset + m_lpMemoryFileHead->m_nBlockMapSize);
	while(TRUE)
	{
		nHeadBufferSize = sizeof(BASEFILEBLOCKMAPHEAD) + m_lpMemoryFileHead->m_nBlockMapStructSize*(lpMasterBaseFileBlockMapHead->m_nBlockMapNum - 1);

		//检测映射表大小
		if (nHeadBufferSize > (DWORD)m_lpMemoryFileHead->m_nBlockMapSize)
		{
			return MF_FLASHBACK_INVALID_MAP_SIZE;
		}

		memcpy((LPBYTE)lpSlaveBaseFileBlockMapHead, (LPBYTE)lpMasterBaseFileBlockMapHead, m_lpMemoryFileHead->m_nBlockMapSize);
		if(lpMasterBaseFileBlockMapHead->m_nNextBlockMapOffset != 0)
		{
			lpMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + lpMasterBaseFileBlockMapHead->m_nNextBlockMapOffset);
			lpMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + lpMasterBaseFileBlockMapHead->m_nNextBlockMapOffset + m_lpMemoryFileHead->m_nBlockMapSize);
		}
		else
		{
			break;
		}
	}
	return MF_OK;
}