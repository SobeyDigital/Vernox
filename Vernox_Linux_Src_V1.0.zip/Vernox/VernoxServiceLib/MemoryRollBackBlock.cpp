﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryRollBackBlock.h"

#define MF_BASE_TIME 516269953590000000


CMemoryRollBackBlock::CMemoryRollBackBlock(int nSize)
{
	m_pBlockAddr = NULL;
	m_pBlockBody = NULL;
	m_pBlockHead = NULL;

	InitialBlock(nSize);

	// 在进入多线程环境之前，初始化临界区  
	::InitializeCriticalSection(&m_CritRollbackBlock); 
}

CMemoryRollBackBlock::~CMemoryRollBackBlock(void)
{
	// 释放临界区资源，当不再使用临界区时调用该函数  
	::DeleteCriticalSection(&m_CritRollbackBlock); 
	delete []m_pBlockAddr;
}

LPBYTE CMemoryRollBackBlock::AllocBlockNewData(int nSize, UINT& nTimestamp,  int &nVarDataOffset)
{
	CCriticalSectionPtr cs(&m_CritRollbackBlock);

	int nTotalDataLen;
	LPROLLBACKBLOCKVARDATASTRUCT pVarDataAddr;
	
	nTotalDataLen = nSize + sizeof(ROLLBACKBLOCKVARDATASTRUCT);
	if(m_pBlockHead->m_nVarDataInsertPos + nTotalDataLen <= m_pBlockHead->m_nRollbackTotalSize)
	{
		nVarDataOffset = m_pBlockHead->m_nVarDataInsertPos;
		m_pBlockHead->m_nVarDataInsertPos += nTotalDataLen;	
		m_pBlockHead->m_nCurTimestamp =	 nTimestamp;
	}
	else
	{
		m_pBlockHead->m_nVarDataInsertPos = m_pBlockHead->m_nRollbackHeadSize;
		nVarDataOffset = m_pBlockHead->m_nVarDataInsertPos;
		m_pBlockHead->m_nVarDataInsertPos += nTotalDataLen;	
		if(m_pBlockHead->m_nCurTimestamp == nTimestamp)
		{
			nTimestamp += 1;
		}
		m_pBlockHead->m_nPreTimestamp = m_pBlockHead->m_nStartTimestamp;
		m_pBlockHead->m_nCurTimestamp = nTimestamp; 
		m_pBlockHead->m_nStartTimestamp = nTimestamp;
	}

	pVarDataAddr = (LPROLLBACKBLOCKVARDATASTRUCT)(m_pBlockAddr + nVarDataOffset);
	pVarDataAddr->m_nDataFlag = MAKEHEADFLAG('S','B','B','V');
	pVarDataAddr->m_nActualLength = nSize;
	pVarDataAddr->m_nDataLength = nTotalDataLen;
	
	return (LPBYTE)pVarDataAddr;															//返回定长数据部分的指针
}

void CMemoryRollBackBlock::InitialBlock(int nBlockSize)
{
	m_pBlockAddr = new BYTE[nBlockSize];
	m_pBlockHead = (LPROLLBACKBLOCKHEAD)m_pBlockAddr;			//块头指针
	m_pBlockBody = m_pBlockAddr + sizeof(ROLLBACKBLOCKHEAD);	//块体指针

	memset(m_pBlockAddr, 0, nBlockSize);						//清空块	
	//初始化块头
	//注意：保留数据、时间戳、数据标志没有进行初始化
	m_pBlockHead->m_nDataFlag				= MAKEHEADFLAG('S','B','D','B');
	m_pBlockHead->m_nRollbackTotalSize		= nBlockSize;	
	m_pBlockHead->m_nRollbackHeadSize		= sizeof(ROLLBACKBLOCKHEAD);
	m_pBlockHead->m_bStatus					= MF_LOCK_STATUS_NULL;
	m_pBlockHead->m_bSaveFlag				= 0;
	m_pBlockHead->m_bReserved				= 0;
	m_pBlockHead->m_nPreTimestamp			= 0;

	m_pBlockHead->m_nStartTimestamp			= TimestampToSecondNum(GetSystemTimestamp());
	m_pBlockHead->m_nCurTimestamp			= TimestampToSecondNum(GetSystemTimestamp());

	m_pBlockHead->m_nVarDataInsertPos = m_pBlockHead->m_nRollbackHeadSize;
}

long long CMemoryRollBackBlock::InsertRollBackData(LPBYTE& lpData, int nLen, long long nTimestamp, long long nPreRollbackDataID)
{
	int nVarDataInsertOffset;
	long long nRollBackVarDataID;
	UINT nRollbackTime, nTmpTimestamp;
	LPROLLBACKBLOCKVARDATASTRUCT pVardataAddr; 

	//判断nPreRollbackDataID是否有效
	//回滚id是0不需要判断是否有效 直接插入 回滚id为非0值需要判断
	if (nPreRollbackDataID != 0)
	{
		nRollbackTime = GetRollBackBlockTime(nPreRollbackDataID);
		if(nRollbackTime <= m_pBlockHead->m_nStartTimestamp)
		{
		   nPreRollbackDataID  = 0;
		}

		nVarDataInsertOffset = GetRollBackOffsetID(nPreRollbackDataID);
		//时间判断 回滚轮数判断 偏移量是否越界判断
		if(!(((nVarDataInsertOffset <= m_pBlockHead->m_nVarDataInsertPos) && (nRollbackTime >= m_pBlockHead->m_nStartTimestamp))
			|| ((nVarDataInsertOffset > m_pBlockHead->m_nVarDataInsertPos) && (nRollbackTime >= m_pBlockHead->m_nPreTimestamp))))
		{
			nPreRollbackDataID  = 0;
		}

	}

	nTmpTimestamp = TimestampToSecondNum(nTimestamp);
	
	//1.调用AllocBlockNewData为新数据分配空间
	pVardataAddr = (LPROLLBACKBLOCKVARDATASTRUCT)AllocBlockNewData(nLen, nTmpTimestamp, nVarDataInsertOffset);	 
	if(!pVardataAddr)
	{
		return MF_MEMORYFILE_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;	
	}

	if ((nVarDataInsertOffset >= m_pBlockHead->m_nRollbackTotalSize) && (nVarDataInsertOffset <= 0))
	{
		nVarDataInsertOffset = m_pBlockHead->m_nRollbackHeadSize;
	}																							
	
	//将变长数据的地址返回，由外部填充
	lpData = pVardataAddr->m_pDataContent;
	memset(lpData, 0, nLen);
	pVardataAddr->m_nActualLength = nLen;					
	pVardataAddr->m_nPreRollbackDataID = nPreRollbackDataID;
	pVardataAddr->m_nTimestamp = nTimestamp;

	nRollBackVarDataID = MakeRollBackDataID(nTmpTimestamp, nVarDataInsertOffset);
	return nRollBackVarDataID;
}

int CMemoryRollBackBlock::GetRollBackData(long long nRollBackVarDataID, long long nTimestamp, LPBYTE &lpVarDataAddr, int &nLen)
{
	UINT nBlockTime;
	int nVarDataInsertOffset;
	LPROLLBACKBLOCKVARDATASTRUCT pVardataAddr;

	nLen = 0;
	lpVarDataAddr = 0;
	nVarDataInsertOffset = GetRollBackOffsetID(nRollBackVarDataID);
	nBlockTime = GetRollBackBlockTime(nRollBackVarDataID);
	//时间判断 回滚轮数判断 偏移量是否越界判断
	if(!(((nVarDataInsertOffset <= m_pBlockHead->m_nVarDataInsertPos) && (nBlockTime >= m_pBlockHead->m_nStartTimestamp))
		|| ((nVarDataInsertOffset > m_pBlockHead->m_nVarDataInsertPos) && (nBlockTime >= m_pBlockHead->m_nPreTimestamp))))
	{
		return MF_ROLLBACKBUFFER_GETDATA_BLOCKNUM_ERROR;
	}

	if (!((nVarDataInsertOffset <= m_pBlockHead->m_nRollbackTotalSize)&&(nVarDataInsertOffset >= 0)))
	{
		return MF_ROLLBACKBUFFER_GETDATA_OFFSET_ERROR;
	}
	
	pVardataAddr = (LPROLLBACKBLOCKVARDATASTRUCT)(m_pBlockAddr + nVarDataInsertOffset);
	while(TRUE)
	{
		if(nTimestamp >= pVardataAddr->m_nTimestamp)
		{
			nLen = pVardataAddr->m_nActualLength;
			lpVarDataAddr =  pVardataAddr->m_pDataContent;	
			return MF_OK;
		}
		if(pVardataAddr->m_nPreRollbackDataID != 0)
		{
			nVarDataInsertOffset = GetRollBackOffsetID(pVardataAddr->m_nPreRollbackDataID);
			nBlockTime = GetRollBackBlockTime(pVardataAddr->m_nPreRollbackDataID);
			if (nBlockTime <= m_pBlockHead->m_nStartTimestamp)
			{
				return MF_ROLLBACKBUFFER_GETDATA_BLOCKNUM_ERROR;
			}

			if (!(((nVarDataInsertOffset <= m_pBlockHead->m_nVarDataInsertPos) && (nBlockTime >= m_pBlockHead->m_nStartTimestamp))
				|| ((nVarDataInsertOffset > m_pBlockHead->m_nVarDataInsertPos) && (nBlockTime >= m_pBlockHead->m_nPreTimestamp))))
			{
				return MF_ROLLBACKBUFFER_GETDATA_BLOCKNUM_ERROR;
			}

			if (!((nVarDataInsertOffset <= m_pBlockHead->m_nRollbackTotalSize)&&(nVarDataInsertOffset >= 0)))
			{
				return MF_ROLLBACKBUFFER_GETDATA_OFFSET_ERROR;
			}

			pVardataAddr = (LPROLLBACKBLOCKVARDATASTRUCT)(m_pBlockAddr + nVarDataInsertOffset);
		}
		else
		{
			break;
		}
	}
	return MF_ROLLBACKBUFFER_GETDATA_TIMESTAMP_ERROR;
}

UINT CMemoryRollBackBlock::TimestampToSecondNum(long long nTimestamp)
{
	UINT nTime;
	nTime = (UINT)((nTimestamp - MF_BASE_TIME)/40000000);
	if(nTime <= m_pBlockHead->m_nCurTimestamp)
		return m_pBlockHead->m_nCurTimestamp;
	return nTime;
}

/************************************************************************
	功能说明：
		判断回滚区数据是否合法
	参数说明：
		lpTransactionArray：事务数组
		nRollBackVarDataID：回滚区DataID
		nTimestamp:时间戳
************************************************************************/
BOOL CMemoryRollBackBlock::CheckDataVaild(long long nRollBackVarDataID, long long nTimestamp)
{
	UINT nBlockTime;
	int nVarDataInsertOffset;
	LPROLLBACKBLOCKVARDATASTRUCT pVardataAddr;

	nVarDataInsertOffset = GetRollBackOffsetID(nRollBackVarDataID);
	nBlockTime = GetRollBackBlockTime(nRollBackVarDataID);
	
	//时间判断 回滚轮数判断 偏移量是否越界判断
	if(!(((nVarDataInsertOffset <= m_pBlockHead->m_nVarDataInsertPos) && (nBlockTime >= m_pBlockHead->m_nStartTimestamp))
		|| ((nVarDataInsertOffset > m_pBlockHead->m_nVarDataInsertPos) && (nBlockTime >= m_pBlockHead->m_nPreTimestamp))))
	{
		return FALSE;
	}

	if(!((nVarDataInsertOffset <= m_pBlockHead->m_nRollbackTotalSize)&&(nVarDataInsertOffset >= 0)))
	{
		return FALSE;
	}

	pVardataAddr = (LPROLLBACKBLOCKVARDATASTRUCT)(m_pBlockAddr + nVarDataInsertOffset);
	while(TRUE)
	{
		if(nTimestamp >= pVardataAddr->m_nTimestamp)
		{
			return TRUE;
		}
		if(pVardataAddr->m_nPreRollbackDataID != 0)
		{
			nVarDataInsertOffset = GetRollBackOffsetID(pVardataAddr->m_nPreRollbackDataID);
			nBlockTime = GetRollBackBlockTime(pVardataAddr->m_nPreRollbackDataID);
			if (nBlockTime <= m_pBlockHead->m_nStartTimestamp)
			{
				return FALSE;
			}

			if (!(((nVarDataInsertOffset <= m_pBlockHead->m_nVarDataInsertPos) && (nBlockTime >= m_pBlockHead->m_nStartTimestamp))
				|| ((nVarDataInsertOffset > m_pBlockHead->m_nVarDataInsertPos) && (nBlockTime >= m_pBlockHead->m_nPreTimestamp))))
			{
				return FALSE;
			}

			if (!((nVarDataInsertOffset <= m_pBlockHead->m_nRollbackTotalSize)&&(nVarDataInsertOffset >= 0)))
			{
				return FALSE;
			}
			pVardataAddr = (LPROLLBACKBLOCKVARDATASTRUCT)(m_pBlockAddr + nVarDataInsertOffset);
		}
		else
		{
			break;
		}
	}
	return FALSE;
}