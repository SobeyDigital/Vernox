﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "MemoryBTreeIndex.h"

class CMemoryMultiStr : public CMemoryBTreeIndex
{
private:
	#pragma pack(1)
	//字符串型结点头
	typedef struct
	{
		int					m_nDataFlag;				//数据标志，目前数据块为‘SBDB’
		int                 m_nBlockNo;                 //块号(新插入块的编号 = 最大块号+1)
		long long           m_nTimestamp;               //时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
		int                 m_nBlockSize;               //块大小
		int                 m_nBlockHeadSize;           //块头大小
		BYTE                m_bStatus;                  //数据锁定状态，一般修改单条数据不需要整块锁，但如果整块进行整理时就必须进行锁定，防止其他读取或者修改操作出现错乱
		BYTE                m_bFileNo;                  //文件编号
		BYTE				m_bSaveFlag;				//数据库保存标志，防止单纯按照时间戳判断出现误判
		BYTE                m_bThreadNum;	            //保留数据

		NODETYPE			m_bNodeType;				//结点类型(叶子结点或者树干结点，结点类型决定该结构体的类型)，1表示树干、2表示叶子
		BYTE				m_bReserved[3];				//保留字段
		int					m_nDataSize;				//索引项大小
		int					m_nTotalDataNum;			//可以容纳索引项的总条数
		int					m_nDataNum;					//现有索引项条数
		int					m_nNextNodeNo;				//下一个结点的编号
		int					m_nPreNodeNo;				//前一个结点的编号	
		long long			m_nMaxKeyOffset;			//最大关键字偏移
	}MULTINODEHEAD,*LPMULTINODEHEAD;	

	//树干结构体(存放于树干结点中)
	typedef struct
	{
		long long			m_nMaxKeyOffset;			//最大关键字偏移量
		int					m_nNodeNo;					//结点编号
	}TRUNKSTRUCT,*LPTRUNKSTRUCT;

	//大树干结构体(存放于树干结点中)
	typedef struct
	{
		long long			m_nMaxKeyOffset;			//最大关键字偏移量
		int					m_nNodeNo;					//结点编号
	}BIGTRUNKSTRUCT,*LPBIGTRUNKSTRUCT;

	#pragma pack()
protected:
	/************************************************************************
		功能说明：
			获取符合关键字信息
	************************************************************************/
	int GetMultiKeyInfo(LPBYTE lpAddr, LPKEYINFO& lpMultiKeyInfo);

	/************************************************************************
		功能说明：
			根据关键字信息获取关键字值
	************************************************************************/
	void GetKeyValueByKeyInfo(LPBYTE lpKeyInfoAddr, MF_SYS_FIELDTYPE bKeyType, int nLevel, VARDATA& varKey);

	/************************************************************************
		功能说明：
			实现折半查找，需要精确查找给定的Key，实现被查询的
	************************************************************************/
	BOOL SuffixSearch(char* pSuffixKey, int nKeyLen, char* pKey, int* pSuffixMap, int nLow, int nHigh);
	
	/************************************************************************
		功能说明：
			获取结点头大小
	************************************************************************/
	virtual int GetHeadSize(LPMULTIINDEX lpMultiIndex);

	/************************************************************************
		功能说明：
			获取叶子大小
	************************************************************************/
	virtual int GetLeaveSize(LPMULTIINDEX lpMultiIndex);

	/************************************************************************
		功能说明：
			获取树干大小
	************************************************************************/
	virtual int GetTrunkSize(LPMULTIINDEX lpMultiIndex);

	/************************************************************************
		功能说明：
			获取关键字值
	************************************************************************/
	virtual void GetKeyValue(LPVOID lpKey, int nLevel, VARDATA& varKey);

	/************************************************************************
		功能说明：
			设置关键字值
	************************************************************************/
	virtual void SetKeyValue(LPVOID lpKey, LPVOID lpKeyValue, BOOL bInsert);

	/************************************************************************
		功能说明：
			获取Key的指针
	************************************************************************/
	virtual LPVOID GetKeyPtr(LPVOID lpData, NODETYPE bNodeType);

	/************************************************************************
		功能说明：
			获取MaxKey的指针
	************************************************************************/
	virtual LPVOID GetMaxKeyPtr(LPBYTE lpNode);

	/************************************************************************
		功能说明：
			判断是否为最大关键字
	************************************************************************/
	virtual BOOL CheckMaxKey(LPVOID lpKeyPtr);

	/************************************************************************
		功能说明：
			从叶子结构体中获取值，即DataID
	************************************************************************/
	virtual long long GetDataIDFromLeavePtr(LPVOID lpLeaveData);

	/************************************************************************
		功能说明：
			从关键字指针中获取关键字值
	************************************************************************/
	virtual int GetValueFromKeyPtr(LPVOID lpKeyPtr, int nIndex, VARDATA& varData);

	/************************************************************************
		功能说明：
			设置叶子结点数据
	************************************************************************/
	virtual void SetLeaveData(LPVOID lpLeaveData, LPMULTIINDEX lpMultiIndex, long long nDataID) ;

	/************************************************************************
		功能说明：
			从树干结构体中获取值，即结点编号
	************************************************************************/
	virtual int GetNodeNoFromTrunk(LPVOID lpTrunkData) ;
	
	/************************************************************************
		功能说明：
			在树干树干中设置节点编号
	************************************************************************/
	virtual void SetNodeNoToTrunk(LPVOID lpTrunkData, int nNodeNo) ;
	
	/************************************************************************
		功能说明：
			设置树干结点数据
	************************************************************************/
	virtual void SetTrunkData(LPVOID lpTrunkData, LPMULTIINDEX lpMultiIndex, int nNodeNo) ;

	/************************************************************************
		功能说明：
			设置索引字段数据
	************************************************************************/
	virtual void SetIndexField(LPMULTIINDEX lpMultiIndex, LPVOID lpKey) ;
	
	/************************************************************************
		功能说明：
			比较函数
	************************************************************************/
	virtual int Compare(LPMULTIINDEX lpMultiIndex, LPVOID lpKey, BYTE bOperator, BOOL& bFindKey) ;
	
	/************************************************************************
		功能说明：
			判断值是否合法
	************************************************************************/
	virtual void CheckDataValid(LPINDEXINFO lpIndexInfo, LPVOID lpKey, int nLevel, BOOL& bContinue, BOOL& bPush);
	
	/************************************************************************
		功能说明:
			初始化块头
	************************************************************************/
	virtual void InitialBlock(LPVOID lpNodeHead, int nDataSize, int nHeadSize, BYTE nNodeTypeFlag) ;

public:
	CMemoryMultiStr();
	~CMemoryMultiStr();
	
};