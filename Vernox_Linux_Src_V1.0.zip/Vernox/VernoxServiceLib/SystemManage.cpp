﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include <assert.h>
#include "SystemManage.h"
#include "TimestampManage.h"
#include "MemoryFile.h"
#include "MemoryBTreeFile.h"
#include "MemoryHashFile.h"
#include "MemoryRollBackBlock.h"
#include "MemoryPageManager.h"
#include "CharCompare.h"
#include "Check.h"
//////////////////////////////////////////////////////////////////////////////////////////////
//								日志定义													//
//																							//
//     日志等级请参见MF_TRACE_LEVEL系列的宏定义，日志错误码建议每条日志都独立一个编码，按此 //
//思路，对于每个函数都会有一个错误码的范围。文件占3位，函数占3位，函数内编码占3位			//
//     此文件的日志错误码定义为100000000～100999000，请按照函数的先后顺序合理申请错误码，当 //
//前使用最大的错误码为：																	//
//																							//
//																				  吴春中	//
//																				  2014-8-25 //
//////////////////////////////////////////////////////////////////////////////////////////////


#define MF_SYS_BLOCKSIZE                        262144    //系统表的块大小定义，目前暂时定为256KB
#define MF_SYS_BLOCKFREESIZE                    52428     //系统块保留空余空间，目前只有保存OBJECT对象的块需要这样处理，其他的目前按照空余2048字节即可
#define MF_TRACE_BUFFER_SIZE                    512       //日志格式化Buffer

CSystemManage * CSystemManage::m_pSinstance = NULL;
FILE* CSystemManage::m_pCommonTraceFile = NULL;

const char* arrayParameter[MF_PARAMETER_TYPE_MAX_COUNT]={
	"SERVICE_PORT",						  //Web Service的监听端口，默认为8080；
	"SERVICE_WORKERS",					  //Web Service的服务线程数量，默认为10 ；
	"TCP_LISTEN_IP",					  //TCP监听IP地址，默认为0，表示不绑定网卡；
	"TCP_LISTEN_PORT",					  //TCP监听端口，默认为8000；
	"TCP_TIMEOUT",						  //TCP发送及接收数据超时时间，默认为60秒；
	"SERVER_TRACE_LEVEL",				  //系统日志等级，默认为10；
	"SERVER_EFFICIENCY_TRACE",			  //系统效率日志，默认为0；
	"SERVER_PARALLELMODE",				  //并行模式，0：读写互不影响，1：串行方式执行；
	"SERVER_WRITE_UNDOMODE",			  //写重做日志模式(默认为1)，0：不写，1：写
	"SERVER_EXECUTETIME_MONITOR",		  //执行时间监控，用于改善SQL性能，默认100毫秒
	"SERVER_CASE_SENSITIVE",			  //字符串大小写是否敏感，0为不敏感、1为敏感，默认为0；
	"MEMORY_TEMPORARY_SIZE",			  //临时内存大小(大量数据检索使用)，单位为MB，默认48
	"MEMORY_UNDO_SIZE",					  //重做内存大小，用于数据回滚或一致性读取使用，默认48MB；
	"MEMORY_PROCESS_SIZE",				  //处理线程私有内存大小，处理与客户端通讯，默认2MB ；
	"MEMORY_PLAN_REMAINSIZE",			  //执行计划空间大小，默认10KB；
	"MEMORY_SQLPLAN_MAXSIZE",			  //SQL执行计划最大大小，默认10MB；
	"MEMORY_RECORDSETPLAN_MAXSIZE",		  //结果集执行计划最大大小，默认500MB；
	"WRITE_FILE_DELAY_TIME",			  //写文件延迟时间，默认为3秒；
	"WRITE_UNDO_DELAY_TIME",			  //写重做日志文件延迟时间，默认为3秒；
	"WRITE_TRACE_DELAY_TIME",			  //写日志文件延迟时间，默认为3秒；
	"WRITE_UNDO_MAX_SIZE",				  //重做日志文件大小
	"WRITE_TRACE_MAX_SIZE",				  //操作日志文件大小
	"BLOCK_DATA_SIZE",					  //数据块的大小，默认为1MB；
	"BLOCK_BTREE_INDEX_SIZE",			  //B树索引块大小，默认为32KB；
	"BLOCK_BTREE_DATA_SIZE",			  //B树数据块大小，默认为32KB(必需为索引块的整数倍)；
	"BLOCK_HASH_INDEX_SIZE",			  //HASH索引块大小，默认为256KB；
	"BLOCK_HASH_INDEX_CHAIN_MAXSIZE",	  //哈希索引链最大长度，超过此长度就自动增加哈希的基础槽位长度，默认为8；
	"BLOCK_HASH_INDEX_EXPAND_RATIO",	  //哈希索引的基础槽位膨胀率，默认为4；
	"BLOCK_USED_RATIO",					  //数据块使用率，达到此值表示块已经写满，默认为80；
	"BLOCK_INSERT_MAXUSE_RATIO",		  //插入数据最大使用率，超过此值不允许继续插入，默认为90；
	"BLOCK_FREE_RATIO",					  //数据块剩余率，删除数据后剩余数据率低于此值可再用，默认为40；
	"BLOCK_REORGANIZE_RATIO",			  //数据块整理率，达到此值时引起块内整理预判，默认为80；
	"BLOCK_RECYCLE_RATIO",				  //数据块回收率，达到此值时进行数据整理重组，默认为10；
	"BLOCK_INDEX_DIVIDE_MODE"			  //索引分裂方式，1：表示按照一半的方式进行分裂，2：表示按照九比一的比率分裂，3：表示按照一比九的比率分裂；
	"OBJECT_TRANSACTION_MAXNUM"			  //对象支持的最大事务数，默认4
	"TRANSACTION_LOGIC_SLOT_COUNT"		  //短事务锁槽位数量，默认100
	"TRANSACTION_LOGIC_TIMEOUT"			  //短事务锁有效时间，单位为秒，默认60秒
	"ACTIVE_LOG_FILES"						//活动重做日志数量，默认20
	"PERSISTENCE_INTERVALS"					//持久化时间间隔（单位：秒），按照事务完成进行持久化处理，默认3
};										  

void Trace0(LPCSTR szFuncationName, LONG  lLogLevel, LONG lLogErrorCode, LPCSTR szLog)
{
	try
	{
		if(CSystemManage::m_pSinstance == NULL)
		{
			CSystemManage::WriteTraceLog(szFuncationName, 0, lLogLevel, lLogErrorCode, szLog);
			return;
		}
		else if(CSystemManage::m_pSinstance->m_pTraceFileHead == NULL)
		{
			CSystemManage::WriteTraceLog(szFuncationName, 0, lLogLevel, lLogErrorCode, szLog);
			return;
		}
		else
		{
			if(CSystemManage::m_pSinstance->m_pMemoryFileHead != NULL)
			{
				if(CSystemManage::m_pSinstance->m_pMemoryFileHead->m_nServerTraceLevel < lLogLevel)
				{
					//属于系统定义不需要输出的日志，所以直接忽略就可以了
					return;
				}
			}
			else
			{
				//暂时定义为，只输出日志等级小于等于10级的
				if(10 < lLogLevel)
				{
					return;
				}
			}
			CSystemManage::m_pSinstance->TraceLog(szFuncationName, 0, lLogLevel, lLogErrorCode, szLog);
		}
	}
	catch (...)
	{
		char lpBuffer[256];
		memset(lpBuffer, 0, 256);
		sprintf(lpBuffer, "写日志出现异常错误(详细日志信息丢失)，错误编码：%d", GetLastError());
		CSystemManage::WriteTraceLog("Trace0", 0, MF_TRACE_LEVEL_FAILED, 100000001, lpBuffer);
	}
}

void Trace(LPCSTR szFuncationName, LONG lLogLevel, LONG lLogErrorCode, const char *fmt, ... )
{
	try
	{
		va_list args;
		char lpBuffer[20480];

		va_start(args, fmt);
		vsnprintf(lpBuffer, 20480, fmt, args);
		lpBuffer[20479] = 0;
		va_end(args);
		Trace0(szFuncationName, lLogLevel, lLogErrorCode, lpBuffer);
	}
	catch (...)
	{
		char lpBuffer[256];
		memset(lpBuffer, 0, 256);
		sprintf(lpBuffer, "写日志进行格式化时，出现异常错误(详细日志信息丢失)，错误编码：%d", GetLastError());
		Trace0("Trace", MF_TRACE_LEVEL_FAILED, 100000002, lpBuffer);
	}
}

int  GetSystemParameterValue(MF_PARAMETER_TYPE nParameterName)
{
	if(CSystemManage::m_pSinstance == NULL)
	{
		Trace("GetSystemParameterValue", 0, 10000010, ("程序还未初始化，无法获取系统参数，参数类型：%d"), nParameterName);
		return 0;
	}
	else
	{
		return CSystemManage::m_pSinstance->GetParameterValue(nParameterName);
	}
}

void FreeSystemTemporaryMemory(LPBYTE lpBuf)
{
	if(CSystemManage::m_pSinstance == NULL)
	{
		Trace("FreeSystemTemporaryMemory", 0, 100000040, ("程序还未初始化，无法做临时内存释放，专为直接释放内存的方式，地址：%d"), lpBuf);
		delete [] lpBuf;
	}
	else
	{
		CSystemManage::m_pSinstance->FreeTemporaryMem(lpBuf);
	}
}

CSystemManage::CSystemManage(void)
{
	Init();
}

void CSystemManage::Init()
{
	m_nMemoryShmId		= NULL;
	m_pFileAddr			= NULL;
	m_pMemoryFileHead	= NULL;
	m_nTraceShmId		= NULL;
	m_pTraceFileAddr	= NULL;
	m_pTraceFileHead	= NULL;
	m_nLogShmId			= NULL;
	m_pLogFileAddr		= NULL;
	m_pLogFileHead		= NULL;
	m_hLogEvent			= NULL;
	m_hTraceEvent     	= NULL;
	m_nTemporaryMemShmId = NULL;
	m_pTemporaryMemory	= NULL;
	m_lpszTraceBuf		= new TCHAR[MF_TRACE_BUFFER_SIZE];
	m_pExecuteStatistics = NULL;
	m_pRollBackMemory   = NULL;
	m_pCharCompare		= NULL;
	m_lTransactionID	= 1;
	m_nTransactionLogicSlotCount = 100;
	m_nTransactionLogicTimeout = 600000000;
	m_pLogicTransaction = NULL;
	m_lpWorkloadStatistics = new WORKLOADSTATISTICSINFO[60*24];//按照一天来进行存储，每分钟存储一次
	memset(m_lpWorkloadStatistics, 0, 60*24*sizeof(WORKLOADSTATISTICSINFO));

	m_nStorageMemFileShmId	= NULL;
	m_lpStorageMemFileAddr  = NULL;
	m_pStorageMemFileHead	= NULL;
	m_thMemStorageThread	= NULL;
	m_bExit					= FALSE;
	m_pBackupRedoFile		= NULL;
	m_lpLatestWorkloadStatistics = NULL;
	m_nLatestWorkloadPos	= 0;
	memset(m_arMemDBFile, 0, sizeof(m_arMemDBFile));

	m_mapObject.Initialize(256);
	m_mapName2Object.Initialize(256);
	m_mapIndex.Initialize(256);
	m_mapSequence.Initialize(256);
	m_mapName2UserInfo.Initialize(256);
	m_mapBlock.Initialize(512);
	m_mapUserInfo.Initialize(256);
	m_mapSession.Initialize(256);
	m_mapSoapServer.Initialize(256);
	m_mapName2Authority.Initialize(20);
	m_mapAuthority.Initialize(20);

	::InitializeCriticalSection(&m_critSysDBFile);
	::InitializeCriticalSection(&m_critSequence);
	::InitializeCriticalSection(&m_critFile);
	::InitializeCriticalSection(&m_critObject);
	::InitializeCriticalSection(&m_critUser);
	::InitializeCriticalSection(&m_critAuthority);
	::InitializeCriticalSection(&m_critTrace);
	::InitializeCriticalSection(&m_critLog);
	::InitializeCriticalSection(&m_critSession);
	::InitializeCriticalSection(&m_critStatistics);
	::InitializeCriticalSection(&m_critTemporaryMemory);
	::InitializeCriticalSection(&m_critLogicTransaction);
	::InitializeCriticalSection(&m_critBlock);
	::InitializeCriticalSection(&m_critDataObject);
	::InitializeCriticalSection(&m_critIndex);
	::InitializeCriticalSection(&m_critMS);
	::InitializeCriticalSection(&m_critNode);
	
	::InitializeCriticalSection(&m_critDataFile);
	::InitializeCriticalSection(&m_critBTreeFile);
	::InitializeCriticalSection(&m_critKVFile);

	::InitializeCriticalSection(&m_critDataFileBlockMap);
	::InitializeCriticalSection(&m_critBTreeFileBlockMap);
	::InitializeCriticalSection(&m_critKVFileHashTable);

	::InitializeCriticalSection(&m_critBTreeRoot);
	::InitializeCriticalSection(&m_critKVRoot);

	::InitializeCriticalSection(&m_critPreprocess);
	::InitializeCriticalSection(&m_critWorkload);

	//打开日志写入共享内存句柄
	m_nTraceShmId = CShareMemory::OpenShareMemory(MF_TRACE_FILE_TRACE_KEY, MF_TRACE_FILE_TRACENAME);
	if(CShareMemory::GetShareMemorySuccess(m_nTraceShmId))
	{
		m_pTraceFileAddr = (LPBYTE)CShareMemory::ShMemAttach(m_nTraceShmId);
		if(m_pTraceFileAddr != NULL)
		{
			m_pTraceFileHead = (LPFILE_TRACEMEMFILEHEAD)m_pTraceFileAddr;
		}
		else
		{
			Trace("CSystemManage::CSystemManage", MF_TRACE_LEVEL_FAILED, 100001001, "打开日志内存文件，然后映射操作内存地址失败，错误码：%d，内存文件名：%s", GetLastError(), MF_TRACE_FILE_TRACENAME);
			CShareMemory::CloseShareMemory(m_nTraceShmId);
		}
	}
	else
	{
		Trace("CSystemManage::CSystemManage", MF_TRACE_LEVEL_FAILED, 100001002, "打开日志内存文件失败，错误码：%d，内存文件名：%s", GetLastError(), MF_TRACE_FILE_TRACENAME);
	}

	//创建事件
#ifdef WIN32
	m_hBlockLockEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	if(m_hBlockLockEvent ==	NULL)
	{
		Trace("CSystemManage::CSystemManage", MF_TRACE_LEVEL_FAILED, 100001003, "块锁事件创建失败，错误码：%d", GetLastError());
	}

	m_hObjectLockEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	if(m_hObjectLockEvent == NULL)
	{
		Trace("CSystemManage::CSystemManage", MF_TRACE_LEVEL_FAILED, 100001004, "对象锁事件创建失败，错误码：%d", GetLastError());
	}

	m_hIndexLockEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	if(m_hIndexLockEvent ==	NULL)
	{
		Trace("CSystemManage::CSystemManage", MF_TRACE_LEVEL_FAILED, 100001005, "索引锁事件创建失败，错误码：%d", GetLastError());
	}
#else
    m_hBlockLockEvent    = sem_open("Global\\MemDBSysBlockLock", O_CREAT, 0644, 1);
	if(m_hBlockLockEvent == SEM_FAILED)
	{
		Trace("CSystemManage::CSystemManage", MF_TRACE_LEVEL_FAILED, 100001003, "块锁事件创建失败，错误码：%d", GetLastError());
	}

	m_hObjectLockEvent  = sem_open("Global\\MemDBSysObjectLock", O_CREAT, 0644, 1);
	if(m_hObjectLockEvent == SEM_FAILED)
	{
		Trace("CSystemManage::CSystemManage", MF_TRACE_LEVEL_FAILED, 100001004, "对象锁事件创建失败，错误码：%d", GetLastError());
	}

	m_hIndexLockEvent    = sem_open("Global\\MemDBSysIndexLock", O_CREAT, 0644, 1);
	if(m_hIndexLockEvent ==	SEM_FAILED)
	{
		Trace("CSystemManage::CSystemManage", MF_TRACE_LEVEL_FAILED, 100001005, "索引锁事件创建失败，错误码：%d", GetLastError());
	}
#endif
}

CSystemManage::~CSystemManage(void)
{
	Release();
}

void CSystemManage::Release()
{
	FreeData();
	::DeleteCriticalSection(&m_critSysDBFile);
	::DeleteCriticalSection(&m_critSequence);
	::DeleteCriticalSection(&m_critFile);
	::DeleteCriticalSection(&m_critObject);
	::DeleteCriticalSection(&m_critUser);
	::DeleteCriticalSection(&m_critAuthority);
	::DeleteCriticalSection(&m_critTrace);
	::DeleteCriticalSection(&m_critLog);
	::DeleteCriticalSection(&m_critSession);
	::DeleteCriticalSection(&m_critStatistics);
	::DeleteCriticalSection(&m_critTemporaryMemory);
	::DeleteCriticalSection(&m_critLogicTransaction);
	::DeleteCriticalSection(&m_critBlock);
	::DeleteCriticalSection(&m_critDataObject);
	::DeleteCriticalSection(&m_critIndex);
	::DeleteCriticalSection(&m_critMS);
	::DeleteCriticalSection(&m_critNode);
	
	::DeleteCriticalSection(&m_critDataFile);
	::DeleteCriticalSection(&m_critBTreeFile);
	::DeleteCriticalSection(&m_critKVFile);

	::DeleteCriticalSection(&m_critDataFileBlockMap);
	::DeleteCriticalSection(&m_critBTreeFileBlockMap);
	::DeleteCriticalSection(&m_critKVFileHashTable);

	::DeleteCriticalSection(&m_critBTreeRoot);
	::DeleteCriticalSection(&m_critKVRoot);
	
	::DeleteCriticalSection(&m_critPreprocess);
	::DeleteCriticalSection(&m_critWorkload);

	if (NULL != m_pBackupRedoFile)
	{
		fclose(m_pBackupRedoFile);
		m_pBackupRedoFile = NULL;
	}
	
	if(m_pCommonTraceFile != NULL)
	{
		fclose(m_pCommonTraceFile);
		m_pCommonTraceFile = NULL;
	}
#ifdef WIN32	
	if(m_hBlockLockEvent != INVALID_HANDLE_VALUE)
	{
		CloseHandle(m_hBlockLockEvent);
	}

	if(m_hObjectLockEvent != INVALID_HANDLE_VALUE)
	{
		CloseHandle(m_hObjectLockEvent);
	}

	if(m_hIndexLockEvent != INVALID_HANDLE_VALUE)
	{
		CloseHandle(m_hIndexLockEvent);
	}
#else
	if(m_hBlockLockEvent != SEM_FAILED)
	{
		sem_close(m_hBlockLockEvent);
	}

	if(m_hObjectLockEvent != SEM_FAILED)
	{
		sem_close(m_hObjectLockEvent);
	}

	if(m_hIndexLockEvent != SEM_FAILED)
	{
		sem_close(m_hIndexLockEvent);
	}
#endif
}

CSystemManage & CSystemManage::instance()
{
	if(NULL == m_pSinstance)
	{
		m_pSinstance = new CSystemManage;
	}
	return *m_pSinstance;
}

void CSystemManage::DestoryInstance()
{
	if(m_pSinstance != NULL)
	{
		delete m_pSinstance;
		m_pSinstance = NULL;
	}
}

//错误码100002000
int CSystemManage::OpenMemDBFile(LPMEMDBFILEDEF lpMemDBFileDef)
{
	switch(lpMemDBFileDef->m_bFileType)
	{
	case MF_SYS_FILETYPE_DATAFILE:
		lpMemDBFileDef->m_pInstance = new CMemoryFile;
		break;
	case MF_SYS_FILETYPE_TREEINDEXFILE:
		lpMemDBFileDef->m_pInstance = new CMemoryBTreeFile;
		break;
	case MF_SYS_FILETYPE_KVINDEXFILE:
		lpMemDBFileDef->m_pInstance = new CMemoryHashFile;
		break;
	default:
		Trace("CSystemManage::OpenMemDBFile", MF_TRACE_LEVEL_FAILED, 100002001, "打开内存文件遇到不支持的文件类型，内存文件名：%s, 文件类型：%d", lpMemDBFileDef->m_lpszFilePath, lpMemDBFileDef->m_bFileType);
		return MF_SYS_DBFILE_NOSUPPORT_FILETYPE_FAILED;
	}
	return lpMemDBFileDef->m_pInstance->Open(lpMemDBFileDef);
}

//错误码100003000
int CSystemManage::CloseMemDBFile(LPMEMDBFILEDEF lpMemDBFileDef)
{
	int nRet;
	nRet = lpMemDBFileDef->m_pInstance->Close();
	lpMemDBFileDef->m_pInstance = NULL;
	return nRet;
}

//错误码100004000
int CSystemManage::RecycleFileData(LPEXECUTEPLANBSON lpExecutePlan, BYTE bFileNo, int nID)
{
	LPMEMDBFILEDEF lpMemDBFileDef = NULL;
	lpMemDBFileDef = m_arMemDBFile[bFileNo];
	if(lpMemDBFileDef == NULL)
	{
		Trace("CSystemManage::RecycleFileData", MF_TRACE_LEVEL_FAILED, 100004001, "根据内存文件编号查找内存数据存在，但是为空指针，文件编号：%d", bFileNo);
		return MF_INNER_POINTER_NULL;
	}
	if(lpMemDBFileDef->m_pInstance == NULL)
	{
		Trace("CSystemManage::RecycleFileData", MF_TRACE_LEVEL_FAILED, 100004002, "根据内存文件编号查找内存数据，但实例未初始化，文件编号：%d", bFileNo);
		return MF_INNER_INSTANCE_UNINITALIZE;
	}

	return lpMemDBFileDef->m_pInstance->DropObject(lpExecutePlan, nID);
}

//初始化系统管理类
int CSystemManage::InitData()
{
	int nRet;
	key_t nShmKey;
	SECURITY_DESCRIPTOR sec;
	SECURITY_ATTRIBUTES attr;
	CCriticalSectionPtr cs(&m_critSysDBFile);
	try
	{
		InitializeSecurityDescriptor(&sec, 1/*SECURITY_DESCRIPTOR_REVISION*/);
		SetSecurityDescriptorDacl(&sec, TRUE, NULL, FALSE);
		attr.bInheritHandle = FALSE;
		attr.lpSecurityDescriptor = &sec;
		attr.nLength = sizeof(SECURITY_ATTRIBUTES);

		//从这儿开始就可以写日志了
		if(m_pTraceFileHead != NULL)
		{
			m_hTraceEvent = CreateEventSem(&attr, MF_TRACE_FILE_TRACEEVENT);
			if(!CreateEventSemSuccess(m_hTraceEvent))
			{
				//事件没创建起，其实影响不大，所以让系统依然可以运行
				Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005001, "打开全局内存事件失败，错误码：%d，全局事件名：%s", GetLastError(), MF_TRACE_FILE_TRACEEVENT);
			}
		}

		m_hLogEvent = CreateEventSem(&attr, MF_TRACE_FILE_LOGEVENT);
		if(!CreateEventSemSuccess(m_hLogEvent))
		{
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005002, "打开全局内存事件失败，错误码：%d，全局事件名：%s", GetLastError(), MF_TRACE_FILE_LOGEVENT);
			return MF_INNER_SYS_TRACE_EVENT_FAILED;
		}

		//打开日志写入共享内存句柄
		m_nLogShmId = CShareMemory::OpenShareMemory(MF_TRACE_FILE_LOG_KEY, MF_TRACE_FILE_LOGNAME);
		if(!CShareMemory::GetShareMemorySuccess(m_nLogShmId))
		{
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005003, "打开重做日志内存文件失败，错误码：%d，内存文件名：%s", GetLastError(), MF_TRACE_FILE_LOGNAME);
			return MF_INNER_OPENMEMFILE_FAILED;//打开失败
		}

		m_pLogFileAddr = (LPBYTE)CShareMemory::ShMemAttach(m_nLogShmId);
		if(m_pLogFileAddr == NULL)
		{
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005004, "打开重做日志内存文件，然后映射操作内存地址失败，错误码：%d，内存文件名：%s", GetLastError(), MF_TRACE_FILE_LOGNAME);
			CShareMemory::CloseShareMemory(m_nLogShmId);
			return MF_INNER_MAPMEMFILE_FAILED;
		}
		m_pLogFileHead = (LPFILE_TRACEMEMFILEHEAD)m_pLogFileAddr;

		//固定系统文件的内存文件名
		nShmKey = MF_MEMFILE_BASEKEY + MF_SYS_FILETYPE_SYSFILE;
		m_nMemoryShmId = CShareMemory::OpenShareMemory(nShmKey, ("Global\\MemDBSysFile"));
		if(!CShareMemory::GetShareMemorySuccess(m_nMemoryShmId))
		{
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005005, "打开系统内存文件失败，错误码：%d，内存文件名：%s", GetLastError(), "Global\\MemDBSysFile");
			return MF_INNER_OPENMEMFILE_FAILED;//打开失败
		}

		m_pFileAddr = (LPBYTE)CShareMemory::ShMemAttach(m_nMemoryShmId);
		if(m_pFileAddr == NULL)
		{
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005006, "打开系统内存文件，然后映射操作内存地址失败，错误码：%d，内存文件名：%s", GetLastError(), ("Global\\MemDBSysFile"));
			CShareMemory::CloseShareMemory(m_nMemoryShmId);
			return MF_INNER_MAPMEMFILE_FAILED;
		}
		m_pMemoryFileHead = (LPSYSTEMFILEHEAD)m_pFileAddr;

		//把文件头指针设置给时间戳管理对象，建立起一个合理的时间戳管理
		CTimestampManage::instance().SetSystemFileHead(m_pMemoryFileHead);

		//分配临时内存
		if(m_pMemoryFileHead->m_nMemoryTemporarySize < 5*1024*1024)
		{
			m_pMemoryFileHead->m_nMemoryTemporarySize = 48*1024*1024;
		}
		m_nTransactionLogicSlotCount = m_pMemoryFileHead->m_nTransactionLogicSlotCount;
		if(m_nTransactionLogicSlotCount <= 0 || m_nTransactionLogicSlotCount > 100000)
		{
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005007, "事务逻辑锁槽位参数不正确，参数值：%d", m_nTransactionLogicSlotCount);
			return MF_INNER_MAPMEMFILE_FAILED;
		}
		m_pLogicTransaction = new LOGICTRANSACTION[m_nTransactionLogicSlotCount];
		memset(m_pLogicTransaction, 0, sizeof(LOGICTRANSACTION) * m_nTransactionLogicSlotCount);
		m_nTransactionLogicTimeout = m_pMemoryFileHead->m_nTransactionLogicTimeout;
		m_nTransactionLogicTimeout = m_nTransactionLogicTimeout * 10000000;

		m_nTemporaryMemShmId = CShareMemory::CreateShareMemory(ME_TEMPORARYMEM_KEY, m_pMemoryFileHead->m_nMemoryTemporarySize, NULL);
		if(!CShareMemory::GetShareMemorySuccess(m_nTemporaryMemShmId))
		{
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005008, "打开重做日志内存文件失败，错误码：%d", GetLastError());
			return MF_INNER_OPENMEMFILE_FAILED;			//打开失败
		}

		m_pTemporaryMemory = (LPTEMPORARYMEMHEAD)CShareMemory::ShMemAttach(m_nTemporaryMemShmId);
		if(m_pTemporaryMemory == NULL)
		{
			Sleep(5000);
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005009, "打开重做日志内存文件，然后映射操作内存地址失败，错误码：%d，内存文件名：%s", GetLastError(), MF_TRACE_FILE_LOGNAME);
			CShareMemory::DestoryShareMemory(m_nTemporaryMemShmId);
			return MF_INNER_MAPMEMFILE_FAILED;
		}
		m_pTemporaryMemory->m_nDataFlag     = MAKEHEADFLAG('S', 'B', 'T', 'M');
		m_pTemporaryMemory->m_nTotalSize    = m_pMemoryFileHead->m_nMemoryTemporarySize;
		m_pTemporaryMemory->m_nHeaderSize   = sizeof(TEMPORARYMEMHEAD);
		m_pTemporaryMemory->m_nAllocPos     = m_pTemporaryMemory->m_nHeaderSize;
		m_pTemporaryMemory->m_nLastAllocPos = 0;
		m_pTemporaryMemory->m_nFreePos      = m_pTemporaryMemory->m_nHeaderSize;

		//打开闪回内存映射文件
		m_nStorageMemFileShmId = CShareMemory::OpenShareMemory(MF_STORAGEMEM_FILE_KEY, MF_STORAGEMEM_FILE_NAME);
		if(!CShareMemory::GetShareMemorySuccess(m_nStorageMemFileShmId))
		{
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005010, "打开闪回内存文件失败，错误码：%d，内存文件名：%s", GetLastError(), MF_STORAGEMEM_FILE_NAME);
			return MF_INNER_OPENMEMFILE_FAILED;//打开失败
		}
		m_lpStorageMemFileAddr = (LPBYTE)CShareMemory::ShMemAttach(m_nStorageMemFileShmId);
		if(m_lpStorageMemFileAddr == NULL)
		{
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005011, "打开闪回内存文件，然后映射操作内存地址失败，错误码：%d，内存文件名：%s", GetLastError(), MF_STORAGEMEM_FILE_NAME);
			CShareMemory::CloseShareMemory(m_nStorageMemFileShmId);
			return MF_INNER_MAPMEMFILE_FAILED;
		}
		m_pStorageMemFileHead = (LPSTORAGEMEMHEAD)m_lpStorageMemFileAddr;
		m_bExit = FALSE;

		//初始化系统对象
		ReLoadSysObject();

		m_pRollBackMemory = new CMemoryRollBackBlock(m_pMemoryFileHead->m_nMemoryUndoSize);
		m_pPageManager = new CMemoryPageManager;
		nRet = m_pPageManager->InitialBuffer();
		if(nRet != MF_OK)
		{
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005099, "分配页面Buffer出错，错误码%d", nRet);
			return nRet;
		}

#ifdef WIN32
		m_thMemStorageThread = (HANDLE)_beginthreadex(NULL, 0, MemStorageThread, this, 0, NULL);
#else
		nRet = pthread_create(&m_thMemStorageThread, NULL, MemStorageThread, (void*)this);
		if(nRet != MF_OK)
		{
			Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005099, "初始化数据出现异常，错误码：%d", GetLastError());
			return MF_INNER_EXPCETION_FAILED;
		}
#endif
	}
	catch(...)
	{
		Trace("CSystemManage::InitData", MF_TRACE_LEVEL_FAILED, 100005099, "初始化数据出现异常，错误码：%d", GetLastError());
		return MF_INNER_EXPCETION_FAILED;
	}

	return MF_OK;
}

//错误码100006000
int CSystemManage::FreeData()
{
	int i;
	char* pName;
	string strTemp;
	LPINDEXDEF lpIndex;
	LPOBJECTDEF lpObject;
	LPVOID lpPos, lpValue;
	LPUSERINFODEF lpUserInfo;
	LPLOGICTRANSACTION pNext;
	LPSEQUENCEDEF lpSequence;
	LPAUTHORITYINFO lpAuthorityInfo;
	LPSQLEXECUTESTATISTICSINFO lpNode;

	m_bExit = TRUE;
	//等待线程退出
	Sleep(m_pStorageMemFileHead->m_nCycleTime * 20);

	CTimestampManage::instance().SetSystemFileHead(NULL);
	//释放所有的数据空间
	m_mapIndex.Clear();
	m_mapObject.Clear();
	m_mapAuthority.Clear();
	m_mapUserInfo.Clear();

	lpPos = m_mapName2Object.GetHeadPosition();
	while(lpPos != NULL)
	{
		m_mapName2Object.GetNext(lpPos, pName, lpValue);
		if(lpValue != NULL)
		{
			lpObject = (LPOBJECTDEF)lpValue;
		}
		else
		{
			continue;
		}
		//删除索引信息
		lpIndex = lpObject->m_lpIndex;
		while(lpIndex != NULL)
		{
			lpObject->m_lpIndex = lpIndex->m_pNext;
			delete lpIndex;
			lpIndex = lpObject->m_lpIndex;
		}
		delete [] lpObject->m_lpField;
		delete lpObject;
	}
	m_mapName2Object.Clear();

	lpPos = m_mapSequence.GetHeadPosition();
	while(lpPos)
	{
		m_mapSequence.GetNext(lpPos, pName, lpValue);
		if(lpValue != NULL)
		{
			lpSequence = (LPSEQUENCEDEF)lpValue;
			delete lpSequence;
		}
	}
	m_mapSequence.Clear();
	m_mapBlock.Clear();

	for(i = 0;i < 256;i++)
	{
		if(m_arMemDBFile[i] != NULL)
		{
			CloseMemDBFile(m_arMemDBFile[i]);
			delete m_arMemDBFile[i];
			m_arMemDBFile[i] = NULL;
		}
	}

	lpPos = m_mapName2Authority.GetHeadPosition();
	while(lpPos != NULL)
	{
		m_mapName2Authority.GetNext(lpPos, pName, lpValue);
		if(lpValue != NULL)
		{
			lpAuthorityInfo = (LPAUTHORITYINFO)lpValue;
			delete lpAuthorityInfo;
		}
	}
	m_mapName2Authority.Clear();

	lpPos = m_mapName2UserInfo.GetHeadPosition();
	while(lpPos != NULL)
	{
		m_mapName2UserInfo.GetNext(lpPos, pName, lpValue);
		if(lpValue != NULL)
		{
			lpUserInfo = (LPUSERINFODEF)lpValue;
			delete lpUserInfo;
		}
	}
	m_mapName2UserInfo.Clear();

	//释放系统文件
	CTimestampManage::DestoryInstance();
	m_pMemoryFileHead = NULL;
	if(m_pFileAddr != NULL)
	{
		CShareMemory::ShMemDetach(m_pFileAddr);
	}
	if(CShareMemory::ShareMemoryExsist(m_nMemoryShmId))
	{
		CShareMemory::CloseShareMemory(m_nMemoryShmId);
	}

	SetEvent(m_hTraceEvent);
	SetEvent(m_hLogEvent);
	//释放日志体系
	m_pLogFileHead = NULL;
	if(m_pLogFileAddr != NULL)
	{
		CShareMemory::ShMemDetach(m_pLogFileAddr);
	}
	if(CShareMemory::ShareMemoryExsist(m_nLogShmId))
	{
		CShareMemory::CloseShareMemory(m_nLogShmId);
	}
	m_pTraceFileHead = NULL;
	Sleep(10);
	if(m_pTraceFileAddr != NULL)
	{
		CShareMemory::ShMemDetach(m_pTraceFileAddr);
	}
	if(CShareMemory::ShareMemoryExsist(m_nTraceShmId))
	{
		CShareMemory::CloseShareMemory(m_nTraceShmId);
	}
	//释放临时内存
	if(m_pTemporaryMemory != NULL)
	{
		CShareMemory::ShMemDetach(m_pTemporaryMemory);
	}
	if(CShareMemory::ShareMemoryExsist(m_nTemporaryMemShmId))
	{
		CShareMemory::DestoryShareMemory(m_nTemporaryMemShmId);
	}
	if(m_lpszTraceBuf)
	{
		delete m_lpszTraceBuf;
		m_lpszTraceBuf = NULL;
	}
	if(m_lpWorkloadStatistics)
	{
		delete [] m_lpWorkloadStatistics;
		m_lpWorkloadStatistics = NULL;
	}


	if (m_pRollBackMemory != NULL)
	{
		delete m_pRollBackMemory;
		m_pRollBackMemory = NULL;
	}
	if(m_pPageManager != NULL)
	{
		delete m_pPageManager;
		m_pPageManager = NULL;
	}

	for(i = 0;i < m_nTransactionLogicSlotCount;i++)
	{
		while(m_pLogicTransaction[i].m_pNext != NULL)
		{
			pNext = m_pLogicTransaction[i].m_pNext;
			m_pLogicTransaction[i].m_pNext = pNext->m_pNext;
			delete pNext;
		}
	}
	delete [] m_pLogicTransaction;

	if(m_pCharCompare != NULL)
	{
		delete m_pCharCompare;
		m_pCharCompare = NULL;
	}

	//释放闪回内存映射文件
	m_pStorageMemFileHead = NULL;
	if(m_lpStorageMemFileAddr != NULL)
	{
		CShareMemory::ShMemDetach(m_lpStorageMemFileAddr);
	}
	if(CShareMemory::ShareMemoryExsist(m_nStorageMemFileShmId))
	{
		CShareMemory::CloseShareMemory(m_nStorageMemFileShmId);
	}
	for(lpNode = m_pExecuteStatistics;lpNode != NULL; )
	{
		m_pExecuteStatistics = lpNode->m_pNext;
		if(lpNode->m_lpszSql != NULL)
		{
			delete [] lpNode->m_lpszSql;
			lpNode->m_lpszSql = NULL;
		}
		delete lpNode;
		lpNode = m_pExecuteStatistics;
	}

#ifdef WIN32
	if (m_thMemStorageThread != NULL)
	{
		::CloseHandle(m_thMemStorageThread);
		m_thMemStorageThread = NULL;
	}
#endif

	return MF_OK;
}

//考虑所有数据都为定长数据，这样就不需要其他的数据开销
int CSystemManage::LoadMemDBFileData(LPSYSTEMBLOCKHEAD lpSystemBlockHead)
{
	int i, nRet;
	LPMEMDBFILEDEF lpMemDBFileDef;
	map<BYTE, LPMEMDBFILEDEF>::iterator iter;
	LPFILE_MEMDBFILEINFO lpFileMemDBFileInfo;
	if(lpSystemBlockHead->m_nObjectID != MF_SYS_OBJECTTYPE_FILE)
	{
		//按道理不应该出现这种情况
		Trace("CSystemManage::LoadMemDBFileData", MF_TRACE_LEVEL_FAILED, 100007001, "初始化内存文件数据时，发现传入块的OBJECTID不正确，OBJECTID：%d，正确值为：%d", lpSystemBlockHead->m_nObjectID, MF_SYS_OBJECTTYPE_FILE);
		return MF_INNER_SYS_OBJECTMAP_DATAERROR;
	}
	if(lpSystemBlockHead->m_nBlockDataStructSize != sizeof(FILE_MEMDBFILEINFO))
	{
		//结构体发生变化了？
		Trace("CSystemManage::LoadMemDBFileData", MF_TRACE_LEVEL_FAILED, 100007002, "初始化内存文件数据时，发现传入块的m_nBlockDataStructSize数据不正确，m_nBlockDataStructSize：%d，正确值为：%d", lpSystemBlockHead->m_nBlockDataStructSize, sizeof(FILE_MEMDBFILEINFO));
		return MF_INNER_ITEMDATASIZE_ERROR;
	}
	//直接把定长数据转换成结构体
	lpFileMemDBFileInfo = (LPFILE_MEMDBFILEINFO)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
	for(i = 0;i < lpSystemBlockHead->m_nDataNum; i++)
	{
		//检查删除标记
		if(lpFileMemDBFileInfo[i].m_bDropFlag == 1)
		{
			//直接忽略
			Trace("CSystemManage::LoadMemDBFileData", MF_TRACE_LEVEL_INNER_DEBUG, 100007003, "发现删除的数据，文件编号：%d，文件路径：%s", lpFileMemDBFileInfo[i].m_bFileNo, lpFileMemDBFileInfo[i].m_lpszFilePath);
			continue;
		}

		//检查一下是否存在
		if(m_arMemDBFile[lpFileMemDBFileInfo[i].m_bFileNo] != NULL)
		{
			//有相同文件编号的文件，系统出错了
			Trace("CSystemManage::LoadMemDBFileData", MF_TRACE_LEVEL_FAILED, 100007004, "初始化内存文件数据时，发现文件编号重复（%d）", lpFileMemDBFileInfo[i].m_bFileNo);
			return MF_SYS_DBFILE_FILENO_REPEATERROR;
		}

		lpMemDBFileDef = new MEMDBFILEDEF;
		memset(lpMemDBFileDef, 0, sizeof(MEMDBFILEDEF));
		lpMemDBFileDef->m_nDataID = MakeDataID(lpSystemBlockHead->m_bFileNo, lpSystemBlockHead->m_nBlockNo, lpFileMemDBFileInfo[i].m_nInnerNo); 
		lpMemDBFileDef->m_bFileNo = lpFileMemDBFileInfo[i].m_bFileNo;
		lpMemDBFileDef->m_bFileType = lpFileMemDBFileInfo[i].m_bFileType;
		lpMemDBFileDef->m_pLoadSize = &lpFileMemDBFileInfo[i].m_nLoadSize;
		memcpy(lpMemDBFileDef->m_lpszFilePath, lpFileMemDBFileInfo[i].m_lpszFilePath, 256*sizeof(TCHAR));
		memcpy(lpMemDBFileDef->m_lpszMemFileName, lpFileMemDBFileInfo[i].m_lpszMemFileName, 64*sizeof(TCHAR));
		lpMemDBFileDef->m_nFileSize = lpFileMemDBFileInfo[i].m_nFileSize;
		lpMemDBFileDef->m_pInstance = NULL;
		nRet = OpenMemDBFile(lpMemDBFileDef);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		m_arMemDBFile[lpMemDBFileDef->m_bFileNo] = lpMemDBFileDef;
	}
	return MF_OK;
}

//由于列的内容不定，所以肯定需要保存到变长数据中，目前暂时不考虑出现一条数据保存到两个变长链表中，所以每次修改数据都做一次整理
int CSystemManage::LoadObjectData(LPSYSTEMBLOCKHEAD lpSystemBlockHead)
{
	BYTE bCount;	
	CMemoryFile* pFile;
	LPMEMDBFILEDEF lpMemDBFileDef;
	LPFILE_OBJECTFIELDDEF lpFieldDef;
	IVirtualMemoryFile* pVirtualFile;
	LPFILE_OBJECTDEF lpFileObjectInfo;
	int nRet, i, j, n, nOffset, nFieldNum;
	LPSYSTEMBLOCKDATASTRUCT lpBlockDataMap;
	LPOBJECTDEF lpObjectInfo, lpObjectTemp;
	LPSYSTEMBLOCKVARDATASTRUCT lpBlockVarData;
	
	if(lpSystemBlockHead->m_nObjectID != MF_SYS_OBJECTTYPE_OBJECT)
	{
		//按道理不应该出现这种情况
		Trace("CSystemManage::LoadObjectData", MF_TRACE_LEVEL_FAILED, 100008001, "初始化对象数据时，发现传入块的OBJECTID不正确，OBJECTID：%d，正确值为：%d", lpSystemBlockHead->m_nObjectID, MF_SYS_OBJECTTYPE_OBJECT);
		return MF_INNER_SYS_OBJECTMAP_DATAERROR;
	}
	if(lpSystemBlockHead->m_nBlockDataStructSize != sizeof(SYSTEMBLOCKDATASTRUCT))
	{
		Trace("CSystemManage::LoadObjectData", MF_TRACE_LEVEL_FAILED, 100008002, "初始化对象数据时，发现传入块的m_nBlockDataStructSize数据不正确，m_nBlockDataStructSize：%d，正确值为：%d", lpSystemBlockHead->m_nBlockDataStructSize, sizeof(SYSTEMBLOCKDATASTRUCT));
		return MF_INNER_ITEMDATASIZE_ERROR;
	}
	
	//直接把定长数据转换成结构体
	lpBlockDataMap = (LPSYSTEMBLOCKDATASTRUCT)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
	for(i = 0;i < lpSystemBlockHead->m_nDataNum; i++)
	{
		//检查删除标记
		if(lpBlockDataMap[i].m_nVarDataOffset == 0)
		{
			Trace("CSystemManage::LoadObjectData", MF_TRACE_LEVEL_INNER_DEBUG, 100008003, "发现删除的对象数据，对象编号：%d", lpBlockDataMap[i].m_nInnerNo);
			//直接忽略
			continue;
		}

		//检查一下是否存在
		lpObjectInfo		= NULL;
		lpBlockVarData		= (LPSYSTEMBLOCKVARDATASTRUCT)(((LPBYTE)lpSystemBlockHead) + lpBlockDataMap[i].m_nVarDataOffset);
		lpFileObjectInfo	= (LPFILE_OBJECTDEF)&(lpBlockVarData->m_pDataContent);
		if(m_mapObject.Get(lpFileObjectInfo->m_nObjectID) != NULL)
		{
			//有相同OBJECT编号，系统出错了
			Trace("CSystemManage::LoadObjectData", MF_TRACE_LEVEL_FAILED, 100008004, "初始化对象数据时，发现对象编号重复（%d）", lpFileObjectInfo->m_nObjectID);
			return MF_SYS_OBJECT_REPEATERROR;
		}
		
		//校验一下文件是否存在
		lpMemDBFileDef = m_arMemDBFile[lpFileObjectInfo->m_bFileNo];
		if(lpMemDBFileDef == NULL)
		{
			//对象表对应的文件编号查询到的数据为空，系统出错了
			Trace0("CSystemManage::LoadObjectData", MF_TRACE_LEVEL_FAILED, 100008006, "初始化对象数据时，查找返回成功，但发现指针为空");
			return MF_INNER_POINTER_NULL;
		}

		nRet = GetMemoryFileInstance(lpFileObjectInfo->m_bFileNo, pVirtualFile);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pFile = (CMemoryFile*)pVirtualFile;

		lpObjectInfo = new OBJECTDEF;
		lpObjectTemp = lpObjectInfo;
		nFieldNum	 = lpFileObjectInfo->m_nFieldNum1;
		lpFieldDef   = &(lpFileObjectInfo->m_stFirstField);
		n			 = 0;
		bCount	     = (BYTE)((lpBlockVarData->m_nActualLength - sizeof(FILE_OBJECTDEF))/sizeof(FILE_OBJECTFIELDDEF)) + 1;
		while(TRUE)
		{
			memcpy(lpObjectTemp->m_lpszName, lpFileObjectInfo->m_lpszName, 32*sizeof(TCHAR));
			lpObjectTemp->m_nDataID				= MakeDataID(lpSystemBlockHead->m_bFileNo, lpSystemBlockHead->m_nBlockNo, lpBlockDataMap[i].m_nInnerNo);
			lpObjectTemp->m_nObjectID			= lpFileObjectInfo->m_nObjectID;
			lpObjectTemp->m_nBlockSize			= lpFileObjectInfo->m_nBlockSize;
			lpObjectTemp->m_bFileNo				= lpFileObjectInfo->m_bFileNo;
			lpObjectTemp->m_nFieldNum			= nFieldNum;
			lpObjectTemp->m_bImplementClass		= lpFileObjectInfo->m_bImplementClass;
			lpObjectTemp->m_pDataNum			= pFile->GetObjectDataPtr(lpFileObjectInfo->m_nObjectID, FALSE); 
			lpObjectTemp->m_bMaxTransactionNum	= CSystemManage::instance().GetParameterValue(MF_OBJECT_TRANSACTION_MAXNUM);
			lpObjectTemp->m_lpTimestampArray	= new long long[lpObjectTemp->m_bMaxTransactionNum];
			memset(lpObjectTemp->m_lpTimestampArray, 0, lpObjectTemp->m_bMaxTransactionNum*sizeof(long long));
			
			//临时处理方案
			if(lpObjectTemp->m_bImplementClass == 0)
			{
				lpObjectTemp->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_COMMON;
			}

			//加载对象列数据
			lpObjectTemp->m_lpField	= new OBJECTFIELDDEF[lpObjectTemp->m_nFieldNum];
			lpObjectTemp->InitalMap();
			if(lpBlockVarData->m_nNextOffset == 0)
			{
				for(j = 0;j < lpObjectTemp->m_nFieldNum; j++, n++)
				{
					lpObjectTemp->m_lpField[j].m_bObjectFieldNo	= lpFieldDef[n].m_bObjectFieldNo;
					lpObjectTemp->m_lpField[j].m_bFieldType		= lpFieldDef[n].m_bFieldType;
					lpObjectTemp->m_lpField[j].m_bCharLen		= lpFieldDef[n].m_bCharLen;
					lpObjectTemp->m_lpField[j].m_bAllowNull		= lpFieldDef[n].m_bAllowNull;
					memcpy(lpObjectTemp->m_lpField[j].m_lpszName, lpFieldDef[n].m_lpszName, 32*sizeof(TCHAR));
					if(lpObjectTemp->m_lpField[j].m_bObjectFieldNo != j+1 && lpObjectTemp->m_lpField[j].m_bObjectFieldNo != 0)
					{
						//要求列号必须和顺序一一对应，如果列被删除，只是把列号清空，但列数据同样存在
						Trace("CSystemManage::LoadObjectData", MF_TRACE_LEVEL_FAILED, 100008007, "初始化对象数据时，发现列的序号和位置不是一一对应，对象ID：%d、列序号：%d、数组位置：%d", lpObjectInfo->m_nObjectID, lpObjectInfo->m_lpField[j].m_bObjectFieldNo, j);
						return MF_SYS_OBJECT_FIELDORDERERROR;
					}
					if(lpObjectTemp->m_lpField[j].m_bObjectFieldNo != 0)
					{
						lpObjectTemp->m_mapName2FieldNo.Set(lpObjectTemp->m_lpField[j].m_lpszName, (LPVOID)lpObjectTemp->m_lpField[j].m_bObjectFieldNo);
					}
				}
			}
			else
			{
				for(j = 0; j < lpObjectTemp->m_nFieldNum; j++, n++)
				{
					if(n >= bCount)
					{
						nOffset = lpBlockVarData->m_nNextOffset;
						if(nOffset == 0)
						{
							//错误
							Trace("CSystemManage::LoadObjectData", MF_TRACE_LEVEL_FAILED, 100008008, "加载对象时，内存异常！，对象ID：%d", lpObjectInfo->m_nObjectID);
							return MF_FAILED;
						}
						else
						{
							lpBlockVarData	= (LPSYSTEMBLOCKVARDATASTRUCT)(((LPBYTE)lpSystemBlockHead) + nOffset);
							bCount	        = (BYTE)(lpBlockVarData->m_nActualLength / sizeof(FILE_OBJECTFIELDDEF));
							lpFieldDef		= (LPFILE_OBJECTFIELDDEF)(&lpBlockVarData->m_pDataContent);
							n				= 0;
						}
					}
					lpObjectTemp->m_lpField[j].m_bObjectFieldNo	= lpFieldDef[n].m_bObjectFieldNo;
					lpObjectTemp->m_lpField[j].m_bFieldType		= lpFieldDef[n].m_bFieldType;
					lpObjectTemp->m_lpField[j].m_bCharLen		= lpFieldDef[n].m_bCharLen;
					lpObjectTemp->m_lpField[j].m_bAllowNull		= lpFieldDef[n].m_bAllowNull;
					memcpy(lpObjectTemp->m_lpField[j].m_lpszName, lpFieldDef[n].m_lpszName, 32*sizeof(TCHAR));
					if(lpObjectTemp->m_lpField[j].m_bObjectFieldNo != j+1 && lpObjectTemp->m_lpField[j].m_bObjectFieldNo != 0)
					{
						//要求列号必须和顺序一一对应，如果列被删除，只是把列号清空，但列数据同样存在
						Trace("CSystemManage::LoadObjectData", MF_TRACE_LEVEL_FAILED, 100008009, "初始化对象数据时，发现列的序号和位置不是一一对应，对象ID：%d、列序号：%d、数组位置：%d", lpObjectInfo->m_nObjectID, lpObjectInfo->m_lpField[j].m_bObjectFieldNo, j);
						return MF_SYS_OBJECT_FIELDORDERERROR;
					}
					if(lpObjectTemp->m_lpField[j].m_bObjectFieldNo != 0)
					{
						lpObjectTemp->m_mapName2FieldNo.Set(lpObjectTemp->m_lpField[j].m_lpszName, (LPVOID)lpObjectTemp->m_lpField[j].m_bObjectFieldNo);
					}
				}
			}

			if(lpFileObjectInfo->m_bObjectType == MF_OBJECT_COMMON)
			{
				lpObjectTemp->m_bObjectType = MF_OBJECT_COMMON; 
				break;
			}
		}

		m_mapObject.Set(lpObjectInfo->m_nObjectID, lpObjectInfo);
		m_mapName2Object.Set(lpObjectInfo->m_lpszName, lpObjectInfo);
	}
	return MF_OK;
}

//考虑所有数据都为定长数据，这样就不需要其他的数据开销
int CSystemManage::LoadIndexData(LPSYSTEMBLOCKHEAD lpSystemBlockHead)
{
	int i;
	LPINDEXDEF lpIndexInfo;
	LPFILE_INDEXDEF lpFileIndexInfo;
	LPOBJECTDEF lpObjectInfo;
	if(lpSystemBlockHead->m_nObjectID != MF_SYS_OBJECTTYPE_INDEX)
	{
		//按道理不应该出现这种情况
		Trace("CSystemManage::LoadIndexData", MF_TRACE_LEVEL_FAILED, 100009001, "初始化索引数据时，发现传入块的OBJECTID不正确，OBJECTID：%d，正确值为：%d", lpSystemBlockHead->m_nObjectID, MF_SYS_OBJECTTYPE_INDEX);
		return MF_INNER_SYS_OBJECTMAP_DATAERROR;
	}
	if(lpSystemBlockHead->m_nBlockDataStructSize != sizeof(FILE_INDEXDEF))
	{
		//结构体发生变化了？
		Trace("CSystemManage::LoadIndexData", MF_TRACE_LEVEL_FAILED, 100009002, "初始化索引数据时，发现传入块的m_nBlockDataStructSize数据不正确，m_nBlockDataStructSize：%d，正确值为：%d", lpSystemBlockHead->m_nBlockDataStructSize, sizeof(FILE_INDEXDEF));
		return MF_INNER_ITEMDATASIZE_ERROR;
	}
	//直接把定长数据转换成结构体
	lpFileIndexInfo = (LPFILE_INDEXDEF)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
	for(i = 0;i < lpSystemBlockHead->m_nDataNum; i++)
	{
		//先检查删除标志
		if(lpFileIndexInfo[i].m_bDropFlag != 0)
		{
			Trace("CSystemManage::LoadObjectData", MF_TRACE_LEVEL_INNER_DEBUG, 100009003, "发现删除的索引数据，索引编号：%d、对象编号：%d、索引名：%s", lpFileIndexInfo[i].m_nIndexID, lpFileIndexInfo[i].m_nObjectID, lpFileIndexInfo[i].m_lpszName);
			//直接忽略
			continue;
		}
		//先查一下是否存在
		lpObjectInfo = (LPOBJECTDEF)m_mapObject.Get(lpFileIndexInfo[i].m_nObjectID);
		if(lpObjectInfo == NULL)
		{
			//没找到索引对应的对象，系统出错了
			Trace("CSystemManage::LoadIndexData", MF_TRACE_LEVEL_FAILED, 100009004, "初始化索引数据时，没找到对应对象数据，索引编号：%d、对象编号：%d、索引名：%s", lpFileIndexInfo[i].m_nIndexID, lpFileIndexInfo[i].m_nObjectID, lpFileIndexInfo[i].m_lpszName);
			continue;
		}

		if(lpObjectInfo == NULL)
		{
			//索引对应的对象取出来为空，系统出错了
			Trace("CSystemManage::LoadIndexData", MF_TRACE_LEVEL_FAILED, 100009005, "初始化索引数据时，找到对应对象数据，但返回的指针为空，索引编号：%d、对象编号：%d、索引名：%s", lpFileIndexInfo[i].m_nIndexID, lpFileIndexInfo[i].m_nObjectID, lpFileIndexInfo[i].m_lpszName);
			return MF_INNER_POINTER_NULL;
		}
		
		lpIndexInfo = new INDEXDEF;
		lpIndexInfo->m_nDataID = MakeDataID(lpSystemBlockHead->m_bFileNo, lpSystemBlockHead->m_nBlockNo, lpFileIndexInfo[i].m_nInnerNo);
		lpIndexInfo->m_nIndexID = lpFileIndexInfo[i].m_nIndexID;
		memcpy(lpIndexInfo->m_lpszName, lpFileIndexInfo[i].m_lpszName, 32*sizeof(TCHAR));
		lpIndexInfo->m_nBlockSize	= lpFileIndexInfo[i].m_nBlockSize;
		lpIndexInfo->m_bIndexType	= lpFileIndexInfo[i].m_bIndexType;
		lpIndexInfo->m_bFileNo		= lpFileIndexInfo[i].m_bFileNo;
		lpIndexInfo->m_nObjectID	= lpFileIndexInfo[i].m_nObjectID;
		lpIndexInfo->m_bFieldNo[0]	= lpFileIndexInfo[i].m_bFieldNo[0];
		lpIndexInfo->m_bFieldNo[1]	= lpFileIndexInfo[i].m_bFieldNo[1];
		lpIndexInfo->m_bFieldNo[2]	= lpFileIndexInfo[i].m_bFieldNo[2];
		lpIndexInfo->m_bFieldNo[3]	= lpFileIndexInfo[i].m_bFieldNo[3];
		lpIndexInfo->m_bConstraintType = lpFileIndexInfo[i].m_bConstraintType;
		lpIndexInfo->m_bStatus		= 0;
		lpIndexInfo->m_nTimestamp	= 0;
		lpIndexInfo->m_pNext		= lpObjectInfo->m_lpIndex;
		lpObjectInfo->m_lpIndex		= lpIndexInfo;

		m_mapIndex.Set(lpIndexInfo->m_nIndexID, lpIndexInfo);
	}
	return MF_OK;
}

//考虑所有数据都为定长数据，这样就不需要其他的数据开销
int CSystemManage::LoadSequenceData(LPSYSTEMBLOCKHEAD lpSystemBlockHead)
{
	int i;
	LPSEQUENCEDEF lpSequenceInfo;
	LPFILE_SEQUENCEDEF lpFileSequenceInfo;
	if(lpSystemBlockHead->m_nObjectID != MF_SYS_OBJECTTYPE_SEQUENCE)
	{
		//按道理不应该出现这种情况
		Trace("CSystemManage::LoadSequenceData", MF_TRACE_LEVEL_FAILED, 100010001, "初始化序列数据时，发现传入块的OBJECTID不正确，OBJECTID：%d，正确值为：%d", lpSystemBlockHead->m_nObjectID, MF_SYS_OBJECTTYPE_SEQUENCE);
		return MF_INNER_SYS_OBJECTMAP_DATAERROR;
	}
	if(lpSystemBlockHead->m_nBlockDataStructSize != sizeof(FILE_SEQUENCEDEF))
	{
		//结构体发生变化了？
		Trace("CSystemManage::LoadSequenceData", MF_TRACE_LEVEL_FAILED, 100010002, "初始化序列数据时，发现传入块的m_nBlockDataStructSize数据不正确，m_nBlockDataStructSize：%d，正确值为：%d", lpSystemBlockHead->m_nBlockDataStructSize, sizeof(FILE_SEQUENCEDEF));
		return MF_INNER_ITEMDATASIZE_ERROR;
	}
	//直接把定长数据转换成结构体
	lpFileSequenceInfo = (LPFILE_SEQUENCEDEF)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
	for(i = 0;i < lpSystemBlockHead->m_nDataNum; i++)
	{
		//检查删除标志
		if(lpFileSequenceInfo[i].m_bDropFlag != 0)
		{
			Trace("CSystemManage::LoadSequenceData", MF_TRACE_LEVEL_INNER_DEBUG, 100010003, "发现删除的序列数据，序列名：%s", lpFileSequenceInfo[i].m_lpszName);
			continue;
		}

		//检查一下是否存在
		if(m_mapSequence.Get(lpFileSequenceInfo[i].m_lpszName) != NULL)
		{
			//有相同名字的序列，系统出错了
			Trace("CSystemManage::LoadSequenceData", MF_TRACE_LEVEL_FAILED, 100010004, "初始化序列数据时，发现重名序列，序列名：%s", lpFileSequenceInfo[i].m_lpszName);
			return MF_SYS_SEQUENCE_NAME_REPEATERROR;
		}

		lpSequenceInfo = new SEQUENCEDEF;
		lpSequenceInfo->m_nDataID = MakeDataID(lpSystemBlockHead->m_bFileNo, lpSystemBlockHead->m_nBlockNo, lpFileSequenceInfo[i].m_nInnerNo);
		memcpy(lpSequenceInfo->m_lpszName, lpFileSequenceInfo[i].m_lpszName, 32*sizeof(TCHAR));
		lpSequenceInfo->m_nCurrentVal = lpFileSequenceInfo[i].m_nCurrentVal;
		lpSequenceInfo->m_nCacheEndVal = lpFileSequenceInfo[i].m_nCurrentVal; //默认不读取可以的序列，以免不是用的序列在系统重复启动就变大了
		lpSequenceInfo->m_nIncrementBy = lpFileSequenceInfo[i].m_nIncrementBy;
		lpSequenceInfo->m_bMaxValError = FALSE;
		m_mapSequence.Set(lpSequenceInfo->m_lpszName, lpSequenceInfo);
	}
	return MF_OK;
}

int CSystemManage::LoadUserData(LPSYSTEMBLOCKHEAD lpSystemBlockHead)
{
	int i;
	LPUSERINFODEF lpUserInfo;
	LPFILE_USERINFO lpFileUserInfo;

	if(lpSystemBlockHead->m_nObjectID != MF_SYS_OBJECTTYPE_USERINFO)
	{
		//按道理不应该出现这种情况
		Trace("CSystemManage::LoadUserData", MF_TRACE_LEVEL_FAILED, 1000095001, "初始化用户数据时，发现传入块的OBJECTID不正确，OBJECTID：%d，正确值为：%d", lpSystemBlockHead->m_nObjectID, MF_SYS_OBJECTTYPE_USERINFO);
		return MF_INNER_SYS_OBJECTMAP_DATAERROR;
	}
	if(lpSystemBlockHead->m_nBlockDataStructSize != sizeof(FILE_USERINFO))
	{
		Trace("CSystemManage::LoadUserData", MF_TRACE_LEVEL_FAILED, 1000095002, "初始化对象数据时，发现传入块的m_nBlockDataStructSize数据不正确，m_nBlockDataStructSize：%d，正确值为：%d", lpSystemBlockHead->m_nBlockDataStructSize, sizeof(SYSTEMBLOCKDATASTRUCT));
		return MF_INNER_ITEMDATASIZE_ERROR;
	}

	//直接把定长数据转换成结构体
	lpFileUserInfo = (LPFILE_USERINFO)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
	for(i = 0;i < lpSystemBlockHead->m_nDataNum; i++)
	{
		//检查删除标记
		if(lpFileUserInfo[i].m_bDropFlag == 1)
		{
			Trace("CSystemManage::LoadUserData", MF_TRACE_LEVEL_INNER_DEBUG, 1000095003, "发现删除的用户数据，用户编号：%d", lpFileUserInfo[i].m_nUserID);
			//直接忽略
			continue;
		}

		//检查一下是否存在
		if(NULL != m_mapUserInfo.Get(lpFileUserInfo[i].m_nUserID))
		{
			//有相同User编号，系统出错了
			Trace("CSystemManage::LoadUserData", MF_TRACE_LEVEL_FAILED, 1000095004, "初始化用户数据时，发现用户编号重复（%d）", lpFileUserInfo[i].m_nUserID);
			return MF_SYS_USER_REPEATERROR;
		}

		lpUserInfo						= new USERINFODEF;
		lpUserInfo->m_nUserID			= lpFileUserInfo[i].m_nUserID;	
		lpUserInfo->m_bStatus			= lpFileUserInfo[i].m_bStatus;
		memcpy(lpUserInfo->m_pUserName, lpFileUserInfo[i].m_pUserName, 24);
		memcpy(lpUserInfo->m_pPassword, lpFileUserInfo[i].m_pPassword, 24);
		memcpy(lpUserInfo->m_bAuthority, lpFileUserInfo[i].m_bAuthorityID, 64);

		m_mapUserInfo.Set(lpUserInfo->m_nUserID, lpUserInfo);
		m_mapName2UserInfo.Set(lpUserInfo->m_pUserName, lpUserInfo);
	}
	return MF_OK;
}

int CSystemManage::LoadAuthorityData(LPSYSTEMBLOCKHEAD lpSystemBlockHead)
{	
	int i;
	LPAUTHORITYINFO lpAuthorityInfo;
	LPFILE_AUTHORITY lpFileAuthority;

	if(lpSystemBlockHead->m_nObjectID != MF_SYS_OBJECTTYPE_AUTHORITY)
	{
		//按道理不应该出现这种情况
		Trace("CSystemManage::LoadAuthorityData", MF_TRACE_LEVEL_FAILED, 1000072001, "初始化权限数据时，发现传入块的OBJECTID不正确，OBJECTID：%d，正确值为：%d", lpSystemBlockHead->m_nObjectID, MF_SYS_OBJECTTYPE_AUTHORITY);
		return MF_INNER_SYS_OBJECTMAP_DATAERROR;
	}
	if(lpSystemBlockHead->m_nBlockDataStructSize != sizeof(FILE_AUTHORITY))
	{
		Trace("CSystemManage::LoadAuthorityData", MF_TRACE_LEVEL_FAILED, 1000072002, "初始化权限数据时，发现传入块的m_nBlockDataStructSize数据不正确，m_nBlockDataStructSize：%d，正确值为：%d", lpSystemBlockHead->m_nBlockDataStructSize, sizeof(SYSTEMBLOCKDATASTRUCT));
		return MF_INNER_ITEMDATASIZE_ERROR;
	}

	//直接把定长数据转换成结构体
	lpFileAuthority = (LPFILE_AUTHORITY)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
	for(i = 0;i < lpSystemBlockHead->m_nDataNum; i++)
	{
		//检查删除标记
		if(lpFileAuthority[i].m_bDropFlag == 1)
		{
			Trace("CSystemManage::LoadAuthorityData", MF_TRACE_LEVEL_INNER_DEBUG, 1000072003, "发现删除的权限数据，权限编号：%d", lpFileAuthority[i].m_bAuthorityID);
			//直接忽略
			continue;
		}

		//检查一下是否存在
		if(m_mapAuthority.Get(lpFileAuthority[i].m_bAuthorityID) != NULL)
		{
			//有相同User编号，系统出错了
			Trace("CSystemManage::LoadAuthorityData", MF_TRACE_LEVEL_FAILED, 1000072004, "初始化权限数据时，发现权限编号重复（%d）", lpFileAuthority[i].m_bAuthorityID);
			return MF_SYS_USER_REPEATERROR;
		}

		lpAuthorityInfo							= new AUTHORITYINFO;
		lpAuthorityInfo->m_bAuthorityID			= lpFileAuthority[i].m_bAuthorityID;	
		memcpy(lpAuthorityInfo->m_pAuthorityName, lpFileAuthority[i].m_pAuthorityName, 32);
		memcpy(lpAuthorityInfo->m_pAuthorityDesc, lpFileAuthority[i].m_pAuthorityDesc, 128);
	
		m_mapAuthority.Set(lpAuthorityInfo->m_bAuthorityID, lpAuthorityInfo);
		m_mapName2Authority.Set(lpAuthorityInfo->m_pAuthorityName, lpAuthorityInfo);
	}
	return MF_OK;
}

int CSystemManage::GetSystemFreeBlock(long long nTimestamp, int nSysObjectID, int nFreeSpace, LPSYSTEMBLOCKHEAD &lpSystemBlockHead)
{
	long long nDataOffsetTemp, nDataOffset;
	LPBASEFILEBLOCKMAPHEAD lpBaseFileBlockMapHead;
	LPBASEFILEBLOCKMAP lpBaseFileBlockMap, lpPrevBlockMap;

	lpSystemBlockHead = NULL;
	if(m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nID == nSysObjectID)
	{
		//获取空闲块，用于插入系统数据
		lpPrevBlockMap = NULL;
		m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFinishedTimestamp = 0;
		nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFreeBlockMapOffset;
		while(nDataOffset != 0)
		{
			lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
			lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			//检查空余空间，是否够
			if(lpSystemBlockHead->m_nVarDataInsertOffset - lpSystemBlockHead->m_nDataInsertOffset > nFreeSpace)
			{
				return MF_OK;
			}
			else
			{
				//检查空间是否太小了，考虑从空闲列表移除
				if(lpSystemBlockHead->m_nVarDataInsertOffset - lpSystemBlockHead->m_nDataInsertOffset < 2048 || 
					(nSysObjectID == MF_SYS_OBJECTTYPE_OBJECT && lpSystemBlockHead->m_nVarDataInsertOffset - lpSystemBlockHead->m_nDataInsertOffset < MF_SYS_BLOCKFREESIZE))
				{
					//实现把Block块从空闲链表移到数据链表中
					if(lpPrevBlockMap == NULL)
					{
						nDataOffsetTemp = lpBaseFileBlockMap->m_nNextOffset;
						lpBaseFileBlockMap->m_nNextOffset = m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFullBlockMapOffset;
						m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFullBlockMapOffset = nDataOffset;
						m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFreeBlockMapOffset = nDataOffsetTemp;
						nDataOffset = nDataOffsetTemp;
					}
					else
					{
						nDataOffsetTemp = lpBaseFileBlockMap->m_nNextOffset;
						lpBaseFileBlockMap->m_nNextOffset = m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFullBlockMapOffset;
						m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFullBlockMapOffset = nDataOffset;
						lpPrevBlockMap->m_nNextOffset = nDataOffsetTemp;
						nDataOffset = nDataOffsetTemp;
					}
				}
				else
				{
					nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
				}
			}
			lpPrevBlockMap = lpBaseFileBlockMap;
		}
	}
	else
	{
		if(m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nID == 0)
		{
			//表示此系统对象还未初始化，所以直接初始化就可以了
			m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nID					 = nSysObjectID;
			m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFullBlockMapOffset	 = 0;
			m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFreeBlockMapOffset	 = 0;
			m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFinishedTimestamp	 = 0;
			m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nPersistentTimestamp  = 0;
			m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nRecordNum			 = 0;
		}
		else
		{
			//怎么被初始化成了别的数据了呢？这怎么可能呢？
			Trace("CSystemManage::GetSystemFreeBlock", MF_TRACE_LEVEL_FAILED, 100011001, "分配数据块时，对应的数据库被使用，本应该为：%d，实际为：%d", nSysObjectID, m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nID);
			return MF_INNER_SYS_OBJECTMAP_DATAERROR;
		}
		
		////系统对象ID不存在
		//Trace("CSystemManage::GetSystemFreeBlock", MF_TRACE_LEVEL_FAILED, 100011001, "为系统对象分配数据块时，对应的系统对象不存在，对象ID：%d", nSysObjectID);
		//return MF_INNER_SYS_OBJECTMAP_DATAERROR;
	}

	lpSystemBlockHead = NULL;
	if(nSysObjectID > 0 && nSysObjectID < 100)
	{
		CCriticalSectionPtr cs(&m_critSysDBFile);
		//分配新的空闲块
		//首先检查一下是否分配了第一个块
		if(m_pMemoryFileHead->m_nBlockNum == 0)
		{
			//初始化应该初始化的一些参数
			m_pMemoryFileHead->m_nBlockMapStructSize	= sizeof(BASEFILEBLOCKMAP);
			m_pMemoryFileHead->m_nBlockMapStartOffset	= m_pMemoryFileHead->m_nFileHeaderSize; //放在头结构体之后
			m_pMemoryFileHead->m_nFileFreePos			= MF_SYS_BLOCKSIZE;//从256KB的位置开始写数据，前面256KB保留给文件头使用吧，按道理此文件可以扩展到接近4GB左右，按经验完全使用不完
			m_pMemoryFileHead->m_nFileFreeSize			= m_pMemoryFileHead->m_nFileTotalSize - m_pMemoryFileHead->m_nFileFreePos;
			lpBaseFileBlockMapHead						= (LPBASEFILEBLOCKMAPHEAD)(m_pFileAddr + m_pMemoryFileHead->m_nBlockMapStartOffset);
			memset(lpBaseFileBlockMapHead, 0, sizeof(BASEFILEBLOCKMAPHEAD));
		}

		//首先判断是否有空块，如果有就直接使用空块
		if(m_pMemoryFileHead->m_nFreeBlockOffset != 0)
		{
			//维护MAP链表
			lpBaseFileBlockMap	= (LPBASEFILEBLOCKMAP)(m_pFileAddr + m_pMemoryFileHead->m_nFreeBlockOffset);
			lpSystemBlockHead	= (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			if(lpSystemBlockHead->m_nBlockSize != MF_SYS_BLOCKSIZE)
			{
				//目前定义系统文件的块大小固定为256KB，所以不可能出现其他的大小，如果出现肯定系统内部出现问题了
				Trace("CSystemManage::GetSystemFreeBlock", MF_TRACE_LEVEL_FAILED, 100011002, "分配数据块时，发现一个空块，但大小不正确(%d)，目前整个系统的系统块大小(%d)", lpSystemBlockHead->m_nBlockSize, MF_SYS_BLOCKSIZE);
				return MF_INNER_SYS_BLOCKSIZE_ERROR;
			}

			m_pMemoryFileHead->m_nFreeBlockOffset = lpBaseFileBlockMap->m_nNextOffset;
			lpBaseFileBlockMap->m_nNextOffset = m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFreeBlockMapOffset;
			m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFreeBlockMapOffset = nDataOffset;

			//填充数据库结构体
			lpSystemBlockHead->m_nObjectID			= nSysObjectID;
			lpSystemBlockHead->m_nDataFlag			= MAKEHEADFLAG('S','B','D','B');
			lpSystemBlockHead->m_nBlockNo			= lpBaseFileBlockMap->m_nBlockNo;
			lpSystemBlockHead->m_nBlockHeadSize		= sizeof(SYSTEMBLOCKHEAD);
			lpSystemBlockHead->m_bStatus			= 0;
			lpSystemBlockHead->m_bFileNo			= m_pMemoryFileHead->m_bFileNo;
			lpSystemBlockHead->m_nObjectID			= nSysObjectID;
			lpSystemBlockHead->m_nInnerMaxNo		= 0;
			lpSystemBlockHead->m_nDataInsertOffset	= lpSystemBlockHead->m_nBlockHeadSize;
			lpSystemBlockHead->m_nVarDataInsertOffset= MF_SYS_BLOCKSIZE;
			lpSystemBlockHead->m_nDataNum			= 0;
			if(nSysObjectID == MF_SYS_OBJECTTYPE_FILE)
			{
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_MEMDBFILEINFO);
			}
			else if(nSysObjectID == MF_SYS_OBJECTTYPE_OBJECT)
			{
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(SYSTEMBLOCKDATASTRUCT);
			}
			else if(nSysObjectID == MF_SYS_OBJECTTYPE_INDEX)
			{
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_INDEXDEF);
			}
			else if(nSysObjectID == MF_SYS_OBJECTTYPE_SEQUENCE)
			{
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_SEQUENCEDEF);
			}
			else if(nSysObjectID == MF_SYS_OBJECTTYPE_USERINFO)
			{
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_USERINFO);
			}
			else if(nSysObjectID == MF_SYS_OBJECTTYPE_AUTHORITY)
			{
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_AUTHORITY);
			}
			else
			{
				//目前还未考虑，暂时统一成定长数据
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(SYSTEMBLOCKDATASTRUCT);
			}
			SetTimestamp(lpSystemBlockHead, nTimestamp);
			m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
		}
		else
		{
			//首先判断空间是否够
			if(m_pMemoryFileHead->m_nFileFreePos + MF_SYS_BLOCKSIZE > m_pMemoryFileHead->m_nFileTotalSize)
			{
				//剩余空间不够
				Trace("CSystemManage::GetSystemFreeBlock", MF_TRACE_LEVEL_FAILED, 100011003, "分配数据块时，发现剩余空间不够，文件大小：%lld，当前空余位置：%lld，需要分配的空间大小为：%d", m_pMemoryFileHead->m_nFileTotalSize, m_pMemoryFileHead->m_nFileFreePos, MF_SYS_BLOCKSIZE);
				return MF_INNER_ALLOWBLOCK_NOENOUGHSPACE;
			}

			//分配一块空间出来
			lpBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_pFileAddr + m_pMemoryFileHead->m_nBlockMapStartOffset);
			lpBaseFileBlockMap	= &lpBaseFileBlockMapHead->m_pBlockMap[lpBaseFileBlockMapHead->m_nBlockMapNum];
			nDataOffset = m_pMemoryFileHead->m_nBlockMapStartOffset + sizeof(BASEFILEBLOCKMAPHEAD) + (lpBaseFileBlockMapHead->m_nBlockMapNum - 1)*sizeof(BASEFILEBLOCKMAP);
			//填充块映射表数据，修改相应的指针
			lpBaseFileBlockMap->m_nBlockOffset		= m_pMemoryFileHead->m_nFileFreePos;
			lpBaseFileBlockMap->m_nBlockNo			= m_pMemoryFileHead->m_nInnerMaxNo;
			m_pMemoryFileHead->m_nInnerMaxNo++;
			m_pMemoryFileHead->m_nFileFreePos		= m_pMemoryFileHead->m_nFileFreePos + MF_SYS_BLOCKSIZE;
			m_pMemoryFileHead->m_nFileFreeSize		= m_pMemoryFileHead->m_nFileTotalSize - m_pMemoryFileHead->m_nFileFreePos;

			lpSystemBlockHead	= (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			//填充数据库结构体
			lpSystemBlockHead->m_nDataFlag			= MAKEHEADFLAG('S','B','D','B');
			lpSystemBlockHead->m_nBlockNo			= lpBaseFileBlockMap->m_nBlockNo;
			lpSystemBlockHead->m_nBlockSize			= MF_SYS_BLOCKSIZE;
			lpSystemBlockHead->m_nBlockHeadSize		= sizeof(SYSTEMBLOCKHEAD);
			lpSystemBlockHead->m_bStatus			= 0;
			lpSystemBlockHead->m_bFileNo			= m_pMemoryFileHead->m_bFileNo;
			lpSystemBlockHead->m_nObjectID			= nSysObjectID;
			lpSystemBlockHead->m_nInnerMaxNo		= 0;
			lpSystemBlockHead->m_nDataInsertOffset	= lpSystemBlockHead->m_nBlockHeadSize;
			lpSystemBlockHead->m_nVarDataInsertOffset= MF_SYS_BLOCKSIZE;
			lpSystemBlockHead->m_nDataNum			= 0;
			if(nSysObjectID == MF_SYS_OBJECTTYPE_FILE)
			{
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_MEMDBFILEINFO);
			}
			else if(nSysObjectID == MF_SYS_OBJECTTYPE_OBJECT)
			{
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(SYSTEMBLOCKDATASTRUCT);
			}
			else if(nSysObjectID == MF_SYS_OBJECTTYPE_INDEX)
			{
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_INDEXDEF);
			}
			else if(nSysObjectID == MF_SYS_OBJECTTYPE_SEQUENCE)
			{
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(FILE_SEQUENCEDEF);
			}
			else
			{
				//目前还未考虑，暂时统一成定长数据
				Trace("CSystemManage::GetSystemFreeBlock", MF_TRACE_LEVEL_FAILED, 100011004, "分配数据块时，发现一个新的类型(%d)", nSysObjectID);
				lpSystemBlockHead->m_nBlockDataStructSize = sizeof(SYSTEMBLOCKDATASTRUCT);
			}

			//加入到链表中
			lpBaseFileBlockMap->m_nNextOffset = m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFreeBlockMapOffset;
			m_pMemoryFileHead->m_stuFileObjectData[nSysObjectID].m_nFreeBlockMapOffset = nDataOffset;
			lpBaseFileBlockMapHead->m_nBlockMapNum++;
			m_pMemoryFileHead->m_nBlockNum++;
			SetTimestamp(lpSystemBlockHead, nTimestamp);
			m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
		}
	}

	return MF_OK;
}

int CSystemManage::AddMemDBFile(long long nTimestamp, LPCTSTR lpszFilePath, LPCTSTR lpszMemFileName, BYTE bFileType, long long nFileSize)
{
	int i,nRet;
	string strMemFileName;
	LPMEMDBFILEDEF lpMemDBFileDef;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPFILE_MEMDBFILEINFO lpFileMemDBFileInfo;
	CCriticalSectionPtr cs(&m_critFile);
	try
	{
		nRet = CreateMemDBFileName(lpszMemFileName, strMemFileName);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		nRet = GetSystemFreeBlock(nTimestamp, MF_SYS_OBJECTTYPE_FILE, sizeof(FILE_MEMDBFILEINFO), lpSystemBlockHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpSystemBlockHead == NULL)
		{
			Trace0("CSystemManage::AddMemDBFile", MF_TRACE_LEVEL_FAILED, 100012001, "添加内存文件时，调GetSystemFreeBlock函数返回正确，但块空间头却为空指针");
			return MF_INNER_POINTER_NULL;
		}

		lpFileMemDBFileInfo = (LPFILE_MEMDBFILEINFO)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
		for(i = 0;i < lpSystemBlockHead->m_nDataNum; i++)
		{
			if (lpFileMemDBFileInfo[i].m_bDropFlag != 0)
			{
				//忽略已经删除的文件
				continue;
			}
			if(_tcsicmp(lpszFilePath, lpFileMemDBFileInfo[i].m_lpszFilePath) == 0)
			{
				//文件路径重复
				Trace("CSystemManage::AddMemDBFile", MF_TRACE_LEVEL_FAILED, 100012002, "添加内存文件时，出现文件路径重复，原文件编号：%d，文件路径：%s", lpFileMemDBFileInfo[i].m_bFileNo, lpszFilePath);
				return MF_SYS_DBFILE_FILENAME_ERROR;
			}
			else if(strMemFileName.compare(lpFileMemDBFileInfo[i].m_lpszMemFileName) == 0)
			{
				//内存文件名重复
				Trace("CSystemManage::AddMemDBFile", MF_TRACE_LEVEL_FAILED, 100012003, "添加内存文件时，出现内存文件路径重复，原文件编号：%d，内存文件名：%s", lpFileMemDBFileInfo[i].m_bFileNo, lpszMemFileName);
				return MF_SYS_DBFILE_MEMFILENAME_ERROR;
			}
		}

		lpFileMemDBFileInfo = (LPFILE_MEMDBFILEINFO)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nDataInsertOffset);
		lpFileMemDBFileInfo->m_nInnerNo	= lpSystemBlockHead->m_nInnerMaxNo;
		lpSystemBlockHead->m_nInnerMaxNo++;
		lpFileMemDBFileInfo->m_bFileNo	= m_pMemoryFileHead->m_bFileMaxNo;
		m_pMemoryFileHead->m_bFileMaxNo++;
		lpFileMemDBFileInfo->m_bFileType	= bFileType;
		lpFileMemDBFileInfo->m_bDropFlag	= 0;
		lpFileMemDBFileInfo->m_nFileSize	= nFileSize;
		_tcscpy(lpFileMemDBFileInfo->m_lpszFilePath, lpszFilePath);
		_tcscpy(lpFileMemDBFileInfo->m_lpszMemFileName, strMemFileName.c_str());
		lpFileMemDBFileInfo->m_bFileCMD	= MF_SYS_FILECMD_NEWFILE;//请求新建文件
		lpSystemBlockHead->m_nDataNum++;
		lpSystemBlockHead->m_nDataInsertOffset	+= lpSystemBlockHead->m_nBlockDataStructSize;
		m_pMemoryFileHead->m_bFileCMD			= 1;//请求进程VernoxStorage.exe创建对应的文件
		for(i = 0; i < 20000; i++)
		{
			if(m_pMemoryFileHead->m_bFileCMD == 32)
			{
				break;
			}
			Sleep(32);
		}

		if(lpFileMemDBFileInfo->m_bFileCMD != 0)
		{
			//显示一下失败原因，并删除最后一条数据
			lpSystemBlockHead->m_nDataNum--;
			lpSystemBlockHead->m_nDataInsertOffset	-= lpSystemBlockHead->m_nBlockDataStructSize;
			if(lpFileMemDBFileInfo->m_bFileCMD == 255)
			{
				Trace("CSystemManage::AddMemDBFile", MF_TRACE_LEVEL_FAILED, 100012004, "添加内存文件时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage检查到添加的文件编号重复错误，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICE_FILENO_ERROR;
			}
			else if(lpFileMemDBFileInfo->m_bFileCMD == 254)
			{
				Trace("CSystemManage::AddMemDBFile", MF_TRACE_LEVEL_FAILED, 100012005, "添加内存文件时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage检查到添加的文件路径重复错误，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICE_FILEPATH_ERROR;
			}
			else if(lpFileMemDBFileInfo->m_bFileCMD == 253)
			{
				Trace("CSystemManage::AddMemDBFile", MF_TRACE_LEVEL_FAILED, 100012006, "添加内存文件时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage检查到添加的内存文件名重复错误，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICE_MEMFILE_ERROR;
			}
			else if(lpFileMemDBFileInfo->m_bFileCMD == 252)
			{
				Trace("CSystemManage::AddMemDBFile", MF_TRACE_LEVEL_FAILED, 100012007, "添加内存文件时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage新建文件出现错误，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICE_NEWFILE_FAILED;
			}
			else
			{
				Trace("CSystemManage::AddMemDBFile", MF_TRACE_LEVEL_FAILED, 100012008, "添加内存文件时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage出现未知错误，错误编码：%d，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileCMD, lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICESTORAGE_NOTRESPONSE;
			}
		}

		//完成文件的创建工作，处理后续工作
		m_pMemoryFileHead->m_bFileCMD = 0;
		SetTimestamp(lpSystemBlockHead, nTimestamp);

		lpMemDBFileDef = new MEMDBFILEDEF;
		memset(lpMemDBFileDef, 0, sizeof(MEMDBFILEDEF));
		lpMemDBFileDef->m_nDataID = MakeDataID(lpSystemBlockHead->m_bFileNo, lpSystemBlockHead->m_nBlockNo, lpFileMemDBFileInfo->m_nInnerNo); 
		lpMemDBFileDef->m_bFileNo = lpFileMemDBFileInfo->m_bFileNo;
		lpMemDBFileDef->m_bFileType = lpFileMemDBFileInfo->m_bFileType;
		lpMemDBFileDef->m_pLoadSize = &lpFileMemDBFileInfo->m_nLoadSize;
		memcpy(lpMemDBFileDef->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszFilePath, 256*sizeof(TCHAR));
		memcpy(lpMemDBFileDef->m_lpszMemFileName, lpFileMemDBFileInfo->m_lpszMemFileName, 64*sizeof(TCHAR));
		lpMemDBFileDef->m_nFileSize = lpFileMemDBFileInfo->m_nFileSize;
		lpMemDBFileDef->m_pInstance = NULL;
		nRet = OpenMemDBFile(lpMemDBFileDef);
		if(nRet != MF_OK)
		{
			delete lpMemDBFileDef;
			return nRet;
		}
		m_arMemDBFile[lpMemDBFileDef->m_bFileNo] = lpMemDBFileDef;
		SetObjectTimestamp(MF_SYS_OBJECTTYPE_FILE, nTimestamp);
	}
	catch (...)
	{
		Trace("CSystemManage::AddMemDBFile", MF_TRACE_LEVEL_FAILED, 100012099, "添加内存文件时，文件路径：%s，内存文件名：%s，错误码：%d", lpszFilePath, lpszMemFileName, GetLastError());
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::AlterMemDBFilePath(long long nTimestamp, BYTE bFileNo, LPCTSTR lpszOldFilePath, LPCTSTR lpszNewFilePath)
{
	int i, nRet, nOffset;
	LPMEMDBFILEDEF lpMemDBFileDef;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPFILE_MEMDBFILEINFO lpFileMemDBFileInfo;
	CCriticalSectionPtr cs(&m_critFile);
	try
	{
		//因为文件需要通过名字来查找比较少且数据量也不会太多，所以直接遍历整个MAP来找数据
		lpMemDBFileDef = m_arMemDBFile[bFileNo];
		if(lpMemDBFileDef == NULL)
		{
			Trace("CSystemManage::AlterMemDBFilePath", MF_TRACE_LEVEL_FAILED, 100013001, "修改文件路径时，未找到原来的内存文件，原文件路径：%s，新文件路径：%s", lpszOldFilePath, lpszNewFilePath);
			return MF_SYS_DBFILE_NOTEXIST;
		}

		nRet = ConvertDataID2Offset(lpMemDBFileDef->m_nDataID, nOffset, lpSystemBlockHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpSystemBlockHead == NULL)
		{
			Trace("CSystemManage::AlterMemDBFilePath", MF_TRACE_LEVEL_FAILED, 100013002, "修改文件路径时，调ConvertDataID2Offset函数返回成功，但对应块指针为空，数据ID：%lld", lpMemDBFileDef->m_nDataID);
			return MF_INNER_POINTER_NULL;
		}

		lpFileMemDBFileInfo = (LPFILE_MEMDBFILEINFO)(((LPBYTE)lpSystemBlockHead) + nOffset);
		if(_tcsicmp(lpszOldFilePath, lpFileMemDBFileInfo->m_lpszFilePath) != 0)
		{
			//查找的数据有问题
			Trace("CSystemManage::AlterMemDBFilePath", MF_TRACE_LEVEL_FAILED, 100013003, "修改文件路径时，调ConvertDataID2Offset函数返回成功，但对应块数据不匹配，数据ID：%lld，希望值：%s，实际值：%s", lpMemDBFileDef->m_nDataID, lpszOldFilePath, lpFileMemDBFileInfo->m_lpszFilePath);
			return MF_INNER_INNERNO_DATAERROR;
		}

		_tcscpy(lpFileMemDBFileInfo->m_lpszFilePath, lpszNewFilePath);
		lpFileMemDBFileInfo->m_bFileCMD			= MF_SYS_FILECMD_CHANGEFILEPATH;//请求新建文件
		m_pMemoryFileHead->m_bFileCMD			= 1;//请求进程VernoxStorage.exe创建对应的文件
		for(i = 0; i < 10000; i++)
		{
			if(m_pMemoryFileHead->m_bFileCMD == 32)
			{
				break;
			}
			Sleep(20);
		}

		if(lpFileMemDBFileInfo->m_bFileCMD != 0)
		{
			//显示一下失败原因，并删除最后一条数据
			_tcscpy(lpFileMemDBFileInfo->m_lpszFilePath, lpszOldFilePath);
			if(lpFileMemDBFileInfo->m_bFileCMD == 254)
			{
				Trace("CSystemManage::AlterMemDBFilePath", MF_TRACE_LEVEL_FAILED, 100013004, "修改文件路径时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage检查到添加的文件路径重复错误，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICE_FILEPATH_ERROR;
			}
			else if(lpFileMemDBFileInfo->m_bFileCMD == 251)
			{
				Trace("CSystemManage::AlterMemDBFilePath", MF_TRACE_LEVEL_FAILED, 100013005, "修改文件路径时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage没找到对应文件，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICE_NOTEXIST;
			}
			else if(lpFileMemDBFileInfo->m_bFileCMD == 250)
			{
				Trace("CSystemManage::AlterMemDBFilePath", MF_TRACE_LEVEL_FAILED, 100013006, "修改文件路径时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage改变文件路径失败，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICE_CHANGEFILE_FAILED;
			}
			else
			{
				Trace("CSystemManage::AlterMemDBFilePath", MF_TRACE_LEVEL_FAILED, 100013007, "修改文件路径时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage出现未知错误，错误编码：%d，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileCMD, lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICESTORAGE_NOTRESPONSE;
			}
		}
		//完成文件的创建工作，处理后续工作
		m_pMemoryFileHead->m_bFileCMD = 0;
		SetTimestamp(lpSystemBlockHead, nTimestamp);
		SetObjectTimestamp(MF_SYS_OBJECTTYPE_FILE, nTimestamp);
		//修改内存数据
		memcpy(lpMemDBFileDef->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszFilePath, 256*sizeof(TCHAR));
	}
	catch (...)
	{
		Trace("CSystemManage::AlterMemDBFilePath", MF_TRACE_LEVEL_FAILED, 100013099, "修改文件路径时，出现未知异常，错误码：%d，原文件路径：%s，新文件路径：%s", GetLastError(), lpszOldFilePath, lpszNewFilePath);
		return MF_INNER_EXPCETION_FAILED;		
	}
	return MF_OK;
}

//错误码100014000
int CSystemManage::AlterMemDBFileSize(long long nTimestamp, BYTE bFileNo, LPCTSTR lpszFilePath, long long nFileSize)
{
	long long nOldFileSize;
	int i, nRet, nOffset;
	LPMEMDBFILEDEF lpMemDBFileDef;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPFILE_MEMDBFILEINFO lpFileMemDBFileInfo;
	CCriticalSectionPtr cs(&m_critFile);
	try
	{
		//因为文件需要通过名字来查找比较少且数据量也不会太多，所以直接遍历整个MAP来找数据
		lpMemDBFileDef = m_arMemDBFile[bFileNo];
		if(lpMemDBFileDef == NULL)
		{
			Trace("CSystemManage::AlterMemDBFileSize", MF_TRACE_LEVEL_FAILED, 100014001, "修改文件路径时，未找到原来的内存文件，文件路径：%s", lpszFilePath);
			return MF_SYS_DBFILE_NOTEXIST;
		}

		nRet = ConvertDataID2Offset(lpMemDBFileDef->m_nDataID, nOffset, lpSystemBlockHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpSystemBlockHead == NULL)
		{
			Trace("CSystemManage::AlterMemDBFileSize", MF_TRACE_LEVEL_FAILED, 100014002, "修改文件路径时，调ConvertDataID2Offset函数返回成功，但对应块指针为空，数据ID：%lld", lpMemDBFileDef->m_nDataID);
			return MF_INNER_POINTER_NULL;
		}

		lpFileMemDBFileInfo = (LPFILE_MEMDBFILEINFO)(((LPBYTE)lpSystemBlockHead) + nOffset);
		if(_tcsicmp(lpszFilePath, lpFileMemDBFileInfo->m_lpszFilePath) != 0)
		{
			//查找的数据有问题
			Trace("CSystemManage::AlterMemDBFileSize", MF_TRACE_LEVEL_FAILED, 100014003, "修改文件路径时，调ConvertDataID2Offset函数返回成功，但对应块数据不匹配，数据ID：%lld，希望值：%s，实际值：%s", lpMemDBFileDef->m_nDataID, lpszFilePath, lpFileMemDBFileInfo->m_lpszFilePath);
			return MF_INNER_INNERNO_DATAERROR;
		}

		nOldFileSize							= lpFileMemDBFileInfo->m_nFileSize;

		//关闭内存句柄
		nRet = CloseMemDBFile(lpMemDBFileDef);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		Sleep(10);
		lpFileMemDBFileInfo->m_nFileSize		= nFileSize;
		lpFileMemDBFileInfo->m_bFileCMD			= MF_SYS_FILECMD_CHANGEFILESIZE;//修改内存数据文件大小
		m_pMemoryFileHead->m_bFileCMD			= 1;//请求进程VernoxStorage.exe创建对应的文件
		for(i = 0; i < 10000; i++)
		{
			if(m_pMemoryFileHead->m_bFileCMD == 32)
			{
				break;
			}
			Sleep(20);
		}

		if(lpFileMemDBFileInfo->m_bFileCMD != 0)
		{
			//显示一下失败原因
			lpFileMemDBFileInfo->m_nFileSize	= nOldFileSize;
			if(lpFileMemDBFileInfo->m_bFileCMD == 251)
			{
				Trace("CSystemManage::AlterMemDBFileSize", MF_TRACE_LEVEL_FAILED, 100014005, "修改文件大小时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage没找到对应文件，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICE_NOTEXIST;
			}
			else if(lpFileMemDBFileInfo->m_bFileCMD == 249)
			{
				Trace("CSystemManage::AlterMemDBFileSize", MF_TRACE_LEVEL_FAILED, 100014006, "修改文件大小时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage改变文件大小失败，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICE_CHANGEFILE_FAILED;
			}
			else
			{
				Trace("CSystemManage::AlterMemDBFileSize", MF_TRACE_LEVEL_FAILED, 100014007, "修改文件大小时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage出现未知错误，错误编码：%d，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileCMD, lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICESTORAGE_NOTRESPONSE;
			}
		}

		//完成文件的创建工作，处理后续工作
		m_pMemoryFileHead->m_bFileCMD = 0;
		SetTimestamp(lpSystemBlockHead, nTimestamp);
		SetObjectTimestamp(MF_SYS_OBJECTTYPE_FILE, nTimestamp);

		//修改内存数据
		lpMemDBFileDef->m_nFileSize = lpFileMemDBFileInfo->m_nFileSize;
		nRet = OpenMemDBFile(lpMemDBFileDef);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AlterMemDBFileSize", MF_TRACE_LEVEL_FAILED, 100014099, "修改文件路径时，出现未知异常，错误码：%d，文件路径：%s", GetLastError(), lpszFilePath);
		return MF_INNER_EXPCETION_FAILED;		
	}
	return MF_OK;
}

//错误码100015000
int CSystemManage::DropMemDBFile(long long nTimestamp, LPCTSTR lpszFilePath)
{
	int i, nRet, nOffset;
	LPMEMDBFILEDEF lpMemDBFileDef;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPFILE_MEMDBFILEINFO lpFileMemDBFileInfo;
	CCriticalSectionPtr cs(&m_critFile);
	try
	{
		lpMemDBFileDef = NULL;
		nRet = GetMemDBFileInfo(lpszFilePath, lpMemDBFileDef);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		if(lpMemDBFileDef == NULL)
		{
			Trace("CSystemManage::DropMemDBFile", MF_TRACE_LEVEL_FAILED, 100015001, "删除内存数据文件时，未找到原来的内存文件，文件路径：%s", lpszFilePath);
			return MF_SYS_DBFILE_NOTEXIST;
		}

		nRet = ConvertDataID2Offset(lpMemDBFileDef->m_nDataID, nOffset, lpSystemBlockHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpSystemBlockHead == NULL)
		{
			Trace("CSystemManage::DropMemDBFile", MF_TRACE_LEVEL_FAILED, 100015002, "删除内存数据文件时，调ConvertDataID2Offset函数返回成功，但对应块指针为空，数据ID：%lld", lpMemDBFileDef->m_nDataID);
			return MF_INNER_POINTER_NULL;
		}

		lpFileMemDBFileInfo = (LPFILE_MEMDBFILEINFO)(((LPBYTE)lpSystemBlockHead) + nOffset);
		if(_tcsicmp(lpszFilePath, lpFileMemDBFileInfo->m_lpszFilePath) != 0)
		{
			//查找的数据有问题
			Trace("CSystemManage::DropMemDBFile", MF_TRACE_LEVEL_FAILED, 100015003, "删除内存数据文件时，调ConvertDataID2Offset函数返回成功，但对应块数据不匹配，数据ID：%lld，希望值：%s，实际值：%s", lpMemDBFileDef->m_nDataID, lpszFilePath, lpFileMemDBFileInfo->m_lpszFilePath);
			return MF_INNER_INNERNO_DATAERROR;
		}

		//关闭内存句柄
		nRet = CloseMemDBFile(lpMemDBFileDef);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		m_arMemDBFile[lpMemDBFileDef->m_bFileNo] = NULL;
		Sleep(10);
		lpFileMemDBFileInfo->m_bFileCMD			= MF_SYS_FILECMD_DROPFILE;//修改内存数据文件大小
		m_pMemoryFileHead->m_bFileCMD			= 1;//请求进程VernoxStorage.exe创建对应的文件
		for(i = 0; i < 10000; i++)
		{
			if(m_pMemoryFileHead->m_bFileCMD == 32)
			{
				break;
			}
			Sleep(20);
		}

		if(lpFileMemDBFileInfo->m_bFileCMD != 0)
		{
			//显示一下失败原因
			if(lpFileMemDBFileInfo->m_bFileCMD == 251)
			{
				Trace("CSystemManage::DropMemDBFile", MF_TRACE_LEVEL_FAILED, 100015005, "删除内存数据文件时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage没找到对应文件，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICE_NOTEXIST;
			}
			else
			{
				Trace("CSystemManage::DropMemDBFile", MF_TRACE_LEVEL_FAILED, 100015006, "删除内存数据文件时，调VernoxStorage.exe服务执行文件命令失败，失败原因：VernoxStorage出现未知错误，错误编码：%d，文件编号：%d，文件路径：%s，内存文件名：%s", lpFileMemDBFileInfo->m_bFileCMD, lpFileMemDBFileInfo->m_bFileNo, lpFileMemDBFileInfo->m_lpszFilePath, lpFileMemDBFileInfo->m_lpszMemFileName);
				return MF_SYS_DBFILE_SERVICESTORAGE_NOTRESPONSE;
			}
		}

		//完成文件的删除工作，处理后续工作
		lpFileMemDBFileInfo->m_bDropFlag	= 1;
		m_pMemoryFileHead->m_bFileCMD		= 0;
		SetTimestamp(lpSystemBlockHead, nTimestamp);
		SetObjectTimestamp(MF_SYS_OBJECTTYPE_FILE, nTimestamp);
		//delete lpFileMemDBFileInfo;
		delete lpMemDBFileDef;
	}
	catch (...)
	{
		Trace("CSystemManage::DropMemDBFile", MF_TRACE_LEVEL_FAILED, 100015099, "修改文件路径时，出现未知异常，错误码：%d，文件路径：%s", GetLastError(), lpszFilePath);
		return MF_INNER_EXPCETION_FAILED;		
	}
	return MF_OK;
}

int CSystemManage::ConvertDataID2Offset(long long nDataID, int &nOffset, LPSYSTEMBLOCKHEAD &lpSystemBlockHead)
{
	int nBlockNo, nInnerNo, nDirect, nTemp, nIndexTop, nIndexBottom, nMid;

	nOffset = 0;
	lpSystemBlockHead = NULL;
	if(GetFileNoFromDataID(nDataID) != 1)
	{
		//不是系统文件，直接返回失败
		Trace("CSystemManage::ConvertDataID2Offset", MF_TRACE_LEVEL_FAILED, 100016001, "转换数据ID时，发现文件编号不是系统文件的编号，数据ID：%lld", nDataID);
		return MF_INNER_FILENO_ERROR;
	}
	nBlockNo = GetBlockNoFromDataID(nDataID);

	lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)m_mapBlock.Get(nBlockNo);
	if(lpSystemBlockHead == NULL)
	{
		//没找到，要不是程序自身问题，要不就是数据有问题
		Trace("CSystemManage::ConvertDataID2Offset", MF_TRACE_LEVEL_FAILED, 100016002, "转换数据ID时，使用块编号找不到块地址指针，数据ID：%lld，块编号：%d", nDataID, nBlockNo);
		return MF_INNER_BLOCKNO_ERROR;
	}
	nInnerNo = GetInnerNoFromDataID(nDataID);

	//寄希望于直接使用内部编号直接定位，且所有定长数据的第一个值必须是内部编号
	nDirect = *(int *)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize + nInnerNo * lpSystemBlockHead->m_nBlockDataStructSize);
	if(nDirect == nInnerNo)
	{
		nOffset = lpSystemBlockHead->m_nBlockHeadSize + nInnerNo * lpSystemBlockHead->m_nBlockDataStructSize;
		return MF_OK;
	}
	else if(nDirect > nInnerNo)
	{
		//做好全范围内的二分法查找的准备，原则上此方式不可能发生
		nIndexTop = 0;
		nIndexBottom = nInnerNo;
		nMid = nInnerNo + nInnerNo - nDirect;
		if(nMid <= 0)
		{
			nMid = (nIndexTop + nIndexBottom)/2;
		}

		//预防开始的数据就是正确的，结果找半天
		nTemp = *(int *)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize + nIndexTop * lpSystemBlockHead->m_nBlockDataStructSize);
		if(nTemp == nInnerNo)
		{
			nOffset = lpSystemBlockHead->m_nBlockHeadSize + nIndexTop * lpSystemBlockHead->m_nBlockDataStructSize;
			return MF_OK;
		}
	}
	else
	{
		//做好全范围内的二分法查找的准备，原则上此方式不可能发生
		nIndexTop = nInnerNo;
		nIndexBottom = lpSystemBlockHead->m_nDataNum - 1;
		nMid = nInnerNo + nInnerNo - nDirect;

		//预防结束的数据就是正确的，结果找半天
		nTemp = *(int *)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize + nIndexBottom * lpSystemBlockHead->m_nBlockDataStructSize);
		if(nTemp == nInnerNo)
		{
			nOffset = lpSystemBlockHead->m_nBlockHeadSize + nIndexBottom * lpSystemBlockHead->m_nBlockDataStructSize;
			return MF_OK;
		}
	}

	//再快速做一次内部推荐的二分法定位，企图可以快速找到数据
	nTemp = *(int *)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize + nMid * lpSystemBlockHead->m_nBlockDataStructSize);
	if(nTemp == nInnerNo)
	{
		nOffset = lpSystemBlockHead->m_nBlockHeadSize + nMid * lpSystemBlockHead->m_nBlockDataStructSize;
		return MF_OK;
	}
	else if(nTemp < nInnerNo)
	{
		//在范围以内，直接二分法查找了
		nIndexTop = nMid;
	}
	else
	{
		nIndexBottom = nMid;
	}

	//执行二分法查找算法
	while(nIndexTop < nIndexBottom && nIndexBottom - nIndexTop > 1)
	{
		nMid = (nIndexTop + nIndexBottom)/2;
		nTemp = *(int *)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize + nMid * lpSystemBlockHead->m_nBlockDataStructSize);
		if(nTemp == nInnerNo)
		{
			nOffset = lpSystemBlockHead->m_nBlockHeadSize + nMid * lpSystemBlockHead->m_nBlockDataStructSize;
			return MF_OK;
		}
		else if(nTemp > nInnerNo)
		{
			nIndexBottom = nMid;
		}
		else
		{
			nIndexTop = nMid;
		}
	}

	Trace("CSystemManage::ConvertDataID2Offset", MF_TRACE_LEVEL_FAILED, 100016003, "转换数据ID时，找不到对应数据，数据ID：%lld", nDataID);
	return MF_INNER_INNERNO_NOTEXIST;
}

int CSystemManage::AddSequence(long long nTimestamp, LPCTSTR lpszName, long long nCurrentVal, int nIncrementBy, long long nMinVal, long long nMaxVal, BYTE bCycleFlag, BYTE bCacheFlag)
{
	int nRet;
	LPSEQUENCEDEF lpSequence;
	LPFILE_SEQUENCEDEF lpFileSequence;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	CCriticalSectionPtr cs(&m_critSequence);

	try
	{
		//首先进行数据排重
		if(m_mapSequence.Get(lpszName) != NULL)
		{
			//序列已经存在
			Trace("CSystemManage::AddSequence", MF_TRACE_LEVEL_FAILED, 100017001, "添加序列，找到对应序列已经存在，序列名：%s", lpszName);
			return MF_SYS_SEQUENCE_ADDNAMEEXIST;
		}
		//从系统文件中获取一个空闲块
		nRet = GetSystemFreeBlock(nTimestamp, MF_SYS_OBJECTTYPE_SEQUENCE, sizeof(FILE_SEQUENCEDEF), lpSystemBlockHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpSystemBlockHead == NULL)
		{
			Trace("CSystemManage::AddSequence", MF_TRACE_LEVEL_FAILED, 100017002, "添加序列，调GetSystemFreeBlock函数返回成功，但指针却为空，序列名：%s", lpszName);
			return MF_INNER_POINTER_NULL;
		}
		else
		{
			lpFileSequence = (LPFILE_SEQUENCEDEF)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nDataInsertOffset);
			lpFileSequence->m_nInnerNo	= lpSystemBlockHead->m_nInnerMaxNo;
			lpSystemBlockHead->m_nInnerMaxNo++;
			_tcscpy(lpFileSequence->m_lpszName, lpszName);
			lpFileSequence->m_nMinVal		= nMinVal;
			lpFileSequence->m_nCurrentVal	= nCurrentVal;
			lpFileSequence->m_nMaxVal		= nMaxVal;
			lpFileSequence->m_nIncrementBy	= nIncrementBy;
			lpFileSequence->m_bCycleFlag	= bCycleFlag;
			lpFileSequence->m_bCacheFlag	= bCacheFlag;
			lpFileSequence->m_bDropFlag		= 0;
			lpFileSequence->m_bReserved		= 0;
			lpSystemBlockHead->m_nDataNum++;
			lpSystemBlockHead->m_nDataInsertOffset	+= lpSystemBlockHead->m_nBlockDataStructSize;

			SetTimestamp(lpSystemBlockHead, nTimestamp);

			lpSequence = new SEQUENCEDEF;
			lpSequence->m_nDataID		= MakeDataID(lpSystemBlockHead->m_bFileNo, lpSystemBlockHead->m_nBlockNo, lpFileSequence->m_nInnerNo);
			memcpy(lpSequence->m_lpszName, lpFileSequence->m_lpszName, 32*sizeof(TCHAR));
			lpSequence->m_nCurrentVal	= nCurrentVal;
			lpSequence->m_nCacheEndVal	= nCurrentVal;
			lpSequence->m_nIncrementBy	= nIncrementBy;
			lpSequence->m_bMaxValError	= FALSE;
			m_mapSequence.Set((char*)lpszName, lpSequence);

			SetObjectTimestamp(MF_SYS_OBJECTTYPE_SEQUENCE, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AddSequence", MF_TRACE_LEVEL_FAILED, 100017003, "添加序列，出现未知异常，序列名：%s", lpszName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::DropSequence(long long nTimestamp, LPCTSTR lpszName)
{
	int nOffset, nRet;
	LPSEQUENCEDEF lpSequence;
	LPFILE_SEQUENCEDEF lpFileSequence;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	CCriticalSectionPtr cs(&m_critSequence);
	try
	{
		//首先进行数据排重
		lpSequence = (LPSEQUENCEDEF)m_mapSequence.Get(lpszName);
		if(lpSequence == NULL)
		{
			//序列不存在
			Trace("CSystemManage::AddSequence", MF_TRACE_LEVEL_FAILED, 100018001, "删除序列，没找到对应序列，序列名：%s", lpszName);
			return MF_SYS_SEQUENCE_NOTEXIST;
		}
		else
		{
			//需要修改内存和物理文件
			nRet = ConvertDataID2Offset(lpSequence->m_nDataID, nOffset, lpSystemBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpFileSequence = (LPFILE_SEQUENCEDEF)(((LPBYTE)lpSystemBlockHead) + nOffset);
			if(_tcsicmp(lpszName, lpFileSequence->m_lpszName) != 0)
			{
				//找出来的数据是错的，算法肯定出错了
				Trace("CSystemManage::AddSequence", MF_TRACE_LEVEL_FAILED, 100018002, "删除序列，通过ConvertDataID2Offset转换出来的数据不正确，序列名：%s，通过转换查找到的名字为：%s", lpszName, lpFileSequence->m_lpszName);
				return MF_INNER_INNERNO_DATAERROR;
			}
			//设置删除标志
			lpFileSequence->m_bDropFlag = 1;
			m_mapSequence.Remove(lpszName);
			delete lpSequence;

			//修改块数据时间戳
			SetTimestamp(lpSystemBlockHead, nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_SEQUENCE, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AddSequence", MF_TRACE_LEVEL_FAILED, 100018099, "删除序列，出现未知异常，错误码：%d，序列名：%s", GetLastError(), lpszName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::AddUser(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp)
{
	int nRet;
	BYTE pPassword[24];
	LPUSERINFODEF lpUserInfo;
	LPFILE_USERINFO lpFileUser;
	LPSYSTEMBLOCKHEAD lpObjectBlockHead;

	CCriticalSectionPtr cs(&m_critUser);
	try
	{
		memset(pPassword, 0, 24);
		//首先进行数据排重
		if(m_mapName2UserInfo.Get(lpUserInfoBson->m_pUserName) != NULL)
		{
			//用户已经存在
			Trace("CSystemManage::AddUser", MF_TRACE_LEVEL_FAILED, 100093001, "添加用户时，发现同名的用户已经存在，用户名：%s", lpUserInfoBson->m_pUserName);
			return MF_SYS_USER_ADDNAMEEXIST;
		}

		//获取一块空闲块
		nRet = GetSystemFreeBlock(nTimestamp, MF_SYS_OBJECTTYPE_USERINFO, sizeof(LPFILE_USERINFO), lpObjectBlockHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpObjectBlockHead == NULL)
		{
			Trace("CSystemManage::AddUser", MF_TRACE_LEVEL_FAILED, 100093002, "添加用户时，GetSystemFreeBlock找到对象数据块，但返回值为空，用户名：%s", lpUserInfoBson->m_pUserName);
			return MF_INNER_POINTER_NULL;
		}
		else if((int)sizeof(LPFILE_USERINFO) >= lpObjectBlockHead->m_nVarDataInsertOffset - lpObjectBlockHead->m_nDataInsertOffset)
		{
			//空间不足，按道理不应该，因为分配时就判断了的，这里再做一下二次判断以防漏网之鱼
			Trace("CSystemManage::AddUser", MF_TRACE_LEVEL_FAILED, 100093003, "添加用户时，发现返回的数据库剩余空间不够，用户名：%s", lpUserInfoBson->m_pUserName);
			return MF_FAILED;
		}
		else
		{
			//加密
			memset(pPassword, 0, sizeof(pPassword));
			if(lpUserInfoBson->m_pPassword[0] != 0)
			{
				Encryption(lpUserInfoBson->m_pPassword, pPassword);
			}
			lpFileUser								= (LPFILE_USERINFO)(((LPBYTE)lpObjectBlockHead) + lpObjectBlockHead->m_nDataInsertOffset);
			lpFileUser->m_nInnerNo					= lpObjectBlockHead->m_nInnerMaxNo;								
			lpFileUser->m_nUserID					= MakeDataID(m_pMemoryFileHead->m_bFileNo, lpObjectBlockHead->m_nBlockNo, lpFileUser->m_nInnerNo);
			lpFileUser->m_bStatus					= 1;
			memcpy(lpFileUser->m_pUserName, lpUserInfoBson->m_pUserName, 24);
			memcpy(lpFileUser->m_pPassword, pPassword, 24);
			memcpy(lpFileUser->m_bAuthorityID, lpUserInfoBson->m_bAuthorityID, 64);
			
			lpObjectBlockHead->m_nDataInsertOffset	+= lpObjectBlockHead->m_nBlockDataStructSize;
			lpObjectBlockHead->m_nDataNum++;
			lpObjectBlockHead->m_nInnerMaxNo++;

			//创建USERDEF
			lpUserInfo = new USERINFODEF;
			if(lpUserInfo == NULL)
			{
				Trace("CSystemManage::AddUser", MF_TRACE_LEVEL_FAILED, 100093004, "添加用户时，分配用户内存失败，用户名：%s", lpUserInfoBson->m_pUserName);
				return MF_INNER_ALLOCMEM_FAILED;
			}
			lpUserInfo->m_nUserID					= lpFileUser->m_nUserID;
			lpUserInfo->m_bStatus					= lpFileUser->m_bStatus;

			memcpy(lpUserInfo->m_pUserName, lpFileUser->m_pUserName, 24);
			memcpy(lpUserInfo->m_pPassword, pPassword, 24);
			memcpy(lpUserInfo->m_bAuthority, lpFileUser->m_bAuthorityID, 64);
			m_mapUserInfo.Set(lpUserInfo->m_nUserID, lpUserInfo);
			m_mapName2UserInfo.Set(lpUserInfo->m_pUserName, lpUserInfo);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_USERINFO, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AddUser", MF_TRACE_LEVEL_FAILED, 100093005, "添加用户时，出现未知异常，用户名：%s，错误码：%d", lpUserInfo->m_pUserName, GetLastError());
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::DropUser(char* pUserName, long long nTimestamp)
{
	int nRet, nOffset;
	LPUSERINFODEF lpUserInfo;
	LPFILE_USERINFO lpFileUser;
	LPSYSTEMBLOCKHEAD lpUserBlockHead;
	CCriticalSectionPtr cs(&m_critUser);
	try
	{
		lpUserInfo = (LPUSERINFODEF)m_mapName2UserInfo.Get(pUserName);
		if(lpUserInfo ==  NULL)
		{
			//用户不存在
			Trace("CSystemManage::DropUser", MF_TRACE_LEVEL_FAILED, 100094001, "删除用户时，发现用户不存在，用户名：%s", pUserName);
			return MF_SYS_USER_NOTEXIST;
		}
		else if(_tcsicmp(lpUserInfo->m_pUserName, pUserName) != 0)
		{
			//找出来的数据是错的，算法肯定出错了
			Trace("CSystemManage::DropUser", MF_TRACE_LEVEL_FAILED, 100094002, "删除用户时，发现找出来的用户的名称和实际的对不上，用户名：%s，找出来的为：%s", pUserName, lpUserInfo->m_pUserName);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else
		{
			//需要修改内存和物理文件,注意UserID实际就是User记录的DataID
			nRet = ConvertDataID2Offset(lpUserInfo->m_nUserID, nOffset, lpUserBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpFileUser = (LPFILE_USERINFO)(((LPBYTE)lpUserBlockHead) + nOffset);
			if(_tcsicmp(lpFileUser->m_pUserName, pUserName) != 0)
			{
				//找出来的数据是错的，算法肯定出错了
				//找出来的数据是错的，算法肯定出错了
				Trace("CSystemManage::DropUser", MF_TRACE_LEVEL_FAILED, 100094003, "删除用户时，用户数名称不匹配，用户名：%s，实际名称%s", pUserName, lpFileUser->m_pUserName);
				return MF_INNER_INNERNO_DATAERROR;
			}

			//设置删除标志_
			lpFileUser->m_bDropFlag = 1;

			//清理内存
			m_mapUserInfo.Remove(lpUserInfo->m_nUserID);
			m_mapName2UserInfo.Remove(lpUserInfo->m_pUserName);
			delete lpUserInfo;

			//修改块数据时间戳
			SetTimestamp(lpUserBlockHead, nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_USERINFO, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::DropUser", MF_TRACE_LEVEL_FAILED, 100094004, "删除用户时，出现未知异常，错误码：%d，用户名：%s", GetLastError(), pUserName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::AlterUserChangePassword(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp)
{
	int nRet, nOffset;
	BYTE bPasswordSrc[24];
	LPUSERINFODEF lpUserInfo;
	LPFILE_USERINFO lpFileUser;
	LPSYSTEMBLOCKHEAD lpObjectBlockHead;
	CCriticalSectionPtr cs(&m_critUser);
	try
	{
		lpUserInfo = (LPUSERINFODEF)m_mapName2UserInfo.Get(lpUserInfoBson->m_pUserName);
		if(lpUserInfo == NULL)
		{
			Trace("CSystemManage::AlterUserChangePassword", MF_TRACE_LEVEL_FAILED, 100075001, "修改用户密码时，找到的用户数据指针为空，用户名：%s", lpUserInfoBson->m_pUserName);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else
		{
			//需要修改内存和物理文件
			nRet = ConvertDataID2Offset(lpUserInfo->m_nUserID, nOffset, lpObjectBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpFileUser = (LPFILE_USERINFO)(((LPBYTE)lpObjectBlockHead) + nOffset);
			if(_tcsicmp(lpFileUser->m_pUserName, lpUserInfoBson->m_pUserName) != 0)
			{
				//找出来的数据是错的，算法肯定出错了
				Trace("CSystemManage::AlterUserChangePassword", MF_TRACE_LEVEL_FAILED, 100075002, "修改用户密码时，用户数名称不匹配，用户名：%s，实际名称%s", lpUserInfoBson->m_pUserName, lpFileUser->m_pUserName);
				return MF_INNER_INNERNO_DATAERROR;
			}
			memset(bPasswordSrc, 0, 24);
			if(lpUserInfoBson->m_pPassword[0] != 0)
			{
				Encryption(lpUserInfoBson->m_pPassword, bPasswordSrc);
			}
			memcpy(lpFileUser->m_pPassword, bPasswordSrc, 24);
			memcpy(lpUserInfo->m_pPassword, bPasswordSrc, 24);

			//修改块数据时间戳
			SetTimestamp(lpObjectBlockHead, nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_OBJECT, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AlterUserAddAuthority", MF_TRACE_LEVEL_FAILED, 100095003, "添加用户权限时，出现未知异常，错误码：%d，用户名：%", GetLastError(), lpUserInfoBson->m_pUserName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::AlterUserAddAuthority(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp)
{
	int i, nRet, nOffset;
	LPUSERINFODEF lpUserInfo;
	LPFILE_USERINFO lpFileUser;
	LPSYSTEMBLOCKHEAD lpObjectBlockHead;
	CCriticalSectionPtr cs(&m_critUser);
	try
	{
		lpUserInfo = (LPUSERINFODEF)m_mapName2UserInfo.Get(lpUserInfoBson->m_pUserName);
		if(lpUserInfo == NULL)
		{
			Trace("CSystemManage::AlterUserAddAuthority", MF_TRACE_LEVEL_FAILED, 100095001, "添加用户权限时，找到的用户数据指针为空，用户名：%s", lpUserInfoBson->m_pUserName);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else
		{
			//需要修改内存和物理文件
			nRet = ConvertDataID2Offset(lpUserInfo->m_nUserID, nOffset, lpObjectBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpFileUser = (LPFILE_USERINFO)(((LPBYTE)lpObjectBlockHead) + nOffset);
			if(_tcsicmp(lpFileUser->m_pUserName, lpUserInfoBson->m_pUserName) != 0)
			{
				//找出来的数据是错的，算法肯定出错了
				Trace("CSystemManage::AlterUserAddAuthority", MF_TRACE_LEVEL_FAILED, 100095002, "添加用户权限时，用户数名称不匹配，用户名：%s，实际名称%s", lpUserInfoBson->m_pUserName, lpFileUser->m_pUserName);
				return MF_INNER_INNERNO_DATAERROR;
			}
			for(i = 0; i < lpUserInfoBson->m_nAuthorityNum; i++)
			{
				lpFileUser->m_bAuthorityID[lpUserInfoBson->m_bAuthorityID[i]] = 1;
			}
			memcpy(lpUserInfo->m_bAuthority, lpFileUser->m_bAuthorityID, 64);

			//修改块数据时间戳
			SetTimestamp(lpObjectBlockHead, nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_OBJECT, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AlterUserAddAuthority", MF_TRACE_LEVEL_FAILED, 100095003, "添加用户权限时，出现未知异常，错误码：%d，用户名：%", GetLastError(), lpUserInfoBson->m_pUserName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}


int CSystemManage::AlterUserDropAuthority(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp)
{	
	int i, nRet, nOffset;
	LPUSERINFODEF lpUserInfo;
	LPFILE_USERINFO lpFileUser;
	LPSYSTEMBLOCKHEAD lpObjectBlockHead;
	CCriticalSectionPtr cs(&m_critUser);
	try
	{
		lpUserInfo = (LPUSERINFODEF)m_mapName2UserInfo.Get(lpUserInfoBson->m_pUserName);
		if(lpUserInfo == NULL)
		{
			Trace("CSystemManage::AlterUserDropAuthority", MF_TRACE_LEVEL_FAILED, 100096001, "删除用户权限时，找到的用户数据指针为空，用户名：%s", lpUserInfoBson->m_pUserName);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else
		{
			//需要修改内存和物理文件
			nRet = ConvertDataID2Offset(lpUserInfo->m_nUserID, nOffset, lpObjectBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpFileUser = (LPFILE_USERINFO)(((LPBYTE)lpObjectBlockHead) + nOffset);
			if(_tcsicmp(lpFileUser->m_pUserName, lpUserInfoBson->m_pUserName) != 0)
			{
				//找出来的数据是错的，算法肯定出错了
				Trace("CSystemManage::AlterUserDropAuthority", MF_TRACE_LEVEL_FAILED, 100096002, "删除用户权限时，用户数名称不匹配，用户名：%s，实际名称%s", lpUserInfoBson->m_pUserName, lpFileUser->m_pUserName);
				return MF_INNER_INNERNO_DATAERROR;
			}
			for(i = 0; i < lpUserInfoBson->m_nAuthorityNum; i++)
			{
				lpFileUser->m_bAuthorityID[lpUserInfoBson->m_bAuthorityID[i]] = 0;
			}
			memcpy(lpUserInfo->m_bAuthority, lpFileUser->m_bAuthorityID, 64);

			//修改块数据时间戳
			SetTimestamp(lpObjectBlockHead, nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_OBJECT, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AlterUserDropAuthority", MF_TRACE_LEVEL_FAILED, 100096003, "删除用户权限时，出现未知异常，错误码：%d，用户名：%", GetLastError(), lpUserInfoBson->m_pUserName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::AlterUserDisable(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp)
{
	int nRet, nOffset;
	LPUSERINFODEF lpUserInfo;
	LPFILE_USERINFO lpFileUser;
	LPSYSTEMBLOCKHEAD lpObjectBlockHead;
	CCriticalSectionPtr cs(&m_critUser);
	try
	{
		lpUserInfo = (LPUSERINFODEF)m_mapName2UserInfo.Get(lpUserInfoBson->m_pUserName);
		if(lpUserInfo == NULL)
		{
			Trace("CSystemManage::AlterUserDisable", MF_TRACE_LEVEL_FAILED, 100097001, "终止用户时，找到的用户数据指针为空，用户名：%s", lpUserInfoBson->m_pUserName);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else
		{
			//需要修改内存和物理文件
			nRet = ConvertDataID2Offset(lpUserInfo->m_nUserID, nOffset, lpObjectBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpFileUser = (LPFILE_USERINFO)(((LPBYTE)lpObjectBlockHead) + nOffset);
			if(_tcsicmp(lpFileUser->m_pUserName, lpUserInfoBson->m_pUserName) != 0)
			{
				//找出来的数据是错的，算法肯定出错了
				Trace("CSystemManage::AlterUserDisable", MF_TRACE_LEVEL_FAILED, 100097002, "终止用户时，用户数名称不匹配，用户名：%s，实际名称%s", lpUserInfoBson->m_pUserName, lpFileUser->m_pUserName);
				return MF_INNER_INNERNO_DATAERROR;
			}
			lpFileUser->m_bStatus = 0;
			lpUserInfo->m_bStatus = 0;

			//修改块数据时间戳
			SetTimestamp(lpObjectBlockHead, nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_OBJECT, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AlterUserDisable", MF_TRACE_LEVEL_FAILED, 100097003, "终止用户时，出现未知异常，错误码：%d，用户名：%", GetLastError(), lpUserInfoBson->m_pUserName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::AlterUserEnable(LPUSERINFOBSON lpUserInfoBson, long long nTimestamp)
{
	int nRet, nOffset;
	LPUSERINFODEF lpUserInfo;
	LPFILE_USERINFO lpFileUser;
	LPSYSTEMBLOCKHEAD lpObjectBlockHead;
	CCriticalSectionPtr cs(&m_critUser);
	try
	{
		lpUserInfo = (LPUSERINFODEF)m_mapName2UserInfo.Get(lpUserInfoBson->m_pUserName);
		if(lpUserInfo == NULL)
		{
			Trace("CSystemManage::AlterUserEnable", MF_TRACE_LEVEL_FAILED, 100098001, "启动用户时，找到的用户数据指针为空，用户名：%s", lpUserInfoBson->m_pUserName);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else
		{
			//需要修改内存和物理文件
			nRet = ConvertDataID2Offset(lpUserInfo->m_nUserID, nOffset, lpObjectBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpFileUser = (LPFILE_USERINFO)(((LPBYTE)lpObjectBlockHead) + nOffset);
			if(_tcsicmp(lpFileUser->m_pUserName, lpUserInfoBson->m_pUserName) != 0)
			{
				//找出来的数据是错的，算法肯定出错了
				Trace("CSystemManage::AlterUserEnable", MF_TRACE_LEVEL_FAILED, 100098002, "启动用户时，用户数名称不匹配，用户名：%s，实际名称%s", lpUserInfoBson->m_pUserName, lpFileUser->m_pUserName);
				return MF_INNER_INNERNO_DATAERROR;
			}
			lpFileUser->m_bStatus = 1;
			lpUserInfo->m_bStatus = 1;

			//修改块数据时间戳
			SetTimestamp(lpObjectBlockHead, nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_OBJECT, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AlterUserEnable", MF_TRACE_LEVEL_FAILED, 100098003, "启动用户时，出现未知异常，错误码：%d，用户名：%", GetLastError(), lpUserInfoBson->m_pUserName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::GetSequenceNextVal(LPCTSTR lpszName, long long &nVal)
{
	LPSEQUENCEDEF lpSequence;
	CCriticalSectionPtr cs(&m_critSequence);
	nVal = 0;
	//首先进行数据排重
	lpSequence = (LPSEQUENCEDEF)m_mapSequence.Get(lpszName);
	if(lpSequence == NULL)
	{
		//序列不存在
		Trace("CSystemManage::GetSequenceNextVal", MF_TRACE_LEVEL_FAILED, 100019001, "获取序列新值，没找到对应序列，序列名：%s", lpszName);
		return MF_SYS_SEQUENCE_NOTEXIST;
	}
	if(lpSequence->m_bMaxValError)
	{
		//已经达到最大值错误
		Trace("CSystemManage::GetSequenceNextVal", MF_TRACE_LEVEL_FAILED, 100019002, "获取序列新值，序列已达最大值，序列名：%s，序列值：%lld", lpszName, lpSequence->m_nCurrentVal);
		return MF_SYS_SEQUENCE_MAXVALUE;
	}
	else if(lpSequence->m_nCacheEndVal == lpSequence->m_nCurrentVal || lpSequence->m_nCacheEndVal - lpSequence->m_nCurrentVal < lpSequence->m_nIncrementBy)
	{
		int nOffset, nRet;
		LPFILE_SEQUENCEDEF lpFileSequence;
		LPSYSTEMBLOCKHEAD lpSystemBlockHead;
		//需要修改内存和物理文件
		nRet = ConvertDataID2Offset(lpSequence->m_nDataID, nOffset, lpSystemBlockHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpFileSequence = (LPFILE_SEQUENCEDEF)(((LPBYTE)lpSystemBlockHead) + nOffset);
		if(_tcsicmp(lpszName, lpFileSequence->m_lpszName) != 0)
		{
			//找出来的数据是错的，算法肯定出错了
			Trace("CSystemManage::GetSequenceNextVal", MF_TRACE_LEVEL_FAILED, 100019003, "获取序列新值，通过ConvertDataID2Offset查找出来的数据不正确，序列名：%s，查出来的名称：%s", lpszName, lpSequence->m_lpszName);
			return MF_INNER_INNERNO_DATAERROR;
		}

		if(lpFileSequence->m_bCacheFlag > lpSequence->m_nIncrementBy)
		{
			//正常情况均走此方式
			//先增加序列的当前值，然后再考虑缓存的事情
			lpSequence->m_nCurrentVal = lpSequence->m_nCurrentVal + lpSequence->m_nIncrementBy;
			lpFileSequence->m_nCurrentVal = lpSequence->m_nCurrentVal + lpFileSequence->m_bCacheFlag;
			lpSequence->m_nCacheEndVal = lpFileSequence->m_nCurrentVal;
			if(lpFileSequence->m_nCurrentVal > lpFileSequence->m_nMaxVal)
			{
				//循环序列
				if(lpFileSequence->m_bCycleFlag)
				{
					lpSequence->m_nCurrentVal = lpFileSequence->m_nMinVal;
					lpFileSequence->m_nCurrentVal = lpFileSequence->m_nMinVal + lpFileSequence->m_bCacheFlag;
					lpSequence->m_nCacheEndVal = lpFileSequence->m_nCurrentVal;
					lpSequence->m_bMaxValError = FALSE;
				}
				else
				{
					lpSequence->m_nCurrentVal = lpFileSequence->m_nMaxVal;
					lpFileSequence->m_nCurrentVal = lpFileSequence->m_nMaxVal;
					lpSequence->m_nCacheEndVal = lpFileSequence->m_nMaxVal;
					lpSequence->m_bMaxValError = TRUE;
				}
			}
			else
			{
				lpSequence->m_bMaxValError = FALSE;
			}
		}
		else
		{
			//相当于对序列有洁癖，必须连续等需求才可能走这种方式，保持文件记录的和发出去的序列号完全相同
			lpSequence->m_nCurrentVal = lpFileSequence->m_nCurrentVal + lpSequence->m_nIncrementBy;
			lpFileSequence->m_nCurrentVal = lpSequence->m_nCurrentVal;
			lpSequence->m_nCacheEndVal = lpSequence->m_nCurrentVal;
			if(lpFileSequence->m_nCurrentVal > lpFileSequence->m_nMaxVal)
			{
				//循环序列
				if(lpFileSequence->m_bCycleFlag)
				{
					lpSequence->m_nCurrentVal = lpFileSequence->m_nMinVal;
					lpFileSequence->m_nCurrentVal = lpFileSequence->m_nMinVal;
					lpSequence->m_nCacheEndVal = lpFileSequence->m_nMinVal;
					lpSequence->m_bMaxValError = FALSE;
				}
				else
				{
					lpSequence->m_nCurrentVal = lpFileSequence->m_nMaxVal;
					lpFileSequence->m_nCurrentVal = lpFileSequence->m_nMaxVal;
					lpSequence->m_nCacheEndVal = lpFileSequence->m_nMaxVal;
					lpSequence->m_bMaxValError = TRUE;
				}
			}
			else
			{
				lpSequence->m_bMaxValError = FALSE;
			}
		}

		long long nTimestamp;
		CSystemTimestampTransactionManage stTransaction;

		nTimestamp = GetSystemTimestamp();
		stTransaction.StartTransaction(nTimestamp);
		//修改块数据时间戳
		SetTimestamp(lpSystemBlockHead, nTimestamp);
		SetObjectTimestamp(MF_SYS_OBJECTTYPE_SEQUENCE, nTimestamp);
		if(lpSequence->m_bMaxValError)
		{
			//已经达到最大值错误
			stTransaction.CommitTransaction(nTimestamp);
			Trace("CSystemManage::GetSequenceNextVal", MF_TRACE_LEVEL_FAILED, 100019004, "获取序列新值，序列已达最大值，序列名：%s，序列值：%lld", lpszName, lpSequence->m_nCurrentVal);
			return MF_SYS_SEQUENCE_MAXVALUE;
		}
		else
		{
			nVal = lpSequence->m_nCurrentVal;
			stTransaction.CommitTransaction(nTimestamp);
			return MF_OK;
		}
	}
	else
	{
		lpSequence->m_nCurrentVal = lpSequence->m_nCurrentVal + lpSequence->m_nIncrementBy;
		nVal = lpSequence->m_nCurrentVal;
		return MF_OK;
	}

	Trace("CSystemManage::GetSequenceNextVal", MF_TRACE_LEVEL_FAILED, 100019099, "获取序列新值，出现未知异常，序列名：%s", lpszName);
	return MF_FAILED;
}

//判断序列是否存在
BOOL CSystemManage::CheckSequenctExit(LPCTSTR lpszName)
{
	LPSEQUENCEDEF lpSequence;
	lpSequence = (LPSEQUENCEDEF)m_mapSequence.Get(lpszName);
	if(lpSequence == NULL)
	{
		//序列不存在
		return FALSE;
	}
	return TRUE;
}
int CSystemManage::GetSequenceCurrentVal(LPCTSTR lpszName, long long &nVal)
{
	LPSEQUENCEDEF lpSequence;
	nVal = 0;
	//首先进行数据排重
	lpSequence = (LPSEQUENCEDEF)m_mapSequence.Get(lpszName);
	if(lpSequence == NULL)
	{
		//序列不存在
		Trace("CSystemManage::GetSequenceCurrentVal", MF_TRACE_LEVEL_FAILED, 100020001, "获取序列当前值，没找到对应序列，序列名：%s", lpszName);
		return MF_SYS_SEQUENCE_NOTEXIST;
	}
	
	if(lpSequence->m_bMaxValError)
	{
		//已经达到最大值错误
		Trace("CSystemManage::GetSequenceCurrentVal", MF_TRACE_LEVEL_FAILED, 100020002, "获取序列当前值，已达最大值，序列名：%s，当前值：%lld", lpszName, lpSequence->m_nCurrentVal);
		return MF_SYS_SEQUENCE_MAXVALUE;
	}
	else
	{
		nVal = lpSequence->m_nCurrentVal;
		return MF_OK;
	}

	Trace("CSystemManage::GetSequenceCurrentVal", MF_TRACE_LEVEL_FAILED, 100020099, "获取序列当前值，出现未知异常，序列名：%s", lpszName);
	return MF_FAILED;
}

int CSystemManage::AddObject(CServiceBson& stBson, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp, LPOBJECTDEFBSON lpObject, LPCTSTR lpszObjectDBFilePath, LPCTSTR lpszIndexDBFilePath, LPCTSTR lpszKVDBFilePath)
{
	int i;
	LPINDEXDEF lpNewIndex;
	LPOBJECTDEF lpObjectInfo;
	LPINDEXDEFBSON lpIndexField;
	LPFILE_OBJECTDEF lpFileObject;
	LPMEMDBFILEDEF lpMemDBFileDef;
	LPOBJECTFIELDDEFBSON lpFieldBson;
	IVirtualMemoryFile* pVirtualFile;
	int nRet, nVarLength, nActualVarLen;
	LPOBJECTDEFBSON lpObjectBson;
	BYTE bObjectFileNo, bIndexFileNo, bKVFileNo;
	LPSYSTEMBLOCKHEAD lpObjectBlockHead, lpIndexBlockHead;

	CCriticalSectionPtr cs(&m_critObject);
	try
	{
		//首先进行数据排重
		if(NULL != m_mapName2Object.Get(lpObject->m_bObjectName))
		{
			//对象已经存在
			Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021001, "添加对象时，发现同名的对象已经存在，对象名：%s", lpObject->m_bObjectName);
			return MF_SYS_OBJECT_ADDNAMEEXIST;
		}
		if(lpObject->m_nFieldNum < 1)
		{
			//没有列的对象不允许创建
			Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021002, "添加对象时，对象带的列数太少，对象名：%s，列数：%d", lpObject->m_bObjectName, lpObject->m_nFieldNum);
			return MF_SYS_OBJECT_NOFIELD;
		}
		else if(lpObject->m_nFieldNum > 255)
		{
			//对象的列过多，系统设计不支持
			Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021003, "添加对象时，对象带的列数太多，对象名：%s，列数：%d", lpObject->m_bObjectName, lpObject->m_nFieldNum);
			return MF_SYS_OBJECT_MANYFIELD;
		}
		if(lpObject->m_bImplementClass == MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM || lpObject->m_bImplementClass == 0)
		{
			return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
		}

		if(lpObject->m_nIndexOffset != 0)
		{
			lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpObject->m_nFieldOffset);
			for(i = 0; i < lpObject->m_nFieldNum; i++)
			{
				if(lpFieldBson->m_bFieldNo != i + 1)
				{
					//列序不正确，肯定导致索引中的列号也不对
					Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021004, "添加对象时，对象带的列序不正确，对象名：%s，不正确列序号：%d", lpObject->m_bObjectName, lpFieldBson->m_bFieldNo);
					return MF_SYS_OBJECT_FIELDNO_ERROR;
				}
				if(lpFieldBson->m_nNextOffset != 0)
				{
					lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpFieldBson->m_nNextOffset);
				}
			}
		}

		//根据文件路径获取各文件编号
		i			   = 0;
		bKVFileNo	   = 0;
		bIndexFileNo   = 0;
		bObjectFileNo  = 0;
		lpMemDBFileDef = NULL;
		for(i = 0; i < 256; i++)
		{
			lpMemDBFileDef = m_arMemDBFile[i];
			if(lpMemDBFileDef == NULL)
			{
				continue;
			}
			if(CmpMemDBFileName(lpszObjectDBFilePath, lpMemDBFileDef))
			{
				bObjectFileNo = i;
			} 
			else if(CmpMemDBFileName(lpszIndexDBFilePath, lpMemDBFileDef))
			{
				bIndexFileNo = i;
			}
			else if(CmpMemDBFileName(lpszKVDBFilePath, lpMemDBFileDef))
			{
				bKVFileNo = i;
			}	
		}

		//判断数据文件和索引文件是否存在
		if(bObjectFileNo == 0)
		{
			//对象数据文件不存在
			Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021005, "添加对象时，给定的数据文件没找到，对象名：%s，数据文件名：%s", lpObject->m_bObjectName, lpszObjectDBFilePath);
			return MF_SYS_OBJECT_DATAFILE_NOTEXIST;
		}

		i = 0;
		if(lpObject->m_nIndexOffset != 0)
		{
			lpIndexField = (LPINDEXDEFBSON)stBson.ConvertOffset2Addr(lpObject->m_nIndexOffset);
		}
		else
		{
			lpIndexField = NULL;
		}

		while(lpIndexField)
		{
			i++;
			if(lpIndexField->m_bIndexType < 10)
			{
				if(bKVFileNo == 0)
				{
					//对象KV索引文件不存在
					Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021006, "添加对象时，给定的KV索引文件没找到，对象名：%s，索引文件名：%s", lpObject->m_bObjectName, lpszKVDBFilePath);
					return MF_SYS_OBJECT_KVINDEXFILE_NOTEXIST;
				}
			}
			else if(lpIndexField->m_bIndexType <= 20)
			{
				if(bIndexFileNo == 0)
				{
					//对象B树索引文件不存在
					Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021007, "添加对象时，给定的B树索引文件没找到，对象名：%s，索引文件名：%s", lpObject->m_bObjectName, lpszIndexDBFilePath);
					return MF_SYS_OBJECT_BINDEXFILE_NOTEXIST;
				}
			}
			else
			{
				Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021008, "添加对象时，给定的索引类型不支持，对象名：%s，索引类型：%d", lpObject->m_bObjectName, lpIndexField->m_bIndexType);
				return MF_SYS_OBJECT_INDEXTYPE_NOTSUPPORT;
			}
			if(lpIndexField->m_nNextOffset != 0)
			{
				lpIndexField = (LPINDEXDEFBSON)stBson.ConvertOffset2Addr(lpIndexField->m_nNextOffset);
			}
			else
			{
				lpIndexField = NULL;
			}
		}

		//先看有没有索引定义，如果有就需要把相关的块找到
		if(lpObject->m_nIndexOffset != 0)
		{
			nRet = GetSystemFreeBlock(nTimestamp, MF_SYS_OBJECTTYPE_INDEX, sizeof(FILE_INDEXDEF)*i, lpIndexBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpIndexBlockHead == NULL)
			{
				Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021009, "添加对象时，GetSystemFreeBlock找到索引数据块，但返回值为空，对象名：%s", lpObject->m_bObjectName);
				return MF_INNER_POINTER_NULL;
			}
		}

		//计算变长数据分配长度，并处理成32的整数倍
		nActualVarLen = sizeof(FILE_OBJECTDEF) + (lpObject->m_nFieldNum - 1) * sizeof(FILE_OBJECTFIELDDEF);
		nVarLength = nActualVarLen + sizeof(SYSTEMBLOCKVARDATASTRUCT);

		//获取一块空闲块
		nRet = GetSystemFreeBlock(nTimestamp, MF_SYS_OBJECTTYPE_OBJECT, nVarLength + sizeof(SYSTEMBLOCKDATASTRUCT), lpObjectBlockHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpObjectBlockHead == NULL)
		{
			Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021010, "添加对象时，GetSystemFreeBlock找到对象数据块，但返回值为空，对象名：%s", lpObject->m_bObjectName);
			return MF_INNER_POINTER_NULL;
		}
		else if(nVarLength + (int)sizeof(SYSTEMBLOCKDATASTRUCT) >= lpObjectBlockHead->m_nVarDataInsertOffset - lpObjectBlockHead->m_nDataInsertOffset)
		{
			//空间不足，按道理不应该，因为分配时就判断了的，这里再做一下二次判断以防漏网之鱼
			Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021011, "添加对象时，发现返回的数据库剩余空间不够，对象名：%s", lpObject->m_bObjectName);
			return MF_FAILED;
		}
		else
		{
			int nObjectID, n;
			long long nDataID;
			LPOBJECTDEF lpObjectTemp;
			LPFILE_INDEXDEF lpFileIndex;
			LPFILE_OBJECTFIELDDEF lpFileField;
			LPSYSTEMBLOCKDATASTRUCT lpSysBlockItemData;					//定长数据
			LPSYSTEMBLOCKVARDATASTRUCT lpSysBlockItemVarData;			//变长数据(用于存放FILE_OBJECTDEF)
		

			//先申请ObjectID
			nObjectID	= m_pMemoryFileHead->m_nObjectMaxID;
			m_pMemoryFileHead->m_nObjectMaxID++;
			
			//先保存OBJECT数据信息
			lpSysBlockItemData	= (LPSYSTEMBLOCKDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + lpObjectBlockHead->m_nDataInsertOffset);
			lpSysBlockItemData->m_nInnerNo	= lpObjectBlockHead->m_nInnerMaxNo;
			lpObjectBlockHead->m_nInnerMaxNo++;
			lpSysBlockItemData->m_bLockStatus		= 0;
			lpSysBlockItemData->m_bReserved[0]		= 0;
			lpSysBlockItemData->m_bReserved[1]		= 0;
			lpSysBlockItemData->m_bReserved[2]		= 0;
			lpSysBlockItemData->m_nRollbackDataID	= 0;
			lpSysBlockItemData->m_nVarDataLength	= nActualVarLen;
			lpSysBlockItemData->m_nVarDataOffset	= lpObjectBlockHead->m_nVarDataInsertOffset - nVarLength;				//从后向前分配
			
			//分配变长数据空间
			lpSysBlockItemVarData = (LPSYSTEMBLOCKVARDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + lpSysBlockItemData->m_nVarDataOffset);
			lpSysBlockItemVarData->m_nDataFlag		= MAKEHEADFLAG('S','B','B','V');
			lpSysBlockItemVarData->m_nInnerNo		= lpSysBlockItemData->m_nInnerNo;
			lpSysBlockItemVarData->m_nDataLength	= nVarLength;
			lpSysBlockItemVarData->m_nActualLength	= lpSysBlockItemData->m_nVarDataLength;
			lpSysBlockItemVarData->m_nNextOffset	= 0;
			
			lpFileObject							= (LPFILE_OBJECTDEF)(&lpSysBlockItemVarData->m_pDataContent);
			lpFileObject->m_nObjectID				= nObjectID;
			lpFileObject->m_bFileNo					= bObjectFileNo;
			lpFileObject->m_bObjectType				= lpObject->m_bObjectType;
			lpFileObject->m_nBlockSize				= lpObject->m_nBlockSize;
			lpFileObject->m_nFieldNum1				= lpObject->m_nFieldNum;
			lpFileObject->m_bImplementClass			= lpObject->m_bImplementClass;
			memcpy(lpFileObject->m_lpszName, lpObject->m_bObjectName, 32*sizeof(TCHAR));

			//存放列信息
			lpFileField								= &(lpFileObject->m_stFirstField);
			lpFieldBson =  (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpObject->m_nFieldOffset);
			n = 0;
			for(i = 0; i < lpFileObject->m_nFieldNum1; n++, i++)
			{
				lpFileField[n].m_bObjectFieldNo = i + 1;
				lpFileField[n].m_bFieldType		= lpFieldBson->m_bFieldType;
				lpFileField[n].m_bCharLen		= lpFieldBson->m_bCharLen;
				lpFileField[n].m_bAllowNull		= lpFieldBson->m_bAllowNull;
				memcpy(lpFileField[n].m_lpszName, lpFieldBson->m_bFieldName, 32*sizeof(TCHAR));
				if(lpFieldBson->m_nNextOffset != 0)
				{
					lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpFieldBson->m_nNextOffset);
				}
			}

			lpObjectBson = lpObject;
			while(TRUE)
			{
				//然后再处理索引的事情
				if(lpObjectBson->m_nIndexOffset != 0)
				{
					lpIndexField = (LPINDEXDEFBSON)stBson.ConvertOffset2Addr(lpObjectBson->m_nIndexOffset);
				}
				else
				{
					lpIndexField = NULL;
				}
				while(lpIndexField)
				{
					lpFileIndex = (LPFILE_INDEXDEF)(((LPBYTE)lpIndexBlockHead) + lpIndexBlockHead->m_nDataInsertOffset);
					lpFileIndex->m_nInnerNo	= lpIndexBlockHead->m_nInnerMaxNo;
					lpIndexBlockHead->m_nInnerMaxNo++;
					
					_tcscpy(lpFileIndex->m_lpszName, lpIndexField->m_pIndexName);
					lpFileIndex->m_nIndexID		= m_pMemoryFileHead->m_nObjectMaxID;
					m_pMemoryFileHead->m_nObjectMaxID++;
					lpFileIndex->m_nObjectID	= nObjectID;
					memcpy(lpFileIndex->m_lpszName, lpIndexField->m_pIndexName, 32*sizeof(TCHAR));
					lpFileIndex->m_bObjectType  = lpObjectBson->m_bObjectType;
					lpFileIndex->m_nBlockSize	= lpIndexField->m_nBlockSize;
					lpFileIndex->m_bIndexType	= lpIndexField->m_bIndexType;
					if(lpFileIndex->m_bIndexType < 10)
					{
						lpFileIndex->m_bFileNo	= bKVFileNo;
					}
					else if(lpFileIndex->m_bIndexType <= 20)
					{
						lpFileIndex->m_bFileNo	= bIndexFileNo;
					}
					else
					{
						Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021012, "添加对象时，给定的索引类型不支持，对象名：%s，索引类型：%d", lpObjectBson->m_bObjectName, lpFileIndex->m_bIndexType);
						return MF_SYS_OBJECT_INDEXTYPE_NOTSUPPORT;
					}
					lpFileIndex->m_bFieldNo[0]	= lpIndexField->m_bFieldNo[0];
					lpFileIndex->m_bFieldNo[1]	= lpIndexField->m_bFieldNo[1];
					lpFileIndex->m_bFieldNo[2]	= lpIndexField->m_bFieldNo[2];
					lpFileIndex->m_bFieldNo[3]	= lpIndexField->m_bFieldNo[3];
					lpFileIndex->m_bConstraintType 	= lpIndexField->m_bConstraintType;

					//分配索引空间
					nRet = AllocFileData(lpFileIndex->m_bFileNo, lpFileIndex->m_nIndexID, lpFileIndex->m_nBlockSize, lpFileIndex->m_bIndexType, lpFileIndex->m_nDataNum);
					if(nRet != MF_OK)
					{
						return nRet;
					}

					lpIndexField->m_bFileNo					= lpFileIndex->m_bFileNo;
					lpIndexField->m_nIndexID				= lpFileIndex->m_nIndexID;
					lpIndexField->m_nDataID					= MakeDataID(lpIndexBlockHead->m_bFileNo, lpIndexBlockHead->m_nBlockNo, lpFileIndex->m_nInnerNo);
					lpIndexBlockHead->m_nDataInsertOffset	+= lpIndexBlockHead->m_nBlockDataStructSize;
					lpIndexBlockHead->m_nDataNum++;
					if(lpIndexField->m_nNextOffset != 0)
					{
						lpIndexField = (LPINDEXDEFBSON)(stBson.ConvertOffset2Addr(lpIndexField->m_nNextOffset));
					}
					else
					{
						lpIndexField = NULL;
					}
					SetTimestamp(lpIndexBlockHead, nTimestamp);
					SetObjectTimestamp(MF_SYS_OBJECTTYPE_INDEX, nTimestamp);

					nRet = GetMemoryFileInstance(lpFileIndex->m_bFileNo, pVirtualFile);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					if(lpFileIndex->m_bIndexType < 10)
					{
						int nRootNo, nHashIndexNodeSize;
						nHashIndexNodeSize = ((CMemoryHashFile*)pVirtualFile)->GetHashIndexNodeSize(lpFileField[lpFileIndex->m_bFieldNo[0] - 1].m_bFieldType, lpFileField[lpFileIndex->m_bFieldNo[0] - 1].m_bCharLen + 1);
						nRet = ((CMemoryHashFile*)pVirtualFile)->CreateRoot(lpExecutePlan, lpFileIndex->m_nIndexID, nHashIndexNodeSize, nRootNo, nTimestamp);
						if(nRet != MF_OK)
						{
							return nRet;
						}
					}
					else if(lpFileIndex->m_bIndexType <= 20)
					{
						int nRootNo, n;
						UINT nFieldOffset;
						BYTE bFieldType[5], bFieldNum;
						
						//获取索引字段数量和类型
						bFieldNum = 0;
						for(n = 0; n < 4; n++)
						{
							if(lpFileIndex->m_bFieldNo[n] == 0)
							{
								break;
							}
							bFieldNum++;
							
							nFieldOffset = lpObjectBson->m_nFieldOffset;
							while(nFieldOffset)
							{
								lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(nFieldOffset);
								if(lpFieldBson->m_bFieldNo == lpFileIndex->m_bFieldNo[n])
								{
									bFieldType[n] = lpFieldBson->m_bFieldType;
									break;
								}
								nFieldOffset = lpFieldBson->m_nNextOffset;
							}
						}
						//最后一个字段一定是DataID
						bFieldType[bFieldNum] = MF_SYS_FIELDTYPE_BIGINT;
						bFieldNum++;
						nRet = ((CMemoryBTreeFile*)pVirtualFile)->CreateRoot(lpExecutePlan, lpFileIndex->m_nIndexID, bFieldNum, bFieldType, nRootNo, nTimestamp);
						if(nRet != MF_OK)
						{
							return nRet;
						}
					}
				}

				break;
			}
			
			//在数据文件中为对象分配空间
			nDataID										= MakeDataID(lpObjectBlockHead->m_bFileNo, lpObjectBlockHead->m_nBlockNo, lpSysBlockItemData->m_nInnerNo);
			lpObjectBlockHead->m_nVarDataInsertOffset	= lpSysBlockItemData->m_nVarDataOffset;
			lpObjectBlockHead->m_nDataInsertOffset		+= lpObjectBlockHead->m_nBlockDataStructSize;
			lpObjectBlockHead->m_nDataNum++;
			SetTimestamp(lpObjectBlockHead, nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_OBJECT, nTimestamp);

			nRet = GetMemoryFileInstance(bObjectFileNo, pVirtualFile);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			nRet = ((CMemoryFile*)pVirtualFile)->CreateObject(lpExecutePlan, nObjectID, lpObject->m_bObjectType, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			
			//创建OBJECTDEF
			lpObjectInfo = new OBJECTDEF;
			if(lpObjectInfo == NULL)
			{
				Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021013, "添加对象时，分配对象内存失败，对象名：%s", lpObject->m_bObjectName);
				return MF_INNER_ALLOCMEM_FAILED;
			}
			lpObjectTemp = lpObjectInfo;

			lpObjectBson = lpObject;
			while(TRUE)
			{
				lpObjectTemp->m_nDataID						= nDataID;
				lpObjectTemp->m_nObjectID					= nObjectID;
				lpObjectTemp->m_bFileNo						= bObjectFileNo;
				lpObjectTemp->m_nBlockSize					= lpObjectBson->m_nBlockSize;
				lpObjectTemp->m_nFieldNum					= lpObjectBson->m_nFieldNum;
				lpObjectTemp->m_bImplementClass				= lpObjectBson->m_bImplementClass;
				lpObjectTemp->m_bObjectType					= lpObjectBson->m_bObjectType;
				lpObjectTemp->m_pDataNum				    = ((CMemoryFile*)pVirtualFile)->GetObjectDataPtr(lpObjectTemp->m_nObjectID, lpObjectTemp->m_bObjectType);
				memcpy(lpObjectTemp->m_lpszName, lpObjectBson->m_bObjectName, 32*sizeof(TCHAR));
				
				lpObjectTemp->m_lpField = new OBJECTFIELDDEF[lpObjectBson->m_nFieldNum];
				lpObjectTemp->InitalMap();
				if(lpObjectTemp->m_lpField == NULL)
				{
					Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021013, "添加对象时，分配对象列内存失败，对象名：%s", lpObjectBson->m_bObjectName);
					return MF_INNER_ALLOCMEM_FAILED;
				}

				lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpObjectBson->m_nFieldOffset);
				for(i = 0; i < lpObjectTemp->m_nFieldNum; i++)
				{
					memcpy(lpObjectTemp->m_lpField[i].m_lpszName, lpFieldBson->m_bFieldName, 32);
					lpObjectTemp->m_lpField[i].m_bObjectFieldNo	= lpFieldBson->m_bFieldNo;
					lpObjectTemp->m_lpField[i].m_bAllowNull		= lpFieldBson->m_bAllowNull;
					lpObjectTemp->m_lpField[i].m_bFieldType		= lpFieldBson->m_bFieldType;
					lpObjectTemp->m_lpField[i].m_bCharLen		= lpFieldBson->m_bCharLen;
					lpObjectTemp->m_mapName2FieldNo.Set(lpObjectTemp->m_lpField[i].m_lpszName, (LPVOID)lpObjectTemp->m_lpField[i].m_bObjectFieldNo);

					if(lpFieldBson->m_nNextOffset != 0)
					{
						lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpFieldBson->m_nNextOffset);
					}
				}

				lpObjectTemp->m_bMaxTransactionNum = CSystemManage::instance().GetParameterValue(MF_OBJECT_TRANSACTION_MAXNUM);
				lpObjectTemp->m_lpTimestampArray   = new long long[lpObjectTemp->m_bMaxTransactionNum];
				memset(lpObjectTemp->m_lpTimestampArray, 0, lpObjectTemp->m_bMaxTransactionNum*sizeof(long long));
				
				//处理索引部分
				if(lpObjectBson->m_nIndexOffset != 0)
				{
					lpIndexField = (LPINDEXDEFBSON)stBson.ConvertOffset2Addr(lpObjectBson->m_nIndexOffset);
				}
				else
				{
					lpIndexField = NULL;
				}
				while(lpIndexField)
				{					
					lpNewIndex = new INDEXDEF;
					if(lpNewIndex == NULL)
					{
						Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021014, "添加对象时，分配索引内存失败，对象名：%s", lpObjectBson->m_bObjectName);
						return MF_INNER_ALLOCMEM_FAILED;
					}
					memset(lpNewIndex, 0, sizeof(INDEXDEF));
					lpNewIndex->m_bFieldNo[0]	= lpIndexField->m_bFieldNo[0];
					lpNewIndex->m_bFieldNo[1]	= lpIndexField->m_bFieldNo[1];
					lpNewIndex->m_bFieldNo[2]	= lpIndexField->m_bFieldNo[2];
					lpNewIndex->m_bFieldNo[3]	= lpIndexField->m_bFieldNo[3];
					
					lpNewIndex->m_nObjectID		= nObjectID;
					lpNewIndex->m_bFileNo		= lpIndexField->m_bFileNo;
					lpNewIndex->m_bIndexType	= lpIndexField->m_bIndexType;
					lpNewIndex->m_nBlockSize    = lpIndexField->m_nBlockSize;
					lpNewIndex->m_nDataID		= lpIndexField->m_nDataID;
					lpNewIndex->m_nIndexID		= lpIndexField->m_nIndexID;
					lpNewIndex->m_bConstraintType = lpIndexField->m_bConstraintType;
					lpNewIndex->m_bStatus	    = 0;
					lpNewIndex->m_nTimestamp	= 0;
					memcpy(lpNewIndex->m_lpszName, lpIndexField->m_pIndexName, 32);
					lpNewIndex->m_pNext			= NULL;
					if(lpObjectTemp->m_lpIndex == NULL)
					{
						lpObjectTemp->m_lpIndex = lpNewIndex;
					}
					else
					{
						lpNewIndex->m_pNext = lpObjectTemp->m_lpIndex;			
						lpObjectTemp->m_lpIndex = lpNewIndex;
					}

					m_mapIndex.Set(lpNewIndex->m_nIndexID, lpNewIndex);
					if(lpIndexField->m_nNextOffset != 0)
					{
						lpIndexField = (LPINDEXDEFBSON)stBson.ConvertOffset2Addr(lpIndexField->m_nNextOffset);
					}
					else
					{
						lpIndexField = NULL;
					}
				}
				SortObjectIndex(lpObjectTemp);					//索引优先级排序
				break;
			}

			m_mapObject.Set(lpObjectInfo->m_nObjectID, lpObjectInfo);
			m_mapName2Object.Set(lpObjectInfo->m_lpszName, lpObjectInfo);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_OBJECT, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AddObject", MF_TRACE_LEVEL_FAILED, 100021013, "添加对象时，出现未知异常，对象名：%s，错误码：%d", lpObject->m_bObjectName, GetLastError());
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::DropObject(LPEXECUTEPLANBSON lpExecutePlan, LPCTSTR lpszObjectName)
{
	int nRet, nOffset;
	LPINDEXDEF lpIndex;
	LPOBJECTDEF lpObject;
	LPFILE_INDEXDEF lpFileIndex;
	LPSYSTEMBLOCKDATASTRUCT lpSysBlockItemData;
	LPSYSTEMBLOCKHEAD lpObjectBlockHead, lpIndexBlockHead;
	CCriticalSectionPtr cs(&m_critObject);
	try
	{
		lpObject = (LPOBJECTDEF)m_mapName2Object.Get((char*)lpszObjectName);
		if(lpObject == NULL)
		{
			Trace("CSystemManage::DropObject", MF_TRACE_LEVEL_FAILED, 100022002, "删除对象时，发现找出来的数据为空，对象名：%s", lpszObjectName);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else if(_tcsicmp(lpObject->m_lpszName, lpszObjectName) != 0)
		{
			//找出来的数据是错的，算法肯定出错了
			Trace("CSystemManage::DropObject", MF_TRACE_LEVEL_FAILED, 100022003, "删除对象时，发现找出来的数据的名称和实际的对不上，对象名：%s，找出来的为：%s", lpszObjectName, lpObject->m_lpszName);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else
		{
			for(lpIndex = lpObject->m_lpIndex; lpIndex != NULL; )
			{
				//需要修改内存和物理文件
				nRet = ConvertDataID2Offset(lpIndex->m_nDataID, nOffset, lpIndexBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpFileIndex = (LPFILE_INDEXDEF)(((LPBYTE)lpIndexBlockHead) + nOffset);
				if(_tcsicmp(lpIndex->m_lpszName, lpFileIndex->m_lpszName) != 0)
				{
					//找出来的数据是错的，算法肯定出错了
					Trace("CSystemManage::DropObject", MF_TRACE_LEVEL_FAILED, 100022004, "删除对象时，发现通过ConvertDataID2Offset找出来的索引的名称和实际的对不上，索引名：%s，找出来的为：%s", lpIndex->m_lpszName, lpFileIndex->m_lpszName);
					return MF_INNER_INNERNO_DATAERROR;
				}
				
				//释放索引对象空间
				nRet = RecycleFileData(lpExecutePlan, lpFileIndex->m_bFileNo, lpFileIndex->m_nIndexID);
				if(nRet != MF_OK)
				{
					return nRet;
				}

				//设置删除标志
				lpFileIndex->m_bDropFlag = 1;
				m_mapIndex.Remove(lpFileIndex->m_nIndexID);
				lpIndex = lpIndex->m_pNext;
				delete lpObject->m_lpIndex;
				lpObject->m_lpIndex = lpIndex;

				//修改块数据时间戳
				SetTimestamp(lpIndexBlockHead, lpExecutePlan->m_nTimestamp);
				SetObjectTimestamp(MF_SYS_OBJECTTYPE_INDEX, lpExecutePlan->m_nTimestamp);
			}

			//需要修改内存和物理文件
			nRet = ConvertDataID2Offset(lpObject->m_nDataID, nOffset, lpObjectBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpSysBlockItemData = (LPSYSTEMBLOCKDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + nOffset);
			if(lpSysBlockItemData->m_nInnerNo != GetInnerNoFromDataID(lpObject->m_nDataID))
			{
				//找出来的数据是错的，算法肯定出错了
				Trace("CSystemManage::DropObject", MF_TRACE_LEVEL_FAILED, 100022005, "删除对象时，发现通过GetInnerNoFromDataID找出来的数据内部编号不对应，对象名：%s", lpszObjectName);
				return MF_INNER_INNERNO_DATAERROR;
			}

			//释放数据对象空间
			nRet = RecycleFileData(lpExecutePlan, lpObject->m_bFileNo, lpObject->m_nObjectID);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			//设置删除标志_
			lpSysBlockItemData->m_nVarDataOffset = 0;

			//清理内存
			m_mapObject.Remove(lpObject->m_nObjectID);
			m_mapName2Object.Remove(lpObject->m_lpszName);
			delete [] lpObject->m_lpField;
			delete lpObject;

			//修改块数据时间戳
			SetTimestamp(lpObjectBlockHead, lpExecutePlan->m_nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_OBJECT, lpExecutePlan->m_nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::DropObject", MF_TRACE_LEVEL_FAILED, 100022005, "删除对象时，出现未知异常，错误码：%d，对象名：%s", GetLastError(), lpszObjectName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::AlterObjectAddField(CServiceBson& stBson, long long nTimestamp, LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson)
{
	BYTE i,bFieldNo;
	string strFiledName;
	LPOBJECTFIELDDEF lpField;
	LPFILE_OBJECTDEF lpFileObject;
	LPOBJECTFIELDDEFBSON lpFieldBson;
	LPFILE_OBJECTFIELDDEF lpFileField;
	LPOBJECTDEF lpObject, lpObjectTemp;
	LPSYSTEMBLOCKHEAD lpObjectBlockHead;
	int nRet, nOffset, nSize, nFieldNum;
	LPSYSTEMBLOCKDATASTRUCT lpSysBlockItemData;
	LPALTEROBJECTFIELDBSON lpAlterObjectFieldTemp;
	LPSYSTEMBLOCKVARDATASTRUCT lpSysBlockItemVarData, lpVarNewData;
	CCriticalSectionPtr cs(&m_critObject);
	try
	{
		lpObject = (LPOBJECTDEF)m_mapObject.Get(lpAlterObjectFieldBson->m_nObjectID);
		if(lpObject == NULL)
		{
			Trace("CSystemManage::AlterObjectAddField", MF_TRACE_LEVEL_FAILED, 100023001, "添加对象列时，没找到对象数据，对象：%s(%d)", lpAlterObjectFieldBson->m_pObjectName, lpAlterObjectFieldBson->m_nObjectID);
			return MF_SYS_OBJECT_NOTEXIST;
		}

		if(lpObject == NULL)
		{
			Trace("CSystemManage::AlterObjectAddField", MF_TRACE_LEVEL_FAILED, 100023002, "添加对象列时，找到的对象数据指针为空，对象ID：%s(%d)", lpAlterObjectFieldBson->m_pObjectName, lpAlterObjectFieldBson->m_nObjectID);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else if(lpObject->m_nObjectID != lpAlterObjectFieldBson->m_nObjectID)
		{
			//找出来的数据是错的，算法肯定出错了
			Trace("CSystemManage::AlterObjectAddField", MF_TRACE_LEVEL_FAILED, 100023003, "添加对象列时，找到的对象数据名和相符，对象名：%d，找出来的ID为：%d", lpAlterObjectFieldBson->m_nObjectID, lpObject->m_nObjectID);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else if(lpObject->m_bObjectType == MF_OBJECT_COMMON && lpAlterObjectFieldBson->m_bObjectType != MF_OBJECT_COMMON)
		{
			return MF_COMMON_INVALID_OBJECTTYPE;
		}
		else
		{
			//需要修改内存和物理文件
			nRet = ConvertDataID2Offset(lpObject->m_nDataID, nOffset, lpObjectBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpSysBlockItemData = (LPSYSTEMBLOCKDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + nOffset);
			if(lpSysBlockItemData->m_nInnerNo != GetInnerNoFromDataID(lpObject->m_nDataID))
			{
				//找出来的数据是错的，算法肯定出错了
				Trace("CSystemManage::AlterObjectAddField", MF_TRACE_LEVEL_FAILED, 100023005, "添加对象列时，通过ConvertDataID2Offset找到的对象数据编号不相符，对象名：%s", lpAlterObjectFieldBson->m_pObjectName);
				return MF_INNER_INNERNO_DATAERROR;
			}

			lpSysBlockItemVarData = (LPSYSTEMBLOCKVARDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + lpSysBlockItemData->m_nVarDataOffset);
			//首先检查字段重名
			lpFileObject		   = (LPFILE_OBJECTDEF)(&lpSysBlockItemVarData->m_pDataContent);
			lpFileField			   = &(lpFileObject->m_stFirstField);			
			lpAlterObjectFieldTemp = lpAlterObjectFieldBson;
			while(TRUE)
			{
				lpFieldBson			   = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpAlterObjectFieldTemp->m_nFieldOffset);
				lpObjectTemp = lpObject;
				for(i = 0;i < lpAlterObjectFieldTemp->m_nFieldNum; i++)
				{
					bFieldNo	 = 0;
					strFiledName = lpFieldBson->m_bFieldName;
					if(NULL != lpObjectTemp->m_mapName2FieldNo.Get(strFiledName.c_str()))
					{
						//字段名重复
						Trace("CSystemManage::AlterObjectAddField", MF_TRACE_LEVEL_FAILED, 100023006, "添加对象列时，字段名出现重复，添加失败，对象名：%s，字段名：%s", lpAlterObjectFieldBson->m_pObjectName, lpFieldBson->m_bFieldName);
						return MF_SYS_OBJECT_ADDFIELDNAME_EXIST;
					}
					if(lpFieldBson->m_nNextOffset != 0)
					{
						lpFieldBson = (LPOBJECTFIELDDEFBSON)(stBson.ConvertOffset2Addr(lpFieldBson->m_nNextOffset));
					}
				}
				if(lpAlterObjectFieldTemp->m_nNextOffset != 0)
				{
					lpAlterObjectFieldTemp = (LPALTEROBJECTFIELDBSON)stBson.ConvertOffset2Addr(lpAlterObjectFieldTemp->m_nNextOffset);
				}
				else
				{
					break;
				}
			}
			
			//首先检查空间是否够
			if(lpAlterObjectFieldBson->m_nNextOffset != 0)
			{
				lpAlterObjectFieldTemp = (LPALTEROBJECTFIELDBSON)stBson.ConvertOffset2Addr(lpAlterObjectFieldBson->m_nNextOffset);
				nSize = (int)(sizeof(FILE_OBJECTFIELDDEF) * (lpAlterObjectFieldBson->m_nFieldNum + lpAlterObjectFieldTemp->m_nFieldNum));
			}
			else
			{
				nSize = (int)(sizeof(FILE_OBJECTFIELDDEF) * lpAlterObjectFieldBson->m_nFieldNum);
			}
			if(lpObjectBlockHead->m_nVarDataInsertOffset - lpObjectBlockHead->m_nDataInsertOffset < nSize + (int)sizeof(SYSTEMBLOCKVARDATASTRUCT))
			{
				//空间不够
				Trace("CSystemManage::AlterObjectAddField", MF_TRACE_LEVEL_FAILED, 100023007, "添加对象列时，由于空间不够导致失败，对象名：%", lpAlterObjectFieldBson->m_pObjectName);
				return MF_INNER_ALLOWBLOCK_NOENOUGHSPACE;
			}

			//找到最后一个变长数据块
			nOffset = lpSysBlockItemVarData->m_nNextOffset;
			while(nOffset != 0)
			{
				lpSysBlockItemVarData = (LPSYSTEMBLOCKVARDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + nOffset);
				nOffset = lpSysBlockItemVarData->m_nNextOffset;
			}

			//分配新的变长空间
			lpSysBlockItemVarData->m_nNextOffset	  = lpObjectBlockHead->m_nVarDataInsertOffset - sizeof(SYSTEMBLOCKVARDATASTRUCT) - nSize;
			lpObjectBlockHead->m_nVarDataInsertOffset = lpSysBlockItemVarData->m_nNextOffset;
			lpVarNewData							  = (LPSYSTEMBLOCKVARDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + lpSysBlockItemVarData->m_nNextOffset);
			lpVarNewData->m_nDataFlag				  = MAKEHEADFLAG('S','B','B','V');
			lpVarNewData->m_nInnerNo				  = lpSysBlockItemData->m_nInnerNo;
			lpVarNewData->m_nDataLength				  = sizeof(SYSTEMBLOCKVARDATASTRUCT) + nSize;
			lpVarNewData->m_nActualLength			  = nSize;
			lpVarNewData->m_nNextOffset				  = 0;
			lpSysBlockItemData->m_nVarDataLength	  += lpVarNewData->m_nActualLength;
			lpFileField								  = (LPFILE_OBJECTFIELDDEF)(&lpVarNewData->m_pDataContent);

			if(lpObject->m_bObjectType == MF_OBJECT_COMMON)
			{
				lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpAlterObjectFieldBson->m_nFieldOffset);
				for(i = 0;i < lpAlterObjectFieldBson->m_nFieldNum;i++)
				{
					lpFileObject->m_nFieldNum1++;
					lpFieldBson->m_bFieldNo				= lpFileObject->m_nFieldNum1;
					lpFileField[i].m_bObjectFieldNo		= lpFileObject->m_nFieldNum1;
					lpFileField[i].m_bFieldType			= lpFieldBson->m_bFieldType;
					lpFileField[i].m_bCharLen			= lpFieldBson->m_bCharLen;
					lpFileField[i].m_bAllowNull			= lpFieldBson->m_bAllowNull;
					memcpy(lpFileField[i].m_lpszName, lpFieldBson->m_bFieldName, 32*sizeof(TCHAR));

					if(lpFieldBson->m_nNextOffset != 0)
					{
						lpFieldBson = (LPOBJECTFIELDDEFBSON)(stBson.ConvertOffset2Addr(lpFieldBson->m_nNextOffset));
					}
				}
				if(lpFileObject->m_nFieldNum1 - lpObject->m_nFieldNum != lpAlterObjectFieldBson->m_nFieldNum)
				{
					//空间不够
					Trace("CSystemManage::AlterObjectAddField", MF_TRACE_LEVEL_FAILED, 100023008, "添加对象列时，最后把数据更新到内存中时出现内存不正常错误，对象名：%", lpAlterObjectFieldBson->m_pObjectName);
					return MF_INNER_ALLOWBLOCK_NOENOUGHSPACE;
				}
			}
			else
			{
				BYTE bCount, n, *pFieldNum;
				//首先检查字段重名
				lpFileField			    = &(lpFileObject->m_stFirstField);	
				lpSysBlockItemVarData   = (LPSYSTEMBLOCKVARDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + lpSysBlockItemData->m_nVarDataOffset);
				bCount					= (BYTE)((lpSysBlockItemVarData->m_nActualLength - sizeof(FILE_OBJECTDEF))/sizeof(FILE_OBJECTFIELDDEF)) + 1;
				n						= 0;
				pFieldNum				= &lpFileObject->m_nFieldNum1;
				lpObjectTemp			= lpObject;
				lpAlterObjectFieldTemp	= lpAlterObjectFieldBson;
				while(TRUE)
				{
					for(i = 0; i < lpObjectTemp->m_nFieldNum; i++, n++)
					{
						if(n >= bCount)
						{
							if(lpSysBlockItemVarData->m_nNextOffset != 0)
							{
								lpSysBlockItemVarData = (LPSYSTEMBLOCKVARDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + lpSysBlockItemVarData->m_nNextOffset);
								lpFileField			  = (LPFILE_OBJECTFIELDDEF)(&lpSysBlockItemVarData->m_pDataContent);
								bCount				  = (BYTE)(lpSysBlockItemVarData->m_nActualLength / sizeof(FILE_OBJECTFIELDDEF));
								n					  = 0;
							}
							else
							{
								Trace("CSystemManage::AlterObjectAddField", MF_TRACE_LEVEL_FAILED, 100023009, "添加对象列时，最后把数据更新到内存中时出现内存不正常错误，对象名：%", lpAlterObjectFieldTemp->m_pObjectName);
								return MF_INNER_ALLOWBLOCK_NOENOUGHSPACE;
							}
						}
						lpFileField[n].m_bAllowNull		= lpObjectTemp->m_lpField[i].m_bAllowNull;
						lpFileField[n].m_bFieldType		= lpObjectTemp->m_lpField[i].m_bFieldType;
						lpFileField[n].m_bCharLen		= lpObjectTemp->m_lpField[i].m_bCharLen;
						lpFileField[n].m_bObjectFieldNo = lpObjectTemp->m_lpField[i].m_bObjectFieldNo;
						memcpy(lpFileField[n].m_lpszName, lpObjectTemp->m_lpField[i].m_lpszName, 32);
					}
					
					if(lpObjectTemp->m_bObjectType == lpAlterObjectFieldTemp->m_bObjectType)
					{
						lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpAlterObjectFieldTemp->m_nFieldOffset);
						for(i = 0; i < lpAlterObjectFieldTemp->m_nFieldNum; i++, n++)
						{
							if(n >= bCount)
							{
								if(lpSysBlockItemVarData->m_nNextOffset != 0)
								{
									lpSysBlockItemVarData = (LPSYSTEMBLOCKVARDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + lpSysBlockItemVarData->m_nNextOffset);
									lpFileField			  = (LPFILE_OBJECTFIELDDEF)(&lpSysBlockItemVarData->m_pDataContent);
									bCount				  = (BYTE)(lpSysBlockItemVarData->m_nActualLength / sizeof(FILE_OBJECTFIELDDEF));
									n					  = 0;
								}
								else
								{
									Trace("CSystemManage::AlterObjectAddField", MF_TRACE_LEVEL_FAILED, 100023011, "添加对象列时，最后把数据更新到内存中时出现内存不正常错误，对象名：%", lpAlterObjectFieldTemp->m_pObjectName);
									return MF_INNER_ALLOWBLOCK_NOENOUGHSPACE;
								}
							}
							
							*pFieldNum = (*pFieldNum) + 1;
							lpFieldBson->m_bFieldNo				= *pFieldNum;
							lpFileField[n].m_bObjectFieldNo		= *pFieldNum;
							lpFileField[n].m_bFieldType			= lpFieldBson->m_bFieldType;
							lpFileField[n].m_bCharLen			= lpFieldBson->m_bCharLen;
							lpFileField[n].m_bAllowNull			= lpFieldBson->m_bAllowNull;
							memcpy(lpFileField[n].m_lpszName, lpFieldBson->m_bFieldName, 32*sizeof(TCHAR));

							if(lpFieldBson->m_nNextOffset != 0)
							{
								lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpFieldBson->m_nNextOffset);
							}
						}
					}

					if(lpObjectTemp->m_lpNext != 0)
					{
						pFieldNum	 = &lpFileObject->m_nFieldNum2;
						lpObjectTemp = lpObjectTemp->m_lpNext;
						if(lpAlterObjectFieldTemp->m_nNextOffset != 0)
						{
							lpAlterObjectFieldTemp = (LPALTEROBJECTFIELDBSON)stBson.ConvertOffset2Addr(lpAlterObjectFieldTemp->m_nNextOffset);
						}
					}
					else
					{
						break;
					}
				}
			}
			
			lpAlterObjectFieldTemp = lpAlterObjectFieldBson;
			lpObjectTemp = lpObject;
			nFieldNum    = lpFileObject->m_nFieldNum1;
			while(TRUE)
			{
				int nOldFieldNum;
				//修改Object的列信息
				nOldFieldNum				= lpObjectTemp->m_nFieldNum;
				lpObjectTemp->m_nFieldNum	= nFieldNum;

				lpField = lpObjectTemp->m_lpField;
				lpObjectTemp->m_lpField	= new OBJECTFIELDDEF[nFieldNum];
				memcpy(lpObjectTemp->m_lpField, lpField, sizeof(OBJECTFIELDDEF) * lpObjectTemp->m_nFieldNum);	    //拷贝原始列数据
				delete [] lpField;

				lpObjectTemp->InitalMap();
				lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpAlterObjectFieldTemp->m_nFieldOffset);
				
				//将原始字段加入MAP
				for(i = 0; i < nOldFieldNum; i++)
				{
					lpObjectTemp->m_mapName2FieldNo.Set(lpObjectTemp->m_lpField[i].m_lpszName, (LPVOID)(i + 1));				
				}

				//将新增字段加入MAP
				for(i = 0; i < lpAlterObjectFieldTemp->m_nFieldNum;i++)												//添加新增列数据
				{
					lpObjectTemp->m_lpField[nOldFieldNum + i].m_bObjectFieldNo	= lpFieldBson->m_bFieldNo;
					lpObjectTemp->m_lpField[nOldFieldNum + i].m_bFieldType		= lpFieldBson->m_bFieldType;
					lpObjectTemp->m_lpField[nOldFieldNum + i].m_bCharLen		= lpFieldBson->m_bCharLen;
					lpObjectTemp->m_lpField[nOldFieldNum + i].m_bAllowNull		= lpFieldBson->m_bAllowNull;
					memcpy(lpObjectTemp->m_lpField[nOldFieldNum + i].m_lpszName, lpFieldBson->m_bFieldName, 32*sizeof(TCHAR));
					lpObjectTemp->m_mapName2FieldNo.Set(lpFieldBson->m_bFieldName, (LPVOID)lpFieldBson->m_bFieldNo);

					if(lpFieldBson->m_nNextOffset != 0)
					{
						lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpFieldBson->m_nNextOffset);
					}
				}
				
				if(lpObjectTemp->m_lpNext != NULL)
				{
					if(lpAlterObjectFieldTemp->m_nNextOffset != 0)
					{
						lpAlterObjectFieldTemp = (LPALTEROBJECTFIELDBSON)stBson.ConvertOffset2Addr(lpAlterObjectFieldTemp->m_nNextOffset);
						lpObjectTemp = lpObjectTemp->m_lpNext;
					}
					else
					{
						break;
					}
				}
				else
				{
					break;
				}
			}

			//修改块数据时间戳
			SetTimestamp(lpObjectBlockHead, nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_OBJECT, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AlterObjectAddField", MF_TRACE_LEVEL_FAILED, 100023099, "添加对象列时，出现未知异常，错误码：%d，对象名：%", GetLastError(), lpAlterObjectFieldBson->m_pObjectName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::AlterObjectDropField(CServiceBson& stBson, long long nTimestamp, LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson)
{
	LPVOID lpValue;
	string strFiledName;
	LPOBJECTDEF lpObject;
	LPFILE_OBJECTDEF lpFileObject;
	int n, nRet, nOffset, nFieldNum;
	LPOBJECTFIELDDEFBSON lpFieldBson;
	LPFILE_OBJECTFIELDDEF lpFileField;
	LPSYSTEMBLOCKHEAD lpObjectBlockHead;
	LPSYSTEMBLOCKDATASTRUCT lpSysBlockItemData;
	BYTE bCount, bFieldNo, bFieldOffset, bIndex;
	LPSYSTEMBLOCKVARDATASTRUCT lpSysBlockItemVarData;
	CCriticalSectionPtr cs(&m_critObject);
	try
	{
		lpObject = (LPOBJECTDEF)m_mapObject.Get(lpAlterObjectFieldBson->m_nObjectID);
		if(lpObject == NULL)
		{
			Trace("CSystemManage::AlterObjectDropField", MF_TRACE_LEVEL_FAILED, 100024001, "删除对象列时，没找到对象数据，对象ID：%d", lpAlterObjectFieldBson->m_nObjectID);
			return MF_SYS_OBJECT_NOTEXIST;
		}
		if(lpObject == NULL)
		{
			Trace("CSystemManage::AlterObjectDropField", MF_TRACE_LEVEL_FAILED, 100024002, "删除对象列时，找到的对象数据指针为空，对象ID：%d", lpAlterObjectFieldBson->m_nObjectID);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else if(lpObject->m_nObjectID != lpAlterObjectFieldBson->m_nObjectID)
		{
			//找出来的数据是错的，算法肯定出错了
			Trace("CSystemManage::AlterObjectDropField", MF_TRACE_LEVEL_FAILED, 100024003, "删除对象列时，找到的对象名不正确，对象ID：%d", lpAlterObjectFieldBson->m_nObjectID);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else
		{
			//需要修改内存和物理文件
			nRet = ConvertDataID2Offset(lpObject->m_nDataID, nOffset, lpObjectBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpSysBlockItemData = (LPSYSTEMBLOCKDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + nOffset);
			if(lpSysBlockItemData->m_nInnerNo != GetInnerNoFromDataID(lpObject->m_nDataID))
			{
				//找出来的数据是错的，算法肯定出错了
				Trace("CSystemManage::AlterObjectDropField", MF_TRACE_LEVEL_FAILED, 100024005, "删除对象列时，通过DataID找到的数据不正确，对象名：%s", lpObject->m_lpszName);
				return MF_INNER_INNERNO_DATAERROR;
			}

			lpSysBlockItemVarData = (LPSYSTEMBLOCKVARDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + lpSysBlockItemData->m_nVarDataOffset);
			lpFileObject		  = (LPFILE_OBJECTDEF)(&lpSysBlockItemVarData->m_pDataContent);
			while(TRUE)
			{
				nFieldNum = lpFileObject->m_nFieldNum1;
				bFieldOffset = 0;

				if(lpAlterObjectFieldBson->m_nFieldOffset != 0)
				{
					lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpAlterObjectFieldBson->m_nFieldOffset);
				}
				for(n = 0;n < lpAlterObjectFieldBson->m_nFieldNum;n++)
				{
					strFiledName = lpFieldBson->m_bFieldName;
					lpValue  = lpObject->m_mapName2FieldNo.Get(strFiledName.c_str());
					if(lpValue != NULL && (BYTE)reinterpret_cast<long long>(lpValue) > 0)
					{
						lpFileField	= &(lpFileObject->m_stFirstField);
						bFieldNo    = (BYTE)reinterpret_cast<long long>(lpValue);
						bIndex      = bFieldNo + bFieldOffset;
						if(lpSysBlockItemVarData->m_nNextOffset == 0)
						{
							if(bFieldNo <= nFieldNum)
							{
								//设置删除标志
								lpFileField[bIndex - 1].m_bObjectFieldNo			= 0;
								lpObject->m_lpField[bFieldNo - 1].m_bObjectFieldNo	= 0;
								lpObject->m_mapName2FieldNo.Remove(lpObject->m_lpField[bFieldNo - 1].m_lpszName);
							}
						}
						else
						{
							bCount = (BYTE)((lpSysBlockItemVarData->m_nActualLength - sizeof(FILE_OBJECTDEF))/sizeof(FILE_OBJECTFIELDDEF)) + 1;
							if(bIndex <= bCount)
							{
								//设置删除标志
								lpFileField[bIndex - 1].m_bObjectFieldNo			= 0;
								lpObject->m_lpField[bFieldNo - 1].m_bObjectFieldNo	= 0;
								lpObject->m_mapName2FieldNo.Remove(lpObject->m_lpField[bFieldNo - 1].m_lpszName);
							}
							else
							{
								bIndex = bIndex - bCount;
								nOffset  = lpSysBlockItemVarData->m_nNextOffset;
								while(nOffset != 0)
								{
									lpSysBlockItemVarData = (LPSYSTEMBLOCKVARDATASTRUCT)(((LPBYTE)lpObjectBlockHead) + nOffset);
									lpFileField			  = (LPFILE_OBJECTFIELDDEF)(&lpSysBlockItemVarData->m_pDataContent);
									bCount = (BYTE)((lpSysBlockItemVarData->m_nActualLength)/sizeof(FILE_OBJECTFIELDDEF));
									if(bIndex <= bCount)
									{
										//设置删除标志
										lpFileField[bIndex - 1].m_bObjectFieldNo			= 0;
										lpObject->m_lpField[bFieldNo - 1].m_bObjectFieldNo	= 0;
										lpObject->m_mapName2FieldNo.Remove(lpObject->m_lpField[bFieldNo - 1].m_lpszName);
										break;
									}
									else
									{
										bIndex = bIndex - bCount;
									}

									nOffset = lpSysBlockItemVarData->m_nNextOffset;
								}
							}
						}
					}
					else
					{
						//找出来的数据是错的，算法肯定出错了
						Trace("CSystemManage::AlterObjectDropField", MF_TRACE_LEVEL_FAILED, 100024006, "删除对象列时，通过字段名未找到相应字段，对象名：%s，字段名：%s", lpObject->m_lpszName, strFiledName.c_str());
						return MF_INNER_INNERNO_DATAERROR;
					}
					if(lpFieldBson->m_nNextOffset != 0)
					{
						lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(lpFieldBson->m_nNextOffset);
					}
				}
				
				if(lpAlterObjectFieldBson->m_nNextOffset)
				{
					lpAlterObjectFieldBson = (LPALTEROBJECTFIELDBSON)stBson.ConvertOffset2Addr(lpAlterObjectFieldBson->m_nNextOffset);
				}
				else
				{
					break;
				}
			}
			
			//修改块数据时间戳
			SetTimestamp(lpObjectBlockHead, nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_OBJECT, nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AlterObjectDropField", MF_TRACE_LEVEL_FAILED, 100024099, "删除对象列时，出现异常，错误码：%d，对象ID：%d", GetLastError(), lpAlterObjectFieldBson->m_nObjectID);
		return MF_INNER_EXPCETION_FAILED;
	}

	return MF_OK;
}

int CSystemManage::AlterObjectAddIndex(CServiceBson& stBson, long long nTimestamp, LPFILE_INDEXDEFBSON lpAddIndexBson)
{
	int nRet;
	string strTemp;
	LPINDEXDEF lpIndex;
	LPOBJECTDEF lpObject;
	LPFILE_INDEXDEF lpFileIndex;
	LPSYSTEMBLOCKHEAD lpBlockHead;
	CCriticalSectionPtr cs(&m_critObject);
	try
	{
		//首先进行数据排重
		lpObject = (LPOBJECTDEF)m_mapObject.Get(lpAddIndexBson->m_nObjectID);
		if(lpObject == NULL)
		{
			//索引已经存在
			Trace("CSystemManage::AlterObjectAddIndex", MF_TRACE_LEVEL_FAILED, 100025001, "添加对象索引时，没找到对象数据，对象ID：%d", lpAddIndexBson->m_nObjectID);
			return MF_SYS_OBJECT_NOTEXIST;
		}

		if(lpObject == NULL)
		{
			Trace("CSystemManage::AlterObjectAddIndex", MF_TRACE_LEVEL_FAILED, 100025002, "添加对象索引时，找到的对象数据指针为空，对象ID：%d", lpAddIndexBson->m_nObjectID);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else if(lpObject->m_nObjectID != lpAddIndexBson->m_nObjectID)
		{
			//找出来的数据是错的，算法肯定出错了
			Trace("CSystemManage::AlterObjectAddIndex", MF_TRACE_LEVEL_FAILED, 100025003, "添加对象索引时，找到的对象名不正确，对象ID：%d，索引名：%s", lpAddIndexBson->m_nObjectID, lpAddIndexBson->m_pIndexName);
			return MF_INNER_INNERNO_DATAERROR;
		}

		//查一下索引名称是否重名
		for(lpIndex = lpObject->m_lpIndex;lpIndex != NULL;lpIndex = lpIndex->m_pNext)
		{
			if(_tcsicmp(lpIndex->m_lpszName, lpAddIndexBson->m_pIndexName) == 0)
			{
				Trace("CSystemManage::AlterObjectAddIndex", MF_TRACE_LEVEL_FAILED, 100025003, "添加对象索引时，找到的重名的索引，对象名：%s，索引名：%s", lpObject->m_lpszName, lpAddIndexBson->m_pIndexName);
				return MF_SYS_OBJECT_ADDINDEX_EXIST;
			}
		}
		if(lpAddIndexBson->m_bConstraintType == MF_CONSTRAINT_PRIMARYKEY)
		{
			//判断是否有多个主键
			for(lpIndex = lpObject->m_lpIndex; lpIndex != NULL; lpIndex = lpIndex->m_pNext)
			{
				if(lpIndex->m_bConstraintType == MF_CONSTRAINT_PRIMARYKEY)
				{
					return MF_SYS_OBJECT_ADDINDEX_MULTIPRIMRAYKEY_ERROR;
				}
			}
		}

		//更新索引信息
		nRet = GetSystemFreeBlock(nTimestamp, MF_SYS_OBJECTTYPE_INDEX, sizeof(FILE_INDEXDEF), lpBlockHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpBlockHead == NULL)
		{
			Trace("CSystemManage::AlterObjectAddIndex", MF_TRACE_LEVEL_FAILED, 100025016, "添加对象索引时，获取索引写入块指针时未空，对象名：%s，索引文件名：%s", lpObject->m_lpszName, lpAddIndexBson->m_pIndexName);
			return MF_INNER_POINTER_NULL;
		}
		else
		{
			lpFileIndex = (LPFILE_INDEXDEF)(((LPBYTE)lpBlockHead) + lpBlockHead->m_nDataInsertOffset);
			lpFileIndex->m_nInnerNo	= lpBlockHead->m_nInnerMaxNo;
			lpBlockHead->m_nInnerMaxNo++;
			_tcscpy(lpFileIndex->m_lpszName, lpAddIndexBson->m_pIndexName);
			lpFileIndex->m_nIndexID		= m_pMemoryFileHead->m_nObjectMaxID;
			m_pMemoryFileHead->m_nObjectMaxID++;
			lpFileIndex->m_nObjectID	= lpObject->m_nObjectID;
			lpFileIndex->m_nBlockSize	= lpAddIndexBson->m_nBlockSize;
			lpFileIndex->m_bIndexType	= lpAddIndexBson->m_bIndexType;
			lpFileIndex->m_bFileNo		= lpAddIndexBson->m_bFileNo;
			lpFileIndex->m_bFieldNo[0]	= lpAddIndexBson->m_bFieldNo[0];
			lpFileIndex->m_bFieldNo[1]	= lpAddIndexBson->m_bFieldNo[1];
			lpFileIndex->m_bFieldNo[2]	= lpAddIndexBson->m_bFieldNo[2];
			lpFileIndex->m_bFieldNo[3]	= lpAddIndexBson->m_bFieldNo[3];
			lpFileIndex->m_bConstraintType = lpAddIndexBson->m_bConstraintType;

			//分配索引空间
			nRet = AllocFileData(lpFileIndex->m_bFileNo, lpFileIndex->m_nIndexID, lpFileIndex->m_nBlockSize, lpFileIndex->m_bIndexType, lpFileIndex->m_nDataNum);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpBlockHead->m_nDataInsertOffset+= lpBlockHead->m_nBlockDataStructSize;
			lpBlockHead->m_nDataNum++;
			SetTimestamp(lpBlockHead, nTimestamp);

			lpIndex = new INDEXDEF;
			lpIndex->m_nDataID			= MakeDataID(lpBlockHead->m_bFileNo, lpBlockHead->m_nBlockNo, lpFileIndex->m_nInnerNo);
			lpIndex->m_nIndexID			= lpFileIndex->m_nIndexID;
			lpIndex->m_nBlockSize		= lpFileIndex->m_nBlockSize;
			_tcscpy(lpIndex->m_lpszName, lpAddIndexBson->m_pIndexName);
			lpIndex->m_nObjectID		= lpObject->m_nObjectID;
			lpIndex->m_bIndexType		= lpFileIndex->m_bIndexType;
			lpIndex->m_bFileNo			= lpFileIndex->m_bFileNo;
			lpIndex->m_bFieldNo[0]		= lpFileIndex->m_bFieldNo[0];
			lpIndex->m_bFieldNo[1]		= lpFileIndex->m_bFieldNo[1];
			lpIndex->m_bFieldNo[2]		= lpFileIndex->m_bFieldNo[2];
			lpIndex->m_bFieldNo[3]		= lpFileIndex->m_bFieldNo[3];
			lpIndex->m_pNext			= lpObject->m_lpIndex;			
			lpObject->m_lpIndex			= lpIndex;
			lpIndex->m_bConstraintType	= lpFileIndex->m_bConstraintType;
			lpIndex->m_bStatus          = 0;
			lpIndex->m_nTimestamp		= 0;
			m_mapIndex.Set(lpIndex->m_nIndexID, lpIndex);

			//为相应字段创建索引
			IVirtualMemoryFile* pIVirtualMemoryFile = NULL;
			nRet = GetMemoryFileInstance(lpFileIndex->m_bFileNo, pIVirtualMemoryFile);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			switch(lpFileIndex->m_bIndexType)
			{
			case MF_SYS_INDEXTYPE_KV_INT:
			case MF_SYS_INDEXTYPE_KV_BIGINT:
			case MF_SYS_INDEXTYPE_KV_DOUBLE:
			case MF_SYS_INDEXTYPE_KV_CHAR:
				nRet = ((CMemoryHashFile*)pIVirtualMemoryFile)->CreateIndex(stBson, lpFileIndex->m_nObjectID, lpFileIndex->m_nIndexID, lpFileIndex->m_bFieldNo[0]);
				break;
			case MF_SYS_INDEXTYPE_TREE_INT:
			case MF_SYS_INDEXTYPE_TREE_BIGINT:
			case MF_SYS_INDEXTYPE_TREE_DOUBLE:
			case MF_SYS_INDEXTYPE_TREE_MULTINUM:  
			case MF_SYS_INDEXTYPE_TREE_MULTISTR:
			case MF_SYS_INDEXTYPE_FUZZY_CHAR:
				nRet = ((CMemoryBTreeFile*)pIVirtualMemoryFile)->CreateIndex(stBson, lpFileIndex->m_nObjectID, lpFileIndex->m_nIndexID, lpFileIndex->m_bFieldNo, lpIndex->m_bConstraintType);
				break;	
			default:
				return MF_COMMON_INVALID_INDEXTYPE;
			}
			if(nRet != MF_OK)
			{
				return nRet;
			}
			SortObjectIndex(lpObject);
		}	
		
		SetObjectTimestamp(MF_SYS_OBJECTTYPE_INDEX, nTimestamp);
	}	
	catch (...)
	{
		Trace("CSystemManage::AlterObjectAddIndex", MF_TRACE_LEVEL_FAILED, 100025099, "添加对象索引时，出现未知异常，错误码：%d，对象名：%d，索引文件名：%s", GetLastError(), lpAddIndexBson->m_nObjectID, lpAddIndexBson->m_pIndexName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::AlterObjectDropIndex(LPEXECUTEPLANBSON lpExecutePlan, int lObjectID, LPFILE_INDEXDEFBSON lpIndexBson)
{
	int nRet, nOffset;
	char* lpszIndexName;
	LPOBJECTDEF lpObject;
	LPINDEXDEF lpIndex, pPrev;
	LPFILE_INDEXDEF lpFileIndex;
	LPSYSTEMBLOCKHEAD lpObjectBlockHead;
	CCriticalSectionPtr cs(&m_critObject);
	try
	{
		lpObject = (LPOBJECTDEF)m_mapObject.Get(lObjectID);
		if(lpObject == NULL)
		{
			Trace("CSystemManage::AlterObjectDropIndex", MF_TRACE_LEVEL_FAILED, 100026001, "删除对象索引时，没找到对象数据，对象ID：%d", lObjectID);
			return MF_SYS_OBJECT_NOTEXIST;
		}

		if(lpObject == NULL)
		{
			Trace("CSystemManage::AlterObjectDropIndex", MF_TRACE_LEVEL_FAILED, 100026002, "删除对象索引时，找到的对象数据指针为空，对象ID：%d", lObjectID);
			return MF_INNER_INNERNO_DATAERROR;
		}
		else if(lpObject->m_nObjectID != lObjectID)
		{
			//找出来的数据是错的，算法肯定出错了
			Trace("CSystemManage::AlterObjectDropIndex", MF_TRACE_LEVEL_FAILED, 100026003, "删除对象索引时，找到的对象名不正确，对象ID：%d", lObjectID);
			return MF_INNER_INNERNO_DATAERROR;
		}

		lpszIndexName = lpIndexBson->m_pIndexName;
		//查一下索引名称
		for(lpIndex = lpObject->m_lpIndex;lpIndex != NULL;lpIndex = lpIndex->m_pNext)
		{
			if(_tcsicmp(lpIndex->m_lpszName, lpszIndexName) == 0)
			{
				break;
			}
		}
		if(lpIndex == NULL)
		{
			Trace("CSystemManage::AlterObjectDropIndex", MF_TRACE_LEVEL_FAILED, 100026004, "删除对象索引时，找不到对应的索引，对象名：%s，索引名：%s", lpObject->m_lpszName, lpszIndexName);
			return MF_SYS_OBJECT_DELETEINDEX_NOTEXIST;
		}
		else
		{
			//需要修改内存和物理文件
			nRet = ConvertDataID2Offset(lpIndex->m_nDataID, nOffset, lpObjectBlockHead);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpFileIndex = (LPFILE_INDEXDEF)(((LPBYTE)lpObjectBlockHead) + nOffset);
			if(_tcsicmp(lpFileIndex->m_lpszName, lpszIndexName) != 0)
			{
				//找出来的数据是错的，算法肯定出错了
				Trace("CSystemManage::AlterObjectDropIndex", MF_TRACE_LEVEL_FAILED, 100026004, "删除对象索引时，按数据ID找出来的索引名称对不上，对象名：%s，索引名：%s", lpObject->m_lpszName, lpszIndexName);
				return MF_INNER_INNERNO_DATAERROR;
			}

			//删除索引
			IVirtualMemoryFile* pIVirtualMemoryFile = NULL;
			nRet = GetMemoryFileInstance(lpFileIndex->m_bFileNo, pIVirtualMemoryFile);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			switch(lpFileIndex->m_bIndexType)
			{
			case MF_SYS_INDEXTYPE_KV_INT:
			case MF_SYS_INDEXTYPE_KV_BIGINT:
			case MF_SYS_INDEXTYPE_KV_DOUBLE:
			case MF_SYS_INDEXTYPE_KV_CHAR:
			case MF_SYS_INDEXTYPE_HB_CHAR:
			case MF_SYS_INDEXTYPE_HB_INT:
				((CMemoryHashFile*)pIVirtualMemoryFile)->DropObject(lpExecutePlan, lpFileIndex->m_nIndexID);
				break;
			case MF_SYS_INDEXTYPE_TREE_INT:
			case MF_SYS_INDEXTYPE_TREE_BIGINT:
			case MF_SYS_INDEXTYPE_TREE_DOUBLE:
			case MF_SYS_INDEXTYPE_TREE_MULTINUM:  
			case MF_SYS_INDEXTYPE_TREE_MULTISTR:
			case MF_SYS_INDEXTYPE_FUZZY_CHAR:
				((CMemoryBTreeFile*)pIVirtualMemoryFile)->DropObject(lpExecutePlan, lpFileIndex->m_nIndexID);
				break;
			default:
				return MF_COMMON_INVALID_INDEXTYPE;
			}

			//修改删除标志
			lpFileIndex->m_bDropFlag = 1;
			//修改内存中的数据
			pPrev = NULL;
			m_mapIndex.Remove(lpIndex->m_nIndexID);
			for(lpIndex = lpObject->m_lpIndex;lpIndex != NULL;)
			{
				if(lpIndex->m_nIndexID == lpFileIndex->m_nIndexID)
				{
					//处理删除数据
					if(pPrev == NULL)
					{
						lpObject->m_lpIndex = lpIndex->m_pNext;
						delete lpIndex;
					}
					else
					{
						pPrev->m_pNext = lpIndex->m_pNext;
						delete lpIndex;
					}
					lpIndex = NULL;
					break;
				}
				pPrev = lpIndex;
				lpIndex = lpIndex->m_pNext;
			}

			//修改块数据时间戳
			SetTimestamp(lpObjectBlockHead, lpExecutePlan->m_nTimestamp);
			SetObjectTimestamp(MF_SYS_OBJECTTYPE_INDEX, lpExecutePlan->m_nTimestamp);
		}
	}
	catch (...)
	{
		Trace("CSystemManage::AlterObjectDropIndex", MF_TRACE_LEVEL_FAILED, 100026099, "删除对象索引时，按数据ID出现未知异常，错误码：%d，对象ID：%d，索引名：%s", GetLastError(), lObjectID, lpszIndexName);
		return MF_INNER_EXPCETION_FAILED;
	}
	return MF_OK;
}

int CSystemManage::GetObjectInfo(LPCTSTR lpszObjectName, LPOBJECTDEF &lpObjectInfo)
{
	lpObjectInfo = (LPOBJECTDEF)m_mapName2Object.Get((char*)lpszObjectName);
	if(lpObjectInfo == NULL)
	{
		Trace("CSystemManage::GetObjectInfo", MF_TRACE_LEVEL_FAILED, 100027001, "获取对象信息时，未找到指定名称的对象，对象名：%s", lpszObjectName);
		return MF_SYS_OBJECT_NOTEXIST;
	}
	return MF_OK;
}

BOOL CSystemManage::FindObject(LPCTSTR lpszObjectName)
{
	LPVOID lpData;

	lpData = m_mapName2Object.Get((char*)lpszObjectName);
	if(lpData == NULL)
	{
		return FALSE;
	}
	return TRUE;
}

int CSystemManage::GetObjectInfo(int nObjectID, LPOBJECTDEF &lpObjectInfo)
{
	lpObjectInfo = NULL;
	map<int, LPOBJECTDEF>::iterator iter;

	lpObjectInfo = (LPOBJECTDEF)m_mapObject.Get(nObjectID);
	if(lpObjectInfo == NULL)
	{
		Trace("CSystemManage::GetObjectInfo", MF_TRACE_LEVEL_FAILED, 100028001, "获取对象信息时，未找到指定名称的对象，对象ID：%d", nObjectID);
		return MF_SYS_OBJECT_NOTEXIST;
	}
	
	if(lpObjectInfo == NULL)
	{
		Trace("CSystemManage::GetObjectInfo", MF_TRACE_LEVEL_ERROR, 100028002, "获取对象信息时，找到的对象指针为空，对象ID：%d", nObjectID);
		return MF_INNER_POINTER_NULL;
	}
	return MF_OK;

}

int CSystemManage::GetUserInfo(LPCTSTR lpszUserName, LPUSERINFODEF &lpUserInfo)
{
	lpUserInfo = (LPUSERINFODEF)m_mapName2UserInfo.Get(lpszUserName);
	if(lpUserInfo == NULL)
	{
		Trace("CSystemManage::GetUserInfo", MF_TRACE_LEVEL_ERROR, 100091001, "获取用户信息时，找到的用户指针为空，用户名：%s", lpszUserName);
		return MF_INNER_POINTER_NULL;
	}
	return MF_OK;
}

int CSystemManage::GetUserInfo(long long nUserID, LPUSERINFODEF &lpUserInfo)
{
	lpUserInfo = (LPUSERINFODEF)m_mapUserInfo.Get(nUserID);
	if(lpUserInfo == NULL)
	{
		Trace("CSystemManage::GetUserInfo", MF_TRACE_LEVEL_FAILED, 100092001, "获取用户信息时，未找到指定名称的用户，用户ID：%d", nUserID);
		return MF_SYS_USER_NOTEXIST;
	}
	return MF_OK;
}

int CSystemManage::GetAuthority(MF_AUTHORITY_ID bAuthorityID, LPAUTHORITYINFO &lpAuthority)
{
	lpAuthority = (LPAUTHORITYINFO)m_mapAuthority.Get(bAuthorityID);
	if(lpAuthority == NULL)
	{
		Trace("CSystemManage::GetAuthority", MF_TRACE_LEVEL_ERROR, 100099001, "获取权限信息时，找到的权限指针为空，权限ID：%d", bAuthorityID);
		return MF_INNER_POINTER_NULL;
	}
	return MF_OK;
}

int CSystemManage::GetAuthority(LPCTSTR lpszAuthorityName, LPAUTHORITYINFO &lpAuthority)
{
	lpAuthority = (LPAUTHORITYINFO)m_mapName2Authority.Get(lpszAuthorityName);
	if(lpAuthority == NULL)
	{
		Trace("CSystemManage::GetAuthority", MF_TRACE_LEVEL_FAILED, 100074001, "获取权限信息时，未找到指定名称的权限，权限名：%d", lpszAuthorityName);
		return MF_SYS_AUTHORITY_NOTEXIST;
	}
	return MF_OK;
}

int CSystemManage::GetIndexInfo(int IndexID, LPINDEXDEF &lpIndexInfo)
{
	lpIndexInfo = (LPINDEXDEF)m_mapIndex.Get(IndexID);
	if(lpIndexInfo == NULL)
	{
		Trace("CSystemManage::GetObjectInfo", MF_TRACE_LEVEL_ERROR, 100029001, "获取对象信息时，找到的索引指针为空，索引ID：%d", IndexID);
		return MF_INNER_POINTER_NULL;
	}
	return MF_OK;
}


void CSystemManage::WriteTraceLog(LPCSTR szFuncationName, LONG dwThreadID, DWORD dwLevel, DWORD dwErrorCode, LPCSTR szText)
{
	FILE* pFile;
	DWORD dwWriteLen;
	if(m_pCommonTraceFile == NULL)
	{
		BOOL bFind;
		int i,nIndex;
		char lpFilePath[256];

		bFind = FALSE;
		memset(lpFilePath, 0, 256);
		GetModuleFileName(NULL, lpFilePath, 256);
		nIndex = _tcslen(lpFilePath) - 1;
		for(;nIndex > 0;nIndex--)
		{
			if(lpFilePath[nIndex] == '\\' || lpFilePath[nIndex] == '/')
			{
				bFind = TRUE;
				_tcscpy(&lpFilePath[nIndex + 1], "VernoxService.log");
				break;
			}
			else
			{
				lpFilePath[nIndex] = 0;
			}
		}

		if(!bFind)
		{
			//这个都失败了，那就真没办法写日志了
			return;
		}

		for(i = 0; i < 5;i++)
		{
			m_pCommonTraceFile = fopen(lpFilePath, "ab+");
			if (m_pCommonTraceFile == NULL)
			{
				Sleep(10);
				continue;
			}
			break;
		}

		if(NULL != m_pCommonTraceFile)
		{
			DWORD dwSize;
			char lpTextBuf[256];
			dwWriteLen = 0;
			pFile = m_pCommonTraceFile;
			dwSize = GetFileSize(pFile, NULL);
			if(dwSize==0)
			{
				//				TCHAR tcFileHead[4];
				//				tcFileHead[0] = 0xEF;
				//				tcFileHead[1] = 0xBB;
				//				tcFileHead[2] = 0xBF;
				//				if(!fwrite(&tcFileHead, 3, 3, m_pCommonTraceFile))
				//				{
				//					fclose(m_pCommonTraceFile);
				//					m_pCommonTraceFile = NULL;
				//					return ;
				//				}
				_tcscpy(lpTextBuf, "Timestamp               Thread	Level    Code     FuncationName		Description");
				fwrite(lpTextBuf, sizeof(TCHAR), _tcslen(lpTextBuf), m_pCommonTraceFile);
			}
			else
			{
				fseek(m_pCommonTraceFile, 0 ,SEEK_END);
			}
		}
	}
	if(m_pCommonTraceFile != NULL)
	{
		TCHAR lpTextBuf[256];
		
		if(dwThreadID == 0)
			dwThreadID = GetCurrentThreadId();
#ifdef WIN32
		SYSTEMTIME	st;
		GetLocalTime(&st);
		sprintf_s(lpTextBuf, 256*sizeof(TCHAR), "\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d %d %d %s ",
			st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, dwThreadID, dwLevel, dwErrorCode, szFuncationName);
#else
		timeval tTime;
		tm* pLoalTime;
		gettimeofday(&tTime, NULL);
		pLoalTime = localtime(&tTime.tv_sec);
		sprintf(lpTextBuf, "\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d %d %d %s ",
				pLoalTime->tm_year + 1900, pLoalTime->tm_mon + 1, pLoalTime->tm_mday, pLoalTime->tm_hour, pLoalTime->tm_min, pLoalTime->tm_sec,
				(int)(tTime.tv_usec/1000), dwThreadID, dwLevel, dwErrorCode, szFuncationName);

#endif
	
		dwWriteLen = 0;
		fwrite(lpTextBuf, sizeof(TCHAR), _tcslen(lpTextBuf), m_pCommonTraceFile);
		fwrite(szText, sizeof(TCHAR), _tcslen(szText), m_pCommonTraceFile);
	}
}

BOOL CSystemManage::TraceLog(LPCSTR szFuncationName, LONG dwThreadID, DWORD dwLevel, DWORD dwErrorCode, LPCSTR szText)
{	
	int nReadPos, nWritePos, nLen, nTextLen, nBufLen, nRemainLen;	
	if(dwThreadID == 0)
		dwThreadID = GetCurrentThreadId();
	nTextLen = _tcslen(szText)*sizeof(TCHAR);

	CCriticalSectionPtr cs(&m_critTrace);
	try
	{
		if(m_pTraceFileHead == NULL)
		{
			//转为本进程直接写日志，按道理不应该出现此问题
			WriteTraceLog(szFuncationName, dwThreadID, dwLevel, dwErrorCode, szText);
			return TRUE;
		}
		else
		{
			nRemainLen = sizeof(TCHAR) * 128;
			if(m_pTraceFileHead->m_nReadPos > m_pTraceFileHead->m_nWritePos && (m_pTraceFileHead->m_nReadPos - m_pTraceFileHead->m_nWritePos == 1 || m_pTraceFileHead->m_nReadPos - m_pTraceFileHead->m_nWritePos == 2))
			{
				//已经写满了
				SetEvent(m_hTraceEvent);
				WriteTraceLog(szFuncationName, 0, MF_TRACE_LEVEL_ERROR, 100000010, "由于日志没有及时的写入到文件，日志内存文件没有可用空间，下面是日志内容：");
				WriteTraceLog(szFuncationName, dwThreadID, dwLevel, dwErrorCode, szText);
				return FALSE;
			}
			else
			{
				nReadPos = m_pTraceFileHead->m_nReadPos;
			}
#ifdef WIN32
			SYSTEMTIME	st;
			GetLocalTime(&st);
			sprintf_s(m_lpszTraceBuf, MF_TRACE_BUFFER_SIZE,"\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d %d %d %s ",
				st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, dwThreadID, dwLevel, dwErrorCode, szFuncationName);
#else
			timeval tTime;
			tm* pLoalTime;
			gettimeofday(&tTime, NULL);
			pLoalTime = localtime(&tTime.tv_sec);
			sprintf(m_lpszTraceBuf, "\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d %d %d %s ",
				pLoalTime->tm_year + 1900, pLoalTime->tm_mon + 1, pLoalTime->tm_mday, pLoalTime->tm_hour, pLoalTime->tm_min, pLoalTime->tm_sec,
				(int)(tTime.tv_usec/1000), dwThreadID, dwLevel, dwErrorCode, szFuncationName);

#endif

			nBufLen = _tcslen(m_lpszTraceBuf)*sizeof(TCHAR);
			//先判断是否能够整体写的下日志内容
			nLen = nBufLen + nTextLen;
			nWritePos = m_pTraceFileHead->m_nWritePos;

			//把数据写入到共享内存区域
			if(m_pTraceFileHead->m_nWritePos < nReadPos)
			{
				//先判断是否能够整体写的下日志内容
				if(nLen > nReadPos - nWritePos - nRemainLen)
				{
					//写不下日志，需要丢弃日志
					WriteTraceLog(szFuncationName, 0, MF_TRACE_LEVEL_ERROR, 100000011, "由于日志没有及时的写入到文件或者日志内容过大，日志内存文件剩余放不下此条日志信息，下面是日志内容：");
					WriteTraceLog(szFuncationName, dwThreadID, dwLevel, dwErrorCode, szText);
					return FALSE;
				}

				//只能写中间一部分的数据，且不能写满了，必须得空一个字节（建议空两个字节）
				nLen = nBufLen;
				memcpy(m_pTraceFileAddr + nWritePos, m_lpszTraceBuf, nLen);
				nWritePos += nLen;
				nLen = nTextLen;
				memcpy(m_pTraceFileAddr + nWritePos, szText, nLen);
				nWritePos += nLen;
				if(nWritePos + (int)sizeof(TCHAR) < nReadPos)
				{
					m_pTraceFileHead->m_nWritePos = nWritePos;
				}
				else
				{
					//这个怎么可能呢？如果真出现了，那就是写日志出现错误，所以只有采取不修改有效数据指针来解决问题
					WriteTraceLog(szFuncationName, 0, MF_TRACE_LEVEL_ERROR, 100000012, "写日志时计算的空间是够的，但实际写完后发现指针位置出现了问题，可能出现日志数据被覆盖的情况，下面是日志内容：");
					WriteTraceLog(szFuncationName, dwThreadID, dwLevel, dwErrorCode, szText);
				}

				if(nReadPos - nWritePos < MF_TRACE_FILE_WORNING_SIZE)
				{
					//提醒另外一个服务立即写日志
					SetEvent(m_hTraceEvent);
				}
			}
			else
			{
				//这种情况就是需要直接先写到尾，然后再从头开始写
				//先判断是否能够整体写的下日志内容
				if(nLen > MF_TRACE_FILE_SIZE - m_pTraceFileHead->m_nFileHeaderSize - (nWritePos - nReadPos + nRemainLen))
				{
					//写不下日志，需要丢弃日志
					WriteTraceLog(szFuncationName, 0, MF_TRACE_LEVEL_ERROR, 100000013, "由于日志没有及时的写入到文件或者日志内容过大，日志内存文件剩余放不下此条日志信息，下面是日志内容：");
					WriteTraceLog(szFuncationName, dwThreadID, dwLevel, dwErrorCode, szText);
					return FALSE;
				}

				//计算一下，当前位置到结尾是否够
				if(nLen <= MF_TRACE_FILE_SIZE - nWritePos)
				{
					nLen = nBufLen;
					memcpy(m_pTraceFileAddr + nWritePos, m_lpszTraceBuf, nLen);
					nWritePos += nLen;
					nLen = nTextLen;
					memcpy(m_pTraceFileAddr + nWritePos, szText, nLen);
					nWritePos += nLen;
					if(nWritePos >= MF_TRACE_FILE_SIZE)
					{
						nWritePos = m_pTraceFileHead->m_nFileHeaderSize;
					}
				}
				else if(nBufLen <= MF_TRACE_FILE_SIZE - nWritePos)
				{
					nLen = nBufLen;
					memcpy(m_pTraceFileAddr + nWritePos, m_lpszTraceBuf, nLen);
					nWritePos += nLen;
					nLen = nTextLen;
					nLen = min(nLen, MF_TRACE_FILE_SIZE - nWritePos);
					memcpy(m_pTraceFileAddr + nWritePos, szText, nLen);
					nWritePos = m_pTraceFileHead->m_nFileHeaderSize;
					if(nTextLen - nLen > 0)
					{
						memcpy(m_pTraceFileAddr + nWritePos, ((LPBYTE)szText) + nLen, nTextLen - nLen);
						nWritePos += nTextLen - nLen;
					}
				}
				else
				{
					nLen = nBufLen;
					nLen = min(nLen, MF_TRACE_FILE_SIZE - nWritePos);
					memcpy(m_pTraceFileAddr + nWritePos, m_lpszTraceBuf, nLen);
					nWritePos = m_pTraceFileHead->m_nFileHeaderSize;
					if(nBufLen - nLen > 0)
					{
						memcpy(m_pTraceFileAddr + nWritePos, ((LPBYTE)m_lpszTraceBuf) + nLen, nBufLen - nLen);
						nWritePos += nBufLen - nLen;
					}
					nLen = nTextLen;
					memcpy(m_pTraceFileAddr + nWritePos, szText, nLen);
					nWritePos += nLen;
				}

				m_pTraceFileHead->m_nWritePos = nWritePos;

				if((nWritePos < nReadPos && nReadPos - nWritePos < MF_TRACE_FILE_WORNING_SIZE) || (nWritePos > nReadPos  && nWritePos - nReadPos > MF_TRACE_FILE_WORNING_SIZEEX))
				{
					//提醒另外一个服务立即写日志
					SetEvent(m_hTraceEvent);
				}
			}
		}
	}
	catch(...)
	{
		Trace("CSystemManage::TraceLog", MF_TRACE_LEVEL_FAILED, 100049001, "写日志异常，错误码：%d", GetLastError());
		return MF_SYS_OBJECT_NOTEXIST;
	}
	return TRUE;
}

//100030000
int CSystemManage::GetMemoryFileInstance(BYTE bFileNo, IVirtualMemoryFile* &pVMF)
{
	LPMEMDBFILEDEF lpMemDBFileDef = NULL;
	if(bFileNo == 0)
	{
		pVMF = NULL;
		return MF_INNER_POINTER_NULL;
	}

	lpMemDBFileDef = m_arMemDBFile[bFileNo];
	if(lpMemDBFileDef == NULL)
	{
		Trace("CSystemManage::GetMemoryFileInstance", MF_TRACE_LEVEL_FAILED, 100030002, "根据内存文件编号查找到内存对象指针，但是为空指针，文件编号：%d", bFileNo);
		return MF_INNER_POINTER_NULL;
	}
	if(lpMemDBFileDef->m_pInstance == NULL)
	{
		Trace("CSystemManage::GetMemoryFileInstance", MF_TRACE_LEVEL_FAILED, 100030003, "根据内存文件编号查找到内存对象指针，但实例未初始化，文件编号：%d", bFileNo);
		return MF_INNER_INSTANCE_UNINITALIZE;
	}

	pVMF = lpMemDBFileDef->m_pInstance;
	return MF_OK;
}

//100031000
int CSystemManage::AllocFileData(BYTE bFileNo, int nID, int nBlockSize, MF_SYS_INDEXTYPE bType, int nDataNum)
{
	LPMEMDBFILEDEF lpMemDBFileDef = NULL;

	lpMemDBFileDef = m_arMemDBFile[bFileNo];
	if(lpMemDBFileDef == NULL)
	{
		Trace("CSystemManage::RecycleFileData", MF_TRACE_LEVEL_FAILED, 100031002, "根据内存文件编号查找内存数据存在，但是为空指针，文件编号：%d", bFileNo);
		return MF_INNER_POINTER_NULL;
	}
	if(lpMemDBFileDef->m_pInstance == NULL)
	{
		Trace("CSystemManage::RecycleFileData", MF_TRACE_LEVEL_FAILED, 100031003, "根据内存文件编号查找内存数据，但实例未初始化，文件编号：%d", bFileNo);
		return MF_INNER_INSTANCE_UNINITALIZE;
	}

	return lpMemDBFileDef->m_pInstance->CreateObject(nID, nBlockSize, bType, nDataNum);
}

//100032000
int CSystemManage::ModifyMemDBFile(CServiceBson& stBson, long long nTimestamp, LPFILE_MEMDBFILEINFOBSON lpDBFileBson)
{
	LPMEMDBFILEDEF lpMemDBFileDef = NULL;

	lpMemDBFileDef = m_arMemDBFile[lpDBFileBson->m_bFileNo];
	if(lpMemDBFileDef == NULL)
	{
		Trace("CSystemManage::ModifyMemDBFile", MF_TRACE_LEVEL_FAILED, 100032002, "根据内存文件编号查找到内存对象指针，但是为空指针，文件编号：%d", lpDBFileBson->m_bFileNo);
		return MF_INNER_POINTER_NULL;
	}

	if(lpDBFileBson->m_nFileSize > lpMemDBFileDef->m_nFileSize && _tcsicmp(lpDBFileBson->m_pAlterFilePath, lpMemDBFileDef->m_lpszFilePath) == 0)
	{
		//如果大小改变
		return AlterMemDBFileSize(nTimestamp, lpDBFileBson->m_bFileNo, lpMemDBFileDef->m_lpszFilePath, lpDBFileBson->m_nFileSize);
	}
	else if(_tcsicmp(lpDBFileBson->m_pAlterFilePath, lpMemDBFileDef->m_lpszFilePath) != 0 && lpDBFileBson->m_nFileSize == lpMemDBFileDef->m_nFileSize)
	{
		//如果物理文件名改变
		return AlterMemDBFilePath(nTimestamp, lpDBFileBson->m_bFileNo, lpMemDBFileDef->m_lpszFilePath, lpDBFileBson->m_pAlterFilePath);
	}
	else
	{
		return MF_FAILED;
	}
	return MF_OK;
}

int CSystemManage::GetMemDBFileInfoByNo(BYTE bFileNo, LPMEMDBFILEDEF &lpMemDBFileDef)
{
	lpMemDBFileDef = m_arMemDBFile[bFileNo];
	if(lpMemDBFileDef == NULL)
	{
		return MF_SYS_DBFILE_NOTEXIST;
	}

	return MF_OK;
}
//100033000
int CSystemManage::GetMemDBFileInfo(LPCTSTR lpszFilePath, LPMEMDBFILEDEF &lpMemDBFileDef)
{
	int i;
	for(i = 0;i < 256;i++)
	{
		lpMemDBFileDef = m_arMemDBFile[i];
		if(lpMemDBFileDef == NULL)
		{
			continue;
		}
		if(_tcsicmp(lpszFilePath, lpMemDBFileDef->m_lpszFilePath) == 0)
		{
			return MF_OK;
		}
	}

	lpMemDBFileDef = NULL;
	return MF_SYS_DBFILE_NOTEXIST;
}

//100034000
int CSystemManage::GetMemDBFileInfoByMem(LPCTSTR lpszMemFileName, LPMEMDBFILEDEF &lpMemDBFileDef)
{
	int i, nRet;
	string strMemFileName;
	nRet = CreateMemDBFileName(lpszMemFileName, strMemFileName);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	for(i = 0;i < 256;i++)
	{
		lpMemDBFileDef = m_arMemDBFile[i];
		if(lpMemDBFileDef == NULL)
		{
			continue;
		}

		if(_tcsicmp(lpszMemFileName, lpMemDBFileDef->m_lpszMemFileName) == 0)
		{
			return MF_OK;
		}
		if(strMemFileName.compare(lpMemDBFileDef->m_lpszMemFileName) == 0)
		{
			return MF_OK;
		}
	}
	lpMemDBFileDef = NULL;
	return MF_SYS_DBFILE_NOTEXIST;
}

//100035000
int CSystemManage::CreateMemDBFileName(LPCTSTR lpszMemFileName, string &strMemFileName)
{
	int i, nLen;
	string strGlobalName;

	nLen = _tcslen(lpszMemFileName);
	for(i = 0; i < nLen; i++)
	{
		if((lpszMemFileName[i] >= 'A' && lpszMemFileName[i] <= 'F') || (lpszMemFileName[i] >= 'a' && lpszMemFileName[i] <= 'f'))
		{
			continue;
		}
		else if((lpszMemFileName[i] >= '0' && lpszMemFileName[i] <= '9'))
		{
			if(i == 0)
			{
				return MF_INNER_SYS_MEMDBFILENAME_INVALID;
			}
			continue;
		}
	}
	if(_tcsnicmp(lpszMemFileName, "Global\\", 7) == 0)
	{
		strMemFileName = lpszMemFileName;
	}
	else
	{
		strGlobalName = "Global\\";
		strMemFileName = strGlobalName + lpszMemFileName;
	}
	return MF_OK;
}
//100036000
int CSystemManage::InitSysObject()
{
	BYTE bi;
	//初始化系统虚拟表
	LPOBJECTDEF lpObject;
	lpObject = new OBJECTDEF;
	lpObject->m_nDataID   = 0;
	lpObject->m_bFileNo   = 0;
	lpObject->m_nFieldNum = 0;
	lpObject->m_nObjectID = MF_SYS_OBJECTTYPE_DUAL;
	lpObject->m_bObjectType = MF_OBJECT_COMMON;
	_tcscpy(lpObject->m_lpszName, "DUAL");
	lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
	lpObject->m_lpField = NULL;
	m_mapObject.Set(lpObject->m_nObjectID, lpObject);
	m_mapName2Object.Set(lpObject->m_lpszName, lpObject);

	//统计视图表
	lpObject = new OBJECTDEF;
	lpObject->m_nDataID   = 0;
	lpObject->m_bObjectType = MF_OBJECT_COMMON;
	lpObject->m_bFileNo   = 0;
	lpObject->m_nFieldNum = 13;
	lpObject->m_nObjectID = MF_SYS_OBJECTTYPE_STATISTICS;
	_tcscpy(lpObject->m_lpszName, "V$STATISTICS");
	lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
	lpObject->m_lpField = new OBJECTFIELDDEF[lpObject->m_nFieldNum];
	memset(lpObject->m_lpField, 0, sizeof(OBJECTFIELDDEF) * lpObject->m_nFieldNum);
	lpObject->InitalMap();
	//SQL语句
	lpObject->m_lpField[0].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
	_tcscpy(lpObject->m_lpField[0].m_lpszName, "SQLTEXT");
	//执行次数
	lpObject->m_lpField[1].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[1].m_lpszName, "RUNCOUNT");
	//累计调用耗时
	lpObject->m_lpField[2].m_bFieldType      = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[2].m_lpszName, "RUNTIME");
	//累计准备耗时
	lpObject->m_lpField[3].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[3].m_lpszName, "PREPARETIME");
	//累计资源申请耗时
	lpObject->m_lpField[4].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[4].m_lpszName, "APPLYRESOURCETIME");
	//累计索引耗时
	lpObject->m_lpField[5].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[5].m_lpszName, "INDEXSEARCHTIME");
	//累计执行耗时
	lpObject->m_lpField[6].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[6].m_lpszName, "EXECUTETIME");
	//累计日志耗时
	lpObject->m_lpField[7].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[7].m_lpszName, "LOGTIME");
	//累计资源释放耗时
	lpObject->m_lpField[8].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[8].m_lpszName, "RELEASERESOURCETIME");
	//累计工作量
	lpObject->m_lpField[9].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[9].m_lpszName, "WORKLOAD");
	//SQL的HASH值
	lpObject->m_lpField[10].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[10].m_lpszName, "HASHID");
	//SQL操作的表名
	lpObject->m_lpField[11].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
	_tcscpy(lpObject->m_lpField[11].m_lpszName, "OBJECTNAME");
	//SQL首次执行时间
	lpObject->m_lpField[12].m_bFieldType     = MF_SYS_FIELDTYPE_DATE;
	_tcscpy(lpObject->m_lpField[12].m_lpszName, "FIRSTTIME");
	for(bi = 0;bi < lpObject->m_nFieldNum;bi++)
	{
		lpObject->m_lpField[bi].m_bAllowNull     = 1;
		lpObject->m_lpField[bi].m_bObjectFieldNo = bi+1;
		lpObject->m_mapName2FieldNo.Set(lpObject->m_lpField[bi].m_lpszName, (LPVOID)lpObject->m_lpField[bi].m_bObjectFieldNo);
	}
	m_mapObject.Set(lpObject->m_nObjectID, lpObject);
	m_mapName2Object.Set(lpObject->m_lpszName, lpObject);

	//会话视图
	lpObject = new OBJECTDEF;
	lpObject->m_nDataID   = 0;
	lpObject->m_bObjectType = MF_OBJECT_COMMON;
	lpObject->m_bFileNo   = 0;
	lpObject->m_nFieldNum = 20;
	lpObject->m_nObjectID = MF_SYS_OBJECTTYPE_SESSION;
	_tcscpy(lpObject->m_lpszName, "V$SESSION");
	lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
	lpObject->m_lpField = new OBJECTFIELDDEF[lpObject->m_nFieldNum];
	memset(lpObject->m_lpField, 0, sizeof(OBJECTFIELDDEF) * lpObject->m_nFieldNum);
	lpObject->InitalMap();
	//会话ID
	lpObject->m_lpField[0].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[0].m_lpszName, "SESSIONID");
	//登录用户名
	lpObject->m_lpField[1].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
	_tcscpy(lpObject->m_lpField[1].m_lpszName, "USER");
	//连接类型
	lpObject->m_lpField[2].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
	_tcscpy(lpObject->m_lpField[2].m_lpszName, "CONNECTTYPE");
	//机器IP
	lpObject->m_lpField[3].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
	_tcscpy(lpObject->m_lpField[3].m_lpszName, "MACHINEIP");
	//机器端口
	lpObject->m_lpField[4].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[4].m_lpszName, "MACHINEPORT");
	//状态
	lpObject->m_lpField[5].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[5].m_lpszName, "STATUS");
	//应用程序名
	lpObject->m_lpField[6].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
	_tcscpy(lpObject->m_lpField[6].m_lpszName, "PROGRAMNAME");
	//进程ID
	lpObject->m_lpField[7].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[7].m_lpszName, "PROCESSID");
	//线程ID
	lpObject->m_lpField[8].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[8].m_lpszName, "THREADID");
	//登录时间
	lpObject->m_lpField[9].m_bFieldType     = MF_SYS_FIELDTYPE_DATE;
	_tcscpy(lpObject->m_lpField[9].m_lpszName, "LOGONTIME");
	//最后调用时间
	lpObject->m_lpField[10].m_bFieldType     = MF_SYS_FIELDTYPE_DATE;
	_tcscpy(lpObject->m_lpField[10].m_lpszName, "LASTCALLTIME");
	//累计调用耗时
	lpObject->m_lpField[11].m_bFieldType      = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[11].m_lpszName, "TOTALTIME");
	//累计准备耗时
	lpObject->m_lpField[12].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[12].m_lpszName, "TOTALPREPARETIME");
	//累计资源申请耗时
	lpObject->m_lpField[13].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[13].m_lpszName, "TOTALAPPLYRESOURCETIME");
	//累计索引耗时
	lpObject->m_lpField[14].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[14].m_lpszName, "TOTALINDEXSEARCHTIME");
	//累计执行耗时
	lpObject->m_lpField[15].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[15].m_lpszName, "TOTALEXECUTETIME");
	//累计日志耗时
	lpObject->m_lpField[16].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[16].m_lpszName, "TOTALLOGTIME");
	//累计资源释放耗时
	lpObject->m_lpField[17].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[17].m_lpszName, "TOTALRELEASERESOURCETIME");
	//累计工作量
	lpObject->m_lpField[18].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[18].m_lpszName, "TOTALWORKLOAD");
	//累计调用次数
	lpObject->m_lpField[19].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[19].m_lpszName, "TOTALCALLCOUNT");
	for(bi = 0; bi < lpObject->m_nFieldNum; bi++)
	{
		lpObject->m_lpField[bi].m_bAllowNull     = 1;
		lpObject->m_lpField[bi].m_bObjectFieldNo = bi+1;
		lpObject->m_mapName2FieldNo.Set(lpObject->m_lpField[bi].m_lpszName, (LPVOID)lpObject->m_lpField[bi].m_bObjectFieldNo);
	}
	m_mapObject.Set(lpObject->m_nObjectID, lpObject);
	m_mapName2Object.Set(lpObject->m_lpszName, lpObject);

	//Soap服务视图
	lpObject = new OBJECTDEF;
	lpObject->m_bObjectType = MF_OBJECT_COMMON;
	lpObject->m_nDataID   = 0;
	lpObject->m_bFileNo   = 0;
	lpObject->m_nFieldNum = 15;
	lpObject->m_nObjectID = MF_SYS_OBJECTTYPE_SOAPSERVER;
	_tcscpy(lpObject->m_lpszName, "V$SOAPSERVER");
	lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
	lpObject->m_lpField = new OBJECTFIELDDEF[lpObject->m_nFieldNum];
	memset(lpObject->m_lpField, 0, sizeof(OBJECTFIELDDEF) * lpObject->m_nFieldNum);
	lpObject->InitalMap();
	//会话ID
	lpObject->m_lpField[0].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[0].m_lpszName, "SERVERID");
	//机器IP
	lpObject->m_lpField[1].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
	_tcscpy(lpObject->m_lpField[1].m_lpszName, "MACHINEIP");
	//机器端口
	lpObject->m_lpField[2].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[2].m_lpszName, "MACHINEPORT");
	//状态
	lpObject->m_lpField[3].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[3].m_lpszName, "STATUS");
	//登录时间
	lpObject->m_lpField[4].m_bFieldType     = MF_SYS_FIELDTYPE_DATE;
	_tcscpy(lpObject->m_lpField[4].m_lpszName, "LOGONTIME");
	//最后调用时间
	lpObject->m_lpField[5].m_bFieldType     = MF_SYS_FIELDTYPE_DATE;
	_tcscpy(lpObject->m_lpField[5].m_lpszName, "LASTCALLTIME");
	//累计调用耗时
	lpObject->m_lpField[6].m_bFieldType      = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[6].m_lpszName, "TOTALTIME");
	//累计准备耗时
	lpObject->m_lpField[7].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[7].m_lpszName, "TOTALPREPARETIME");
	//累计资源申请耗时
	lpObject->m_lpField[8].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[8].m_lpszName, "TOTALAPPLYRESOURCETIME");
	//累计索引耗时
	lpObject->m_lpField[9].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[9].m_lpszName, "TOTALINDEXSEARCHTIME");
	//累计执行耗时
	lpObject->m_lpField[10].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[10].m_lpszName, "TOTALEXECUTETIME");
	//累计日志耗时
	lpObject->m_lpField[11].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[11].m_lpszName, "TOTALLOGTIME");
	//累计资源释放耗时
	lpObject->m_lpField[12].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[12].m_lpszName, "TOTALRELEASERESOURCETIME");
	//累计工作量
	lpObject->m_lpField[13].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[13].m_lpszName, "TOTALWORKLOAD");
	//累计调用次数
	lpObject->m_lpField[14].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
	_tcscpy(lpObject->m_lpField[14].m_lpszName, "TOTALCALLCOUNT");
	for(bi = 0;bi < lpObject->m_nFieldNum;bi++)
	{
		lpObject->m_lpField[bi].m_bAllowNull     = 1;
		lpObject->m_lpField[bi].m_bObjectFieldNo = bi+1;
		lpObject->m_mapName2FieldNo.Set(lpObject->m_lpField[bi].m_lpszName, (LPVOID)lpObject->m_lpField[bi].m_bObjectFieldNo);
	}
	m_mapObject.Set(lpObject->m_nObjectID, lpObject);
	m_mapName2Object.Set(lpObject->m_lpszName, lpObject);

	//服务工作量视图
	lpObject = new OBJECTDEF;
	lpObject->m_bObjectType = MF_OBJECT_COMMON;
	lpObject->m_nDataID   = 0;
	lpObject->m_bFileNo   = 0;
	lpObject->m_nFieldNum = 7;
	lpObject->m_nObjectID = MF_SYS_OBJECTTYPE_WORKLOAD;
	_tcscpy(lpObject->m_lpszName, "V$WORKLOAD");
	lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
	lpObject->m_lpField = new OBJECTFIELDDEF[lpObject->m_nFieldNum];
	memset(lpObject->m_lpField, 0, sizeof(OBJECTFIELDDEF) * lpObject->m_nFieldNum);
	lpObject->InitalMap();
	//统计时间
	lpObject->m_lpField[0].m_bFieldType     = MF_SYS_FIELDTYPE_DATE;
	_tcscpy(lpObject->m_lpField[0].m_lpszName, "BEGINTIME");
	//统计时长
	lpObject->m_lpField[1].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[1].m_lpszName, "RUNTIME");
	//平均执行时长
	lpObject->m_lpField[2].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[2].m_lpszName, "EXECUTETIME");
	//最小执行时长
	lpObject->m_lpField[3].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[3].m_lpszName, "MINTIME");
	//最长执行时长
	lpObject->m_lpField[4].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[4].m_lpszName, "MAXTIME");
	//查询次数
	lpObject->m_lpField[5].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[5].m_lpszName, "QUERYCOUNT");
	//修改次数
	lpObject->m_lpField[6].m_bFieldType      = MF_SYS_FIELDTYPE_INT;
	_tcscpy(lpObject->m_lpField[6].m_lpszName, "UPDATECOUNT");
	for(bi = 0;bi < lpObject->m_nFieldNum;bi++)
	{
		lpObject->m_lpField[bi].m_bAllowNull     = 1;
		lpObject->m_lpField[bi].m_bObjectFieldNo = bi+1;
		lpObject->m_mapName2FieldNo.Set(lpObject->m_lpField[bi].m_lpszName, (LPVOID)lpObject->m_lpField[bi].m_bObjectFieldNo);
	}
	m_mapObject.Set(lpObject->m_nObjectID, lpObject);
	m_mapName2Object.Set(lpObject->m_lpszName, lpObject);

	return MF_OK;
}

//100037000
int CSystemManage::CopyExecuteStatistics(LPSQLEXECUTESTATISTICSINFO lpNode, LPEXECUTESTATISTICSINFO lpExecuteInfo, LPEXECUTEPLANBSON lpExecutePlan, BOOL bNew)
{
	if(bNew)
	{
		int nLen;
		lpNode->m_dwTotalExecuteCount		  = 1;
		lpNode->m_dwTotalTime				  = lpExecuteInfo->m_dwTime;
		lpNode->m_dwTotalWorkLoad			  = lpExecuteInfo->m_lWorkLoad;
		lpNode->m_dwTotalPrepareTime		  = 0;
		lpNode->m_dwTotalApplyResourceTime	  = 0;
		lpNode->m_dwTotalIndexSearchTime	  = 0;
		lpNode->m_dwTotalExecuteTime		  = 0;
		lpNode->m_dwTotalLogTime			  = 0;
		lpNode->m_dwTotalReleaseResourceTime  = 0;
		if(lpExecuteInfo->m_liPretreatmentStart.QuadPart > lpExecuteInfo->m_liStart.QuadPart && lpExecuteInfo->m_liStart.QuadPart != 0)
		{
			lpNode->m_dwTotalPrepareTime	= (DWORD)(1000000 * (lpExecuteInfo->m_liPretreatmentStart.QuadPart - lpExecuteInfo->m_liStart.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
		}
		if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_QUERY)
		{
			//查询方式计算耗时
			if(lpExecuteInfo->m_liIndexSearchEnd.QuadPart > lpExecuteInfo->m_liExecuteStart.QuadPart && lpExecuteInfo->m_liExecuteStart.QuadPart != 0)
			{
				lpNode->m_dwTotalIndexSearchTime	= (DWORD)(1000000 * (lpExecuteInfo->m_liIndexSearchEnd.QuadPart - lpExecuteInfo->m_liExecuteStart.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
			if(lpExecuteInfo->m_liExecuteEnd.QuadPart > lpExecuteInfo->m_liIndexSearchEnd.QuadPart && lpExecuteInfo->m_liIndexSearchEnd.QuadPart != 0)
			{
				lpNode->m_dwTotalExecuteTime		= (DWORD)(1000000 * (lpExecuteInfo->m_liExecuteEnd.QuadPart - lpExecuteInfo->m_liIndexSearchEnd.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
		}
		else
		{
			if(lpExecuteInfo->m_liExecuteStart.QuadPart > lpExecuteInfo->m_liPretreatmentStart.QuadPart && lpExecuteInfo->m_liPretreatmentStart.QuadPart != 0)
			{
				lpNode->m_dwTotalApplyResourceTime	= (DWORD)(1000000 * (lpExecuteInfo->m_liExecuteStart.QuadPart - lpExecuteInfo->m_liPretreatmentStart.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
			if(lpExecuteInfo->m_liExecuteEnd.QuadPart > lpExecuteInfo->m_liExecuteStart.QuadPart && lpExecuteInfo->m_liExecuteStart.QuadPart != 0)
			{
				lpNode->m_dwTotalExecuteTime		= (DWORD)(1000000 * (lpExecuteInfo->m_liExecuteEnd.QuadPart - lpExecuteInfo->m_liExecuteStart.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
			if(lpExecuteInfo->m_liWriteLogEnd.QuadPart > lpExecuteInfo->m_liExecuteEnd.QuadPart && lpExecuteInfo->m_liExecuteEnd.QuadPart != 0)
			{
				lpNode->m_dwTotalLogTime			= (DWORD)(1000000 * (lpExecuteInfo->m_liWriteLogEnd.QuadPart - lpExecuteInfo->m_liExecuteEnd.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
			if(lpExecuteInfo->m_liEnd.QuadPart > lpExecuteInfo->m_liWriteLogEnd.QuadPart && lpExecuteInfo->m_liWriteLogEnd.QuadPart != 0)
			{
				lpNode->m_dwTotalReleaseResourceTime= (DWORD)(1000000 * (lpExecuteInfo->m_liEnd.QuadPart - lpExecuteInfo->m_liWriteLogEnd.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
		}

		lpNode->m_dwTime			  = lpExecuteInfo->m_dwTime;
		lpNode->m_nObjectID			  = lpExecuteInfo->m_nObjectID;
		lpNode->m_dwHashID			  = lpExecuteInfo->m_dwHashID;
		lpNode->m_ftFirstTime		  = lpExecuteInfo->m_ftStartTime;
		nLen						  = lpExecutePlan->m_nSqlLen;
		lpNode->m_lpszSql			  = new char[nLen + 2];
		memcpy(lpNode->m_lpszSql, ((char *)lpExecutePlan) + lpExecutePlan->m_nSqlOffset, nLen);
		lpNode->m_lpszSql[nLen]		  = 0;
	}
	else
	{
		//相同的SQL语句，处理数据叠加
		lpNode->m_dwTotalExecuteCount++;
		lpNode->m_dwTotalTime		 += lpExecuteInfo->m_dwTime;
		lpNode->m_dwTotalWorkLoad	 += lpExecuteInfo->m_lWorkLoad;
		if(lpExecuteInfo->m_dwTime > lpNode->m_dwTime)
		{
			lpNode->m_dwTime		  = lpExecuteInfo->m_dwTime;
		}
		if(lpExecuteInfo->m_liPretreatmentStart.QuadPart > lpExecuteInfo->m_liStart.QuadPart && lpExecuteInfo->m_liStart.QuadPart != 0)
		{
			lpNode->m_dwTotalPrepareTime	+= (DWORD)(1000000 * (lpExecuteInfo->m_liPretreatmentStart.QuadPart - lpExecuteInfo->m_liStart.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
		}
		if(lpExecutePlan->m_nType == MF_EXECUTEPLAN_CMDTYPE_QUERY)
		{
			//查询方式计算耗时
			if(lpExecuteInfo->m_liIndexSearchEnd.QuadPart > lpExecuteInfo->m_liExecuteStart.QuadPart && lpExecuteInfo->m_liExecuteStart.QuadPart != 0)
			{
				lpNode->m_dwTotalIndexSearchTime	+= (DWORD)(1000000 * (lpExecuteInfo->m_liIndexSearchEnd.QuadPart - lpExecuteInfo->m_liExecuteStart.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
			if(lpExecuteInfo->m_liExecuteEnd.QuadPart > lpExecuteInfo->m_liIndexSearchEnd.QuadPart && lpExecuteInfo->m_liIndexSearchEnd.QuadPart != 0)
			{
				lpNode->m_dwTotalExecuteTime		+= (DWORD)(1000000 * (lpExecuteInfo->m_liExecuteEnd.QuadPart - lpExecuteInfo->m_liIndexSearchEnd.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
		}
		else
		{
			if(lpExecuteInfo->m_liExecuteStart.QuadPart > lpExecuteInfo->m_liPretreatmentStart.QuadPart && lpExecuteInfo->m_liPretreatmentStart.QuadPart != 0)
			{
				lpNode->m_dwTotalApplyResourceTime	+= (DWORD)(1000000 * (lpExecuteInfo->m_liExecuteStart.QuadPart - lpExecuteInfo->m_liPretreatmentStart.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
			if(lpExecuteInfo->m_liExecuteEnd.QuadPart > lpExecuteInfo->m_liExecuteStart.QuadPart && lpExecuteInfo->m_liExecuteStart.QuadPart != 0)
			{
				lpNode->m_dwTotalExecuteTime		+= (DWORD)(1000000 * (lpExecuteInfo->m_liExecuteEnd.QuadPart - lpExecuteInfo->m_liExecuteStart.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
			if(lpExecuteInfo->m_liWriteLogEnd.QuadPart > lpExecuteInfo->m_liExecuteEnd.QuadPart && lpExecuteInfo->m_liExecuteEnd.QuadPart != 0)
			{
				lpNode->m_dwTotalLogTime			+= (DWORD)(1000000 * (lpExecuteInfo->m_liWriteLogEnd.QuadPart - lpExecuteInfo->m_liExecuteEnd.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
			if(lpExecuteInfo->m_liEnd.QuadPart > lpExecuteInfo->m_liWriteLogEnd.QuadPart && lpExecuteInfo->m_liWriteLogEnd.QuadPart != 0)
			{
				lpNode->m_dwTotalReleaseResourceTime+= (DWORD)(1000000 * (lpExecuteInfo->m_liEnd.QuadPart - lpExecuteInfo->m_liWriteLogEnd.QuadPart) / lpExecuteInfo->m_liFrequence.QuadPart );
			}
		}
	}
	return MF_OK;
}

//100038000
int CSystemManage::SetExecuteStatistics(LPEXECUTESTATISTICSINFO lpExecuteInfo, LPEXECUTEPLANBSON lpExecutePlan)
{
	//对于速度实在是太快的，也就没必要进入后面的判断了（小于5000微秒的，属于我们认可的速度范围内）。
	if(lpExecuteInfo->m_dwTime < (DWORD)m_pMemoryFileHead->m_nServerExecuteTimeMonitor)
	{
		return MF_OK;
	}
	else
	{
		int i;
		LPSQLEXECUTESTATISTICSINFO lpNode, lpExecuteData;
		CExecutePlanCriticalPtr cs(&m_critStatistics, lpExecutePlan);

		lpNode = NULL;
		lpExecuteData = NULL;
		lpExecuteInfo->m_nObjectID = lpExecutePlan->m_nObjectID;
		lpExecuteInfo->m_dwHashID  = lpExecutePlan->m_dwHashID;
		try
		{
			//首先判断SQL语句是否重复
			for(i = 0, lpNode = m_pExecuteStatistics;i < 1001;i++,lpNode = lpNode->m_pNext)
			{
				//空指针就直接退出
				if(lpNode == NULL)
				{
					break;
				}

				//判断是否相同的SQL语句
				if(lpNode->m_dwHashID == lpExecuteInfo->m_dwHashID)
				{
					if(lpNode->m_nObjectID == lpExecuteInfo->m_nObjectID)
					{
						if(strcmp(lpNode->m_lpszSql, ((char *)lpExecutePlan) + lpExecutePlan->m_nSqlOffset) == 0)
						{
							CopyExecuteStatistics(lpNode, lpExecuteInfo, lpExecutePlan, FALSE);
							return MF_OK;
						}
					}
				}
			}

			if(i >= 1000 && lpNode != NULL)
			{
				//删除后面的数据
				while(lpNode->m_pNext != NULL)
				{
					lpExecuteData = lpNode->m_pNext;
					lpNode->m_pNext = lpExecuteData->m_pNext;
					delete [] lpExecuteData->m_lpszSql;
					delete lpExecuteData;
				}
			}

			if(m_pExecuteStatistics == NULL || m_pExecuteStatistics->m_dwTime < lpExecuteInfo->m_dwTime)
			{
				lpExecuteData = new SQLEXECUTESTATISTICSINFO;
				CopyExecuteStatistics(lpExecuteData, lpExecuteInfo, lpExecutePlan, TRUE);
				lpExecuteData->m_pNext = m_pExecuteStatistics;
				m_pExecuteStatistics = lpExecuteData;
			}
			else
			{
				for(i = 0, lpNode = m_pExecuteStatistics;i < 1001;i++,lpNode = lpNode->m_pNext)
				{
					if(lpNode->m_pNext == NULL)
						break;
					if(lpNode->m_pNext->m_dwTime < lpExecuteInfo->m_dwTime)
					{
						break;
					}
				}

				if(lpNode != NULL)
				{
					lpExecuteData		   = new SQLEXECUTESTATISTICSINFO;
					CopyExecuteStatistics(lpExecuteData, lpExecuteInfo, lpExecutePlan, TRUE);
					lpExecuteData->m_pNext = lpNode->m_pNext;
					lpNode->m_pNext		   = lpExecuteData;
				}
			}
		}
		catch(...)
		{
			Trace("CSystemManage::SetExecuteStatistics", MF_TRACE_LEVEL_FAILED, 100038001, "处理性能统计时出现异常，错误码：%d", GetLastError());
		}
	}
	return MF_OK;
}

//数据修改类日志，可用于数据重演
//错误代码100029001～100029999
void CSystemManage::WriteLogBuffer(LPBYTE lpData, int &nPos, int nLen)
{ 
	int nReadPos, nWritePos, nWriteLen;
	nReadPos  = m_pLogFileHead->m_nReadPos;
	nWritePos = m_pLogFileHead->m_nWritePos;

	//把数据写入到共享内存区域
	if(m_pLogFileHead->m_nWritePos < nReadPos)
	{
		if(nLen - nPos < nReadPos - nWritePos)
		{
			//从写入点到内存保护点空间大于需要写入的长度时，就直接写入
			memcpy(m_pLogFileAddr + nWritePos, lpData + nPos, nLen - nPos);
			nWritePos += nLen - nPos;
			nPos	   = nLen;
		}
		else
		{
			//只写入本次需要写入的数据
			nWriteLen = nReadPos - nWritePos - 1;
			memcpy(m_pLogFileAddr + nWritePos, lpData + nPos, nWriteLen);
			nWritePos += nWriteLen;
			nPos	  += nWriteLen;
			m_pLogFileHead->m_bWriteFinishFlag = 1;
		}

		m_pLogFileHead->m_nWritePos = nWritePos;
		if(nPos	>= nLen)
		{
			m_pLogFileHead->m_bWriteFinishFlag = 0;
		}
		else
		{
			m_pLogFileHead->m_bWriteFinishFlag = 1;
		}
		if(nReadPos - nWritePos < MF_TRACE_FILE_WORNING_SIZE)
		{
			//提醒另外一个服务立即写日志
			SetEvent(m_hLogEvent);
		}
	}
	else
	{
		if (nReadPos == m_pLogFileHead->m_nFileHeaderSize)		//nReadPos在缓存第一位时，缓存的最后一位不允许写入
		{
			if(nLen - nPos <= MF_TRACE_FILE_SIZE - nWritePos - 1)
			{
				//从写入点到结束位置大于需要写入的长度时，就直接写入
				nWriteLen = nLen - nPos;
			}
			else
			{
				nWriteLen = MF_TRACE_FILE_SIZE - nWritePos - 1;
			}
			memcpy(m_pLogFileAddr + nWritePos, lpData + nPos, nWriteLen);
			nWritePos += nWriteLen;
			nPos	  += nWriteLen;
		} 
		else
		{
			if(nLen - nPos <= MF_TRACE_FILE_SIZE - nWritePos)
			{
				//从写入点到结束位置大于需要写入的长度时，就直接写入
				memcpy(m_pLogFileAddr + nWritePos, lpData + nPos, nLen - nPos);	
				nWritePos += nLen - nPos;
				if(nWritePos >= MF_TRACE_FILE_SIZE)
				{
					nWritePos = m_pLogFileHead->m_nFileHeaderSize;
				}
				nPos	   = nLen;
			}
			else
			{
				//只写入本次需要写入填充最后面的一部分数据
				nWriteLen = MF_TRACE_FILE_SIZE - nWritePos;
				memcpy(m_pLogFileAddr + nWritePos, lpData + nPos, nWriteLen);
				nWritePos  = m_pLogFileHead->m_nFileHeaderSize;
				nPos	  += nWriteLen;

				//再重新计算还能写入多少数据
				if(nLen - nPos < nReadPos - nWritePos)
				{
					//从写入点到内存保护点空间大于需要写入的长度时，就直接写入
					memcpy(m_pLogFileAddr + nWritePos, lpData + nPos, nLen - nPos);
					nWritePos += nLen - nPos;
					nPos	   = nLen;
				}
				else
				{
					//只写入本次需要写入的数据
					nWriteLen = nReadPos - nWritePos - 1;
					memcpy(m_pLogFileAddr + nWritePos, lpData + nPos, nWriteLen);
					nWritePos += nWriteLen;
					nPos	  += nWriteLen;
					m_pLogFileHead->m_bWriteFinishFlag = 1;
				}
			}
		}
		

		m_pLogFileHead->m_nWritePos = nWritePos;
		if(nPos	>= nLen)
		{
			m_pLogFileHead->m_bWriteFinishFlag = 0;
		}
		else
		{
			m_pLogFileHead->m_bWriteFinishFlag = 1;
		}
		if((nWritePos < nReadPos && nReadPos - nWritePos < MF_TRACE_FILE_WORNING_SIZE) || (nWritePos > nReadPos  && nWritePos - nReadPos > MF_TRACE_FILE_WORNING_SIZEEX))
		{
			//提醒另外一个服务立即写日志
			SetEvent(m_hTraceEvent);
		}
	}
}

BOOL CSystemManage::WriteLog(CServiceBson& stBson, CExecutePlanManager& stExecuteManager)
{
	LPBYTE lpBuffer;
	int i, nSectionNum;
	LPEXECUTEPLANBSON lpExecutePlan;
	UINT nDefaultBufferSize, nBufferSize;

	lpExecutePlan = stExecuteManager.GetExecutePlan();
	CExecutePlanCriticalPtr cs(&m_critLog, lpExecutePlan);

	nDefaultBufferSize = lpExecutePlan->m_nDefaultSectionSize;

	//写Bson缓存
	lpBuffer	= (LPBYTE)lpExecutePlan;
	nBufferSize = lpExecutePlan->m_nBsonDataSize;
	if(!ExecuteWrite(lpBuffer, nBufferSize))
	{
		return FALSE;
	}

	nSectionNum = stBson.GetBufferSectionNum();
	for(i = lpExecutePlan->m_nClientSectionNum + 1; i <= nSectionNum; i++)
	{
		lpBuffer = stBson.GetBufferSection(i);
		if(i == nSectionNum)
		{
			if(!ExecuteWrite(lpBuffer, stBson.GetCurretDataSize()))
			{
				return FALSE;
			}
		}
		else
		{
			if(!ExecuteWrite(lpBuffer, nDefaultBufferSize))
			{
				return FALSE;
			}
		}
	}

	return TRUE;
}

BOOL CSystemManage::ExecuteWrite(LPBYTE lpData, int nLen)
{
	int i, nPos;
	if(m_pLogFileHead == NULL)
	{
		//写日志失败
		Trace0("CSystemManage::WriteLog", MF_TRACE_LEVEL_FAILED, 100039001, "重做日志内存指针为空，无法写入重做日志！");
		return FALSE;
	}
	else
	{
		for(nPos = 0, i = 0; nPos < nLen;i++)
		{
			WriteLogBuffer(lpData, nPos, nLen);
			if(nPos < nLen)
			{
				if(i % 200 == 15)
				{
					Trace("CSystemManage::WriteLog", MF_TRACE_LEVEL_FAILED, 100039002, "写入重做日志太慢，日志大小：%d，已写入：%d，尝试次数：%d！", nLen, nPos, i);
				}
				Sleep(10);
			}
		}
	}
	return TRUE;
}

//重做日志备份，用于集群同步时暂存重做日志
BOOL CSystemManage::WriteBackupRedo(CServiceBson& stBson, CExecutePlanManager& stExecuteManager)
{
	LPBYTE lpBuffer;
	int i, nSectionNum;
	LPEXECUTEPLANBSON lpExecutePlan;
	UINT nDefaultBufferSize, nBufferSize;

	lpExecutePlan = stExecuteManager.GetExecutePlan();
	CExecutePlanCriticalPtr cs(&m_critLog, lpExecutePlan);

	nDefaultBufferSize = lpExecutePlan->m_nDefaultSectionSize;

	//写Bson缓存
	lpBuffer	= (LPBYTE)lpExecutePlan;
	nBufferSize = lpExecutePlan->m_nBsonDataSize;
	if(!WriteBackupRedo(lpBuffer, nBufferSize))
	{
		return FALSE;
	}

	nSectionNum = stBson.GetBufferSectionNum();
	for(i = lpExecutePlan->m_nClientSectionNum + 1; i <= nSectionNum; i++)
	{
		lpBuffer = stBson.GetBufferSection(i);
		if(i == nSectionNum)
		{
			if(!WriteBackupRedo(lpBuffer, stBson.GetCurretDataSize()))
			{
				return FALSE;
			}
		}
		else
		{
			if(!WriteBackupRedo(lpBuffer, nDefaultBufferSize))
			{
				return FALSE;
			}
		}
	}
	return TRUE;
}

BOOL CSystemManage::WriteBackupRedo(LPBYTE lpData, int nLen)
{
	if (NULL == m_pBackupRedoFile)
	{
		return FALSE;
	}
	if (nLen != fwrite(lpData, 1, nLen, m_pBackupRedoFile))
	{
		return FALSE;
	}
	fflush(m_pBackupRedoFile);
	return TRUE;
}

BOOL CSystemManage::InitBackupRedo(const char* lpFilePath)
{
	if (NULL != m_pBackupRedoFile)
	{
		fclose(m_pBackupRedoFile);
		m_pBackupRedoFile = NULL;
	}
	m_pBackupRedoFile = fopen(lpFilePath, "wb+");
	if (NULL == m_pBackupRedoFile)
	{
		Trace("CSystemManage::InitBackupRedo", MF_TRACE_LEVEL_FAILED, 100038083, "创建临时重做日志文件失败，文件路径：%s，错误码：%d", lpFilePath, GetLastError());
		return FALSE;
	}

	MF_REDOLOGFILEHEAD stRedoLogFileHead;
	memset(&stRedoLogFileHead, 0, sizeof(MF_REDOLOGFILEHEAD));
	stRedoLogFileHead.m_usDatabaseGuid = GetDatabaseGuid();
	stRedoLogFileHead.m_nSequenceNO = 0;
	strcpy(stRedoLogFileHead.m_lpszFileFlag, "VernoxLog");
	stRedoLogFileHead.m_nVersion	= 1;
	GetSystemTimeAsFileTime(&stRedoLogFileHead.m_ftCreateTime);
	//写入文件标识头
	if (sizeof(stRedoLogFileHead) != fwrite(&stRedoLogFileHead, 1, sizeof(stRedoLogFileHead), m_pBackupRedoFile))
	{
		return FALSE;
	}
	fflush(m_pBackupRedoFile);
	return TRUE;
}

int CSystemManage::SortObjectIndex(LPOBJECTDEF lpObject)
{
	int i,j,nCount;
	LPINDEXDEF lpNode;
	LPINDEXDEF pIndexArray[256], lpIndex;//最多支持256个索引，理论上不可能这么多，系统已经慢的像蜗牛了
	if(lpObject->m_lpIndex == NULL)
	{
		//没有索引就直接返回
		return MF_OK;
	}
	memset(pIndexArray, 0, sizeof(pIndexArray));
	for(i = 0,lpNode = lpObject->m_lpIndex;lpNode != NULL;lpNode = lpNode->m_pNext)
	{
		if(lpNode != NULL)
		{
			pIndexArray[i] = lpNode;
			i++;
		}
	}
	nCount = i;
	//索引排序，目前暂时按照类型进行排序
	for(i = 0;i < nCount;i++)
	{
		for(j = i + 1;j < nCount;j++)
		{
			if(pIndexArray[j]->m_bIndexType < pIndexArray[i]->m_bIndexType)
			{
				lpIndex			= pIndexArray[i];
				pIndexArray[i]	= pIndexArray[j];
				pIndexArray[j]	= lpIndex;
			}
		}
	}

	//再把索引挂到对象的链表中
	for(i = 0;i < nCount-1; i++)
	{
		pIndexArray[i]->m_pNext = pIndexArray[i+1];
	}
	//链表尾部索引的Next指针至为空
	pIndexArray[i]->m_pNext = NULL;
	lpObject->m_lpIndex = pIndexArray[0];
	return MF_OK;
}

int CSystemManage::GetDualData(CServiceBson& stBson, CSysRecordContainer& stRecordContainer)
{
	stRecordContainer.resize(1);
	return MF_OK;
}

int CSystemManage::GetVObjectData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer)
{
	BOOL bValid;
	Check stCheck;
	LPVOID lpPos, lpValue;
	int nRet, nKey, nRowNum;
	LPMEMDBFILEDEF lpFileInfo;
	LPEXECUTEPLANBSON lpExecutePlan;
	LPBASECONDITIONBSON lpCondition;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	LPSINGLERECORD lpDataArray, lpDataArray2;
	LPOBJECTDEF lpSysObjectInfo, lpObjectInfo;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpQueryPlan		= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	
	//获取V$OBJECT表的相关信息
	nRet = GetObjectInfo("V$OBJECT", lpSysObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//获取查询条件
	lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	if(lpCommonCondition->m_nWhereOffset != 0)
	{
		lpCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);
	}
	else
	{
		lpCondition = NULL;
	}
	stCheck.Initial(&stBson, NULL);

	nRowNum		 = 0;
	lpDataArray  = NULL;
	lpDataArray2 = NULL;
	//获取V$OBJECT表的所有数据, 遍历m_mapObject获取所需信息
	nKey  = 0;
	lpPos = m_mapObject.GetHeadPosition();
	while(lpPos != NULL)
	{
		m_mapObject.GetNext(lpPos, nKey, lpValue);
		if(lpValue != NULL)
		{
			lpObjectInfo = (LPOBJECTDEF)lpValue;
		}
		else
		{
			continue;
		}
		if(MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM == lpObjectInfo->m_bImplementClass)
		{
			continue;
		}	

		if(lpDataArray2 == NULL)
		{
			//防止重复分配不合法的数据
			nRet = stRecordContainer.AllocSingleRecord(lpDataArray, lpSysObjectInfo->m_nFieldNum);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpDataArray2 = lpDataArray;
		}
		else
		{
			lpDataArray = lpDataArray2;
		}

		lpDataArray->m_lpRecordData[0].SetData(lpObjectInfo->m_nDataID);
		lpDataArray->m_lpRecordData[1].SetData(lpObjectInfo->m_nObjectID);
		lpDataArray->m_lpRecordData[2].SetData(lpObjectInfo->m_lpszName, strlen(lpObjectInfo->m_lpszName)+1);		
		lpDataArray->m_lpRecordData[3].SetData(lpObjectInfo->m_nBlockSize);
		lpDataArray->m_lpRecordData[4].SetData((int)lpObjectInfo->m_bFileNo);
		lpDataArray->m_lpRecordData[5].SetData((int)lpObjectInfo->m_nFieldNum);
		lpDataArray->m_lpRecordData[6].SetData((int)lpObjectInfo->m_bImplementClass);
		
		lpFileInfo = m_arMemDBFile[lpObjectInfo->m_bFileNo];
		if(lpFileInfo != NULL)
		{
			lpDataArray->m_lpRecordData[7].SetData(lpFileInfo->m_lpszMemFileName+7, strlen(lpFileInfo->m_lpszMemFileName)+1-7);
			if(lpFileInfo->m_bFileType == 1)
			{
				lpDataArray->m_lpRecordData[8].SetData("SYSTEMFILE",11);
			}
			else if(lpFileInfo->m_bFileType == 2)
			{
				lpDataArray->m_lpRecordData[8].SetData("DATAFILE",9);
			}
			else if(lpFileInfo->m_bFileType == 3)
			{
				lpDataArray->m_lpRecordData[8].SetData("TREEFILE",9);
			}
			else if(lpFileInfo->m_bFileType == 4)
			{
				lpDataArray->m_lpRecordData[8].SetData("KVFILE",7);
			}
		}

		//判断系统表中的记录是否符合查询条件
		nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(bValid)
		{
			if(nRowNum < lpQueryPlan->m_nPageSize)
			{
				nRowNum++;
				lpDataArray->m_bValid = 1;
				lpDataArray2		  = NULL;
			}
			else
			{
				break;
			}
		}
	}
	return MF_OK;
}

int CSystemManage::GetVIndexData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer)
{
	BOOL bValid;
	BYTE bFieldNo;
	Check stCheck;
	char* lpszBuffer;
	string strFieldName;
	LPVOID lpPos, lpValue;
	LPINDEXDEF lpIndexInfo;
	LPOBJECTDEF lpObjectInfo;
	LPMEMDBFILEDEF lpFileInfo;
	LPOBJECTDEF lpIndexObjectInfo;
	LPBASECONDITIONBSON lpCondition;
	LPEXECUTEPLANBSON lpExecutePlan;
	int nRet, i, nKey, nLen, nRowNum;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	LPSINGLERECORD lpDataArray, lpDataArray2;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpQueryPlan		= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);

	//获取V$INDEX表的相关信息
	nRet = GetObjectInfo("V$INDEX", lpIndexObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//获取查询条件
	lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	if(lpCommonCondition->m_nWhereOffset != 0)
	{
		lpCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);
	}
	else
	{
		lpCondition = NULL;
	}
	stCheck.Initial(&stBson, NULL);

	nRowNum		 = 0;
	lpDataArray  = NULL;
	lpDataArray2 = NULL;
	//获取V$INDEX表的所有数据, 遍历m_mapIndex获取所需信息
	lpIndexInfo = NULL;
	nKey		= 0;
	lpPos       = m_mapIndex.GetHeadPosition();
	while(lpPos)
	{
		m_mapIndex.GetNext(lpPos, nKey, lpValue);
		if(lpValue != NULL)
		{
			lpIndexInfo = (LPINDEXDEF)lpValue;
		}
		else
		{
			continue;
		}

		lpObjectInfo = NULL;
		nRet = GetObjectInfo(lpIndexInfo->m_nObjectID , lpObjectInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpDataArray2 == NULL)
		{
			nRet = stRecordContainer.AllocSingleRecord(lpDataArray, lpIndexObjectInfo->m_nFieldNum);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpDataArray2 = lpDataArray;
		}
		else
		{	
			lpDataArray = lpDataArray2;
		}
		lpDataArray->m_lpRecordData[0].SetData(lpIndexInfo->m_nDataID);
		if(lpObjectInfo != NULL)
		{
			lpDataArray->m_lpRecordData[1].SetData(lpObjectInfo->m_lpszName, strlen(lpObjectInfo->m_lpszName)+1);
		}
		else
		{
			lpDataArray->m_lpRecordData[1].SetData("", 1);
		}
		lpDataArray->m_lpRecordData[2].SetData(lpIndexInfo->m_lpszName, strlen(lpIndexInfo->m_lpszName)+1);		
		//建立字段名
		for(i = 0; i < 4; i++)
		{
			bFieldNo = lpIndexInfo->m_bFieldNo[i];
			if(bFieldNo == 0)
			{
				break;
			}
			else
			{
				if(i == 0)
				{
					strFieldName = lpObjectInfo->m_lpField[bFieldNo-1].m_lpszName;
				}
				else
				{
					strFieldName += ",";
					strFieldName += lpObjectInfo->m_lpField[bFieldNo-1].m_lpszName;
				}
			}
		}
		nLen = strFieldName.length()+1;
		lpszBuffer = new char[nLen];
		memcpy(lpszBuffer, strFieldName.c_str(), nLen);
		lpDataArray->m_lpRecordData[3].AttachBuffer(MF_VARDATA_STRING, lpszBuffer, nLen);
		//获取索引类型
		if(lpIndexInfo->m_bConstraintType == MF_CONSTRAINT_PRIMARYKEY)
		{
			lpDataArray->m_lpRecordData[4].SetData("PrimaryKey", 11);
		}
		else if(lpIndexInfo->m_bConstraintType == MF_CONSTRAINT_UNIQUE)
		{
			lpDataArray->m_lpRecordData[4].SetData("Unique", 7);
		}
		else
		{
			lpDataArray->m_lpRecordData[4].SetData("Common", 7);
		}
		if(lpIndexInfo->m_bIndexType <= 10)
		{
			lpDataArray->m_lpRecordData[5].SetData("KV", 3);
		}
		else
		{
			lpDataArray->m_lpRecordData[5].SetData("BTREE", 5);
		}
		lpDataArray->m_lpRecordData[6].SetData(lpIndexInfo->m_nBlockSize);
		
		lpFileInfo = m_arMemDBFile[lpIndexInfo->m_bFileNo];
		if(lpFileInfo != NULL)
		{
			lpDataArray->m_lpRecordData[7].SetData(lpFileInfo->m_lpszMemFileName+7, strlen(lpFileInfo->m_lpszMemFileName)+1-7);
			if(lpFileInfo->m_bFileType == 1)
			{
				lpDataArray->m_lpRecordData[8].SetData("SYSTEMFILE",11);
			}
			else if(lpFileInfo->m_bFileType == 2)
			{
				lpDataArray->m_lpRecordData[8].SetData("DATAFILE",9);
			}
			else if(lpFileInfo->m_bFileType == 3)
			{
				lpDataArray->m_lpRecordData[8].SetData("TREEFILE",9);
			}
			else if(lpFileInfo->m_bFileType == 4)
			{
				lpDataArray->m_lpRecordData[8].SetData("KVFILE",7);
			}
		}

		//判断系统表中的记录是否符合查询条件
		nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(bValid)
		{
			if(nRowNum < lpQueryPlan->m_nPageSize)
			{
				nRowNum++;
				lpDataArray->m_bValid = 1;
				lpDataArray2		  = NULL;
			}
			else
			{
				break;
			}
		}
	}
	return MF_OK;
}

int CSystemManage::GetVColumnData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer)
{
	BOOL bValid;
	Check stCheck;
	LPVOID lpPos, lpValue;
	LPOBJECTDEF lpObjectInfo;
	LPOBJECTDEF lpColumnObjectInfo;
	int nRet, nKey, i, nID, nRowNum;
	LPBASECONDITIONBSON lpCondition;	
	LPEXECUTEPLANBSON lpExecutePlan;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	LPSINGLERECORD lpDataArray, lpDataArray2;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpQueryPlan		= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);

	//获取V$COLUMN表的相关信息
	lpColumnObjectInfo = NULL;
	nRet = GetObjectInfo("V$COLUMN", lpColumnObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//获取查询条件
	lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	if(lpCommonCondition->m_nWhereOffset != 0)
	{
		lpCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);
	}
	else
	{
		lpCondition = NULL;
	}
	stCheck.Initial(&stBson, NULL);
	
	nRowNum		 = 0;
	lpDataArray  = NULL;
	lpDataArray2 = NULL;
	//获取V$COLUMN表的所有数据, 遍历m_mapObject获取所需信息
	lpObjectInfo = NULL;
	nKey		 = 0;
	lpPos		 = m_mapObject.GetHeadPosition();
	while(lpPos != NULL)
	{
		m_mapObject.GetNext(lpPos, nID, lpValue);
		if(lpValue != NULL)
		{
			lpObjectInfo = (LPOBJECTDEF)lpValue;
		}
		else
		{
			continue;
		}
		if(MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM == lpObjectInfo->m_bImplementClass)
		{
			continue;
		}
		for(i = 0; i < lpObjectInfo->m_nFieldNum; i++)
		{
			if(lpObjectInfo->m_lpField[i].m_bObjectFieldNo == 0)
			{
				continue;
			}
			if(lpDataArray2 == NULL)
			{
				nRet = stRecordContainer.AllocSingleRecord(lpDataArray, lpColumnObjectInfo->m_nFieldNum);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpDataArray2 = lpDataArray;
			}
			else
			{
				lpDataArray = lpDataArray2;
			}

			//对象名
			lpDataArray->m_lpRecordData[0].SetData(lpObjectInfo->m_lpszName, strlen(lpObjectInfo->m_lpszName)+1);
			//列名
			lpDataArray->m_lpRecordData[1].SetData(lpObjectInfo->m_lpField[i].m_lpszName, strlen(lpObjectInfo->m_lpField[i].m_lpszName)+1);
			//列类型和长度
			switch(lpObjectInfo->m_lpField[i].m_bFieldType)
			{
			case MF_SYS_FIELDTYPE_INT:
				lpDataArray->m_lpRecordData[2].SetData("INT", 4);		
				lpDataArray->m_lpRecordData[3].SetData((int)sizeof(int));
				break;
			case MF_SYS_FIELDTYPE_BIGINT:
				lpDataArray->m_lpRecordData[2].SetData("BIGINT", 7);		
				lpDataArray->m_lpRecordData[3].SetData((int)sizeof(long long));
				break;
			case MF_SYS_FIELDTYPE_DOUBLE:
				lpDataArray->m_lpRecordData[2].SetData("DOUBLE", 7);		
				lpDataArray->m_lpRecordData[3].SetData((int)sizeof(double));
				break;
			case MF_SYS_FIELDTYPE_DATE:
				lpDataArray->m_lpRecordData[2].SetData("DATE", 5);		
				lpDataArray->m_lpRecordData[3].SetData((int)sizeof(DATE));
				break;
			case MF_SYS_FIELDTYPE_CHAR:
				lpDataArray->m_lpRecordData[2].SetData("CHAR", 5);		
				lpDataArray->m_lpRecordData[3].SetData((int)lpObjectInfo->m_lpField[i].m_bCharLen);
				break;
			case MF_SYS_FIELDTYPE_VARCHAR:
				lpDataArray->m_lpRecordData[2].SetData("VARCHAR", 8);		
				lpDataArray->m_lpRecordData[3].SetData(255);
				break;
			case MF_SYS_FIELDTYPE_CLOB:
				lpDataArray->m_lpRecordData[2].SetData("CLOB", 5);		
				lpDataArray->m_lpRecordData[3].SetData(255);
				break;
			case MF_SYS_FIELDTYPE_BLOB:
				lpDataArray->m_lpRecordData[2].SetData("BLOB", 5);		
				lpDataArray->m_lpRecordData[3].SetData(255);
				break;		
			}
			if(lpObjectInfo->m_lpField[i].m_bAllowNull)
			{
				lpDataArray->m_lpRecordData[4].SetData("NO", 3);	
			}
			else
			{
				lpDataArray->m_lpRecordData[4].SetData("YES", 4);
			}

			//判断系统表中的记录是否符合查询条件
			nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(bValid)
			{
				if(nRowNum < lpQueryPlan->m_nPageSize)
				{
					nRowNum++;
					lpDataArray->m_bValid = 1;
					lpDataArray2		  = NULL;
				}
				else
				{
					break;
				}
			}
		}
	}
	return MF_OK;
}

int CSystemManage::GetVSequenceData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer)
{
	char* pName;
	BOOL bValid;
	Check stCheck;
	LPVOID lpPos, lpValue;
	int nOffset, nRet, nRowNum;
	LPSEQUENCEDEF lpSequenceInfo;
	LPBASECONDITIONBSON lpCondition;	
	LPEXECUTEPLANBSON lpExecutePlan;
	LPOBJECTDEF lpSequenceObjectInfo;
	LPFILE_SEQUENCEDEF lpFileSequence;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPSINGLERECORD lpDataArray, lpDataArray2;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpQueryPlan	= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);

	//获取V$SEQUENCE表的相关信息
	nRet = GetObjectInfo("V$SEQUENCE", lpSequenceObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//获取查询条件
	lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	if(lpCommonCondition->m_nWhereOffset != 0)
	{
		lpCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);
	}
	else
	{
		lpCondition = NULL;
	}
	stCheck.Initial(&stBson, NULL);
	
	nRowNum		  = 0;
	lpDataArray   = NULL;
	lpDataArray2  = NULL;
	//获取V$SEQUENCE表的所有数据, 遍历m_mapSequence获取所需信息
	lpPos = m_mapSequence.GetHeadPosition();
	while(lpPos)
	{
		nOffset			= 0;
		lpFileSequence	= NULL;
		m_mapSequence.GetNext(lpPos, pName, lpValue);
		if(lpValue != NULL)
		{
			lpSequenceInfo	= (LPSEQUENCEDEF)lpValue;
		}
		else
		{
			continue;
		}
		nRet = ConvertDataID2Offset(lpSequenceInfo->m_nDataID, nOffset, lpSystemBlockHead);
		if(nRet == MF_OK)
		{
			lpFileSequence = (LPFILE_SEQUENCEDEF)(((LPBYTE)lpSystemBlockHead) + nOffset);
		}

		if(lpDataArray2 == NULL)
		{
			nRet = stRecordContainer.AllocSingleRecord(lpDataArray, lpSequenceObjectInfo->m_nFieldNum);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpDataArray2 = lpDataArray;
		}
		else
		{
			lpDataArray = lpDataArray2;
		}

		lpDataArray->m_lpRecordData[0].SetData(lpSequenceInfo->m_nDataID);
		lpDataArray->m_lpRecordData[1].SetData(lpSequenceInfo->m_lpszName, strlen(lpSequenceInfo->m_lpszName)+1);
		if(lpFileSequence != NULL)
		{
			lpDataArray->m_lpRecordData[2].SetData(lpFileSequence->m_nMinVal);
			lpDataArray->m_lpRecordData[3].SetData(lpFileSequence->m_nMaxVal);
		}
		lpDataArray->m_lpRecordData[4].SetData(lpSequenceInfo->m_nIncrementBy);
		lpDataArray->m_lpRecordData[5].SetData(lpSequenceInfo->m_nCurrentVal);
		if(lpFileSequence != NULL)
		{
			lpDataArray->m_lpRecordData[6].SetData((int)lpFileSequence->m_bCacheFlag);
			lpDataArray->m_lpRecordData[7].SetData((int)lpFileSequence->m_bCycleFlag);
		}

		//判断系统表中的记录是否符合查询条件
		nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(bValid)
		{
			if(nRowNum < lpQueryPlan->m_nPageSize)
			{
				nRowNum++;
				lpDataArray->m_bValid = 1;
				lpDataArray2		  = NULL;
			}
			else
			{
				break;
			}
		}
	}

	return MF_OK;
}

int CSystemManage::GetVDataFileData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer)
{
	BYTE bKey;
	BOOL bValid;
	Check stCheck;
	int i, nRet, nRowNum;
	LPMEMDBFILEDEF lpFileInfo;
	LPBASECONDITIONBSON lpCondition;	
	LPEXECUTEPLANBSON lpExecutePlan;
	LPOBJECTDEF lpDataFileObjectInfo;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	LPSINGLERECORD lpDataArray, lpDataArray2;
	long long nFileTotalSize, nFileUseSize, nFileFreeSize;
	
	
	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpQueryPlan		= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	//获取V$DATAFILE表的相关信息
	nRet = GetObjectInfo("V$DATAFILE", lpDataFileObjectInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//获取查询条件
	lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	if(lpCommonCondition->m_nWhereOffset != 0)
	{
		lpCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);
	}
	else
	{
		lpCondition = NULL;
	}
	stCheck.Initial(&stBson, NULL);
	
	nRowNum		  = 0;
	lpDataArray   = NULL;
	lpDataArray2  = NULL;
	//获取V$DATAFILE表的所有数据, 遍历m_mapSequence获取所需信息
	lpFileInfo = NULL;
	bKey	 = 0;
	for(i = 0;i < 256;i++)
	{
		if(m_arMemDBFile[i] == NULL)
		{
			continue;
		}
		lpFileInfo  = m_arMemDBFile[i];
		if(lpDataArray2 == NULL)
		{
			nRet = stRecordContainer.AllocSingleRecord(lpDataArray, lpDataFileObjectInfo->m_nFieldNum);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpDataArray2 = lpDataArray;
		}
		else
		{
			lpDataArray = lpDataArray2;
		}

		lpDataArray->m_lpRecordData[0].SetData(GetInnerNoFromDataID(lpFileInfo->m_nDataID));
		lpDataArray->m_lpRecordData[1].SetData((int)lpFileInfo->m_bFileNo);
		lpDataArray->m_lpRecordData[2].SetData((int)lpFileInfo->m_bFileType);
		lpDataArray->m_lpRecordData[3].SetData(lpFileInfo->m_lpszFilePath, strlen(lpFileInfo->m_lpszFilePath)+1);
		lpDataArray->m_lpRecordData[4].SetData(lpFileInfo->m_lpszMemFileName + 7, strlen(lpFileInfo->m_lpszMemFileName)+1-7);		//+,-7是为了去掉Global


		nFileTotalSize = 0;
		nFileUseSize   = 0;
		nFileFreeSize  = 0;
		if(lpFileInfo->m_pInstance != NULL && m_pMemoryFileHead->m_bStatus == 0)
		{
			lpFileInfo->m_pInstance->GetFileSpace(lpExecutePlan, nFileTotalSize, nFileUseSize, nFileFreeSize);
		}

		lpDataArray->m_lpRecordData[5].SetData(nFileTotalSize);
		lpDataArray->m_lpRecordData[6].SetData(nFileFreeSize);
		lpDataArray->m_lpRecordData[7].SetData(nFileUseSize);
		if(lpFileInfo->m_pLoadSize == NULL)
		{
			lpDataArray->m_lpRecordData[8].SetData(nFileTotalSize);
		}
		else
		{
			lpDataArray->m_lpRecordData[8].SetData(*lpFileInfo->m_pLoadSize);
		}

		//判断系统表中的记录是否符合查询条件
		nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(bValid)
		{
			if(nRowNum < lpQueryPlan->m_nPageSize)
			{
				nRowNum++;
				lpDataArray->m_bValid = 1;
				lpDataArray2		  = NULL;
			}
			else
			{
				break;
			}
		}
	}

	//系统文件数据
	if(lpDataArray2 == NULL)
	{
		nRet = stRecordContainer.AllocSingleRecord(lpDataArray, lpDataFileObjectInfo->m_nFieldNum);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpDataArray2 = lpDataArray;
	}
	else
	{
		lpDataArray = lpDataArray2;
	}

	lpDataArray->m_lpRecordData[0].SetData(0);
	lpDataArray->m_lpRecordData[1].SetData(1);
	lpDataArray->m_lpRecordData[2].SetData(MF_SYS_FILETYPE_SYSFILE);
	lpDataArray->m_lpRecordData[3].SetData("System.dbf", 11);
	lpDataArray->m_lpRecordData[4].SetData("MemDBSysFile", 13);
	lpDataArray->m_lpRecordData[5].SetData(m_pMemoryFileHead->m_nFileTotalSize);
	lpDataArray->m_lpRecordData[6].SetData(m_pMemoryFileHead->m_nFileFreeSize);
	lpDataArray->m_lpRecordData[7].SetData(m_pMemoryFileHead->m_nFileTotalSize - m_pMemoryFileHead->m_nFileFreeSize);
	if(m_pMemoryFileHead->m_bStatus == 0)
	{
		lpDataArray->m_lpRecordData[8].SetData(m_pMemoryFileHead->m_nFileTotalSize);
	}
	else
	{
		lpDataArray->m_lpRecordData[8].SetData(0);
	}

	//判断系统表中的记录是否符合查询条件
	nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(bValid)
	{
		if(nRowNum < lpQueryPlan->m_nPageSize)
		{
			nRowNum++;
			lpDataArray->m_bValid = 1;
			lpDataArray2		  = NULL;
		}
	}
	return MF_OK;
}	

int CSystemManage::GetVStatisticsData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer)
{
	DATE dtTime;
	BOOL bValid;
	Check stCheck;
	timeval tTime;
	int nRet, nRowNum;
	LPBASECONDITIONBSON lpCondition;	
	LPEXECUTEPLANBSON lpExecutePlan;
	LPSQLEXECUTESTATISTICSINFO lpNode;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	LPSINGLERECORD lpDataArray, lpDataArray2;
	LPOBJECTDEF pStatisticInfo, lpObjectInfo;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpQueryPlan	= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	
	//获取V$STATISTICS表的相关信息
	nRet = GetObjectInfo("V$STATISTICS", pStatisticInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}	

	//获取查询条件
	lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	if(lpCommonCondition->m_nWhereOffset != 0)
	{
		lpCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);
	}
	else
	{
		lpCondition = NULL;
	}
	stCheck.Initial(&stBson, NULL);
	
	nRowNum		  = 0;
	lpDataArray   = NULL;
	lpDataArray2  = NULL;
	for(lpNode = m_pExecuteStatistics;lpNode != NULL; lpNode = lpNode->m_pNext)
	{
		lpObjectInfo = NULL;
		GetObjectInfo(lpNode->m_nObjectID, lpObjectInfo);

		if(lpDataArray2 == NULL)
		{
			nRet = stRecordContainer.AllocSingleRecord(lpDataArray, pStatisticInfo->m_nFieldNum);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpDataArray2 = lpDataArray;
		}
		else
		{
			lpDataArray = lpDataArray2;
		}

		lpDataArray->m_lpRecordData[0].SetData(lpNode->m_lpszSql, strlen(lpNode->m_lpszSql)+1);
		lpDataArray->m_lpRecordData[1].SetData((int)lpNode->m_dwTotalExecuteCount);
		lpDataArray->m_lpRecordData[2].SetData((int)lpNode->m_dwTotalTime);
		lpDataArray->m_lpRecordData[3].SetData((int)lpNode->m_dwTotalPrepareTime);
		lpDataArray->m_lpRecordData[4].SetData((int)lpNode->m_dwTotalApplyResourceTime);
		lpDataArray->m_lpRecordData[5].SetData((int)lpNode->m_dwTotalIndexSearchTime);
		lpDataArray->m_lpRecordData[6].SetData((int)lpNode->m_dwTotalExecuteTime);
		lpDataArray->m_lpRecordData[7].SetData((int)lpNode->m_dwTotalLogTime);
		lpDataArray->m_lpRecordData[8].SetData((int)lpNode->m_dwTotalReleaseResourceTime);
		lpDataArray->m_lpRecordData[9].SetData((int)lpNode->m_dwTotalWorkLoad);
		lpDataArray->m_lpRecordData[10].SetData((int)lpNode->m_dwHashID);
		if(lpObjectInfo != NULL)
		{
			lpDataArray->m_lpRecordData[11].SetData(lpObjectInfo->m_lpszName, strlen(lpObjectInfo->m_lpszName)+1);
		}
		else
		{
			lpDataArray->m_lpRecordData[11].SetData("", 1);
		}

		tTime = ConvertFileTimetoTime(lpNode->m_ftFirstTime);
		dtTime = ConvertTimetoDate(tTime.tv_sec);

		lpDataArray->m_lpRecordData[12].SetData(dtTime, MF_SYS_FIELDTYPE_DATE);

		//判断系统表中的记录是否符合查询条件
		nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(bValid)
		{
			if(nRowNum < lpQueryPlan->m_nPageSize)
			{
				nRowNum++;
				lpDataArray->m_bValid = 1;
				lpDataArray2		  = NULL;
			}
			else
			{
				break;
			}
		}
	}

	return MF_OK;
}

int CSystemManage::GetVSessionData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer)
{
	DATE dtTime;
	BOOL bValid;
	Check stCheck;
	timeval tTime;
	int lSessionID;
	int nRet, nRowNum;
	LPVOID lpPos, lpValue;
	LPOBJECTDEF lpSessionInfo;
	LPSESSIONINFO lpSessionData;
	LPBASECONDITIONBSON lpCondition;	
	LPEXECUTEPLANBSON lpExecutePlan;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	LPSINGLERECORD lpDataArray, lpDataArray2;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpQueryPlan		= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);

	//获取查询条件
	lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	if(lpCommonCondition->m_nWhereOffset != 0)
	{
		lpCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);
	}
	else
	{
		lpCondition = NULL;
	}
	stCheck.Initial(&stBson, NULL);
	
	nRowNum		  = 0;
	lpDataArray   = NULL;
	lpDataArray2  = NULL;
	CCriticalSectionPtr cs(&m_critSession);
	try
	{
		nRet = GetObjectInfo("V$SESSION", lpSessionInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpPos = m_mapSession.GetHeadPosition();
		while(lpPos)
		{
			m_mapSession.GetNext(lpPos, lSessionID, lpValue);
			if(lpValue != NULL)
			{
				lpSessionData = (LPSESSIONINFO)lpValue;
			}
			else
			{
				continue;
			}

			if(lpDataArray2 == NULL)
			{
				nRet = stRecordContainer.AllocSingleRecord(lpDataArray, lpSessionInfo->m_nFieldNum);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpDataArray2 = lpDataArray;
			}
			else
			{
				lpDataArray = lpDataArray2;
			}
			lpDataArray->m_lpRecordData[0].SetData((int)lSessionID);
			lpDataArray->m_lpRecordData[1].SetData(lpSessionData->m_lpszUserName, strlen(lpSessionData->m_lpszUserName)+1);
			if (lpSessionData->m_bConnectType == 0)
			{
				lpDataArray->m_lpRecordData[2].SetData("COMMON", 7);
			} 
			else if (lpSessionData->m_bConnectType == 1)
			{
				lpDataArray->m_lpRecordData[2].SetData("CLUSTER", 8);
			}
			else
			{
				lpDataArray->m_lpRecordData[2].SetData("UNKNOWN", 8);
			}
			lpDataArray->m_lpRecordData[3].SetData(lpSessionData->m_lpszMachineIP, strlen(lpSessionData->m_lpszMachineIP)+1);
			lpDataArray->m_lpRecordData[4].SetData((int)lpSessionData->m_usMachinePort);
			lpDataArray->m_lpRecordData[5].SetData((int)lpSessionData->m_bStatus);
			lpDataArray->m_lpRecordData[6].SetData(lpSessionData->m_lpszProgramName, strlen(lpSessionData->m_lpszProgramName)+1);
			lpDataArray->m_lpRecordData[7].SetData((int)lpSessionData->m_dwProcessID);
			lpDataArray->m_lpRecordData[8].SetData((int)lpSessionData->m_dwThreadID);

			tTime = ConvertFileTimetoTime(lpSessionData->m_ftLogonTime);
			dtTime = ConvertTimetoDate(tTime.tv_sec);
			lpDataArray->m_lpRecordData[9].SetData(dtTime, MF_SYS_FIELDTYPE_DATE);
			if(lpSessionData->m_ftLastCallTime.dwHighDateTime == 0 && lpSessionData->m_ftLastCallTime.dwLowDateTime == 0)
			{
				dtTime = 0;
			}
			else
			{
				tTime = ConvertFileTimetoTime(lpSessionData->m_ftLastCallTime);
				dtTime = ConvertTimetoDate(tTime.tv_sec);
			}
			lpDataArray->m_lpRecordData[10].SetData(dtTime, MF_SYS_FIELDTYPE_DATE);
			lpDataArray->m_lpRecordData[11].SetData(lpSessionData->m_nTotalTime);
			lpDataArray->m_lpRecordData[12].SetData(lpSessionData->m_nTotalPrepareTime);
			lpDataArray->m_lpRecordData[13].SetData(lpSessionData->m_nTotalApplyResourceTime);
			lpDataArray->m_lpRecordData[14].SetData(lpSessionData->m_nTotalIndexSearchTime);
			lpDataArray->m_lpRecordData[15].SetData(lpSessionData->m_nTotalExecuteTime);
			lpDataArray->m_lpRecordData[16].SetData(lpSessionData->m_nTotalLogTime);
			lpDataArray->m_lpRecordData[17].SetData(lpSessionData->m_nTotalReleaseResourceTime);
			lpDataArray->m_lpRecordData[18].SetData(lpSessionData->m_nTotalWorkLoad);
			lpDataArray->m_lpRecordData[19].SetData(lpSessionData->m_nTotalCallCount);

			//判断系统表中的记录是否符合查询条件
			nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(bValid)
			{
				if(nRowNum < lpQueryPlan->m_nPageSize)
				{
					nRowNum++;
					lpDataArray->m_bValid = 1;
					lpDataArray2		  = NULL;
				}
				else
				{
					break;
				}
			}
		}
	}
	catch(...)
	{
		Trace("CSystemManage::GetVSessionData", MF_TRACE_LEVEL_FAILED, 100042001, "获取Session数据异常，错误码：%d", GetLastError());
	}
	return MF_OK;
}

int CSystemManage::GetVSoapServerData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer)
{
	DATE dtTime;
	BOOL bValid;
	Check stCheck;
	timeval tTime;
	LPVOID lpPos, lpValue;
	LPOBJECTDEF lpSoapInfo;
	LPSESSIONINFO lpSessionData;
	int nRet, lSessionID, nRowNum;
	LPBASECONDITIONBSON lpCondition;	
	LPEXECUTEPLANBSON lpExecutePlan;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	LPSINGLERECORD lpDataArray, lpDataArray2;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpQueryPlan		= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	//获取查询条件
	lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	if(lpCommonCondition->m_nWhereOffset != 0)
	{
		lpCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);
	}
	else
	{
		lpCondition = NULL;
	}
	stCheck.Initial(&stBson, NULL);
	
	nRowNum		  = 0;
	lpDataArray   = NULL;
	lpDataArray2  = NULL;
	CCriticalSectionPtr cs(&m_critSession);
	try
	{
		nRet = GetObjectInfo("V$SOAPSERVER", lpSoapInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpPos = m_mapSoapServer.GetHeadPosition();
		while(lpPos)
		{
			m_mapSoapServer.GetNext(lpPos, lSessionID, lpValue);
			if(lpValue != NULL)
			{
				lpSessionData = (LPSESSIONINFO)lpValue;
			}
			else
			{
				continue;
			}

			if(lpDataArray2 == NULL)
			{
				nRet = stRecordContainer.AllocSingleRecord(lpDataArray, lpSoapInfo->m_nFieldNum);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpDataArray2 = lpDataArray;
			}
			else
			{
				lpDataArray = lpDataArray2;
			}

			lpDataArray->m_lpRecordData[0].SetData((int)lSessionID);
			lpDataArray->m_lpRecordData[1].SetData(lpSessionData->m_lpszMachineIP, strlen(lpSessionData->m_lpszMachineIP)+1);
			lpDataArray->m_lpRecordData[2].SetData((int)lpSessionData->m_usMachinePort);
			lpDataArray->m_lpRecordData[3].SetData((int)lpSessionData->m_bStatus);

			tTime = ConvertFileTimetoTime(lpSessionData->m_ftLogonTime);
			dtTime = ConvertTimetoDate(tTime.tv_sec);

			lpDataArray->m_lpRecordData[4].SetData(dtTime, MF_SYS_FIELDTYPE_DATE);
			if(lpSessionData->m_ftLastCallTime.dwHighDateTime == 0 && lpSessionData->m_ftLastCallTime.dwLowDateTime == 0)
			{
				dtTime = 0;
			}
			else
			{
				tTime = ConvertFileTimetoTime(lpSessionData->m_ftLastCallTime);
				dtTime = ConvertTimetoDate(tTime.tv_sec);
			}
			lpDataArray->m_lpRecordData[5].SetData(dtTime, MF_SYS_FIELDTYPE_DATE);
			lpDataArray->m_lpRecordData[6].SetData(lpSessionData->m_nTotalTime);
			lpDataArray->m_lpRecordData[7].SetData(lpSessionData->m_nTotalPrepareTime);
			lpDataArray->m_lpRecordData[8].SetData(lpSessionData->m_nTotalApplyResourceTime);
			lpDataArray->m_lpRecordData[9].SetData(lpSessionData->m_nTotalIndexSearchTime);
			lpDataArray->m_lpRecordData[10].SetData(lpSessionData->m_nTotalExecuteTime);
			lpDataArray->m_lpRecordData[11].SetData(lpSessionData->m_nTotalLogTime);
			lpDataArray->m_lpRecordData[12].SetData(lpSessionData->m_nTotalReleaseResourceTime);
			lpDataArray->m_lpRecordData[13].SetData(lpSessionData->m_nTotalWorkLoad);
			lpDataArray->m_lpRecordData[14].SetData(lpSessionData->m_nTotalCallCount);

			//判断系统表中的记录是否符合查询条件
			nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(bValid)
			{
				if(nRowNum < lpQueryPlan->m_nPageSize)
				{
					nRowNum++;
					lpDataArray->m_bValid = 1;
					lpDataArray2		  = NULL;
				}
				else
				{
					break;
				}
			}
		}
	}
	catch(...)
	{
		Trace("CSystemManage::GetVSoapServerData", MF_TRACE_LEVEL_FAILED, 100043001, "获取Soap数据异常，错误码：%d", GetLastError());
	}
	return MF_OK;
}

//获取用户信息
int CSystemManage::GetVUserData(CServiceBson &stBson, CSysRecordContainer& stRecordContainer)
{
	BOOL bValid;
	Check stCheck;
	LPVOID lpPos, lpValue;
	int nRet, nID, nRowNum;
	LPOBJECTDEF lpObjectUser;
	LPUSERINFODEF lpUserData;
	LPBASECONDITIONBSON lpCondition;	
	LPEXECUTEPLANBSON lpExecutePlan;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	LPSINGLERECORD lpDataArray, lpDataArray2;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpQueryPlan		= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	//获取查询条件
	lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	if(lpCommonCondition->m_nWhereOffset != 0)
	{
		lpCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);
	}
	else
	{
		lpCondition = NULL;
	}
	stCheck.Initial(&stBson, NULL);
	
	nRowNum		  = 0;
	lpDataArray   = NULL;
	lpDataArray2  = NULL;
	CCriticalSectionPtr cs(&m_critUser);
	try
	{
		nRet = GetObjectInfo("V$USER", lpObjectUser);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpPos = m_mapUserInfo.GetHeadPosition();
		while(lpPos)
		{
			m_mapUserInfo.GetNext(lpPos, nID, lpValue);
			if(lpValue != NULL)
			{
				lpUserData = (LPUSERINFODEF)lpValue;
			}
			else
			{
				continue;
			}
		
			if(lpDataArray2 == NULL)
			{
				nRet = stRecordContainer.AllocSingleRecord(lpDataArray, lpObjectUser->m_nFieldNum);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpDataArray2 = lpDataArray;
			}
			else
			{
				lpDataArray = lpDataArray2;
			}

			lpDataArray->m_lpRecordData[0].SetData(lpUserData->m_nUserID);
			if(lpUserData->m_bStatus)
			{
				lpDataArray->m_lpRecordData[1].SetData("Enable", 7);
			}
			else
			{
				lpDataArray->m_lpRecordData[1].SetData("Disable", 8);
			}
			lpDataArray->m_lpRecordData[2].SetData(lpUserData->m_pUserName, strlen(lpUserData->m_pUserName)+1);
			lpDataArray->m_lpRecordData[3].SetData((const char*)lpUserData->m_pPassword, 24);
			lpDataArray->m_lpRecordData[4].SetData((int)lpUserData->m_bAuthority[MF_AUTHORITY_DBA]);
			lpDataArray->m_lpRecordData[5].SetData((int)lpUserData->m_bAuthority[MF_AUTHORITY_ALTERSYSTEM]);
			lpDataArray->m_lpRecordData[6].SetData((int)lpUserData->m_bAuthority[MF_AUTHORITY_CREATEOBJECT]);
			lpDataArray->m_lpRecordData[7].SetData((int)lpUserData->m_bAuthority[MF_AUTHORITY_ALTEROBJECT]);
			lpDataArray->m_lpRecordData[8].SetData((int)lpUserData->m_bAuthority[MF_AUTHORITY_DROPOBJECT]);
			lpDataArray->m_lpRecordData[9].SetData((int)lpUserData->m_bAuthority[MF_AUTHORITY_CREATESEQUENCE]);
			lpDataArray->m_lpRecordData[10].SetData((int)lpUserData->m_bAuthority[MF_AUTHORITY_DROPSEQUENCE]);
			
			//判断系统表中的记录是否符合查询条件
			nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(bValid)
			{
				if(nRowNum < lpQueryPlan->m_nPageSize)
				{
					nRowNum++;
					lpDataArray->m_bValid = 1;
					lpDataArray2		  = NULL;
				}
				else
				{
					break;
				}
			}
		}
	}
	catch(...)
	{
		Trace("CSystemManage::GetVUserData", MF_TRACE_LEVEL_FAILED, 100047002, "获取用户数据异常，错误码：%d", GetLastError());
	}
	return MF_OK;
}

//获取用户信息
int CSystemManage::GetVAuthority(CServiceBson &stBson, CSysRecordContainer& stRecordContainer)
{
	BOOL bValid;
	Check stCheck;
	LPVOID lpPos, lpValue;
	int nRet, nID, nRowNum;
	LPOBJECTDEF lpObjectAuthority;
	LPAUTHORITYINFO lpAuthorityInfo;
	LPBASECONDITIONBSON lpCondition;	
	LPEXECUTEPLANBSON lpExecutePlan;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	LPSINGLERECORD lpDataArray, lpDataArray2;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpQueryPlan		= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	//获取查询条件
	lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	if(lpCommonCondition->m_nWhereOffset != 0)
	{
		lpCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);
	}
	else
	{
		lpCondition = NULL;
	}
	stCheck.Initial(&stBson, NULL);
	
	nRowNum		  = 0;
	lpDataArray   = NULL;
	lpDataArray2  = NULL;
	CCriticalSectionPtr cs(&m_critAuthority);
	try
	{
		nRet = GetObjectInfo("V$AUTHORITY", lpObjectAuthority);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		lpPos = m_mapAuthority.GetHeadPosition();
		while(lpPos)
		{
			m_mapAuthority.GetNext(lpPos, nID, lpValue);
			if(lpValue != NULL)
			{
				lpAuthorityInfo = (LPAUTHORITYINFO)lpValue;
			}
			else
			{
				continue;
			}
			
			if(lpDataArray2 == NULL)
			{
				nRet = stRecordContainer.AllocSingleRecord(lpDataArray, lpObjectAuthority->m_nFieldNum);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpDataArray2 = lpDataArray;
			}
			else
			{
				lpDataArray = lpDataArray2;
			}

			lpDataArray->m_lpRecordData[0].SetData((int)lpAuthorityInfo->m_bAuthorityID);
			lpDataArray->m_lpRecordData[1].SetData(lpAuthorityInfo->m_pAuthorityName, strlen(lpAuthorityInfo->m_pAuthorityName) + 1);
			lpDataArray->m_lpRecordData[2].SetData(lpAuthorityInfo->m_pAuthorityDesc, strlen(lpAuthorityInfo->m_pAuthorityDesc) + 1);
	
			//判断系统表中的记录是否符合查询条件
			nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(bValid)
			{
				if(nRowNum < lpQueryPlan->m_nPageSize)
				{
					nRowNum++;
					lpDataArray->m_bValid = 1;
					lpDataArray2		  = NULL;
				}
				else
				{
					break;
				}
			}
		}
	}
	catch(...)
	{
		Trace("CSystemManage::GetVUserData", MF_TRACE_LEVEL_FAILED, 100047003, "获取用户数据异常，错误码：%d", GetLastError());
	}
	return MF_OK;
}

int CSystemManage::GetVWorkLoad(CServiceBson &stBson, CSysRecordContainer& stRecordContainer)
{
	BOOL bValid;
	DATE dtTime;
	time_t tTime;
	Check stCheck;
	FILETIME ftTime;
	ULARGE_INTEGER ui;  
	int nRet, i, nRowNum;
	long long nTimestamp, nTime;
	LPOBJECTDEF lpObjectWorkLoad;
	LPBASECONDITIONBSON lpCondition;	
	LPEXECUTEPLANBSON lpExecutePlan;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPCOMMONCONDITION lpCommonCondition;
	LPSINGLERECORD lpDataArray, lpDataArray2;

	lpExecutePlan	= (LPEXECUTEPLANBSON)stBson.GetBuffer();
	lpQueryPlan		= (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	//获取查询条件
	lpCommonCondition = (LPCOMMONCONDITION)stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
	if(lpCommonCondition->m_nWhereOffset != 0)
	{
		lpCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpCommonCondition->m_nWhereOffset);
	}
	else
	{
		lpCondition = NULL;
	}
	stCheck.Initial(&stBson, NULL);
	
	nRowNum		  = 0;
	lpDataArray   = NULL;
	lpDataArray2  = NULL;
	nTime		  = 24*60*60;
	nTime		  *= 10000000;
	CCriticalSectionPtr cs(&m_critWorkload);
	try
	{
		nRet = GetObjectInfo("V$WORKLOAD", lpObjectWorkLoad);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		for(i = 0; i < 60*24; i++)
		{
			if(lpDataArray2 == NULL)
			{
				nRet = stRecordContainer.AllocSingleRecord(lpDataArray, lpObjectWorkLoad->m_nFieldNum);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpDataArray2 = lpDataArray;
			}
			else
			{
				lpDataArray = lpDataArray2;
			}
			
			GetSystemTimeAsFileTime((LPFILETIME)&nTimestamp);
			if(nTimestamp - m_lpWorkloadStatistics[i].m_llBeginTime > nTime)
			{
				continue;
			}
			ftTime			=  *((LPFILETIME)&m_lpWorkloadStatistics[i].m_llBeginTime);
			ui.LowPart      =  ftTime.dwLowDateTime;  
			ui.HighPart     =  ftTime.dwHighDateTime;  
			tTime			=  ((long long)(ui.QuadPart  -  116444736000000000)  /  10000000); 
			dtTime			= ConvertTimetoDate(tTime);

			lpDataArray->m_lpRecordData[0].SetData(dtTime, MF_VARDATA_DATE);
			lpDataArray->m_lpRecordData[1].SetData(m_lpWorkloadStatistics[i].m_nRunTime);
			lpDataArray->m_lpRecordData[2].SetData(m_lpWorkloadStatistics[i].m_nExecuteTime);
			lpDataArray->m_lpRecordData[3].SetData(m_lpWorkloadStatistics[i].m_nMinExecuteTime);
			lpDataArray->m_lpRecordData[4].SetData(m_lpWorkloadStatistics[i].m_nMaxExecuteTime);
			lpDataArray->m_lpRecordData[5].SetData(m_lpWorkloadStatistics[i].m_nQueryCount);
			lpDataArray->m_lpRecordData[6].SetData(m_lpWorkloadStatistics[i].m_nUpdateCount);
			
			//判断系统表中的记录是否符合查询条件
			nRet = stCheck.CheckValid(lpDataArray, lpCondition, bValid);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(bValid)
			{
				if(nRowNum < lpQueryPlan->m_nPageSize)
				{
					nRowNum++;
					lpDataArray->m_bValid = 1;
					lpDataArray2		  = NULL;
				}
				else
				{
					break;
				}
			}
		}
	}
	catch(...)
	{
		Trace("CSystemManage::GetVWorkLoad", MF_TRACE_LEVEL_FAILED, 100047004, "获取负载数据异常，错误码：%d", GetLastError());
	}
	return MF_OK;
}

void CSystemManage::GetFilePath(MF_SYS_FILETYPE bFileType, LPCTSTR& lpFilePath)
{
	int i;
	LPMEMDBFILEDEF lpFileInfo;

	lpFilePath	= NULL;
	lpFileInfo	= NULL;
	for(i = 0;i < 256;i++)
	{
		if(m_arMemDBFile[i] == NULL)
		{
			continue;
		}
		lpFileInfo  = m_arMemDBFile[i];
		if(lpFileInfo->m_bFileType == bFileType)
		{
			lpFilePath = lpFileInfo->m_lpszFilePath;
			break;
		}
	}
}

void CSystemManage::SetSessionInfo(LPSESSIONINFO lpSessionInfo, BOOL bSaop)
{
	CCriticalSectionPtr cs(&m_critSession);
	try
	{
		if(bSaop)
		{
			m_mapSoapServer.Set(lpSessionInfo->m_dwSessionID, lpSessionInfo);
		}
		else
		{
			m_mapSession.Set(lpSessionInfo->m_dwSessionID, lpSessionInfo);
		}
	}
	catch(...)
	{
		Trace("CSystemManage::SetSessionInfo", MF_TRACE_LEVEL_FAILED, 100040001, "设置Session异常，错误码：%d", GetLastError());
	}
}

void CSystemManage::RemoveSessionInfo(LPSESSIONINFO &lpSessionInfo, BOOL bSaop)
{
	CCriticalSectionPtr cs(&m_critSession);
	try
	{
		if(bSaop)
		{
			if(NULL != m_mapSoapServer.Get(lpSessionInfo->m_dwSessionID))
			{	
				m_mapSoapServer.Remove(lpSessionInfo->m_dwSessionID);
			}
		}
		else
		{
			if(NULL != m_mapSession.Get(lpSessionInfo->m_dwSessionID))
			{
				m_mapSession.Remove(lpSessionInfo->m_dwSessionID);
			}	
		}
		if (lpSessionInfo != NULL)
		{
			delete lpSessionInfo;
			lpSessionInfo = NULL;
		}
	}
	catch(...)
	{
		Trace("CSystemManage::RemoveSessionInfo", MF_TRACE_LEVEL_FAILED, 100041001, "删除Session异常，错误码：%d", GetLastError());
	}
}

BOOL CSystemManage::CheckTemporaryMem()
{
	BOOL bAdjust;
	long long nCurrentTime;
	LPTEMPORARYMEMBLOCK lpFreeBlock;
	CCriticalSectionPtr cs(&m_critTemporaryMemory);

	try
	{
		bAdjust      = FALSE;
		nCurrentTime = 0;
		GetSystemTimeAsFileTime((LPFILETIME)&nCurrentTime);

		lpFreeBlock = (LPTEMPORARYMEMBLOCK)(((LPBYTE)m_pTemporaryMemory) + m_pTemporaryMemory->m_nFreePos);
		while(TRUE)
		{
			if(lpFreeBlock->m_bFlag != 255)
			{
				assert(0);
				Trace("CSystemManage::CheckTemporaryMem", MF_TRACE_LEVEL_FAILED, 100049001, "内存数据出现错乱，重新初始化临时内存，Flag：%d，Size：%d，Status：%d！", lpFreeBlock->m_bFlag, lpFreeBlock->m_nSize, lpFreeBlock->m_bStatus);
				//尝试查一下最后一个内存块是否正常，挽救最后一个分配的内存块
				if(m_pTemporaryMemory->m_nLastAllocPos != m_pTemporaryMemory->m_nFreePos)
				{
					lpFreeBlock = (LPTEMPORARYMEMBLOCK)(((LPBYTE)m_pTemporaryMemory) + m_pTemporaryMemory->m_nLastAllocPos);
					if(lpFreeBlock->m_bFlag == 255)
					{
						m_pTemporaryMemory->m_nFreePos = m_pTemporaryMemory->m_nLastAllocPos;
						bAdjust      = TRUE;
						continue;
					}
				}

				m_pTemporaryMemory->m_nAllocPos     = m_pTemporaryMemory->m_nHeaderSize;
				m_pTemporaryMemory->m_nLastAllocPos = 0;
				m_pTemporaryMemory->m_nFreePos      = m_pTemporaryMemory->m_nHeaderSize;
				bAdjust      = TRUE;
				break;
			}
			if(lpFreeBlock->m_bStatus == 1)
			{
				if(nCurrentTime - lpFreeBlock->m_nAllocTime > 10000000 || lpFreeBlock->m_nAllocTime > nCurrentTime)//超过1分钟就直接释放内存,单位是100ns
				{
					lpFreeBlock->m_bStatus = 0;
				}
				else
				{
					break;
				}
			}

			bAdjust      = TRUE;
			if(lpFreeBlock->m_nNextPos == 0)
			{
				//可以直接重新初始化
				m_pTemporaryMemory->m_nAllocPos     = m_pTemporaryMemory->m_nHeaderSize;
				m_pTemporaryMemory->m_nLastAllocPos = 0;
				m_pTemporaryMemory->m_nFreePos      = m_pTemporaryMemory->m_nHeaderSize;
				break;
			}
			else
			{
				m_pTemporaryMemory->m_nFreePos = lpFreeBlock->m_nNextPos;
			}
			lpFreeBlock = (LPTEMPORARYMEMBLOCK)(((LPBYTE)m_pTemporaryMemory) + m_pTemporaryMemory->m_nFreePos);
		}
	}
	catch(...)
	{
		Trace("CSystemManage::CheckTemporaryMem", MF_TRACE_LEVEL_FAILED, 100044001, "设置Session异常，错误码：%d", GetLastError());
	}
	return bAdjust;
}

LPBYTE CSystemManage::AllocTemporaryMemCore(UINT nSize, int &nErrorNo)
{
	LPTEMPORARYMEMBLOCK lpBlock, lpPrev;
	CCriticalSectionPtr cs(&m_critTemporaryMemory);

	try
	{
		lpBlock = NULL;
		lpPrev  = NULL;
		nErrorNo= 0;
		if(m_pTemporaryMemory->m_nLastAllocPos != 0)
		{
			lpPrev = (LPTEMPORARYMEMBLOCK)(((LPBYTE)m_pTemporaryMemory) + m_pTemporaryMemory->m_nLastAllocPos);
		}
		//首先判断后面位置是否能分配出足够大的空间，暂时不考虑分配出去的内存使用情况
		if(m_pTemporaryMemory->m_nTotalSize - m_pTemporaryMemory->m_nAllocPos < nSize + sizeof(TEMPORARYMEMBLOCK))
		{
			//判断一下请求的空间是不是太大没办法分配
			if(nSize > m_pTemporaryMemory->m_nTotalSize - 1024)
			{
				//直接写错误日志，并返回空指针
				Trace("CSystemManage::AllocTemporaryMemCore", MF_TRACE_LEVEL_FAILED, 100050001, "申请的内存太大，无法分配临时内存，申请大小：%d，TotalSize：%d，FreePos：%d，AllocPos：%d！", nSize, m_pTemporaryMemory->m_nTotalSize, m_pTemporaryMemory->m_nFreePos, m_pTemporaryMemory->m_nAllocPos);
				nErrorNo = 1;
				return NULL;
			}
			else
			{
				if(m_pTemporaryMemory->m_nFreePos > m_pTemporaryMemory->m_nAllocPos)
				{
					//后面还有数据不能抹掉，所以肯定不能分配
					Trace("CSystemManage::AllocTemporaryMemCore", MF_TRACE_LEVEL_FAILED, 100050002, "没有可用临时内存供分配，申请大小：%d，TotalSize：%d，FreePos：%d，AllocPos：%d！", nSize, m_pTemporaryMemory->m_nTotalSize, m_pTemporaryMemory->m_nFreePos, m_pTemporaryMemory->m_nAllocPos);
					nErrorNo = 2;
					return NULL;
				}
				else if(m_pTemporaryMemory->m_nFreePos < m_pTemporaryMemory->m_nHeaderSize + nSize + sizeof(TEMPORARYMEMBLOCK))
				{
					//仍然有数据会被抹掉
					Trace("CSystemManage::AllocTemporaryMemCore", MF_TRACE_LEVEL_FAILED, 100050003, "没有可用临时内存供分配，申请大小：%d，TotalSize：%d，FreePos：%d，AllocPos：%d！", nSize, m_pTemporaryMemory->m_nTotalSize, m_pTemporaryMemory->m_nFreePos, m_pTemporaryMemory->m_nAllocPos);
					nErrorNo = 3;
					return NULL;
				}
				m_pTemporaryMemory->m_nAllocPos		= m_pTemporaryMemory->m_nHeaderSize;
				m_pTemporaryMemory->m_nLastAllocPos = m_pTemporaryMemory->m_nAllocPos;
				lpBlock = (LPTEMPORARYMEMBLOCK)(((LPBYTE)m_pTemporaryMemory) + m_pTemporaryMemory->m_nAllocPos);
				lpBlock->m_nSize	= nSize;
				lpBlock->m_nNextPos	= 0;
				lpBlock->m_bStatus	= 1;
				lpBlock->m_bFlag	= 255;

				GetSystemTimeAsFileTime((LPFILETIME)&lpBlock->m_nAllocTime);

				m_pTemporaryMemory->m_nAllocPos = m_pTemporaryMemory->m_nAllocPos + nSize + sizeof(TEMPORARYMEMBLOCK);
			}
		}
		else
		{
			//先判断剩余的可用空间是否够
			if(m_pTemporaryMemory->m_nFreePos > m_pTemporaryMemory->m_nAllocPos)
			{
				if(m_pTemporaryMemory->m_nFreePos - m_pTemporaryMemory->m_nAllocPos < nSize + sizeof(TEMPORARYMEMBLOCK))
				{
					//空间不够
					Trace("CSystemManage::AllocTemporaryMemCore", MF_TRACE_LEVEL_FAILED, 100050010, "没有可用临时内存供分配，申请大小：%d，TotalSize：%d，FreePos：%d，AllocPos：%d！", nSize, m_pTemporaryMemory->m_nTotalSize, m_pTemporaryMemory->m_nFreePos, m_pTemporaryMemory->m_nAllocPos);
					nErrorNo = 4;
					return NULL;
				}
			}
			m_pTemporaryMemory->m_nLastAllocPos = m_pTemporaryMemory->m_nAllocPos;
			lpBlock = (LPTEMPORARYMEMBLOCK)(((LPBYTE)m_pTemporaryMemory) + m_pTemporaryMemory->m_nAllocPos);
			lpBlock->m_nSize	= nSize;
			lpBlock->m_nNextPos	= 0;
			lpBlock->m_bStatus	= 1;
			lpBlock->m_bFlag	= 255;

			GetSystemTimeAsFileTime((LPFILETIME)&lpBlock->m_nAllocTime);

			m_pTemporaryMemory->m_nAllocPos = m_pTemporaryMemory->m_nAllocPos + nSize + sizeof(TEMPORARYMEMBLOCK);
		}
		if(lpPrev)
		{
			lpPrev->m_nNextPos = m_pTemporaryMemory->m_nLastAllocPos;
		}
	}
	catch(...)
	{
		Trace("CSystemManage::AllocTemporaryMemCore", MF_TRACE_LEVEL_FAILED, 100045001, "分配虚拟空间异常，错误码：%d", GetLastError());
	}
	return &lpBlock->m_bMemAddr;
}


BOOL CSystemManage::SetObjectMutexLock(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo)
{
	int i;
	CExecutePlanCriticalPtr cs(&m_critDataObject, lpExecutePlan);
	
	//将Object共享锁提升为互斥锁
	for(i = 0; i < lpObjectInfo->m_bMaxTransactionNum; i++)
	{
		if(lpObjectInfo->m_lpTimestampArray[i] != 0)
		{
			if(CheckTransactionFinish(lpObjectInfo->m_lpTimestampArray[i]))
			{
				lpObjectInfo->m_lpTimestampArray[i] = 0;
			}
			else if(lpObjectInfo->m_lpTimestampArray[i] != lpExecutePlan->m_nTimestamp)
			{
				//要对Object加互斥锁，
				return FALSE;
			}
		}
	}
	lpObjectInfo->m_lpTimestampArray[0] = lpExecutePlan->m_nTimestamp;			//只用将m_nTimestampArray中的一个时间戳改为当前实现戳，就可以保证时间戳有效
	lpObjectInfo->m_bStatus = MF_LOCK_STATUS_MUTEX;
	return TRUE;
}

BOOL CSystemManage::SetObjectShareLock(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo)
{
	int i;
	CExecutePlanCriticalPtr cs(&m_critDataObject, lpExecutePlan);
	//判断Object上是否为互斥锁
	if(lpObjectInfo->m_bStatus == MF_LOCK_STATUS_MUTEX)
	{
		//如果是互斥锁则判断锁是否失效
		if(lpObjectInfo->m_lpTimestampArray[0] != 0 && !CheckTransactionFinish(lpObjectInfo->m_lpTimestampArray[0]))
		{
			//同一个事务可以直接加锁
			if(lpObjectInfo->m_lpTimestampArray[0] == lpExecutePlan->m_nTimestamp)
			{
				return TRUE;
			}
			else
			{
				return FALSE;
			}
		}
		else 
		{
			lpObjectInfo->m_bStatus = MF_LOCK_STATUS_SHARE;
			lpObjectInfo->m_lpTimestampArray[0] = lpExecutePlan->m_nTimestamp;
			return TRUE;
		}
	}

	for(i = 0; i < lpObjectInfo->m_bMaxTransactionNum; i++)
	{
		if(lpObjectInfo->m_lpTimestampArray[i] == 0)
		{
			//无锁状态
			lpObjectInfo->m_bStatus = MF_LOCK_STATUS_SHARE;
			lpObjectInfo->m_lpTimestampArray[i] = lpExecutePlan->m_nTimestamp;
			return TRUE;
		}
		else if(lpObjectInfo->m_lpTimestampArray[i] == lpExecutePlan->m_nTimestamp)
		{
			//时间戳相同直接上锁
			return TRUE;
		}	
		else if(CheckTransactionFinish(lpObjectInfo->m_lpTimestampArray[i]))
		{
			//锁失效状态
			lpObjectInfo->m_bStatus = MF_LOCK_STATUS_SHARE;
			lpObjectInfo->m_lpTimestampArray[i] = lpExecutePlan->m_nTimestamp;
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CSystemManage::SetObjectNullLock(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo)
{
	int i;
	CExecutePlanCriticalPtr cs(&m_critDataObject, lpExecutePlan);
	//判断Object上是否为互斥锁
	if(lpObjectInfo->m_bStatus == MF_LOCK_STATUS_MUTEX)
	{
		//如果是互斥锁则判断锁是否失效
		if(lpObjectInfo->m_lpTimestampArray[0] != 0 && !CheckTransactionFinish(lpObjectInfo->m_lpTimestampArray[0]))
		{
			return FALSE;
		}
	}
	for(i = 0; i < lpObjectInfo->m_bMaxTransactionNum; i++)
	{
		//无锁状态
		if(lpObjectInfo->m_lpTimestampArray[i]	== lpExecutePlan->m_nTimestamp)
		{
			lpObjectInfo->m_lpTimestampArray[i] = 0;
		}
	}
	return TRUE;
}

int CSystemManage::SetTransactionLine(CServiceBson& stBson, long long nTimestamp, UINT& nTransactionOffset, int& nTransactionNum)
{
	return CTimestampManage::instance().SetTransactionLine(stBson, nTimestamp, nTransactionOffset, nTransactionNum);
}

BOOL CSystemManage::CheckTransactionFinish(long long nTimestamp)
{
	return CTimestampManage::instance().CheckFinishFlag(nTimestamp);
}

BOOL CSystemManage::CheckTransactionActive()
{
	return CTimestampManage::instance().CheckTransactionActive();
}

BOOL CSystemManage::SetObjectLock(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, BYTE bLockType, DWORD dwMilliseconds)
{
	BOOL bRet;
	DWORD dwTime;
	long long nStart, nEnd;

	GetSystemTimeAsFileTime((LPFILETIME)&nStart);
	while(TRUE)
	{
		bRet = FALSE;
		if(bLockType == MF_LOCK_STATUS_MUTEX)
		{
			bRet = SetObjectMutexLock(lpExecutePlan, lpObjectInfo);
		}
		else if(bLockType == MF_LOCK_STATUS_SHARE)
		{
			bRet = SetObjectShareLock(lpExecutePlan, lpObjectInfo);
		}
		else if(bLockType == MF_LOCK_STATUS_NULL)
		{
			bRet = SetObjectNullLock(lpExecutePlan, lpObjectInfo);
		}
		if(bRet)
		{
			break;
		}
		GetSystemTimeAsFileTime((LPFILETIME)&nEnd);
		//转换到毫秒
		dwTime = (DWORD)(nEnd - nStart) / 10000;
		if(dwTime < dwMilliseconds)
		{
			WaitForSingleObject(m_hObjectLockEvent, 1);
		}
		else
		{
			break;
		}
	}
	return bRet;
}

//注意：m_critBlock块临界区的作用是为了保护lpBlockHead->m_bStatus不被多个线程同时修改
//同时：由于所有的线程共享一个m_critBlock块临界区，所以对于lpBlockHead->m_bStatus的修改不能并行，即便是对于不同块的lpBlockHead->m_bStatus的修改该
BOOL CSystemManage::SetBlockLockMutex(LPEXECUTEPLANBSON lpExecutePlan, LPBASEBLOCKHEAD lpBlockHead)
{
	int i;
	LPBLOCKINFO lpBlockInfo;
	CExecutePlanCriticalPtr cs(&m_critBlock, lpExecutePlan);
	if(lpBlockHead->m_bStatus == MF_LOCK_STATUS_NULL || lpBlockHead->m_nTimestamp == lpExecutePlan->m_nTimestamp)
	{
		if(lpBlockHead->m_nTimestamp != lpExecutePlan->m_nTimestamp)
		{
			lpBlockHead->m_nTimestamp = lpExecutePlan->m_nTimestamp;
			lpBlockHead->m_bSaveFlag  = 0;
		}
		lpBlockHead->m_bStatus = MF_LOCK_STATUS_MUTEX;
	}
	else
	{
		//判断锁是否有效
		if(CheckTransactionFinish(lpBlockHead->m_nTimestamp))
		{
			if(lpBlockHead->m_nTimestamp != lpExecutePlan->m_nTimestamp)
			{
				lpBlockHead->m_nTimestamp = lpExecutePlan->m_nTimestamp;
				lpBlockHead->m_bSaveFlag  = 0;
			}
			lpBlockHead->m_bStatus = MF_LOCK_STATUS_MUTEX;
		}
		else
		{
			return FALSE;
		}
	}

	//记录上锁的块
	lpBlockInfo = (LPBLOCKINFO)((LPBYTE)lpExecutePlan + lpExecutePlan->m_stSourceInfo.m_nBlockOffset);
	for(i = 0; i < MF_MAX_BLOCKINFO_NUM; i++)
	{
		if(lpBlockInfo[i].m_nBlockNo == lpBlockHead->m_nBlockNo)
		{
			break;
		}
		else if(lpBlockInfo[i].m_nBlockNo == 0)
		{
			lpBlockInfo[i].m_nBlockNo = lpBlockHead->m_nBlockNo;
			lpExecutePlan->m_stSourceInfo.m_nBlockNoNum++;
			break;
		}
	}
	return TRUE;
}

BOOL CSystemManage::SetIndexLockStatus(LPEXECUTEPLANBSON lpExecutePlan, LPINDEXDEF lpIndexInfo, long long nTimestamp, MF_LOCK_STATUS_TYPE bStatus)
{
	CExecutePlanCriticalPtr cs(&m_critIndex, lpExecutePlan);
	if(lpIndexInfo->m_bStatus == MF_LOCK_STATUS_NULL)
	{
		//无锁状态可以加任意锁
		lpIndexInfo->m_nTimestamp = nTimestamp;
		lpIndexInfo->m_bStatus = bStatus;
		if(bStatus == MF_LOCK_STATUS_SHARE)
		{
			lpIndexInfo->m_nShareNum++;
		}
		return TRUE;
	}
	else if(lpIndexInfo->m_bStatus == MF_LOCK_STATUS_SHARE)
	{
		//共享锁上面可以加共享锁
		if(bStatus == MF_LOCK_STATUS_SHARE)
		{
			lpIndexInfo->m_nTimestamp = nTimestamp;
			lpIndexInfo->m_bStatus = bStatus;
			lpIndexInfo->m_nShareNum++;
			return TRUE;
		}
		else 
		{
			if(lpIndexInfo->m_nTimestamp == nTimestamp)
			{
				lpIndexInfo->m_bStatus = bStatus;
				return TRUE;
			}
			else if(CheckTransactionFinish(lpIndexInfo->m_nTimestamp))
			{
				//如果锁无效，则可以加任意锁
				lpIndexInfo->m_nTimestamp	= nTimestamp;
				lpIndexInfo->m_bStatus		= bStatus;
				return TRUE;
			}
		}
	}
	else if(lpIndexInfo->m_bStatus == MF_LOCK_STATUS_MUTEX)
	{
		//如果是互斥锁，则判断锁是否有效
		if(lpIndexInfo->m_nTimestamp == nTimestamp)
		{
			lpIndexInfo->m_bStatus = bStatus;
			return TRUE;
		}
		else if(CheckTransactionFinish(lpIndexInfo->m_nTimestamp))
		{
			//如果锁无效，则可以加任意锁
			lpIndexInfo->m_nTimestamp	= nTimestamp;
			lpIndexInfo->m_bStatus		= bStatus;
			return TRUE;
		}
	}
	return FALSE;
}

LPBYTE CSystemManage::AllocTemporaryMem(UINT nSize)
{
	LPBYTE lpBuf;
	int nErrorNo;

	lpBuf = AllocTemporaryMemCore(nSize, nErrorNo);
	if(lpBuf != NULL)
	{
		return lpBuf;
	}
	else if(nErrorNo != 1)
	{
		if(!CheckTemporaryMem())
		{
			Sleep(10);
		}
		lpBuf = AllocTemporaryMemCore(nSize, nErrorNo);
	}

	return lpBuf;
}

void CSystemManage::FreeTemporaryMem(LPBYTE lpBuf)
{
	LPTEMPORARYMEMBLOCK lpBlock, lpFreeBlock;
	CCriticalSectionPtr cs(&m_critTemporaryMemory);

	try
	{
		//先做有效性判断
		if(lpBuf < (LPBYTE)m_pTemporaryMemory)
		{
			//不是临时内存范围内的地址，直接调系统的内存释放
			delete [] lpBuf;
			return;
		}

		if(lpBuf > ((LPBYTE)m_pTemporaryMemory) + m_pTemporaryMemory->m_nTotalSize)
		{
			//不是临时内存范围内的地址，直接调系统的内存释放
			delete [] lpBuf;
			return;
		}

		lpBlock = (LPTEMPORARYMEMBLOCK)(lpBuf - sizeof(TEMPORARYMEMBLOCK) + 1);
		//判断有效性
		if(lpBlock->m_bFlag	!= 255)
		{
			assert(0);
			Trace("CSystemManage::FreeTemporaryMem", MF_TRACE_LEVEL_FAILED, 100051001, "内存数据出现错乱，重新初始化临时内存，Flag：%d，Size：%d，Status：%d！", lpBlock->m_bFlag, lpBlock->m_nSize, lpBlock->m_bStatus);
			//尝试查一下最后一个内存块是否正常，挽救最后一个分配的内存块
			if(m_pTemporaryMemory->m_nLastAllocPos != m_pTemporaryMemory->m_nFreePos)
			{
				lpFreeBlock = (LPTEMPORARYMEMBLOCK)(((LPBYTE)m_pTemporaryMemory) + m_pTemporaryMemory->m_nLastAllocPos);
				if(lpFreeBlock->m_bFlag == 255)
				{
					m_pTemporaryMemory->m_nFreePos = m_pTemporaryMemory->m_nLastAllocPos;
					return;
				}
			}

			m_pTemporaryMemory->m_nAllocPos     = m_pTemporaryMemory->m_nHeaderSize;
			m_pTemporaryMemory->m_nLastAllocPos = 0;
			m_pTemporaryMemory->m_nFreePos      = m_pTemporaryMemory->m_nHeaderSize;
			return;
		}
		if(lpBlock->m_bStatus == 1)
		{
			lpBlock->m_bStatus = 0;
		}

		lpFreeBlock = (LPTEMPORARYMEMBLOCK)(((LPBYTE)m_pTemporaryMemory) + m_pTemporaryMemory->m_nFreePos);
		if(lpFreeBlock == lpBlock)
		{
			//开始循环把内存还回去
			while(TRUE)
			{
				if(lpFreeBlock->m_bFlag != 255)
				{
					assert(0);
					Trace("CSystemManage::FreeTemporaryMem", MF_TRACE_LEVEL_FAILED, 100051002, "内存数据出现错乱，重新初始化临时内存，Flag：%d，Size：%d，Status：%d！", lpFreeBlock->m_bFlag, lpFreeBlock->m_nSize, lpFreeBlock->m_bStatus);
					//尝试查一下最后一个内存块是否正常，挽救最后一个分配的内存块
					if(m_pTemporaryMemory->m_nLastAllocPos != m_pTemporaryMemory->m_nFreePos)
					{
						lpFreeBlock = (LPTEMPORARYMEMBLOCK)(((LPBYTE)m_pTemporaryMemory) + m_pTemporaryMemory->m_nLastAllocPos);
						if(lpFreeBlock->m_bFlag == 255)
						{
							m_pTemporaryMemory->m_nFreePos = m_pTemporaryMemory->m_nLastAllocPos;
							continue;
						}
					}

					m_pTemporaryMemory->m_nAllocPos     = m_pTemporaryMemory->m_nHeaderSize;
					m_pTemporaryMemory->m_nLastAllocPos = 0;
					m_pTemporaryMemory->m_nFreePos      = m_pTemporaryMemory->m_nHeaderSize;
					break;
				}
				else if(lpFreeBlock->m_bStatus == 1)
				{
					break;
				}

				if(lpFreeBlock->m_nNextPos == 0)
				{
					//可以直接重新初始化
					m_pTemporaryMemory->m_nAllocPos     = m_pTemporaryMemory->m_nHeaderSize;
					m_pTemporaryMemory->m_nLastAllocPos = 0;
					m_pTemporaryMemory->m_nFreePos      = m_pTemporaryMemory->m_nHeaderSize;
					break;
				}
				else
				{
					m_pTemporaryMemory->m_nFreePos = lpFreeBlock->m_nNextPos;
				}
				lpFreeBlock = (LPTEMPORARYMEMBLOCK)(((LPBYTE)m_pTemporaryMemory) + m_pTemporaryMemory->m_nFreePos);
			}
		}
	}
	catch(...)
	{
		Trace("CSystemManage::FreeTemporaryMem", MF_TRACE_LEVEL_FAILED, 100046001, "释放虚拟表空间异常，错误码：%d", GetLastError());
	}
}

long long CSystemManage::InsertRollBackData(LPBYTE& lpData, int nLen, long long nTimestamp, long long nPreRollbackDataID)
{
	return m_pRollBackMemory->InsertRollBackData(lpData, nLen, nTimestamp, nPreRollbackDataID);
}

int CSystemManage::GetRollBackData(long long nRollBackVarDataID, long long nTimestamp, LPBYTE &lpVarDataAddr, int &nLen)
{
	return m_pRollBackMemory->GetRollBackData(nRollBackVarDataID, nTimestamp, lpVarDataAddr, nLen);
}
int CSystemManage::CheckValidRollBackData(long long nRollBackVarDataID, long long nTimestamp)
{
	return m_pRollBackMemory->CheckDataVaild(nRollBackVarDataID, nTimestamp);
}
int CSystemManage::GetParameterValue(MF_PARAMETER_TYPE nParameterName)
{
	if(m_pMemoryFileHead == NULL)
	{
		Trace("CSystemManage::GetParameterValue", 0, 100060001, ("程序还未初始化完成，无法获取系统参数，参数类型：%d"), nParameterName);
		return 0;
	}
	else if(nParameterName <= 0 || nParameterName >= MF_PARAMETER_TYPE_MAX_COUNT)
	{
		Trace("CSystemManage::GetParameterValue", 0, 100060002, ("无效参数类型，参数类型：%d"), nParameterName);
		return 0;
	}
	else
	{
		int *pParameter;
		pParameter = &m_pMemoryFileHead->m_nServicePort;
		return pParameter[nParameterName - 1];
	}
}

int CSystemManage::StartTransactionLogic(DWORD dwIP, const char * lpszTransactionData, int &lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nPos;
	long long nTimestamp;
	LPLOGICTRANSACTION pNext, pPrev;

	GetSystemTimeAsFileTime((LPFILETIME)&nTimestamp);

	nPos = CalcKeyHash((LPBYTE)lpszTransactionData, m_nTransactionLogicSlotCount);
	if(m_pLogicTransaction == NULL)
	{
		return MF_INNER_POINTER_NULL;
	}
	else
	{
		CCriticalSectionPtr cs(&m_critLogicTransaction);
		//首先比较一下此字符串是否存在
		pPrev = NULL;
		pNext = &m_pLogicTransaction[nPos];
		while(pNext != NULL)
		{
			if(pNext->m_nStartTime != 0)
			{
				//检查是否超时
				if(nTimestamp - pNext->m_nStartTime > m_nTransactionLogicTimeout)
				{
					m_mapLogicTransaction.erase(pNext->m_lTransactionID);
					if(pPrev == NULL)
					{
						//HASH槽里面
						pPrev = pNext->m_pNext;
						memset(pNext, 0, sizeof(LOGICTRANSACTION));
						pNext->m_pNext = pPrev;
						pNext = pNext->m_pNext;
					}
					else
					{
						//直接清除超期的事务锁
						pPrev = pNext->m_pNext;
						delete pNext;
						pNext = pPrev->m_pNext;
					}
					continue;
				}

				if(strcmp(pNext->m_lpszTransactionData, lpszTransactionData) == 0)
				{
					//找到相同的
					return MF_INNER_SYS_TRANSACTIONLOGIC_EXIST_FAILED;
				}
			}
			pPrev = pNext;
			pNext = pNext->m_pNext;
		}

		//加事务锁
		if(m_pLogicTransaction[nPos].m_lTransactionID == 0)
		{
			m_pLogicTransaction[nPos].m_lTransactionID = m_lTransactionID;
			m_pLogicTransaction[nPos].m_nStartTime		= nTimestamp;
			m_pLogicTransaction[nPos].m_pNext			= NULL;
			_tcscpy(m_pLogicTransaction[nPos].m_lpszTransactionData, lpszTransactionData);
			m_mapLogicTransaction.insert(pair<int, LPLOGICTRANSACTION>(m_pLogicTransaction[nPos].m_lTransactionID, &m_pLogicTransaction[nPos]));
			lTransactionID								= m_lTransactionID;
		}
		else
		{
			pNext = new LOGICTRANSACTION;
			memset(pNext, 0, sizeof(LOGICTRANSACTION));
			pNext->m_lTransactionID = m_lTransactionID;
			pNext->m_nStartTime		= nTimestamp;
			pNext->m_pNext			= NULL;
			_tcscpy(pNext->m_lpszTransactionData, lpszTransactionData);
			pPrev->m_pNext			= pNext;
			m_mapLogicTransaction.insert(pair<int, LPLOGICTRANSACTION>(pNext->m_lTransactionID, pNext));
			lTransactionID								= m_lTransactionID;
		}

		//事务锁ID自增加
		m_lTransactionID++;
		if(m_lTransactionID <= 0)
		{
			m_lTransactionID = 1;
		}
	}

	return MF_OK;
}

int CSystemManage::StopTransactionLogic(DWORD dwIP, int lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{
	int nPos;
	map<int, LPLOGICTRANSACTION>::iterator iter;
	LPLOGICTRANSACTION pNext, pPrev, pTransaction;
	CCriticalSectionPtr cs(&m_critLogicTransaction);
	if(m_pLogicTransaction == NULL)
	{
		return MF_INNER_POINTER_NULL;
	}

	pTransaction = NULL;
	iter = m_mapLogicTransaction.find(lTransactionID);
	if(iter == m_mapLogicTransaction.end())
	{
		return MF_OK;
	}
	else
	{
		pTransaction = iter->second;
	}
	if(pTransaction == NULL)
	{
		//事务已经被自动清理了
		return MF_OK;
	}
	else
	{
		m_mapLogicTransaction.erase(lTransactionID);
		nPos = CalcKeyHash((LPBYTE)pTransaction->m_lpszTransactionData, m_nTransactionLogicSlotCount);
		pPrev = NULL;
		pNext = &m_pLogicTransaction[nPos];
		while(pNext != NULL)
		{
			if(pNext->m_lTransactionID == lTransactionID)
			{
				if(pPrev == NULL)
				{
					//HASH槽里面
					pPrev = pNext->m_pNext;
					memset(pNext, 0, sizeof(LOGICTRANSACTION));
					pNext->m_pNext = pPrev;
				}
				else
				{
					//直接清除超期的事务锁
					pPrev = pNext->m_pNext;
					delete pNext;
				}
				return MF_OK;
			}
			pPrev = pNext;
			pNext = pNext->m_pNext;
		}
	}

	return MF_OK;
}

char _INT[32] = "INT";
char _BIGINT[32] = "BIGINT";
char _DOUBLE[32] = "DOUBLE";
char _DATE[32] = "DATE";
char _CHAR[32] = "CHAR";
char _VARCHAR[32] = "VARCHAR";
char _CLOB[32] = "CLOB";
char _BLOB[32] = "BLOB";
//将字段类型ID转换为字段类型字符串
int CSystemManage::ConvertTypeIDtoString(MF_SYS_FIELDTYPE bFieldType, char* &pType)
{
	switch(bFieldType)
	{
	case MF_SYS_FIELDTYPE_INT:
		pType = _INT;
		break;
	case MF_SYS_FIELDTYPE_BIGINT:
		pType = _BIGINT;
		break;
	case MF_SYS_FIELDTYPE_DOUBLE: 
		pType = _DOUBLE;
		break;
	case MF_SYS_FIELDTYPE_DATE:
		pType = _DATE;
		break;
	case MF_SYS_FIELDTYPE_CHAR:
		pType = _CHAR;
		break;
	case MF_SYS_FIELDTYPE_VARCHAR:
		pType = _VARCHAR;
		break;
	case MF_SYS_FIELDTYPE_CLOB:
		pType = _CLOB;
		break;
	case MF_SYS_FIELDTYPE_BLOB:  
		pType = _BLOB;
		break;
	}
	return MF_OK;
}

int CSystemManage::SetParameterValue( MF_PARAMETER_TYPE nParameterName, int nParameterValue )
{
	if(m_pMemoryFileHead == NULL)
	{
		Trace("CSystemManage::GetParameterValue", 0, 100060001, ("程序还未初始化完成，无法获取系统参数，参数类型：%d"), nParameterName);
		return MF_PARSECMD_ALTER_SET_SYSTEM_INIT_ERROR;
	}
	else if(nParameterName <= 0 || nParameterName >= MF_PARAMETER_TYPE_MAX_COUNT)
	{
		Trace("CSystemManage::GetParameterValue", 0, 100060002, ("无效参数类型，参数类型：%d"), nParameterName);
		return MF_PARSECMD_ALTER_SET_SYSTEM_PARAMETERNAME_ERROR;
	}
	else
	{
		long long nTimestamp;
		CSystemTimestampTransactionManage stTransaction;

		nTimestamp = GetSystemTimestamp();
		stTransaction.StartTransaction(nTimestamp);
		
		(&m_pMemoryFileHead->m_nServicePort)[nParameterName - 1] = nParameterValue;
		m_pMemoryFileHead->m_nTimestamp	= nTimestamp;

		stTransaction.CommitTransaction(nTimestamp);
		return MF_OK;
	}
}

int CSystemManage::GetSystemParameter( const char *pStr )
{
	int nVlaue = MF_PARAMETER_UNKNOWN;
	for (int i =0; i < 32; i++)
	{
		if (strcmp(pStr,arrayParameter[i]) == 0)
		{
			nVlaue = i+1;
			break;
		}
		if (strcmp(arrayParameter[i],("")) == 0)
		{
			break;
		}
	}
	return nVlaue;
}

int CSystemManage::LockBlock(LPEXECUTEPLANBSON lpExecutePlan, LPBASEBLOCKHEAD lpBlockHead, DWORD dwMilliseconds)
{
	BOOL bRet;
	DWORD dwTime;
	long long nStart, nEnd;

	GetSystemTimeAsFileTime((LPFILETIME)&nStart);
	while(TRUE)
	{
		bRet = SetBlockLockMutex(lpExecutePlan, lpBlockHead);
		if(bRet)
		{
			break;
		}
		//判断超时
		if(dwMilliseconds == 0)
		{
			break;
		}
		
		GetSystemTimeAsFileTime((LPFILETIME)&nEnd);
		//转换到毫秒
		dwTime = (DWORD)(nEnd - nStart) / 10000;
		if(dwTime < dwMilliseconds)
		{
			WaitForSingleObject(m_hBlockLockEvent, 1);
		}
		else
		{
			break;
		}
	}
	if(bRet)
	{
		return MF_OK;
	}
	else
	{
		return MF_INNER_SYS_SOURCEOCCUPIED_INVALID;
	}
}

void CSystemManage::UnLockBlock(LPEXECUTEPLANBSON lpExecutePlan, LPBASEBLOCKHEAD lpBlockHead)
{
	int i;
	LPBLOCKINFO lpBlockInfo;
	CExecutePlanCriticalPtr cs(&m_critBlock, lpExecutePlan);
	if(lpBlockHead->m_nTimestamp == lpExecutePlan->m_nTimestamp)
	{
		lpBlockHead->m_bStatus = MF_LOCK_STATUS_NULL;
	}

	lpBlockInfo = (LPBLOCKINFO)((LPBYTE)lpExecutePlan + lpExecutePlan->m_stSourceInfo.m_nBlockOffset);
	for(i = 0; i < MF_MAX_BLOCKINFO_NUM; i++)
	{
		if(lpBlockInfo[i].m_nBlockNo == lpBlockHead->m_nBlockNo)
		{
			memset(&lpBlockInfo[i], 0, sizeof(BLOCKINFO));
			lpExecutePlan->m_stSourceInfo.m_nBlockNoNum--;
			break;
		}
	}
	SetEvent(m_hBlockLockEvent);
}

void CSystemManage::UnLockBlock(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, int nBlockNum, LPBLOCKINFO lpBlockInfo)
{
	int i, nRet;
	CMemoryFile* pFile;
	IVirtualMemoryFile* pVirtualFile;

	//获取文件指针
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return;
	}
	pFile = (CMemoryFile*)pVirtualFile;

	for(i = 0; i < nBlockNum; i++)
	{
		if(lpBlockInfo[i].m_nBlockNo != 0)
		{
			pFile->UnlockBlock(lpExecutePlan, lpBlockInfo[i].m_nBlockNo);
		}
	}
}

int CSystemManage::LockObject(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, int nBlockNum, LPBLOCKINFO lpBlockInfo, DWORD dwMilliseconds)
{
	int nRet, i;
	BYTE bLockType;
	CMemoryFile* pFile;
	IVirtualMemoryFile* pVirtualFile;

	//获取文件指针
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVirtualFile;

	//给Object加共享锁
	if(nBlockNum >= 10)
	{
		bLockType = MF_LOCK_STATUS_MUTEX;		//互斥锁
	}
	else
	{
		bLockType = MF_LOCK_STATUS_SHARE;
	}

	if(!SetObjectLock(lpExecutePlan, lpObjectInfo, bLockType, dwMilliseconds))
	{
		return MF_INNER_SYS_SOURCEOCCUPIED_INVALID;
	}
	//对于共享锁需要在块上逐个添加块级别的互斥锁
	//对于对象级别的互斥锁，不需要在块级别上锁
	if(bLockType == MF_LOCK_STATUS_SHARE)
	{
		for(i = 0; i < nBlockNum; i++)
		{
			if(lpBlockInfo[i].m_nBlockNo != 0)
			{
				nRet = pFile->LockBlock(lpExecutePlan, lpBlockInfo[i].m_nBlockNo, dwMilliseconds);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
		}
	}
	return MF_OK;
}

//给对象上锁
int CSystemManage::LockObject(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, MF_LOCK_STATUS_TYPE bLockType, DWORD dwMilliseconds)
{
	BOOL bRet;
	DWORD dwTime;
	long long nStart, nEnd;

	GetSystemTimeAsFileTime((LPFILETIME)&nStart);
	while(TRUE)
	{
		bRet = FALSE;
		if(bLockType == MF_LOCK_STATUS_MUTEX)
		{
			bRet = SetObjectMutexLock(lpExecutePlan, lpObjectInfo);
		}
		else if(bLockType == MF_LOCK_STATUS_SHARE)
		{
			bRet = SetObjectShareLock(lpExecutePlan, lpObjectInfo);
		}
		else if(bLockType == MF_LOCK_STATUS_NULL)
		{
			bRet = SetObjectNullLock(lpExecutePlan, lpObjectInfo);
		}
		if(bRet)
		{
			return MF_OK;
		}
		GetSystemTimeAsFileTime((LPFILETIME)&nEnd);
		//转换到毫秒
		dwTime = (DWORD)(nEnd - nStart) / 10000;
		if(dwTime < dwMilliseconds)
		{
			WaitForSingleObject(m_hObjectLockEvent, 1);
		}
		else
		{
			break;
		}
	}
	return MF_INNER_SYS_SOURCEOCCUPIED_INVALID;
}

void CSystemManage::UnLockObject(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, int nBlockNum, LPBLOCKINFO lpBlockInfo)
{
	int i, nRet;
	CMemoryFile* pFile;
	IVirtualMemoryFile* pVirtualFile;

	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
	if(nRet != MF_OK)
	{
		return;
	}
	pFile = (CMemoryFile*)pVirtualFile;

	CExecutePlanCriticalPtr cs(&m_critDataObject, lpExecutePlan);
	try
	{
		if(lpObjectInfo->m_bStatus == MF_LOCK_STATUS_MUTEX)
		{
			if(lpObjectInfo->m_lpTimestampArray[0] == lpExecutePlan->m_nTimestamp)
			{
				lpObjectInfo->m_bStatus = MF_LOCK_STATUS_NULL;
				lpObjectInfo->m_lpTimestampArray[0] = 0;
			}
		}
		else if(lpObjectInfo->m_bStatus == MF_LOCK_STATUS_SHARE)
		{
			for(i = 0; i < nBlockNum; i++)
			{
				if(lpBlockInfo[i].m_nBlockNo != 0)
				{
					pFile->UnlockBlock(lpExecutePlan, lpBlockInfo[i].m_nBlockNo);
				}
			}
		}

		SetEvent(m_hObjectLockEvent);
	}
	catch(...)
	{

	}
}

int CSystemManage::LockIndex(LPEXECUTEPLANBSON lpExecutePlan, LPINDEXDEF lpIndexInfo, MF_LOCK_STATUS_TYPE bStatus, DWORD dwMilliseconds, long long nTimestamp)
{
	BOOL bRet;
	DWORD dwTime;
	long long nStart, nEnd;

	GetSystemTimeAsFileTime((LPFILETIME)&nStart);
	while(TRUE)
	{
		bRet = SetIndexLockStatus(lpExecutePlan, lpIndexInfo, nTimestamp, bStatus);
		if(bRet)
		{
			break;
		}
		//判断超时
		if(dwMilliseconds == 0)
		{
			break;
		}

		GetSystemTimeAsFileTime((LPFILETIME)&nEnd);
		//转换到毫秒
		dwTime = (DWORD)(nEnd - nStart) / 10000;
		if(dwTime < dwMilliseconds)
		{
			WaitForSingleObject(m_hIndexLockEvent, 1);
		}
		else
		{
			break;
		}
	}
	if(bRet)
	{
		return MF_OK;
	}
	else
	{
		return MF_INNER_SYS_SOURCEOCCUPIED_INVALID;
	}
}

void CSystemManage::UnLockIndex(LPEXECUTEPLANBSON lpExecutePlan, LPINDEXDEF lpIndexInfo)
{
	try
	{
		CExecutePlanCriticalPtr cs(&m_critIndex, lpExecutePlan);
		if(lpIndexInfo->m_bStatus == MF_LOCK_STATUS_SHARE)
		{
			lpIndexInfo->m_nShareNum--;
			if(lpIndexInfo->m_nShareNum == 0)
			{
				lpIndexInfo->m_bStatus = MF_LOCK_STATUS_NULL;
			}
		}
		else
		{
			lpIndexInfo->m_bStatus = MF_LOCK_STATUS_NULL;
		}
		SetEvent(m_hIndexLockEvent);
	}
	catch (...)
	{
	}
}

BOOL CSystemManage::CmpMemDBFileName( LPCTSTR lpszMemFileName, LPMEMDBFILEDEF lpszDBFilePath)
{
	string strMemFileName;
	if(lpszMemFileName == NULL)
	{
		return FALSE;
	}
	if(_tcsicmp(lpszMemFileName, lpszDBFilePath->m_lpszFilePath) == 0)
	{
		return TRUE;
	}
	else
	{
		if(MF_OK == CreateMemDBFileName(lpszMemFileName,strMemFileName))
		{
			if (_tcsicmp(strMemFileName.c_str(), lpszDBFilePath->m_lpszMemFileName) == 0)
			{
				return TRUE;
			}
		}
	}
	return FALSE;
}

void CSystemManage::InitCharCompare(LPBYTE lpBuffer, int nSize)
{
	if(m_pCharCompare == NULL)
	{
		m_pCharCompare = new CCharCompare;
	}
	m_pCharCompare->InitPinYin(lpBuffer, nSize);
}


int CSystemManage::CharCompare(const char * pSrc, int nSrcLen, const char * pDet, int nDesLen, BOOL bMatch)
{
	if(m_pCharCompare == NULL)
	{
		Trace0("CharCompare", 0, 100000020, ("Compare类指针为空"));
		return strcmp(pSrc, pDet);
	}
	else
	{
		return m_pCharCompare->Compare(pSrc, nSrcLen, pDet, nDesLen, m_pMemoryFileHead->m_nServerCaseSensitive, bMatch);
	}
}

int CSystemManage::CharFind(const char *pSrc, const int nSrcLen, const char *pPat, const int nPatLen)
{
	if(nPatLen <= 0)
	{
		return -1;
	}
	else
	{
		if(pPat[nPatLen - 1] != 0)
		{
			return SubStringFind(pSrc, nSrcLen, pPat, nPatLen, m_pMemoryFileHead->m_nServerCaseSensitive);
		}
		else
		{
			int nLen;
			nLen = nPatLen - 1;
			while(pPat[nLen] == 0 && nLen > 0)
			{
				nLen--;
			}
			while(nLen > 0 && pPat[nLen] == MF_OPERATOR_PERCENT && pPat[nLen - 1] == MF_OPERATOR_PERCENT)
			{
				nLen--;
			}
			nLen++;
			if(pPat[nLen] != 0)
			{
				((char *)pPat)[nLen] = 0;
			}
			return SubStringFind(pSrc, nSrcLen, pPat, nLen, m_pMemoryFileHead->m_nServerCaseSensitive);
		}
	}
}

//获取Session的数量
int CSystemManage::GetSeccionNum()
{
	LPVOID lpPos, lpValue;
	int nCount, nSessionID;
	lpPos = m_mapSession.GetHeadPosition();

	nCount = 0;
	while(lpPos)
	{
		m_mapSession.GetNext(lpPos, nSessionID, lpValue);
		if(lpValue != NULL)
		{
			nCount++;
		}
	}

	return nCount;
}

int CSystemManage::FlashBack(BYTE bFileNo, int nBlockNo, LPBYTE& lpBuffer, long long nTimestamp)
{
	int nRet;
	CMemoryFile* pFile;
	IVirtualMemoryFile* pVritualFile;

	nRet = GetMemoryFileInstance(bFileNo, pVritualFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pVritualFile;

	return pFile->FlashBack(nBlockNo, lpBuffer, nTimestamp);
}

int CSystemManage::Paging(long long nBufferNo, CDataIDContainer* pDataIDContainer, int nPageDataNum)
{
	return m_pPageManager->Paging(nBufferNo, pDataIDContainer, nPageDataNum);
}

int CSystemManage::GetPage(long long nBufferNo, int nPageNo, int nPageDataNum, CDataIDContainer* pDataIDContainer)
{
	return m_pPageManager->GetPage(nBufferNo, nPageNo, nPageDataNum, pDataIDContainer);
}

#ifdef WIN32
unsigned int __stdcall CSystemManage::MemStorageThread(LPVOID lpParam)
#else
void* CSystemManage::MemStorageThread(LPVOID lpParam)
#endif
{
	//参数
	int nDelayTime;
	CSystemManage *pThis;
	DWORD dwHeadBufferSize;
	LPOBJECTDEF lpObjectInfo;
	LPBYTE pBuffer, pFileAddr;
	LPBASEFILEHEAD pBaseFileHead;
	IVirtualMemoryFile* pVirtualFile;
	long long nMapSize, nMapBlockOffset;
	LPSTORAGEMEMHEAD pStorageMemFileHead;
	LPBASEFILEBLOCKMAPHEAD pSlaveBaseFileBlockMapHead, pMasterBaseFileBlockMapHead;

	pThis = (CSystemManage *)lpParam;
	pStorageMemFileHead = pThis->m_pStorageMemFileHead;

	pBuffer = NULL;

	lpObjectInfo = (LPOBJECTDEF)pThis->m_mapObject.Get(pStorageMemFileHead->m_nObjectNo);
	if(lpObjectInfo == NULL)
	{
		Trace("CSystemManage::MemStorageThread", MF_TRACE_LEVEL_FAILED, 100300001, "%d", pStorageMemFileHead->m_nObjectNo);
#ifdef WIN32
		return MF_SYS_OBJECT_NOTEXIST;
#else
		return (void*)MF_SYS_OBJECT_NOTEXIST;
#endif
	}
	if(lpObjectInfo == NULL)
	{
		Trace("CSystemManage::MemStorageThread", MF_TRACE_LEVEL_FAILED, 100300001, "%d", pStorageMemFileHead->m_nObjectNo);
#ifdef WIN32
		return MF_SYS_OBJECT_NOTEXIST;
#else
		return (void*)MF_SYS_OBJECT_NOTEXIST;
#endif
	}
	nDelayTime = pStorageMemFileHead->m_nCycleTime;
	//启动成功
	pStorageMemFileHead->m_bServer = 1;
	Trace0(("MemStorageThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 100300002, ("MemStorageThread线程启动！"));
	//干活的地方
	while(TRUE)
	{
		Sleep(nDelayTime);

		if (pStorageMemFileHead->m_bCommandType == MF_STORAGEMEM_COMMAND_FLASHBACK)
		{
			//调用闪回
			pBuffer = pThis->m_lpStorageMemFileAddr + pStorageMemFileHead->m_nBakBlockOffset;
			pStorageMemFileHead->m_nResult = pThis->FlashBack(pStorageMemFileHead->m_bFileNo, pStorageMemFileHead->m_nBlockNo, pBuffer, pStorageMemFileHead->m_nTimestamp);
			pStorageMemFileHead->m_bCommandType = MF_STORAGEMEM_COMMAND_NO;
		}
		else if (pStorageMemFileHead->m_bCommandType == MF_STORAGEMEM_COMMAND_COPYMAP)
		{
			//备份映射表
			//给对象链表上锁
			pBuffer = pThis->m_lpStorageMemFileAddr + pStorageMemFileHead->m_nBakFileHeadOffset;
			pStorageMemFileHead->m_nResult = 0;

			if(pStorageMemFileHead->m_bFileNo == 1)
			{
				pBaseFileHead = (LPBASEFILEHEAD)pThis->m_pMemoryFileHead;

				if(pBaseFileHead->m_nFileHeaderSize > MF_STORAGEMEM_BLOCK_SIZE)
				{
					pStorageMemFileHead->m_nResult = MF_FLASHBACK_INVALID_BUFFER_SIZE;
					Trace(("MemStorageThread"), MF_TRACE_LEVEL_FAILED, 100300003, ("系统文件头大小异常，文件头大小：%d，缓存大小：%d"),
						pBaseFileHead->m_nFileHeaderSize, MF_STORAGEMEM_BLOCK_SIZE);
					pStorageMemFileHead->m_bCommandType = MF_STORAGEMEM_COMMAND_NO;
					continue;
				}
				else
				{
					//先备份文件头
					memcpy(pBuffer, (char*)pBaseFileHead, pBaseFileHead->m_nFileHeaderSize);

					pFileAddr = (LPBYTE)(pBaseFileHead);
					pMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(pFileAddr + pBaseFileHead->m_nBlockMapStartOffset);
					nMapSize = pStorageMemFileHead->m_nMapSize;
					pSlaveBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(pFileAddr + pBaseFileHead->m_nBlockMapStartOffset + nMapSize);

					nMapBlockOffset = pBaseFileHead->m_nBlockMapStartOffset;

					while(TRUE)
					{
						dwHeadBufferSize = sizeof(BASEFILEBLOCKMAPHEAD) + pBaseFileHead->m_nBlockMapStructSize*(pMasterBaseFileBlockMapHead->m_nBlockMapNum - 1);

						//检测映射表大小
						if (dwHeadBufferSize > (DWORD)nMapSize)
						{
							//映射表大小超出范围
							Trace(("MemStorageThread"), MF_TRACE_LEVEL_FAILED, 100300004, ("检测到映射表大小超出允许范围，文件编号：%d，映射表位置偏移：%d，映射表使用大小：%d，映射表大小最大值：%d"),
								pBaseFileHead->m_bFileNo, nMapBlockOffset, dwHeadBufferSize, nMapSize);

							pStorageMemFileHead->m_nResult = MF_FLASHBACK_INVALID_MAP_SIZE;
							break;
						}

						//将主映射表复制到备映射表
						memcpy(pSlaveBaseFileBlockMapHead, pMasterBaseFileBlockMapHead, dwHeadBufferSize);

						if(pMasterBaseFileBlockMapHead->m_nNextBlockMapOffset == 0)
						{
							break;
						}
						else
						{
							//指向下一个映射表区
							nMapBlockOffset = pMasterBaseFileBlockMapHead->m_nNextBlockMapOffset;
							//主映射表
							pMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(pFileAddr + nMapBlockOffset);
							//备映射表
							pSlaveBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(pFileAddr + nMapBlockOffset + nMapSize);
						}
					}
				}
				pStorageMemFileHead->m_bCommandType = MF_STORAGEMEM_COMMAND_NO;
			} 
			else
			{
				pStorageMemFileHead->m_nResult = pThis->GetMemoryFileInstance(pStorageMemFileHead->m_bFileNo, pVirtualFile);
				if(pStorageMemFileHead->m_nResult != MF_OK)
				{
					Trace(("MemStorageThread"), MF_TRACE_LEVEL_FAILED, 100300005, ("获取对应文件数据失败，错误码：%d，文件编号：%d"),
						pStorageMemFileHead->m_nResult, pBaseFileHead->m_bFileNo);
					pStorageMemFileHead->m_bCommandType = MF_STORAGEMEM_COMMAND_NO;
					continue;
				}
				pBaseFileHead = pVirtualFile->GetFileHead();

				pStorageMemFileHead->m_nResult = pVirtualFile->BackUpFileData(pBuffer, MF_STORAGEMEM_BLOCK_SIZE);
				pStorageMemFileHead->m_bCommandType = MF_STORAGEMEM_COMMAND_NO;
			}
		}

		if (pThis->m_bExit == TRUE)
		{
			break;
		}
	}
	pStorageMemFileHead->m_bServer = 0;
	Trace0(("MemStorageThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 100300099, ("MemStorageThread线程退出！"));

	//_endthreadex(NULL);
	return 0;
}

int CSystemManage::ReLoadSysObject()
{
	//清除一些数据然后重新载入
	{
		int i, nID;
		char* pName;
		string strTemp;
		LPINDEXDEF lpIndex;
		LPOBJECTDEF lpObject;
		LPVOID lpPos, lpValue;
		LPUSERINFODEF lpUserInfo;
		LPSEQUENCEDEF lpSequence;
		LPAUTHORITYINFO lpAuthorityInfo;

		//释放所有的数据空间
		m_mapIndex.Clear();
		m_mapObject.Clear();

		lpPos = m_mapName2Object.GetHeadPosition();
		while(lpPos != NULL)
		{
			m_mapName2Object.GetNext(lpPos, pName, lpValue);
			if(lpValue != NULL)
			{
				lpObject = (LPOBJECTDEF)lpValue;
			}
			else
			{
				continue;
			}
			//删除索引信息
			lpIndex = lpObject->m_lpIndex;
			while(lpIndex != NULL)
			{
				lpObject->m_lpIndex = lpIndex->m_pNext;
				delete lpIndex;
				lpIndex = lpObject->m_lpIndex;
			}
			delete [] lpObject->m_lpField;
			delete lpObject;
		}
		m_mapName2Object.Clear();

		lpPos = m_mapSequence.GetHeadPosition();
		while(lpPos)
		{
			m_mapSequence.GetNext(lpPos, pName, lpValue);
			if(lpValue != NULL)
			{
				lpSequence = (LPSEQUENCEDEF)lpValue;
				delete lpSequence;
			}
		}
		m_mapSequence.Clear();
		m_mapBlock.Clear();

		for(i = 0;i < 256;i++)
		{
			if(m_arMemDBFile[i] != NULL)
			{
				CloseMemDBFile(m_arMemDBFile[i]);
				delete m_arMemDBFile[i];
				m_arMemDBFile[i] = NULL;
			}
		}

		lpPos = m_mapAuthority.GetHeadPosition();
		while(lpPos)
		{
			m_mapAuthority.GetNext(lpPos, nID, lpValue);
			if(lpValue != NULL)
			{
				lpAuthorityInfo = (LPAUTHORITYINFO)lpValue;
				delete lpAuthorityInfo;
			}
		}
		m_mapAuthority.Clear();
		m_mapName2Authority.Clear();

		lpPos = m_mapUserInfo.GetHeadPosition();
		while(lpPos)
		{
			m_mapUserInfo.GetNext(lpPos, nID, lpValue);
			if(lpValue != NULL)
			{
				lpUserInfo = (LPUSERINFODEF)lpValue;
				delete lpUserInfo;
			}
		}
		m_mapUserInfo.Clear();
		m_mapName2UserInfo.Clear();
	}

	//重新载入数据
	{
		BYTE bi;
		int nRet, nID;
		LPOBJECTDEF lpObject;
		long long nDataOffset;
		LPVOID lpPos, lpValue;
		map<string, int>::iterator iter;
		LPSYSTEMBLOCKHEAD lpSystemBlockHead;
		LPBASEFILEBLOCKMAP lpBaseFileBlockMap;

		//初始化系统文件对象
		lpObject = new OBJECTDEF;
		lpObject->m_nDataID   = 0;
		lpObject->m_bObjectType = MF_OBJECT_COMMON;
		lpObject->m_bFileNo   = MF_SYS_OBJECTTYPE_FILE;
		lpObject->m_nFieldNum = 9;
		lpObject->m_nObjectID = MF_SYS_OBJECTTYPE_FILE;
		_tcscpy(lpObject->m_lpszName, "V$DATAFILE");
		lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
		lpObject->m_lpField = new OBJECTFIELDDEF[lpObject->m_nFieldNum];
		memset(lpObject->m_lpField, 0, sizeof(OBJECTFIELDDEF) * lpObject->m_nFieldNum);
		lpObject->InitalMap();
		//内部编号
		lpObject->m_lpField[0].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[0].m_lpszName, "INNERNO");
		//文件编号
		lpObject->m_lpField[1].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[1].m_lpszName, "FILENO");
		//文件类型
		lpObject->m_lpField[2].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[2].m_lpszName, "FILETYPE");
		//文件路径
		lpObject->m_lpField[3].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[3].m_lpszName, "FILEPATH");
		//内存文件名
		lpObject->m_lpField[4].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[4].m_lpszName, "MEMFILENAME");
		//文件大小
		lpObject->m_lpField[5].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
		_tcscpy(lpObject->m_lpField[5].m_lpszName, "FILESIZE");
		//剩余大小
		lpObject->m_lpField[6].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
		_tcscpy(lpObject->m_lpField[6].m_lpszName, "FREESIZE");
		//已用大小
		lpObject->m_lpField[7].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
		_tcscpy(lpObject->m_lpField[7].m_lpszName, "USEDSIZE");
		//加载大小
		lpObject->m_lpField[8].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
		_tcscpy(lpObject->m_lpField[8].m_lpszName, "LOADSIZE");
		for(bi = 0;bi < lpObject->m_nFieldNum;bi++)
		{
			lpObject->m_lpField[bi].m_bAllowNull     = 1;
			lpObject->m_lpField[bi].m_bObjectFieldNo = bi+1;
			lpObject->m_mapName2FieldNo.Set(lpObject->m_lpField[bi].m_lpszName, (LPVOID)lpObject->m_lpField[bi].m_bObjectFieldNo);
		}
		m_mapObject.Set(lpObject->m_nObjectID, lpObject);
		m_mapName2Object.Set(lpObject->m_lpszName, lpObject);

		//加载文件数据
		if(m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nID == MF_SYS_OBJECTTYPE_FILE)
		{
			//读取文件数据信息
			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFullBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadMemDBFileData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}

			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFreeBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadMemDBFileData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}
		}

		//初始化系统对象表
		lpObject = new OBJECTDEF;
		lpObject->m_nDataID   = 0;
		lpObject->m_bObjectType = MF_OBJECT_COMMON;
		lpObject->m_bFileNo   = MF_SYS_OBJECTTYPE_FILE;
		lpObject->m_nFieldNum = 9;
		lpObject->m_nObjectID = MF_SYS_OBJECTTYPE_OBJECT;
		_tcscpy(lpObject->m_lpszName, ("V$OBJECT"));
		lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
		lpObject->m_lpField = new OBJECTFIELDDEF[lpObject->m_nFieldNum];
		memset(lpObject->m_lpField, 0, sizeof(OBJECTFIELDDEF) * lpObject->m_nFieldNum);
		lpObject->InitalMap();
		//数据ID
		lpObject->m_lpField[0].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
		_tcscpy(lpObject->m_lpField[0].m_lpszName, "DATAID");
		//对象ID
		lpObject->m_lpField[1].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[1].m_lpszName, "OBJECTID");
		//对象名
		lpObject->m_lpField[2].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[2].m_lpszName, "OBJECTNAME");
		//块大小
		lpObject->m_lpField[3].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[3].m_lpszName, "BLOCKSIZE");
		//存储文件编号
		lpObject->m_lpField[4].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[4].m_lpszName, "FILENO");
		//列数
		lpObject->m_lpField[5].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[5].m_lpszName, "FIELDNUM");
		//实现类
		lpObject->m_lpField[6].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[6].m_lpszName, "IMPLEMENTCLASS");
		//文件名
		lpObject->m_lpField[7].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[7].m_lpszName, "FILENAME");
		//文件类型
		lpObject->m_lpField[8].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[8].m_lpszName, "FILETYPE");
		for(bi = 0;bi < lpObject->m_nFieldNum;bi++)
		{
			lpObject->m_lpField[bi].m_bAllowNull     = 1;
			lpObject->m_lpField[bi].m_bObjectFieldNo = bi+1;
			lpObject->m_mapName2FieldNo.Set(lpObject->m_lpField[bi].m_lpszName, (LPVOID)lpObject->m_lpField[bi].m_bObjectFieldNo);
		}
		m_mapObject.Set(lpObject->m_nObjectID, lpObject);
		m_mapName2Object.Set(lpObject->m_lpszName, lpObject);

		//初始化系统对象列表
		lpObject = new OBJECTDEF;
		lpObject->m_nDataID   = 0;
		lpObject->m_bObjectType = MF_OBJECT_COMMON;
		lpObject->m_bFileNo   = MF_SYS_OBJECTTYPE_FILE;
		lpObject->m_nFieldNum = 5;
		lpObject->m_nObjectID = MF_SYS_OBJECTTYPE_FIELD;
		_tcscpy(lpObject->m_lpszName, "V$COLUMN");
		lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
		lpObject->m_lpField = new OBJECTFIELDDEF[lpObject->m_nFieldNum];
		memset(lpObject->m_lpField, 0, sizeof(OBJECTFIELDDEF) * lpObject->m_nFieldNum);
		lpObject->InitalMap();
		//对象名
		lpObject->m_lpField[0].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[0].m_lpszName, "OBJECTNAME");
		//列名
		lpObject->m_lpField[1].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[1].m_lpszName, "FIELDNAME");
		//列类型
		lpObject->m_lpField[2].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[2].m_lpszName, "FIELDTYPE");
		//长度
		lpObject->m_lpField[3].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[3].m_lpszName, "DATALENGTH");
		//非空
		lpObject->m_lpField[4].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[4].m_lpszName, "NOTNULL");
		for(bi = 0;bi < lpObject->m_nFieldNum;bi++)
		{
			lpObject->m_lpField[bi].m_bAllowNull     = 1;
			lpObject->m_lpField[bi].m_bObjectFieldNo = bi+1;
			lpObject->m_mapName2FieldNo.Set(lpObject->m_lpField[bi].m_lpszName, (LPVOID)lpObject->m_lpField[bi].m_bObjectFieldNo);
		}
		m_mapObject.Set(lpObject->m_nObjectID, lpObject);
		m_mapName2Object.Set(lpObject->m_lpszName, lpObject);

		//加载对象数据
		if(m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_OBJECT].m_nID == MF_SYS_OBJECTTYPE_OBJECT)
		{
			//读取文件数据信息
			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_OBJECT].m_nFullBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadObjectData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}

			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_OBJECT].m_nFreeBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadObjectData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}
		}

		//初始化系统索引表
		lpObject = new OBJECTDEF;
		lpObject->m_nDataID   = 0;
		lpObject->m_bObjectType = MF_OBJECT_COMMON;
		lpObject->m_bFileNo   = MF_SYS_OBJECTTYPE_FILE;
		lpObject->m_nFieldNum = 9;
		lpObject->m_nObjectID = MF_SYS_OBJECTTYPE_INDEX;
		_tcscpy(lpObject->m_lpszName, "V$INDEX");
		lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
		lpObject->m_lpField = new OBJECTFIELDDEF[lpObject->m_nFieldNum];
		memset(lpObject->m_lpField, 0, sizeof(OBJECTFIELDDEF) * lpObject->m_nFieldNum);
		lpObject->InitalMap();
		//数据ID
		lpObject->m_lpField[0].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
		_tcscpy(lpObject->m_lpField[0].m_lpszName, "DATAID");
		//对象ID
		lpObject->m_lpField[1].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[1].m_lpszName, "OBJECTNAME");
		//索引名
		lpObject->m_lpField[2].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[2].m_lpszName, "INDEXNAME");
		//索引字段
		lpObject->m_lpField[3].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[3].m_lpszName, "INDEXFIELD");
		//索引类型
		lpObject->m_lpField[4].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[4].m_lpszName, "INDEXTYPE");
		//索引结构
		lpObject->m_lpField[5].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[5].m_lpszName, "INDEXSTRUCT");
		//块大小
		lpObject->m_lpField[6].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[6].m_lpszName, "BLOCKSIZE");
		//索引文件名
		lpObject->m_lpField[7].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[7].m_lpszName, "INDEXFILENAME");
		//索引文件类型
		lpObject->m_lpField[8].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[8].m_lpszName, "INDEXFILETYPE");
		for(bi = 0;bi < lpObject->m_nFieldNum;bi++)
		{
			lpObject->m_lpField[bi].m_bAllowNull     = 1;
			lpObject->m_lpField[bi].m_bObjectFieldNo = bi+1;
			lpObject->m_mapName2FieldNo.Set(lpObject->m_lpField[bi].m_lpszName, (LPVOID)lpObject->m_lpField[bi].m_bObjectFieldNo);
		}
		m_mapObject.Set(lpObject->m_nObjectID, lpObject);
		m_mapName2Object.Set(lpObject->m_lpszName, lpObject);
		//加载索引数据
		if(m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_INDEX].m_nID == MF_SYS_OBJECTTYPE_INDEX)
		{
			//读取文件数据信息
			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_INDEX].m_nFullBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadIndexData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}

			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_INDEX].m_nFreeBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadIndexData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}
		}

		//初始化系统索引表
		lpObject = new OBJECTDEF;
		lpObject->m_nDataID   = 0;
		lpObject->m_bObjectType = MF_OBJECT_COMMON;
		lpObject->m_bFileNo   = MF_SYS_OBJECTTYPE_FILE;
		lpObject->m_nFieldNum = 8;
		lpObject->m_nObjectID = MF_SYS_OBJECTTYPE_SEQUENCE;
		_tcscpy(lpObject->m_lpszName, "V$SEQUENCE");
		lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
		lpObject->m_lpField = new OBJECTFIELDDEF[lpObject->m_nFieldNum];
		memset(lpObject->m_lpField, 0, sizeof(OBJECTFIELDDEF) * lpObject->m_nFieldNum);
		lpObject->InitalMap();
		//数据ID
		lpObject->m_lpField[0].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
		_tcscpy(lpObject->m_lpField[0].m_lpszName, "DATAID");
		//序列名
		lpObject->m_lpField[1].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[1].m_lpszName, "SEQNAME");
		//最小值
		lpObject->m_lpField[2].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
		_tcscpy(lpObject->m_lpField[2].m_lpszName, "MINVAL");
		//最大值
		lpObject->m_lpField[3].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
		_tcscpy(lpObject->m_lpField[3].m_lpszName, "MAXVAL");
		//增量
		lpObject->m_lpField[4].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[4].m_lpszName, "INCREMENTBY");
		//当前值
		lpObject->m_lpField[5].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[5].m_lpszName, "CURRENTVAL");
		//缓存数量
		lpObject->m_lpField[6].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[6].m_lpszName, "CACHEFLAG");
		//循环标志
		lpObject->m_lpField[7].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[7].m_lpszName, "CYCLEFLAG");

		for(bi = 0;bi < lpObject->m_nFieldNum;bi++)
		{
			lpObject->m_lpField[bi].m_bAllowNull     = 1;
			lpObject->m_lpField[bi].m_bObjectFieldNo = bi+1;
			lpObject->m_mapName2FieldNo.Set(lpObject->m_lpField[bi].m_lpszName, (LPVOID)lpObject->m_lpField[bi].m_bObjectFieldNo);
		}
		m_mapObject.Set(lpObject->m_nObjectID, lpObject);
		m_mapName2Object.Set(lpObject->m_lpszName, lpObject);
		//加载序列数据
		if(m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_SEQUENCE].m_nID == MF_SYS_OBJECTTYPE_SEQUENCE)
		{
			//读取文件数据信息
			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_SEQUENCE].m_nFullBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadSequenceData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}

			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_SEQUENCE].m_nFreeBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadSequenceData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}
		}

		lpPos = m_mapObject.GetHeadPosition();
		while(lpPos != NULL)
		{
			m_mapObject.GetNext(lpPos, nID, lpValue);
			if(lpValue != NULL)
			{
				lpObject = (LPOBJECTDEF)lpValue;
				SortObjectIndex(lpObject);
			}
		}
		
		//初始化系统用户对象
		lpObject = new OBJECTDEF;
		lpObject->m_nDataID		= 0;
		lpObject->m_bObjectType = MF_OBJECT_COMMON;
		lpObject->m_bFileNo		= MF_SYS_OBJECTTYPE_FILE;
		lpObject->m_nFieldNum	= 11;
		lpObject->m_nObjectID	= MF_SYS_OBJECTTYPE_USERINFO;
		_tcscpy(lpObject->m_lpszName, "V$USER");
		lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
		lpObject->m_lpField = new OBJECTFIELDDEF[lpObject->m_nFieldNum];
		memset(lpObject->m_lpField, 0, sizeof(OBJECTFIELDDEF) * lpObject->m_nFieldNum);
		lpObject->InitalMap();

		//用户ID
		lpObject->m_lpField[0].m_bFieldType     = MF_SYS_FIELDTYPE_BIGINT;
		_tcscpy(lpObject->m_lpField[0].m_lpszName, "USERID");
		//用户状态
		lpObject->m_lpField[1].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[1].m_lpszName, "STATUS");
		//用户名
		lpObject->m_lpField[2].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[2].m_lpszName, "USERNAME");
		//用户密码
		lpObject->m_lpField[3].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[3].m_lpszName, "PASSWORD");
		//DBA权限
		lpObject->m_lpField[4].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[4].m_lpszName, "DBA_PRIV");
		//系统修改权限
		lpObject->m_lpField[5].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[5].m_lpszName, "ALTERSYSTEM_PRIV");
		//创建对象表权限
		lpObject->m_lpField[6].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[6].m_lpszName, "CREATEOBJECT_PRIV");
		//修改对象表权限
		lpObject->m_lpField[7].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[7].m_lpszName, "ALTEROBJECT_PRIV");
		//删除对象表权限
		lpObject->m_lpField[8].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[8].m_lpszName, "DROPOBJECT_PRIV");
		//创建序列权限
		lpObject->m_lpField[9].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[9].m_lpszName, "CREATESEQUENCE_PRIV");
		//删除序列权限
		lpObject->m_lpField[10].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[10].m_lpszName, "DROPSEQUENCE_PRIV");
		for(bi = 0;bi < lpObject->m_nFieldNum;bi++)
		{
			lpObject->m_lpField[bi].m_bAllowNull     = 1;
			lpObject->m_lpField[bi].m_bObjectFieldNo = bi+1;
			lpObject->m_mapName2FieldNo.Set(lpObject->m_lpField[bi].m_lpszName, (LPVOID)lpObject->m_lpField[bi].m_bObjectFieldNo);
		}
		m_mapObject.Set(lpObject->m_nObjectID, lpObject);
		m_mapName2Object.Set(lpObject->m_lpszName, lpObject);

		//加载用户数据
		if(m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_USERINFO].m_nID == MF_SYS_OBJECTTYPE_USERINFO)
		{
			//读取用户数据信息
			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_USERINFO].m_nFullBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadUserData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}

			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_USERINFO].m_nFreeBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadUserData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}
		}

		//初始化系统权限对象
		lpObject = new OBJECTDEF;
		lpObject->m_nDataID		= 0;
		lpObject->m_bObjectType = MF_OBJECT_COMMON;
		lpObject->m_bFileNo		= MF_SYS_OBJECTTYPE_FILE;
		lpObject->m_nFieldNum	= 3;
		lpObject->m_nObjectID	= MF_SYS_OBJECTTYPE_AUTHORITY;
		_tcscpy(lpObject->m_lpszName, "V$AUTHORITY");
		lpObject->m_bImplementClass = MF_MEMOBJECT_IMPLEMENTCLASS_SYSTEM;
		lpObject->m_lpField = new OBJECTFIELDDEF[lpObject->m_nFieldNum];
		memset(lpObject->m_lpField, 0, sizeof(OBJECTFIELDDEF) * lpObject->m_nFieldNum);
		lpObject->InitalMap();
		//权限ID
		lpObject->m_lpField[0].m_bFieldType     = MF_SYS_FIELDTYPE_INT;
		_tcscpy(lpObject->m_lpField[0].m_lpszName, "AUTHORITYID");
		//权限名称
		lpObject->m_lpField[1].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[1].m_lpszName, "AUTHORITYNAME");
		//权限描述
		lpObject->m_lpField[2].m_bFieldType     = MF_SYS_FIELDTYPE_VARCHAR;
		_tcscpy(lpObject->m_lpField[2].m_lpszName, "AUTHORITYDESC");
		for(bi = 0;bi < lpObject->m_nFieldNum;bi++)
		{
			lpObject->m_lpField[bi].m_bAllowNull     = 1;
			lpObject->m_lpField[bi].m_bObjectFieldNo = bi+1;
			lpObject->m_mapName2FieldNo.Set(lpObject->m_lpField[bi].m_lpszName, (LPVOID)lpObject->m_lpField[bi].m_bObjectFieldNo);
		}
		m_mapObject.Set(lpObject->m_nObjectID, lpObject);
		m_mapName2Object.Set(lpObject->m_lpszName, lpObject);

		//加载权限数据
		if(m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_AUTHORITY].m_nID == MF_SYS_OBJECTTYPE_AUTHORITY)
		{
			//读取权限数据信息
			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_AUTHORITY].m_nFullBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadAuthorityData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}

			nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_AUTHORITY].m_nFreeBlockMapOffset;
			while(nDataOffset != 0)
			{
				lpBaseFileBlockMap = (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
				lpSystemBlockHead = (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
				nRet = LoadAuthorityData(lpSystemBlockHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				m_mapBlock.Set(lpSystemBlockHead->m_nBlockNo, lpSystemBlockHead);
				nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
			}
		}

		//初始化其他系统对象
		nRet = InitSysObject();
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	return MF_OK;
}

//获取Storage已经保存过的时间戳
long long CSystemManage::GetLastTimestamp()
{
	return m_pMemoryFileHead->m_nBeginTimestamp;
}

//获取数据库唯一标识
USHORT CSystemManage::GetDatabaseGuid()
{
	return m_pMemoryFileHead->m_usDatabaseGuid;
}

//获取内存文件数据锁定状态
BYTE CSystemManage::GetMemFileStatus()
{
	return m_pMemoryFileHead->m_bStatus;
}

//立即写日志
void CSystemManage::SetWriteRedoEvent()
{
	SetEvent(m_hLogEvent);
}

void CSystemManage::ClearDataFile()
{
	int nRet;
	CMemoryFile* pFile;
	long long nDataOffset, i;
	IVirtualMemoryFile* pVirtualFile;
	LPSYSTEMBLOCKHEAD lpSystemBlockHead;
	LPBASEFILEBLOCKMAP lpBaseFileBlockMap;
	LPFILE_MEMDBFILEINFO lpFileMemDBFileInfo;

	//加载文件数据
	if(m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nID == MF_SYS_OBJECTTYPE_FILE)
	{
		nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFullBlockMapOffset;
		while(nDataOffset != 0)
		{
			lpBaseFileBlockMap	= (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
			lpSystemBlockHead	= (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			lpFileMemDBFileInfo = (LPFILE_MEMDBFILEINFO)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
			for(i = 0; i < lpSystemBlockHead->m_nDataNum; i++)
			{
				//检查删除标记
				if(lpFileMemDBFileInfo[i].m_bDropFlag == 1)
				{
					continue;
				}
				else if(lpFileMemDBFileInfo[i].m_bFileType == MF_SYS_FILETYPE_DATAFILE)
				{
					nRet = GetMemoryFileInstance(lpFileMemDBFileInfo[i].m_bFileNo, pVirtualFile);
					if(nRet != MF_OK)
					{
						Trace("CSystemManage::ClearDataFile", MF_TRACE_LEVEL_FAILED, 100900001, "清理数据文件时，未找到文件指针，文件编号：%d", lpFileMemDBFileInfo[i].m_bFileNo);
						continue;
					}
					pFile = (CMemoryFile*)pVirtualFile;
					pFile->ClearDataFile();
				}
			}
			nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
		}

		nDataOffset = m_pMemoryFileHead->m_stuFileObjectData[MF_SYS_OBJECTTYPE_FILE].m_nFreeBlockMapOffset;
		while(nDataOffset != 0)
		{
			lpBaseFileBlockMap	= (LPBASEFILEBLOCKMAP)(m_pFileAddr + nDataOffset);
			lpSystemBlockHead	= (LPSYSTEMBLOCKHEAD)(m_pFileAddr + lpBaseFileBlockMap->m_nBlockOffset);
			lpFileMemDBFileInfo = (LPFILE_MEMDBFILEINFO)(((LPBYTE)lpSystemBlockHead) + lpSystemBlockHead->m_nBlockHeadSize);
			for(i = 0; i < lpSystemBlockHead->m_nDataNum; i++)
			{
				//检查删除标记
				if(lpFileMemDBFileInfo[i].m_bDropFlag == 1)
				{
					Trace("CSystemManage::ClearDataFile", MF_TRACE_LEVEL_FAILED, 100900002, "清理数据文件时，未找到文件指针，文件编号：%d", lpFileMemDBFileInfo[i].m_bFileNo);
					continue;
				}
				else if(lpFileMemDBFileInfo[i].m_bFileType == MF_SYS_FILETYPE_DATAFILE)
				{
					nRet = GetMemoryFileInstance(lpFileMemDBFileInfo[i].m_bFileNo, pVirtualFile);
					if(nRet != MF_OK)
					{
						continue;
					}
					pFile = (CMemoryFile*)pVirtualFile;
					pFile->ClearDataFile();
				}
			}
			nDataOffset = lpBaseFileBlockMap->m_nNextOffset;
		}
	}
}

BOOL CSystemManage::SetWorkloadStatistics(long long llExecuteBeginTime, long long llExecuteEndTime, long long nExecuteTime, int nMinExecuteTime, int nMaxExecuteTime, int nQueryCount, int nUpdateCount)
{
	int nPos;
	long long llTime;
	CCriticalSectionPtr cs(&m_critWorkload);
	nPos	= (int)(((llExecuteBeginTime + llExecuteEndTime)/1200000000)%1440);
	llTime	= llExecuteBeginTime - m_lpWorkloadStatistics[nPos].m_llBeginTime;
	if(llTime < 0)
	{
		llTime = -llTime;
	}
	if(llTime < 600000000)
	{
		//已经被前面的数据占了
		return FALSE;
	}
	m_lpWorkloadStatistics[nPos].m_llBeginTime		= llExecuteBeginTime;
	m_lpWorkloadStatistics[nPos].m_nMinExecuteTime	= nMinExecuteTime;
	m_lpWorkloadStatistics[nPos].m_nMaxExecuteTime	= nMaxExecuteTime;
	if(nQueryCount + nUpdateCount >= 1)
	{
		m_lpWorkloadStatistics[nPos].m_nExecuteTime	= (int)(nExecuteTime/(nQueryCount + nUpdateCount));
	}
	else
	{
		m_lpWorkloadStatistics[nPos].m_nExecuteTime	= nMinExecuteTime;
	}
	m_lpWorkloadStatistics[nPos].m_nQueryCount		= nQueryCount;
	m_lpWorkloadStatistics[nPos].m_nUpdateCount		= nUpdateCount;
	m_lpWorkloadStatistics[nPos].m_nRunTime			= (int)((llExecuteEndTime - llExecuteBeginTime)/10000);//换算成毫秒
	if(nQueryCount + nUpdateCount >= 10000)
	{
		//负载量大于1万时写一下日志
		Trace("WorkloadStatistics", MF_TRACE_LEVEL_FAILED, 100000000, "工作量统计信息，开始时间点：%lld、结束时间点：%lld、执行时间：%d、最小执行时间：%d、最大执行时间：%d、检索次数：%d、修改次数：%d", llExecuteBeginTime, llExecuteEndTime, nExecuteTime, nMinExecuteTime, nMaxExecuteTime, nQueryCount, nUpdateCount);
	}
	
	m_lpLatestWorkloadStatistics = &m_lpWorkloadStatistics[nPos];
	m_nLatestWorkloadPos = nPos;
	return TRUE;
}
