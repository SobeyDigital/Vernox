﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include "DataIDContainer.h"
class CTempDataID : public CDataIDContainer
{
public:
	CTempDataID(CServiceBson* pServiceBson);
	~CTempDataID(void);

private:
	UINT			m_nDataIDNum;				//DataID数量
	UINT			m_nFirstIndex;				//第一个DataID位置
	UINT			m_nCurrentIndex;		    //当前DataID位置
	CServiceBson*	m_pServiceBson;				//Bson对象
	long long*		m_pDataIDArray;				//DataID数组
public:
	int push_back(long long nDataID);

	void clear();

	virtual UINT size() 
	{
		return m_nDataIDNum;
	}

	virtual void resize(UINT nDataIDNum)
	{
		m_nDataIDNum = nDataIDNum;
	}

	//移动到DataID的起始位置
	virtual void MoveFirst();

	//下一条DataID
	virtual int NextDataID(long long& nDataID);

	//弹出DataID
	virtual long long PopDataID();
};
