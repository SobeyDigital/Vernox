﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryMultiKeyBlock.h"
#include "MemoryBTreeFile.h"

#define MIN_KEY_LEN			8		//最小关键字长度
#define MAX_ARRAY_SIZE		1010	//数组最大长度
CMemoryMultiKeyBlock::CMemoryMultiKeyBlock()
{
	m_lpBlockAddr	= NULL;
	m_pBlockBody	= NULL;
	m_lpBlockHead	= NULL;
	m_bKeyNum		= NULL;
	m_bKeyNum		= 0;
}
CMemoryMultiKeyBlock::~CMemoryMultiKeyBlock()
{

}

/************************************************************************
		功能说明：
			获取数据大小
		参数说明：
			nMultiKeySize：关键字大小
			nOffset：数据偏移(相对于文件头)
		返回值说明：
			lpDataAddr:数据指针
************************************************************************/
LPBYTE CMemoryMultiKeyBlock::AllocData(int nMultiKeySize,  long long& nOffset)
{
	LPBYTE lpDataAddr;
	
	//分配定长数据管理复合关键字
	nOffset	   = m_lpBlockAddr - m_pIndexFile->GetFileAddr() + m_lpBlockHead->m_nDataInsertOffset;
	lpDataAddr = m_lpBlockAddr + m_lpBlockHead->m_nDataInsertOffset;
	memset(lpDataAddr, 0, nMultiKeySize);

	m_lpBlockHead->m_nDataInsertOffset += nMultiKeySize;
	m_lpBlockHead->m_nDataNum++;
	return lpDataAddr;
}

/************************************************************************
		功能说明：
			创建后缀数据
		参数说明：
			pArray：数组
			pArrayLen：数组长度
			pStr：字符串
			nLen：字符串长度
************************************************************************/
void CMemoryMultiKeyBlock::BuildSuffixArray(int* pArray, int* pArrayLen, char* pStr, int nStrLen)
{
	BYTE bMidFlag;
	int i, j, n, nTemp;
	char *pStr1, *pStr2;
	//初始化数组
	for(i = 0, n = 0; i < nStrLen; i++)
	{
		//去掉UTF8的中间字符
		bMidFlag = (*(pStr + i))&0XC0;
		if(bMidFlag != 0X80)
		{
			pArray[n] = i;
			n++;
		}
	}
	*pArrayLen = n;

	pArrayLen += sizeof(int);
	//冒泡排序
	for(i = 0; i < n; i++)
	{
		for(j = 0; j < n - i - 1; j++)
		{
			pStr1 = pStr + pArray[j];
			pStr2 = pStr + pArray[j + 1];
			if(CSystemManage::instance().CharCompare(pStr1, nStrLen - pArray[j], pStr2, nStrLen-pArray[j+1], FALSE) > 0)
			{
				nTemp = pArray[j];
				pArray[j] = pArray[j + 1];
				pArray[j + 1] = nTemp;
			}
		}
	}
}

/************************************************************************
		功能说明：
			获取数据大小
		参数说明：
			lpDataAddr：数据地址
			lpMultiIndex：复合索引
			nKeyLen：关键字长度
			llKeyOffset：关键字自身偏移
			nDataID：数据ID
************************************************************************/
int CMemoryMultiKeyBlock::WriteData(LPBYTE lpDataAddr, LPMULTIINDEX lpMultiIndex, int nKeyLen, long long llKeyOffset, long long nDataID)
{
	int i;
	LPKEYINFO lpKeyInfo;
	LPBYTE lpKeyInfoAddr;
	LPINDEXCONDITION lpIndexField;

	memset(lpDataAddr, 0, nKeyLen);
	//将第一个关键字写入内存
	lpDataAddr[0]	= 0;
	lpDataAddr		+= 1;
	memcpy(lpDataAddr, lpMultiIndex->m_lpIndexCondition[0].m_varCondition2.m_lpszValue, lpMultiIndex->m_lpIndexCondition[0].m_varCondition2.m_nStrLen);
	lpDataAddr		+= lpMultiIndex->m_lpIndexCondition[0].m_varCondition2.m_nStrLen + 4;				//存放4字节的0
	
	//获取关键字信息
	lpKeyInfoAddr				= lpDataAddr;
	lpKeyInfo					= (LPKEYINFO)lpDataAddr;
	lpKeyInfo->m_nTotalKeyLen	= nKeyLen;
	lpKeyInfo->m_nBufferOffset	= (int)(lpKeyInfoAddr - m_pIndexFile->GetFileAddr() - llKeyOffset);
	lpDataAddr					+= sizeof(KEYINFO);

	//将剩余关键字写入内存
	for(i = 1; i < (int)lpMultiIndex->m_nIndexNum; i++)
	{
		lpIndexField = &lpMultiIndex->m_lpIndexCondition[i];
		if(lpIndexField->m_varCondition2.m_vt == MF_VARDATA_NULL)
		{
			//空值偏移为0
			lpKeyInfo->m_bKeyOffset[i - 1] = 0;
		}
		else if(lpIndexField->m_varCondition2.m_vt == MF_VARDATA_INT)
		{
			lpKeyInfo->m_bKeyOffset[i - 1] = (BYTE)(lpDataAddr - lpKeyInfoAddr);							//相对于lpKeyInfo的偏移，方便获取
			*(int*)lpDataAddr = lpIndexField->m_varCondition2.m_nValue;
			lpDataAddr += sizeof(int);
		}
		else if(lpIndexField->m_varCondition2.m_vt == MF_VARDATA_INT64)
		{
			lpKeyInfo->m_bKeyOffset[i - 1] = (BYTE)(lpDataAddr - lpKeyInfoAddr);							//相对于lpKeyInfo的偏移，方便获取
			*(long long*)lpDataAddr = lpIndexField->m_varCondition2.m_llValue;

			long long n = *(long long*)lpDataAddr;
			lpDataAddr += sizeof(long long);
		}	
		else if(lpIndexField->m_varCondition2.m_vt == MF_VARDATA_DOUBLE || lpIndexField->m_varCondition2.m_vt == MF_VARDATA_DATE)
		{
			lpKeyInfo->m_bKeyOffset[i - 1] = (BYTE)(lpDataAddr - lpKeyInfoAddr);							//相对于lpKeyInfo的偏移，方便获取
			*(double*)lpDataAddr = lpIndexField->m_varCondition2.m_dblValue;
			lpDataAddr += sizeof(double);
		}
		else
		{
			lpKeyInfo->m_bKeyOffset[i - 1] = (BYTE)(lpDataAddr - lpKeyInfoAddr);							//相对于lpKeyInfo的偏移，方便获取
			*(int*)lpDataAddr = lpIndexField->m_varCondition2.m_nStrLen;
			lpDataAddr += sizeof(int);
			memcpy(lpDataAddr, lpIndexField->m_varCondition2.m_lpszValue, lpIndexField->m_varCondition2.m_nStrLen);
			lpDataAddr += lpIndexField->m_varCondition2.m_nStrLen;
			
			BuildSuffixArray((int*)(lpDataAddr + sizeof(int)), (int*)lpDataAddr, lpIndexField->m_varCondition2.m_lpszValue, lpIndexField->m_varCondition2.m_nStrLen - 1);
		}
	}
	return MF_OK;
}


/************************************************************************
		功能说明：
			计算空闲区与块总大小的比例
		返回值说明:
			返回空闲区与块总大小的比例
		特别说明：
			该函数用于在文件级执行数据插入和数据修改时使用，在文件级进行数据插入和修改后，
			需要判断当前数据块属于可插链表还是属于满块链表(阀值：0.2)
************************************************************************/
double CMemoryMultiKeyBlock::RaitoStat()
{
	double dFreeMemorySize, dBlockBodySize;

	dFreeMemorySize = m_lpBlockHead->m_nKeyInsertOffset - m_lpBlockHead->m_nDataInsertOffset;			//得到空闲区大小
	dBlockBodySize  = m_lpBlockHead->m_nBlockSize - m_lpBlockHead->m_nBlockHeadSize;					//得到块体使用的大小
	return dFreeMemorySize / dBlockBodySize;
}

/************************************************************************
		功能说明：
			判断插入数据后，块是否会满
		参数说明:
			nLen：数据的长度
************************************************************************/
BOOL CMemoryMultiKeyBlock::IsFull(int nSize, double nRatio)
{
	double dblFreeMemorySize, dblAllocSize, dblBlockBodySize;

	dblFreeMemorySize = m_lpBlockHead->m_nKeyInsertOffset - m_lpBlockHead->m_nDataInsertOffset;		//计算块内空区的大小(变长数据偏移 - 定长数据偏移)
	dblBlockBodySize = m_lpBlockHead->m_nBlockSize - m_lpBlockHead->m_nBlockHeadSize;					//得到块体使用的大小

	dblAllocSize = (nSize/32 + 1) * 32;									//计算需要分配的内存大小,为32字节的整数倍
	dblAllocSize += m_lpBlockHead->m_nDataSize;							//加上定长数据部分的大小

	if(dblFreeMemorySize < dblAllocSize)
	{
		return TRUE;
	}
	else
	{
		dblFreeMemorySize -= dblAllocSize;
	}
	return dblFreeMemorySize / dblBlockBodySize <= nRatio;
}

/************************************************************************
	功能说明：
		设置文件指针
	参数说明：
		pIndexFile：文件指针
		pBlockAddr：块指针
************************************************************************/
void CMemoryMultiKeyBlock::	SetBlockAddr(CBaseMemoryFile* pFilePtr, LPBYTE pBlockAddr)
{
	m_pIndexFile = (CMemoryBTreeFile*)pFilePtr;			//文件指针
	m_lpBlockAddr = pBlockAddr;							//块指针
	m_lpBlockHead = (LPBLOCKHEAD)m_lpBlockAddr;			//块头指针
	m_pBlockBody = m_lpBlockAddr + sizeof(BLOCKHEAD);	//块体指针	
}

/************************************************************************
		功能说明:
			初始化新建块
		参数说明：
			nIndexID：索引ID
************************************************************************/
void CMemoryMultiKeyBlock::InitialBlock(int nIndexID)
{
	m_lpBlockHead->m_nIndex				= nIndexID;
	m_lpBlockHead->m_nDataInsertOffset	= sizeof(BLOCKHEAD);
	m_lpBlockHead->m_nBlockHeadSize		= sizeof(BLOCKHEAD);
	m_lpBlockHead->m_nKeyInsertOffset	= m_lpBlockHead->m_nBlockSize;
	m_lpBlockHead->m_nDataNum			= 0;	
}

/************************************************************************
		功能说明：
			插入关键字
		参数说明：
			lpExecutePlan：执行计划
			lpIndexInfo：索引信息
			nTimestamp：时间戳
************************************************************************/
int CMemoryMultiKeyBlock::InsertKey(LPEXECUTEPLANBSON lpExecutePlan, LPINDEXINFO lpIndexInfo, long long nTimestamp)
{
	LPBYTE lpDataAddr;
	int nRet, nKeySize;
	long long llKeyOffset;

	nKeySize = (int)lpIndexInfo->m_nParam4;
	//为关键字分配空间
	lpDataAddr = AllocData(nKeySize, llKeyOffset);
	lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_llValue = llKeyOffset + 1;	//+1是因为字符串最前面存放了0

	//将关键字写入
	nRet = WriteData(lpDataAddr, &lpIndexInfo->m_stMultiIndex, nKeySize, llKeyOffset, lpIndexInfo->m_nDataID);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpBlockHead, nTimestamp);
	return MF_OK;
}

/************************************************************************
		功能说明：
			删除关键字
		参数说明：
			lpIndexInfo：索引信息
			lpExecutePlan：执行计划
			nTimestamp：时间戳
************************************************************************/
int CMemoryMultiKeyBlock::DeleteKey(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	LPKEYINFO lpKeyInfo;
	KEYBUFFERINFO stKeyBufferInfo;
	int nRet, nBlockNo, nLen, nIndex;
	LPBYTE lpBlockAddr, lpAddr, lpKeyInfoAddr;
	long long *arrRecycleMap, nBlockMapOffset, nKeyOffset, nDataID;

	nLen		= 4;
	nKeyOffset	= lpIndexInfo->m_nParam4;
	lpAddr		= (LPBYTE)m_pIndexFile->ConvertOffsettoAddr(nKeyOffset);
	//获取LPKEYINFO
	while(TRUE)
	{
		if(lpAddr[nLen] == 0)
		{
			while (TRUE)
			{
				nLen++;
				if(lpAddr[nLen] != 0)
				{
					lpKeyInfoAddr  = lpAddr + nLen;
					lpKeyInfo = (LPKEYINFO)lpKeyInfoAddr;
					break;
				}
			}
			break;
		}
		else
		{
			nLen += 4;
		}
	}

	nDataID = *(long long*)(lpKeyInfoAddr + lpKeyInfo->m_bKeyOffset[m_bKeyNum - 2]);			//m_bKeyNum记录的是总字段数，而m_bKeyOffset记录的偏移不包含第一个字符串字段,所以这里要除去第一个字段，然后作为数组下标本身要-1，所以这里是-2
	if(lpIndexInfo->m_nDataID != nDataID)
	{
		return MF_BTREEINDEX_DELETEKEY_KEYPOSERROR;
	}
	
	stKeyBufferInfo.m_bFlag			= 1;
	stKeyBufferInfo.m_nBufferSize	= lpKeyInfo->m_nTotalKeyLen;
	//获取回收映射表块
	nRet = m_pIndexFile->GetRecycleBlockNo(lpExecutePlan, lpIndexInfo->m_nIndexID, nBlockNo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(nBlockNo == 0)
	{
		//分配一个块作为回收映射表块
		nRet = m_pIndexFile->AllocBlock(lpExecutePlan, nBlockNo, nBlockMapOffset, DEF_BTREEBLOCK_SIZE, nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		//设置回收映射表块
		nRet = m_pIndexFile->SetRecycleBlockNo(lpExecutePlan, lpIndexInfo->m_nIndexID, nBlockNo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	lpBlockAddr   = m_pIndexFile->ConvertBlockNotoAddr(nBlockNo);
	arrRecycleMap = (long long*)(lpBlockAddr + ((LPBASEBLOCKHEAD)lpBlockAddr)->m_nBlockHeadSize);
	nIndex		  = lpKeyInfo->m_nTotalKeyLen / 8;
	if(nIndex > MAX_ARRAY_SIZE)
	{
		nIndex = MAX_ARRAY_SIZE;
	}

	//插头
	stKeyBufferInfo.m_llNextOffset  = arrRecycleMap[nIndex];
	arrRecycleMap[nIndex]			= lpKeyInfoAddr - m_pIndexFile->GetFileAddr() - lpKeyInfo->m_nBufferOffset;

	//将关键字Buffer信息写入原关键字Buffer
	lpAddr = (LPBYTE)m_pIndexFile->ConvertOffsettoAddr(arrRecycleMap[nIndex]);
	memset(lpAddr, 0, lpKeyInfo->m_nTotalKeyLen);
	memcpy(lpAddr, &stKeyBufferInfo, sizeof(KEYBUFFERINFO));

	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)lpBlockAddr, nTimestamp);
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpBlockAddr, nTimestamp);
	return MF_OK;
}

/************************************************************************
		功能说明：
			删除关键字
		参数说明：
			lpIndexInfo：索引信息
			llKeyBufferOffset：关键字Buffer偏移
			nBufferLen：关键字Buffer长度
************************************************************************/
int CMemoryMultiKeyBlock::GetKeyBuffer(LPINDEXINFO lpIndexInfo, long long& llKeyBufferOffset, int& nBufferLen)
{
	int nLen;
	LPKEYINFO lpKeyInfo;
	LPBYTE lpAddr, lpKeyInfoAddr;
	long long nKeyOffset, nDataID;

	nLen		= 4;
	nKeyOffset	= lpIndexInfo->m_nParam4;
	lpAddr		= (LPBYTE)m_pIndexFile->ConvertOffsettoAddr(nKeyOffset);
	//获取LPKEYINFO
	while(TRUE)
	{
		if(lpAddr[nLen] == 0)
		{
			while (TRUE)
			{
				nLen++;
				if(lpAddr[nLen] != 0)
				{
					lpKeyInfoAddr  = lpAddr + nLen;
					lpKeyInfo = (LPKEYINFO)lpKeyInfoAddr;
					break;
				}
			}
			break;
		}
		else
		{
			nLen += 4;
		}
	}

	nDataID = *(long long*)(lpKeyInfoAddr + lpKeyInfo->m_bKeyOffset[m_bKeyNum - 2]);		  //m_bKeyNum记录的是总字段数，而m_bKeyOffset记录的偏移不包含第一个字符串字段,所以这里要除去第一个字段，然后作为数组下标本身要-1，所以这里是-2
	if(lpIndexInfo->m_nDataID != nDataID)
	{
		return MF_BTREEINDEX_DELETEKEY_KEYPOSERROR;
	}

	nBufferLen  = lpKeyInfo->m_nTotalKeyLen;
	llKeyBufferOffset = lpKeyInfoAddr - m_pIndexFile->GetFileAddr() - lpKeyInfo->m_nBufferOffset;
	return MF_OK;
}