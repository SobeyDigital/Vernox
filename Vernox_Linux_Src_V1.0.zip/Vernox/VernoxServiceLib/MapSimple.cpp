﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MapSimple.h"
#include <stdlib.h>

CMapSimple::CMapSimple(void)
{
	m_nDataCount = 0;
	m_lpBaseData = NULL;

	::InitializeCriticalSection(&m_critMap);
}

CMapSimple::~CMapSimple(void)
{
	if(m_lpBaseData != NULL)
	{
		Clear();
		delete [] m_lpBaseData;
		m_lpBaseData = NULL;
	}

	::DeleteCriticalSection(&m_critMap);
}

int CMapSimple::Initialize(int nMapSize)
{
	if(nMapSize <= 8)
	{
		nMapSize = 8;
	}

	if(m_lpBaseData != NULL)
	{
		Clear();
		delete [] m_lpBaseData;
		m_lpBaseData = NULL;
	}
	m_nDataCount = nMapSize;
	m_lpBaseData = new LPMAPSIMPLEBASEDATA[nMapSize];
	if(m_lpBaseData == NULL)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	memset(m_lpBaseData, 0, m_nDataCount * sizeof(LPMAPSIMPLEBASEDATA));
	return MF_OK;
}

void CMapSimple::Clear()
{
	int i;
	LPMAPSIMPLEBASEDATA lpNode, lpNext, *lpBaseData, *lpBaseTempData;
	CCriticalSectionPtr cs(&m_critMap);

	lpBaseTempData	= new LPMAPSIMPLEBASEDATA[m_nDataCount];
	memset(lpBaseTempData, 0, m_nDataCount * sizeof(LPMAPSIMPLEBASEDATA));
	lpBaseData		= m_lpBaseData;
	m_lpBaseData	= lpBaseTempData;
	Sleep(1);
	for(i = 0;i < m_nDataCount;i++)
	{
		if(lpBaseData[i] == NULL)
		{
			continue;
		}
		else
		{
			lpNode = lpBaseData[i];
			lpBaseData[i] = NULL;
			while(lpNode != NULL)
			{
				lpNext = lpNode->m_lpNext;
				delete lpNode;
				lpNode = lpNext;
			}
		}
	}
	delete [] lpBaseData;
}

int CMapSimple::Set(int nID, LPVOID lpData)
{
	int nPos;
	LPMAPSIMPLEBASEDATA lpNode;
	CCriticalSectionPtr cs(&m_critMap);

	nPos = abs(nID) % m_nDataCount;
	if(m_lpBaseData[nPos] == NULL)
	{
		lpNode = new MAPSIMPLEBASEDATA;
		if(lpNode == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		lpNode->m_nID		= nID;
		lpNode->m_lpData	= lpData;
		lpNode->m_lpNext	= NULL;
		m_lpBaseData[nPos]	= lpNode;
	}
	else
	{
		//首先查一下是否同样的ID存在
		for(lpNode = m_lpBaseData[nPos];lpNode != NULL;lpNode = lpNode->m_lpNext)
		{
			if(lpNode->m_nID == nID)
			{
				lpNode->m_lpData = lpData;
				return MF_INNER_ALLOCMEM_FAILED;
			}
		}

		//检查被删除的空槽位
		for(lpNode = m_lpBaseData[nPos];lpNode != NULL;lpNode = lpNode->m_lpNext)
		{
			if(lpNode->m_nID == 0)
			{
				lpNode->m_nID		= nID;
				lpNode->m_lpData	= lpData;
				return MF_OK;
			}
		}

		//挂接数据到链表上
		lpNode = new MAPSIMPLEBASEDATA;
		if(lpNode == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		lpNode->m_nID		= nID;
		lpNode->m_lpData	= lpData;
		lpNode->m_lpNext	= m_lpBaseData[nPos];
		m_lpBaseData[nPos]	= lpNode;
	}
	return MF_OK;
}

LPVOID CMapSimple::Get(int nID)
{
	int nPos;
	LPMAPSIMPLEBASEDATA lpNode;
	nPos = abs(nID) % m_nDataCount;
	if(m_lpBaseData[nPos] == NULL)
	{
		return NULL;
	}

	for(lpNode = m_lpBaseData[nPos];lpNode != NULL;lpNode = lpNode->m_lpNext)
	{
		if(lpNode->m_nID == nID)
		{
			return lpNode->m_lpData;
		}
	}
	return NULL;
}

LPVOID CMapSimple::Remove(int nID)
{
	int nPos;
	LPMAPSIMPLEBASEDATA lpNode;

	CCriticalSectionPtr cs(&m_critMap);
	nPos = abs(nID) % m_nDataCount;
	if(m_lpBaseData[nPos] == NULL)
	{
		return NULL;
	}

	lpNode = m_lpBaseData[nPos];
	if(lpNode->m_nID == nID)
	{
		lpNode->m_nID = 0;
		return lpNode->m_lpData;
	}

	for(lpNode = lpNode->m_lpNext;lpNode != NULL;lpNode = lpNode->m_lpNext)
	{
		if(lpNode->m_nID == nID)
		{
			lpNode->m_nID = 0;
			return lpNode->m_lpData;
		}
	}
	return NULL;
}

LPVOID CMapSimple::GetHeadPosition()
{
	int i;
	LPMAPSIMPLEBASEDATA lpNode;
	for(i = 0; i < m_nDataCount; i++)
	{
		if(m_lpBaseData[i] == NULL)
		{
			continue;
		}
		if(m_lpBaseData[i]->m_nID != 0)
		{
			return m_lpBaseData[i];
		}

		for(lpNode = m_lpBaseData[i]->m_lpNext;lpNode != NULL;lpNode = lpNode->m_lpNext)
		{
			if(lpNode->m_nID != 0)
			{
				return lpNode;
			}
		}
	}
	return NULL;
}

void CMapSimple::GetNext(LPVOID &nPos, int &nID, LPVOID &lpData)
{
	int n;
	LPMAPSIMPLEBASEDATA lpNode, lpNode1;
	lpNode = (LPMAPSIMPLEBASEDATA)nPos;

	if(lpNode == NULL)
	{
		nID = 0;
		lpData = NULL;
	}
	else
	{
		nPos = NULL;
		nID = lpNode->m_nID;
		lpData = lpNode->m_lpData;
		for(lpNode1 = lpNode->m_lpNext;lpNode1 != NULL;lpNode1 = lpNode1->m_lpNext)
		{
			if(lpNode1->m_nID != 0)
			{
				nPos = lpNode1;
				return;
			}
		}
		if(nPos == NULL)
		{
			n = abs(nID) % m_nDataCount;
			if(n == m_nDataCount - 1)
			{
				//读取已经结束
				nPos = NULL;
				return;
			}

			for(n++; n < m_nDataCount;n++)
			{
				if(m_lpBaseData[n] == NULL)
				{
					continue;
				}
				if(m_lpBaseData[n]->m_nID != 0)
				{
					nPos = m_lpBaseData[n];
					return;
				}

				for(lpNode = m_lpBaseData[n]->m_lpNext;lpNode != NULL;lpNode = lpNode->m_lpNext)
				{
					if(lpNode->m_nID != 0)
					{
						nPos = lpNode;
						return;
					}
				}
			}
		}
	}
}

CMapLongLong::CMapLongLong(void)
{
	m_nDataCount = 0;
	m_lpBaseData = NULL;

	::InitializeCriticalSection(&m_critMap);
}
CMapLongLong:: ~CMapLongLong(void)
{
	if(m_lpBaseData != NULL)
	{
		Clear();
		delete [] m_lpBaseData;
		m_lpBaseData = NULL;
	}
	::DeleteCriticalSection(&m_critMap);
}
int CMapLongLong::Initialize(int nMapSize)
{
	if(nMapSize <= 8)
	{
		nMapSize = 8;
	}

	if(m_lpBaseData != NULL)
	{
		Clear();
		delete [] m_lpBaseData;
		m_lpBaseData = NULL;
	}
	m_nDataCount = nMapSize;
	m_lpBaseData = new LPMAPSIMPLEBASEDATA[nMapSize];
	if(m_lpBaseData == NULL)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	memset(m_lpBaseData, 0, m_nDataCount * sizeof(LPMAPSIMPLEBASEDATA));
	return MF_OK;

}
void CMapLongLong::Clear()
{
	int i;
	LPMAPSIMPLEBASEDATA lpNode, lpNext, *lpBaseData, *lpBaseTempData;
	CCriticalSectionPtr cs(&m_critMap);

	lpBaseTempData	= new LPMAPSIMPLEBASEDATA[m_nDataCount];
	memset(lpBaseTempData, 0, m_nDataCount * sizeof(LPMAPSIMPLEBASEDATA));
	lpBaseData		= m_lpBaseData;
	m_lpBaseData	= lpBaseTempData;
	Sleep(1);
	for(i = 0;i < m_nDataCount;i++)
	{
		if(lpBaseData[i] == NULL)
		{
			continue;
		}
		else
		{
			lpNode = lpBaseData[i];
			lpBaseData[i] = NULL;
			while(lpNode != NULL)
			{
				lpNext = lpNode->m_lpNext;
				delete lpNode;
				lpNode = lpNext;
			}
		}
	}
	delete [] lpBaseData;
}

int CMapLongLong::Set(long long llKey, long long llValue)
{
	int nPos;
	LPMAPSIMPLEBASEDATA lpNode;
	CCriticalSectionPtr cs(&m_critMap);

	nPos = llKey % m_nDataCount;
	if(m_lpBaseData[nPos] == NULL)
	{
		lpNode = new MAPSIMPLEBASEDATA;
		if(lpNode == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		lpNode->m_llKey		= llKey;
		lpNode->m_llValue	= llValue;
		lpNode->m_lpNext	= NULL;
		m_lpBaseData[nPos]	= lpNode;
	}
	else
	{
		//首先查一下是否同样的ID存在
		for(lpNode = m_lpBaseData[nPos];lpNode != NULL;lpNode = lpNode->m_lpNext)
		{
			if(lpNode->m_llKey == llKey)
			{
				lpNode->m_llValue = llValue;
				return MF_INNER_ALLOCMEM_FAILED;
			}
		}

		//检查被删除的空槽位
		for(lpNode = m_lpBaseData[nPos];lpNode != NULL;lpNode = lpNode->m_lpNext)
		{
			if(lpNode->m_llKey == 0)
			{
				lpNode->m_llKey		= llKey;
				lpNode->m_llValue	= llValue;
				return MF_OK;
			}
		}

		//挂接数据到链表上
		lpNode = new MAPSIMPLEBASEDATA;
		if(lpNode == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		lpNode->m_llKey		= llKey;
		lpNode->m_llValue	= llValue;
		lpNode->m_lpNext	= m_lpBaseData[nPos];
		m_lpBaseData[nPos]	= lpNode;
	}
	return MF_OK;
}

long long CMapLongLong::Get(long long llKey)
{
	int nPos;
	LPMAPSIMPLEBASEDATA lpNode;
	nPos = llKey % m_nDataCount;
	if(m_lpBaseData[nPos] == NULL)
	{
		return NULL;
	}

	for(lpNode = m_lpBaseData[nPos];lpNode != NULL;lpNode = lpNode->m_lpNext)
	{
		if(lpNode->m_llKey == llKey)
		{
			return lpNode->m_llValue;
		}
	}
	return 0;
}

CMapString::CMapString(void)
{
	m_nDataCount = 0;
	m_lpBaseData = NULL;
	::InitializeCriticalSection(&m_critMap);
}

CMapString::~CMapString(void)
{
	if(m_lpBaseData != NULL)
	{
		Clear();
		delete [] m_lpBaseData;
		m_lpBaseData = NULL;
	}

	::DeleteCriticalSection(&m_critMap);
}

int CMapString::Initialize(int nMapSize)
{
	if(nMapSize <= 8)
	{
		nMapSize = 8;
	}

	if(m_lpBaseData != NULL)
	{
		Clear();
		delete [] m_lpBaseData;
		m_lpBaseData = NULL;
	}
	m_nDataCount = nMapSize;
	m_lpBaseData = new LPMAPSTRINGBASEDATA[nMapSize];
	if(m_lpBaseData == NULL)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	memset(m_lpBaseData, 0, m_nDataCount * sizeof(LPMAPSTRINGBASEDATA));
	return MF_OK;
}

void CMapString::Clear()
{
	int i;
	LPMAPSTRINGBASEDATA lpNode, lpNext, *lpBaseData, *lpBaseTempData;
	CCriticalSectionPtr cs(&m_critMap);

	lpBaseTempData	= new LPMAPSTRINGBASEDATA[m_nDataCount];
	memset(lpBaseTempData, 0, m_nDataCount * sizeof(LPMAPSTRINGBASEDATA));
	lpBaseData		= m_lpBaseData;
	m_lpBaseData	= lpBaseTempData;
	Sleep(1);
	for(i = 0;i < m_nDataCount;i++)
	{
		if(lpBaseData[i] == NULL)
		{
			continue;
		}
		else
		{
			lpNode = lpBaseData[i];
			lpBaseData[i] = NULL;
			while(lpNode != NULL)
			{
				lpNext = lpNode->m_lpNext;
				delete lpNode;
				lpNode = lpNext;
			}
		}
	}
	delete [] lpBaseData;
}

int CMapString::Set(char * lpszDataID, LPVOID lpData)
{
	int nPos;
	LPMAPSTRINGBASEDATA lpNode;
	CCriticalSectionPtr cs(&m_critMap);

	nPos = GetPos(lpszDataID);
	if(m_lpBaseData[nPos] == NULL)
	{
		lpNode = new MAPSTRINGBASEDATA;
		if(lpNode == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		memcpy(lpNode->m_lpszDataID, lpszDataID, sizeof(lpNode->m_lpszDataID));
		lpNode->m_lpData	= lpData;
		lpNode->m_lpNext	= NULL;
		m_lpBaseData[nPos]	= lpNode;
	}
	else
	{
		//首先查一下是否同样的ID存在
		for(lpNode = m_lpBaseData[nPos];lpNode != NULL;lpNode = lpNode->m_lpNext)
		{
			if(lpNode->m_lpszDataID[0] == 0)
			{
			}
			else if(strcmp(lpNode->m_lpszDataID, lpszDataID) == 0)
			{
				lpNode->m_lpData = lpData;
				return MF_INNER_ALLOCMEM_FAILED;
			}
		}
		//检查被删除的空槽位
		for(lpNode = m_lpBaseData[nPos];lpNode != NULL;lpNode = lpNode->m_lpNext)
		{
			if(lpNode->m_lpszDataID[0] == 0)
			{
				memcpy(lpNode->m_lpszDataID, lpszDataID, sizeof(lpNode->m_lpszDataID));
				lpNode->m_lpData	= lpData;
				return MF_OK;
			}
		}

		//挂接数据到链表上
		lpNode = new MAPSTRINGBASEDATA;
		if(lpNode == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		memcpy(lpNode->m_lpszDataID, lpszDataID, sizeof(lpNode->m_lpszDataID));
		lpNode->m_lpData	= lpData;
		lpNode->m_lpNext	= m_lpBaseData[nPos];
		m_lpBaseData[nPos]	= lpNode;
	}
	return MF_OK;
}

LPVOID CMapString::Get(const char * lpszDataID)
{
	int nPos;
	LPMAPSTRINGBASEDATA lpNode;

	nPos = GetPos(lpszDataID);
	if(m_lpBaseData[nPos] == NULL)
	{
		return NULL;
	}

	for(lpNode = m_lpBaseData[nPos];lpNode != NULL;lpNode = lpNode->m_lpNext)
	{
		if(lpNode->m_lpszDataID[0] == 0)
		{
		}
		else if(strcmp(lpNode->m_lpszDataID, lpszDataID) == 0)
		{
			return lpNode->m_lpData;
		}
	}
	return NULL;
}

LPVOID CMapString::Remove(const char * lpszDataID)
{
	int nPos;
	LPMAPSTRINGBASEDATA lpNode;
	CCriticalSectionPtr cs(&m_critMap);
	nPos = GetPos(lpszDataID);
	if(m_lpBaseData[nPos] == NULL)
	{
		return NULL;
	}

	lpNode = m_lpBaseData[nPos];
	if(strcmp(lpNode->m_lpszDataID, lpszDataID) == 0)
	{
		memset(lpNode->m_lpszDataID, 0, sizeof(lpNode->m_lpszDataID));
		return lpNode->m_lpData;
	}

	for(lpNode = lpNode->m_lpNext;lpNode != NULL;lpNode = lpNode->m_lpNext)
	{
		if(strcmp(lpNode->m_lpszDataID, lpszDataID) == 0)
		{
			memset(lpNode->m_lpszDataID, 0, sizeof(lpNode->m_lpszDataID));
			return lpNode->m_lpData;
		}
	}
	return NULL;
}

LPVOID CMapString::GetHeadPosition()
{
	int i;
	LPMAPSTRINGBASEDATA lpNode;
	for(i = 0; i < m_nDataCount; i++)
	{
		if(m_lpBaseData[i] == NULL)
		{
			continue;
		}
		if(m_lpBaseData[i]->m_lpszDataID[0] != 0)
		{
			return m_lpBaseData[i];
		}

		for(lpNode = m_lpBaseData[i]->m_lpNext;lpNode != NULL;lpNode = lpNode->m_lpNext)
		{
			if(lpNode->m_lpszDataID[0] != 0)
			{
				return lpNode;
			}
		}
	}
	return NULL;
}

void CMapString::GetNext(LPVOID &nPos, char * &lpszDataID, LPVOID &lpData)
{
	int n;
	LPMAPSTRINGBASEDATA lpNode, lpNode1;
	lpNode = (LPMAPSTRINGBASEDATA)nPos;

	if(lpNode == NULL)
	{
		lpszDataID = NULL;
		lpData = NULL;
	}
	else
	{
		nPos = NULL;
		lpszDataID = lpNode->m_lpszDataID;
		lpData = lpNode->m_lpData;
		for(lpNode1 = lpNode->m_lpNext;lpNode1 != NULL;lpNode1 = lpNode1->m_lpNext)
		{
			if(lpNode1->m_lpszDataID[0] != 0)
			{
				nPos = lpNode1;
				return;
			}
		}
		if(nPos == NULL)
		{
			n = GetPos(lpNode->m_lpszDataID);
			if(n == m_nDataCount - 1)
			{
				//读取已经结束
				nPos = NULL;
				return;
			}

			for(n++; n < m_nDataCount;n++)
			{
				if(m_lpBaseData[n] == NULL)
				{
					continue;
				}
				if(m_lpBaseData[n]->m_lpszDataID[0] != 0)
				{
					nPos = m_lpBaseData[n];
					return;
				}

				for(lpNode = m_lpBaseData[n]->m_lpNext;lpNode != NULL;lpNode = lpNode->m_lpNext)
				{
					if(lpNode->m_lpszDataID[0] != 0)
					{
						nPos = lpNode;
						return;
					}
				}
			}
		}
	}
}

int	CMapString::GetPos(const char * lpszDataID)
{
	int i, nChar, nBit, nHash;

	nHash = 0;
	for(i = 0;i < 32 && lpszDataID[i] != 0;i++)
	{
		nBit  = i%24;
		nChar = lpszDataID[i];
		nChar = nChar << nBit;
		nHash += nChar;
	}
	if(nHash < 0)
	{
		nHash = -nHash;
	}
	i = nHash % m_nDataCount;
	return i;
}


CMapDataID::CMapDataID(void)
{
	m_nIndex = 0;
	m_nDataCount = 0;
	m_lpBaseData = NULL;
}

CMapDataID::~CMapDataID(void)
{
	if(m_lpBaseData != NULL)
	{
		Clear();
		delete [] m_lpBaseData;
		m_lpBaseData = NULL;
	}
}

void CMapDataID::Clear()
{
	int i;
	LPMAPDATAIDBASEDATA lpNode, lpNext;
	for(i = 0;i < m_nDataCount;i++)
	{
		m_lpBaseData[i].m_nDataID = 0;
		if(m_lpBaseData[i].m_lpNext == NULL)
		{
			continue;
		}
		else
		{
			lpNode = m_lpBaseData[i].m_lpNext;
			m_lpBaseData[i].m_lpNext = NULL;
			while(lpNode != NULL)
			{
				lpNext = lpNode->m_lpNext;
				delete lpNode;
				lpNode = lpNext;
			}
		}
	}
	m_nIndex = 0;
}

int CMapDataID::SetData(__int64 nDataID)
{
	int nPos;
	LPMAPDATAIDBASEDATA lpNode;
	m_nIndex++;
	nPos = _abs64(nDataID) % m_nDataCount;
	if(m_lpBaseData[nPos].m_nDataID == 0)
	{
		m_lpBaseData[nPos].m_nDataID = nDataID;
	}
	else
	{
		//挂接数据到链表上
		lpNode = new MAPDATAIDBASEDATA;
		if(lpNode == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		lpNode->m_nDataID	= nDataID;
		lpNode->m_lpNext	= m_lpBaseData[nPos].m_lpNext;
		m_lpBaseData[nPos].m_lpNext = lpNode;
	}
	return MF_OK;
}

int CMapDataID::Set(__int64 nDataID, BOOL& bFind)
{
	int nPos, nCount;
	if(m_nIndex <= 16)
	{
		//少量数据的时候就直接用数组解决
		for(nPos = 0;nPos < m_nIndex;nPos++)
		{
			if(m_arDataID[nPos] == nDataID)
			{
				//找到，说明已经存在
				bFind = TRUE;
				return MF_OK;		
			}
		}
		if(m_nIndex == 16)
		{
			//需要切换到Hash方式判断重复问题，所以先构建Hash数据
			m_nDataCount = 512;
			m_lpBaseData = new MAPDATAIDBASEDATA[m_nDataCount];
			if(m_lpBaseData == NULL)
			{
				bFind = FALSE;
				return MF_INNER_ALLOCMEM_FAILED;
			}
			memset(m_lpBaseData, 0, m_nDataCount * sizeof(MAPDATAIDBASEDATA));
			nCount = m_nIndex;
			m_nIndex = 0;
			for(nPos = 0;nPos < nCount;nPos++)
			{
				SetData(m_arDataID[nPos]);
			}
			SetData(nDataID);
		}
		else
		{
			m_arDataID[m_nIndex] = nDataID;
			m_nIndex++;

			bFind = FALSE;
			return MF_OK;
		}
	}
	else
	{
		LPMAPDATAIDBASEDATA lpNode;
		//首先查一下是否存在
		nPos = _abs64(nDataID) % m_nDataCount;
		if(m_lpBaseData[nPos].m_nDataID == nDataID)
		{
			bFind = TRUE;
			return MF_OK;
		}
		else
		{
			//首先查一下是否同样的ID存在
			for(lpNode = m_lpBaseData[nPos].m_lpNext;lpNode != NULL;lpNode = lpNode->m_lpNext)
			{
				if(lpNode->m_nDataID == nDataID)
				{
					bFind = TRUE;
					return MF_OK;
				}
			}
		}
		if(m_nIndex > m_nDataCount && m_nDataCount < 524288)
		{
			//需要重构HASH数据
			LPMAPDATAIDBASEDATA lpNext;
			LPMAPDATAIDBASEDATA lpBaseData;
			lpBaseData = m_lpBaseData;
			nCount = m_nDataCount;
			if(m_nDataCount < 131072)
			{
				m_nDataCount = m_nDataCount * 8; //按照8倍的速度进行膨胀
			}
			else
			{
				m_nDataCount = m_nDataCount * 4; //按照4倍的速度进行膨胀
			}
			m_lpBaseData = new MAPDATAIDBASEDATA[m_nDataCount];
			if(m_lpBaseData == NULL)
			{
				m_lpBaseData = lpBaseData;
				m_nDataCount = nCount;
				bFind		 = FALSE;
				return MF_INNER_ALLOCMEM_FAILED;
			}
			memset(m_lpBaseData, 0, m_nDataCount * sizeof(MAPDATAIDBASEDATA));
			for(nPos = 0;nPos < nCount;nPos++)
			{
				if(lpBaseData[nPos].m_nDataID == 0)
				{
					continue;
				}
				else
				{
					SetData(lpBaseData[nPos].m_nDataID);
					lpNode = lpBaseData[nPos].m_lpNext;
					while(lpNode != NULL)
					{
						if(lpNode->m_nDataID == 0)
						{
							continue;
						}
						SetData(lpNode->m_nDataID);
						lpNext = lpNode->m_lpNext;
						delete lpNode;
						lpNode = lpNext;
					}
				}
			}
			delete [] lpBaseData;
			SetData(nDataID);
		}
		else
		{
			//添加到Hash中
			SetData(nDataID);
		}
	}

	bFind = FALSE;
	return MF_OK;
}

BOOL CMapDataID::Find(__int64 nDataID)
{
	int nPos;
	if(m_nIndex <= 16)
	{
		//少量数据的时候就直接用数组解决
		for(nPos = 0;nPos < m_nIndex;nPos++)
		{
			if(m_arDataID[nPos] == nDataID)
			{
				//找到，说明已经存在
				return TRUE;		
			}
		}
		return FALSE;
	}
	else
	{
		LPMAPDATAIDBASEDATA lpNode;
		//首先查一下是否存在
		nPos = _abs64(nDataID) % m_nDataCount;
		if(m_lpBaseData[nPos].m_nDataID == nDataID)
		{
			return TRUE;
		}
		else
		{
			//首先查一下是否同样的ID存在
			for(lpNode = m_lpBaseData[nPos].m_lpNext;lpNode != NULL;lpNode = lpNode->m_lpNext)
			{
				if(lpNode->m_nDataID == nDataID)
				{
					return TRUE;
				}
			}
		}
	}
	return FALSE;
}

LPVOID CMapDataID::GetHeadPosition()
{
	if(m_nIndex == 0)
	{
		return NULL;
	}
	else if(m_nIndex <= 16)
	{
		return (LPVOID)1;
	}
	else
	{
		int i;
		for(i = 0; i < m_nDataCount; i++)
		{
			if(m_lpBaseData[i].m_nDataID == 0)
			{
				continue;
			}
			else
			{
				return &m_lpBaseData[i];
			}
		}
	}
	return NULL;
}

void CMapDataID::GetNext(LPVOID &nPos, __int64 &nDataID)
{
	if(m_nIndex <= 16)
	{
		int nIndex;
		nIndex = *(int*)nPos;
		if(nIndex < m_nIndex)
		{
			nDataID = m_arDataID[nIndex - 1];
			nPos = (LPVOID)(nIndex + 1);
		}
		else if(nIndex == m_nIndex)
		{
			nDataID = m_arDataID[nIndex - 1];
			nPos = NULL;
		}
		else
		{
			nDataID = 0;
			nPos = NULL;
		}
	}
	else
	{
		int n;
		LPMAPDATAIDBASEDATA lpNode;
		lpNode = (LPMAPDATAIDBASEDATA)nPos;
		if(lpNode == NULL)
		{
			nDataID = 0;
		}
		else
		{
			nPos = NULL;
			nDataID = lpNode->m_nDataID;
			if(lpNode->m_lpNext != NULL)
			{
				nPos = lpNode->m_lpNext;
				return;
			}
			n = _abs64(nDataID) % m_nDataCount;
			if(n == m_nDataCount - 1)
			{
				//读取已经结束
				nPos = NULL;
				return;
			}

			for(n++; n < m_nDataCount;n++)
			{
				if(m_lpBaseData[n].m_nDataID == 0)
				{
					continue;
				}
				nPos = &m_lpBaseData[n];
			}
		}
	}
}

CMapTemporaryDataID::CMapTemporaryDataID(void)
{
	m_nDataCount = 1024;
	m_lpDataID	 = new __int64[m_nDataCount];
	memset(m_lpDataID, 0, m_nDataCount * sizeof(__int64));
}

CMapTemporaryDataID::~CMapTemporaryDataID(void)
{
	if(m_lpDataID != NULL)
	{
		delete [] m_lpDataID;
		m_lpDataID = NULL;
	}
}

void CMapTemporaryDataID::Set(__int64 nDataID)
{
	int nPos;
	nPos = _abs64(nDataID) % m_nDataCount;
	m_lpDataID[nPos] = nDataID;
}

BOOL CMapTemporaryDataID::Check(__int64 nDataID)
{
	int nPos;
	nPos = _abs64(nDataID) % m_nDataCount;
	if(m_lpDataID[nPos] == nDataID)
	{
		return TRUE;
	}
	return FALSE;
}


CMemStack::CMemStack(void)
{
	m_lpBuffer		= NULL;
	m_nBufferSize	= 0;
	m_nElementSize  = 0;
	m_nElementNum	= 0;
	m_lpTopPtr		= NULL;
	m_bPointer		= FALSE;
	m_bAutoRelease	= FALSE;
}

CMemStack::~CMemStack(void)
{
	if(m_bAutoRelease)
	{
		if(m_lpBuffer != NULL)
		{
			delete [] m_lpBuffer;
			m_lpBuffer = NULL;
		}
	}
}

//初始化
void CMemStack::Initial(LPBYTE lpBuffer, UINT nBufferSize, UINT nElementSize, BOOL bPointer)
{
	if(lpBuffer == NULL)
	{
		lpBuffer = new BYTE[nBufferSize];
		if(lpBuffer == NULL)
		{
			nBufferSize = 0;
		}
		m_bAutoRelease = TRUE;
	}

	m_lpBuffer		= lpBuffer;
	m_nBufferSize	= nBufferSize;
	m_nElementSize  = nElementSize;
	m_lpTopPtr		= lpBuffer;
	m_bPointer		= bPointer;
	m_nElementNum	= 0;
}	


//随机访问栈中元素
void* CMemStack::GetElement(int nIndex)
{
	if(nIndex < m_nElementNum)
	{
		if(m_bPointer)
		{
			return *(void**)(m_lpTopPtr - nIndex*m_nElementSize);
		}
		else
		{
			return m_lpTopPtr - nIndex*m_nElementSize;	
		}
	}
	else
	{
		return NULL;
	}
}

//压栈
int CMemStack::Push(void* pElement)
{
	if(m_lpTopPtr + m_nElementSize < m_lpBuffer + m_nBufferSize)
	{
		if(m_nElementNum != 0)
		{
			m_lpTopPtr += m_nElementSize;
		}
		
		if(m_bPointer)
		{
			memcpy(m_lpTopPtr, &pElement, m_nElementSize);
		}
		else
		{
			memcpy(m_lpTopPtr, pElement, m_nElementSize);
		}
		m_nElementNum++;
		return MF_OK;
	}
	else
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
}

void* CMemStack::Pop()
{
	void* pRetPtr;
	if(m_nElementNum == 0)
	{
		return NULL;
	}
	if(m_bPointer)
	{
		pRetPtr = *(void**)m_lpTopPtr;
	}
	else
	{
		pRetPtr = m_lpTopPtr;
	}
	if(m_nElementNum)
	{
		m_lpTopPtr   -= m_nElementSize;	
		m_nElementNum--;
	}
	return pRetPtr;
}

void* CMemStack::Top()
{
	if(m_bPointer)
	{
		return *(void**)m_lpTopPtr;
	}
	else
	{
		return m_lpTopPtr;
	}
}
