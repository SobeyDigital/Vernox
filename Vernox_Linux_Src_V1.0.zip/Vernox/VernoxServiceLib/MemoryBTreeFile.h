﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "IndexSelector.h"
#include "MapSimple.h"
#define DEF_BTREEBLOCK_SIZE (8*1024)
#define DEF_KEYBLOCK_SIZE (256*1024)
#define LINK_TYPE		BYTE
#define FREE_LINK		1
#define FULL_LINK		2
using namespace std;
/************************************************************************
	索引文件类说明:
	该类实现对于索引文件块的管理主要有以下功能：
	1.创内存块作为树干结点或者叶子结点
	2.维护块号向实际地址的映射表
	3.维护空块队列

	重点说明：
	在索引文件中，由于索引块的大小都是一样的，所以可以直接按照顺序给索引块编号，
	然后根据块编号*块大小就可以获得索引的偏移量，那么这样就无需在文件级建立映射表(目前还是保留映射表)

	对于索引块的删除，可以这样处理，由于索引块长度固定，所以如果某一索引块中的索引全部被删除之后，
	没有必要删除索引块，可以建立一个空块队列把该索引块加入到其中，每次需要建立新索引块时，先查看空块队列
	如果有空块则直接向空块中插入索引项，同时将其从空块队列中删除
	空块队列的建立：直接用一个int类型的变量去保存块的编号即可
************************************************************************/
class CBaseBlock;
class CMemoryBTreeFile : public CBaseMemoryFile
{
private:
	#pragma pack(1)
	/************************************************************************
		在文件头中维护一个ROOT数组，指向索引树的根结点
	************************************************************************/
	typedef struct
	{
		int m_nIndexID;												//Object标识
		int m_nBlockNo;												//根结点块编号
		int m_nRecycleMapNo;										//回收映射表块编号
		
		BYTE m_bFieldNum;											//字段数量
		BYTE m_bFieldType[5];										//字段类型
		BYTE m_bReserved[2];										//保留字段
	}ROOTSTRUCT,*LPROOTSTRUCT;

	//文件头(需要写入内存)
	typedef struct
	{
		int		m_nDataFlag;										//数据标志，目前定为‘SBMF’
		long long m_nTimestamp;										//文件保存的时间戳
		BYTE	m_bFileNo;											//文件编号
		BYTE	m_bStatus;											//内存文件数据锁定状态
		USHORT	m_usDatabaseGuid;									//数据库唯一标识
		long long m_nFileTotalSize;									//文件总大小
		int		m_nFileHeaderSize;									//文件头大小
		int		m_nBlockNum;										//块个数
		int		m_nBlockMapStructSize;								//块地址映射表中表项的长度，实际为FILEBLOCKMAP结构体大小
		int		m_nBlockMapStartOffset;								//指向第一个FILEBLOCKMAP结构体的地址		
		long long m_nBlockStartOffset;								//块的起始地址
		BASEFILEOBJECTDEF m_stFileObjectData[MAX_OBJECT_NUM];		//不同类型索引的块的入口地址数组

		int		  m_nInnerMaxNo;									//块编号最大值，用于插入时
		long long m_nFileFreeSize;									//空闲区大小
		long long m_nFileFreeMemoryOffset;							//空闲空间首地址
		long long m_nFreeBlockMapOffset;							//对象删除等回收的BLOCK块的映射结点偏移地址	
		long long m_nBlockMapSize;									//块映射表大小
		long long m_nMaxBlockMapNum;								//块映射表中所能容纳的最大数据数量
		ROOTSTRUCT	  m_stRootMap[MAX_OBJECT_NUM];					//不同Object索引的入口地址数组
	}FILEHEAD,*LPFILEHEAD;

	typedef struct
	{
		LINK_TYPE		m_bLikType;
		BOOL			m_bStart;
		BOOL			m_bLock;
		int				m_nBlockNo;
		long long		m_nBlockMapOffset;
	}LINKINFO,*LPLINKINFO;
	#pragma pack()
private:
	LPBYTE		m_lpFileAddr;										//内存文件体指针(文件指针+文件头大小)
	LPFILEHEAD	m_lpMemoryFileHead;									//内存映射文件头(m_pMemoryFileHead = (MemoryFileHead*)m_pFile)
	LPBASEFILEBLOCKMAPHEAD m_lpBlockMapTail;						//文件块映射链表尾
	CMapSimple  m_stIndexMap;									//块号和内存块对象指针映射Map,说明：由于文件级包含了两种类型的索引，所以文件级不能确定转换出来的块地址是哪一种索引的，于是只返回块首地址，交由具体的索引来转换该指针
	friend class CMemoryStrKeyBlock;
	friend class CMemoryMultiKeyBlock;
	friend class CMemoryBTreeIndex;
	friend class CMemoryBTreeDouble;
private:
	//防止此类被非法构造成对象或者复制
	CMemoryBTreeFile(const CMemoryBTreeFile&);
	CMemoryBTreeFile& operator = (const CMemoryBTreeFile&);
	
private:
	/************************************************************************
		功能说明：
			根据块号获得块在内存中的实际地址
	************************************************************************/
	LPBYTE ConvertBlockNotoAddr(int nBlockNo);

	/************************************************************************
		功能说明：
			根据偏移获取实际地址
	************************************************************************/
	inline char* ConvertOffsettoAddr(long long nOffset)
	{
		return (char*)(m_lpFileAddr + nOffset);
	}

	/************************************************************************
		功能说明：
			初始化索引文件管理类，让整个实例是可执行的
	************************************************************************/
	int SetFileAddr(LPBYTE lpFileAddr);

	/************************************************************************
		功能说明：
			获取文件指针
	************************************************************************/
	inline LPBYTE GetFileAddr()
	{
		return m_lpFileAddr;
	}

	/************************************************************************
		功能说明：
			分配空间并创建内存块
	************************************************************************/
	int AllocBlock(LPEXECUTEPLANBSON lpExecutePlan, int& nBlockNo, long long& nBlockMapOffset, int nBlockSize, long long nTimestamp);	
							
	/************************************************************************
		功能说明：
			释放内存块(清空),并把块号添加到空块队列中
	************************************************************************/
	void FreeBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo);

	/************************************************************************
		功能说明：
			修改根结点
	************************************************************************/
	int RootUpdate(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nBlockNo);

	/************************************************************************
		功能说明：
			删除根结点
	************************************************************************/
	int RootDelete(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID);

	/************************************************************************
		功能说明：
			释放跟结点的块
	************************************************************************/
	int FreeRootBlock(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID);

	/************************************************************************
		功能说明：
			获得根节点
	************************************************************************/
	int GetRootNo(LPEXECUTEPLANBSON lpExecutePlan, int& nRootNo, int nIndexID);

	/************************************************************************
		功能说明：
			设置根节点
	************************************************************************/
	int SetRootNo(LPEXECUTEPLANBSON lpExecutePlan, int nRootNo, int nIndexID);

	/************************************************************************
		功能说明：
			设置根节点
	************************************************************************/
	int GetFieldInfo(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, BYTE& bFieldNum, LPBYTE& bFieldType);

	/************************************************************************
		功能说明：
			获取回收映射表
	************************************************************************/
	int GetRecycleBlockNo(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int& nRecycleBlockNo);

	/************************************************************************
		功能说明：
			设置回收映射表
	************************************************************************/
	int SetRecycleBlockNo(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nRecycleBlockNo);
public:
	friend class CMemoryMultiKeyBlock;									//友元类
	friend class CMemoryMultiStr;										//友元类
	friend class CMemoryMultiNum;										//友元类

	CMemoryBTreeFile(void);
	~CMemoryBTreeFile(void);

private:
	/************************************************************************
		功能说明：
			从满块或空块链表上获取一个块对象
	************************************************************************/
	int GetBlockFromLink(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, LPLINKINFO lpLinkInfo, LPBYTE& lpBlockAddr);

	/************************************************************************
		功能说明：	
			获取字符串复合关键字的大小
	************************************************************************/
	int GetStrMultiKeySize(LPMULTIINDEX lpMultiIndex);

	/************************************************************************
		功能说明：
			获取数据区的入口地址
	************************************************************************/
	int GetIndexDataDef(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, LPBASEFILEOBJECTDEF& pIndexData);

	/************************************************************************
		功能说明：
			将关键字写入数据块
	***********************************************************************/
	int InsertKey(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);

	/************************************************************************
		功能说明：
			将一个映射表结点插入一个链表(头插法)
	************************************************************************/
	int InsertMapStruct(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, LINK_TYPE bLinkType, long long nBlockMapOffset);

	/************************************************************************
		功能说明：
			将一个某块从一个链表移动到另一个链表
	************************************************************************/
	int MoveMapStruct(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nBlockNo, LINK_TYPE bLinkType);

	/************************************************************************
		功能说明：
			从回收映射表中获取Buffer
	************************************************************************/
	int GetBufferFromRecycleMap(int nRecycleBlockNo, int nBufferSize, int nIndex, long long& nBufferOffset);
public:
	/************************************************************************
		功能说明：
			创建根节点
	************************************************************************/
	int CreateRoot(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, BYTE bFieldNum, LPBYTE bFieldType, int& nRootNo, long long nTimestamp);

	/************************************************************************
		功能说明:
			获取数据ID
	************************************************************************/
	int GetDataID(LPINDEXINFO lpIndexInfo, CDataIDContainer* pDataIDContainer);

	/************************************************************************
		功能说明：
			根据key值在索引块中插入一个新的索引项
	************************************************************************/
	int InsertIndex(LPINDEXINFO lpIndexInfo, long long nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);
	
	/************************************************************************
		功能说明：
			根据key值在索引块中删除一个新的索引项
	************************************************************************/
	int DeleteIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);

	/************************************************************************
		功能说明：
			更新索引
	************************************************************************/
	int UpdateIndex(LPINDEXINFO lpIndexInfo, long long nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);

	/************************************************************************
		功能说明：
			为某字段创建索引
	************************************************************************/	
	int CreateIndex(CServiceBson& stBson, int nObjectID, int nIndexID, LPBYTE pFieldNo,  MF_CONSTRAINT_TYPE bConstraintType);

	/************************************************************************
		功能说明：
			删除索引
	************************************************************************/
	int DropObject(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID);

	/************************************************************************
		功能说明：
			获取文件大小信息
	************************************************************************/
	int GetFileSpace(LPEXECUTEPLANBSON lpExecutePlan, long long &nFileTotalSize, long long &nFileUseSize, long long &nFileFreeSize);

	/************************************************************************
		功能说明：
			设置索引数据
	************************************************************************/
	void SetObjectData(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, long long nDataNum = 0);

	/************************************************************************
		功能说明：
			获取子索引条件的索引范围
	************************************************************************/
	int GetIndexScanScope(LPSUBINDEXPLAN lpSubIndexPlan);

	/************************************************************************
		功能说明：
			获取索引的最大关键字值和最小关键字值
	************************************************************************/
	int GetIndexRange(LPSUBINDEXPLAN lpSubIndexPlan, VARDATA& varMaxKey, VARDATA& varMinKey);

	/************************************************************************
		功能说明:
			获取文件头
	************************************************************************/
	virtual LPBASEFILEHEAD GetFileHead()
	{
		return (LPBASEFILEHEAD)m_lpMemoryFileHead;
	}

	/************************************************************************
		功能说明：
			修改时间戳
	************************************************************************/
	void TimestampUpdate(LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
	{
		//根据块的指针判断块的类型(存放哈希表的块还是存放索引项的块)
		CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeFileCritical(), lpExecutePlan);
		if(m_lpMemoryFileHead->m_nTimestamp < nTimestamp)
		{
			m_lpMemoryFileHead->m_nTimestamp = nTimestamp;
		}
	}

	/************************************************************************
		功能说明：
			备份文件数据
	************************************************************************/
	int BackUpFileData(LPBYTE lpBuffer, int nBufferSize);
};