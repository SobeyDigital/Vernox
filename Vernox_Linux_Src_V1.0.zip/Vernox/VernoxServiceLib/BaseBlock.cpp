﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "stdafx.h"
#include "BaseBlock.h"

CBaseBlock::CBaseBlock(void)
{
}

CBaseBlock::~CBaseBlock(void)
{
}

/************************************************************************
		功能说明：
			修改时间戳
		参数说明:
			lpExecutePlan：执行计划
			lpBlockHead：块头
			llTimestamp:时间戳
		特别说明:
			当块中某条数据发生变化后，要修改其所在块的时间戳
************************************************************************/
void CBaseBlock::TimestampUpdate(LPEXECUTEPLANBSON lpExecutePlan, LPBASEBLOCKHEAD lpBlockHead, long long llTimestamp)
{
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBlockCritical(), lpExecutePlan);
	//根据块的指针判断块的类型(存放哈希表的块还是存放索引项的块)
	if(lpBlockHead->m_nTimestamp != llTimestamp)
	{
		lpBlockHead->m_nTimestamp = llTimestamp;
		lpBlockHead->m_bSaveFlag  = 0;
	}
}
