﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryMultiStr.h"
#include "Check.h"


CMemoryMultiStr::CMemoryMultiStr()
{

}

CMemoryMultiStr::~CMemoryMultiStr()
{

}

/************************************************************************
		功能说明：
			获取符合关键字信息
		参数说明：
			lpAddr：地址指针
			lpMultiKeyInfo：关键字信息
		返回值说明：
			返回字段信息前的字符串长度
************************************************************************/
int CMemoryMultiStr::GetMultiKeyInfo(LPBYTE lpAddr, LPKEYINFO& lpMultiKeyInfo)
{
	int nLen;

	nLen = 4;
	while(TRUE)
	{
		if(lpAddr[nLen] == 0)
		{
			while (TRUE)
			{
				nLen++;
				if(lpAddr[nLen] != 0)
				{
					lpMultiKeyInfo = (LPKEYINFO)(lpAddr + nLen);
					break;
				}
			}
			break;
		}
		else
		{
			nLen += 4;
		}
	}
	return nLen - 5;		//在字符串末尾添加了4个字节存放0再加上字符串本身带有一个字节的结束符，所以字符串的实际长度等于nLen-5
}

/************************************************************************
		功能说明：
			根据关键字信息获取关键字值
		参数说明：
			lpKeyInfoAddr：关键字信息
			bKeyType：关键字类型
			nLevel：关键字位置
			varKey：关键字值
************************************************************************/
void CMemoryMultiStr::GetKeyValueByKeyInfo(LPBYTE lpKeyInfoAddr, MF_SYS_FIELDTYPE bKeyType, int nLevel, VARDATA& varKey)
{
	LPKEYINFO lpKeyInfo;
	lpKeyInfo = (LPKEYINFO)lpKeyInfoAddr;

	if(lpKeyInfo->m_bKeyOffset[nLevel] == 0)
	{
		//偏移为0,表示空
		varKey.m_vt = MF_VARDATA_NULL;
		return;
	}
	switch(bKeyType)
	{
	case MF_SYS_FIELDTYPE_INT:
		{
			int nData;
			nData = *(int*)(lpKeyInfoAddr + lpKeyInfo->m_bKeyOffset[nLevel]);
			varKey.SetData(nData);
		}
		break;
	case MF_SYS_FIELDTYPE_BIGINT:
		{
			long long llData;
			llData = *(long long*)(lpKeyInfoAddr + lpKeyInfo->m_bKeyOffset[nLevel]);
			varKey.SetData(llData);
		}
		break;
	case MF_SYS_FIELDTYPE_DOUBLE:
		{
			double dblData;
			dblData = *(double*)(lpKeyInfoAddr + lpKeyInfo->m_bKeyOffset[nLevel]);
			varKey.SetData(dblData, MF_SYS_FIELDTYPE_DOUBLE);
		}
		break;
	case MF_SYS_FIELDTYPE_DATE:
		{
			double dblData;
			dblData = *(double*)(lpKeyInfoAddr + lpKeyInfo->m_bKeyOffset[nLevel]);
			varKey.SetData(dblData, MF_SYS_FIELDTYPE_DATE);
		}
		break;
	default:
		{
			int nLen;
			char* pStr;
			
			pStr = (char*)(lpKeyInfoAddr + lpKeyInfo->m_bKeyOffset[nLevel]);
			nLen = *(int*)pStr - 1;
			pStr += sizeof(int);
			varKey.SetData(pStr, nLen);
		}
		break;
	}
}

/************************************************************************
		功能说明：
			实现折半查找，需要精确查找给定的Key，实现被查询的
		参数说明：
			pPatternKey：模式关键字
			nPatternLen：关键字长度
			pKey：关键字
			nLow：二分下限
			nHigh：二分上线
************************************************************************/
BOOL CMemoryMultiStr::SuffixSearch(char* pPatternKey, int nPatternLen, char* pKey, int* pSuffixMap, int nLow, int nHigh)
{
	char* pSrc;
	int	mid, low, high, n, nLen;

	low		= nLow;
	high	= nHigh - 1;
	nLen    = nHigh;

	while(low <= high)
	{
		mid	 = (low + high) / 2;
		pSrc = pKey + pSuffixMap[mid];
		n	 = CSystemManage::instance().CharCompare(pPatternKey, nPatternLen, pSrc, nLen - pSuffixMap[mid], FALSE);
		
		if(n < 0)
		{
			high = mid - 1;	
		}
		else if(n > 0)
		{
			low = mid + 1;	
		}	
		else
		{
			return TRUE;
		}
	}
	return FALSE;
}

/************************************************************************
		功能说明：
			获取结点头大小
		参数说明：
			lpMultiIndex：符合索引
************************************************************************/
int CMemoryMultiStr::GetHeadSize(LPMULTIINDEX lpMultiIndex)
{
	return sizeof(MULTINODEHEAD);
}

/************************************************************************
		功能说明：
			获取叶子大小
		参数说明：
			lpMultiIndex：符合索引
************************************************************************/
int CMemoryMultiStr::GetLeaveSize(LPMULTIINDEX lpMultiIndex)
{
	return sizeof(long long);
}

/************************************************************************
	功能说明：
		获取树干大小
	参数说明：
		lpMultiIndex：符合索引
************************************************************************/
int CMemoryMultiStr::GetTrunkSize(LPMULTIINDEX lpMultiIndex)
{	
	return sizeof(TRUNKSTRUCT);
}

/************************************************************************
		功能说明：
			获取关键字值
		参数说明：
			lpKey：关键字指针
			nLevel：值位置
			varKey：关键字值
************************************************************************/
void CMemoryMultiStr::GetKeyValue(LPVOID lpKey, int nLevel, VARDATA& varKey)
{
	int nLen;
	LPKEYINFO lpKeyInfo;
	long long nKeyOffset;
	LPBYTE lpKeyAddr, lpKeyInfoAddr;
	
	nKeyOffset = *(long long*)lpKey;
	if(nKeyOffset == 0)
	{
		varKey.m_vt = MF_VARDATA_MAX;
	}
	else
	{
		lpKeyAddr     = (LPBYTE)ConvertOffsettoAddr(nKeyOffset);
		nLen		  = GetMultiKeyInfo(lpKeyAddr, lpKeyInfo);
		lpKeyInfoAddr = (LPBYTE)lpKeyInfo;
		if(nLevel == 0)
		{
			varKey.SetData((char*)lpKeyAddr, nLen);
		}
		else
		{
			GetKeyValueByKeyInfo(lpKeyInfoAddr, m_bKeyType[nLevel], nLevel - 1, varKey);
		}
	}
}

/************************************************************************
		功能说明：
			设置关键字值
		参数说明：
			lpKey：关键字指针
			lpKeyValue：关键字值
			bInsert：是否做插入操作
-************************************************************************/
void CMemoryMultiStr::SetKeyValue(LPVOID lpKey, LPVOID lpKeyValue, BOOL bInsert)
{
	////ZHY：测试
	//char *pKeyOld, *pKeyNew;
	//pKeyOld = ConvertOffsettoAddr(*(long long*)lpKey);
	//pKeyNew = ConvertOffsettoAddr(*(long long*)lpKeyValue);
	
	long long nOffset;
	if(!bInsert)
	{
		//等于0为最大值，无需修改
		nOffset = *(long long*)lpKey;
		if(nOffset == 0)
		{
			return;
		}
	}
	*(long long*)lpKey = *(long long*)lpKeyValue;
}

/************************************************************************
	功能说明：
		获取Key的指针
	参数说明：
		lpData：数据结构体指针
		bNodeType：结点类型
************************************************************************/
LPVOID CMemoryMultiStr::GetKeyPtr(LPVOID lpData, NODETYPE bNodeType)
{
	return lpData;
}

/************************************************************************
	功能说明：
		获取MaxKey的指针
	参数说明：
		lpData：结点指针
************************************************************************/
LPVOID CMemoryMultiStr::GetMaxKeyPtr(LPBYTE lpNode)
{
	return &((LPMULTINODEHEAD)lpNode)->m_nMaxKeyOffset;
}

/************************************************************************
		功能说明：
			判断是否为最大关键字
		参数说明：
			最大关键字指针
************************************************************************/
BOOL CMemoryMultiStr::CheckMaxKey(LPVOID lpKeyPtr)
{
	long long nKeyOffset;
	nKeyOffset = *(long long*)lpKeyPtr;
	if(nKeyOffset == 0)
	{
		return TRUE;	
	}
	else
	{
		return FALSE;
	}
}

/************************************************************************
		功能说明：
			从叶子结构体中获取值，即DataID
		参数说明：
			lpLeaveData：叶子结点数据
************************************************************************/
long long CMemoryMultiStr::GetDataIDFromLeavePtr(LPVOID lpLeaveData)
{
	VARDATA varKey;
	long long nOffset;
	LPKEYINFO lpKeyInfo;
	LPBYTE lpKeyAddr, lpKeyInfoAddr;

	nOffset = *(long long*)lpLeaveData;
	if(nOffset == 0)
	{
		return 0;
	}
	else
	{
		lpKeyAddr = (LPBYTE)ConvertOffsettoAddr(nOffset);
		GetMultiKeyInfo(lpKeyAddr, lpKeyInfo);
		lpKeyInfoAddr = (LPBYTE)lpKeyInfo;

		GetKeyValueByKeyInfo(lpKeyInfoAddr, m_bKeyType[m_bKeyNum - 1], m_bKeyNum - 2, varKey);
		return varKey.m_llValue;
	}
}

/************************************************************************
		功能说明：
			从关键字指针中获取关键字值
		 参数说明：
			lpKeyPtr：关键字指针
			nIndex：关键字位置
			varData：关键字值
************************************************************************/
int CMemoryMultiStr::GetValueFromKeyPtr(LPVOID lpKeyPtr, int nIndex, VARDATA& varData)
{
	int nLen;
	LPKEYINFO lpKeyInfo;
	LPBYTE lpKeyAddr, lpKeyInfoAddr;

	lpKeyAddr = (LPBYTE)ConvertOffsettoAddr(*(long long*)lpKeyPtr);
	nLen = GetMultiKeyInfo(lpKeyAddr, lpKeyInfo);

	if(nIndex == 0)
	{
		varData.SetData((char*)lpKeyAddr, nLen);
	}
	else
	{
		lpKeyInfoAddr = (LPBYTE)lpKeyInfo;
		if(nIndex > m_bKeyNum)
		{
			return MF_FAILED;
		}
		GetKeyValueByKeyInfo(lpKeyInfoAddr, m_bKeyType[nIndex], nIndex - 1, varData);
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			设置叶子结点数据
		参数说明：
			lpLeaveData：叶子结点数据
			lpMultiIndex：复合索引
			nDataID：数据ID
************************************************************************/
void CMemoryMultiStr::SetLeaveData(LPVOID lpLeaveData, LPMULTIINDEX lpMultiIndex, long long nDataID)
{
	*(long long*)lpLeaveData = lpMultiIndex->m_lpIndexCondition[0].m_varCondition1.m_llValue;
}

/************************************************************************
		功能说明：
			从树干结构体中获取值，即结点编号
		参数说明：
			lpTrunkData：树干结点数据
************************************************************************/
int CMemoryMultiStr::GetNodeNoFromTrunk(LPVOID lpTrunkData)
{
	return ((LPTRUNKSTRUCT)lpTrunkData)->m_nNodeNo;
}
	
/************************************************************************
		功能说明：
			在树干树干中设置节点编号
		参数说明：
			lpTrunkData：树干结点数据
			nNodeNo：结点编号
************************************************************************/
void CMemoryMultiStr::SetNodeNoToTrunk(LPVOID lpTrunkData, int nNodeNo) 
{
	((LPTRUNKSTRUCT)lpTrunkData)->m_nNodeNo = nNodeNo;
}

/************************************************************************
		功能说明：
			设置树干结点数据
		参数说明：
			lpTrunkData：树干结点数据
			lpMultiIndex：复合索引
			nDataID：数据ID
************************************************************************/
void CMemoryMultiStr::SetTrunkData(LPVOID lpTrunkData, LPMULTIINDEX lpMultiIndex, int nNodeNo)
{
	((LPTRUNKSTRUCT)lpTrunkData)->m_nMaxKeyOffset = lpMultiIndex->m_lpIndexCondition[0].m_varCondition1.m_llValue;
	((LPTRUNKSTRUCT)lpTrunkData)->m_nNodeNo = nNodeNo;
}

/************************************************************************
		功能说明：
			设置索引字段数据
		参数说明：
			lpMultiIndex：复合索引
			lpKey：关键字
************************************************************************/
void CMemoryMultiStr::SetIndexField(LPMULTIINDEX lpMultiIndex, LPVOID lpKey)
{
	int n;
	VARDATA varKey;
	LPINDEXCONDITION lpIndexField;
	for(n = 0; n < (int)lpMultiIndex->m_nIndexNum; n++)
	{
		lpIndexField = &lpMultiIndex->m_lpIndexCondition[n];
		if(n == 0)
		{
			lpIndexField->m_varCondition1.SetData(*(long long*)lpKey);
		}
		GetKeyValue(lpKey, n, varKey);
		lpIndexField->m_varCondition2.SetData(varKey);
	}
}
	
/************************************************************************
		功能说明：
			比较函数
		参数说明：
			lpMultiIndex：复合索引
			lpKey：关键字
			bOperator：操作类型
************************************************************************/
int CMemoryMultiStr::Compare(LPMULTIINDEX lpMultiIndex, LPVOID lpKey, BYTE bOperator, BOOL& bFindKey)
{
	int i, n, nLen;
	LPKEYINFO lpKeyInfo;
	long long llKeyOffset;
	VARDATA varKey1, varKey2;
	LPINDEXCONDITION lpIndexField;
	LPBYTE lpKeyInfoAddr, lpKeyAddr;
	//获取关键字信息
	llKeyOffset   = *(long long*)lpKey;
	lpKeyAddr     = (LPBYTE)ConvertOffsettoAddr(llKeyOffset);
	if(llKeyOffset == 0)
	{
		return -1;
	}
	else
	{
		nLen		  = GetMultiKeyInfo(lpKeyAddr, lpKeyInfo);
		lpKeyInfoAddr = (LPBYTE)lpKeyInfo;
		for(i = 0;  i < (int)lpMultiIndex->m_nIndexNum; i++)
		{
			if(bOperator == OPERATOR_INSERT && i + 1 >= lpMultiIndex->m_nIndexNum)
			{
				bFindKey = TRUE;		//对于Insert情况，最后一个字段(DataID)不参与关键字的比较
			}
			lpIndexField = &lpMultiIndex->m_lpIndexCondition[i];
			if(lpIndexField->m_bOperator == MF_EXECUTEPLAN_OPERATOR_NOTEQUAL || lpIndexField->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESS ||
				lpIndexField->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESSEQUAL)
			{
				break;
			}

			if(bOperator == OPERATOR_INSERT)
			{
				varKey1.SetData(lpIndexField->m_varCondition2);
			}
			else
			{
				varKey1.SetData(lpIndexField->m_varCondition1);
			}
			if(i == 0)
			{
				varKey2.SetData((char*)lpKeyAddr, nLen);
			}
			else
			{
				GetKeyValueByKeyInfo(lpKeyInfoAddr, lpIndexField->m_bFieldType, i - 1, varKey2);
			}
			n = CMemoryBTreeIndex::Compare(varKey1, varKey2, bOperator == OPERATOR_SEARCH);
			if(n != 0)
			{
				return n;
			}

			if(lpIndexField->m_bOperator != MF_EXECUTEPLAN_OPERATOR_EQUAL)
			{
				break;
			}
		}
	}

	bFindKey = TRUE;
	return 0;
}
	
/************************************************************************
		功能说明：
			判断值是否合法
		参数说明：
			lpIndexField：索引字段
			lpKey：关键字
			nLevel：递归层数
			bContinue：是否可以继续循环
			bPush：是否可以Push数据ID
************************************************************************/
void CMemoryMultiStr::CheckDataValid(LPINDEXINFO lpIndexInfo, LPVOID lpKey, int nLevel, BOOL& bContinue, BOOL& bPush)
{
	int n;
	BOOL bCheck;
	VARDATA varKey;
	LPINDEXCONDITION lpIndexField;
	MF_EXECUTEPLAN_OPERATOR bOperator;
     
	bCheck			= TRUE;
	bContinue		= TRUE;
	bPush			= FALSE;

	for(n = 0; n < (int)lpIndexInfo->m_stMultiIndex.m_nIndexNum; n++)
	{
		GetKeyValue(lpKey, n, varKey);
		lpIndexField = &lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[n];
		bOperator	 = lpIndexField->m_bOperator;
		switch(bOperator)
		{
		case MF_EXECUTEPLAN_OPERATOR_EQUAL:
			if(varKey != lpIndexField->m_varCondition1)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_NOTEQUAL:
			if(varKey == lpIndexField->m_varCondition1)
			{
				bCheck	  = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_GREATER:
			if(varKey <= lpIndexField->m_varCondition1)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
			if(varKey < lpIndexField->m_varCondition1)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_LESS:
			if(varKey >= lpIndexField->m_varCondition1)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
			if(varKey > lpIndexField->m_varCondition1)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEEN:
			if(varKey > lpIndexField->m_varCondition2)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			else if(varKey < lpIndexField->m_varCondition1)
			{
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
			if(varKey > lpIndexField->m_varCondition2)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			else if(varKey <= lpIndexField->m_varCondition1)
			{
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENE:
			if(varKey >= lpIndexField->m_varCondition2)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			else if(varKey < lpIndexField->m_varCondition1)
			{
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENBE:
			if(varKey >= lpIndexField->m_varCondition2)
			{
				if(n <= nLevel)
				{
					bContinue = FALSE;
				}
				bCheck = FALSE;
			}
			else if(varKey <= lpIndexField->m_varCondition1)
			{
				bCheck = FALSE;
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_LIKE:
			if(n == 0)
			{
				if(lpIndexInfo->m_pParam2 == lpIndexInfo->m_pParam3)
				{
					bContinue = FALSE;
					bCheck    = FALSE;
				}
				else
				{
					if(lpIndexInfo->m_pParam3 == NULL)
					{
						//获取最后一个元素时会出现这样的情况
						bContinue = FALSE;
					}
					if(lpIndexField->m_varCondition1.m_bParam1 == 2 || lpIndexField->m_varCondition1.m_bParam2 == 2)
					{
						int n;
						char * pValue;
						//需要用找子串的办法重新确定一下条件是否满足
						pValue = varKey.m_lpszValue;
						n = -1;
						while(*(pValue + n) != 0)
						{
							n --;
						}
						n++;
						if(0 == CSystemManage::instance().CharFind(pValue + n, varKey.m_nStrLen - n, lpIndexField->m_varCondition1.m_lpszValue, lpIndexField->m_varCondition1.m_nStrLen - 1))
						{
							bCheck = TRUE;
						}
						else
						{
							bCheck = FALSE;
						}
					}
					else
					{
						if(lpIndexField->m_varCondition1.m_bParam1 == 0)
						{
							//没有前百分号
							if(varKey.m_lpszValue[-1] != 0)
							{
								bCheck = FALSE;
							}
						}
						if(lpIndexField->m_varCondition1.m_bParam2 == 0)
						{
							//数一下前面的百分号个数
							int nStrLen;
							char *pValue;
							nStrLen = lpIndexField->m_varCondition1.m_nStrLen - 1;
							pValue  = lpIndexField->m_varCondition1.m_lpszValue;
							while(pValue[0] == MF_OPERATOR_PERCENT)
							{
								nStrLen--;
								pValue++;
							}

							if(varKey.m_lpszValue[nStrLen] != 0)
							{
								bCheck = FALSE;
							}
						}
					}
				}
			}
			else
			{
				//处理前后百分号
				VARDATA varKey2;
				int nMapLen, *pSuffixMap;
				RemovePercent(lpIndexField->m_varCondition1.m_lpszValue, lpIndexField->m_varCondition1.m_nStrLen, varKey2);				
				//获取后缀数组
				pSuffixMap = (int*)(varKey.m_lpszValue + varKey.m_nStrLen + 1);
				nMapLen	   = *pSuffixMap;
				pSuffixMap++;
				if(SuffixSearch(varKey2.m_lpszValue, varKey2.m_nStrLen, varKey.m_lpszValue, pSuffixMap, 0 ,nMapLen))
				{
					//判断前后百分号
					if(!varKey2.m_bParam1)
					{
						//后百分号
						if(varKey.m_lpszValue[-1] != 0)
						{
							bCheck = FALSE;
						}
					}

					if(!varKey2.m_bParam2)
					{
						//前百分号
						if(varKey.m_lpszValue[varKey2.m_nStrLen - 1] != 0)
						{
							bCheck = FALSE;
						}
					}
				}
				else
				{
					if(n <= nLevel)
					{
						bContinue = FALSE;
					}
					bCheck = FALSE;
				}	
				
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_IN:
			{
				int *lpHashTable, nHashTableOffset;
				nHashTableOffset = lpIndexField->m_varCondition2.m_nValue;
				lpHashTable		 = (int*)lpIndexInfo->m_pBson->ConvertOffset2Addr(nHashTableOffset);
				if(!varKey.In(lpIndexInfo->m_pBson, lpHashTable, lpIndexField->m_varCondition1.m_nValue))
				{
					bCheck = FALSE;
				}
			}
			break;
		case MF_EXECUTEPLAN_OPERATOR_NOTIN:
			{
				int *lpHashTable, nHashTableOffset;
				nHashTableOffset = lpIndexField->m_varCondition2.m_nValue;
				lpHashTable		 = (int*)lpIndexInfo->m_pBson->ConvertOffset2Addr(nHashTableOffset);
				if(varKey.In(lpIndexInfo->m_pBson, lpHashTable, lpIndexField->m_varCondition1.m_nValue))
				{
					bCheck = FALSE;
				}
			}
			break;
		}

		if(!bContinue || !bCheck)
		{
			break;
		}
	}

	if(bCheck)
	{
		if(!lpIndexInfo->m_pCheck || lpIndexInfo->m_pCheck->CheckRecordValid(lpIndexInfo->m_nDataID))
		{
			if(lpIndexInfo->m_bPagingType == MF_PAGING_FIRST)
			{
				if(lpIndexInfo->m_nCount >= lpIndexInfo->m_nPagePos)
				{
					bPush = TRUE;
				}
				lpIndexInfo->m_nCount++;
			}
			else
			{
				bPush = TRUE;
			}
		}
	}
}

/************************************************************************
		功能说明:
			初始化块头
			判断值是否合法
		参数说明：
			lpNodeHead：结点头
			nDataSize：数据大小
			nHeadSize：结点头大小
			nNodeTypeFlag：结点类型
************************************************************************/
void CMemoryMultiStr::InitialBlock(LPVOID lpNodeHead, int nDataSize, int nHeadSize, BYTE nNodeTypeFlag)
{
	LPMULTINODEHEAD lpMultiNodeHead;
	
	lpMultiNodeHead = (LPMULTINODEHEAD)lpNodeHead;
	
	lpMultiNodeHead->m_nBlockHeadSize	= nHeadSize;
	lpMultiNodeHead->m_bNodeType		= nNodeTypeFlag;
	lpMultiNodeHead->m_nDataSize		= nDataSize;
	lpMultiNodeHead->m_nTotalDataNum	= (lpMultiNodeHead->m_nBlockSize - nHeadSize) / nDataSize;
	lpMultiNodeHead->m_nTotalDataNum	= lpMultiNodeHead->m_nTotalDataNum / 2 * 2;			//变为2的整数倍
	lpMultiNodeHead->m_nDataNum			= 0;
	lpMultiNodeHead->m_nMaxKeyOffset	= 0;
	lpMultiNodeHead->m_nNextNodeNo		= 0;
	lpMultiNodeHead->m_nPreNodeNo		= 0;
}
