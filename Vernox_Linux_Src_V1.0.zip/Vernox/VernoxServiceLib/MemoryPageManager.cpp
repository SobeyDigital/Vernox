﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryPageManager.h"
CMemoryPageManager::CMemoryPageManager(void)
{
	m_pBuffer = NULL;
	m_nBufferSize = 0;
	m_nFreeMemPos = 0;
}

CMemoryPageManager::~CMemoryPageManager(void)
{
	if(m_pBuffer != NULL)
	{
		delete [] m_pBuffer;
		m_pBuffer = NULL;
	}
}

/************************************************************************
		功能说明：
			分配空间
		参数说明：
			nBufferNo:缓存编号
			nTotalDataNum：DataID总数
			nPageDataNum：页面数据数
			pBuffer：缓存指针
************************************************************************/
int CMemoryPageManager::Alloc(long long nBufferNo, int nTotalDataNum, int nPageDataNum, char* &pBuffer)
{
	LPPAGEBUFFERHEAD pPageBufferHead;
	int nBufferSize, nPageNum, nHeadSize;
	//1.计算所有页面的总大小，并分配空间
	if(nTotalDataNum % nPageDataNum != 0)
	{
		nPageNum = nTotalDataNum / nPageDataNum + 1;
	}
	else
	{
		nPageNum = nTotalDataNum / nPageDataNum;
	}
	nBufferSize = nPageNum*(sizeof(PAGEHEAD) + (nPageDataNum - 1)*sizeof(long long));		
	nHeadSize = sizeof(PAGEBUFFERHEAD) + sizeof(int)*(nPageNum - 1);
	nBufferSize += nHeadSize;										
	
	if(nBufferSize > m_nBufferSize)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	else
	{
		pBuffer = m_pBuffer + m_nFreeMemPos;
	}
	
	if(m_nFreeMemPos + nBufferSize > m_nBufferSize)
	{
		//直接覆盖Buffer开始位置的数据
		m_nFreeMemPos =  m_nFreeMemPos + nBufferSize - m_nBufferSize;
	}
	else
	{
		m_nFreeMemPos = m_nFreeMemPos + nBufferSize;
	}
	pPageBufferHead = (LPPAGEBUFFERHEAD)pBuffer;
	pPageBufferHead->m_nDataFlag	= MAKEHEADFLAG('S','B','B','H');
	pPageBufferHead->m_nBufferSize	= nBufferSize;
	pPageBufferHead->m_nPageNum		= nPageNum;
	pPageBufferHead->m_nPageDataNum = nPageDataNum;
	pPageBufferHead->m_arrPgeMap[0] = nBufferSize;
	pPageBufferHead->m_nBufferNo	= nBufferNo;
	
	m_mapBufferMap.insert(pair<long long, char*>(nBufferNo, pBuffer));
	return MF_OK;
}

/************************************************************************
	功能说明：
		初始化Buffer
	参数说明：
		nBufferSize：页面大小
************************************************************************/
int CMemoryPageManager::InitialBuffer(int nBufferSize)
{
	//m_pBuffer = (char*)CSystemManage::instance().AllocTemporaryMem(nBufferSize);
	m_pBuffer = new char[nBufferSize];
	if(m_pBuffer == NULL)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	m_nBufferSize = nBufferSize;
	return MF_OK;
}

/************************************************************************
		功能说明：
			分页
		参数说明：
			nBufferNo：缓存编号
			pDataIDContainer：DataID容器
			nPageDataNum:页面数据条数
************************************************************************/
int CMemoryPageManager::Paging(long long nBufferNo, CDataIDContainer* pDataIDContainer, int nPageDataNum)
{
	//char* pPageBuffer;
	//LPPAGEHEAD lpPageHead;
	//LPPAGEBUFFERHEAD lpPageBufferHead;
	//int nRet, i, j, nDataNum, *arrMap, nCount, nPageSize;

	//pPageBuffer = NULL;
	//nDataNum = pDataIDContainer.size();
	//nRet = Alloc(nBufferNo, nDataNum, nPageDataNum, pPageBuffer);
	//if(nRet != MF_OK)
	//{
	//	return nRet;
	//}

	//nCount = 0;
	//lpPageBufferHead = (LPPAGEBUFFERHEAD)pPageBuffer;
	//nPageSize = sizeof(PAGEHEAD) + (nPageDataNum - 1)*sizeof(long long);
	//arrMap = lpPageBufferHead->m_arrPgeMap;
	//for(i = 0; i < lpPageBufferHead->m_nPageNum; i++)
	//{
	//	lpPageHead = (LPPAGEHEAD)(pPageBuffer + arrMap[i]);
	//	memset(lpPageHead, 0, sizeof(PAGEHEAD));
	//	lpPageHead->m_nPageNo = i + 1;
	//	lpPageHead->m_nDataFlag = MAKEHEADFLAG('S', 'B', 'P', 'H');
	//	for(j = 0; j < nPageDataNum; j++)
	//	{
	//		lpPageHead->m_arrDataID[j] = pDataIDContainer[nCount];
	//		lpPageHead->m_nDataIDNum++;
	//		nCount++;
	//		if(nCount >= nDataNum)
	//		{
	//			return MF_OK;
	//		}
	//	}
	//	if(arrMap[i] + nPageSize > m_nBufferSize)
	//	{
	//		arrMap[i+1] = 0;
	//	}
	//	else
	//	{
	//		arrMap[i+1] = arrMap[i] + nPageSize;
	//	}
	//}
	return MF_PAGING_ERROR;
}

/************************************************************************
		功能说明：
			获取页面
		参数说明：
			nBufferNo：缓存编号
			nPageNo：页面编号
			nPageDataNum:页面大小
			pDataIDContainer：DataID容器
************************************************************************/
int CMemoryPageManager::GetPage(long long nBufferNo, int nPageNo, int nPageDataNum, CDataIDContainer* pDataIDContainer)
{
	int i;
	char* pBuffer;
	LPPAGEHEAD pPageHead;
	LPPAGEBUFFERHEAD pBufferHead;
	map<long long, char*>::iterator iter;

	iter = m_mapBufferMap.find(nBufferNo);
	if(iter == m_mapBufferMap.end())
	{
		return MF_PAGING_INVALIDBUFFERNO_ERROR;
	}
	else
	{
		pBuffer = iter->second;
	}

	pBufferHead = (LPPAGEBUFFERHEAD)pBuffer;
	if(pBufferHead->m_nDataFlag != MAKEHEADFLAG('S','B','B','H'))
	{
		return MF_PAGING_PAGETIMEOUT_ERROR;
	}
	if(pBufferHead->m_nPageDataNum != nPageDataNum)
	{
		return MF_PAGING_PAGETIMEOUT_ERROR;
	}	
	if(nPageNo > pBufferHead->m_nPageNum)
	{
		return MF_OK;
	}
	pPageHead = (LPPAGEHEAD)(pBuffer + pBufferHead->m_arrPgeMap[nPageNo - 1]);
	if(pPageHead->m_nDataFlag != MAKEHEADFLAG('S','B','P','H'))
	{
		return MF_PAGING_PAGETIMEOUT_ERROR;
	}
	for(i = 0; i < pPageHead->m_nDataIDNum; i++)
	{
		pDataIDContainer->push_back(pPageHead->m_arrDataID[i]);
	}
	return MF_OK;
}