﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "Check.h"
#include "FunctionManager.h"
#include "MemoryHashFile.h"

Check::Check() 
{
	m_pMemoryFile				= NULL;
	m_pBson						= NULL;
	m_lpTransactionArray		= NULL;
	m_nTimestamp				= 0;
	m_nWhereOffset				= 0;
}

Check::~Check(void) 
{
}

CheckHBTreeIndex::CheckHBTreeIndex(void) 
{
	m_pStartDataID = NULL;
	m_lpQueryInfo  = NULL;
}

CheckHBTreeIndex::~CheckHBTreeIndex(void) {
}

/************************************************************************
	 功能说明：
		从记录中获取字符串型字段值
	 参数说明：
		 nDataID：数据ID(用于ROWNUM)
		 lpRecordBuffer：记录Buffer
		 nBufferLen：缓存大小
		 lpCompareExp：比较表达式
		 bResult：结果
 ************************************************************************/
int Check::Compare(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen, LPCOMPAREEXPBSON lpCompareExp, BOOL& bResult)
{
	int nRet;
	LPMATHEXPBSON lpMathExp;
	VARDATA varData1, varData2, varData3;
	if (lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_IN || lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_NOTIN) 
	{
		LPDATANODE lpDataNode;
		LPINCONDITIONBSON lpInCondition;
		int nDataPos, *lpHashTable, nDataNodeOffset;

		if (lpCompareExp->m_nMathExpOffset1 != 0) 
		{
			lpMathExp = (LPMATHEXPBSON) m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset1);
			nRet = m_stExpression.GetExpressionResult(nDataID, lpRecordBuffer, nBufferLen, lpMathExp, varData1);
			if (nRet != MF_OK) 
			{
				return nRet;
			}
		}
		else 
		{
			bResult = FALSE;
			return MF_OK;
		}

		if (lpCompareExp->m_nMathExpOffset2 != 0) 
		{
			lpInCondition = (LPINCONDITIONBSON) m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset2);
		} 
		else 
		{
			return FALSE;
		}
		lpHashTable = (int*) m_pBson->ConvertOffset2Addr(lpInCondition->m_nHashTableOffset);
		if (lpInCondition->m_bDataType == MF_VARDATA_STRING) 
		{
			nDataPos = CalcKeyHash((LPBYTE) varData1.m_lpszValue, lpInCondition->m_nDataNum);
		} 
		else 
		{
			nDataPos = CalcKeyHash(varData1.m_llValue,lpInCondition->m_nDataNum);
		}
		nDataNodeOffset = lpHashTable[nDataPos];
		while (nDataNodeOffset) 
		{
			lpDataNode = (LPDATANODE) m_pBson->ConvertOffset2Addr(nDataNodeOffset);
			switch (lpInCondition->m_bDataType) 
			{
			case MF_VARDATA_INT64:
				varData2.SetData(*(long long*) lpDataNode->m_pDataBuffer);
				break;
			case MF_VARDATA_DOUBLE:
				varData2.SetData(*(double*) lpDataNode->m_pDataBuffer, MF_VARDATA_DOUBLE);
				break;
			case MF_VARDATA_STRING:
				varData2.SetData(lpDataNode->m_pDataBuffer,lpDataNode->m_nDataLen);
				break;
			}
			if (varData1 == varData2) 
			{
				if (lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_IN) 
				{
					bResult = TRUE;
					return MF_OK;
				} 
				else if (lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_NOTIN) 
				{
					bResult = FALSE;
					return MF_OK;
				}
			}
			nDataNodeOffset = lpDataNode->m_nNextOffset;
		}
		if (lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_IN)
		{
			bResult = FALSE;
			return MF_OK;
		} 
		else 
		{
			bResult = TRUE;
			return MF_OK;
		}
	} 
	else 
	{
		if (lpCompareExp->m_nMathExpOffset1 != 0)
		{
			lpMathExp = (LPMATHEXPBSON) m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset1);
			nRet = m_stExpression.GetExpressionResult(nDataID, lpRecordBuffer, nBufferLen, lpMathExp, varData1);
			if (nRet != MF_OK) 
			{
				return nRet;
			}
		}
		if (lpCompareExp->m_nMathExpOffset2 != 0) 
		{
			lpMathExp = (LPMATHEXPBSON) m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset2);
			nRet = m_stExpression.GetExpressionResult(nDataID, lpRecordBuffer, nBufferLen, lpMathExp, varData2);
			if (nRet != MF_OK) 
			{
				return nRet;
			}

		}
		if (lpCompareExp->m_nMathExpOffset3 != 0) 
		{
			lpMathExp = (LPMATHEXPBSON) m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset3);
			nRet = m_stExpression.GetExpressionResult(nDataID, lpRecordBuffer, nBufferLen, lpMathExp, varData3);
			if (nRet != MF_OK) 
			{
				return nRet;
			}
		}
		if(varData1.m_vt == MF_VARDATA_NULL || varData2.m_vt == MF_VARDATA_NULL || varData3.m_vt == MF_VARDATA_NULL)
		{
			bResult = FALSE;
			return MF_OK;
		}

		switch (lpCompareExp->m_bOperator) 
		{
		case MF_EXECUTEPLAN_OPERATOR_BETWEEN:
			bResult = (varData2 <= varData1) && (varData3 >= varData1);
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
			bResult = (varData2 <= varData1) && (varData3 > varData1);
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENE:
			bResult = (varData2 < varData1) && (varData3 >= varData1);
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENBE:
			bResult = (varData2 < varData1) && (varData3 > varData1);
			break;
		case MF_EXECUTEPLAN_OPERATOR_EQUAL:
			bResult = varData1 == varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_NOTEQUAL:
			bResult = varData1 != varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_GREATER:
			bResult = varData1 > varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
			bResult = varData1 >= varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_LESS:
			bResult = varData1 < varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
			bResult = varData1 <= varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_LIKE:
			bResult = (-1 != CSystemManage::instance().CharFind(varData1.m_lpszValue, varData1.m_nStrLen,varData2.m_lpszValue, varData2.m_nStrLen - 1));
			break;
		default:
			return MF_COMMON_INVALID_OPERATOR;
		}
	}
	if (lpCompareExp->m_bLogicNot) 
	{
		bResult = !bResult;
	}
	return MF_OK;
}

int Check::Compare(LPRECORDDATAINFO lpRecordInfo, LPCOMPAREEXPBSON lpCompareExp, BOOL& bResult)
{
	int nRet;
	LPMATHEXPBSON lpMathExp;
	VARDATA varData1, varData2, varData3;
	if (lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_IN || lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_NOTIN) 
	{
		LPDATANODE lpDataNode;
		LPINCONDITIONBSON lpInCondition;
		int nDataPos, *lpHashTable, nDataNodeOffset;

		if (lpCompareExp->m_nMathExpOffset1 != 0) 
		{
			lpMathExp = (LPMATHEXPBSON) m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset1);
			nRet = m_stExpression.GetExpressionResult(lpRecordInfo, lpMathExp, varData1);
			if (nRet != MF_OK) 
			{
				return nRet;
			}
		}
		else 
		{
			bResult = FALSE;
			return MF_OK;
		}

		if (lpCompareExp->m_nMathExpOffset2 != 0) 
		{
			lpInCondition = (LPINCONDITIONBSON) m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset2);
		} 
		else 
		{
			return FALSE;
		}
		lpHashTable = (int*) m_pBson->ConvertOffset2Addr(lpInCondition->m_nHashTableOffset);
		if (lpInCondition->m_bDataType == MF_VARDATA_STRING) 
		{
			nDataPos = CalcKeyHash((LPBYTE) varData1.m_lpszValue, lpInCondition->m_nDataNum);
		} 
		else 
		{
			nDataPos = CalcKeyHash(varData1.m_llValue,lpInCondition->m_nDataNum);
		}
		nDataNodeOffset = lpHashTable[nDataPos];
		while (nDataNodeOffset) 
		{
			lpDataNode = (LPDATANODE) m_pBson->ConvertOffset2Addr(nDataNodeOffset);
			switch (lpInCondition->m_bDataType) 
			{
			case MF_VARDATA_INT64:
				varData2.SetData(*(long long*) lpDataNode->m_pDataBuffer);
				break;
			case MF_VARDATA_DOUBLE:
				varData2.SetData(*(double*) lpDataNode->m_pDataBuffer, MF_VARDATA_DOUBLE);
				break;
			case MF_VARDATA_STRING:
				varData2.SetData(lpDataNode->m_pDataBuffer,lpDataNode->m_nDataLen);
				break;
			}
			if (varData1 == varData2) 
			{
				if (lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_IN) 
				{
					bResult = TRUE;
					return MF_OK;
				} 
				else if (lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_NOTIN) 
				{
					bResult = FALSE;
					return MF_OK;
				}
			}
			nDataNodeOffset = lpDataNode->m_nNextOffset;
		}
		if (lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_IN)
		{
			bResult = FALSE;
			return MF_OK;
		} 
		else 
		{
			bResult = TRUE;
			return MF_OK;
		}
	} 
	else 
	{
		if (lpCompareExp->m_nMathExpOffset1 != 0)
		{
			lpMathExp = (LPMATHEXPBSON) m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset1);
			nRet = m_stExpression.GetExpressionResult(lpRecordInfo, lpMathExp, varData1);
			if (nRet != MF_OK) 
			{
				return nRet;
			}
		}
		if (lpCompareExp->m_nMathExpOffset2 != 0) 
		{
			lpMathExp = (LPMATHEXPBSON) m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset2);
			nRet = m_stExpression.GetExpressionResult(lpRecordInfo, lpMathExp, varData2);
			if (nRet != MF_OK) 
			{
				return nRet;
			}

		}
		if (lpCompareExp->m_nMathExpOffset3 != 0) 
		{
			lpMathExp = (LPMATHEXPBSON) m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset3);
			nRet = m_stExpression.GetExpressionResult(lpRecordInfo, lpMathExp, varData3);
			if (nRet != MF_OK) 
			{
				return nRet;
			}
		}
		if(varData1.m_vt == MF_VARDATA_NULL || varData2.m_vt == MF_VARDATA_NULL || varData3.m_vt == MF_VARDATA_NULL)
		{
			bResult = FALSE;
			return MF_OK;
		}

		switch (lpCompareExp->m_bOperator) 
		{
		case MF_EXECUTEPLAN_OPERATOR_BETWEEN:
			bResult = (varData2 <= varData1) && (varData3 >= varData1);
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
			bResult = (varData2 <= varData1) && (varData3 > varData1);
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENE:
			bResult = (varData2 < varData1) && (varData3 >= varData1);
			break;
		case MF_EXECUTEPLAN_OPERATOR_BETWEENBE:
			bResult = (varData2 < varData1) && (varData3 > varData1);
			break;
		case MF_EXECUTEPLAN_OPERATOR_EQUAL:
			bResult = varData1 == varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_NOTEQUAL:
			bResult = varData1 != varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_GREATER:
			bResult = varData1 > varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
			bResult = varData1 >= varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_LESS:
			bResult = varData1 < varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
			bResult = varData1 <= varData2;
			break;
		case MF_EXECUTEPLAN_OPERATOR_LIKE:
			bResult = (-1 != CSystemManage::instance().CharFind(varData1.m_lpszValue, varData1.m_nStrLen,varData2.m_lpszValue, varData2.m_nStrLen - 1));
			break;
		default:
			return MF_COMMON_INVALID_OPERATOR;
		}
	}
	if (lpCompareExp->m_bLogicNot) 
	{
		bResult = !bResult;
	}
	return MF_OK;
}

int Check::Compare(LPSINGLERECORD lpDataArray, LPCOMPAREEXPBSON lpCompareExp, BOOL& bResult)
{
	int nRet;
	LPMATHEXPBSON lpMathExp;
	VARDATA varData1, varData2, varData3;

	if(lpCompareExp->m_nMathExpOffset1 != 0)
	{
		lpMathExp = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset1);
		nRet = m_stExpression.GetExpressionResult(lpDataArray, lpMathExp, varData1);
	}
	if(lpCompareExp->m_nMathExpOffset2 != 0)
	{
		lpMathExp = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset2);
		nRet = m_stExpression.GetExpressionResult(lpDataArray, lpMathExp, varData2);

	}
	if(lpCompareExp->m_nMathExpOffset3 != 0)
	{
		lpMathExp = (LPMATHEXPBSON)m_pBson->ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset3);
		nRet = m_stExpression.GetExpressionResult(lpDataArray, lpMathExp, varData3);
	}
	if(nRet != MF_OK)
	{
		return nRet;
	}
	switch(lpCompareExp->m_bOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_BETWEEN:
		bResult = (varData2 <= varData1) && (varData3 >=  varData1);
		break;
	case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
		bResult = (varData2 <= varData1) && (varData3 >  varData1);
		break;
	case MF_EXECUTEPLAN_OPERATOR_BETWEENE:
		bResult = (varData2 < varData1) && (varData3 >=  varData1);
		break;
	case MF_EXECUTEPLAN_OPERATOR_BETWEENBE:
		bResult = (varData2 < varData1) && (varData3 >  varData1);
		break;
	case MF_EXECUTEPLAN_OPERATOR_EQUAL:
		bResult = varData1 == varData2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_NOTEQUAL:
		bResult = varData1 != varData2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_GREATER:
		bResult = varData1 > varData2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
		bResult = varData1 >= varData2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_LESS:
		bResult = varData1 < varData2;
		break;
	case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
		bResult = varData1 <= varData2;
		break;
	default:
		return MF_COMMON_INVALID_OPERATOR;
	}
	return MF_OK;
}

/************************************************************************
 功能说明：
 初始化
 参数说明：
 pBson：Bson对象
 lpQueryInfo：查询信息
 ************************************************************************/
int Check::Initial(CServiceBson* pBson, LPQUERYINFO lpQueryInfo) 
{
	int nRet;
	LPOBJECTDEF lpObjectInfo;
	IVirtualMemoryFile* pVirtualFile;

	//初始化最基本的查询信息
	//该信息包括Bson对象，文件指针，查询条件
	//Bson对象提供临时内存空间，用于通过文件指针和查询条件获取字段值
	m_pBson					= pBson;
	if(lpQueryInfo != NULL)
	{
		lpObjectInfo = lpQueryInfo->m_lpObjectInfo;
		nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
		if (nRet != MF_OK) 
		{
			return nRet;
		}

		m_pMemoryFile			= (CMemoryFile*) pVirtualFile;
		m_nTimestamp			= lpQueryInfo->m_nTimestamp;
		m_lpTransactionArray	= lpQueryInfo->m_lpTransactionArray;
		m_nWhereOffset			= lpQueryInfo->m_nWhereOffset;
	}
	else
	{
		lpObjectInfo			= NULL;
	}
	
	m_stExpression.Initial(m_pBson, lpObjectInfo);
	return MF_OK;
}

/************************************************************************
 功能说明：
 判断查询条件是否合法
 参数说明：
 nDataID：数据ID用于ROWID字段
 lpRecordBuffer：记录Buffer
 nBufferLen：Buffer长度
 lpCondition：条件表达式
 bValid：是否合法
 ************************************************************************/
int Check::CheckValid(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen, LPBASECONDITIONBSON lpCondition, BOOL& bValid)
{
	int nRet;
	BOOL bResult1, bResult2;
	LPCOMPAREEXPBSON lpCompareExp1, lpCompareExp2;
	LPBASECONDITIONBSON lpCondition1, lpCondition2;

	//根据条件判断记录是否合法
	if (lpCondition == NULL)
	{
		bValid = TRUE;
		return MF_OK;
	}

	bResult1 = FALSE;
	bResult2 = FALSE;
	//计算条件1的逻辑结果
	if(MF_CONDITION_INVALID == lpCondition->m_bConditionType1 || MF_CONDITION_ROWNUM == lpCondition->m_bConditionType1) 
	{
		bResult1 = TRUE;
		lpCondition->m_bLogicOperator = MF_EXECUTEPLAN_OPERATOR_AND;
	} 
	else if(MF_CONDITION_LOGIC == lpCondition->m_bConditionType1) 
	{
		lpCondition1 = (LPBASECONDITIONBSON) m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset1);
		nRet = CheckValid(nDataID, lpRecordBuffer, nBufferLen, lpCondition1, bResult1);
		if (nRet != MF_OK) 
		{
			return nRet;
		}
	} 
	else 
	{
		//做比较运算
		lpCompareExp1 = (LPCOMPAREEXPBSON) m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset1);
		nRet = Compare(nDataID, lpRecordBuffer, nBufferLen, lpCompareExp1, bResult1);
		if (nRet != MF_OK) 
		{
			return nRet;
		}
	}

	//计算条件2的逻辑结果
	if (MF_CONDITION_INVALID == lpCondition->m_bConditionType2 || MF_CONDITION_ROWNUM == lpCondition->m_bConditionType2) 
	{
		bResult2 = TRUE;
		lpCondition->m_bLogicOperator = MF_EXECUTEPLAN_OPERATOR_AND;
	}
	else if(MF_CONDITION_LOGIC == lpCondition->m_bConditionType2) 
	{
		lpCondition2 = (LPBASECONDITIONBSON) m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset2);
		nRet = CheckValid(nDataID, lpRecordBuffer, nBufferLen, lpCondition2, bResult2);
		if (nRet != MF_OK) 
		{
			return nRet;
		}
	}
	else
	{
		//做比较运算
		lpCompareExp2 = (LPCOMPAREEXPBSON) m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset2);
		nRet = Compare(nDataID, lpRecordBuffer, nBufferLen, lpCompareExp2, bResult2);
		if (nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算总的逻辑结果
	switch (lpCondition->m_bLogicOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_OR:
		bValid = (bResult1 || bResult2);
		break;
	default:
		bValid = (bResult1 && bResult2);
		break;
	}

	//最后计算一次非（NOT运算）
	if (lpCondition->m_bLogicNot)
	{
		bValid = !bValid;
	}
	return MF_OK;
}

int Check::CheckValid(LPRECORDDATAINFO lpRecordInfo, LPBASECONDITIONBSON lpCondition, BOOL& bValid)
{
	int nRet;
	BOOL bResult1, bResult2;
	LPCOMPAREEXPBSON lpCompareExp1, lpCompareExp2;
	LPBASECONDITIONBSON lpCondition1, lpCondition2;

	//根据条件判断记录是否合法
	if(lpCondition == NULL)
	{
		//判断可见性
		nRet = m_pMemoryFile->GetRecordBuffer(*m_pBson, lpRecordInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpRecordInfo->m_lpRecordBuffer == NULL)
		{
			bValid = FALSE;
		}
		else
		{
			bValid = TRUE;
		}
		return MF_OK;
	}

	bResult1 = FALSE;
	bResult2 = FALSE;
	//计算条件1的逻辑结果
	if(MF_CONDITION_INVALID == lpCondition->m_bConditionType1 || MF_CONDITION_ROWNUM == lpCondition->m_bConditionType1) 
	{
		bResult1 = TRUE;
		lpCondition->m_bLogicOperator = MF_EXECUTEPLAN_OPERATOR_AND;
	} 
	else if(MF_CONDITION_LOGIC == lpCondition->m_bConditionType1) 
	{
		lpCondition1 = (LPBASECONDITIONBSON) m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset1);
		nRet = CheckValid(lpRecordInfo, lpCondition1, bResult1);
		if (nRet != MF_OK) 
		{
			return nRet;
		}
	} 
	else 
	{
		//做比较运算
		lpCompareExp1 = (LPCOMPAREEXPBSON) m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset1);
		nRet = Compare(lpRecordInfo, lpCompareExp1, bResult1);
		if (nRet != MF_OK) 
		{
			return nRet;
		}
	}

	//计算条件2的逻辑结果
	if (MF_CONDITION_INVALID == lpCondition->m_bConditionType2 || MF_CONDITION_ROWNUM == lpCondition->m_bConditionType2) 
	{
		bResult2 = TRUE;
		lpCondition->m_bLogicOperator = MF_EXECUTEPLAN_OPERATOR_AND;
	}
	else if(MF_CONDITION_LOGIC == lpCondition->m_bConditionType2) 
	{
		lpCondition2 = (LPBASECONDITIONBSON) m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset2);
		nRet = CheckValid(lpRecordInfo, lpCondition2, bResult2);
		if (nRet != MF_OK) 
		{
			return nRet;
		}
	}
	else
	{
		//做比较运算
		lpCompareExp2 = (LPCOMPAREEXPBSON) m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset2);
		nRet = Compare(lpRecordInfo, lpCompareExp2, bResult2);
		if (nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算总的逻辑结果
	switch (lpCondition->m_bLogicOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_OR:
		bValid = (bResult1 || bResult2);
		break;
	default:
		bValid = (bResult1 && bResult2);
		break;
	}

	//最后计算一次非（NOT运算）
	if (lpCondition->m_bLogicNot)
	{
		bValid = !bValid;
	}
	return MF_OK;
}

int Check::CheckValid(LPSINGLERECORD lpDataArray, LPBASECONDITIONBSON lpCondition, BOOL& bValid)
{
	int nRet;
	BOOL bResult1, bResult2;
	LPCOMPAREEXPBSON lpCompareExp1, lpCompareExp2;
	LPBASECONDITIONBSON lpCondition1, lpCondition2;
	
	if(NULL == lpCondition)
	{
		bValid = TRUE;
		return MF_OK;
	}

	bResult1 = FALSE;
	bResult2 = FALSE;
	//计算条件1的逻辑结果
	if(MF_CONDITION_INVALID == lpCondition->m_bConditionType1 || MF_CONDITION_ROWNUM == lpCondition->m_bConditionType1)
	{
		bResult1 = TRUE;
	}
	else if(MF_CONDITION_LOGIC == lpCondition->m_bConditionType1)
	{
		lpCondition1 = (LPBASECONDITIONBSON)m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset1);
		nRet = CheckValid(lpDataArray, lpCondition1, bResult1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//做比较运算
		lpCompareExp1 = (LPCOMPAREEXPBSON)m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset1);
		nRet = Compare(lpDataArray, lpCompareExp1, bResult1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算条件2的逻辑结果
	if(MF_CONDITION_INVALID == lpCondition->m_bConditionType2 || MF_CONDITION_ROWNUM == lpCondition->m_bConditionType2)
	{
		bResult2 = TRUE;
	}
	else if(MF_CONDITION_LOGIC == lpCondition->m_bConditionType2)
	{
		lpCondition2 = (LPBASECONDITIONBSON)m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset2);
		nRet = CheckValid(lpDataArray, lpCondition2, bResult2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//做比较运算
		lpCompareExp2 = (LPCOMPAREEXPBSON)m_pBson->ConvertOffset2Addr(lpCondition->m_nConditionOffset2);
		nRet = Compare(lpDataArray, lpCompareExp2, bResult2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//计算总的逻辑结果
	switch(lpCondition->m_bLogicOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_OR:
		bValid = (bResult1 || bResult2);
		break;
	default:
		bValid = (bResult1 && bResult2);
		break;
	}

	//最后计算一次非（NOT运算）
	if(lpCondition->m_bLogicNot)
	{
		bValid = !bValid;
	}
	return MF_OK;
}

/************************************************************************
	 功能说明：
		判断记录是否合法
	 参数说明：
		nDataID：记录ID
 ************************************************************************/
BOOL Check::CheckRecordValid(long long nDataID) 
{
	int nRet;
	BOOL bValid;
	RECORDDATAINFO stRecordInfo;
	LPBASECONDITIONBSON lpCondition;
	
	stRecordInfo.m_nDataID			= nDataID;
	stRecordInfo.m_bDataPosition	= MF_DATAPOSITION_UNKNOWN;
	stRecordInfo.m_nTimestamp		= m_nTimestamp;
	stRecordInfo.m_lpTransactionArray = m_lpTransactionArray;

	bValid = FALSE;
	lpCondition = (LPBASECONDITIONBSON)m_pBson->ConvertOffset2Addr(m_nWhereOffset);
	nRet = CheckValid(&stRecordInfo, lpCondition, bValid);
	if (nRet != MF_OK) 
	{
		return FALSE;
	}
	return bValid;
}

BOOL Check::CheckRecordValid(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen)
{
	int nRet;
	BOOL bValid;
	LPBASECONDITIONBSON lpCondition;

	bValid = FALSE;
	lpCondition = (LPBASECONDITIONBSON) m_pBson->ConvertOffset2Addr(m_nWhereOffset);
	nRet = CheckValid(nDataID, lpRecordBuffer, nBufferLen, lpCondition, bValid);
	if (nRet != MF_OK)
	{
		return FALSE;
	}

	return bValid;
}

int CheckHBTreeIndex::CheckDownID(CServiceBson& stBson, long long nDataID,int nLevel, BOOL& bFind) 
{
	int nRet;
	VARDATA varData;
	LPRECURSION lpRecursion;
	CExpression stExpression;
	CMemoryHashFile* pHashFile;
	RECORDDATAINFO stRecordInfo;
	IVirtualMemoryFile* pVirtualFile;
	CTempDataID stTempDataID(&stBson);

	nRet = CSystemManage::instance().GetMemoryFileInstance(m_stIndexInfo.m_bFileNo, pVirtualFile);
	if (nRet != MF_OK)
	{
		return nRet;
	}
	pHashFile		= (CMemoryHashFile*) pVirtualFile;
	lpRecursion		= (LPRECURSION)stBson.ConvertOffset2Addr(m_lpQueryInfo->m_nConnOffset);

	nLevel++;
	if (lpRecursion->m_bLevel != 0 && nLevel > lpRecursion->m_bLevel) {
		bFind = FALSE;
		return MF_OK;
	}

	stExpression.Initial(&stBson, m_lpQueryInfo->m_lpObjectInfo);
	stRecordInfo.m_nTimestamp = m_lpQueryInfo->m_nTimestamp;
	stRecordInfo.m_lpTransactionArray = m_lpQueryInfo->m_lpTransactionArray;
	stRecordInfo.m_nDataID = nDataID;

	if (m_pStartDataID->find(nDataID)) {
		bFind = TRUE;
		return MF_OK;
	} else {
		//获取nDataID对应记录的PID字段值
		nRet = m_pMemoryFile->GetRecordBuffer(stBson, &stRecordInfo);
		if (nRet != MF_OK) {
			return nRet;
		}
		if (stRecordInfo.m_lpRecordBuffer == NULL) {
			return MF_FAILED;
		}
		nRet = stExpression.GetFieldValueFromRecordBuffer(
				stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, lpRecursion->m_bPIDFieldNo,
				varData);
		if (nRet != MF_OK) {
			return nRet;
		}
		if (varData.m_nValue == 0) {
			bFind = FALSE;
			return MF_OK;
		}
		//判断SuccessHash或FailedHash中是否存在DataID
		if(m_stSuccessHash.Check(nDataID)) 
		{
			bFind = TRUE;
			return MF_OK;
		} 
		else if(m_stFailedHash.Check(nDataID))
		{
			bFind = FALSE;
			return MF_OK;
		}

		//获取PID对应记录的DataID
		m_stIndexInfo.m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.SetData(
				varData);
		nRet = pHashFile->GetDataID(&m_stIndexInfo, &stTempDataID);
		if (nRet != MF_OK) {
			return nRet;
		}

		stTempDataID.MoveFirst();
		stTempDataID.NextDataID(nDataID);
		nRet = CheckDownID(stBson, nDataID, nLevel, bFind);
		if (nRet != MF_OK) {
			return nRet;
		}
		if(bFind) 
		{
			m_stSuccessHash.Set(nDataID);
		}
		else 
		{
			m_stFailedHash.Set(nDataID);
		}
	}
	return MF_OK;
}

/************************************************************************
 功能说明：
 初始化
 参数说明：
 pBson：Bson指针
 lpQueryInfo：查询信息
 pDataIDContainer：DataID容器
 ************************************************************************/
int CheckHBTreeIndex::Initial(CServiceBson* pBson, LPQUERYINFO lpQueryInfo,
		CDataIDContainer* pDataIDContainer) {
	int nRet;
	LPINDEXDEF lpIndex;
	LPRECURSION lpRecursion;

	m_lpObjectInfo = lpQueryInfo->m_lpObjectInfo;
	nRet = Check::Initial(pBson, lpQueryInfo);
	if (nRet != MF_OK) {
		return nRet;
	}

	if (lpQueryInfo->m_nConnOffset != 0) {
		//获取HB树索引
		for (lpIndex = m_lpObjectInfo->m_lpIndex; lpIndex != NULL; lpIndex
				= lpIndex->m_pNext) {
			if (lpIndex->m_bIndexType == MF_SYS_INDEXTYPE_HB_INT
					|| lpIndex->m_bIndexType == MF_SYS_INDEXTYPE_HB_CHAR) {
				break;
			}
		}

		m_stIndexInfo.m_pBson = pBson;
		m_stIndexInfo.m_bFileNo = lpIndex->m_bFileNo;
		m_stIndexInfo.m_bIndexType = lpIndex->m_bIndexType;
		m_stIndexInfo.m_nIndexID = lpIndex->m_nIndexID;

		m_stIndexInfo.m_bFieldNo[0] = lpIndex->m_bFieldNo[0];
		m_stIndexInfo.m_bFieldNo[1] = lpIndex->m_bFieldNo[1];
		m_stIndexInfo.m_bFieldNo[2] = lpIndex->m_bFieldNo[2];
		m_stIndexInfo.m_bFieldNo[3] = lpIndex->m_bFieldNo[3];

		//为向上递归创建Hash表
		m_pStartDataID	= pDataIDContainer;
		lpRecursion		= (LPRECURSION) pBson->ConvertOffset2Addr(lpQueryInfo->m_nConnOffset);
	}

	m_lpQueryInfo = lpQueryInfo;
	return MF_OK;
}

/************************************************************************
 功能说明：
 判断数据是否合法
 参数说明：
 nDataID：数据ID
 ************************************************************************/
BOOL CheckHBTreeIndex::CheckRecordValid(long long nDataID) 
{
	BOOL bValid;
	RECORDDATAINFO stRecordInfo;
	stRecordInfo.m_nDataID = nDataID;
	stRecordInfo.m_nTimestamp = m_nTimestamp;
	stRecordInfo.m_lpTransactionArray = m_lpTransactionArray;

	bValid = FALSE;
	if (m_lpQueryInfo->m_nConnOffset != 0) 
	{
		int nRet, nLevel;
		LPRECURSION lpRecursion;
		LPBASECONDITIONBSON lpRecursionCond;

		lpRecursion = (LPRECURSION) m_pBson->ConvertOffset2Addr(
				m_lpQueryInfo->m_nConnOffset);
		lpRecursionCond = (LPBASECONDITIONBSON) m_pBson->ConvertOffset2Addr(
				lpRecursion->m_nConnectCondOffset);
		//判断nDataID是否满足递归条件
		nRet = m_pMemoryFile->GetRecordBuffer(*m_pBson, &stRecordInfo);
		if (nRet != MF_OK) 
		{
			return nRet;
		}
		if (stRecordInfo.m_lpRecordBuffer == NULL) 
		{
			return FALSE;
		}
		nRet = CheckValid(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, lpRecursionCond,
				bValid);
		if (nRet != MF_OK) 
		{
			return nRet;
		}
		if (bValid == FALSE) 
		{
			return FALSE;
		}
		nLevel = 0;
		nRet = CheckDownID(*m_pBson, nDataID, nLevel, bValid);
		if (nRet != MF_OK) 
		{
			return nRet;
		}
		if (bValid)
		{
			m_stSuccessHash.Set(nDataID);
		} 
		else 
		{
			m_stFailedHash.Set(nDataID);
			return FALSE;
		}
	}

	return Check::CheckRecordValid(nDataID);
}
