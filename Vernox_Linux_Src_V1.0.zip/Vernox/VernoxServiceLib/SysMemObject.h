﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "BaseMemObject.h"

class CSysMemObject: public CBaseMemObject
{
private:
	
public:
	CSysMemObject(void);
	virtual ~CSysMemObject(void);
protected:
	int SysAlter(CServiceBson& stBson, LPEXECUTEPLANBSON lpExecutePlan, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int SysCreate(CServiceBson& stBson, LPEXECUTEPLANBSON lpExecutePlan, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int SysDrop(CServiceBson& stBson, LPEXECUTEPLANBSON lpExecutePlan, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
public:
	virtual int  Release();
	virtual int  GetRecordNum(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int& nRecordNum, LPEXECUTESTATISTICSINFO lpExecuteInfo);														
	virtual int  Preprocess(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual void CriticalRelease(CServiceBson& stBson);
	virtual int  ResourceRelease(CServiceBson& stuBisKon, int nRetValue, CExecutePlanManager& stExecutePlanManager);
	virtual int  ExecuteCommand(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual int  GetRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual int  UpdateRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual int	 ExportObject(CServiceBson& stBson, char* pObjectName, LPEXPORTPARAM lpExportParam, long long nTimestamp);
	virtual int	 ImportObject(CServiceBson& stBson, char* pObjectName, LPIMPORTPARAM lpImportParam, long long nTimestamp);
	
	USHORT GetDatabaseGuid();
public:
	virtual int  Recover(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
};
