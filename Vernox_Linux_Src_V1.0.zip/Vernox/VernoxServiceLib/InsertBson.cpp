﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "InsertBson.h"
#include "Expression.h"
CInsertBson::CInsertBson(CServiceBson* pBson)
{
	m_pBson				= pBson;
	m_lpBuffer			= NULL;
	m_nBufferSize		= 0;	
	m_nDataSize			= 0;
}

CInsertBson::~CInsertBson()
{
}


/************************************************************************
		功能说明：
			为记录分配空间
		参数说明：
			nBufferLen：分配空间长度
************************************************************************/
int CInsertBson::AllocRecordBuffer(UINT nBufferLen)
{
	int nRet;
	if(m_lpBuffer == NULL || nBufferLen > m_nBufferSize)
	{
		m_nBufferSize = (nBufferLen / 32 + 1) * 32;
		nRet = m_pBson->AllocFromTempBuffer(m_nBufferSize, m_lpBuffer);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	m_nDataSize = 0;
	return MF_OK;
}

/************************************************************************
		功能说明：
			从BSON缓存中分配空间
		参数说明：
			nLen：空间大小
			nOffset：偏移
			lpAddr：地址指针
************************************************************************/
int CInsertBson::AllocFromBsonBuffer(UINT nLen, UINT &nOffset, LPBYTE &lpAddr)
{
	int nNewDataLen, nOldDataLen;

	nNewDataLen = 0;						//分配后的数据长度
	nOldDataLen = 0;						//如果在分配的时候，发生因内存不足引起的Buffer重分配，
											//那么原始插入位置的指针(pInsertAddr)也就会发生变化，所以要记录插入位置的偏移，以便重新计算插入位置
	if(m_lpBuffer == NULL)
	{
		return MF_INNER_ALLOCMEM_FAILED;	
	}
	if(lpAddr == NULL)
	{
		nNewDataLen = m_nDataSize;		//在现有数据局末尾插入新数据
		nOldDataLen = nNewDataLen;
		if(nNewDataLen+nLen > m_nBufferSize)
		{	
			return MF_INNER_ALLOCMEM_FAILED;
		}
	}
	else
	{
		nNewDataLen = (int)(lpAddr - m_lpBuffer);	//在现有数据中间某处插入数据
		nOldDataLen = nNewDataLen;
		if(nNewDataLen+nLen > m_nBufferSize)
		{	
			return MF_INNER_ALLOCMEM_FAILED;
		}
	}

	nNewDataLen += nLen;
	if((UINT)nNewDataLen > m_nDataSize)
	{
		m_nDataSize = nNewDataLen;
	}
	nOffset = nOldDataLen;
	lpAddr  = m_lpBuffer + nOldDataLen;
	memset(lpAddr, 0, nLen);
	return MF_OK;
}

/************************************************************************
		功能说明：
			将字段值写入指定位置
		参数说明：
			pInsertAddr：指定的位置
			bFieldType：字段类型
			bFieldNo：字段编号
			varData：字段值
************************************************************************/
int CInsertBson::WriteFieldData(MF_SYS_FIELDTYPE bFieldType, BYTE bFieldNo, VARDATA &varData, LPBYTE lpAddr)
{
	UINT nOffset;
	int nRet, nLen;
	switch(bFieldType)
	{
	case MF_SYS_FIELDTYPE_NULL:
		break;
	case MF_SYS_FIELDTYPE_INT:
		nLen = sizeof(BYTE) + sizeof(int);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((int*)lpAddr) = varData.GetCompatibleInt();
		break;
	case MF_SYS_FIELDTYPE_BIGINT:
		nLen = sizeof(BYTE) + sizeof(long long);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((long long*)lpAddr) = varData.GetCompatibleBigInt();
		break;
	case MF_SYS_FIELDTYPE_DATE:
	case MF_SYS_FIELDTYPE_DOUBLE:
		nLen = sizeof(BYTE) + sizeof(double);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((double*)lpAddr) = varData.GetCompatibleDouble();
		break;
	case MF_SYS_FIELDTYPE_CHAR:
	case MF_SYS_FIELDTYPE_VARCHAR:
	case MF_SYS_FIELDTYPE_CLOB:
	case MF_SYS_FIELDTYPE_BLOB:
		if(varData.m_nStrLen < 250)
		{
			nLen = sizeof(BYTE) + sizeof(BYTE) + varData.m_nStrLen;
			nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			*((BYTE*)lpAddr) = bFieldNo;
			lpAddr += sizeof(BYTE);
			*((BYTE*)lpAddr) = varData.m_nStrLen;
			lpAddr += sizeof(BYTE);
			memcpy(lpAddr, varData.m_lpszValue, varData.m_nStrLen);
		}
		else
		{
			nLen = sizeof(BYTE) + sizeof(BYTE) + sizeof(int) + varData.m_nStrLen;
			nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			*((BYTE*)lpAddr) = bFieldNo;
			lpAddr += sizeof(BYTE);
			*((BYTE*)lpAddr) = 255;
			lpAddr += sizeof(BYTE);
			*(int*)lpAddr = varData.m_nStrLen;
			lpAddr += sizeof(int);
			memcpy(lpAddr, varData.m_lpszValue, varData.m_nStrLen);
		}
		break;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			插入字符串类型数据
		参数说明：
			pData：字符串数据
			nLen：字符串长度
************************************************************************/
BOOL CInsertBson::AppendBuffer(void* pData, int nLen)
{
	int nOldLen;
	if(m_nDataSize + nLen <= m_nBufferSize)
	{
		nOldLen = m_nDataSize;				
		m_nDataSize += nLen;				

		memcpy(m_lpBuffer + nOldLen, pData, nLen);							
		return TRUE;
	}
	return FALSE;
}

/************************************************************************
		功能说明：
			计算Bson长度
		参数说明：
			lpObjectInfo：对象信息
			lpDataArray：字段值数组
			bRecordTpye：记录类型
		返回值说明：
			返回Bson长度，-1表示计算失败
************************************************************************/
int CInsertBson::GetBsonLen(LPOBJECTDEF lpObjectInfo, LPVARDATA lpDataArray, MF_RECORD_TYPE bRecordTpye)
{
	BYTE bRecordSectionNum;
	int nRet, i, nLen, nBufferLen;

	nBufferLen = 0;
	//1.计算记录片段数量
	if(0 == lpObjectInfo->m_nFieldNum % MF_RECORDSECTION_FIELDNUM)
	{
		bRecordSectionNum = lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM; 
	}
	else
	{
		bRecordSectionNum = lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM + 1; 
	}

	//2.计算记录实际长度所需要的空间
	for(i = 0; i < lpObjectInfo->m_nFieldNum; i++)
	{
		if(lpDataArray[i].m_vt == MF_VARDATA_UNKNOWN || lpDataArray[i].m_vt == MF_VARDATA_NULL)
		{
			continue;
		}
		nLen = 0;
		nRet = GetFieldBufferLen(nLen, lpObjectInfo->m_lpField[i].m_bFieldType, lpDataArray[i].m_nStrLen);
		if(nRet != MF_OK)
		{
			return -1;
		}
		nBufferLen += nLen;
	}	

	//3.如果记录包含HB树索引则需要分配空间存放孩子结点和兄弟结点的DataID
	if(bRecordTpye == MF_RECORD_HBTREE)
	{
		nBufferLen += 2*sizeof(long long);
	}
	else if(bRecordTpye == MF_RECORD_NODE)
	{
		nBufferLen += sizeof(NODEHEAD);		
	}
	else if(bRecordTpye == MF_RECORD_RELATION)
	{
		nBufferLen += sizeof(RELATIONHEAD);		
	}

	//4.计算记录片段映射表所需要的空间
	nLen = 2*sizeof(BYTE) + bRecordSectionNum * sizeof(BYTE);
	if(nBufferLen + nLen < 250)
	{	
		nBufferLen += nLen;
	}
	else 
	{
		nLen = 2*sizeof(BYTE) + bRecordSectionNum * sizeof(USHORT);
		if(nBufferLen + nLen < 65530)
		{
			nBufferLen += nLen;
		}
		else
		{
			nLen = 2*sizeof(BYTE) + bRecordSectionNum * sizeof(int);
			nBufferLen += nLen;
		}
	}
	return nBufferLen;
}

//重载函数用于UpdateRecordset
int CInsertBson::GetBsonLen(LPOBJECTDEF lpObjectInfo, LPXMLFIELDBSON* lpFieldBsonMap, MF_RECORD_TYPE bRecordTpye)
{
	BYTE bRecordSectionNum;
	int i, nBufferLen, nLen;

	nBufferLen = 0;
	//1.计算记录片段数量
	if(0 == lpObjectInfo->m_nFieldNum % MF_RECORDSECTION_FIELDNUM)
	{
		bRecordSectionNum = lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM; 
	}
	else
	{
		bRecordSectionNum = lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM + 1; 
	}
	
	//2.计算记录实际长度所需要的空间
	for(i = 0; i < lpObjectInfo->m_nFieldNum; i++)
	{
		if(lpFieldBsonMap[i] != NULL)
		{
			nBufferLen += lpFieldBsonMap[i]->m_nFieldDataLen;
		}
	}

	//3.如果记录包含HB树索引则需要分配空间存放孩子结点和兄弟结点的DataID
	if(bRecordTpye == MF_RECORD_HBTREE)
	{
		nBufferLen += 2*sizeof(long long);
	}
	else if(bRecordTpye == MF_RECORD_NODE)
	{
		nBufferLen += sizeof(NODEHEAD);		
	}
	else if(bRecordTpye == MF_RECORD_RELATION)
	{
		nBufferLen += sizeof(RELATIONHEAD);		
	}

	//4.计算记录片段映射表所需要的空间
	nLen = 2*sizeof(BYTE) + bRecordSectionNum * sizeof(BYTE);
	if(nBufferLen + nLen < 250)
	{	
		nBufferLen += nLen;
	}
	else 
	{
		nLen = 2*sizeof(BYTE) + bRecordSectionNum * sizeof(USHORT);
		if(nBufferLen + nLen < 65530)
		{
			nBufferLen += nLen;
		}
		else
		{
			nLen = 2*sizeof(BYTE) + bRecordSectionNum * sizeof(int);
			nBufferLen += nLen;
		}
	}
	return nBufferLen;
}

/************************************************************************
	功能说明：
		创建记录Bson
	参数说明：
		lpParam：公共参数
		lpObjectInfo：对象信息
		lpFieldBsonMap：字段映射表
		lpDataArray：字段值
		stRecordHead：记录信息头
************************************************************************/
int CInsertBson::BuildBson(LPBASESTEPPARAM lpParam, LPOBJECTDEF lpObjectInfo, LPEXECUTEFIELDBSON* lpFieldBsonMap, LPVARDATA lpDataArray, RECORDHEAD& stRecordHead)
{
	int nRet, i;
	void* arrFieldOffset;
	BYTE bFieldNo, bRecordSectionNum, bSectionArrayType;

	//1.分配空间存放记录			
	nRet = AllocRecordBuffer(stRecordHead.m_nRecordLen);
	if(nRet != MF_OK)
	{
		return MF_OK;
	}
	lpParam->m_lpRecordBuffer = (long long)m_lpBuffer;

	//2.计算记录片段数量
	if(0 == lpObjectInfo->m_nFieldNum % MF_RECORDSECTION_FIELDNUM)
	{
		bRecordSectionNum = lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM; 
	}
	else
	{
		bRecordSectionNum = lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM + 1; 
	}

	//3.创建记录片段映射表
	*(BYTE*)(m_lpBuffer + m_nDataSize) = bRecordSectionNum;
	m_nDataSize	    += sizeof(BYTE);
	if(stRecordHead.m_nRecordLen < 250)
	{
		bSectionArrayType   = MF_RECORDSECTIONARRAY_BYTE;
		*(BYTE*)(m_lpBuffer + m_nDataSize) = bSectionArrayType;
		m_nDataSize			+= sizeof(BYTE);
		arrFieldOffset		= m_lpBuffer + m_nDataSize;
		m_nDataSize			+= bRecordSectionNum * sizeof(BYTE);
	}
	else if(stRecordHead.m_nRecordLen < 65530)
	{
		bSectionArrayType   = MF_RECORDSECTIONARRAY_SHORT;
		*(BYTE*)(m_lpBuffer + m_nDataSize) = bSectionArrayType;
		m_nDataSize			+= sizeof(BYTE);
		arrFieldOffset		= m_lpBuffer + m_nDataSize;
		m_nDataSize			+= bRecordSectionNum * sizeof(USHORT);
	}
	else
	{
		bSectionArrayType   = MF_RECORDSECTIONARRAY_INT;
		*(BYTE*)(m_lpBuffer + m_nDataSize) = bSectionArrayType;
		m_nDataSize			+= sizeof(BYTE);
		arrFieldOffset		= m_lpBuffer + m_nDataSize;
		m_nDataSize			+= bRecordSectionNum * sizeof(int);
	}

	if(lpParam->m_bRecordType == MF_RECORD_HBTREE)
	{
		memset(m_lpBuffer + m_nDataSize, 0, sizeof(2*sizeof(long long)));
		m_nDataSize += 2*sizeof(long long);
	}
	else if(lpParam->m_bRecordType == MF_RECORD_NODE)
	{
		memset(m_lpBuffer + m_nDataSize, 0, sizeof(NODEHEAD));
		m_nDataSize += sizeof(NODEHEAD);
	}
	else if(lpParam->m_bRecordType == MF_RECORD_RELATION)
	{
		memset(m_lpBuffer + m_nDataSize, 0, sizeof(RELATIONHEAD));
		m_nDataSize += sizeof(RELATIONHEAD);
	}

	//4.对字段值进行序列化
	for(i = 0; i < lpObjectInfo->m_nFieldNum; i++)
	{
		if(0 == i % MF_RECORDSECTION_FIELDNUM)
		{
			if(bSectionArrayType == MF_RECORDSECTIONARRAY_BYTE)
			{
				((BYTE*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else if(bSectionArrayType == MF_RECORDSECTIONARRAY_SHORT)
			{
				((USHORT*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else if(bSectionArrayType == MF_RECORDSECTIONARRAY_INT)
			{
				((int*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else
			{
				return MF_FAILED;
			}
		}

		if(lpFieldBsonMap[i] == NULL || lpDataArray[i].m_vt == MF_SYS_FIELDTYPE_NULL)
		{
			continue;
		}

		bFieldNo = lpFieldBsonMap[i]->m_bFieldNo;
		nRet = WriteFieldData(lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType, bFieldNo, lpDataArray[bFieldNo - 1]);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	m_nBufferSize = 0;
	return MF_OK;
}

//重载函数用于UpdateRecordset
int CInsertBson::BuildBson(LPBASESTEPPARAM lpParam, LPOBJECTDEF lpObjectInfo, LPXMLFIELDBSON* lpFieldBsonMap, RECORDHEAD& stRecordHead)
{
	int nRet, i;
	LPBYTE lpData;
	void* arrFieldOffset;
	BYTE bRecordSectionNum, bSectionArrayType;

	//1.分配空间存放记录
	nRet = AllocRecordBuffer(stRecordHead.m_nRecordLen);
	if(nRet != MF_OK)
	{
		return MF_OK;
	}
	lpParam->m_lpRecordBuffer = (long long)m_lpBuffer;

	//2.计算记录片段数量
	if(0 == lpObjectInfo->m_nFieldNum % MF_RECORDSECTION_FIELDNUM)
	{
		bRecordSectionNum = lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM; 
	}
	else
	{
		bRecordSectionNum = lpObjectInfo->m_nFieldNum / MF_RECORDSECTION_FIELDNUM + 1; 
	}

	//3.创建记录片段映射表
	*(BYTE*)(m_lpBuffer + m_nDataSize) = bRecordSectionNum;
	m_nDataSize	    += sizeof(BYTE);
	if(stRecordHead.m_nRecordLen < 250)
	{
		bSectionArrayType   = MF_RECORDSECTIONARRAY_BYTE;
		*(BYTE*)(m_lpBuffer + m_nDataSize) = bSectionArrayType;
		m_nDataSize	    += sizeof(BYTE);
		arrFieldOffset		= m_lpBuffer + m_nDataSize;
		m_nDataSize	    += bRecordSectionNum * sizeof(BYTE);
	}
	else if(stRecordHead.m_nRecordLen < 65530)
	{
		bSectionArrayType   = MF_RECORDSECTIONARRAY_SHORT;
		*(BYTE*)(m_lpBuffer + m_nDataSize) = bSectionArrayType;
		m_nDataSize	    += sizeof(BYTE);
		arrFieldOffset		= m_lpBuffer + m_nDataSize;
		m_nDataSize	    += bRecordSectionNum * sizeof(USHORT);
	}
	else
	{
		bSectionArrayType   = MF_RECORDSECTIONARRAY_INT;
		*(BYTE*)(m_lpBuffer + m_nDataSize) = bSectionArrayType;
		m_nDataSize	    += sizeof(BYTE);
		arrFieldOffset		= m_lpBuffer + m_nDataSize;
		m_nDataSize	    += bRecordSectionNum * sizeof(int);
	}

	if(lpParam->m_bRecordType == MF_RECORD_HBTREE)
	{
		memset(m_lpBuffer + m_nDataSize, 0, sizeof(2*sizeof(long long)));
		m_nDataSize += 2*sizeof(long long);
	}
	else if(lpParam->m_bRecordType == MF_RECORD_NODE)
	{
		memset(m_lpBuffer + m_nDataSize, 0, sizeof(NODEHEAD));
		m_nDataSize += sizeof(NODEHEAD);
	}
	else if(lpParam->m_bRecordType == MF_RECORD_RELATION)
	{
		memset(m_lpBuffer + m_nDataSize, 0, sizeof(RELATIONHEAD));
		m_nDataSize += sizeof(RELATIONHEAD);
	}

	//4.将数据序列化到Buffer中
	for(i = 0; i < lpObjectInfo->m_nFieldNum; i++)
	{
		if(0 == i % MF_RECORDSECTION_FIELDNUM)
		{
			if(bSectionArrayType == MF_RECORDSECTIONARRAY_BYTE)
			{
				((BYTE*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else if(bSectionArrayType == MF_RECORDSECTIONARRAY_SHORT)
			{
				((USHORT*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else if(bSectionArrayType == MF_RECORDSECTIONARRAY_INT)
			{
				((int*)arrFieldOffset)[i / 4] = m_nDataSize;
			}
			else
			{
				return MF_FAILED;
			}
		}

		if(lpFieldBsonMap[i] != NULL)
		{
			lpData = m_pBson->ConvertOffset2Addr(lpFieldBsonMap[i]->m_nFieldDataOffset);
			if(!AppendBuffer(lpData, lpFieldBsonMap[i]->m_nFieldDataLen))
			{
				return MF_FAILED;
			}
		}
	}

	m_nBufferSize = 0;
	return MF_OK;
}