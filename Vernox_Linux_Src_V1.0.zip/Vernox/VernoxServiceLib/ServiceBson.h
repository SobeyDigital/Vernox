﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "stdafx.h"
#include "../VernoxBaseLib/BaseBson.h"
#define MAX_TEMP_SECTION    128
class CServiceBson:public CBaseBson
{
public:
	CServiceBson(void);
	~CServiceBson(void);
protected:
	LPBYTE			    m_lpTempBuffer;						//临时缓存指针
	UINT			    m_nTempBufferSize;					//临时缓存大小
	UINT				m_nTempDataSize;					//临时缓存中的数据量
	UINT				m_nTotalDataSize;					//数据总大小
	UINT				m_nTotalBufferSize;					//缓存总大小

	LPBYTE				m_lpCircleBuffer;					//循环Buffer
	UINT				m_nCircleBufferSize;			    //循环Buffer的大小
	UINT				m_nCircleDataSize;				    //循环Buffer中的数据量
		
	LPBYTE				m_lpRecrodBuffer;					//记录缓存
	UINT				m_nRecordBufferSize;			    //记录缓存大小

	USHORT				m_nTempSectionNum;					//临时缓存片段数组
	LPBYTE				m_arrTempSection[MAX_TEMP_SECTION];	//临时缓存数组

	LPOBJECTDEF			m_lpObjectInfo;						//对象信息
	
	BOOL				m_bReleaseBuffer;					//是否释放各类缓存，防止备份Bson对象意外释放缓存

	friend class CExecutePlanManager;
	friend class CExecuteDataID;
protected:
	//分配缓存片段
	int AllocBufferSection();	

	//释放内存
	virtual void Free();
public:
	//初始化缓存
	int Initial(LPBYTE lpBuffer, UINT nTotalBufferSize, BOOL bAutoRelease = FALSE);
	int Initial(LPBYTE lpBuffer, UINT nTotalBufferSize, UINT nTempBufferSize, UINT nCircleBufferSize, UINT nRecordBufferSize);

	//分配临时缓存片段
	int AllocTempSection(int& nSize, LPBYTE& lpBuffer);

	//分配空间，用于运算时的空间开销（四则运算、函数运算等），客户端做四则运算的空间是从BsonBuffer中分配，服务端是从循环Buffer中分配
	virtual int AllocBuffer(UINT nLen, LPBYTE &lpAddr)
	{
		return AllocFromCircleBuffer(nLen, lpAddr);
	}

	//从临时缓存中分配空间
	template<class T>
	int AllocFromTempBuffer(T* &pBuffer, UINT& nOffset);
	int AllocFromTempBuffer(UINT nLen, LPBYTE &lpBuffer, UINT& nOffset);
	int AllocFromTempBuffer(UINT nLen, LPBYTE &lpBuffer);

	//从循环Buffer中分配空间
	template<class T>
	int AllocFromCircleBuffer(T* &pBuffer);
	int AllocFromCircleBuffer(UINT nLen, LPBYTE &lpBuffer);

	//从记录缓存中分配空间
	int AllocFromRecordBuffer(UINT nLen, LPBYTE &lpBuffer);

	//从临时缓存中获取指针
	LPBYTE GetPtrFromTempBuffer(UINT nOffset);

	//将nOffset转换为地址指针
	inline LPBYTE ConvertOffset2Addr(UINT nOffset)
	{
		if((int)nOffset == 0 || (int)nOffset == -1)
		{
			return NULL;
		}
		else
		{
			return (LPBYTE)m_lpBuffer + nOffset;
		}
	}

	//将nAddrID转换为地址指针
	int ConvertAddrID2Addr(UINT nAddrID, LPBYTE& lpAddr);

	//获取片段地址
	void GetSectionBufferAddr(int nSectionNo, LPBYTE& lpAddr);

	//获取片段中实际数据的起始地址指针（出去片段头）
	void GetSectionDataAddr(int nSectionNo, LPBYTE& lpAddr);

	//备份BsonBuffer
	int BackupBsonBuffer(CServiceBson& stBson);

	//清理
	void ClearBsonBuffer();

	//获取空闲空间地址ID
	inline UINT GetFreeMemoryAddrID()
	{
		if(m_nCircleDataSize == 1 && m_nCurrentDataSize == 0)
		{
			return 0;
		}
		else
		{
			return MakeAddrID(m_nCurrentSectionNo, m_nCurrentDataSize);
		}
	}

	//设置对象信息
	inline void SetObjectInfo(LPOBJECTDEF lpObjectInfo)
	{
		m_lpObjectInfo = lpObjectInfo;
	}

	//获取对象信息
	inline LPOBJECTDEF GetObjectInfo()
	{
		return m_lpObjectInfo;
	}

	//锁定BsonBuffer的大小
	inline void LockBsonBufferSize()
	{
		m_nBsonBufferSize	= m_nBsonDataSize;
		m_nTotalDataSize	= m_nBsonDataSize;
	}

	//获取片段起始偏移
	inline UINT GetSectionStartOffset()
	{
		return m_nSectionStartOffset;
	}

	//获取空闲缓存大小
	inline UINT GetFreeBufferSize()
	{
		return m_nFreeBufferSize;
	}

	//获取临时缓存片段大小
	inline UINT GetTempSectionNum()
	{
		return m_nTempSectionNum;
	}

	//获取临时缓存片段
	inline LPBYTE GetTempSectionBuffer(UINT nSectionNo)
	{
		if(nSectionNo > MAX_TEMP_SECTION)
		{
			return NULL;
		}
		else
		{
			return m_arrTempSection[nSectionNo];
		}
	}

	//获取临时空间
	inline LPBYTE GetTempBuffer()
	{
		return m_lpTempBuffer;
	}

	//获取临时空间大小
	inline UINT GetTempBufferSize()
	{
		return m_nTempBufferSize;
	}
};

/************************************************************************
	功能说明：
		从临时缓存中分配空间
	参数说明：
		pBuffer：需要分配的数据缓存
		nOffset：偏移
************************************************************************/
template<class T>
int CServiceBson::AllocFromTempBuffer(T* &pBuffer, UINT& nOffset)
{
	UINT nLen;
	nLen = sizeof(T);
	if(m_nTempDataSize + nLen > m_nTempBufferSize)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}

	nOffset = m_nTempDataSize;
	m_nTempDataSize  += nLen;
	pBuffer = (T*)(m_lpTempBuffer + nOffset);
	memset(pBuffer, 0, nLen);
	return MF_OK;
}

/************************************************************************
	功能说明：
		从循环缓存中分配空间
	参数说明：
		pBuffer：需要分配的数据缓存
************************************************************************/
template<class T>
int CServiceBson::AllocFromCircleBuffer(T* &pBuffer)
{
	USHORT nOffset;
	UINT nLen, nSize;

	nLen  = sizeof(T);
	nSize = nLen;
	if(nSize > m_nCircleBufferSize)
	{
		//释放原来的循环Buffer
		if(m_lpCircleBuffer < m_lpBuffer || m_lpCircleBuffer >= m_lpBuffer + m_nTotalBufferSize)
		{
			CSystemManage::instance().FreeTemporaryMem(m_lpCircleBuffer);
		}

		//分配新的循环Buffer
		nSize = (nSize /2048 + 1)*2048;		//按照2K的整数倍进行分配
		m_lpCircleBuffer = CSystemManage::instance().AllocTemporaryMem(nSize);
		if(m_lpCircleBuffer == NULL)
		{
			return MF_INNER_ALLOCMEM_FAILED;
		}
		m_nCircleDataSize		= 0;
		m_nCircleBufferSize		= nSize;
	}

	if(m_nCircleDataSize + nLen > m_nCircleBufferSize)
	{
		m_nCircleDataSize = 0;
	}

	nOffset = m_nCircleDataSize;
	m_nCircleDataSize  += nLen;
	pBuffer = (T*)(m_lpCircleBuffer + nOffset);
	memset(pBuffer, 0, nLen);
	return MF_OK;
}
