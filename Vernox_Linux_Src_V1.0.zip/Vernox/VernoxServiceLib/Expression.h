﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "../VernoxBaseLib/BaseExpression.h"

//表达式处理类
class CMemoryRowDataBuffer;
class CMemoryRowDataBufferSet;
class CServiceBson;
class CMemoryFile;
class CExpression
{
public:
	CExpression();
	~CExpression();
private:
	CServiceBson* m_pBson;
	CMemoryFile*  m_pFile;
	LPOBJECTDEF   m_lpObjectInfo;
private:
	//获取数据值
	int GetDataValue(CBaseBson& stBson, LPMATHEXPELEMENTBSON lpFieldBson, VARDATA& stVarData);
	//计算表达式中某字段的值
	int GetFieldValue(LPMATHEXPELEMENTBSON lpFieldBson, VARDATA& varResult, LPSINGLERECORD pDataArray);
public:	
	//初始化
	void Initial(CServiceBson* pBson, LPOBJECTDEF lpObjectInfo);
	//从记录Buffer中获取字段值
	int GetFieldValueFromRecordBuffer(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen, BYTE bFieldNo, VARDATA& varResult);
	//获取表达式元素值
	int GetExpElementValue(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen, LPMATHEXPELEMENTBSON lpMathElement, VARDATA& varResult);
	int GetExpElementValue(LPRECORDDATAINFO lpRecordInfo, LPMATHEXPELEMENTBSON lpMathElement, VARDATA& varResult);

	//计算表达式的值(用于处理聚合函数)
	int GetExpressionResult(CDataIDContainer* pDataIDContainer, LPMATHEXPBSON lpMathExp, VARDATA& varResult);
	//计算表达式的值(用于处理与字段值无关的表达式)
	int GetExpressionResult(LPMATHEXPBSON lpMathExp, VARDATA& varResult);
	//计算表达式的值(用于处理与字段值相关的表达式)
	int GetExpressionResult(long long nDataID, LPBYTE lpRecordBuffer, int nBufferLen, LPMATHEXPBSON lpMathExp, VARDATA& varResult);
	int GetExpressionResult(LPRECORDDATAINFO lpRecordInfo, LPMATHEXPBSON lpMathExp, VARDATA& varResult);

	//计算表达式值(处理系统查询表达式)
	int GetExpressionResult(LPSINGLERECORD lpDataArray, LPMATHEXPBSON lpMathExp, VARDATA& varResult);
	//计算表达式的值(用于处理系统查询的聚合函数)
	int GetExpressionResult(CSysRecordContainer* pRecordContainer, LPMATHEXPBSON lpMathExp, VARDATA& varResult);
};