﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include <vector>
using namespace std;
  
//内存对象虚类定义
class IVirtualMemObject
{
public:
	//函数名：析构函数
	//参  数：无
	//返回值：无
	virtual ~IVirtualMemObject() {};

	//函数名：释放资源
	//参  数：无
	//返回值：执行结果
	virtual int Release()																																					= 0;
	
	//获取记录数
	virtual int  GetRecordNum(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int& nRecordNum,  LPEXECUTESTATISTICSINFO lpExecuteInfo)					    = 0;

	//预处理
	virtual int  Preprocess(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)											= 0;

	//函数名：执行命令
	//参  数：lpExecutePlan为执行计划，lAffectCount为执行影响行数，包括报错信息
	//返回值：执行结果
	virtual int ExecuteCommand(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)					= 0;

	//函数名：执行命令
	//描  述：lpExecutePlan为执行计划，ppRs为执行结果集
	//参  数：无
	//返回值：执行结果
	virtual int GetRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo)	= 0;

	//函数名：更新结果集
	//参  数：bstrRs为修改的结果集
	//返回值：执行结果
	virtual	int UpdateRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)										= 0;

	//函数名：导出数据
	virtual int	ExportObject(CServiceBson& stBson, char* pObjectName, LPEXPORTPARAM lpExportParam,long long nTimestamp)														= 0;
	
	//函数名：导入数据
	virtual int	ImportObject(CServiceBson& stBson, char* pObjectName, LPIMPORTPARAM lpImportParam, long long nTimestamp)													= 0;
	
	//函数名：资源释放
	virtual int  ResourceRelease(CServiceBson& stBson, int nRetValue, CExecutePlanManager& stExecutePlanManager)														    = 0;

	//函数名：数据恢复
	virtual int  Recover(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)							= 0;

	//函数名：释放临界区
	virtual void CriticalRelease(CServiceBson& stBson)																														= 0;
};

class CBaseMemObject : public IVirtualMemObject
{
public:
	CBaseMemObject(void);
	virtual ~CBaseMemObject(void);

public:
	virtual int  Release()																																						= 0;
	virtual int  GetRecordNum(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int& nRecordNum,  LPEXECUTESTATISTICSINFO lpExecuteInfo)						    = 0;
	virtual int  Preprocess(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)												= 0;
	virtual void CriticalRelease(CServiceBson& stBson)																															= 0;
	virtual int  ResourceRelease(CServiceBson& stBson, int nRetValue, CExecutePlanManager& stExecutePlanManager)																= 0;
	virtual int  ExecuteCommand(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)						= 0;
	virtual int  GetRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo)		= 0;
	virtual	int  UpdateRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo)										= 0;
	virtual int	 ExportObject(CServiceBson& stBson, char* pObjectName, LPEXPORTPARAM lpExportParam, long long nTimestamp)														= 0;
	virtual int	 ImportObject(CServiceBson& stBson, char* pObjectName, LPIMPORTPARAM lpImportParam, long long nTimestamp)	 													= 0;
public:
	virtual int  Recover(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo)								= 0;
};

