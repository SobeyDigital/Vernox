﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryBTreeIndex.h"
#include "Check.h"

CMemoryBTreeIndex::CMemoryBTreeIndex(void)
{
}


CMemoryBTreeIndex::~CMemoryBTreeIndex(void)
{
}


/************************************************************************
		功能说明：
			释放内存块(清空),并把块号添加到空块队列中
		参数说明：
			lpExecutePlan：执行计划
			nBlockNo：内存块编号
		特别说明:
			该函数调用文件级的FreeBlock()进行回收
************************************************************************/
void CMemoryBTreeIndex::FreeBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo)
{
	LPTREENODEHEAD lpNodeHead, lpPreNodeHead, lpNextNodeHead;

	//将结点从链表中删除
	lpNodeHead		= (LPTREENODEHEAD)ConvertBlockNotoAddr(nBlockNo);
	lpPreNodeHead	= (LPTREENODEHEAD)ConvertBlockNotoAddr(lpNodeHead->m_nPreNodeNo);
	lpNextNodeHead	= (LPTREENODEHEAD)ConvertBlockNotoAddr(lpNodeHead->m_nNextNodeNo);
	if(lpPreNodeHead != NULL)			
	{
		lpPreNodeHead->m_nNextNodeNo = lpNodeHead->m_nNextNodeNo;
	}
	
	if(lpNextNodeHead != NULL)			
	{
		lpNextNodeHead->m_nPreNodeNo = lpNodeHead->m_nPreNodeNo;
	}
	//回收内存块
	m_pIndexFile->FreeBlock(lpExecutePlan, nBlockNo);	
}


/************************************************************************
		功能说明:
			将数据从一个位置移动到另外一个位置
		参数说明:
			pSrcAddr:源地址
			pDestAddr:目标地址
			nLen:移动内存长度
		特别说明:
			实现数据的拷贝移动，这里不作任何有效性判断，但需要考虑如果pSrcAddr > pDestAddr时，我们认为数据的移动为从前向后移动，否则为从后向前移动，以免数据被覆盖。
			其中两个地址之差为每次内存移动的步长，如果超过nLen则直接使用Memcpy。对于较短情况，暂时考虑成4字节赋值方式解决，以后如果速度有问题在考虑使用汇编实现。

			注意这里pSrcAddr和pDestAddr都是实际地址，MoveIndexData会用在两个地方：
			1.执行结点分裂时，将数据从一个块拷贝到另一个块中，这里是跨块的数据移动，可以直接调用memcpy函数
			2.执行块内整理的时候，将数据前移或者后移，这里是在块内进行的数据移动，则调用memmove函数
			具体是跨块移动数据还是块内移动，通过pSrcAddr、pDestAddr的差值与nLen比较就可以判断
************************************************************************/
void CMemoryBTreeIndex::MoveIndexData(LPBYTE pSrcAddr, LPBYTE pDestAddr, int nLen)
{
	int nAddrDistance;

	nAddrDistance = abs((int)(pSrcAddr - pDestAddr));			//获得源地址和目的地址之前的距离
	//比较nAddrDistance与nLen以判断是否是跨块移动数据
	if(nAddrDistance >= nLen)
	{
		//跨快移动调用memcpy
		memcpy(pDestAddr,pSrcAddr,nLen);
		memset(pSrcAddr,0,nLen);								//清空原块中被拷贝部分的数据
	}
	else
	{
		//块内移动，调用memmove
		memmove(pDestAddr,pSrcAddr,nLen);
	}
}

/************************************************************************
		功能说明:
			检查数据索引块是否满
		参数说明：
			lpNodeData:索引节点数据
		特别说明:
			在插入数据时调用，如果满了应该调SplitIndexData函数进行拆分
************************************************************************/
BOOL CMemoryBTreeIndex::CheckNodeFull(LPBYTE lpNodeData)
{
	int nTotalDataNum, nDataNum;
	
	nTotalDataNum = ((LPTREENODEHEAD)lpNodeData)->m_nTotalDataNum;			//获得结点中可以存放的索引项总条数
	nDataNum	  = ((LPTREENODEHEAD)lpNodeData)->m_nDataNum;				//获得结点中现有的索引项条数
	return nDataNum >= nTotalDataNum;
}

/************************************************************************
		功能说明:
			将一块索引数据分裂成两块索引数据
		参数说明：
			lpExecutePlan：执行计划
			bIndexType：索引类型
			lpNodeData：索引节点数据
			bLast：插入位置是否为最后一个节点的最后一个元素
			nNewNodeNo：分裂出的新结点编号
			nTimestamp：时间戳
		特别说明:
			将一个索引节点分裂成两个索引节点，主要用于插入数据时，节点的数据已经满了没办法处理时，需要把数据平均分开到两个块中。
			1、调m_pIndexFIle的AllocBlock函数分配一个新的块B(并返回这个块的位置指针)
			2、调Memcpy函数把A块的后50%复制到块B的开头位置
			3、构建块B的块头信息，并尝试把块B挂接到块A的上级块上
				3.1、如果上级块未满就直接挂接
				3.2、如果上级块已满时，就再次调m_pIndexFIle的AllocBlock函数分配一个新的块C
				3.3、把块A的剩下部分使用Memcpy函数复制到块C
				3.4、构建块C的块信息
				3.5、锁定索引访问（块信息数据变化会导致访问无效）
				3.6、把块A的上级索引分一半给块A，并且把块A的块信息更新为树干节点
				3.7、完成块B和块C在树干节点信息更新挂接
				3.8、解除索引块的访问锁

		关于字符串型索引块的分裂问题：
		在说明此问题之前，先说明字符串型索引项的插入与整型索引项插入的区别
		整型索引是将数据项直接插入内存块，但字符串型索引需要将索引项分为定长部分和变长部分
		定长部分存放key的偏移量，变长部分存放key值，索引项定长数据部分的存放顺序，是按照其变长部分也就是key值的大小顺序有序存放。
		但是其变长数据本身是不进行排序的(是按照索引插入的先后顺序存放)，综上所述字符串型索引的结构是定长部分有序，变长部分无序的存放方式。
		所以在索引块分裂之后必然会引起原变长数据部分出现内存碎片，所以需要提供整理机
************************************************************************/
int CMemoryBTreeIndex::SplitIndexData(LPEXECUTEPLANBSON lpExecutePlan, MF_SYS_INDEXTYPE bIndexType, LPBYTE lpNode, BOOL bLast, int& nNewNodeNo, long long nTimestamp)
{
	long long nBlockMapOffset;
	int nRet, nReservedNum, nMoveNum;
	LPBYTE lpMid, lpPreMid, lpNewNode;
	LPTREENODEHEAD lpNodeHead, lpNewNodeHead;
	//得到索引结点的中间位置(中间位置之后的数据需要进行移动)
	//索引结点中间位置的计算方式：
	//1.由于结点已满所以用m_nTotalDataNum / 2就可以得到半个结点索引条数
	//2.将半个结点的索引条数*索引项的大小，就可以得到中间位置相对于结点头的偏移
	//3.将结点头指针 + 这个偏移就可以得到最终的结果

	lpNodeHead	 = (LPTREENODEHEAD)lpNode;
	if(bLast && bIndexType != MF_SYS_INDEXTYPE_TREE_MULTISTR && bIndexType != MF_SYS_INDEXTYPE_FUZZY_CHAR)
	{
		//最后一个节点的最后一个元素按照9：1分裂(优化自增主键的插入)
		nReservedNum = lpNodeHead->m_nTotalDataNum * 0.9;
		nMoveNum	 = lpNodeHead->m_nTotalDataNum - nReservedNum;
	}
	else
	{
		nReservedNum = lpNodeHead->m_nTotalDataNum / 2;
		nMoveNum	 = lpNodeHead->m_nTotalDataNum - nReservedNum;
	}
	lpMid = lpNode + lpNodeHead->m_nBlockHeadSize + nReservedNum * lpNodeHead->m_nDataSize;

	//中间数据项的前一个数据项指针（即分裂后原结点的最后一个数据项，由此计算分裂后原结点能够存放数据项的最大关键字值）
	lpPreMid = lpMid - lpNodeHead->m_nDataSize;										

	//调用文件级的Alloc函数分配一个新的块
	nRet = m_pIndexFile->AllocBlock(lpExecutePlan, nNewNodeNo, nBlockMapOffset, lpNodeHead->m_nBlockSize, nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	lpNewNode = ConvertBlockNotoAddr(nNewNodeNo);
	lpNewNodeHead = (LPTREENODEHEAD)lpNewNode;
	InitialBlock(lpNewNode, lpNodeHead->m_nDataSize, lpNodeHead->m_nBlockHeadSize, lpNodeHead->m_bNodeType);
	
	//将原结点中50%的数据拷贝到新结点中
	//注意：1.准确的说，是将原结点中，后一半的数据移动到新的结点，
	//		  那么移动之后后，原结点中余留的最后一条数据，其Key值就会成为原块的最大Key值，
	//		  而新块中的最大Key就是分裂前原块的最大Key		
	//		2.同理，分裂后原块的NextNodeNo应该是新块的块号，而新块的NextNodeNo是分裂前原块的NextNodeNo
	//				分裂后新块的PreNodeNo应该是原块的块号，而原块后一个块的PreNodeNo应该是新块的块号
	MoveIndexData(lpMid, lpNewNode + lpNodeHead->m_nBlockHeadSize, nMoveNum * lpNodeHead->m_nDataSize);
	
	//修改源结点头和新结点头的部分数据
	lpNewNodeHead->m_nDataNum = nMoveNum;

	SetKeyValue(GetMaxKeyPtr(lpNewNode), GetMaxKeyPtr(lpNode), TRUE);
	lpNodeHead->m_nDataNum	  = nReservedNum;
	SetKeyValue(GetMaxKeyPtr(lpNode), GetKeyPtr(lpPreMid, lpNodeHead->m_bNodeType), TRUE);
	
	//在双向链表中插入结点
	if(lpNodeHead->m_nNextNodeNo != 0)
	{
		((LPTREENODEHEAD)ConvertBlockNotoAddr(lpNodeHead->m_nNextNodeNo))->m_nPreNodeNo = nNewNodeNo;
	}

	lpNewNodeHead->m_nNextNodeNo	= lpNodeHead->m_nNextNodeNo;
	lpNodeHead->m_nNextNodeNo		= nNewNodeNo;
	lpNewNodeHead->m_nPreNodeNo		= lpNodeHead->m_nBlockNo;

	return MF_OK;
}

/************************************************************************
		功能说明:
			合并两块索引块
		参数说明：
			lpExecutePlan：执行计划
			lpSrcNode：源节点
			lpDestNode：目标节点
			nTimestamp：时间戳
************************************************************************/
void CMemoryBTreeIndex::MergeNode(LPEXECUTEPLANBSON lpExecutePlan, LPBYTE lpSrcNode, LPBYTE lpDestNode, long long nTimestamp)
{
	LPBYTE lpSrcPos, lpMergePos;
	LPTREENODEHEAD lpSrcHead, lpDestHead;

	lpDestHead = (LPTREENODEHEAD)lpDestNode;

	//将源节点中的数据拷贝到目标节点中
	lpSrcHead  = (LPTREENODEHEAD)lpSrcNode;
	lpSrcPos   = lpSrcNode + lpSrcHead->m_nBlockHeadSize;
	lpMergePos = lpDestNode + lpDestHead->m_nBlockHeadSize + lpDestHead->m_nDataNum*lpDestHead->m_nDataSize;
	memcpy(lpMergePos, lpSrcPos, lpSrcHead->m_nDataNum*lpSrcHead->m_nDataSize);

	lpDestHead->m_nDataNum += lpSrcHead->m_nDataNum;

	//修改目标节点的最大关键字值
	SetKeyValue(GetMaxKeyPtr(lpDestNode), GetMaxKeyPtr(lpSrcNode), FALSE);

	//释放源节点
	FreeBlock(lpExecutePlan, lpSrcHead->m_nBlockNo);

	//修改目标块时间戳
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)lpDestNode, nTimestamp);
}

/************************************************************************
	功能说明：
		比较值的大小
	参数说明：
		varData1：数据1
		varData2：数据2
		bMatch：是否部分匹配
************************************************************************/
int CMemoryBTreeIndex::Compare(VARDATA& varData1, VARDATA& varData2, BOOL bMatch)
{
	if(varData1.m_vt == MF_VARDATA_MAX)
	{
		return 1;
	}
	else if(varData2.m_vt == MF_VARDATA_MAX)
	{
		return -1;
	}
	if(varData1.m_vt != MF_VARDATA_STRING)
	{
		if(varData1 > varData2)
		{
			return 1;
		}
		else if(varData1 < varData2)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return CSystemManage::instance().CharCompare(varData1.m_lpszValue, varData1.m_nStrLen, varData2.m_lpszValue, varData2.m_nStrLen, bMatch);
	}
}

/************************************************************************
		功能说明：
			判断是否到达结点的末尾
		参数说明：
			lpNode：结点指针
			pCurrentPos：当前位置
		特别说明：
			该函数在SearchData中使用
************************************************************************/
BOOL CMemoryBTreeIndex::IsEnd(LPBYTE lpNode, LPBYTE lpCurrentPos)
{
	LPBYTE lpLastPos;
	LPTREENODEHEAD lpNodeHead;

	lpNodeHead = (LPTREENODEHEAD)lpNode;
	//得到块尾的地址
	lpLastPos = lpNode + lpNodeHead->m_nBlockHeadSize + lpNodeHead->m_nDataSize * lpNodeHead->m_nDataNum;
	return (lpLastPos <= lpCurrentPos);
}

/************************************************************************
		功能说明：
			判断是否为节点开始
		参数说明：
			lpNode：结点指针
			pCurrentPos：当前位置
************************************************************************/
BOOL CMemoryBTreeIndex::IsFirst(LPBYTE lpNode, LPBYTE lpCurrentPos)
{
	LPBYTE lpFirstPos;
	LPTREENODEHEAD lpNodeHead;

	lpNodeHead = (LPTREENODEHEAD)lpNode;
	//得到块头
	lpFirstPos = lpNode + lpNodeHead->m_nBlockHeadSize;
	return (lpFirstPos == lpCurrentPos);
}

/************************************************************************
		功能说明：
			实现折半查找，需要精确查找给定的Key，实现被查询的
		参数说明：
			lpMultiIndex：复合索引
			lpSearchInfo：查询信息
		返回值说明：
			如果找到数据则返回TRUE，否则返回FALSE
		特别说明：
			该函数与传统二分法相比有几个区别：
			1.支持复合索引，即存在多个关键字的情况
			2.当待查询关键字Key1与结点中的关键字KEY相等时，需要找到与Key1相
			  等的所有关键字的开始位置或结束位置(根据bFirst参数决定)
************************************************************************/
BOOL CMemoryBTreeIndex::BinarySearch(LPMULTIINDEX lpMultiIndex, LPBINARYSEARCHINFO lpSearchInfo)
{
	LPVOID lpKeyPtr;
	BOOL bFind, bFindKey;
	BYTE bFirst, bOperator;
	LPTREENODEHEAD lpNodeHead;
	LPBYTE lpNodeBody, lpData;	
	int i,nMid, nLow, nHigh, n;
	LPINDEXCONDITION lpIndexField;

	//对于>=、<这三种情况，如果存在相同关键字，则需要找到相同关键字的起始位置
	//对于>、<=这两种情况，需要找到第一个与关键字不相同的位置
	//对于=、LIKE情况，这里需要优化，即找到相同关键字的起始位置和结束位置
	//所以下面首先需要判断是哪一种情况，判断规则是根据复合索引中第一个不是等号的运算符符来判断
	bOperator = lpMultiIndex->m_lpIndexCondition[0].m_bOperator;
	for(i = 0; i < (int)lpMultiIndex->m_nIndexNum; i++)
	{
		lpIndexField = &lpMultiIndex->m_lpIndexCondition[i];
		if(lpIndexField->m_bOperator != MF_EXECUTEPLAN_OPERATOR_EQUAL)
		{
			bOperator = lpIndexField->m_bOperator;
			lpSearchInfo->m_nLevel = i;
			break;
		}
	}

	lpNodeHead = (LPTREENODEHEAD)lpSearchInfo->m_lpNodeLow;					
	if(lpSearchInfo->m_bOperatorType == OPERATOR_INSERT || lpSearchInfo->m_bOperatorType == OPERATOR_DELETE)
	{
		bFirst = FIRST_EQUAL;
	}
	else
	{
		if(bOperator == MF_EXECUTEPLAN_OPERATOR_GREATER	|| bOperator == MF_EXECUTEPLAN_OPERATOR_LESSEQUAL || bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENB || bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENBE)
		{
			bFirst = FIRST_NOTEQUAL;				//第一个不相同关键字
		}
		else if(bOperator == MF_EXECUTEPLAN_OPERATOR_EQUAL || bOperator == MF_EXECUTEPLAN_OPERATOR_LIKE)
		{
			if(lpNodeHead->m_bNodeType == LEAVENODE)
			{
				bFirst = FIRST_AND_LAST_EQUAL;	   //相同关键字起始位置和结束位置
			}
			else
			{
				bFirst = FIRST_EQUAL;				//第一个相同关键字
			}
		}
		else
		{
			bFirst = FIRST_EQUAL;					//第一个相同关键字
		}
	}


	//2.开始二分法
	//注意获得数据项首地址指针的方式：lpNodeBody + nMid * nIndexSize
	lpNodeBody = lpSearchInfo->m_lpNodeLow + lpNodeHead->m_nBlockHeadSize;		

	nLow	   = lpSearchInfo->m_nLow;
	nHigh      = lpSearchInfo->m_nHigh;

	bFindKey   = FALSE;
	bFind      = FALSE;
	while(nLow <= nHigh)
	{
		nMid   = (nLow + nHigh) / 2;
		lpData = lpNodeBody + nMid * lpNodeHead->m_nDataSize;	

		lpKeyPtr = GetKeyPtr(lpData, lpNodeHead->m_bNodeType);
		n = Compare(lpMultiIndex, lpKeyPtr, lpSearchInfo->m_bOperatorType, bFindKey); 
		if(n < 0)
		{
			nHigh = nMid - 1;	
		}
		else if(n > 0)
		{
			nLow = nMid + 1;
		}
		else
		{
			bFind = TRUE;
			if(bFirst == FIRST_EQUAL)
			{
				if(nLow == nMid)
				{
					lpSearchInfo->m_nDataPosLow = nMid;
					break;
				}
				else
				{
					lpSearchInfo->m_nLow   = nLow;
					lpSearchInfo->m_nHigh  = nMid;
					lpSearchInfo->m_bFirst = TRUE;  

					//在nLow和nMid之前获取相同关键字起始位置
					BinarySearch2(lpMultiIndex, lpSearchInfo);
					break;
				}
			}
			else if(bFirst == FIRST_AND_LAST_EQUAL)
			{
				//优化LIKE查询，找到后缀的开始和结束
				long long nSearchScope;
				int nRangeLow, nRangeHigh;
				LPBYTE lpNodeLow, lpNodeHigh;
				BINARYSEARCHINFO stSearchInfo;
				memset(&stSearchInfo, 0, sizeof(BINARYSEARCHINFO));

				stSearchInfo.m_bOperatorType	=  lpSearchInfo->m_bOperatorType;
				//找到相同关键字的起始位置
				if(nLow == nMid)
				{
					nRangeLow					=  nMid;
					lpNodeLow					=  lpSearchInfo->m_lpNodeLow;
				}
				else
				{
					stSearchInfo.m_lpNodeLow	=  lpSearchInfo->m_lpNodeLow;
					stSearchInfo.m_bFirst		=  TRUE;
					stSearchInfo.m_nLow			=  nLow;
					stSearchInfo.m_nHigh		=  nMid;
					stSearchInfo.m_nSearchScope =  0;
					stSearchInfo.m_bOverBlock	=  FALSE;

					//在nLow和nMid之前获取关键字起始位置
					BinarySearch2(lpMultiIndex, &stSearchInfo);
					nRangeLow = stSearchInfo.m_nDataPosLow;
					lpNodeLow = stSearchInfo.m_lpNodeLow;
				}

				//找到相同关键字的结束位置
				if(nMid == nHigh)
				{
					if(nMid < lpNodeHead->m_nDataNum - 1)
					{
						//结束位置在当前块
						nRangeHigh				 =  nMid + 1;
						lpNodeHigh			     =  lpSearchInfo->m_lpNodeLow;
					}
					else
					{
						//结束位置在下一个块的起始(无需判断为空情况,因为为空表示最后一个元素）
						lpNodeHigh = ConvertBlockNotoAddr(lpNodeHead->m_nNextNodeNo);
						if(lpNodeHigh != NULL)
						{
							stSearchInfo.m_lpNodeLow	=  lpNodeHigh;
							stSearchInfo.m_bFirst		=  FALSE;
							stSearchInfo.m_nLow			=  0;
							stSearchInfo.m_nHigh		=  ((LPTREENODEHEAD)lpNodeHigh)->m_nDataNum - 1;
							stSearchInfo.m_nSearchScope =  0;
							stSearchInfo.m_bOverBlock	=  TRUE;
							//在nMid和nHigh之前获取关键字结束位置(可能跨块)
							BinarySearch2(lpMultiIndex, &stSearchInfo);
							nRangeHigh = stSearchInfo.m_nDataPosLow;
							lpNodeHigh = stSearchInfo.m_lpNodeLow;
						}
						else
						{
							nRangeHigh			= 0;
						}
					}
				}
				else
				{
					stSearchInfo.m_lpNodeLow	=  lpSearchInfo->m_lpNodeLow;
					stSearchInfo.m_bFirst		=  FALSE;
					stSearchInfo.m_nLow			=  nMid;
					stSearchInfo.m_nHigh		=  nHigh;
					stSearchInfo.m_nSearchScope =  0;
					stSearchInfo.m_bOverBlock	=  FALSE;
					//在nMid和nHigh之前获取关键字结束位置(可能跨块)
					BinarySearch2(lpMultiIndex, &stSearchInfo);
					nRangeHigh = stSearchInfo.m_nDataPosLow;
					lpNodeHigh = stSearchInfo.m_lpNodeLow;
				}
				lpSearchInfo->m_nDataPosLow		= nRangeLow;
				lpSearchInfo->m_nDataPosHigh	= nRangeHigh;

				lpSearchInfo->m_lpNodeLow		= lpNodeLow;
				lpSearchInfo->m_lpNodeHigh		= lpNodeHigh;
				if(stSearchInfo.m_bOverBlock)
				{
					//跨块
					nSearchScope = stSearchInfo.m_nSearchScope;
					nSearchScope += ((LPTREENODEHEAD)lpSearchInfo->m_lpNodeLow)->m_nDataNum - lpSearchInfo->m_nDataPosLow;
					nSearchScope += lpSearchInfo->m_nDataPosHigh;
					
					lpNodeLow = ConvertBlockNotoAddr(((LPTREENODEHEAD)lpNodeLow)->m_nNextNodeNo);
					while(lpNodeLow != lpNodeHigh)
					{
						nSearchScope += ((LPTREENODEHEAD)lpNodeLow)->m_nDataNum;
						lpNodeLow = ConvertBlockNotoAddr(((LPTREENODEHEAD)lpNodeLow)->m_nNextNodeNo);
					}
				}
				else
				{
					nSearchScope = lpSearchInfo->m_nDataPosHigh - lpSearchInfo->m_nDataPosLow;
				}
				lpSearchInfo->m_nSearchScope   = nSearchScope;
				break;
			}
			else
			{
				if(nHigh == nMid)
				{
					lpSearchInfo->m_nDataPosLow = nMid + 1;
					break;
				}
				else
				{
					lpSearchInfo->m_nLow	    = nMid;
					lpSearchInfo->m_nHigh       = nHigh;
					lpSearchInfo->m_bFirst      = FALSE;  
					lpSearchInfo->m_bOverBlock	= FALSE;
					lpSearchInfo->m_nSearchScope= 0;

					//在nMid和nMid之前获取关键字结束位置(可能跨块)
					BinarySearch2(lpMultiIndex, lpSearchInfo);
					break;
				}
			}
		}
	}
	if(!bFind)
	{
		lpSearchInfo->m_nDataPosLow = nLow;
	}
	if(lpSearchInfo->m_bOperatorType == OPERATOR_INSERT)
	{
		return bFindKey;
	}
	else
	{
		return bFind;
	}
}

//用于获取相同关键字的起始位置或结束位置
void CMemoryBTreeIndex::BinarySearch2(LPMULTIINDEX lpMultiIndex, LPBINARYSEARCHINFO lpSearchInfo)
{
	BOOL bFindKey;
	int nMid, nLow, nHigh, n;
	LPTREENODEHEAD	lpNodeHead;
	LPVOID lpKeyPtr, lpMaxKeyPtr;
	LPBYTE lpNodeBody, lpNextNode, lpData;					

	lpNodeHead = (LPTREENODEHEAD)lpSearchInfo->m_lpNodeLow;						
	lpNodeBody = lpSearchInfo->m_lpNodeLow + lpNodeHead->m_nBlockHeadSize;		

	nLow  = lpSearchInfo->m_nLow;													
	nHigh = lpSearchInfo->m_nHigh;		

	//开始折半查找
	//注意获得数据项首地址指针的方式：lpNodeBody + nMid * nIndexSize
	bFindKey = FALSE;
	while(nLow <= nHigh)
	{
		nMid   = (nLow + nHigh) / 2;
		lpData = lpNodeBody + nMid * lpNodeHead->m_nDataSize;

		lpKeyPtr = GetKeyPtr(lpData, lpNodeHead->m_bNodeType);
		n = Compare(lpMultiIndex, lpKeyPtr, lpSearchInfo->m_bOperatorType, bFindKey); 
		if(n < 0)
		{
			nHigh = nMid - 1;	
		}
		else if(n > 0)
		{
			nLow  = nMid + 1;
		}
		else
		{
			if(lpSearchInfo->m_bFirst)
			{
				//如果bFirst为真，则找到相同关键字的起始位置
				lpSearchInfo->m_nDataPosLow = nMid;
				nMid--;
				if(nMid < 0)
				{
					return;
				}
				lpData = lpNodeBody + nMid * lpNodeHead->m_nDataSize;
				lpKeyPtr = GetKeyPtr(lpData, lpNodeHead->m_bNodeType);	
				n = Compare(lpMultiIndex, lpKeyPtr, lpSearchInfo->m_bOperatorType, bFindKey); 
				if(n != 0)
				{
					return;
				}
				else
				{
					lpSearchInfo->m_nLow  = nLow;
					lpSearchInfo->m_nHigh = nMid;
					return BinarySearch2(lpMultiIndex, lpSearchInfo);
				}
			}
			else
			{
				//如果bFirst为假,则找到相同关键字的结束位置
				if(nMid == lpNodeHead->m_nDataNum - 1 && lpNodeHead->m_nNextNodeNo != 0)
				{
					//跨块情况
					while(TRUE)
					{
						lpNextNode = ConvertBlockNotoAddr(lpNodeHead->m_nNextNodeNo);
						if(lpNextNode == NULL)
						{
							return;
						}
						lpSearchInfo->m_bOverBlock = TRUE;
						lpSearchInfo->m_lpNodeLow  = lpNextNode;
						lpNodeHead  = (LPTREENODEHEAD)lpNextNode;

						lpMaxKeyPtr = GetMaxKeyPtr(lpNextNode);		
						n = Compare(lpMultiIndex, lpMaxKeyPtr, lpSearchInfo->m_bOperatorType, bFindKey); 
						if(n !=0)
						{
							break;
						}
						else
						{
							//注意：这里主要用于存储第一个相同关键字所在的块，与最后一个相同关键字所在块之间间隔的数据（不包括第一个块和最后一个块的数据）
							//所以不能将这条语句放在“lpNextNode = ConvertBlockNotoAddr(lpNodeHead->m_nNextNodeNo);”之前，因为这会使结果包含第一个块的数据
							//也不能将这条语句放在Compare之间，因为这会让结果包含最后一个块的数据
							lpSearchInfo->m_nSearchScope += lpNodeHead->m_nDataNum;
						}
					}

					//如果下一个结点的第一个元素值不等于当前Key，则直接返回
					lpData   = lpSearchInfo->m_lpNodeLow + lpNodeHead->m_nBlockHeadSize;
					lpKeyPtr = GetKeyPtr(lpData, lpNodeHead->m_bNodeType);
					n = Compare(lpMultiIndex, lpKeyPtr, lpSearchInfo->m_bOperatorType, bFindKey); 
					if(n !=0)
					{
						lpSearchInfo->m_nDataPosLow = 0;
						return;
					}
					else
					{
						//如果下一个结点的第一个元素值等于nKey，则对下一个结点进行二分法查找
						lpSearchInfo->m_nLow  = 0;
						lpSearchInfo->m_nHigh = lpNodeHead->m_nDataNum - 1;
						return BinarySearch2(lpMultiIndex, lpSearchInfo);
					}
				}
				else
				{
					nMid++;
					if(nMid > nHigh)
					{
						lpSearchInfo->m_nDataPosLow = nMid;
						return;
					}
					lpData = lpNodeBody + nMid * lpNodeHead->m_nDataSize;
					lpKeyPtr = GetKeyPtr(lpData, lpNodeHead->m_bNodeType);
					n = Compare(lpMultiIndex, lpKeyPtr, lpSearchInfo->m_bOperatorType, bFindKey); 
					if(n != 0)
					{
						lpSearchInfo->m_nDataPosLow = nMid;
						return;
					}
					else
					{
						lpSearchInfo->m_nLow  = nMid;
						lpSearchInfo->m_nHigh = nHigh;
						return BinarySearch2(lpMultiIndex, lpSearchInfo);
					}	
				}
			}
		}
	}

	//如果没有查找到则返回nLow的位置
	//注意nLow这个位置是大于nKey的最小的关键字的位置，可以用这个位置直接进行插入操作
	lpSearchInfo->m_nDataPosLow = nLow;
}

/************************************************************************
		功能说明：
			遍历大树干结点，找到关键字对应的树干结点
		参数说明：
			lpMultiIndex：复合索引
			lpSearchInfo：查询信息
			lpTreeNodeInfo：树结点信息
************************************************************************/
int CMemoryBTreeIndex::BigTrunkSearch(LPEXECUTEPLANBSON lpExecutePlan, LPMULTIINDEX lpMultiIndex, LPBINARYSEARCHINFO lpSearchInfo, LPTREENODEINFO lpTreeNodeInfo)
{
	int n;
	BOOL bFindKey;
	LPVOID	lpMaxKeyPtr;
	LPTREENODEHEAD lpBigTrunkHead;
	while(TRUE)						
	{
		lpBigTrunkHead = (LPTREENODEHEAD)lpTreeNodeInfo->m_lpBigTrunkNode;
		lpMaxKeyPtr = GetMaxKeyPtr(lpTreeNodeInfo->m_lpBigTrunkNode);
		n = Compare(lpMultiIndex, lpMaxKeyPtr, lpSearchInfo->m_bOperatorType, bFindKey);
		if(n <= 0)
		{
			break;
		}
		else if(0 == lpBigTrunkHead->m_nNextNodeNo)
		{
			lpTreeNodeInfo->m_lpBigTrunkNode = NULL;
			break;
		}
		else
		{
			lpTreeNodeInfo->m_lpBigTrunkNode = ConvertBlockNotoAddr(lpBigTrunkHead->m_nNextNodeNo);
			if(NULL == lpTreeNodeInfo->m_lpBigTrunkNode)
			{
				//将结点号转换为结点指针错误		
				return MF_BTREEINDEX_INVALIDNODENO_ERROR;	
			}
		}
	}
	if(NULL == lpTreeNodeInfo->m_lpBigTrunkNode )
	{
		return MF_BTREEINDEX_TREESEARCH_NULLPOINTER_ERROR;				//没有找到nKey所在的大树干结点，发生错误
	}
	
	lpBigTrunkHead = (LPTREENODEHEAD)lpTreeNodeInfo->m_lpBigTrunkNode;
	
	//用二分法在大树干结点中，找到关键字对应的树干结点位置
	lpSearchInfo->m_lpNodeLow	= lpTreeNodeInfo->m_lpBigTrunkNode;
	lpSearchInfo->m_nLow		= 0;
	lpSearchInfo->m_nHigh		= lpBigTrunkHead->m_nDataNum - 1;
	lpSearchInfo->m_nLevel		= 0;
	lpSearchInfo->m_nDataPosLow	= 0;
	BinarySearch(lpMultiIndex, lpSearchInfo);
	
	//大树干结构体指针，指向记录关键字所在树干结点
	if(lpSearchInfo->m_nDataPosLow >= lpBigTrunkHead->m_nDataNum)
	{
		lpSearchInfo->m_nDataPosLow = lpBigTrunkHead->m_nDataNum - 1;
	}
	lpTreeNodeInfo->m_lpBigTrunkElement = lpTreeNodeInfo->m_lpBigTrunkNode + lpBigTrunkHead->m_nBlockHeadSize + lpSearchInfo->m_nDataPosLow * lpBigTrunkHead->m_nDataSize; 
	
	return MF_OK;
}

/************************************************************************
		功能说明：
			遍历树干结点，找到关键字对应的叶子结点
		参数说明：
			lpMultiIndex：复合索引
			lpSearchInfo：查询信息
			lpTreeNodeInfo：树结点信息
************************************************************************/
int CMemoryBTreeIndex::TrunkSearch(LPMULTIINDEX lpMultiIndex, LPBINARYSEARCHINFO lpSearchInfo, LPTREENODEINFO lpTreeNodeInfo)
{
	LPTREENODEHEAD lpTrunkHead;							

	lpTrunkHead = (LPTREENODEHEAD)lpTreeNodeInfo->m_lpTrunkNode;
	
	//用二分法在树干结点中，找到关键字对应的叶子结点位置
	lpSearchInfo->m_lpNodeLow	= lpTreeNodeInfo->m_lpTrunkNode;
	lpSearchInfo->m_nLow		= 0;
	lpSearchInfo->m_nHigh		= lpTrunkHead->m_nDataNum - 1;
	lpSearchInfo->m_nLevel		= 0;
	lpSearchInfo->m_nDataPosLow	= 0;
	BinarySearch(lpMultiIndex, lpSearchInfo);

	//树干结构体指针，指向记录关键字所在叶子结点
	if(lpSearchInfo->m_nDataPosLow >= lpTrunkHead->m_nDataNum)
	{
		lpSearchInfo->m_nDataPosLow = lpTrunkHead->m_nDataNum - 1;
	}
	lpTreeNodeInfo->m_lpTrunkElement = lpTreeNodeInfo->m_lpTrunkNode + lpTrunkHead->m_nBlockHeadSize + lpSearchInfo->m_nDataPosLow * lpTrunkHead->m_nDataSize; 

	return MF_OK;
}

/************************************************************************
		功能说明：
			遍历叶子结点，找到关键字对应的DataID
		参数说明：
			lpMultiIndex：复合索引
			lpSearchInfo：查询信息
			lpTreeNodeInfo：树结点信息
************************************************************************/
int CMemoryBTreeIndex::LeaveNodeSearch(LPMULTIINDEX lpMultiIndex, LPBINARYSEARCHINFO lpSearchInfo, LPTREENODEINFO lpTreeNodeInfo)
{
	BOOL bFind, bFindKey;
	LPTREENODEHEAD lpLeaveHead;		

	lpLeaveHead = (LPTREENODEHEAD)lpTreeNodeInfo->m_lpLeaveNode;
	
	//用二分法在叶子结点中，找到关键字对应的索引项位置
	lpSearchInfo->m_lpNodeLow	= lpTreeNodeInfo->m_lpLeaveNode;
	lpSearchInfo->m_nLow		= 0;
	lpSearchInfo->m_nHigh		= lpLeaveHead->m_nDataNum - 1;
	lpSearchInfo->m_nLevel		= 0;
	lpSearchInfo->m_nDataPosLow	= 0;

	bFind = BinarySearch(lpMultiIndex, lpSearchInfo);

	if(lpSearchInfo->m_bOperatorType == OPERATOR_SEARCH)
	{
		//查询操作
		if(lpSearchInfo->m_nDataPosLow > lpLeaveHead->m_nDataNum - 1)
		{
			return MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH; 
		}
		else
		{
			if(!bFind && (lpMultiIndex->m_lpIndexCondition[lpSearchInfo->m_nLevel].m_bOperator == MF_EXECUTEPLAN_OPERATOR_EQUAL || !bFind && lpMultiIndex->m_lpIndexCondition[lpSearchInfo->m_nLevel].m_bOperator == MF_EXECUTEPLAN_OPERATOR_LIKE))
			{
				lpTreeNodeInfo->m_lpLeaveStartElement	= NULL;
				lpTreeNodeInfo->m_lpLeaveEndElement		= NULL;
			}
			else
			{
				lpTreeNodeInfo->m_lpLeaveStartElement	= lpSearchInfo->m_lpNodeLow + lpLeaveHead->m_nBlockHeadSize + lpSearchInfo->m_nDataPosLow * lpLeaveHead->m_nDataSize; 
				if(lpSearchInfo->m_lpNodeHigh != NULL)
				{
					lpTreeNodeInfo->m_lpLeaveEndElement = lpSearchInfo->m_lpNodeHigh + lpLeaveHead->m_nBlockHeadSize + lpSearchInfo->m_nDataPosHigh * lpLeaveHead->m_nDataSize;
				}
			}
		}
	}
	else if(lpSearchInfo->m_bOperatorType == OPERATOR_INSERT)
	{
		//插入操作
		if(lpSearchInfo->m_nDataPosLow > lpLeaveHead->m_nDataNum - 1)
		{
			LPBYTE lpNode;
			LPVOID lpMaxKeyPtr;
			lpNode = lpSearchInfo->m_lpNodeLow;
			lpMaxKeyPtr = GetMaxKeyPtr(lpNode);
			if(Compare(lpMultiIndex, lpMaxKeyPtr, OPERATOR_INSERT, bFindKey) > 0)
			{
				//插入关键字的值大于节点的最大值
				return MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH;
			}
		}
		
		if(bFind)
		{
			lpSearchInfo->m_nDatID = GetDataIDFromLeavePtr(lpSearchInfo->m_lpNodeLow + lpLeaveHead->m_nBlockHeadSize + (lpSearchInfo->m_nDataPosLow - 1) * lpLeaveHead->m_nDataSize);
		}
		//叶子结构体指针，指向记录关键字所在索引项
		lpTreeNodeInfo->m_lpLeaveStartElement   = lpSearchInfo->m_lpNodeLow + lpLeaveHead->m_nBlockHeadSize + lpSearchInfo->m_nDataPosLow * lpLeaveHead->m_nDataSize; 
		if(lpSearchInfo->m_lpNodeHigh != NULL)
		{
			lpTreeNodeInfo->m_lpLeaveEndElement = lpSearchInfo->m_lpNodeHigh + lpLeaveHead->m_nBlockHeadSize + lpSearchInfo->m_nDataPosHigh * lpLeaveHead->m_nDataSize;
		}

		if(!bFind)
		{
			//插入时返回NOKEYEQUAL表示没有找到关键字，主要用于唯一索引的关键字排重
			return MF_BTREEINDEX_BINARYSEARCH_NOKEYEQUAL;
		}
	}
	else
	{
		//删除操作
		if(bFind)
		{
			lpTreeNodeInfo->m_lpLeaveStartElement = lpSearchInfo->m_lpNodeLow + lpLeaveHead->m_nBlockHeadSize + lpSearchInfo->m_nDataPosLow * lpLeaveHead->m_nDataSize; 
			if(lpSearchInfo->m_lpNodeHigh != NULL)
			{
				lpTreeNodeInfo->m_lpLeaveEndElement = lpSearchInfo->m_lpNodeHigh + lpLeaveHead->m_nBlockHeadSize + lpSearchInfo->m_nDataPosHigh * lpLeaveHead->m_nDataSize;
			}
		}
		else
		{
			//删除操作一定能找到关键字
			return MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH;
		}

	}
	return MF_OK;
}
	
/************************************************************************
		功能说明：
			遍历树
		参数说明：
			lpExecutePlan：执行计划
			lpMultiIndex：复合索引
			lpSearchInfo：查询信息
			lpTreeNodeInfo：树结点信息
************************************************************************/
int CMemoryBTreeIndex::TreeSearch(LPEXECUTEPLANBSON lpExecutePlan, LPMULTIINDEX lpMultiIndex, LPBINARYSEARCHINFO lpSearchInfo, LPTREENODEINFO lpTreeNodeInfo)
{
	int nRet;
	LPTREENODEHEAD lpRootHead;
	//根据结点的类型，执行相关的操作
	lpSearchInfo->m_lpNodeLow = m_lpRootBlock;
	lpRootHead = (LPTREENODEHEAD)m_lpRootBlock;

	//1.如果Root是一个新建Root则要将其初始化为一个叶子结点
	if(NEWNODE == lpRootHead->m_bNodeType)
	{
		InitialBlock(lpRootHead, GetLeaveSize(lpMultiIndex), GetHeadSize(lpMultiIndex), LEAVENODE);
	}

	switch(lpRootHead->m_bNodeType)
	{
	case BIGTRUNKNODE:
		//2.如果Root是大树干结点，则首先遍历所有大树干结点，找到关键字对应的树干结点
		lpTreeNodeInfo->m_lpBigTrunkNode = lpSearchInfo->m_lpNodeLow;
		nRet = BigTrunkSearch(lpExecutePlan, lpMultiIndex, lpSearchInfo, lpTreeNodeInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		//获取关键字对应的树干结点位置
		lpSearchInfo->m_lpNodeLow = ConvertBlockNotoAddr(GetNodeNoFromTrunk(lpTreeNodeInfo->m_lpBigTrunkElement));
		if(lpSearchInfo->m_lpNodeLow == NULL)
		{
			return MF_BTREEINDEX_INVALIDNODENO_ERROR;
		}	
		//没有break的
	case TRUNKNODE:
		//3.树干结点
		lpTreeNodeInfo->m_lpTrunkNode = lpSearchInfo->m_lpNodeLow;

		nRet = TrunkSearch(lpMultiIndex, lpSearchInfo, lpTreeNodeInfo);
		if(nRet != MF_OK)
		{
			return MF_OK;
		}
	
		//获取关键字对应的叶子结点位置
		lpSearchInfo->m_lpNodeLow = ConvertBlockNotoAddr(GetNodeNoFromTrunk(lpTreeNodeInfo->m_lpTrunkElement));
		if(lpSearchInfo->m_lpNodeLow == NULL)
		{
			return MF_BTREEINDEX_INVALIDNODENO_ERROR;
		}
		//没有break
	case LEAVENODE:
		//4.叶子结点
		lpTreeNodeInfo->m_lpLeaveNode = lpSearchInfo->m_lpNodeLow;
	
		nRet = LeaveNodeSearch(lpMultiIndex, lpSearchInfo, lpTreeNodeInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		break;
	default:
		return MF_BTREEINDEX_INVALIDNODETYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			在一个结点中查找数据项的插入位置
		参数说明：
			lpExecutePlan：执行计划
			bIndexType：索引类型
			lpMultiIndex：复合索引
			lpNodeInsertInfo：结点插入信息
			nTimestamp：时间戳
		特别说明：
			该函数在插入数据时使用,由于插入数据时可能会发生叶子结点的分裂，
			所以数据的插入不一定是在lpNode对应的结点中
		插入步骤：
			1.判断结点是否已满，如果结点以满则需要分裂
			2.如果发生分裂，则需要判断分裂后应该插入那一个结点，以及插入的位置
************************************************************************/
int CMemoryBTreeIndex::CheckInsertAddr(LPEXECUTEPLANBSON lpExecutePlan, MF_SYS_INDEXTYPE bIndexType, LPMULTIINDEX lpMultiIndex, LPNODEINSERTINFO lpNodeInsertInfo, long long nTimestamp)
{
	LPVOID lpMaxKeyPtr;
	LPBYTE lpInsertNode;
	int nRet, nNewNodeNo;
	BOOL bFindKey, bLast;
	LPTREENODEHEAD lpNodeHead;
	BINARYSEARCHINFO stSearchInfo;

	lpInsertNode = lpNodeInsertInfo->m_lpNode;
	lpNodeHead   = (LPTREENODEHEAD)lpNodeInsertInfo->m_lpNode;
	//1.判断结点是否已满，如果结点以满则需要分裂
	if(CheckNodeFull(lpNodeInsertInfo->m_lpNode))
	{
		//判断插入位置是否为最后一个块的最后一个位置
		lpMaxKeyPtr = GetMaxKeyPtr(lpInsertNode);
		if(CheckMaxKey(lpMaxKeyPtr))
		{
			if(lpInsertNode + lpNodeHead->m_nBlockHeadSize + lpNodeHead->m_nDataNum * lpNodeHead->m_nDataSize == lpNodeInsertInfo->m_lpInsertAddr)
			{
				bLast = TRUE;
			}
			else
			{
				bLast = FALSE;
			}
			
		}
		else
		{
			bLast = FALSE;
		}
		nRet = SplitIndexData(lpExecutePlan, bIndexType, lpNodeInsertInfo->m_lpNode, bLast, nNewNodeNo, nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpNodeInsertInfo->m_lpNewNode = ConvertBlockNotoAddr(nNewNodeNo);
		if(lpNodeInsertInfo->m_lpNewNode == NULL)
		{
			return MF_BTREEINDEX_INVALIDNODENO_ERROR;
		}

		//2.如果发生分裂，则需要判断分裂后应该插入那一个结点，以及插入的位置
		lpMaxKeyPtr = GetMaxKeyPtr(lpInsertNode);
		if(Compare(lpMultiIndex, lpMaxKeyPtr, OPERATOR_INSERT, bFindKey) > 0)
		{
			//如果待插数据项的关键字大于原结点的最大关键字，则插入新结点
			lpInsertNode = lpNodeInsertInfo->m_lpNewNode;
			lpNodeInsertInfo->m_lpNode = lpNodeInsertInfo->m_lpNewNode;
			lpNodeHead   = (LPTREENODEHEAD)lpNodeInsertInfo->m_lpNewNode;
		}

		//如果发生了分裂，则需要用二分法重新定位插入位置
		memset(&stSearchInfo, 0, sizeof(BINARYSEARCHINFO));
		stSearchInfo.m_lpNodeLow     = lpInsertNode;
		stSearchInfo.m_bOperatorType = OPERATOR_INSERT;
		stSearchInfo.m_nHigh 	     = 0;
		stSearchInfo.m_nHigh	     = lpNodeHead->m_nDataNum - 1;
		BinarySearch(lpMultiIndex, &stSearchInfo);
		lpNodeInsertInfo->m_lpInsertAddr = lpInsertNode + lpNodeHead->m_nBlockHeadSize + stSearchInfo.m_nDataPosLow * lpNodeHead->m_nDataSize;			
	}
	
	//如果不发生分裂，则不插入位置就不会发生变化
	lpNodeHead = (LPTREENODEHEAD)lpInsertNode;
	//计算数据插入位置之后还有多少条数据(也就是在插入时需要移动多少条数据)
	lpNodeInsertInfo->m_nMoveLen = (int)(lpInsertNode + lpNodeHead->m_nBlockHeadSize + lpNodeHead->m_nDataNum * lpNodeHead->m_nDataSize - lpNodeInsertInfo->m_lpInsertAddr);	
	return MF_OK;
}

/************************************************************************
		功能说明：
			将索引项插入叶子结点中
		参数说明：
			lpExecutePlan：执行计划
			bIndexType：索引类型
			lpNodeInsertInfo：结点插入信息
			lpMultiIndex：复合索引
			nDataID：数据ID
		特别说明：
			该函数用于实际插入索引项
			插入步骤：
			1.查询索引项的插入位置，得到插入时要移动的数据长度
			2.如果结点不为空,且插入位置不是结点末尾，则插入时需要移动数据
			3.执行插入操作
************************************************************************/
int CMemoryBTreeIndex::InsertLeaveStruct(LPEXECUTEPLANBSON lpExecutePlan, MF_SYS_INDEXTYPE bIndexType, LPNODEINSERTINFO lpNodeInsertInfo, LPMULTIINDEX lpMultiIndex, long long nDataID, long long nTimestamp)
{
	int nRet;
	LPTREENODEHEAD lpLeaveHead;
	//获取插入位置
	if(lpNodeInsertInfo->m_lpInsertAddr == NULL)			
	{
		lpLeaveHead = (LPTREENODEHEAD)lpNodeInsertInfo->m_lpNode;
		//在新建结点中插入数据
		lpNodeInsertInfo->m_lpInsertAddr  = lpNodeInsertInfo->m_lpInsertAddr + lpLeaveHead->m_nBlockHeadSize;
	}
	else
	{
		//获取索引项的插入位置，得到插入时要移动的数据长度
		nRet = CheckInsertAddr(lpExecutePlan, bIndexType, lpMultiIndex, lpNodeInsertInfo, nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpLeaveHead = (LPTREENODEHEAD)lpNodeInsertInfo->m_lpNode;
	
		//如果结点不为空,且插入位置不是结点末尾，则插入时需要移动数据
		if(lpLeaveHead->m_nDataNum && !IsEnd(lpNodeInsertInfo->m_lpNode,lpNodeInsertInfo->m_lpInsertAddr))
		{
			//将插入位置的数据项后移动一个叶子结构体空间的长度
			MoveIndexData(lpNodeInsertInfo->m_lpInsertAddr, lpNodeInsertInfo->m_lpInsertAddr + lpLeaveHead->m_nDataSize, lpNodeInsertInfo->m_nMoveLen); 
		}

	}
	
	//执行插入操作
	SetLeaveData(lpNodeInsertInfo->m_lpInsertAddr, lpMultiIndex, nDataID);
	lpLeaveHead->m_nDataNum++;		
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)lpNodeInsertInfo->m_lpNode, nTimestamp);
	return MF_OK;
}

/************************************************************************
		功能说明：
			将树干结点插入内存中
		参数说明：
			lpExecutePlan：执行计划
			bIndexType：索引类型
			lpNodeInsertInfo：结点插入信息
			lpMultiIndex：复合索引
			nNodeNo：结点编号
			nTimestamp：时间戳
		特别说明：
			1.查询索引项的插入位置，得到插入时要移动的数据长度
			2.如果结点不为空,且插入位置不是结点末尾，则插入时需要移动数据
			3.执行插入操作
************************************************************************/
int CMemoryBTreeIndex::InsertTrunkStruct(LPEXECUTEPLANBSON lpExecutePlan, MF_SYS_INDEXTYPE bIndexType, LPNODEINSERTINFO lpNodeInsertInfo, LPMULTIINDEX lpMultiIndex, int nNodeNo, long long nTimestamp)
{
	int nRet;	
	LPTREENODEHEAD lpTrunkHead;
	//注意这里不需要给树干结点上锁，因为在叶子结点发生分裂时就已经提前给树干结点上了锁
	if(lpNodeInsertInfo->m_lpInsertAddr  == NULL)			
	{
		lpTrunkHead  = (LPTREENODEHEAD)lpNodeInsertInfo->m_lpNode;
		//在新建结点中插入数据
		lpNodeInsertInfo->m_lpInsertAddr = lpNodeInsertInfo->m_lpNode + lpTrunkHead->m_nBlockHeadSize;
	}
	else
	{
		//获取索引项的插入位置，得到插入时要移动的数据长度
		nRet = CheckInsertAddr(lpExecutePlan, bIndexType, lpMultiIndex, lpNodeInsertInfo, nTimestamp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		
		lpTrunkHead = (LPTREENODEHEAD)lpNodeInsertInfo->m_lpNode;

		//如果结点不为空,且插入位置不是结点末尾，则插入时需要移动数据
		if(lpTrunkHead->m_nDataNum && !IsEnd(lpNodeInsertInfo->m_lpNode,lpNodeInsertInfo->m_lpInsertAddr))
		{
			//将插入位置的数据项后移动一个叶子结构体空间的长度
			MoveIndexData(lpNodeInsertInfo->m_lpInsertAddr, lpNodeInsertInfo->m_lpInsertAddr + lpTrunkHead->m_nDataSize, lpNodeInsertInfo->m_nMoveLen);     
		}
	}

	//执行插入操作
	SetTrunkData(lpNodeInsertInfo->m_lpInsertAddr, lpMultiIndex, nNodeNo);
	lpTrunkHead->m_nDataNum++;	

	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)lpNodeInsertInfo->m_lpNode, nTimestamp);
	return MF_OK;
}

/************************************************************************
		功能说明：
			改变最大值
		参数说明：
			lpExecutePlan：执行计划
			stTreeNodeInfo：节点信息
			lpKeyPtr：关键字指针
			bNodeType：节点类型
			nTimestamp：时间戳
************************************************************************/
void CMemoryBTreeIndex::ChangeMaxKey(LPEXECUTEPLANBSON lpExecutePlan, TREENODEINFO& stTreeNodeInfo, LPVOID lpKeyPtr, NODETYPE bNodeType, long long nTimestamp)
{
	LPTREENODEHEAD lpCurrentHead, lpParentHead;
	LPBYTE lpCurrentNode, lpCurrentPos, lpParentPos;

	if(LEAVENODE == bNodeType)
	{
		lpCurrentNode 	= stTreeNodeInfo.m_lpLeaveNode;
		lpCurrentHead   = (LPTREENODEHEAD)lpCurrentNode;
		lpCurrentPos  	= (LPBYTE)stTreeNodeInfo.m_lpLeaveStartElement;
		lpParentHead	= (LPTREENODEHEAD)stTreeNodeInfo.m_lpTrunkNode;
		lpParentPos		= (LPBYTE)stTreeNodeInfo.m_lpTrunkElement;
	}
	else if(TRUNKNODE == bNodeType)
	{
		lpCurrentNode 	= stTreeNodeInfo.m_lpTrunkNode;
		lpCurrentHead   = (LPTREENODEHEAD)lpCurrentNode;
		lpCurrentPos  	= (LPBYTE)stTreeNodeInfo.m_lpTrunkElement;
		lpParentHead	= (LPTREENODEHEAD)stTreeNodeInfo.m_lpBigTrunkNode;
		lpParentPos		= (LPBYTE)stTreeNodeInfo.m_lpBigTrunkElement;
	}
	else
	{
		lpCurrentNode 	= stTreeNodeInfo.m_lpBigTrunkNode;
		lpCurrentHead   = (LPTREENODEHEAD)lpCurrentNode;
		lpCurrentPos  	= (LPBYTE)stTreeNodeInfo.m_lpBigTrunkElement;
		lpParentHead 	= NULL;
		lpParentPos		= NULL;
	}
	SetKeyValue(GetKeyPtr(lpCurrentPos, lpCurrentHead->m_bNodeType), lpKeyPtr, FALSE);
	//如果修改元素为当前节点的最后一个元素，则需要修改节点的最大值
	if(lpCurrentPos + lpCurrentHead->m_nDataSize == lpCurrentNode + lpCurrentHead->m_nBlockHeadSize + lpCurrentHead->m_nDataNum * lpCurrentHead->m_nDataSize)
	{
		SetKeyValue(GetMaxKeyPtr(lpCurrentNode), lpKeyPtr, FALSE);
		if(lpParentHead != NULL)
		{
			ChangeMaxKey(lpExecutePlan, stTreeNodeInfo, lpKeyPtr, lpParentHead->m_bNodeType, nTimestamp);
		}
	}
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)lpCurrentNode, nTimestamp);
}


/************************************************************************
		功能说明：
			获取前驱节点
		参数说明：
			lpNode：节点
			lpNodeElement：节点元素
			lpPreNode：前驱节点
			lpPreElement：前驱节点元素
************************************************************************/
int CMemoryBTreeIndex::GetPrecursorNode(LPBYTE lpNode, LPBYTE lpNodeElement, LPBYTE& lpPreNode, LPBYTE& lpPreElement)
{
	LPTREENODEHEAD lpNodeHead;
	
	lpNodeHead = (LPTREENODEHEAD)lpNode;
	if(IsFirst(lpNode, lpNodeElement))
	{
		//如果当前节点元素为当前节点的第一个元素，则其前驱元素一定在前一个节点中
		if(lpNodeHead->m_nPreNodeNo == 0)
		{
			return MF_BTREEINDEX_MERGENODE_ERROR;
		}
		else
		{
			lpPreNode		= ConvertBlockNotoAddr(lpNodeHead->m_nPreNodeNo);
			
			lpNodeHead		= (LPTREENODEHEAD)lpPreNode;
			lpPreElement	= lpPreNode + lpNodeHead->m_nBlockHeadSize + lpNodeHead->m_nDataSize*(lpNodeHead->m_nDataNum - 1);		//前一个节点的最后一个元素位置
		}
	}
	else
	{
		//否则前驱元素就在当前节点中
		lpPreNode			= lpNode;
		lpPreElement		= lpNodeElement - lpNodeHead->m_nDataSize;				//前一个元素	
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取后继节点
		参数说明：
			lpNode：节点
			lpNodeElement：节点元素
			lpSuccessNode：后继节点
			lpSuccessElement：后继节点元素
************************************************************************/
int CMemoryBTreeIndex::GetSuccessorNode(LPBYTE lpNode, LPBYTE lpNodeElement, LPBYTE& lpSuccessNode, LPBYTE& lpSuccessElement)
{
	LPTREENODEHEAD lpNodeHead;
	lpNodeHead = (LPTREENODEHEAD)lpNode;

	if(lpNodeElement == lpNode + lpNodeHead->m_nBlockHeadSize + lpNodeHead->m_nDataSize * (lpNodeHead->m_nDataNum - 1))
	{
		//如果当前节点元素为当前节点的最后一个元素，则其后继元素一定在后一个节点中
		if(lpNodeHead->m_nNextNodeNo == 0)
		{
			return MF_BTREEINDEX_MERGENODE_ERROR;
		}
		else
		{
			lpSuccessNode		= ConvertBlockNotoAddr(lpNodeHead->m_nNextNodeNo);
			lpNodeHead			= (LPTREENODEHEAD)lpSuccessNode;
			lpSuccessElement	= lpSuccessNode + lpNodeHead->m_nBlockHeadSize;		//下一个块的第一个元素位置
		}
	}
	else
	{
		//否则前驱元素就在当前节点中
		lpSuccessNode			= lpNode;
		lpSuccessElement		= lpNodeElement + lpNodeHead->m_nDataSize;			//下一个元素	
	}

	return MF_OK;
}

/************************************************************************
		功能说明：
			获取相邻节点的信息
		参数说明：
			stSrcTreeNode：原始节点信息
			stNeighborNode：邻居节点
			bNodeType：邻居节点类型
			bSuccessor：是否为后继，如果不是后继则为前驱
************************************************************************/
int CMemoryBTreeIndex::GetNeighborNodeInfo(TREENODEINFO& stSrcTreeNode, TREENODEINFO& stNeighborNode, NODETYPE bNodeType, BOOL bSuccessor)
{
	int nRet;
	LPBYTE lpNode, lpNodeElement, lpNeighborNode, lpNeighborElement;
	if(bSuccessor)
	{
		if(bNodeType == TRUNKNODE)
		{
			lpNode			= (LPBYTE)stSrcTreeNode.m_lpTrunkNode;
			lpNodeElement	= (LPBYTE)stSrcTreeNode.m_lpTrunkElement;

			nRet = GetSuccessorNode(lpNode, lpNodeElement, lpNeighborNode, lpNeighborElement);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			stNeighborNode.m_lpTrunkNode	= lpNeighborNode;
			stNeighborNode.m_lpTrunkElement = lpNeighborElement;

			if(lpNeighborNode == lpNode)
			{
				//如果邻居树干节点与原始节点相同，则邻居大树干节点也与原始节点相同
				stNeighborNode.m_lpBigTrunkNode		= stSrcTreeNode.m_lpBigTrunkNode;
				stNeighborNode.m_lpBigTrunkElement	= stSrcTreeNode.m_lpBigTrunkElement;
			}
			else
			{
				lpNode			= (LPBYTE)stSrcTreeNode.m_lpBigTrunkNode;
				lpNodeElement	= (LPBYTE)stSrcTreeNode.m_lpBigTrunkElement;

				nRet = GetSuccessorNode(lpNode, lpNodeElement, lpNeighborNode, lpNeighborElement);
				if(nRet != MF_OK)
				{
					return nRet;
				}

				stNeighborNode.m_lpBigTrunkNode		= lpNeighborNode;
				stNeighborNode.m_lpBigTrunkElement	= lpNeighborElement;
			}
		}
		else if(bNodeType == BIGTRUNKNODE)
		{
			lpNode			= (LPBYTE)stSrcTreeNode.m_lpBigTrunkNode;
			lpNodeElement	= (LPBYTE)stSrcTreeNode.m_lpBigTrunkElement;

			nRet = GetSuccessorNode(lpNode, lpNodeElement, lpNeighborNode, lpNeighborElement);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			stNeighborNode.m_lpBigTrunkNode		= lpNeighborNode;
			stNeighborNode.m_lpBigTrunkElement	= lpNeighborElement;
		}
	}
	else
	{
		if(bNodeType == TRUNKNODE)
		{
			lpNode			= (LPBYTE)stSrcTreeNode.m_lpTrunkNode;
			lpNodeElement	= (LPBYTE)stSrcTreeNode.m_lpTrunkElement;

			nRet = GetPrecursorNode(lpNode, lpNodeElement, lpNeighborNode, lpNeighborElement);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			stNeighborNode.m_lpTrunkNode	= lpNeighborNode;
			stNeighborNode.m_lpTrunkElement = lpNeighborElement;

			if(lpNeighborNode == lpNode)
			{
				//如果邻居树干节点与原始节点相同，则邻居大树干节点也与原始节点相同
				stNeighborNode.m_lpBigTrunkNode		= stSrcTreeNode.m_lpBigTrunkNode;
				stNeighborNode.m_lpBigTrunkElement	= stSrcTreeNode.m_lpBigTrunkElement;
			}
			else
			{
				lpNode			= (LPBYTE)stSrcTreeNode.m_lpBigTrunkNode;
				lpNodeElement	= (LPBYTE)stSrcTreeNode.m_lpBigTrunkElement;

				nRet = GetPrecursorNode(lpNode, lpNodeElement, lpNeighborNode, lpNeighborElement);
				if(nRet != MF_OK)
				{
					return nRet;
				}

				stNeighborNode.m_lpBigTrunkNode		= lpNeighborNode;
				stNeighborNode.m_lpBigTrunkElement	= lpNeighborElement;
			}
		}
		else if(bNodeType == BIGTRUNKNODE)
		{
			lpNode			= (LPBYTE)stSrcTreeNode.m_lpBigTrunkNode;
			lpNodeElement	= (LPBYTE)stSrcTreeNode.m_lpBigTrunkElement;

			nRet = GetPrecursorNode(lpNode, lpNodeElement, lpNeighborNode, lpNeighborElement);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			stNeighborNode.m_lpBigTrunkNode		= lpNeighborNode;
			stNeighborNode.m_lpBigTrunkElement	= lpNeighborElement;
		}
	}

	return MF_OK;
}
/************************************************************************
		功能说明：
			在结点中删除对应的数据
		参数说明：
			lpExecutePlan：执行计划
			stTreeNodeInfo：遍历树信息
			bNodeType：节点类型
			nTimestamp：时间戳
		特别说明：
			该函数用于实际删除数据
************************************************************************/
int CMemoryBTreeIndex::DeleteKey(LPEXECUTEPLANBSON lpExecutePlan, TREENODEINFO& stTreeNodeInfo, BYTE bNodeType, long long nTimestamp)
{
	BOOL bMerge;
	int nRet, nRootNo;
	BYTE bParentNodeType;
	TREENODEINFO stTreeNodeInfo2;
	LPTREENODEHEAD lpDeleteHead, lpParentHead, lpNextNodeHead, lpPreNodeHead;
	LPBYTE lpLastPos, lpCurrentNode, lpDeletePos, lpParentNode, lpParentPos, lpMergeNode;

	//根据删除关键字所在节点的类型获取关键字所在的节点、关键字所在节点中的位置，节点的父亲节点和孩子节点
	if(LEAVENODE == bNodeType)
	{
		lpCurrentNode 	= stTreeNodeInfo.m_lpLeaveNode;
		lpDeletePos  	= (LPBYTE)stTreeNodeInfo.m_lpLeaveStartElement;
		lpParentNode 	= stTreeNodeInfo.m_lpTrunkNode;
		lpParentHead	= (LPTREENODEHEAD)lpParentNode;
		lpParentPos		= (LPBYTE)stTreeNodeInfo.m_lpTrunkElement;
		bParentNodeType = TRUNKNODE;
	}
	else if(TRUNKNODE == bNodeType)
	{
		lpCurrentNode 	= stTreeNodeInfo.m_lpTrunkNode;
		lpDeletePos  	= (LPBYTE)stTreeNodeInfo.m_lpTrunkElement;
		lpParentNode 	= stTreeNodeInfo.m_lpBigTrunkNode;
		lpParentHead	= (LPTREENODEHEAD)lpParentNode;
		lpParentPos		= (LPBYTE)stTreeNodeInfo.m_lpBigTrunkElement;
		bParentNodeType = BIGTRUNKNODE;
	}
	else
	{
		lpCurrentNode 	= stTreeNodeInfo.m_lpBigTrunkNode;
		lpDeletePos  	= (LPBYTE)stTreeNodeInfo.m_lpBigTrunkElement;
		lpParentHead	= NULL;
		lpParentNode 	= NULL;
		lpParentPos		= NULL;
	}
	lpDeleteHead = (LPTREENODEHEAD)lpCurrentNode;
	//判断关键字是否为节点的最后一个元素
	lpLastPos = lpCurrentNode + lpDeleteHead->m_nBlockHeadSize + lpDeleteHead->m_nDataNum * lpDeleteHead->m_nDataSize;
	if(lpDeletePos + lpDeleteHead->m_nDataSize != lpLastPos)
	{
		//如果删除的数据项不在结点末尾，则将删除位置后的数据向前移动一个数据结构体的长度
		MoveIndexData(lpDeletePos + lpDeleteHead->m_nDataSize, lpDeletePos, (int)(lpLastPos - lpDeletePos - lpDeleteHead->m_nDataSize));
		lpDeleteHead->m_nDataNum--;
	}
	else
	{
		//直接清空索引项
		memset(lpDeletePos, 0, lpDeleteHead->m_nDataSize);
		lpDeleteHead->m_nDataNum--;

		if(lpDeleteHead->m_nDataNum != 0)
		{
			//修改当前节点的最大关键字值
			lpDeletePos -= lpDeleteHead->m_nDataSize;
			SetKeyValue(GetMaxKeyPtr(lpCurrentNode), GetKeyPtr(lpDeletePos, lpDeleteHead->m_bNodeType), FALSE);
			
			//修改其父亲节点的关键字
			if(lpParentHead != NULL)
			{
				ChangeMaxKey(lpExecutePlan, stTreeNodeInfo, GetKeyPtr(lpDeletePos, lpDeleteHead->m_bNodeType), lpParentHead->m_bNodeType, nTimestamp);
			}
		}
	}

	if(lpDeleteHead->m_nDataNum == 0)
	{
		//如果删除关键字后，节点为空，则需要将该节点的空间进行回收
		if(lpParentNode == NULL)
		{
			//当前节点没有父亲节点，则当前节点可能是大树干节点链表中的一个节点，也可能是根节点
			nRet = m_pIndexFile->GetRootNo(lpExecutePlan, nRootNo, m_nIndexID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			
			if(lpDeleteHead->m_bNodeType == BIGTRUNKNODE)
			{
				if(nRootNo == lpDeleteHead->m_nBlockNo)
				{
					//大树干节点为根节点
					if(lpDeleteHead->m_nPreNodeNo != 0)
					{
						//根节点一定没有前驱
						return MF_BTREEINDEX_DELETEINDEX_NODEERROR;
					}
					if(lpDeleteHead->m_nNextNodeNo != 0)
					{
						//根节点更新
						lpNextNodeHead = (LPTREENODEHEAD)ConvertBlockNotoAddr(lpDeleteHead->m_nNextNodeNo);
						lpNextNodeHead->m_nPreNodeNo = 0;
						nRet = RootUpdate(lpExecutePlan, m_nIndexID, lpDeleteHead->m_nNextNodeNo);
						if(nRet != MF_OK)
						{
							return nRet;
						}
					}
					else
					{
						//直接释放根节点
						nRet = FreeRootBlock(lpExecutePlan, m_nIndexID);
						if(nRet != MF_OK)
						{
							return nRet;
						}
					}
				}
				else
				{
					//为大树干节点链上的节点
					if(lpDeleteHead->m_nPreNodeNo == 0)
					{
						return MF_BTREEINDEX_DELETEINDEX_NODEERROR;
					}
					lpPreNodeHead  = (LPTREENODEHEAD)ConvertBlockNotoAddr(lpDeleteHead->m_nPreNodeNo);
					lpPreNodeHead->m_nNextNodeNo = lpDeleteHead->m_nNextNodeNo;

					if(lpDeleteHead->m_nNextNodeNo != 0)
					{
						lpNextNodeHead = (LPTREENODEHEAD)ConvertBlockNotoAddr(lpDeleteHead->m_nNextNodeNo);
						lpNextNodeHead->m_nPreNodeNo = lpDeleteHead->m_nPreNodeNo;
					}
					FreeBlock(lpExecutePlan, lpDeleteHead->m_nBlockNo);
				}
			}
			else if(nRootNo == lpDeleteHead->m_nBlockNo)
			{
				//非大树干节点的根节点，前驱后继都为空
				if(lpDeleteHead->m_nPreNodeNo != 0 || lpDeleteHead->m_nNextNodeNo != 0)
				{
					return MF_BTREEINDEX_DELETEINDEX_NODEERROR;
				}
				
				//直接释放根节点
				nRet = FreeRootBlock(lpExecutePlan, m_nIndexID);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
			else
			{
				return MF_BTREEINDEX_DELETEINDEX_NODEERROR;
			}
		}
		else
		{
			//不为根节点
			if(lpDeleteHead->m_nPreNodeNo != 0)
			{
				lpPreNodeHead  = (LPTREENODEHEAD)ConvertBlockNotoAddr(lpDeleteHead->m_nPreNodeNo);
				lpPreNodeHead->m_nNextNodeNo = lpDeleteHead->m_nNextNodeNo;
			}

			if(lpDeleteHead->m_nNextNodeNo != 0)
			{
				lpNextNodeHead = (LPTREENODEHEAD)ConvertBlockNotoAddr(lpDeleteHead->m_nNextNodeNo);
				lpNextNodeHead->m_nPreNodeNo = lpDeleteHead->m_nPreNodeNo;
			}
			FreeBlock(lpExecutePlan, lpDeleteHead->m_nBlockNo);
			
			//在上级节点中删除对应关键字
			nRet = DeleteKey(lpExecutePlan, stTreeNodeInfo, bParentNodeType, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}
	else if(lpDeleteHead->m_nDataNum <= lpDeleteHead->m_nTotalDataNum*MERGE_THRESHOLD + 1)
	{
		//如果节点中Key值小于总量的百分之40,则考虑进行块合并，合并方式都是从右向左合并
		bMerge = FALSE;
		if(lpDeleteHead->m_nPreNodeNo != 0)
		{
			//如果前一个块可以进行合并，则将当前块向前一个块合并
			lpMergeNode = ConvertBlockNotoAddr(lpDeleteHead->m_nPreNodeNo);
			bMerge		= CanMerge(lpDeleteHead, (LPTREENODEHEAD)lpMergeNode);
			if(bMerge)
			{
				//合并后当前节点为空
				if(lpParentNode == NULL && bNodeType != BIGTRUNKNODE)
				{
					return MF_BTREEINDEX_MERGENODE_ERROR;
				}
				else if(lpParentNode != NULL)
				{
					//获取当前节点前驱的父亲节点和父亲元素
					memset(&stTreeNodeInfo2, 0, sizeof(TREENODEINFO));
					nRet = GetNeighborNodeInfo(stTreeNodeInfo, stTreeNodeInfo2, bParentNodeType, FALSE);
					if(nRet != MF_OK)
					{
						return nRet;
					}

					//合并节点(因为合并后节点前驱会发生变化，所以应该先获取前驱信息再合并)
					MergeNode(lpExecutePlan, lpCurrentNode, lpMergeNode, nTimestamp);

					//修改当前节点前驱的最大关键字值
					ChangeMaxKey(lpExecutePlan, stTreeNodeInfo2, GetMaxKeyPtr(lpMergeNode), bParentNodeType, nTimestamp);

					//在当前节点的父亲节点中删除对应关键字
					nRet = DeleteKey(lpExecutePlan, stTreeNodeInfo, bParentNodeType, nTimestamp);
					if(nRet != MF_OK)
					{
						return nRet;
					}
				}
			}
		}

		if(!bMerge && lpDeleteHead->m_nNextNodeNo != 0)
		{
			//如果当前节点的后一个节点可以合并，则将后一个节点向当前节点合并
			lpMergeNode	= ConvertBlockNotoAddr(lpDeleteHead->m_nNextNodeNo);
			if(CanMerge((LPTREENODEHEAD)lpMergeNode, lpDeleteHead))
			{
				if(lpParentNode == NULL && bNodeType != BIGTRUNKNODE)
				{
					return MF_BTREEINDEX_MERGENODE_ERROR;
				}
				else if(lpParentNode != NULL)
				{
					//获取当前节点后继的父亲节点和父亲元素
					memset(&stTreeNodeInfo2, 0, sizeof(TREENODEINFO));
					nRet = GetNeighborNodeInfo(stTreeNodeInfo, stTreeNodeInfo2, bParentNodeType, TRUE);
					if(nRet != MF_OK)
					{
						return nRet;
					}

					//合并节点(因为合并后节点后继会发生变化，所以应该先获取后继信息再合并)
					MergeNode(lpExecutePlan, lpMergeNode, lpCurrentNode, nTimestamp);

					//修改当前节点父亲节点的最大关键字值
					ChangeMaxKey(lpExecutePlan, stTreeNodeInfo, GetMaxKeyPtr(lpCurrentNode), bParentNodeType, nTimestamp);

					//在当前节点的后继中删除最大关键字
					nRet = DeleteKey(lpExecutePlan, stTreeNodeInfo2, bParentNodeType, nTimestamp);
					if(nRet != MF_OK)
					{
						return nRet;
					}
				}
			}
		}
	}
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)lpCurrentNode, nTimestamp);
	return MF_OK;
}
/************************************************************************
		功能说明：
			移动到下一条数据
		参数说明：
			lpIndexInfo：索引信息
************************************************************************/
int CMemoryBTreeIndex::MoveNext(LPINDEXINFO lpIndexInfo)
{
	LPBYTE lpLeaveNode;
	LPVOID lpLeaveStruct;
	LPTREENODEHEAD lpLeaveHead;

	lpLeaveNode   = (LPBYTE)lpIndexInfo->m_pParam1;
	lpLeaveStruct = lpIndexInfo->m_pParam2;
	lpLeaveHead   = (LPTREENODEHEAD)lpLeaveNode;
	lpLeaveStruct = (LPBYTE)lpLeaveStruct + lpLeaveHead->m_nDataSize;
	//一个结点遍历完毕就跳转到下一个结点
	if(IsEnd(lpLeaveNode, (LPBYTE)lpLeaveStruct))
	{
		lpLeaveHead = (LPTREENODEHEAD)lpLeaveNode;
		if(lpLeaveHead->m_nNextNodeNo != 0)
		{
			lpLeaveNode   = ConvertBlockNotoAddr(lpLeaveHead->m_nNextNodeNo);
			lpLeaveStruct = lpLeaveNode + lpLeaveHead->m_nBlockHeadSize;
			if(lpIndexInfo->m_bPagingType == MF_PAGING_FIRST)
			{
				//zhy:未完善
				//备份当前结点(可以直接覆盖m_pLeaveNode指向的结点)
			}
		}
		else
		{
			lpIndexInfo->m_bEndSearch = TRUE;
		}
	}

	lpIndexInfo->m_pParam1 = lpLeaveNode;
	lpIndexInfo->m_pParam2 = lpLeaveStruct;
	return MF_OK;
}

/************************************************************************
		功能说明：
			找到B树第一个叶子结点的第一个元素
		参数说明：
			lpExecutePlan：执行计划
			lpTreeNodeInfo：树干结点信息
************************************************************************/
int CMemoryBTreeIndex::FirstLeaveElement(LPEXECUTEPLANBSON lpExecutePlan, LPTREENODEINFO lpTreeNodeInfo)
{
	LPBYTE lpNode;
	LPTREENODEHEAD lpBigTrunkHead, lpTrunkHead, lpLeaveHead, lpRootHead;
	
	//根据结点的类型，执行相关的操作
	lpNode		= m_lpRootBlock;
	lpRootHead	= (LPTREENODEHEAD)lpNode;
	switch(lpRootHead->m_bNodeType)
	{
	case BIGTRUNKNODE:
		lpTreeNodeInfo->m_lpBigTrunkNode   = lpNode;	
		lpBigTrunkHead   = (LPTREENODEHEAD)lpTreeNodeInfo->m_lpBigTrunkNode;

		//1.如果是大树干结点，则获取第一个大树干结点中的第一个树干结点
		lpTreeNodeInfo->m_lpBigTrunkElement = lpTreeNodeInfo->m_lpBigTrunkNode + lpBigTrunkHead->m_nBlockHeadSize;
		//获取nKey对应的树干结点位置
		lpNode = ConvertBlockNotoAddr(GetNodeNoFromTrunk(lpTreeNodeInfo->m_lpBigTrunkElement));
		if(lpNode == NULL)
		{
			return MF_BTREEINDEX_INVALIDNODENO_ERROR;
		}
		//没有break的
	case TRUNKNODE:
		lpTreeNodeInfo->m_lpTrunkNode   = lpNode;
		lpTrunkHead   = (LPTREENODEHEAD)lpTreeNodeInfo->m_lpTrunkNode;

		//2.如果是树干结点，获取第一个树干结点中的第一个叶子结点
		lpTreeNodeInfo->m_lpTrunkElement = lpTreeNodeInfo->m_lpTrunkNode + lpTrunkHead->m_nBlockHeadSize; 
		//获取nKey对应的叶子结点位置
		lpNode = ConvertBlockNotoAddr(GetNodeNoFromTrunk(lpTreeNodeInfo->m_lpTrunkElement));
		if(lpNode == NULL)
		{
			return MF_BTREEINDEX_INVALIDNODENO_ERROR;
		}
		
		//没有break
	case LEAVENODE:
		lpTreeNodeInfo->m_lpLeaveNode = lpNode;
		lpLeaveHead = (LPTREENODEHEAD)lpTreeNodeInfo->m_lpLeaveNode;

		//3.如果是叶子结点，获取第一个叶子结点
		lpTreeNodeInfo->m_lpLeaveStartElement = lpTreeNodeInfo->m_lpLeaveNode + lpLeaveHead->m_nBlockHeadSize; 
		break;
	default:
		return MF_BTREEINDEX_INVALIDNODETYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			找到B树最后一个叶子结点的最后一个元素
		参数说明：
			lpExecutePlan：执行计划
			lpTreeNodeInfo：树干结点信息
************************************************************************/
int CMemoryBTreeIndex::LastLeaveElement(LPEXECUTEPLANBSON lpExecutePlan, LPTREENODEINFO lpTreeNodeInfo)
{
	LPBYTE lpNode;
	LPTREENODEHEAD lpBigTrunkHead, lpTrunkHead, lpLeaveHead, lpRootHead;
	
	//根据结点的类型，执行相关的操作
	lpNode		= m_lpRootBlock;
	lpRootHead	= (LPTREENODEHEAD)lpNode;
	switch(lpRootHead->m_bNodeType)
	{
	case BIGTRUNKNODE:
		lpTreeNodeInfo->m_lpBigTrunkNode   = lpNode;	
		lpBigTrunkHead   = (LPTREENODEHEAD)lpTreeNodeInfo->m_lpBigTrunkNode;

		//1.如果是大树干结点，则获取最后一个大树干结点中的最后一个树干结点
		while(lpBigTrunkHead->m_nNextNodeNo)
		{
			lpNode = ConvertBlockNotoAddr(lpBigTrunkHead->m_nNextNodeNo);
			if(lpNode == NULL)
			{
				return MF_BTREEINDEX_INVALIDNODENO_ERROR;
			}
			lpTreeNodeInfo->m_lpBigTrunkNode = lpNode;	
			lpBigTrunkHead  = (LPTREENODEHEAD)lpTreeNodeInfo->m_lpBigTrunkNode;
		}

		lpTreeNodeInfo->m_lpBigTrunkElement = lpTreeNodeInfo->m_lpBigTrunkNode + lpBigTrunkHead->m_nBlockHeadSize + (lpBigTrunkHead->m_nDataNum - 1)*lpBigTrunkHead->m_nDataSize;
		//获取nKey对应的树干结点位置
		lpNode = ConvertBlockNotoAddr(GetNodeNoFromTrunk(lpTreeNodeInfo->m_lpBigTrunkElement));
		if(lpNode == NULL)
		{
			return MF_BTREEINDEX_INVALIDNODENO_ERROR;
		}
		//没有break的
	case TRUNKNODE:
		lpTreeNodeInfo->m_lpTrunkNode   = lpNode;
		lpTrunkHead   = (LPTREENODEHEAD)lpTreeNodeInfo->m_lpTrunkNode;

		//2.如果是树干结点，获取最后一个树干结点中的最后一个叶子结点
		lpTreeNodeInfo->m_lpTrunkElement = lpTreeNodeInfo->m_lpTrunkNode + lpTrunkHead->m_nBlockHeadSize + (lpTrunkHead->m_nDataNum - 1)*lpTrunkHead->m_nDataSize;
		//获取nKey对应的叶子结点位置
		lpNode = ConvertBlockNotoAddr(GetNodeNoFromTrunk(lpTreeNodeInfo->m_lpTrunkElement));
		if(lpNode == NULL)
		{
			return MF_BTREEINDEX_INVALIDNODENO_ERROR;
		}
		
		//没有break
	case LEAVENODE:
		lpTreeNodeInfo->m_lpLeaveNode = lpNode;
		lpLeaveHead = (LPTREENODEHEAD)lpTreeNodeInfo->m_lpLeaveNode;

		//3.如果是叶子结点，获取最后一个叶子结点
		lpTreeNodeInfo->m_lpLeaveStartElement = lpTreeNodeInfo->m_lpLeaveNode + lpLeaveHead->m_nBlockHeadSize + (lpLeaveHead->m_nDataNum - 2)*lpLeaveHead->m_nDataSize;			//注意：这里是nDataNum - 2,因为叶子节点的最后一个元素是MAX标志
		break;
	default:
		return MF_BTREEINDEX_INVALIDNODETYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			找到起始大树干结点、树干结点、叶子结点的位置
		参数说明：
			lpLeaveHead：叶子节点头
			lpTrunkHead：树干节点头
			lpBigTrunkHead：大树干节点头
************************************************************************/
int CMemoryBTreeIndex::FirstNodeHead(LPTREENODEHEAD& lpLeaveHead, LPTREENODEHEAD& lpTrunkHead, LPTREENODEHEAD& lpBigTrunkHead)
{
	LPVOID lpTrunkStruct, lpBigTrunkStruct;
	LPBYTE lpNode, lpLeaveNode, lpTrunkNode, lpBigTrunkNode;

	//根据结点的类型，执行相关的操作
	lpNode = m_lpRootBlock;
	switch(((LPTREENODEHEAD)lpNode)->m_bNodeType)
	{
	case BIGTRUNKNODE:
		lpBigTrunkNode = lpNode;	
		lpBigTrunkHead = (LPTREENODEHEAD)lpBigTrunkNode;
		//1.如果是大树干结点，则获取第一个大树干结点中的第一个树干结点
		lpBigTrunkStruct = lpBigTrunkNode + lpBigTrunkHead->m_nBlockHeadSize;
		//获取nKey对应的树干结点位置
		lpNode = ConvertBlockNotoAddr(GetNodeNoFromTrunk(lpBigTrunkStruct));
		if(lpNode == NULL)
		{
			return MF_BTREEINDEX_INVALIDNODENO_ERROR;
		}
		//没有break的
	case TRUNKNODE:
		lpTrunkNode = lpNode;
		lpTrunkHead = (LPTREENODEHEAD)lpTrunkNode;
		//2.如果是树干结点，获取第一个树干结点中的第一个叶子结点
		lpTrunkStruct = lpTrunkNode + lpTrunkHead->m_nBlockHeadSize; 
		//获取nKey对应的叶子结点位置
		lpNode = ConvertBlockNotoAddr(GetNodeNoFromTrunk(lpTrunkStruct));
		if(lpNode == NULL)
		{
			return MF_BTREEINDEX_INVALIDNODENO_ERROR;
		}
		//没有break
	case LEAVENODE:
		lpLeaveNode = lpNode;
		lpLeaveHead = (LPTREENODEHEAD)lpLeaveNode;
		break;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取叶子结点位置
		参数说明：
			lpIndexInfo索引信息
			lpSearchInfo：二分法信息
************************************************************************/
int CMemoryBTreeIndex::GetLeaveNode(LPINDEXINFO lpIndexInfo, LPBINARYSEARCHINFO lpSearchInfo)
{
	int nRet, i;
	TREENODEINFO stTreeNodeInfo;
	LPEXECUTEPLANBSON lpExecutePlan;
	MF_EXECUTEPLAN_OPERATOR bOperator;
	
	lpExecutePlan = (LPEXECUTEPLANBSON)(lpIndexInfo->m_pBson->GetBuffer());
	memset(&stTreeNodeInfo, 0, sizeof(TREENODEINFO));
	bOperator = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_bOperator;
	if(bOperator == MF_EXECUTEPLAN_OPERATOR_EQUAL		|| bOperator == MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL	||
	   bOperator == MF_EXECUTEPLAN_OPERATOR_GREATER		|| bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEEN			||
	   bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENE	|| bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENB		||
	   bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENBE   || bOperator == MF_EXECUTEPLAN_OPERATOR_LIKE)
	{
		i = 0;
		while(TRUE)
		{
			nRet = TreeSearch(lpExecutePlan, &lpIndexInfo->m_stMultiIndex, lpSearchInfo, &stTreeNodeInfo);
			if(nRet == MF_OK)
			{
				break;
			}
			else if(nRet != MF_INNER_SYS_SOURCEOCCUPIED_INVALID)
			{
				return nRet;
			}
			else
			{
				Sleep(1);
				i++;
				if(i > 10)
				{
					return nRet;
				}
			}
		} 
	}
	else if(bOperator == MF_EXECUTEPLAN_OPERATOR_NOTEQUAL	|| bOperator == MF_EXECUTEPLAN_OPERATOR_LESSEQUAL	||
			bOperator == MF_EXECUTEPLAN_OPERATOR_LESS)
	{
		i = 0;
		while(TRUE)
		{
			nRet = FirstLeaveElement(lpExecutePlan, &stTreeNodeInfo);
			if(nRet == MF_OK)
			{
				break;
			}
			else if(nRet != MF_INNER_SYS_SOURCEOCCUPIED_INVALID)
			{
				return nRet;
			}
			else
			{
				Sleep(1);
				i++;
				if(i > 10)
				{
					return nRet;
				}
			}
		}
	}
	else
	{
		return MF_COMMON_INVALID_OPERATOR;
	}
	lpIndexInfo->m_pParam1 = stTreeNodeInfo.m_lpLeaveNode;
	lpIndexInfo->m_pParam2 = stTreeNodeInfo.m_lpLeaveStartElement;
	lpIndexInfo->m_pParam3 = stTreeNodeInfo.m_lpLeaveEndElement;
	return MF_OK;
}

/************************************************************************
		功能说明:
			从叶子结点中获取DataID
		参数说明：
			lpIndexInfo：索引信息
			lpSearchInfo：树遍历信息
			pDataIDContainer：DataID容器
************************************************************************/
int CMemoryBTreeIndex::GetDataIDFromLeave(LPINDEXINFO lpIndexInfo, LPBINARYSEARCHINFO lpSearchInfo, CDataIDContainer* pDataIDContainer)
{
	int nRet;
	long long nDataID;
	BOOL bContinue, bPush;
	LPVOID lpLeaveStruct, lpKeyPtr;
	
	while(TRUE)
	{
		lpLeaveStruct = lpIndexInfo->m_pParam2;
		lpKeyPtr = GetKeyPtr(lpLeaveStruct, LEAVENODE);
		nDataID  = GetDataIDFromLeavePtr(lpLeaveStruct);

		lpIndexInfo->m_nDataID = nDataID;
		CheckDataValid(lpIndexInfo, lpKeyPtr, lpSearchInfo->m_nLevel, bContinue, bPush);
		if(bPush)
		{
			nRet = pDataIDContainer->push_back(nDataID);
			if(nRet == MF_COMMON_MAX_DATANUM)
			{
				break;
			}
			if(lpIndexInfo->m_bPagingType == MF_PAGING_FIRST && (int)pDataIDContainer->size() >= lpIndexInfo->m_nPageSize)
			{
				break;
			}
		}
		if(!bContinue)
		{
			break;
		}
		else
		{
			nRet = MoveNext(lpIndexInfo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpIndexInfo->m_bEndSearch)
			{
				break;
			}
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			删除索引
		参数说明：
			lpExecutePlan：执行计划
		特别说明：
			执行步骤：
			1.查询起始大树干结点、树干结点、叶子结点
			2.遍历各级结点链表，对每一个块进行删除
			3.调用文件及块回收函数回收块
			4.删除根节点
************************************************************************/
int CMemoryBTreeIndex::DropIndex(LPEXECUTEPLANBSON lpExecutePlan)
{
	int nRet, nBlockNo;
	LPTREENODEHEAD lpBigTrunkHead, lpTrunkHead, lpLeaveHead;

	//1.查询起始大树干结点、树干结点、叶子结点	
	lpLeaveHead		= NULL;
	lpTrunkHead		= NULL;
	lpBigTrunkHead	= NULL;
	nRet = FirstNodeHead(lpLeaveHead, lpTrunkHead, lpBigTrunkHead);
	if (nRet != MF_OK)
	{
		return nRet;
	}
	//2.遍历各级结点链表，对每一个块进行删除
	while(lpLeaveHead)
	{
		nBlockNo = lpLeaveHead->m_nBlockNo;
		FreeBlockDirect(lpExecutePlan, nBlockNo);
		lpLeaveHead = (LPTREENODEHEAD)ConvertBlockNotoAddr(lpLeaveHead->m_nNextNodeNo);
	}

	while(lpTrunkHead)
	{
		nBlockNo = lpTrunkHead->m_nBlockNo;
		FreeBlockDirect(lpExecutePlan, nBlockNo);
		lpTrunkHead = (LPTREENODEHEAD)ConvertBlockNotoAddr(lpTrunkHead->m_nNextNodeNo);
	}

	if(lpBigTrunkHead != NULL)
	{
		nBlockNo = lpBigTrunkHead->m_nBlockNo;
		FreeBlockDirect(lpExecutePlan, nBlockNo);
		lpBigTrunkHead = (LPTREENODEHEAD)ConvertBlockNotoAddr(lpBigTrunkHead->m_nNextNodeNo);
	}

	return MF_OK;
}


/************************************************************************
		功能说明：
			根据index的key值在索引块中插入一个新的索引项
		参数说明：
			lpIndexInfo:索引字段
			lpExecutePlan：执行计划
			nTimestamp：时间戳
		特别说明:
			该操作与数据的插入相关联，插入一条新的数据时，就会为该数据创建一个新的索引项并插入索引表
			插入过程如下：
			1.遍历B树找到关键字在大树结点、树结点、叶子结点的位置
			2.调用文件类的结点号地址转换函数(或者子类函数方案待定)，得到叶子结点指针
			3.调用CheckNodeFull函数，判断A结点是否已满
			4.如果A满，则调用SplitIndexData将A块分为两个块
			5.由于分配了新的块，内存结构发生了变化，所以需要再次调用BinaryExactSearch查找数据的插入位置
			6.插入数据
************************************************************************/
int CMemoryBTreeIndex::InsertIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	VARDATA varData;
	LPVOID lpMaxKeyPtr;
	CMemoryFile* pFile;
	CServiceBson* pBson;
	LPBYTE lpNewLeaveNode;
	CExpression stExpression;
	LPOBJECTDEF lpObjectInfo;
	long long nBlockMapOffset;
	RECORDDATAINFO stRecordInfo;
	TREENODEINFO stTreeNodeInfo;
	BINARYSEARCHINFO stSearchInfo;
	int	nRet, nBlockNo, nNodeNo, i;
	NODEINSERTINFO stNodeInsertInfo;
	IVirtualMemoryFile* pVirtualFile;
	LPTREENODEHEAD lpBigTrunkHead,lpTrunkHead,lpLeaveHead;

	memset(&stTreeNodeInfo, 0, sizeof(TREENODEINFO));
	memset(&stSearchInfo, 0, sizeof(BINARYSEARCHINFO));
	
	stSearchInfo.m_bOperatorType = OPERATOR_INSERT;
	stRecordInfo.m_bDataPosition = MF_DATAPOSITION_LOCAL;
	//1.遍历B树找到关键字在大树结点、树结点、叶子结点的位置指针(注意执行插入操作时，nRet返回值可以是MF_FAILED)
	i = 0;
	while(TRUE)
	{
		nRet = TreeSearch(lpExecutePlan, &lpIndexInfo->m_stMultiIndex, &stSearchInfo, &stTreeNodeInfo);	
		if(nRet == MF_OK)
		{
			if(lpIndexInfo->m_bUnique)
			{
				if(lpIndexInfo->m_bIndexType == MF_SYS_INDEXTYPE_TREE_MULTISTR ||lpIndexInfo->m_bIndexType == MF_SYS_INDEXTYPE_FUZZY_CHAR)
				{								   
					if(lpIndexInfo->m_bFirstString)
					{
						//校验关键字正确性
						pBson		 = lpIndexInfo->m_pBson;
						lpObjectInfo = pBson->GetObjectInfo();
						nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
						if(nRet != MF_OK)
						{
							return nRet;
						}
						pFile = (CMemoryFile*)pVirtualFile;
						stExpression.Initial(pBson, lpObjectInfo);

						stRecordInfo.m_nDataID = stSearchInfo.m_nDatID;
						nRet = pFile->GetRecordFieldValue(pBson, &stExpression, &stRecordInfo, lpIndexInfo->m_bFieldNo[0], varData);
						if(nRet != MF_OK)
						{
							break;
						}
						if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2 == varData)
						{
							return MF_BTREEINDEX_UNIQUEKEY_EXIST;
						}
						else
						{
							break;
						}
					}
					else
					{
						break;
					}
				}
				else
				{
					//校验关键字正确性
					pBson		 = lpIndexInfo->m_pBson;
					lpObjectInfo = pBson->GetObjectInfo();
					nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pVirtualFile);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					pFile = (CMemoryFile*)pVirtualFile;
					stExpression.Initial(pBson, lpObjectInfo);

					stRecordInfo.m_nDataID = stSearchInfo.m_nDatID;
					nRet = pFile->GetRecordFieldValue(pBson, &stExpression, &stRecordInfo, lpIndexInfo->m_bFieldNo[0], varData);
					if(nRet != MF_OK)
					{
						break;
					}
					if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2 == varData)
					{
						return MF_BTREEINDEX_UNIQUEKEY_EXIST;
					}
					else
					{
						break;
					}
				}
			}
			else
			{
				break;
			}
		}
		else if(nRet == MF_BTREEINDEX_BINARYSEARCH_NOKEYEQUAL)
		{
			break;;
		}
		else if(nRet != MF_INNER_SYS_SOURCEOCCUPIED_INVALID)
		{
			return nRet;
		}
		else
		{
			Sleep(1);
			i++;
			if(i > 10)
			{
				return nRet;
			}
		}
	}

	lpBigTrunkHead = (LPTREENODEHEAD)stTreeNodeInfo.m_lpBigTrunkNode;
	lpTrunkHead	   = (LPTREENODEHEAD)stTreeNodeInfo.m_lpTrunkNode;
	lpLeaveHead    = (LPTREENODEHEAD)stTreeNodeInfo.m_lpLeaveNode;

	stNodeInsertInfo.m_lpNode       = stTreeNodeInfo.m_lpLeaveNode;
	stNodeInsertInfo.m_lpParentNode = stTreeNodeInfo.m_lpTrunkNode;
	stNodeInsertInfo.m_lpInsertAddr = (LPBYTE)stTreeNodeInfo.m_lpLeaveStartElement;
	nRet = InsertLeaveStruct(lpExecutePlan, lpIndexInfo->m_bIndexType, &stNodeInsertInfo, &lpIndexInfo->m_stMultiIndex, lpIndexInfo->m_nDataID, nTimestamp);		
	if(nRet != MF_OK)
	{
		return nRet;
	}
	TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)stTreeNodeInfo.m_lpLeaveNode, nTimestamp);				
	
	lpNewLeaveNode = stNodeInsertInfo.m_lpNewNode;
	//2.判断叶子结点是否发生了分裂，如果发生了分裂，则需要把原叶子结点和分裂出来的叶子结点插入树干结点
	if(lpNewLeaveNode != NULL)
	{
		MULTIINDEX stMultiIndex;
		stMultiIndex.m_nIndexNum = lpIndexInfo->m_stMultiIndex.m_nIndexNum;
		for(i = 0; i < (int)stMultiIndex.m_nIndexNum; i++)
		{
			stMultiIndex.m_lpIndexCondition[i].m_bFieldNo   = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[i].m_bFieldNo;
			stMultiIndex.m_lpIndexCondition[i].m_bOperator  = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[i].m_bOperator;
			stMultiIndex.m_lpIndexCondition[i].m_bFieldType = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[i].m_bFieldType;
		}

		memset(&stNodeInsertInfo, 0, sizeof(NODEINSERTINFO));
		//首先判断分裂之前是否存在树干结点，如果不存在树干结点，则要分配一个块作为树干结点，并把根节点的指针指向树干
		if(stTreeNodeInfo.m_lpTrunkNode == NULL)
		{
			nBlockMapOffset = 0;
			nRet = AllocBlock(lpExecutePlan, nBlockNo, nBlockMapOffset, DEF_BTREEBLOCK_SIZE, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			stTreeNodeInfo.m_lpTrunkNode = ConvertBlockNotoAddr(nBlockNo);
			if(stTreeNodeInfo.m_lpTrunkNode == NULL)
			{
				return MF_BTREEINDEX_INVALIDNODENO_ERROR;
			}
			lpTrunkHead = (LPTREENODEHEAD)stTreeNodeInfo.m_lpTrunkNode;

			//初始化树干结点头
			InitialBlock(lpTrunkHead, GetTrunkSize(&stMultiIndex), GetHeadSize(&stMultiIndex), TRUNKNODE);

			//将原叶子结点插入树干
			nNodeNo     = lpLeaveHead->m_nBlockNo;
			lpMaxKeyPtr = GetMaxKeyPtr((LPBYTE)lpLeaveHead);
			SetIndexField(&stMultiIndex, lpMaxKeyPtr);
			
			stNodeInsertInfo.m_lpNode       = stTreeNodeInfo.m_lpTrunkNode;
			stNodeInsertInfo.m_lpParentNode = stTreeNodeInfo.m_lpBigTrunkNode;
			stNodeInsertInfo.m_lpInsertAddr = NULL;
			nRet = InsertTrunkStruct(lpExecutePlan, lpIndexInfo->m_bIndexType, &stNodeInsertInfo, &stMultiIndex, nNodeNo, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			//将新叶子结点插入树干
			nNodeNo		= ((LPTREENODEHEAD)lpNewLeaveNode)->m_nBlockNo;
			lpMaxKeyPtr = GetMaxKeyPtr(lpNewLeaveNode);
			SetIndexField(&stMultiIndex, lpMaxKeyPtr);
			stNodeInsertInfo.m_lpInsertAddr = stTreeNodeInfo.m_lpTrunkNode+lpTrunkHead->m_nBlockHeadSize+lpTrunkHead->m_nDataSize;
			nRet = InsertTrunkStruct(lpExecutePlan, lpIndexInfo->m_bIndexType, &stNodeInsertInfo, &stMultiIndex, nNodeNo, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)stTreeNodeInfo.m_lpTrunkNode, nTimestamp);					//更新树干结点时间
			//文件级要修改该Objcet的root偏移
			nRet = RootUpdate(lpExecutePlan, m_nIndexID, nBlockNo);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else
		{
			//之前有树干结点,由于新结点的nMaxKey就是分裂前原结点的MaxKey所以只需要树干结点中MaxKey对应的块号修改为新叶子结点的块号即可
			SetNodeNoToTrunk(stTreeNodeInfo.m_lpTrunkElement, ((LPTREENODEHEAD)lpNewLeaveNode)->m_nBlockNo);
			
			//插入原叶子结点
			nNodeNo = lpLeaveHead->m_nBlockNo;
			lpMaxKeyPtr = GetMaxKeyPtr((LPBYTE)lpLeaveHead);
			SetIndexField(&stMultiIndex, lpMaxKeyPtr);
			stNodeInsertInfo.m_lpNode       = stTreeNodeInfo.m_lpTrunkNode;
			stNodeInsertInfo.m_lpParentNode = stTreeNodeInfo.m_lpBigTrunkNode;
			stNodeInsertInfo.m_lpInsertAddr = (LPBYTE)stTreeNodeInfo.m_lpTrunkElement;
			nRet = InsertTrunkStruct(lpExecutePlan, lpIndexInfo->m_bIndexType, &stNodeInsertInfo, &stMultiIndex, nNodeNo, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)stTreeNodeInfo.m_lpTrunkNode, nTimestamp);					//更新树干结点时间戳
		}
	
		//判断树干结点是否发生了分裂如果发生分裂则需要将树干结点插入大树干结点
		if(stNodeInsertInfo.m_lpNewNode != NULL)
		{
			//首先判断分裂之前是否存在大树干结点，如果不存在大树干结点，则要分配一个块作为大树干结点，并把根节点的指针指向大树干
			if(stTreeNodeInfo.m_lpBigTrunkNode == NULL)
			{
				nBlockNo = 0;
				nRet = AllocBlock(lpExecutePlan, nBlockNo, nBlockMapOffset, DEF_BTREEBLOCK_SIZE, nTimestamp);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				stTreeNodeInfo.m_lpBigTrunkNode = ConvertBlockNotoAddr(nBlockNo);
				if(stTreeNodeInfo.m_lpBigTrunkNode == NULL)
				{
					return MF_BTREEINDEX_INVALIDNODENO_ERROR;
				}

				lpBigTrunkHead = (LPTREENODEHEAD)stTreeNodeInfo.m_lpBigTrunkNode;

				//初始化大树干结点头
				InitialBlock(lpBigTrunkHead, GetTrunkSize(&stMultiIndex), GetHeadSize(&stMultiIndex), BIGTRUNKNODE);

				//将原树干结点插入大树干
				nNodeNo = lpTrunkHead->m_nBlockNo;
				lpMaxKeyPtr = GetMaxKeyPtr((LPBYTE)lpTrunkHead);
				SetIndexField(&stMultiIndex, lpMaxKeyPtr);

				stNodeInsertInfo.m_lpNode       = stTreeNodeInfo.m_lpBigTrunkNode;
				stNodeInsertInfo.m_lpParentNode = NULL;
				stNodeInsertInfo.m_lpInsertAddr = NULL;
				nRet = InsertTrunkStruct(lpExecutePlan, lpIndexInfo->m_bIndexType, &stNodeInsertInfo, &stMultiIndex, nNodeNo, nTimestamp);
				if(nRet != MF_OK)
				{
					return nRet;
				}

				//将新结点插入大树干
				nNodeNo		= ((LPTREENODEHEAD)stNodeInsertInfo.m_lpNewNode)->m_nBlockNo;
				lpMaxKeyPtr = GetMaxKeyPtr(stNodeInsertInfo.m_lpNewNode);
				SetIndexField(&stMultiIndex, lpMaxKeyPtr);

				stNodeInsertInfo.m_lpInsertAddr = stTreeNodeInfo.m_lpBigTrunkNode+lpBigTrunkHead->m_nBlockHeadSize+lpBigTrunkHead->m_nDataSize;
				nRet = InsertTrunkStruct(lpExecutePlan, lpIndexInfo->m_bIndexType, &stNodeInsertInfo, &stMultiIndex, nNodeNo, nTimestamp);
				if(nRet != MF_OK)
				{
					return nRet;
				}

				TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)stTreeNodeInfo.m_lpBigTrunkNode, nTimestamp);					//更新大树干结点时间戳

				//文件级要修改该Objcet的root偏移
				nRet = RootUpdate(lpExecutePlan, m_nIndexID, nBlockNo);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
			else
			{	
				//之前有大树干结点,由于新结点的nMaxKey就是分裂前原结点的MaxKey所以只需要大树干结点中MaxKey对应的块号该成新树干结点的块号即可
				SetNodeNoToTrunk(stTreeNodeInfo.m_lpBigTrunkElement, ((LPTREENODEHEAD)stNodeInsertInfo.m_lpNewNode)->m_nBlockNo);
				//插入原树干结点
				nNodeNo		= lpTrunkHead->m_nBlockNo;
				lpMaxKeyPtr = GetMaxKeyPtr((LPBYTE)lpTrunkHead);
				SetIndexField(&stMultiIndex, lpMaxKeyPtr);
				
				stNodeInsertInfo.m_lpNode       = stTreeNodeInfo.m_lpBigTrunkNode;
				stNodeInsertInfo.m_lpParentNode = NULL;
				stNodeInsertInfo.m_lpInsertAddr = (LPBYTE)stTreeNodeInfo.m_lpBigTrunkElement;
				nRet = InsertTrunkStruct(lpExecutePlan, lpIndexInfo->m_bIndexType, &stNodeInsertInfo, &stMultiIndex, nNodeNo, nTimestamp);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				TimestampUpdate(lpExecutePlan, (LPBASEBLOCKHEAD)stTreeNodeInfo.m_lpBigTrunkNode, nTimestamp);					//更新大树干结点时间戳
	
				//无需判断大树干结点是否发生分裂，因为大树干结点如果发生分裂，所采取的措施是把分裂出的大树干结点加入链表
				//而其实在分裂时已经完成了链表的相关操作
			}
		}
	}
	//如果叶子结点没有发生分裂则索引项插入操作完成
	return MF_OK;
}

/************************************************************************
		功能说明：
			根据key值在索引块中删除一个索引项
		参数说明：
			lpIndexField：索引文件
			lpExecutePlan：执行计划
			nTimestamp：时间戳
		返回值说明：
			删除成功返回TRUE否则返回FALSE
		特别说明:
			该操作与数据的删除相关联，删除一条数据时，就会删除改数据的对应索引
			该函数会先调用BinaryExactSearch和 ConvertDataPostoAddr函数找到索引项的删除位置，
			删除索引项之后，需要调用MoveIndexData将删除位置后的数据向前移动
************************************************************************/
int CMemoryBTreeIndex::DeleteIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	int nRet, i;
	TREENODEINFO stTreeNodeInfo;
	BINARYSEARCHINFO stSearchInfo;
	LPTREENODEHEAD lpBigTrunkHead, lpTrunkHead, lpLeaveHead;
	
	memset(&stTreeNodeInfo, 0, sizeof(TREENODEINFO));
	memset(&stSearchInfo, 0, sizeof(BINARYSEARCHINFO));
	
	stSearchInfo.m_bOperatorType = OPERATOR_DELETE;

	i = 0;
	while (TRUE)
	{
		nRet = TreeSearch(lpExecutePlan, &lpIndexInfo->m_stMultiIndex, &stSearchInfo, &stTreeNodeInfo);
		if(nRet == MF_OK)
		{
			break;
		}
		else if(nRet == MF_INNER_SYS_SOURCEOCCUPIED_INVALID)
		{
			Sleep(1);
			i++;
			if(i > 10)
			{
				return nRet;
			}
		}
		else 
		{
			return nRet;
		}
	}

	lpBigTrunkHead = (LPTREENODEHEAD)stTreeNodeInfo.m_lpBigTrunkNode;
	lpTrunkHead	   = (LPTREENODEHEAD)stTreeNodeInfo.m_lpTrunkNode;
	lpLeaveHead	   = (LPTREENODEHEAD)stTreeNodeInfo.m_lpLeaveNode;

	//删除字符串索引时，需要在外层函数获取后缀关键字的偏移
	lpIndexInfo->m_nParam4 = *(long long*)stTreeNodeInfo.m_lpLeaveStartElement;

	//删除索引项
	nRet = DeleteKey(lpExecutePlan, stTreeNodeInfo, LEAVENODE, nTimestamp);
	if(nRet!= MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取一个DataID
		参数说明：
			lpIndexInfo：索引信息
			pDataIDContainer：DataID容器
************************************************************************/
int CMemoryBTreeIndex::GetDataID(LPINDEXINFO lpIndexInfo, CDataIDContainer* pDataIDContainer)
{
	int i, nRet;
	BOOL bSearch;
	long long nDataID;
	CServiceBson* pBson;
	BINARYSEARCHINFO stSearchInfo;
	LPEXECUTEPLANBSON lpExecutePlan;
	
	pBson	      = lpIndexInfo->m_pBson;
	lpExecutePlan = (LPEXECUTEPLANBSON)pBson->GetBuffer();
	memset(&stSearchInfo, 0, sizeof(BINARYSEARCHINFO));

	if(lpIndexInfo->m_pParam2 == NULL)
	{
		return MF_OK;
	}

	stSearchInfo.m_bOperatorType = OPERATOR_SEARCH;
	if(lpIndexInfo->m_bIndexType == MF_SYS_INDEXTYPE_FUZZY_CHAR || lpIndexInfo->m_bIndexType == MF_SYS_INDEXTYPE_TREE_MULTISTR)
	{
		pDataIDContainer->SetUnique(TRUE);
	}
	
	for(i = 0; i < 4; i++)
	{
		if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[i].m_bInequality)
		{
			return MF_OK;
		}	
	}
	//首先判断索引选择时获取的关键字起始位置是否发生了变化，如果没有发生变化，则直接获取DataID，否则需要重新在树中定位关键字位置
	bSearch = FALSE;
	if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESS || lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_bOperator == MF_EXECUTEPLAN_OPERATOR_LESSEQUAL)
	{
		bSearch = TRUE;
	}
	else if(lpIndexInfo->m_pParam2 != NULL)
	{
		nDataID = GetDataIDFromLeavePtr(lpIndexInfo->m_pParam2);
		if(nDataID != lpIndexInfo->m_nParam4)
		{
			bSearch = TRUE;
		}

		if(lpIndexInfo->m_bIndexType == MF_SYS_INDEXTYPE_FUZZY_CHAR || lpIndexInfo->m_bIndexType == MF_SYS_INDEXTYPE_TREE_MULTISTR)
		{
			//字符串索引需要判断关键字的结束位置是否发生变化
			if(lpIndexInfo->m_pParam3 != NULL)
			{
				nDataID = GetDataIDFromLeavePtr(lpIndexInfo->m_pParam3);
				if(nDataID != lpIndexInfo->m_nParam5)
				{
					bSearch = TRUE;
				}
			}
			else
			{
				bSearch = TRUE;
			}
		}
	}
	else 
	{
		bSearch = TRUE;
	}

	//获取叶子节点位置
	if(bSearch)
	{
		nRet = GetLeaveNode(lpIndexInfo, &stSearchInfo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//从叶子节点中获取DataID
	nRet = GetDataIDFromLeave(lpIndexInfo, &stSearchInfo, pDataIDContainer);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取索引扫描范围
		参数说明：
			stBson：Bson对象
			lpSubIndexPlan：子索引计划
************************************************************************/
int CMemoryBTreeIndex::GetIndexScanScope(LPSUBINDEXPLAN lpSubIndexPlan)
{
	int nRet, i;
	MULTIINDEX stMultiIndex;
	TREENODEINFO stTreeNodeInfo;
	BINARYSEARCHINFO stSearchInfo;
	MF_EXECUTEPLAN_OPERATOR bOperator;

	memset(&stSearchInfo,	0, sizeof(BINARYSEARCHINFO));
	memset(&stTreeNodeInfo, 0, sizeof(TREENODEINFO));
	memset(&stMultiIndex,	0, sizeof(MULTIINDEX));
	stSearchInfo.m_bOperatorType = OPERATOR_SEARCH;
	for(i = 0; i < 4; i++)
	{
		if(lpSubIndexPlan->m_ppCondition[i] == NULL)
		{
			break;
		}
		else
		{
			memcpy(&stMultiIndex.m_lpIndexCondition[i], &lpSubIndexPlan->m_ppCondition[i]->m_stIndexCondition, sizeof(INDEXCONDITION));
			stMultiIndex.m_nIndexNum++;
		}
	}
	
	if(lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_bInequality)
	{
		//恒不等式
		lpSubIndexPlan->m_nScanScope = 0;
		return MF_OK;
	}

	bOperator = lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_bOperator;
	if(bOperator == MF_EXECUTEPLAN_OPERATOR_EQUAL || bOperator == MF_EXECUTEPLAN_OPERATOR_LIKE)
	{
		//获取索引关键字的起始位置
		nRet = TreeSearch(NULL, &stMultiIndex, &stSearchInfo, &stTreeNodeInfo);
		if(nRet != MF_OK && nRet != MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
		{
			return nRet;
		}
		lpSubIndexPlan->m_nScanScope = stSearchInfo.m_nSearchScope;
	}
	else if(bOperator == MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL || bOperator == MF_EXECUTEPLAN_OPERATOR_GREATER)
	{
		LPBYTE lpNode;
		long long nSearchScope;
		LPTREENODEHEAD lpNodeHead;

		//获取索引关键字的起始位置
		nRet = TreeSearch(NULL, &stMultiIndex, &stSearchInfo, &stTreeNodeInfo);
		if(nRet != MF_OK && nRet != MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
		{
			return nRet;
		}

		//获取索引的搜索范围
		lpNode		 = stSearchInfo.m_lpNodeLow;
		lpNodeHead	 = (LPTREENODEHEAD)lpNode;
		nSearchScope = ((LPTREENODEHEAD)lpNode)->m_nDataNum - stSearchInfo.m_nDataPosLow;
		while(TRUE)
		{
			lpNode = ConvertBlockNotoAddr(lpNodeHead->m_nNextNodeNo);
			if(lpNode == NULL)
			{
				break;
			}
			lpNodeHead   = (LPTREENODEHEAD)lpNode;
			nSearchScope += lpNodeHead->m_nDataNum;
		}
		lpSubIndexPlan->m_nScanScope = nSearchScope;
	}
	else if(bOperator == MF_EXECUTEPLAN_OPERATOR_LESSEQUAL || bOperator == MF_EXECUTEPLAN_OPERATOR_LESS)
	{
		LPBYTE lpNode;
		long long nSearchScope;
		LPTREENODEHEAD lpNodeHead;

		//获取索引关键字的起始位置
		nRet = TreeSearch(NULL, &stMultiIndex, &stSearchInfo, &stTreeNodeInfo);
		if(nRet != MF_OK && nRet != MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
		{
			return nRet;
		}

		//获取索引的搜索范围
		lpNode		 = stSearchInfo.m_lpNodeLow;
		lpNodeHead	 = (LPTREENODEHEAD)lpNode;
		nSearchScope = stSearchInfo.m_nDataPosLow;
		while(TRUE)
		{
			lpNode = ConvertBlockNotoAddr(lpNodeHead->m_nPreNodeNo);
			if(lpNode == NULL)
			{
				break;
			}
			lpNodeHead   = (LPTREENODEHEAD)lpNode;
			nSearchScope += lpNodeHead->m_nDataNum;
		}
		lpSubIndexPlan->m_nScanScope = nSearchScope;
	}
	else if(bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEEN)
	{
		//将BETWEEN拆分成>=和<=两个条件，然后分别获取两个条件的关键字位置，再获取索引搜索范围
		long long nSearchScope;
		TREENODEINFO stTreeNodeInfo2;
		LPBYTE lpStartNode, lpEndNode;
		int nStartDataPos, nEndDataPos;
		LPTREENODEHEAD lpStartNodeHead, lpEndNodeHead;
	
		stMultiIndex.m_lpIndexCondition[0].m_bOperator     = MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL;
		stMultiIndex.m_lpIndexCondition[0].m_varCondition1 = lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1;
		nRet = TreeSearch(NULL, &stMultiIndex, &stSearchInfo, &stTreeNodeInfo);
		if(nRet != MF_OK && nRet != MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
		{
			return nRet;
		}
		lpStartNode		= stSearchInfo.m_lpNodeLow;
		lpStartNodeHead = (LPTREENODEHEAD)lpStartNode;
		nStartDataPos	= stSearchInfo.m_nDataPosLow;

		stMultiIndex.m_lpIndexCondition[0].m_bOperator     = MF_EXECUTEPLAN_OPERATOR_LESSEQUAL;
		stMultiIndex.m_lpIndexCondition[0].m_varCondition1 = lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition2;
		memset(&stTreeNodeInfo2, 0, sizeof(TREENODEINFO));
		memset(&stSearchInfo, 0, sizeof(BINARYSEARCHINFO));
		stSearchInfo.m_bOperatorType = OPERATOR_SEARCH;
		nRet = TreeSearch(NULL, &stMultiIndex, &stSearchInfo, &stTreeNodeInfo2);
		if(nRet != MF_OK && nRet != MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
		{
			return nRet;
		}
		lpEndNode		= stSearchInfo.m_lpNodeLow;
		lpEndNodeHead	= (LPTREENODEHEAD)lpEndNode;
		nEndDataPos  	= stSearchInfo.m_nDataPosLow;

		if(lpStartNodeHead->m_nBlockNo == lpEndNodeHead->m_nBlockNo)
		{
			nSearchScope = nEndDataPos - nStartDataPos;
		}
		else
		{
			nSearchScope = lpStartNodeHead->m_nDataNum - nStartDataPos;
			nSearchScope += nEndDataPos + 1;
			while(TRUE)
			{
				lpStartNode = ConvertBlockNotoAddr(lpStartNodeHead->m_nNextNodeNo);
				if(lpStartNode == NULL)
				{
					break;
				}
				else
				{
					lpStartNodeHead = (LPTREENODEHEAD)lpStartNode;
					if(lpStartNodeHead->m_nBlockNo == lpEndNodeHead->m_nBlockNo)
					{
						break;
					}
				}
				nSearchScope += lpStartNodeHead->m_nDataNum;
			}
		}
		lpSubIndexPlan->m_nScanScope = nSearchScope;
	}
	else if(bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENB)
	{
		//将BETWEENB拆分成>和<=两个条件，然后分别获取两个条件的关键字位置，再获取索引搜索范围
		long long nSearchScope;
		TREENODEINFO stTreeNodeInfo2;
		LPBYTE lpStartNode, lpEndNode;
		int nStartDataPos, nEndDataPos;
		LPTREENODEHEAD lpStartNodeHead, lpEndNodeHead;

		stMultiIndex.m_lpIndexCondition[0].m_bOperator     = MF_EXECUTEPLAN_OPERATOR_GREATER;
		stMultiIndex.m_lpIndexCondition[0].m_varCondition1 = lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1;
		nRet = TreeSearch(NULL, &stMultiIndex, &stSearchInfo, &stTreeNodeInfo);
		if(nRet != MF_OK && nRet != MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
		{
			return nRet;
		}
		lpStartNode		= stSearchInfo.m_lpNodeLow;
		lpStartNodeHead = (LPTREENODEHEAD)lpStartNode;
		nStartDataPos	= stSearchInfo.m_nDataPosLow;

		stMultiIndex.m_lpIndexCondition[0].m_bOperator     = MF_EXECUTEPLAN_OPERATOR_LESSEQUAL;
		stMultiIndex.m_lpIndexCondition[0].m_varCondition1 = lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition2;
		memset(&stTreeNodeInfo2, 0, sizeof(TREENODEINFO));
		memset(&stSearchInfo, 0, sizeof(BINARYSEARCHINFO));
		stSearchInfo.m_bOperatorType = OPERATOR_SEARCH;
		nRet = TreeSearch(NULL, &stMultiIndex, &stSearchInfo, &stTreeNodeInfo2);
		if(nRet != MF_OK && nRet != MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
		{
			return nRet;
		}
		lpEndNode		= stSearchInfo.m_lpNodeLow;
		lpEndNodeHead	= (LPTREENODEHEAD)lpEndNode;
		nEndDataPos  	= stSearchInfo.m_nDataPosLow;

		if(lpStartNodeHead->m_nBlockNo == lpEndNodeHead->m_nBlockNo)
		{
			nSearchScope = nEndDataPos - nStartDataPos;
		}
		else
		{
			nSearchScope = lpStartNodeHead->m_nDataNum - nStartDataPos;
			nSearchScope += nEndDataPos;
			while(TRUE)
			{
				lpStartNode = ConvertBlockNotoAddr(lpStartNodeHead->m_nNextNodeNo);
				if(lpStartNode == NULL)
				{
					break;
				}
				else
				{
					lpStartNodeHead = (LPTREENODEHEAD)lpStartNode;
					if(lpStartNodeHead->m_nBlockNo == lpEndNodeHead->m_nBlockNo)
					{
						break;
					}
				}
				nSearchScope += lpStartNodeHead->m_nDataNum;
			}
		}
		lpSubIndexPlan->m_nScanScope = nSearchScope;
	}
	else if(bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENE)
	{
		//将BETWEENE拆分成>=和<两个条件，然后分别获取两个条件的关键字位置，再获取索引搜索范围
		long long nSearchScope;
		TREENODEINFO stTreeNodeInfo2;
		LPBYTE lpStartNode, lpEndNode;
		int nStartDataPos, nEndDataPos;
		LPTREENODEHEAD lpStartNodeHead, lpEndNodeHead;

		stMultiIndex.m_lpIndexCondition[0].m_bOperator     = MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL;
		stMultiIndex.m_lpIndexCondition[0].m_varCondition1 = lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1;
		nRet = TreeSearch(NULL, &stMultiIndex, &stSearchInfo, &stTreeNodeInfo);
		if(nRet != MF_OK && nRet != MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
		{
			return nRet;
		}
		lpStartNode		= stSearchInfo.m_lpNodeLow;
		lpStartNodeHead = (LPTREENODEHEAD)lpStartNode;
		nStartDataPos	= stSearchInfo.m_nDataPosLow;

		stMultiIndex.m_lpIndexCondition[0].m_bOperator     = MF_EXECUTEPLAN_OPERATOR_LESS;
		stMultiIndex.m_lpIndexCondition[0].m_varCondition1 = lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition2;
		memset(&stTreeNodeInfo2, 0, sizeof(TREENODEINFO));
		memset(&stSearchInfo, 0, sizeof(BINARYSEARCHINFO));
		stSearchInfo.m_bOperatorType = OPERATOR_SEARCH;
		nRet = TreeSearch(NULL, &stMultiIndex, &stSearchInfo, &stTreeNodeInfo2);
		if(nRet != MF_OK && nRet != MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
		{
			return nRet;
		}
		lpEndNode		= stSearchInfo.m_lpNodeLow;
		lpEndNodeHead	= (LPTREENODEHEAD)lpEndNode;
		nEndDataPos  	= stSearchInfo.m_nDataPosLow;

		if(lpStartNodeHead->m_nBlockNo == lpEndNodeHead->m_nBlockNo)
		{
			nSearchScope = nEndDataPos - nStartDataPos;
		}
		else
		{
			nSearchScope = lpStartNodeHead->m_nDataNum - nStartDataPos;
			nSearchScope += nEndDataPos;
			while(TRUE)
			{
				lpStartNode = ConvertBlockNotoAddr(lpStartNodeHead->m_nNextNodeNo);
				if(lpStartNode == NULL)
				{
					break;
				}
				else
				{
					lpStartNodeHead = (LPTREENODEHEAD)lpStartNode;
					if(lpStartNodeHead->m_nBlockNo == lpEndNodeHead->m_nBlockNo)
					{
						break;
					}
				}
				nSearchScope += lpStartNodeHead->m_nDataNum;
			}
		}
		lpSubIndexPlan->m_nScanScope = nSearchScope;
	}
	else if(bOperator == MF_EXECUTEPLAN_OPERATOR_BETWEENBE)
	{
		//将BETWEENBE拆分成> 和 <两个条件，然后分别获取两个条件的关键字位置，再获取索引搜索范围
		long long nSearchScope;
		TREENODEINFO stTreeNodeInfo2;
		LPBYTE lpStartNode, lpEndNode;
		int nStartDataPos, nEndDataPos;
		LPTREENODEHEAD lpStartNodeHead, lpEndNodeHead;

		stMultiIndex.m_lpIndexCondition[0].m_bOperator     = MF_EXECUTEPLAN_OPERATOR_GREATER;
		stMultiIndex.m_lpIndexCondition[0].m_varCondition1 = lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1;
		nRet = TreeSearch(NULL, &stMultiIndex, &stSearchInfo, &stTreeNodeInfo);
		if(nRet != MF_OK && nRet != MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
		{
			return nRet;
		}
		lpStartNode		= stSearchInfo.m_lpNodeLow;
		lpStartNodeHead = (LPTREENODEHEAD)lpStartNode;
		nStartDataPos	= stSearchInfo.m_nDataPosLow;

		stMultiIndex.m_lpIndexCondition[0].m_bOperator     = MF_EXECUTEPLAN_OPERATOR_LESS;
		stMultiIndex.m_lpIndexCondition[0].m_varCondition1 = lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition2;
		memset(&stTreeNodeInfo2, 0, sizeof(TREENODEINFO));
		memset(&stSearchInfo, 0, sizeof(BINARYSEARCHINFO));
		stSearchInfo.m_bOperatorType = OPERATOR_SEARCH;
		nRet = TreeSearch(NULL, &stMultiIndex, &stSearchInfo, &stTreeNodeInfo2);
		if(nRet != MF_OK && nRet != MF_BTREEINDEX_BINARYSEARCH_NOKEYMATH)
		{
			return nRet;
		}
		lpEndNode		= stSearchInfo.m_lpNodeLow;
		lpEndNodeHead	= (LPTREENODEHEAD)lpEndNode;
		nEndDataPos  	= stSearchInfo.m_nDataPosLow;

		if(lpStartNodeHead->m_nBlockNo == lpEndNodeHead->m_nBlockNo)
		{
			nSearchScope = nEndDataPos - nStartDataPos;
		}
		else
		{
			nSearchScope = lpStartNodeHead->m_nDataNum - nStartDataPos;
			nSearchScope += nEndDataPos;
			while(TRUE)
			{
				lpStartNode = ConvertBlockNotoAddr(lpStartNodeHead->m_nNextNodeNo);
				if(lpStartNode == NULL)
				{
					break;
				}
				else
				{
					lpStartNodeHead = (LPTREENODEHEAD)lpStartNode;
					if(lpStartNodeHead->m_nBlockNo == lpEndNodeHead->m_nBlockNo)
					{
						break;
					}
				}
				nSearchScope += lpStartNodeHead->m_nDataNum;
			}
		}
		lpSubIndexPlan->m_nScanScope = nSearchScope;
	}
	else
	{
		return MF_COMMON_INVALID_OPERATOR;
	}

	lpSubIndexPlan->m_lpParamPtr1 = (long long)stTreeNodeInfo.m_lpLeaveNode;
	lpSubIndexPlan->m_lpParamPtr2 = (long long)stTreeNodeInfo.m_lpLeaveStartElement;
	lpSubIndexPlan->m_lpParamPtr3 = (long long)stTreeNodeInfo.m_lpLeaveEndElement;
	if(lpSubIndexPlan->m_lpParamPtr2 != NULL)
	{
		lpSubIndexPlan->m_nParam4 = GetDataIDFromLeavePtr((LPVOID)lpSubIndexPlan->m_lpParamPtr2);
	}

	if(lpSubIndexPlan->m_lpParamPtr3 != NULL)
	{
		lpSubIndexPlan->m_nParam5 = GetDataIDFromLeavePtr((LPVOID)lpSubIndexPlan->m_lpParamPtr3);
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取索引的最大关键字值和最小关键字值
		参数说明：
			nIndexID：索引ID
			varMaxKey：最大关键字值
			varMinKey：最小关键字值
************************************************************************/
int CMemoryBTreeIndex::GetIndexRange(int nIndexID, VARDATA& varMaxKey, VARDATA& varMinKey)
{
	int nRet;
	LPVOID lpKeyPtr;
	TREENODEINFO stTreeNodeInfo;
	memset(&stTreeNodeInfo, 0, sizeof(TREENODEINFO));
	
	//获取最小值 
	nRet = FirstLeaveElement(NULL, &stTreeNodeInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	lpKeyPtr = GetKeyPtr(stTreeNodeInfo.m_lpLeaveStartElement, LEAVENODE);
	nRet = GetValueFromKeyPtr(lpKeyPtr, 0, varMinKey);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//获取最大值
	nRet = LastLeaveElement(NULL, &stTreeNodeInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	lpKeyPtr = GetKeyPtr(stTreeNodeInfo.m_lpLeaveStartElement, LEAVENODE);
	nRet = GetValueFromKeyPtr(lpKeyPtr, 0, varMaxKey);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}