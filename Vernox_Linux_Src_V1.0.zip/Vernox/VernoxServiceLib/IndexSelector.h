﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
//索引选择类

int CombineCondition(LPINDEXCONDITION lpIndexCond1, LPINDEXCONDITION lpIndexCond2);

#pragma pack(1)
typedef struct stu_INDEXINQUERYCONDITION 
{
	INDEXCONDITION					m_stIndexCondition;			//索引条件
	BYTE*							m_pCompareType;				//该索引在原始查询条件中的类型指针
	int*							m_pCompareOffset;			//该索引在原始查询条件中的偏移指针

	stu_INDEXINQUERYCONDITION()
	{
		m_pCompareType		= NULL;
		m_pCompareOffset	= NULL;
	}

	void SetCond(BYTE* pCompareType, int* pCompareOffset)
	{
		m_pCompareType   = pCompareType;
		m_pCompareOffset = pCompareOffset;
	}

	void DeleteCond()
	{
		if(m_pCompareType != NULL)
		{
			*m_pCompareType = MF_CONDITION_INVALID;
		}
		if(m_pCompareOffset != NULL)
		{
			*m_pCompareOffset = 0;
		}
	}

}INDEXINQUERYCONDITION,*LPINDEXINQUERYCONDITION;


//子索引计划，由一个或多个子索引计划，最终组成一个完整的索引计划
typedef struct st_SUBINDEXPLAN
{
	//索引基本信息
	int							m_nIndexID;						  //索引ID
	BYTE						m_bFieldNo[4];				      //索引字段编号
	MF_SYS_INDEXTYPE			m_bIndexType;                     //索引类型
	BYTE						m_bFileNo;					      //文件编号
	MF_CONSTRAINT_TYPE			m_bConstraintType;		   		  //约束条件
	double						m_dblCostFactor;				  //成本系数(粗略值)
	long long					m_nScanScope;					  //扫描范围(精确值)
	LPINDEXINQUERYCONDITION		m_ppCondition[4];				  //索引条件数组
	LPINDEXINQUERYCONDITION		m_ppCondition2[4];				  //另一个索引条件数组(用于处理两个条件合成一个条件的情况)
	st_SUBINDEXPLAN*			m_lpNextPlan;					  //下一个子索引计划指针

	long long					m_lpParamPtr1;					  //参数1：用于表示B树索引中起始节点指针	
	long long					m_lpParamPtr2;					  //参数2：用于表示B树索引中起始节点元素指针	
	long long					m_lpParamPtr3;					  //参数3：用于表示B树索引中结束节点元素指针	
	long long					m_nParam4;						  //参数4：用于表示B树索引中起始关键字DataID(用于校验)
	long long					m_nParam5;						  //参数5：用于表示B树索引中结束关键字DataID(用于校验)
	
	void SetCondition(int nPos, LPINDEXINQUERYCONDITION lpCondition)
	{
		m_ppCondition[nPos] = lpCondition;
	}

	void SetCondition2(int nPos, LPINDEXINQUERYCONDITION lpCondition)
	{
		m_ppCondition2[nPos] = lpCondition;
	}

	void SetIndex(LPINDEXDEF lpIndex)
	{
		m_nIndexID    		= lpIndex->m_nIndexID;
		m_bIndexType  		= lpIndex->m_bIndexType;
		m_bFieldNo[0] 		= lpIndex->m_bFieldNo[0];
		m_bFieldNo[1] 		= lpIndex->m_bFieldNo[1];
		m_bFieldNo[2] 		= lpIndex->m_bFieldNo[2];
		m_bFieldNo[3] 		= lpIndex->m_bFieldNo[3];
		m_bConstraintType	= lpIndex->m_bConstraintType;
		m_bFileNo			= lpIndex->m_bFileNo;
	}

	void DeleteCond()
	{
		int i;
		for(i = 0; i < 4; i++)
		{
			if(m_ppCondition[i] != NULL)
			{
				m_ppCondition[i]->DeleteCond();
			}
			else
			{
				break;
			}
		}

		for(i = 0; i < 4; i++)
		{
			if(m_ppCondition2[i] != NULL)
			{
				m_ppCondition2[i]->DeleteCond();
			}
			else
			{
				break;
			}
		}
	}

}SUBINDEXPLAN, *LPSUBINDEXPLAN;

#pragma pack()

#define	LOGIC_OPERATOR BYTE
#define LOGIC_AND	   1
#define LOGIC_OR	   2
#define LOGIC_NOT	   3
class CIndexSelector
{	
public:
	CIndexSelector(CServiceBson* pServiceBson);
	~CIndexSelector(void);	
private:
	CServiceBson*				m_pServiceBson;			//Bson对象
	LPOBJECTDEF					m_lpObjectInfo;			//对象信息
	LPBASECONDITIONBSON			m_lpCondition;			//查询条件
	LPEXECUTEFIELDBSON			m_lpQueryField;			//查询字段

	CMemStack					m_skLogicOperator;		//逻辑运算符栈
	CMemStack					m_skIndexPlan;			//索引执行计划栈
	CMemStack					m_skTemPlan;			//索引执行计划栈

	long long					m_nTotalDataNum;		//全表数据量
	UINT						m_nIndexPlanOffset;		//索引偏移

	long long					m_nScanRowNum;			//扫描行数
	MF_QUERYPLAN_TYPE			m_bQueryPlanType;		//查询计划类型

	int							m_nLogicAndNum;			//连续的AND运算符的数量
	int							m_nLogicORNum;			//连续的OR运算符数量
	int							m_nLogicBeforNotNum;	//NOT弹栈前，栈中的条件个数
private:
	//反转运算符
	void ReverseOp(MF_EXECUTEPLAN_OPERATOR bOpSrc, MF_EXECUTEPLAN_OPERATOR& bOpDest);
	BOOL ReverseOp(MF_EXECUTEPLAN_OPERATOR bOp, MF_EXECUTEPLAN_OPERATOR& bOpDest, BYTE bLogicNot);
private:
	//结合OR运算符的索引条件
	int CombineORSubPlan(LPSUBINDEXPLAN lpSubIndexPlan1, LPSUBINDEXPLAN lpSubIndexPlan2, BYTE& bInvalidPlan);

	//结合AND运算符的索引条件
	int CombineANDSubPlan(LPSUBINDEXPLAN lpSubIndexPlan1, LPSUBINDEXPLAN lpSubIndexPlan2, BYTE& bInvalidPlan);

	//获取成本系数
	int GetCostFactor(LPSUBINDEXPLAN lpSubIndexPlan);

	//获取查找范围
	int GetScanScope(LPSUBINDEXPLAN lpSubIndexPlan);
private:
	//结合索引执行计划栈中的索引计划（执行计划栈中的条件由OR连接）
	int CombineIndexPlan();

	//从索引执行计划栈中选取最优执行计划（执行计划栈中的条件由AND连接）
	int GetOptimalIndexPlan();

	//选择同一字段上的最佳索引
	int GetOptimalIndexPlanFromSameField();

	//从比较表达式中获取索引
	int GetIndexFromCompareExpression(LPCOMPAREEXPBSON lpCompareExpression, BYTE* pCompareTypePtr, int* pCompareOffsetPtr);

	//获取条件索引
	int GetConditionIndex(LPBASECONDITIONBSON lpCondition);

	//将索引执行计划栈中的索引计划组织成最终的索引执行计划
	int CreateConditonIndex();

public:
	//清空
	inline void Clear()
	{
		m_nIndexPlanOffset	= 0;
		m_lpObjectInfo		= NULL;
		m_lpCondition		= NULL;
		m_lpQueryField		= NULL;
		m_nTotalDataNum	    = 0;

		m_skLogicOperator.Clear();
		m_skIndexPlan.Clear();
	}

	//初始化
	int Initial(LPOBJECTDEF lpObjectInfo, LPBASECONDITIONBSON lpCondition, LPEXECUTEFIELDBSON lpExecuteField);
	
	//获取查询索引
	int GetQueryIndex();

	//获取查询索引的偏移
	inline UINT GetIndexOffset()
	{
		return m_nIndexPlanOffset;
	}

	//获取索引扫描的行号
	inline long long GetRowNum()
	{
		return m_nScanRowNum;
	}

	//获取查询计划的类型
	inline MF_QUERYPLAN_TYPE GetQueryPlanType()
	{
		return m_bQueryPlanType;
	}
};
