﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "MemoryHashIndex.h"
/************************************************************************
	 整型哈希表
************************************************************************/

class CMemoryHashInt : public CMemoryHashIndex
{
private:
	#pragma pack(1)
	//索引项结构体
	typedef struct
	{
		long long	m_nNextOffset;										//冲突链表中的下一个索引项的偏移量，如果为0就表示该链表中只有一个元素
		long long   m_nDataID;											//数据ID(value)
		long long	m_nKey;												//关键字
	}INDEXSTRUCT,*LPINDEXSTRUCT;
	#pragma pack()
private:
	//防止此类被非法构造成对象或者复制
	CMemoryHashInt(const CMemoryHashInt&);
	CMemoryHashInt& operator = (const CMemoryHashInt&);

public:
	CMemoryHashInt();
	~CMemoryHashInt();	
	/************************************************************************
		功能说明：
			获取关键字值
	************************************************************************/
	virtual void GetKeyValue(LPVOID lpNodeData, VARDATA& varKey);

	/************************************************************************
		功能说明：
			获取关键字值
	************************************************************************/
	virtual long long GetDataIDFromNodeData(LPVOID lpNodeData);

	/************************************************************************
		功能说明：
			设置节点数据
	************************************************************************/
	virtual void SetNodeData(LPVOID lpNodeData, VARDATA &VarKey, long long nDataID);

	/************************************************************************
		功能说明：
			清空节点数据
	************************************************************************/
	virtual void ClearNodeData(LPVOID lpNodeData);

	/************************************************************************
		功能说明：
			计算Hash值
	************************************************************************/
	virtual DWORD CalcKeyHash(VARDATA& varKey, int nHashSize);

	/************************************************************************
		功能说明：
			判断关键字是否重复
	************************************************************************/
	virtual BOOL CheckKey(CServiceBson* pBson, VARDATA& varKey, BYTE bFieldNo, LPHASHNODE lpHashNode);
};