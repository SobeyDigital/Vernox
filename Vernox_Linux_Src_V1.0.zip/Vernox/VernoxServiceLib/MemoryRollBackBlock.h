﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "stdafx.h"
#include "TimestampManage.h"
#include "CommonAPI.h"
class CMemoryRollBackBlock
{
private:
	#pragma pack(1)
	//变长数据结构体，除放置数据以外，会额外开销20字节，一条数据可能存在多条变长数据，他们之间的关系使用m_nNextOffset来做串联，最后一个块的m_nNextOffset值为0。
	typedef struct 
	{
		int	m_nDataFlag;					//数据标志，目前定为‘SBBV’
		int m_nDataLength;					//变长数据长度，目前以32的倍数进行内存分配，以防止频繁分配导致无谓的开销
		int m_nActualLength;				//数据实际长度
		long long m_nPreRollbackDataID;	    //前一个回滚区数据ID
		long long m_nTimestamp;				//时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
		BYTE m_pDataContent[1];				//数据内容,首地址
	}ROLLBACKBLOCKVARDATASTRUCT, *LPROLLBACKBLOCKVARDATASTRUCT;

	//Block头，直接为块的开始位置存放的数据，描述块内数据信息
	typedef struct 
	{
		int		m_nDataFlag;						//数据标志，目前数据块为‘SBDB’
		int		m_nRollbackTotalSize;				//块大小
		int		m_nRollbackHeadSize;				//块头大小
		BYTE	m_bStatus;							//数据锁定状态，一般修改单条数据不需要整块锁，但如果整块进行整理时就必须进行锁定，防止其他读取或者修改操作出现错乱
		BYTE    m_bSaveFlag;                        //数据库保存标志，防止单纯按照时间戳判断出现误判
		BYTE	m_bReserved;						//保留数据
		int		m_nVarDataInsertPos;				//变长数据插入位置偏移
		UINT    m_nPreTimestamp;					//时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
		UINT    m_nStartTimestamp;					//时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
		UINT    m_nCurTimestamp;					//时间戳，用于事务或者文件块是否需要从内存写入文件的判断标志
	}ROLLBACKBLOCKHEAD, *LPROLLBACKBLOCKHEAD;
	#pragma pack()
protected:
	CRITICAL_SECTION	m_CritRollbackBlock;		//回滚区临界区，用于写入的操作

private:
	LPBYTE m_pBlockAddr;							//块指针(由构造函数进行初始化)
	LPBYTE m_pBlockBody;							//块体指针m_pBlockBody = m_pBlockAddr + BLOCKHEAD.m_nBlockHeadSize
	LPROLLBACKBLOCKHEAD m_pBlockHead;				//块头指针(m_pBlockHead = (LPBLOCKHEAD*)m_pBlockAddr)

private:
	//防止此类被非法构造成对象或者复制
	CMemoryRollBackBlock(const CMemoryRollBackBlock&);
	CMemoryRollBackBlock& operator = (const CMemoryRollBackBlock&);

	/************************************************************************
		功能说明：
			在内存空间中分配一个变长数据空间(在插入一条新数据的时候使用)
	************************************************************************/
	virtual LPBYTE AllocBlockNewData(int nSize, UINT& nTimestamp,  int &nVarDataOffset);

	/************************************************************************
		功能说明：
			创建一个内存块，并初始化m_pBlockAddr、m_pBlockHead成员变量
	************************************************************************/
	void InitialBlock(int nBlockSize);

	UINT TimestampToSecondNum(long long nTimestamp);

public:
	CMemoryRollBackBlock(int nSize);
	//析构函数
	~CMemoryRollBackBlock(void);

public:

	/************************************************************************
		功能说明：
			将数据写入回滚区
	************************************************************************/
	long long InsertRollBackData(LPBYTE& lpData, int nLen, long long nTimestamp, long long nPreRollbackDataID);
	
	/************************************************************************
		功能说明：
			从回滚区中读取数据
	************************************************************************/
	int GetRollBackData(long long nRollBackVarDataID, long long nTimestamp, LPBYTE &lpVarDataAddr, int &nLen );

	/************************************************************************
		功能说明：
			判断回滚区数据是否合法
	************************************************************************/
	BOOL CheckDataVaild(long long nRollBackVarDataID, long long nTimestamp);
};
