﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "BaseMemObject.h"
class CMemoryFile;
class CInsertBson;
class CCommonMemObject:public CBaseMemObject
{
protected:
	//索引相关操作
	int  InsertIndex(LPINDEXINFO lpIndexInfo, int nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);
	int  DeleteIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);
	int  UpdateIndex(LPINDEXINFO lpIndexInfo, int nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);

protected:
	int  LockBlock(CServiceBson& stBson, LPOBJECTDEF lpObjectInfo, long long& nDataID);

protected:
	int  GetDataNum(LPEXECUTEPLANBSON lpExecutePlan, LPOBJECTDEF lpObjectInfo, LPTRANSACTIONARRAY lpTransactionArray, int& nDataNum);
	int  GetDataIDByIndex(CServiceBson& stBson, LPQUERYINFO lpQueryInfo, CDataIDContainer* pDataIDContainer);
	int	 GetDataIDDriect(CServiceBson& stBson, LPQUERYINFO lpQueryInfo, CDataIDContainer* pDataIDContainer);

protected:
	virtual int ExecuteInsertData(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep);
	virtual int	ExecuteDeleteData(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep);
	virtual int	ExecuteUpdateData(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep);

	int  ExecuteInsertIndex(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep);
	int  ExecuteDeleteIndex(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep);
	int  ExecuteUpdateInsertIndex(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep);
	int  ExecuteUpdateDeleteIndex(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep);
protected:
	virtual int ExecuteStep(CServiceBson& stBson, LPVOID lpParam, LPEXECUTESTEP lpStep, int &lAffectCount);
	virtual int StepRollBack(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPOBJECTDEF lpObjectInfo);

protected:
	virtual int PreprocessInsert(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual int PreprocessDelete(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual int PreprocessUpdate(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual int PreprocessUpdateRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager);

protected:
	virtual int GetDataIDByPage(CServiceBson& stBson, LPQUERYINFO lpQuertInfo, CDataIDContainer* pDataIDContainer, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual int GetRecordDataID(CServiceBson& stBson, LPQUERYINFO lpQuertInfo, CDataIDContainer* pDataIDContainer, LPEXECUTESTATISTICSINFO lpExecuteInfo);

protected:
	int  Insert(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int  Update(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int  Delete(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);

public:
	CCommonMemObject(void);
	virtual ~CCommonMemObject(void);

public:
	int	 IndexRebuild(CServiceBson& stBson, int nObjectID, LPINDEXDEFBSON lpIndexBson);

public:
	virtual int	 ExportObject(CServiceBson& stBson, char* pObjectName, LPEXPORTPARAM lpExportParam, long long nTimestamp);
	virtual int	 ImportObject(CServiceBson& stBson, char* pObjectName, LPIMPORTPARAM lpImportParam, long long nTimestamp);

public:
	virtual int  Release();
	virtual void CriticalRelease(CServiceBson& stBson);
	virtual int  GetRecordNum(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int& nRecordNum,  LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual int  Preprocess(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual int  ResourceRelease(CServiceBson& stBson, int nRetValue, CExecutePlanManager& stExecutePlanManager);															
	virtual int  ExecuteCommand(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual int  GetRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	virtual int  UpdateRecordset(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
public:
	virtual int  Recover(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
};
