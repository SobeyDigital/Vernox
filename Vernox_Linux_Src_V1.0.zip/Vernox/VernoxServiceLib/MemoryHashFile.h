﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
/************************************************************************
	文件类

	总体介绍：
	KV索引分为两级来实现:文件级、索引级，该类属于文件级

	KV索引和数字索引相同都需要支持256种不同类型数据
	(注意：这里指的是256种不同数据的类型即不同的Object，然后要为不同的数据建立索引，而不是索引的类型有256种,KV索引的类型只有两种)
	这里需要将为这256种不同类型的数据建立的索引放入一个内存映射文件
	(原因：如果一个内存映射文件只存放1种类型数据的索引那么内存映射文件会很多，并且同一个数据可能会建立两种类型的索引，所以管理上会很复杂)
	
	一、内存的管理方式
	为了将相同IndexID的索引项存放在相对集中的区域，在构建KV索引的时候，还是需要内存映射文件、内存块、索引项，三种结构，而对于内存块，会存放两种数据：索引项和哈希表
	文件级负责对索引块的管理，包括给索引级分配内存块、从索引级回收内存块(或回收存放哈希表的内存块)、维护空闲内存区链表
	索引级负责管理从文件级获取的内存块。具体的实现如下：
	1.当向内存映射文件中插入一个新的Hash表时，文件级分配一个内存块，然后将Hash表头写入内存
	2.当向一个空的Hash表中插入一条索引项时，首先由文件级分配一块内存块给索引级，然后索引级根据Hash函数计算出该索引项所属的HashNode，最后将索引项插入内存，并将其索引项“挂”在HashNode上
	3.文件级分配给索引级的内存块，由索引级自行管理，当内存块满时，索引级向文件级再申请一个内存块，作为当前使用的内存块
	4.当删除一条索引项时就会留下一段空的内存空间，由于索引项的结构体中包含了一个m_nNextOffset,所以可以利用该结构很方便的建立空索引项栈(先进后出)具体实现步骤如下:
	  (1)在Hash头记录空闲索引栈的首地址m_nIndexFreePos(初始化为0，表示没有空闲索引块)
	  (2)当第一次删除索引项时将m_nIndexFreePos设置为该索引项相对于内存块的偏移量
	  (3)利用“插头法”来形成空块链表栈
	  (4)当插入一条新的索引项时,利用m_nIndexFreePos空索引栈是否有空块可以分配，如果有就执行“弹栈”操作，否则从索引级管理的当前内存块中分配一个空索引项，
		 如果当前内存块满就调用文件级的内存分配函数，从空闲区中分配一个内存块(文件级的AllocMemory函数会返回空内存块相对于文件头的偏移量，用这个偏移量+文件指针就可以得到该处的指针，然后直接插入索引项即可)
	  (5)由于空闲索引栈会存放所有内存块中空闲的索引位置，所以不支持以块为单位的内存回收
	  (6)当哈希表中所有的索引项被清空后，将调用文件级的DeAllocMemory函数回收内存块

	特别说明:虽然内存管理中提供了块的概念，但是块只是为了方便索引集中和内存回收提供的一种结构，在进行检索时，是通过Hash()函数根据key值直接定位数据ID的实际地址，和块无关

	二、索引级

	在哈希表级提供一个哈希结点(HashNode)的概念，一张哈希表是由若干个HashNode组成，一个HashNode链接着所有Hash值相同的索引项
	一个Object对应一张哈希表，哈希表负责完成以下功能：
	1.定位索引项(主要功能)
	  说明：结点的概念和redis的桶是一个概念
	  (1)HashNode的定位是直接根据关键字key通过Hash函数计算得到的(实际哈希函数返回的是HashNode相对于Hash头的偏移量，注意是结点头不是文件头)
	  (2)在HashNode中会存放索引项相对于内存文件首地址的偏移量，所以找到HashNode之后就可以直接定位到索引项了

	2.记录索引项链表长度
	  由于对于哈希表的冲突处理采用Separate chaining(拉链法)方法解决，所以相同Hash值的索引项会被挂在同一个HashNode上，那么需要记录这个链表的长度，
	  在特定的时候进行rehash

    
	这里需要特别注意两个偏移量的概念：根据key和Hash函数计算出的是HashNode的偏移量，这个偏移量是相对于Hash头的，这个值相当于一个虚拟地址
	而HashNode中存放的偏移量是索引项的相对于文件头的偏移量，这个值相当于是一个实际地址

	3.空闲区管理(见一)
	  

	三、文件级
	在文件级主要完成以下主要功能。
	1.完成IndexID向Hash表的映射
	  在文件级维护一张IndexID到Hash表的映射表，将为不同类型数据创建的KV索引和对应的Hash表对应起来
	  (采用256个元素的数组，数组中每个数据项包含一个IndexID和一个HashNode头相对于文件头的偏移量)

	2.完成从空闲区中分配内存(向哈希表级提供一个内存分配函数供其调用)
	  
	3.rehash
	  这是文件级的一个十分重要的操作，当hash表的冲突率或者索引项达到一定数目时，需要将哈希表进行扩张
	  扩张的实质就是将原来的Hash表迁移到一个容量更大的Hash表中
	  具体步骤如下：
	  (1)首先从内存的空闲区申请一块内存作为新的Hash表(reHashTable),reHashTable的容量需要是原HashTable的整数倍
	  (2)然后开始渐进式迁移，所谓渐进式迁移，就是并非一次性把HashTable中的所有节点都迁移到reHashTable中,因为这样会非常耗时。
		 渐进式迁移的策略是在每次进行索引的添加、删除查找时，从HashTable中的第一个结点开始，每次将一个结点中的所有索引项迁移到reHashTable中
		 而进行插入操作时，就直接将新的索引项加入reHashTable中。注意，当从HashTable中迁移完一个结点后，并不将此结点的m_nIndexOffset设置为0，
		 这样做的目的是在数据迁移完成之前，还是可以通过HashTable查找到大部分索引项(而如果要对新加入的索引项进行查找，就必须到reHashTable中去查找了)
	  (3)当HashTable中的所有索引项全部迁移到reHashTable中后，会释放HashTable，并将这部分空间加入到空闲区(这个空闲区之后可以分配给索引项或HashTable),
	     然后将reHashTable作为HashTable(在ROOT结构体中修改对应项的偏移)

     4.维护空闲区链表(见一)
	   在映射文件中会存在一个空闲区，然后在rehash完成后又会释放出新的空闲区，所以在文件级还需要将这些空闲区练成一个链表，
	   在链表头记录空闲区的大小和下一块空闲区的位置
		
************************************************************************/
class CMemoryHashFile : public CBaseMemoryFile
{
private:
	#pragma pack(1)
	/************************************************************************
		在文件头中维护一个ROOT数组，完成不同的Object到哈希表的映射
	************************************************************************/
	typedef struct
	{
		int		m_nIndexID;											//Index标识
		int		m_nBlockNo;											//哈希表编号
	}ROOT,*LPROOT;

	//文件头(需要写入内存)
	typedef struct
	{
		int		m_nDataFlag;										//数据标志，目前定为‘SBMF’
		long long m_nTimestamp;										//文件保存的时间戳
		BYTE	m_bFileNo;											//文件编号
		BYTE	m_bStatus;											//内存文件数据锁定状态
		USHORT	m_usDatabaseGuid;									//数据库唯一标识
		long long m_nFileTotalSize;									//文件总大小
		int		m_nFileHeaderSize;									//文件头大小
		int		m_nBlockNum;										//块个数
		int		m_nBlockMapStructSize;								//块地址映射表中表项的长度，实际为FILEBLOCKMAP结构体大小
		int		m_nBlockMapStartOffset;								//指向第一个FILEBLOCKMAP结构体的地址
		long long m_nBlockStartOffset;								//块的起始地址
		BASEFILEOBJECTDEF m_stFileObjectData[MAX_OBJECT_NUM];		//文件对象数据表

		int			m_nInnerMaxNo;									//块编号最大值，用于插入时
		long long	m_nFileFreeSize;								//空闲区大小
		long long	m_nFileFreeMemoryOffset;						//空闲空间首地址	
		long long	m_nFreeBlockMapOffset;							//对象删除等回收的BLOCK块的映射结点偏移地址
		long long	m_nBlockMapSize;								//块映射表大小
		int			m_nMaxBlockMapNum;								//块映射表中所能容纳的最大数据数量
		ROOT		m_stRootMap[MAX_OBJECT_NUM];					//不同Object索引的入口地址数组
	}FILEHEAD,*LPFILEHEAD;
	#pragma pack()
private:
	LPBYTE	   m_lpFileAddr;										//Hash文件头
	LPFILEHEAD m_lpMemoryFileHead;									//文件头m_lpFileHead = (LPFILEHEAD)m_pHashFile
	LPBASEFILEBLOCKMAPHEAD m_lpBlockMapTail;						//文件块映射链表尾
	CMapSimple m_mapIndex;
private:
	//防止此类被非法构造成对象或者复制
	CMemoryHashFile(const CMemoryHashFile&);
	CMemoryHashFile& operator = (const CMemoryHashFile&);

private:
	/************************************************************************
		功能说明：
			初始化哈希文件管理类，让整个实例是可执行的
	************************************************************************/
	int SetFileAddr(LPBYTE lpFileAddr);

	/************************************************************************
		功能说明：
			根据块号获得块在内存中的实际地址
	************************************************************************/
	LPBYTE ConvertBlockNotoAddr(int nBlockNo);

	/************************************************************************
		功能说明：
			从空闲区队列中分配一块内存空间
	************************************************************************/
	int AllocBlock(LPEXECUTEPLANBSON lpExecutePlan, int& nBlockNo, int nObjdectID, int nBlockSize, long long nTimestamp);

	/************************************************************************
		功能说明：
			释放内存块(清空),并把块号添加到空块队列中
	************************************************************************/
	int FreeBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo, long long nTimestamp);

	/************************************************************************
		功能说明：
			修改根结点
	************************************************************************/
	int RootUpdate(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nBlockNo);

	/************************************************************************
		功能说明：
			删除根结点
	************************************************************************/
	int RootDelete(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID);

	/************************************************************************
		功能说明：
			获得根节点
	************************************************************************/
	int GetRootNo(LPEXECUTEPLANBSON lpExecutePlan, int& nRootNo, int nIndexID);
	
	/************************************************************************
		功能说明：
			初始化块头基础信息
	************************************************************************/
	int InitialBlock(int nBlockNo, int nBlockSize, long long nTimestamp);

	/************************************************************************
		功能说明：
			初始化哈希表头
	************************************************************************/
	int InitialHashBlock(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nKeyLen);
public:
	CMemoryHashFile();
	~CMemoryHashFile();
	
	friend class CMemoryHashIndex;								//友元类
public:
	/************************************************************************
		功能说明：
			获取Hash索引节点大小
	************************************************************************/
	int GetHashIndexNodeSize(BYTE bFieldType, BYTE bDataLen);

	/************************************************************************
		功能说明：
			获取HB树根节点DataID
	************************************************************************/
	int GetHBTreeRoot(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, long long& nDataID);

	/************************************************************************
		功能说明：
			设置HB树根节点DataID
	************************************************************************/
	int SetHBTreeRoot(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, long long nDataID);

	/************************************************************************
		功能说明：
			创建根节点
	************************************************************************/
	int CreateRoot(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nHashNodeSize, int& nRootNo, long long nTimestamp);

	/************************************************************************
		功能说明：
			根据key值在索引块中插入一个新的索引项
	************************************************************************/
	int InsertIndex(LPINDEXINFO lpIndexInfo, int nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);
	
	/************************************************************************
		功能说明：
			根据key值在索引块中删除一条索引项
	************************************************************************/
	int DeleteIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);

	/************************************************************************
		功能说明：
			根据key值在索引块中更新一条索引项
	************************************************************************/
	int UpdateIndex(LPINDEXINFO lpIndexInfo, int nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp);
	
	/************************************************************************
		功能说明：
			根据关键字，获取数据ID
	************************************************************************/
	int GetDataID(LPINDEXINFO lpIndexInfo, CDataIDContainer* pDataIDContainer);
	
	/************************************************************************
		功能说明：
			为某字段创建索引
	************************************************************************/	
	int CreateIndex(CServiceBson& stBson, int nObjectID, int nIndexID, BYTE bFieldNo);

	/************************************************************************
		功能说明：
			删除索引
	************************************************************************/
	int DropObject(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID);

	/************************************************************************
		功能说明：
			获取文件大小信息
	************************************************************************/
	int GetFileSpace(LPEXECUTEPLANBSON lpExecutePlan, long long &nFileTotalSize, long long &nFileUseSize, long long &nFileFreeSize);

	/************************************************************************
		功能说明：
			设置索引数据
	************************************************************************/
	void SetObjectData(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, long long nDataNum = 0);

	/************************************************************************
		功能说明:
			获取文件头
	************************************************************************/
	virtual LPBASEFILEHEAD GetFileHead()
	{
		return (LPBASEFILEHEAD)m_lpMemoryFileHead;
	}

	/************************************************************************
		功能说明：
			修改时间戳
	************************************************************************/
	void TimestampUpdate(LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
	{
		//根据块的指针判断块的类型(存放哈希表的块还是存放索引项的块)
		CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeFileCritical(), lpExecutePlan);
		if(m_lpMemoryFileHead->m_nTimestamp < nTimestamp)
		{
			m_lpMemoryFileHead->m_nTimestamp = nTimestamp;
		}
	}

	/************************************************************************
		功能说明：
			备份文件数据
	************************************************************************/
	int BackUpFileData(LPBYTE lpBuffer, int nBufferSize);
};