﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryFile.h"
#include "MemoryBTreeFile.h"
#include "MemoryMultiNum.h"
#include "MemoryMultiKeyBlock.h"
#include "MemoryMultiStr.h"
#include "Expression.h"
#include "Check.h"

#define MIN_KEY_LEN			8		//最小关键字长度
#define MAX_ARRAY_SIZE		1010	//数组最大长度
#define FREEBLOCK_THRESHOLD 0.1		//可插块阈值
#define MAX_FREELINK_LEN	16		//可插块链表最大长度
CMemoryBTreeFile::CMemoryBTreeFile(void)
{
	
}


CMemoryBTreeFile::~CMemoryBTreeFile(void)
{
	m_stIndexMap.Clear();
}

/************************************************************************
		功能说明：
			从满块或空块链表上获取一个块对象
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			lpLinkInfo：链表信息
			lpBlockAddr：块指针
************************************************************************/
int CMemoryBTreeFile::GetBlockFromLink(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, LPLINKINFO lpLinkInfo, LPBYTE& lpBlockAddr)
{
	int nRet;
	LPBASEFILEBLOCKMAP lpBlockMap;
	LPBASEFILEOBJECTDEF lpIndexDef;

	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeFileBlockMapCritical(), lpExecutePlan);
	nRet = GetIndexDataDef(lpExecutePlan, nIndexID, lpIndexDef);											
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	if(lpLinkInfo->m_bStart)
	{
		lpLinkInfo->m_bStart = FALSE;
		if(lpLinkInfo->m_bLikType == FREE_LINK)
		{
			lpLinkInfo->m_nBlockMapOffset = lpIndexDef->m_nFreeBlockMapOffset;
		}
		else if(lpLinkInfo->m_bLikType == FULL_LINK)
		{
			lpLinkInfo->m_nBlockMapOffset = lpIndexDef->m_nFullBlockMapOffset;
		}

		if(lpLinkInfo->m_nBlockMapOffset == 0)
		{
			lpBlockAddr = NULL;
			return MF_OK;
		}
	}
	else if(lpLinkInfo->m_nBlockMapOffset == 0)
	{
		lpBlockAddr = NULL;
		return MF_OK;
	}

	lpBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + lpLinkInfo->m_nBlockMapOffset);
	lpLinkInfo->m_nBlockNo = lpBlockMap->m_nBlockNo;
	lpBlockAddr = (LPBYTE)m_stIndexMap.Get(lpBlockMap->m_nBlockNo);
	if(lpBlockAddr == NULL)
	{
		return MF_MEMORYFILE_INSERTDATA_INVALIDMEMORYMAP_ERROR;
	}
	lpLinkInfo->m_nBlockMapOffset = lpBlockMap->m_nNextOffset;
	return MF_OK;
}

/************************************************************************
	功能说明：	
		获取字符串复合关键字的大小
	参数说明：
		lpMultiIndex：复合索引
************************************************************************/
int CMemoryBTreeFile::GetStrMultiKeySize(LPMULTIINDEX lpMultiIndex)
{
	int i, nLen;
	LPINDEXCONDITION lpIndexField;

	//分配字符串长度+4个字节存放0
	nLen = lpMultiIndex->m_lpIndexCondition[0].m_varCondition2.m_nStrLen + 4;
	
	//分配空间存放字符串信息
	nLen += sizeof(KEYINFO);

	//遍历索引字段获取关键字总大小
	for(i = 1; i < (int)lpMultiIndex->m_nIndexNum; i++)
	{
		lpIndexField = &lpMultiIndex->m_lpIndexCondition[i];
		if(lpIndexField->m_varCondition2.m_vt == MF_VARDATA_INT)
		{
			nLen += sizeof(int);
		}
		else if(lpIndexField->m_varCondition2.m_vt == MF_VARDATA_INT64)
		{
			nLen += sizeof(long long);
		}	
		else if(lpIndexField->m_varCondition2.m_vt == MF_VARDATA_DOUBLE || lpIndexField->m_varCondition2.m_vt == MF_VARDATA_DATE)
		{
			nLen += sizeof(double);
		}
		else
		{
			int i, n;
			BOOL bMidFlag;
			//分配空间存放字符串长度
			nLen += sizeof(int);

			//分配空间存放字符串
			nLen += lpIndexField->m_varCondition2.m_nStrLen;
			
			//分配空间存放字符串后缀数组
			for(i = 0, n = 0; i < lpIndexField->m_varCondition2.m_nStrLen - 1; i++)
			{
				//去掉UTF8的中间字符
				bMidFlag = (*(lpIndexField->m_varCondition2.m_lpszValue + i))&0XC0;
				if(bMidFlag != 0X80)
				{
					n++;
				}
			}
			nLen += sizeof(int);
			nLen += n*sizeof(int);
		}
	}

	nLen = (nLen / MIN_KEY_LEN + 1) * 8;
	return nLen;
}

/************************************************************************
		功能说明：
			获取数据区的入口地址
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			lpIndexData：数据区入口地址信息
************************************************************************/
int CMemoryBTreeFile::GetIndexDataDef(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, LPBASEFILEOBJECTDEF& lpIndexDef)
{
	int nPos;	

	//遍历FILEOBJECTDEF数组，找到nObjectID所对应的FILEOBJECTDEF结构体
	for(nPos = 0; nPos < MAX_OBJECT_NUM; nPos++)
	{
		if(m_lpMemoryFileHead->m_stFileObjectData[nPos].m_nID == 0)
		{
			//如果数组中IndexID为0，则说明数组后面所有元素的IndexID都为0，遍历完毕
			m_lpMemoryFileHead->m_stFileObjectData[nPos].m_nID = nIndexID;
			m_lpMemoryFileHead->m_stFileObjectData[nPos].m_nFreeBlockMapOffset = 0;
			m_lpMemoryFileHead->m_stFileObjectData[nPos].m_nFullBlockMapOffset = 0;
			lpIndexDef = &m_lpMemoryFileHead->m_stFileObjectData[nPos];
			break;
		}
		else if(nIndexID == m_lpMemoryFileHead->m_stFileObjectData[nPos].m_nID)
		{
			lpIndexDef = &m_lpMemoryFileHead->m_stFileObjectData[nPos];
			break;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		将关键字写入数据块
	参数说明：
		lpIndexInfo：索引信息
		lpExecutePlan：执行计划
		nTimestamp：时间戳
***********************************************************************/
int CMemoryBTreeFile::InsertKey(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{	
	LINKINFO stLinkInfo;
	LPBYTE lpBlockAddr, lpKeyAddr;
	int nRet, nBlockNo, nKeySize, nIndex;
	CMemoryMultiKeyBlock stMultiKeyBlock;
	long long nBlockMapOffset, llKeyOffset;
	
	stMultiKeyBlock.SetBlockAddr(this, NULL);
	nKeySize  = (int)lpIndexInfo->m_nParam4;
	//1.遍历块回收映射表，判断块回收映射表中是否有足够的空间插入数据
	nRet = GetRecycleBlockNo(lpExecutePlan, lpIndexInfo->m_nIndexID, nBlockNo);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(nBlockNo != 0)
	{
		nIndex	= nKeySize / MIN_KEY_LEN;
		if(nIndex > MAX_ARRAY_SIZE)
		{
			nIndex = MAX_ARRAY_SIZE;
			nRet = GetBufferFromRecycleMap(nBlockNo, nKeySize, nIndex, llKeyOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(llKeyOffset != 0)
			{	
				//将关键字写入
				lpKeyAddr = (LPBYTE)ConvertOffsettoAddr(llKeyOffset);
				nRet = stMultiKeyBlock.WriteData(lpKeyAddr, &lpIndexInfo->m_stMultiIndex, nKeySize, llKeyOffset, lpIndexInfo->m_nDataID);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_llValue = llKeyOffset + 1;
				return MF_OK;
			}
		}
		else
		{	
			
			nRet = GetBufferFromRecycleMap(nBlockNo, nKeySize, nIndex, llKeyOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(llKeyOffset != 0)
			{	
				//将关键字写入
				lpKeyAddr = (LPBYTE)ConvertOffsettoAddr(llKeyOffset);
				nRet = stMultiKeyBlock.WriteData(lpKeyAddr, &lpIndexInfo->m_stMultiIndex, nKeySize, llKeyOffset, lpIndexInfo->m_nDataID);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_llValue = llKeyOffset + 1;
				return MF_OK;
			}
			
			//访问下一个槽位
			nIndex++;
			nRet = GetBufferFromRecycleMap(nBlockNo, nKeySize, nIndex, llKeyOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(llKeyOffset != 0)
			{	
				//将关键字写入
				lpKeyAddr = (LPBYTE)ConvertOffsettoAddr(llKeyOffset);
				nRet = stMultiKeyBlock.WriteData(lpKeyAddr, &lpIndexInfo->m_stMultiIndex, nKeySize, llKeyOffset, lpIndexInfo->m_nDataID);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_llValue = llKeyOffset + 1;
				return MF_OK;
			}
		}
	}
	
	//2.遍历该Index的可插链表，得到链表中某可插块的指针
	memset(&stLinkInfo, 0, sizeof(LINKINFO));
	stLinkInfo.m_bLikType	= FREE_LINK;
	stLinkInfo.m_bStart		= TRUE;
	lpBlockAddr				= NULL;
	while(TRUE)
	{
		nRet = GetBlockFromLink(lpExecutePlan, lpIndexInfo->m_nIndexID, &stLinkInfo, lpBlockAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpBlockAddr == NULL)
		{
			break;
		}
	
		stMultiKeyBlock.SetBlockAddr(this, lpBlockAddr);
		if(!stMultiKeyBlock.IsFull(nKeySize))						
		{
			//如果块未满，则执行插入操作
			nRet = stMultiKeyBlock.InsertKey(lpExecutePlan, lpIndexInfo, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
	
			if(stMultiKeyBlock.RaitoStat() <= FREEBLOCK_THRESHOLD)
			{
				//如果比例<FREEBLOCK_THRESHOLD，就把块映射表结点从可插链表移动到满块链表中
				nRet = MoveMapStruct(lpExecutePlan, lpIndexInfo->m_nIndexID, stLinkInfo.m_nBlockNo, FREE_LINK);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
			m_lpMemoryFileHead->m_nTimestamp = nTimestamp;
			return MF_OK;
		}
	}

	//3.如果循环结束，则表明可插链表中没有足够的空间进行插入，那么从空闲区分配一块内存空间进行插入
	nRet = AllocBlock(lpExecutePlan, nBlockNo, nBlockMapOffset, DEF_KEYBLOCK_SIZE, nTimestamp);							
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpBlockAddr = ConvertBlockNotoAddr(nBlockNo);
	if(lpBlockAddr == NULL)
	{
		return MF_BTREEINDEX_INVALIDNODENO_ERROR;
	}

	stMultiKeyBlock.SetBlockAddr(this, lpBlockAddr);
	stMultiKeyBlock.InitialBlock(lpIndexInfo->m_nIndexID);
	nRet = stMultiKeyBlock.InsertKey(lpExecutePlan, lpIndexInfo, nTimestamp);		//用块指针调用块级别的Insert操作进行插入操作
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//插入成功，则计算插入后块空闲区的大小和块总大小的比例
	if(stMultiKeyBlock.RaitoStat() <= FREEBLOCK_THRESHOLD)
	{
		//将该块插入到满块链表(插头法)
		nRet = InsertMapStruct(lpExecutePlan, lpIndexInfo->m_nIndexID, FULL_LINK, nBlockMapOffset);	
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		//将该块插入到可插块链表(插头法)
		nRet = InsertMapStruct(lpExecutePlan, lpIndexInfo->m_nIndexID, FREE_LINK, nBlockMapOffset);	
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	TimestampUpdate(lpExecutePlan, nTimestamp);
	return MF_OK;
}

/************************************************************************
		功能说明：
			将一个映射表结点插入一个链表(头插法)
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			bLinkType：链表类型
			nBlockMapOffset：块映射表偏移
************************************************************************/
int CMemoryBTreeFile::InsertMapStruct(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, LINK_TYPE bLinkType, long long nBlockMapOffset)
{
	int nRet;
	UINT nOffset;
	BYTE bFreeLinkLen;
	LPBYTE lpBlockAddr;
	long long *pNextOffset;
	LPBASEFILEOBJECTDEF lpIndexDef;
	CMemoryMultiKeyBlock stMultiKeyBlock;
	LPBASEFILEBLOCKMAP lpBlockMap, lpPreBlockMap;

	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeFileBlockMapCritical(), lpExecutePlan);
	nRet = GetIndexDataDef(lpExecutePlan, nIndexID, lpIndexDef);										
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nBlockMapOffset);
	lpBlockMap->m_nNextOffset = 0;

	if(bLinkType == FREE_LINK)
	{	
		//用插尾法将结点插入链表
		bFreeLinkLen  = 0;
		nOffset		  = lpIndexDef->m_nFreeBlockMapOffset;
		pNextOffset   = &lpIndexDef->m_nFreeBlockMapOffset;
		lpPreBlockMap = NULL;

		while(nOffset)
		{
			lpBlockMap	= (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nOffset);
			nOffset		= lpBlockMap->m_nNextOffset;
			pNextOffset = &lpBlockMap->m_nNextOffset;
			bFreeLinkLen++;
		}
		*pNextOffset= nBlockMapOffset;

		if(bFreeLinkLen > MAX_FREELINK_LEN)
		{
			nOffset = lpIndexDef->m_nFreeBlockMapOffset;
			while(nOffset)
			{
				lpBlockMap	= (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nOffset);
				lpBlockAddr = ConvertBlockNotoAddr(lpBlockMap->m_nBlockNo);
				stMultiKeyBlock.SetBlockAddr(this, lpBlockAddr);
				if(stMultiKeyBlock.RaitoStat() < FREEBLOCK_THRESHOLD*2)
				{
					//从空块链表中删除
					if(lpPreBlockMap == NULL)
					{
						lpIndexDef->m_nFreeBlockMapOffset = lpBlockMap->m_nNextOffset;
					}
					else
					{
						lpPreBlockMap->m_nNextOffset		= lpBlockMap->m_nNextOffset;
					}

					//插入满块链表
					nOffset								= lpBlockMap->m_nNextOffset;
					lpBlockMap->m_nNextOffset		    = lpIndexDef->m_nFullBlockMapOffset;
					lpIndexDef->m_nFullBlockMapOffset   = nBlockMapOffset;
				}
				else
				{
					nOffset		  = lpBlockMap->m_nNextOffset;
					pNextOffset   = &lpBlockMap->m_nNextOffset;
					lpPreBlockMap = lpBlockMap;
				}
			}
		}
	
	}
	else if(bLinkType == FULL_LINK)
	{
		//用插头法将结点插入链表
		lpBlockMap->m_nNextOffset		  = lpIndexDef->m_nFullBlockMapOffset;
		lpIndexDef->m_nFullBlockMapOffset = nBlockMapOffset;
	}

	return MF_OK;
}

/************************************************************************
	功能说明：
		将一个映射表结点移动到满\空块链表
	参数说明：
		lpExecutePlan：执行计划
		nIndexID：索引ID
		nBlockNo：块编号
		bSrcLinkType：原始链表类型
************************************************************************/
int CMemoryBTreeFile::MoveMapStruct(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nBlockNo, LINK_TYPE bSrcLinkType)
{
	int nRet;
	LPBASEFILEOBJECTDEF lpFileObject;
	LPBASEFILEBLOCKMAP lpSrcBlockMap, lpPreBlockMap;
	long long nSrcOffset, nPreOffset, nDestOffset, *pSrcLinkHead, *pDestLinkHead;

	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeFileBlockMapCritical(), lpExecutePlan);
	nRet = GetIndexDataDef(lpExecutePlan, nIndexID, lpFileObject);										
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//1.获取块在原始节点中的位置
	if(bSrcLinkType == FREE_LINK)
	{
		nSrcOffset	  = lpFileObject->m_nFreeBlockMapOffset;
		nDestOffset	  = lpFileObject->m_nFullBlockMapOffset;

		pSrcLinkHead  = &lpFileObject->m_nFreeBlockMapOffset;
		pDestLinkHead = &lpFileObject->m_nFullBlockMapOffset;
	}
	else if(bSrcLinkType == FULL_LINK)
	{
		nSrcOffset	  = lpFileObject->m_nFullBlockMapOffset;
		nDestOffset   = lpFileObject->m_nFreeBlockMapOffset;

		pSrcLinkHead  = &lpFileObject->m_nFullBlockMapOffset;
		pDestLinkHead = &lpFileObject->m_nFreeBlockMapOffset;
	}
	if(0 == nSrcOffset)
	{
		return MF_BTREEINDEX_FINDMAPSTRUCT_INVALIDLIST_ERROR;			    
	}

	//遍历链表，寻找与nBlockNo相同的表项
	nPreOffset = nSrcOffset;
	while(nSrcOffset)
	{
		lpSrcBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nSrcOffset);
		if(lpSrcBlockMap->m_nBlockNo == nBlockNo)
		{
			break;
		}
		nPreOffset	= nSrcOffset;
		nSrcOffset	= lpSrcBlockMap->m_nNextOffset;
	}
	if(0 == nSrcOffset)
	{
		//未找到当前映射表结点
		return MF_BTREEINDEX_FINDMAPSTRUCT_NOBLOCKMATCH_ERROR;					
	}

	//2.将块从原始链表中删除
	lpPreBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nPreOffset);
	if(nSrcOffset == nPreOffset)
	{
		//表示该块号对应的映射表结点在链表的开始位置
		//将该内存块从链表中移除
		*pSrcLinkHead = lpSrcBlockMap->m_nNextOffset;
	}
	else if(0 == lpSrcBlockMap->m_nNextOffset)
	{
		//表示该块号对应的映射表结点在链表的最后位置
		//将该内存块从链表中移除
		lpPreBlockMap->m_nNextOffset = 0;
	}
	else
	{
		//表示该块号对应的映射表结点在满块链表的中间位置
		//将该内存块从链表中移除
		lpPreBlockMap->m_nNextOffset = lpSrcBlockMap->m_nNextOffset;
	}
	
	//3.将块插入目标链表
	lpSrcBlockMap->m_nNextOffset = *pDestLinkHead;
	*pDestLinkHead = nSrcOffset;

	return MF_OK;
}

/************************************************************************
		功能说明：
			从回收映射表中获取Buffer
		参数说明：
			nRecycleBlockNo：回收映射表块编号
			nBufferSize：Buffer长度
			nIndex：回收映射表数组下标
			nBufferOffset：Buffer偏移
************************************************************************/
int CMemoryBTreeFile::GetBufferFromRecycleMap(int nRecycleBlockNo, int nBufferSize, int nIndex, long long& nBufferOffset)
{
	LPBYTE lpBlockAddr, lpBuffer;
	long long *arrRecycleMap, nOffset;
	LPKEYBUFFERINFO lpKeyBufferInfo, lpPreKeyBufferInfo;

	nBufferOffset	= 0;
	lpBlockAddr		= ConvertBlockNotoAddr(nRecycleBlockNo);
	arrRecycleMap	= (long long*)(lpBlockAddr + ((LPBASEBLOCKHEAD)lpBlockAddr)->m_nBlockHeadSize);
	if(nIndex > MAX_ARRAY_SIZE)
	{
		lpPreKeyBufferInfo = NULL;
		nIndex  = MAX_ARRAY_SIZE;
		nOffset = arrRecycleMap[nIndex];
		
		//遍历链表获取一个块
		while(nOffset)
		{
			lpBuffer = (LPBYTE)ConvertOffsettoAddr(nOffset);;
			lpKeyBufferInfo	= (LPKEYBUFFERINFO)lpBuffer;
			if(lpKeyBufferInfo->m_bFlag != 1)
			{
				return MF_BTREEINDEX_RECYCLEBUFFERSIZE_ERROR;
			}
			if(lpKeyBufferInfo->m_nBufferSize >= nBufferSize)
			{
				//获取Buffer偏移
				nBufferOffset = nOffset;

				//将Buffer从链表中移除
				if(lpPreKeyBufferInfo == NULL)
				{
					arrRecycleMap[nIndex] = lpKeyBufferInfo->m_llNextOffset;
				}
				else
				{
					lpPreKeyBufferInfo->m_llNextOffset = lpKeyBufferInfo->m_llNextOffset;
				}
				lpKeyBufferInfo->m_nBufferSize  = nBufferSize;
				
				//将Buffer中大于nBufferSize的部分插入新的链表
				lpBuffer += nBufferSize;
				nOffset  += nBufferSize;

				nBufferSize = lpKeyBufferInfo->m_nBufferSize - nBufferSize; 
				lpKeyBufferInfo = (LPKEYBUFFERINFO)lpBuffer;
				lpKeyBufferInfo->m_bFlag = 1;
				lpKeyBufferInfo->m_nBufferSize = nBufferSize;

				nIndex = lpKeyBufferInfo->m_nBufferSize / MIN_KEY_LEN;
				if(nIndex > MAX_ARRAY_SIZE)
				{
					return MF_BTREEINDEX_RECYCLEBUFFERSIZE_ERROR;
				}
				else
				{
					lpKeyBufferInfo->m_llNextOffset = arrRecycleMap[nIndex];
					arrRecycleMap[nIndex] = nOffset;
				}
				return MF_OK;
			}
			lpPreKeyBufferInfo = lpKeyBufferInfo;
			nOffset = lpKeyBufferInfo->m_llNextOffset;
		}
	}
	else
	{
		nOffset = arrRecycleMap[nIndex];
		if(nOffset != 0)
		{
			lpBuffer = (LPBYTE)ConvertOffsettoAddr(nOffset);;
			lpKeyBufferInfo	= (LPKEYBUFFERINFO)lpBuffer;
			if(lpKeyBufferInfo->m_bFlag != 1)
			{
				return MF_BTREEINDEX_RECYCLEBUFFERSIZE_ERROR;
			}

			if(lpKeyBufferInfo->m_nBufferSize < nBufferSize)
			{
				return MF_BTREEINDEX_RECYCLEBUFFERSIZE_ERROR;
			}
			else
			{
				//获取Buffer偏移
				nBufferOffset = nOffset;
				
				//将Buffer从链表中移除
				arrRecycleMap[nIndex] = lpKeyBufferInfo->m_llNextOffset;

				//将Buffer中大于nBufferSize的部分插入新的链表
				if(lpKeyBufferInfo->m_nBufferSize > nBufferSize)
				{
					lpBuffer += nBufferSize;
					nOffset  += nBufferSize;

					nBufferSize = lpKeyBufferInfo->m_nBufferSize - nBufferSize; 
					lpKeyBufferInfo = (LPKEYBUFFERINFO)lpBuffer;
					lpKeyBufferInfo->m_bFlag = 1;
					lpKeyBufferInfo->m_nBufferSize = nBufferSize;
					
					nIndex = lpKeyBufferInfo->m_nBufferSize / MIN_KEY_LEN;
					if(nIndex > MAX_ARRAY_SIZE)
					{
						return MF_BTREEINDEX_RECYCLEBUFFERSIZE_ERROR;
					}
					else
					{
						lpKeyBufferInfo->m_llNextOffset = arrRecycleMap[nIndex];
						arrRecycleMap[nIndex] = nOffset;
					}
				}
				return MF_OK;
			}
		}
	}
	
	return MF_OK;
}

/************************************************************************
		功能说明：
			根据块号获得块在内存中的实际地址
		参数说明：
			nBlockNo:块号
		返回值说明：
			转换出来的地址，如果为NULL表示转换失败
************************************************************************/
LPBYTE CMemoryBTreeFile::ConvertBlockNotoAddr(int nBlockNo)
{
	LPBYTE pBlock;				
	if(nBlockNo == 0)
	{
		return NULL;
	}
	else
	{
		pBlock = (LPBYTE)m_stIndexMap.Get(nBlockNo);
		return pBlock;
	}
}

/************************************************************************
		功能说明：
			初始化索引文件管理类，让整个实例是可执行的
		参数说明：
			pFileAddr：内存文件数据块的首地址指针，需要记录在m_pFileAddr变量中
		特别说明：
			同时还需要把m_pMemoryFileHead成员变量也初始化出来，便于后续的写入和读取操作；
			注意，对于新内存文件是由另一个进程来实现的。
************************************************************************/
int CMemoryBTreeFile::SetFileAddr(LPBYTE lpFileAddr)
{
	LPBASEFILEBLOCKMAPHEAD lpBlockMapHead;
	int i, nBlockNo, nFileHeadSize, nBlockMapStructSize;
	long long nFileFreeSize, nBlockMapOffset, nBlockMapSize, nMaxBlockMapNum;

	m_lpFileAddr			= lpFileAddr;	
	m_lpMemoryFileHead		= (LPFILEHEAD)m_lpFileAddr;
	//判断映射表是否为空，如果不为空则遍历映射表创建CMap对象
	if(m_lpMemoryFileHead->m_nBlockMapStartOffset == 0)
	{
		nFileHeadSize		= (sizeof(FILEHEAD) / DEF_KEYBLOCK_SIZE + 1) * DEF_KEYBLOCK_SIZE;
		nBlockMapStructSize = sizeof(BASEFILEBLOCKMAP);
		nMaxBlockMapNum		= m_lpMemoryFileHead->m_nFileTotalSize - DEF_BTREEBLOCK_SIZE;
		nMaxBlockMapNum	    = nMaxBlockMapNum / DEF_BTREEBLOCK_SIZE;
		nBlockMapSize		= nMaxBlockMapNum * nBlockMapStructSize;
		nBlockMapSize		= ((sizeof(BASEFILEBLOCKMAPHEAD) + nBlockMapSize) / DEF_KEYBLOCK_SIZE + 1) * DEF_KEYBLOCK_SIZE;
		nFileFreeSize		= m_lpMemoryFileHead->m_nFileTotalSize - nFileHeadSize - nBlockMapSize * 2;

		lpBlockMapHead								= (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + nFileHeadSize);
		lpBlockMapHead->m_nBlockMapNum				= 0;
		lpBlockMapHead->m_nNextBlockMapOffset		= 0;
		m_lpBlockMapTail								= lpBlockMapHead;

		m_lpMemoryFileHead->m_nFreeBlockMapOffset	= 0;												
		m_lpMemoryFileHead->m_nBlockNum				= 0;
		m_lpMemoryFileHead->m_nInnerMaxNo			= 1;
		m_lpMemoryFileHead->m_nTimestamp			= GetSystemTimestamp();
		m_lpMemoryFileHead->m_nFileHeaderSize		= nFileHeadSize;
		m_lpMemoryFileHead->m_nBlockMapStructSize	= nBlockMapStructSize;
		m_lpMemoryFileHead->m_nFileFreeSize			= nFileFreeSize;
		m_lpMemoryFileHead->m_nBlockMapSize		    = nBlockMapSize;
		m_lpMemoryFileHead->m_nMaxBlockMapNum		= nMaxBlockMapNum;
		m_lpMemoryFileHead->m_nBlockMapStartOffset	= nFileHeadSize;
		m_lpMemoryFileHead->m_nFileFreeMemoryOffset	= nFileHeadSize + nBlockMapSize * 2;							
		m_lpMemoryFileHead->m_nBlockStartOffset		= nFileHeadSize + nBlockMapSize * 2;

		m_stIndexMap.Initialize(m_lpMemoryFileHead->m_nMaxBlockMapNum);
	}
	else
	{
	
		//遍历映射表创建CMap对象
		//注意：1.映射表表项的总个数=块的总个数 
		//		2.映射表表项按照块分配的先后顺序有序存放
		m_stIndexMap.Initialize(m_lpMemoryFileHead->m_nMaxBlockMapNum);
		nBlockMapOffset = m_lpMemoryFileHead->m_nBlockMapStartOffset;
		while(nBlockMapOffset)
		{
			lpBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + nBlockMapOffset);
			for(i = 0; i < lpBlockMapHead->m_nBlockMapNum; i++)
			{
				nBlockNo = lpBlockMapHead->m_pBlockMap[i].m_nBlockNo;
				m_stIndexMap.Set(nBlockNo, m_lpFileAddr + lpBlockMapHead->m_pBlockMap[i].m_nBlockOffset);
			}
			nBlockMapOffset = lpBlockMapHead->m_nNextBlockMapOffset;
		}
		m_lpBlockMapTail = lpBlockMapHead;
	}

	return MF_OK;
}

/************************************************************************
		功能说明：
			分配空间并创建内存块
		参数说明：
			lpExecutePlan：执行计划
			nBlockNo：块编号
			nBlockMapOffset：映射表结构体偏移
			nBlockSize：内存块大小
			nTimestamp：时间戳
		特别说明:
			1.从文件级的空块链表栈中寻找是否具有合适的空块，如果有则从空块链表栈中分配一个空块
			2.如果空块链表栈中没有合适的块，则从空闲区中分配
************************************************************************/
int CMemoryBTreeFile::AllocBlock(LPEXECUTEPLANBSON lpExecutePlan, int& nBlockNo, long long& nBlockMapOffset, int nBlockSize, long long nTimestamp)
{
	LPBYTE lpBlockAddr;
	LPBASEBLOCKHEAD lpBlockHead;
	int	i, nCount, nBlockMapPos, nTempNo;
	LPBASEFILEBLOCKMAP lpBlockMap, lpPreBlockMap;
	long long nFreeBlockOffset, nFreeBlockMapOffset, nBlockMapSize, nOffset;

	//1.从文件级的空块链表栈中寻找是否具有合适的空块，如果有则从空块链表栈中分配一个空块
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeFileCritical(), lpExecutePlan);

	lpPreBlockMap		= NULL;
 	nFreeBlockMapOffset = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
	while(nFreeBlockMapOffset)
 	{
		lpBlockMap  = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nFreeBlockMapOffset);
		lpBlockAddr = ConvertBlockNotoAddr(lpBlockMap->m_nBlockNo);
		if(lpBlockAddr == NULL)
		{
			return MF_BTREEINDEX_INVALIDNODENO_ERROR;
		}
		lpBlockHead = (LPBASEBLOCKHEAD)lpBlockAddr;
		if(lpBlockHead->m_nBlockSize == nBlockSize)
		{
			//将链表的首地址修改为下一个映射表的结点地址
			if(lpPreBlockMap == NULL)
			{
				m_lpMemoryFileHead->m_nFreeBlockMapOffset = lpBlockMap->m_nNextOffset;	
			}
			else
			{
				lpPreBlockMap->m_nNextOffset			  = lpBlockMap->m_nNextOffset;	
			}
			nBlockNo		= lpBlockMap->m_nBlockNo;	
			nBlockMapOffset = nFreeBlockMapOffset;
			InitialBlock(lpBlockAddr, nBlockNo, nBlockSize, m_lpMemoryFileHead->m_bFileNo, nTimestamp);
			return MF_OK;
		}
		else
		{
			lpPreBlockMap       = lpBlockMap;
			nFreeBlockMapOffset = lpBlockMap->m_nNextOffset;
		}
 	}

	//2.如果空块链表栈中没有合适的块，则从空闲区中分配，分配块的大小必须为DEF_KEYBLOCK_SIZE的整数倍
	nCount = DEF_KEYBLOCK_SIZE / nBlockSize;
	for(i = 0; i < nCount; i++)
	{
		if(m_lpMemoryFileHead->m_nFileFreeSize <= nBlockSize || m_lpMemoryFileHead->m_nFileFreeMemoryOffset + nBlockSize > m_lpMemoryFileHead->m_nFileTotalSize)
		{
			return MF_BTREEINDEX_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;													
		}
		else
		{
			//分配块
			nFreeBlockOffset = m_lpMemoryFileHead->m_nFileFreeMemoryOffset;							//记录新分配的空块的偏移
			m_lpMemoryFileHead->m_nFileFreeMemoryOffset += nBlockSize;								//修改空闲区首地址偏移(注意：块是从后往前分配的)		
			m_lpMemoryFileHead->m_nFileFreeSize -= nBlockSize;										//修改空闲区大小

			//为映射表结点赋值
			nTempNo = m_lpMemoryFileHead->m_nInnerMaxNo;
			nBlockMapPos = m_lpBlockMapTail->m_nBlockMapNum;
			m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nBlockNo	   = nTempNo;
			m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nBlockOffset = nFreeBlockOffset;
			m_lpBlockMapTail->m_pBlockMap[nBlockMapPos].m_nNextOffset  = 0;
			m_lpBlockMapTail->m_nBlockMapNum++;
			nOffset = (LPBYTE)(&m_lpBlockMapTail->m_pBlockMap[nBlockMapPos]) - m_lpFileAddr;


			//分配了新块之后，需要将这个块加入m_mapMemoryBlock
			lpBlockAddr = m_lpFileAddr + nFreeBlockOffset;
			m_stIndexMap.Set(nTempNo, lpBlockAddr);
			m_lpMemoryFileHead->m_nInnerMaxNo++;													//递增最大块号
			m_lpMemoryFileHead->m_nBlockNum++;														//递增块个数

			//初始化块头基础部分
			InitialBlock(lpBlockAddr, nTempNo, nBlockSize, m_lpMemoryFileHead->m_bFileNo, nTimestamp);
		}

		//判断映射表中是否还可以插入结点
		if(m_lpBlockMapTail->m_nBlockMapNum >= m_lpMemoryFileHead->m_nMaxBlockMapNum)
		{
			nBlockMapSize = m_lpMemoryFileHead->m_nBlockMapSize;
			//此时说明映射表空间不足,则需要在文件中分配一个块映射表
			if(m_lpMemoryFileHead->m_nFileFreeSize <= nBlockMapSize || m_lpMemoryFileHead->m_nFileFreeMemoryOffset + nBlockMapSize > m_lpMemoryFileHead->m_nFileTotalSize)
			{
				//说明该内存文件已经没有空间进行块的移动，块满
				return MF_BTREEINDEX_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;						    
			}
			m_lpBlockMapTail->m_nNextBlockMapOffset		=  m_lpMemoryFileHead->m_nFileFreeMemoryOffset;
			m_lpMemoryFileHead->m_nFileFreeSize			-= nBlockMapSize;							
			m_lpMemoryFileHead->m_nFileFreeMemoryOffset += nBlockMapSize;
			m_lpBlockMapTail	= (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset);
			memset(m_lpFileAddr + m_lpMemoryFileHead->m_nFileFreeMemoryOffset, 0, nBlockMapSize);	 
		}
	
		if(i == 0)
		{
			nBlockNo		= nTempNo;
			nBlockMapOffset = nOffset;
		}
		else
		{
			//将块加入空块链表
			lpBlockMap = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nOffset);
			lpBlockMap->m_nNextOffset = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
			m_lpMemoryFileHead->m_nFreeBlockMapOffset = nOffset;
		}
	}
	m_lpMemoryFileHead->m_nTimestamp = nTimestamp;
	return MF_OK;					
}

/************************************************************************
		功能说明：
			释放内存块(清空),并把块号添加到空块队列中
		参数说明：
			lpExecutePlan：执行计划
			nBlockNo:内存块编号
************************************************************************/
void CMemoryBTreeFile::FreeBlock(LPEXECUTEPLANBSON lpExecutePlan, int nBlockNo)
{
	int i;
	BOOL bFind;
	LPBASEFILEBLOCKMAP lpFreeBlockMap;
	LPBASEFILEBLOCKMAPHEAD lpFreeBlockMapHead;
	long long nBlockMapHeadOffset, nBlockMapOffset;

	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeFileCritical(), lpExecutePlan);

	bFind = FALSE;
	lpFreeBlockMap = NULL;
	nBlockMapHeadOffset = m_lpMemoryFileHead->m_nBlockMapStartOffset;
	while(nBlockMapHeadOffset)
	{
		lpFreeBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + nBlockMapHeadOffset);
		for(i = 0; i < lpFreeBlockMapHead->m_nBlockMapNum; i++)
		{
			if(lpFreeBlockMapHead->m_pBlockMap[i].m_nBlockNo == nBlockNo)
			{
				lpFreeBlockMap   = &lpFreeBlockMapHead->m_pBlockMap[i];
				nBlockMapOffset  = (LPBYTE)lpFreeBlockMap - m_lpFileAddr;
				bFind = TRUE;
				break;
			}
		}
		if(bFind)
		{
			break;
		}
		nBlockMapHeadOffset = lpFreeBlockMapHead->m_nNextBlockMapOffset;
	}

	//将该内存块对应的映射表结点放入空块链表(插头法)
	if(lpFreeBlockMap != NULL)
	{
		lpFreeBlockMap->m_nNextOffset = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
		m_lpMemoryFileHead->m_nFreeBlockMapOffset = nBlockMapOffset;
	}

	m_lpMemoryFileHead->m_nTimestamp = lpExecutePlan->m_nTimestamp;
}

/************************************************************************
		功能说明：
			修改根结点
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			nBlockNo：新根节点的块号
************************************************************************/
int CMemoryBTreeFile::RootUpdate(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nBlockNo)
{
	//在m_stRootMap中寻找nIndexID对应的Root结构体
	int i;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeRootCritical(), lpExecutePlan);
	for(i = 0; i< MAX_OBJECT_NUM; i++)
	{
		if(nIndexID == m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID)
		{
			 m_lpMemoryFileHead->m_stRootMap[i].m_nBlockNo = nBlockNo;

			 return	 MF_OK;
		}
	}
	return MF_BTREEINDEX_INVALIDINXEXID_ERROR;
}

/************************************************************************
		功能说明：
			删除根结点
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
************************************************************************/
int CMemoryBTreeFile::RootDelete(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID)
{
	int i;
	//在m_stuRootMap中寻找nIndexID对应的Root结构体
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeRootCritical(), lpExecutePlan);
	for(i = 0; i< MAX_OBJECT_NUM; i++)
	{
		if(nIndexID == m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID)
		{
			memset(&m_lpMemoryFileHead->m_stRootMap[i], 0, sizeof(ROOTSTRUCT));
			return MF_OK;
		}
	}
	return MF_BTREEINDEX_INVALIDINXEXID_ERROR;
}

/************************************************************************
		功能说明：
			释放跟结点的块
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
************************************************************************/
int CMemoryBTreeFile::FreeRootBlock(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID)
{
	int i;
	//在m_stuRootMap中寻找nIndexID对应的Root结构体
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeRootCritical(), lpExecutePlan);
	for(i = 0; i< MAX_OBJECT_NUM; i++)
	{
		if(nIndexID == m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID)
		{
			FreeBlock(lpExecutePlan, m_lpMemoryFileHead->m_stRootMap[i].m_nBlockNo);
			m_lpMemoryFileHead->m_stRootMap[i].m_nBlockNo = 0;
			return MF_OK;
		}
	}
	return MF_BTREEINDEX_INVALIDINXEXID_ERROR;
}

/************************************************************************
		功能说明：
			获得根节点
		参数说明：
			lpExecutePlan：执行计划
			nRootNo：根结点编号
			nIndexID：索引ID
************************************************************************/
int CMemoryBTreeFile::GetRootNo(LPEXECUTEPLANBSON lpExecutePlan, int& nRootNo, int nIndexID)
{
	int i;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeRootCritical(), lpExecutePlan);
	//根据nIndexID值在ROOT中找到索引的入口地址
	nRootNo = 0;
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(nIndexID == m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID)
		{
			nRootNo = m_lpMemoryFileHead->m_stRootMap[i].m_nBlockNo;
			return MF_OK;
		}
	}
	return MF_BTREEINDEX_INVALIDINXEXID_ERROR;
}

/************************************************************************
		功能说明：
			设置根节点
		参数说明：
			lpExecutePlan：执行计划
			nRootNo：根结点编号
			nIndexID：索引ID
************************************************************************/
int CMemoryBTreeFile::SetRootNo(LPEXECUTEPLANBSON lpExecutePlan, int nRootNo, int nIndexID)
{
	int i;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeRootCritical(), lpExecutePlan);
	//根据nIndexID值在ROOT中找到索引的入口地
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(nIndexID == m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID)
		{
			m_lpMemoryFileHead->m_stRootMap[i].m_nBlockNo = nRootNo;
			return MF_OK;
		}
	}
	return MF_BTREEINDEX_INVALIDINXEXID_ERROR;
}

/************************************************************************
		功能说明：
			获取字段信息
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			bFieldNum：字段数量
			bFieldType：字段类型
************************************************************************/
int CMemoryBTreeFile::GetFieldInfo(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, BYTE& bFieldNum, LPBYTE& bFieldType)
{
	int i;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeRootCritical(), lpExecutePlan);
	//根据nIndexID值在ROOT中找到索引的入口地址
	bFieldNum  = 0;
	bFieldType = NULL;
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(nIndexID == m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID)
		{
			bFieldNum = m_lpMemoryFileHead->m_stRootMap[i].m_bFieldNum;
			bFieldType= m_lpMemoryFileHead->m_stRootMap[i].m_bFieldType;
			return MF_OK;
		}
	}
	return MF_BTREEINDEX_INVALIDINXEXID_ERROR;
}

/************************************************************************
		功能说明：
			获取回收映射表
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			nRecycleBlockNo：回收块编号
************************************************************************/
int CMemoryBTreeFile::GetRecycleBlockNo(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int& nRecycleBlockNo)
{
	int i;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeRootCritical(), lpExecutePlan);
	//根据nIndexID值在ROOT中找到索引的入口地址
	nRecycleBlockNo = 0;
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(nIndexID == m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID)
		{
			nRecycleBlockNo = m_lpMemoryFileHead->m_stRootMap[i].m_nRecycleMapNo;
			return MF_OK;
		}
	}
	return MF_BTREEINDEX_INVALIDINXEXID_ERROR;
}

/************************************************************************
		功能说明：
			设置回收映射表
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			nRecycleBlockNo：回收块编号
************************************************************************/
int CMemoryBTreeFile::SetRecycleBlockNo(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, int nRecycleBlockNo)
{
	int i;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeRootCritical(), lpExecutePlan);
	//根据nIndexID值在ROOT中找到索引的入口地址
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(nIndexID == m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID)
		{
			m_lpMemoryFileHead->m_stRootMap[i].m_nRecycleMapNo = nRecycleBlockNo;
			return MF_OK;
		}
	}
	return MF_BTREEINDEX_INVALIDINXEXID_ERROR;
}
/************************************************************************
		功能说明：
			创建根节点
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
			bFieldNum：字段数量
			bFieldType: 字段类型
			nRootNo：根节点编号
			nTimestamp：时间戳
************************************************************************/
int CMemoryBTreeFile::CreateRoot(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, BYTE bFieldNum, LPBYTE bFieldType, int& nRootNo, long long nTimestamp)
{
	int i, j, nRet;
	long long nBlockMapOffset;
	
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeRootCritical(), lpExecutePlan);
	for(i = 0; i < MAX_OBJECT_NUM; i++)
	{
		if(m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID == 0)
		{
			m_lpMemoryFileHead->m_stRootMap[i].m_nIndexID = nIndexID;
			nRet = AllocBlock(lpExecutePlan, nRootNo, nBlockMapOffset, DEF_BTREEBLOCK_SIZE, nTimestamp);	
			if(nRet != MF_OK)
			{	
				return nRet;
			}
			m_lpMemoryFileHead->m_stRootMap[i].m_nBlockNo  = nRootNo;
			m_lpMemoryFileHead->m_stRootMap[i].m_bFieldNum = bFieldNum;
			for(j = 0; j < bFieldNum; j++)
			{
				m_lpMemoryFileHead->m_stRootMap[i].m_bFieldType[j] = bFieldType[j];
			}
			return MF_OK;
		}
	}
	return MF_COMMON_MAX_INDEX;
}

/************************************************************************
		功能说明:
			获取数据ID
		参数说明：
			lpIndexInfo：索引信息
			stExecutePlanManager：执行计划
************************************************************************/
int CMemoryBTreeFile::GetDataID(LPINDEXINFO lpIndexInfo, CDataIDContainer* pDataIDContainer)
{
	BYTE bFielNum;
	int nRet, nRootNo; 
	LPINDEXDEF lpIndex;
	LPBYTE lpRoot, bFildType;
	MF_SYS_INDEXTYPE bIndexType;
	LPEXECUTEPLANBSON lpExecutePlan;
	CSystemLockStateManage stIndexLock;
	
	lpExecutePlan = (LPEXECUTEPLANBSON)lpIndexInfo->m_pBson->GetBuffer();

	//给索引加锁
	nRet = CSystemManage::instance().GetIndexInfo(lpIndexInfo->m_nIndexID, lpIndex);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	stIndexLock.Inital(MF_LOCK_INDEX, lpExecutePlan, lpIndex);
	nRet = stIndexLock.Lock(MF_LOCK_STATUS_MUTEX, MF_LOCK_OUTOFTIME, lpExecutePlan->m_nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//1.根据nIndexID值在ROOT中找到索引的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, lpIndexInfo->m_nIndexID);
	if(nRet != MF_OK)
	{
		return MF_OK;
	}
	
	if(nRootNo == 0)
	{
		return MF_OK;
	}
	else
	{
		lpRoot = ConvertBlockNotoAddr(nRootNo);
		if(NULL == lpRoot)
		{
			return MF_BTREEINDEX_INVALIDROOTNO_ERROR;
		}
	}

	//2.获取字段信息
	nRet = GetFieldInfo(lpExecutePlan, lpIndexInfo->m_nIndexID, bFielNum, bFildType);
	if(nRet != MF_OK)
	{
		return MF_OK;
	}

	bIndexType = lpIndexInfo->m_bIndexType;
	switch(bIndexType)
	{
	case MF_SYS_INDEXTYPE_TREE_INT:
	case MF_SYS_INDEXTYPE_TREE_BIGINT:
	case MF_SYS_INDEXTYPE_TREE_DOUBLE:
	case MF_SYS_INDEXTYPE_TREE_MULTINUM:
		{
			CMemoryMultiNum stMultiNum;
			stMultiNum.SetNodeAddr(lpRoot, lpIndexInfo->m_nIndexID, bFielNum, bFildType, this);
			nRet = stMultiNum.GetDataID(lpIndexInfo, pDataIDContainer);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	case MF_SYS_INDEXTYPE_FUZZY_CHAR:
	case MF_SYS_INDEXTYPE_TREE_MULTISTR:
		{
			CMemoryMultiStr stMultiStr;
			//对pKey进行预处理去掉前后百分号
			RemovePercent(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_lpszValue, lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_nStrLen, lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1);
			stMultiStr.SetNodeAddr(lpRoot, lpIndexInfo->m_nIndexID, bFielNum, bFildType, this);
			nRet = stMultiStr.GetDataID(lpIndexInfo, pDataIDContainer);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	default:
		return MF_BTREEINDEX_INVALIDINDEXTYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			根据key值在索引块中插入一个新的索引项
		参数说明：
			lpIndexInfo：索引信息
			nObjectID：对象ID
			lpExecutePlan：执行计划
			nTimestamp：时间戳
		特别说明:
			根据nIndexID值在ROOT中找到索引的入口地址，然后调用Index类的相关函数进行插入
************************************************************************/
int CMemoryBTreeFile::InsertIndex(LPINDEXINFO lpIndexInfo, long long nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	BYTE bFielNum;
	int nRet, nRootNo;
	LPBYTE lpRootBlock, bFildType;
	long long nBlockMapOffset;
	
	//根据nIndexID值在ROOT中找到索引的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, lpIndexInfo->m_nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	else if(nRootNo == 0)
	{
		nRet = AllocBlock(lpExecutePlan, nRootNo, nBlockMapOffset, DEF_BTREEBLOCK_SIZE, nTimestamp);	
		if(nRet != MF_OK)
		{	
			return nRet;
		}
		nRet = SetRootNo(lpExecutePlan, nRootNo, lpIndexInfo->m_nIndexID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//获取字段信息
	nRet = GetFieldInfo(lpExecutePlan, lpIndexInfo->m_nIndexID, bFielNum, bFildType);
	if(nRet != MF_OK)
	{
		return MF_OK;
	}

	lpRootBlock = ConvertBlockNotoAddr(nRootNo);
	if(NULL == lpRootBlock)
	{
		return MF_BTREEINDEX_INVALIDROOTNO_ERROR;		//没有找到ROOTNO对应的根节点
	}
	switch(lpIndexInfo->m_bIndexType)
	{
	case MF_SYS_INDEXTYPE_TREE_INT:
	case MF_SYS_INDEXTYPE_TREE_BIGINT:
	case MF_SYS_INDEXTYPE_TREE_DOUBLE:
	case MF_SYS_INDEXTYPE_TREE_MULTINUM:
		{
			CMemoryMultiNum stMultiNum;
			stMultiNum.SetNodeAddr(lpRootBlock, lpIndexInfo->m_nIndexID, bFielNum, bFildType, this);
			nRet = stMultiNum.InsertIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	case MF_SYS_INDEXTYPE_FUZZY_CHAR:
	case MF_SYS_INDEXTYPE_TREE_MULTISTR:
		{
			BYTE bMidFlag;
			int	i, nRet, nKeyLen;
			char *pSuffixKey, *pKey;
			CMemoryMultiStr stMultiStr;
			long long nSuffixOffset, nKeyOffset;

			if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_nStrLen == 0)
			{
				return MF_OK;
			}
			//1.将pKey插入数据块
			lpIndexInfo->m_nParam4 = GetStrMultiKeySize(&lpIndexInfo->m_stMultiIndex); 
			nRet = InsertKey(lpIndexInfo, lpExecutePlan, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nKeyOffset = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_llValue;
			pKey	   = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_lpszValue;
			nKeyLen    = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_nStrLen - 1;
			stMultiStr.SetNodeAddr(lpRootBlock, lpIndexInfo->m_nIndexID, bFielNum, bFildType, this);

			lpIndexInfo->m_bFirstString = TRUE;
			for(i = 0; i < nKeyLen; i++)
			{
				pSuffixKey = pKey++;
				nSuffixOffset = nKeyOffset++;

				//如果是10XXXXXX的表示UTF8的中间字符
				bMidFlag = (*pSuffixKey)&0XC0;
				if(bMidFlag == 0X80)
				{
					continue;
				}
				else if(*pSuffixKey == ' ' || *pSuffixKey == '	' || *pSuffixKey == '\r' || *pSuffixKey == '\n' ||
					*pSuffixKey == ':' || *pSuffixKey == ',' || *pSuffixKey == '.' || *pSuffixKey == ';')		//空格，TAB，回车，换行	
				{
					continue;
				}
				lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.SetData(nSuffixOffset);
				lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.SetData(pSuffixKey, nKeyLen - i);

				nRet = stMultiStr.InsertIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpIndexInfo->m_bFirstString = FALSE;
			}
		}
		break;
	default:
		return MF_BTREEINDEX_INVALIDINDEXTYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			根据key值在索引块中删除一个新的索引项
		参数说明：
			lpIndexInfo：索引信息
			lpExecutePlan：执行计划
			nTimestamp：时间戳
		特别说明:
			根据nIndexID值在ROOT中找到索引的入口地址，然后调用Index类的相关函数进行删除
************************************************************************/
int CMemoryBTreeFile::DeleteIndex(LPINDEXINFO lpIndexInfo, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	BYTE bFielNum;
	int nRet, nRootNo;
	LPBYTE lpRoot, bFildType;
	//根据nIndexID值在ROOT中找到索引的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, lpIndexInfo->m_nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	if(nRootNo == 0)
	{
		return MF_OK;
	}
	else
	{
		lpRoot = ConvertBlockNotoAddr(nRootNo);
		if(NULL == lpRoot)
		{
			//没有找到RootNO对应的根节点
			return MF_BTREEINDEX_INVALIDROOTNO_ERROR;
		}
	}

	//获取字段信息
	nRet = GetFieldInfo(lpExecutePlan, lpIndexInfo->m_nIndexID, bFielNum, bFildType);
	if(nRet != MF_OK)
	{
		return MF_OK;
	}

	//创建CMemoryMultiNum对象,并调用DeleteIndex进行索引删除操作
	switch(lpIndexInfo->m_bIndexType)
	{
	case MF_SYS_INDEXTYPE_TREE_INT:
	case MF_SYS_INDEXTYPE_TREE_BIGINT:
	case MF_SYS_INDEXTYPE_TREE_DOUBLE:
	case MF_SYS_INDEXTYPE_TREE_MULTINUM:
		{
			CMemoryMultiNum stMultiNum;
			stMultiNum.SetNodeAddr(lpRoot, lpIndexInfo->m_nIndexID, bFielNum, bFildType, this);
			nRet = stMultiNum.DeleteIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			break;
		}
	case MF_SYS_INDEXTYPE_FUZZY_CHAR:
	case MF_SYS_INDEXTYPE_TREE_MULTISTR:
		{
			BYTE bMidFlag;
			LPBYTE lpBlockAddr;
			int	i, nRet, nKeyLen;
			long long nKeyOffset;
			char *pSuffixKey, *pKey;
			CMemoryMultiStr stMultiStr;
			CMemoryMultiKeyBlock stMultiKeyBlock;
			
			if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_nStrLen == 0)
			{
				return MF_OK;
			}
			pKey    = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_lpszValue;
			nKeyLen = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_nStrLen - 1;
			stMultiStr.SetNodeAddr(lpRoot, lpIndexInfo->m_nIndexID, bFielNum, bFildType, this);
			for(i = 0; i < nKeyLen; i++)
			{
				pSuffixKey = pKey++;
				//如果是10XXXXXX的表示UTF8的中间字符
				bMidFlag = (*pSuffixKey)&0XC0;
				if(bMidFlag == 0X80)
				{
					continue;
				}
				else if(*pSuffixKey == ' ' || *pSuffixKey == '	' || *pSuffixKey == '\r' || *pSuffixKey == '\n' ||
					*pSuffixKey == ':' || *pSuffixKey == ',' || *pSuffixKey == '.' || *pSuffixKey == ';')		//空格，TAB，回车，换行	
				{
					continue;
				}
				lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.SetData(pSuffixKey, nKeyLen - i);
				nRet = stMultiStr.DeleteIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}

			nKeyOffset  = lpIndexInfo->m_nParam4;
			//通过Offset找到对应的块,然后找到需要删除的字符串的位置
			lpBlockAddr = m_lpFileAddr + (nKeyOffset & 0xFFFC0000);
			if(((LPBASEBLOCKHEAD)lpBlockAddr)->m_nDataFlag != MAKEHEADFLAG('S','B','D','B'))
			{
				Trace0(_T("DeleteIndex"), 0, 0, _T("原始关键字块位置错误！"));
				return MF_INNER_INNERNO_DATAERROR;
			}
			//从块中删除关键字
			stMultiKeyBlock.SetBlockAddr(this, lpBlockAddr);
			stMultiKeyBlock.SetKeyNum(bFielNum);
			nRet = stMultiKeyBlock.DeleteKey(lpIndexInfo, lpExecutePlan, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			break;
		}
	default:
		return MF_BTREEINDEX_INVALIDINDEXTYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			更新索引(只用于字符串索引)
		参数说明：
			lpIndexInfo:索引信息
			nDataID:数据ID
			lpExecutePlan：执行计划
			nTimestamp：时间戳
		特别说明：
			关于pOldKeyType参数：因为可能会出现对于空字段的更新操作，
			所以如果字段为空就不能进行删除操作
************************************************************************/
int CMemoryBTreeFile::UpdateIndex(LPINDEXINFO lpIndexInfo, long long nObjectID, LPEXECUTEPLANBSON lpExecutePlan, long long nTimestamp)
{
	BYTE bFielNum;
	int nRet, nRootNo;
	LPBYTE lpRoot, bFildType;

	if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_vt == MF_SYS_FIELDTYPE_NULL || lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_vt == MF_SYS_FIELDTYPE_NULL)
	{
		return MF_OK;
	}

	//根据nIndexID值在ROOT中找到索引的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, lpIndexInfo->m_nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(nRootNo == 0)
	{
		return MF_OK;
	}
	else
	{
		lpRoot = ConvertBlockNotoAddr(nRootNo);
		if(NULL == lpRoot)
		{
			//没有找到RootNO对应的根节点
			return MF_BTREEINDEX_INVALIDROOTNO_ERROR;
		}
	}

	//获取字段信息
	nRet = GetFieldInfo(lpExecutePlan, lpIndexInfo->m_nIndexID, bFielNum, bFildType);
	if(nRet != MF_OK)
	{
		return MF_OK;
	}

	//创建CMemoryMultiNum对象,并调用DeleteIndex进行索引删除操作
	switch(lpIndexInfo->m_bIndexType)
	{
	case MF_SYS_INDEXTYPE_TREE_INT:
	case MF_SYS_INDEXTYPE_TREE_BIGINT:
	case MF_SYS_INDEXTYPE_TREE_DOUBLE:
	case MF_SYS_INDEXTYPE_TREE_MULTINUM:
		{
			//数值型索引直接删除原始索引，并添加新索引
			CMemoryMultiNum stMultiNum;
			stMultiNum.SetNodeAddr(lpRoot, lpIndexInfo->m_nIndexID, bFielNum, bFildType, this);
			
			nRet = stMultiNum.DeleteIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nRet = stMultiNum.InsertIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			break;
		}
	case MF_SYS_INDEXTYPE_FUZZY_CHAR:
	case MF_SYS_INDEXTYPE_TREE_MULTISTR:
		{
			BYTE bMidFlag;
			char *pSuffixKey, *pKey;
			CMemoryMultiStr stMultiStr;
			LPBYTE lpBlockAddr, lpKeyBuffer;
			CMemoryMultiKeyBlock stMultiKeyBlock;
			int	i, nRet, nKeyLen, nNewKeyBufferLen, nOldKeyBufferLen;
			long long nKeyOffset, nKeyBufferOffset, nSuffixOffset, nBlockMapOffset;

			pKey    = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_lpszValue;
			if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_nStrLen > 0)
			{
				nKeyLen = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_nStrLen - 1;
			}
			else
			{
				nKeyLen = 0;
			}
			stMultiStr.SetNodeAddr(lpRoot, lpIndexInfo->m_nIndexID, bFielNum, bFildType, this);
			if(nKeyLen == 0 || pKey == NULL)
			{
				nOldKeyBufferLen = 0;
			}
			else
			{
				for(i = 0; i < nKeyLen; i++)
				{
					pSuffixKey = pKey++;
					//如果是10XXXXXX的表示UTF8的中间字符
					bMidFlag = (*pSuffixKey)&0XC0;
					if(bMidFlag == 0X80)
					{
						continue;
					}
					lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.SetData(pSuffixKey, nKeyLen - i);
					nRet = stMultiStr.DeleteIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
					if(nRet != MF_OK)
					{
						return nRet;
					}
				}

				//获取原始关键字Buffer
				stMultiKeyBlock.SetBlockAddr(this, NULL);
				stMultiKeyBlock.SetKeyNum(bFielNum);
				stMultiKeyBlock.GetKeyBuffer(lpIndexInfo, nKeyBufferOffset, nOldKeyBufferLen);
			}
			
			if(lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_lpszValue == NULL || lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_nStrLen == 0)
			{
				if(nOldKeyBufferLen != 0)
				{
					//删除原始关键字
					nKeyOffset  = lpIndexInfo->m_nParam4;
					lpBlockAddr = m_lpFileAddr + (nKeyOffset & 0xFFFFE000);
					stMultiKeyBlock.SetBlockAddr(this, lpBlockAddr);
					stMultiKeyBlock.SetKeyNum(bFielNum);
					nRet = stMultiKeyBlock.DeleteKey(lpIndexInfo, lpExecutePlan, nTimestamp);
					if(nRet != MF_OK)
					{
						return nRet;
					}
				}
			}
			else
			{
				//获取新关键字Buffer的长度，以及原始关键字Buffer
				nNewKeyBufferLen = GetStrMultiKeySize(&lpIndexInfo->m_stMultiIndex); 
				if(nOldKeyBufferLen < nNewKeyBufferLen)
				{
					if(nOldKeyBufferLen != 0)
					{
						//删除原始关键字
						nKeyOffset  = lpIndexInfo->m_nParam4;
						lpBlockAddr = m_lpFileAddr + (nKeyOffset & 0xFFFFE000);
						stMultiKeyBlock.SetBlockAddr(this, lpBlockAddr);
						stMultiKeyBlock.SetKeyNum(bFielNum);
						nRet = stMultiKeyBlock.DeleteKey(lpIndexInfo, lpExecutePlan, nTimestamp);
						if(nRet != MF_OK)
						{
							return nRet;
						}
					}

					//插入新关键字
					lpIndexInfo->m_nParam4 = nNewKeyBufferLen;
					nRet = InsertKey(lpIndexInfo, lpExecutePlan, nTimestamp);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					nKeyOffset = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.m_llValue;
					pKey	   = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_lpszValue;
					nKeyLen    = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_nStrLen - 1;
				}
				else
				{
					//使用原始关键字Buffer写入新数据
					nKeyOffset  = lpIndexInfo->m_nParam4;

					lpKeyBuffer = m_lpFileAddr + nKeyBufferOffset;
					nRet = stMultiKeyBlock.WriteData(lpKeyBuffer, &lpIndexInfo->m_stMultiIndex, nNewKeyBufferLen, nKeyBufferOffset, lpIndexInfo->m_nDataID);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					nKeyOffset = nKeyBufferOffset + 1;
					pKey	   = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_lpszValue;
					nKeyLen    = lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.m_nStrLen - 1;
				}

				//根据nIndexID值在ROOT中找到索引的入口地址
				nRet = GetRootNo(lpExecutePlan, nRootNo, lpIndexInfo->m_nIndexID);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				else if(nRootNo == 0)
				{
					nRet = AllocBlock(lpExecutePlan, nRootNo, nBlockMapOffset, DEF_BTREEBLOCK_SIZE, nTimestamp);	
					if(nRet != MF_OK)
					{	
						return nRet;
					}
					nRet = SetRootNo(lpExecutePlan, nRootNo, lpIndexInfo->m_nIndexID);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					lpRoot = ConvertBlockNotoAddr(nRootNo);
					if(NULL == lpRoot)
					{
						//没有找到RootNO对应的根节点
						return MF_BTREEINDEX_INVALIDROOTNO_ERROR;
					}
				}

				stMultiStr.SetNodeAddr(lpRoot, lpIndexInfo->m_nIndexID, bFielNum, bFildType, this);
				for(i = 0; i < nKeyLen; i++)
				{
					pSuffixKey    = pKey++;
					nSuffixOffset = nKeyOffset++;

					//如果是10XXXXXX的表示UTF8的中间字符
					bMidFlag = (*pSuffixKey)&0XC0;
					if(bMidFlag == 0X80)
					{
						continue;
					}
					else if(*pSuffixKey == ' ' || *pSuffixKey == '	' || *pSuffixKey == '\r' || *pSuffixKey == '\n' ||
						*pSuffixKey == ':' || *pSuffixKey == ',' || *pSuffixKey == '.' || *pSuffixKey == ';')		//空格，TAB，回车，换行	
					{
						continue;
					}
					lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition1.SetData(nSuffixOffset);
					lpIndexInfo->m_stMultiIndex.m_lpIndexCondition[0].m_varCondition2.SetData(pSuffixKey, nKeyLen - i);


					nRet = stMultiStr.InsertIndex(lpIndexInfo, lpExecutePlan, nTimestamp);
					if(nRet != MF_OK)
					{
						return nRet;
					}
				}
			}
			break;
		}
	default:
		return MF_BTREEINDEX_INVALIDINDEXTYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			为某字段创建索引
		参数说明：
			nObjectID：对象ID
			nIndexID：索引ID
			nFieldNo：字段编号
************************************************************************/	
int CMemoryBTreeFile::CreateIndex(CServiceBson& stBson, int nObjectID, int nIndexID, LPBYTE pFieldNo, MF_CONSTRAINT_TYPE bConstraintType)
{
	BOOL bUnique;
	Check stCheck;
	VARDATA varData;
	LPINDEXDEF lpIndex;
	CMemoryFile* pFile;
	INDEXINFO stIndexInfo;
	QUERYINFO stQueryInfo;
	LPOBJECTDEF lpObjectInfo;
	CExpression stExpression;
	RECORDDATAINFO stRecordInfo;
	LPINDEXCONDITION lpIndexField;
	LPEXECUTEPLANBSON lpExecutePlan;
	int nRet, nRootNo, i, nInnerDataNo;
	IVirtualMemoryFile* pIVirtualMemoryFile;
	BYTE bFieldNo, bLinkType, bFieldNum, bFieldType[5];
	long long nDataID, nTimestamp, nBlockMapOffset, *lpTransactionArray;
	
	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	nTimestamp    = lpExecutePlan->m_nTimestamp;
	lpTransactionArray = (long long*)stBson.GetPtrFromTempBuffer(lpExecutePlan->m_nTransactionOffset);
	TRANSACTIONARRAY stTransactionArray(lpExecutePlan->m_nTransactionNum, lpTransactionArray);

	lpObjectInfo  = stBson.GetObjectInfo();

	nRet = CSystemManage::instance().GetIndexInfo(nIndexID, lpIndex);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	while(lpIndex)
	{
		if(pFieldNo[0] == lpIndex->m_bFieldNo[0] && pFieldNo[1] == lpIndex->m_bFieldNo[1] &&
		   pFieldNo[2] == lpIndex->m_bFieldNo[2] && pFieldNo[3] == lpIndex->m_bFieldNo[3])
		{
			break;
		}
		lpIndex = lpIndex->m_pNext;
	}

	//获取索引字段数和字段类型
	bFieldNum = 0;
	for(i = 0; i < 4; i++)
	{
		if(lpIndex->m_bFieldNo[i] == 0)
		{
			break;
		}
		bFieldNum++;
		bFieldType[i] = lpObjectInfo->m_lpField[lpIndex->m_bFieldNo[i] - 1].m_bFieldType;
	}
	//最后一个字段类型一定是DataID
	bFieldType[bFieldNum] = MF_SYS_FIELDTYPE_BIGINT;
	bFieldNum++;

	//1.创建根结点
	nRet = CreateRoot(lpExecutePlan, lpIndex->m_nIndexID, bFieldNum, bFieldType, nRootNo, lpExecutePlan->m_nTimestamp);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//2.根据ObjectID对相应的表进行全表遍历
	nRet = CSystemManage::instance().GetMemoryFileInstance(lpObjectInfo->m_bFileNo, pIVirtualMemoryFile);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pFile = (CMemoryFile*)pIVirtualMemoryFile;

	stQueryInfo.m_nTimestamp			= nTimestamp;
	stQueryInfo.m_lpObjectInfo			= lpObjectInfo;
	stQueryInfo.m_lpTransactionArray		= &stTransactionArray;

	bLinkType		= 0;
	nBlockMapOffset = 0;
	nInnerDataNo	= 0;
	stCheck.Initial(&stBson, &stQueryInfo);
	stExpression.Initial(&stBson, lpObjectInfo);
	//3.遍历vecDataID，获取nFieldNo对应字段的字段值，并建立索引
	stRecordInfo.m_nTimestamp			= nTimestamp;
	stRecordInfo.m_lpTransactionArray	= &stTransactionArray;
	stRecordInfo.m_bDataPosition		= MF_DATAPOSITION_UNKNOWN;
	if(bConstraintType == MF_CONSTRAINT_PRIMARYKEY || bConstraintType == MF_CONSTRAINT_UNIQUE)
	{
		bUnique = TRUE;
	}
	else
	{
		bUnique = FALSE;
	}
	while(TRUE)
	{
		nRet = pFile->GetNextDataID(lpExecutePlan, lpObjectInfo->m_nObjectID, FALSE, bLinkType, nBlockMapOffset, nInnerDataNo, nDataID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(nDataID == 0)
		{
			break;
		}
		stIndexInfo.clear();
		if(stCheck.CheckRecordValid(nDataID))
		{
			for(i = 0; i < 4; i++)
			{
				bFieldNo = pFieldNo[i];
				if(bFieldNo == 0)
				{
					break;
				}
				else
				{
					stIndexInfo.m_stMultiIndex.m_nIndexNum++;
					lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];
				}

				stRecordInfo.m_nDataID  = nDataID;
				nRet = pFile->GetRecordBuffer(stBson, &stRecordInfo);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				if(stRecordInfo.m_lpRecordBuffer == NULL)
				{
					return MF_COMMON_RECORD_NOTEXIT;
				}
				nRet = stExpression.GetFieldValueFromRecordBuffer(stRecordInfo.m_nDataID, stRecordInfo.m_lpRecordBuffer, stRecordInfo.m_nRecordLen, bFieldNo, varData);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				if(bConstraintType == MF_CONSTRAINT_PRIMARYKEY && varData.m_vt == MF_SYS_FIELDTYPE_NULL)
				{
					return MF_COMMON_INVALID_NULLPRIMARYKEY;
				}

				lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
				lpIndexField->m_bFieldNo   = bFieldNo;
				lpIndexField->m_bFieldType = lpObjectInfo->m_lpField[bFieldNo - 1].m_bFieldType;
				lpIndexField->m_varCondition2.SetData(varData);
			}
			//将DataID作为最后一个关键字
			stIndexInfo.m_stMultiIndex.m_nIndexNum++;
			lpIndexField = &stIndexInfo.m_stMultiIndex.m_lpIndexCondition[i];

			lpIndexField->m_bOperator  = MF_EXECUTEPLAN_OPERATOR_EQUAL;
			lpIndexField->m_bFieldType = MF_SYS_FIELDTYPE_BIGINT;
			lpIndexField->m_varCondition2.SetData(nDataID);

			//插入索引项
			stIndexInfo.m_pBson			= &stBson;
			stIndexInfo.m_nIndexID		= nIndexID;
			stIndexInfo.m_bUnique		= bUnique;
			stIndexInfo.m_bFileNo		= lpIndex->m_bFileNo;
			stIndexInfo.m_bIndexType	= lpIndex->m_bIndexType; 
			stIndexInfo.m_nDataID		= nDataID;
			stIndexInfo.m_bFieldNo[0]	= pFieldNo[0];
			stIndexInfo.m_bFieldNo[1]	= pFieldNo[1];
			stIndexInfo.m_bFieldNo[2]	= pFieldNo[2];
			stIndexInfo.m_bFieldNo[3]	= pFieldNo[3];

			nRet = InsertIndex(&stIndexInfo, lpIndex->m_nObjectID, NULL, nTimestamp);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			删除索引
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：索引ID
		特别说明：
			执行步骤：
			1.找到索引树的根节点，然后分别找到起始大树干结点、起始树干结点、起始叶子结点的
			2.将结点链表插入空块队列
			3.删除根节点
************************************************************************/
int CMemoryBTreeFile::DropObject(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID)
{
	BYTE bFielNum;
	int nRet, nRootNo;
	LPINDEXDEF lpIndexInfo;
	LPBYTE lpRoot, bFildType;
	nRet = CSystemManage::instance().GetIndexInfo(nIndexID, lpIndexInfo);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//1.根据nIndexID值在ROOT中找到索引的入口地址
	nRet = GetRootNo(lpExecutePlan, nRootNo, nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(nRootNo == 0)
	{
		return RootDelete(lpExecutePlan, nIndexID);
	}
	else
	{
		lpRoot = ConvertBlockNotoAddr(nRootNo);
		if(NULL == lpRoot)
		{
			return MF_BTREEINDEX_INVALIDROOTNO_ERROR;		//没有找到nIndexID对应的根节点
		}
	}
	
	//2.获取字段信息
	nRet = GetFieldInfo(lpExecutePlan, lpIndexInfo->m_nIndexID, bFielNum, bFildType);
	if(nRet != MF_OK)
	{
		return MF_OK;
	}

	//3.调用对应函数执行删除索引操作
	if(MF_SYS_INDEXTYPE_TREE_INT == lpIndexInfo->m_bIndexType || MF_SYS_INDEXTYPE_TREE_BIGINT == lpIndexInfo->m_bIndexType || MF_SYS_INDEXTYPE_TREE_DOUBLE == lpIndexInfo->m_bIndexType || MF_SYS_INDEXTYPE_TREE_MULTINUM == lpIndexInfo->m_bIndexType)
	{
		CMemoryMultiNum stuMultiNum;
		stuMultiNum.SetNodeAddr(lpRoot, nIndexID, bFielNum, bFildType, this);
		nRet = stuMultiNum.DropIndex(lpExecutePlan);
	}
	else if(MF_SYS_INDEXTYPE_FUZZY_CHAR == lpIndexInfo->m_bIndexType || MF_SYS_INDEXTYPE_TREE_MULTISTR == lpIndexInfo->m_bIndexType)
	{
		int nBlockNo;
		LPBYTE lpBlockAddr;
		LINKINFO stLinkInfo;
		LPBASEBLOCKHEAD lpBlockHead;
		CMemoryMultiStr stuMultiStr;
		stuMultiStr.SetNodeAddr(lpRoot, nIndexID, bFielNum, bFildType, this);
		nRet = stuMultiStr.DropIndex(lpExecutePlan);
		if(nRet != MF_OK)
		{
			return nRet;
		}

		//释放原数据块
		memset(&stLinkInfo, 0, sizeof(LINKINFO));
		stLinkInfo.m_bLikType = FREE_LINK;
		stLinkInfo.m_bStart   = TRUE;
		while(TRUE)
		{
			nRet = GetBlockFromLink(lpExecutePlan, lpIndexInfo->m_nIndexID, &stLinkInfo, lpBlockAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpBlockAddr == NULL)
			{
				break;
			}
			else
			{
				lpBlockHead = (LPBASEBLOCKHEAD)lpBlockAddr;
				FreeBlock(lpExecutePlan, lpBlockHead->m_nBlockNo);
			}
		}
		
		memset(&stLinkInfo, 0, sizeof(LINKINFO));
		stLinkInfo.m_bLikType = FULL_LINK;
		stLinkInfo.m_bStart   = TRUE;
		while(TRUE)
		{
			nRet = GetBlockFromLink(lpExecutePlan, lpIndexInfo->m_nIndexID, &stLinkInfo, lpBlockAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpBlockAddr == NULL)
			{
				break;
			}
			else
			{
				lpBlockHead = (LPBASEBLOCKHEAD)lpBlockAddr;
				FreeBlock(lpExecutePlan, lpBlockHead->m_nBlockNo);
			}
		}

		//释放回收映射表块
		nRet = GetRecycleBlockNo(lpExecutePlan, nIndexID, nBlockNo);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(nBlockNo != 0)
		{
			FreeBlock(lpExecutePlan, nBlockNo);
		}
	}
	else
	{
		return MF_BTREEINDEX_INVALIDINDEXTYPE_ERROR;
	}	

	nRet = RootDelete(lpExecutePlan, nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取文件大小信息
		参数说明：
			lpExecutePlan：执行计划
			nFileTotalSize：文件总大小
			nFileUseSize：使用大小
			nFileFreeSize：剩余空间大小
************************************************************************/
int CMemoryBTreeFile::GetFileSpace(LPEXECUTEPLANBSON lpExecutePlan, long long &nFileTotalSize, long long &nFileUseSize, long long &nFileFreeSize)
{
	LPBASEBLOCKHEAD lpBlockHead;
	long long nFreeBlockMapOffset;
	LPBASEFILEBLOCKMAP lpBlockMap;

	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeFileCritical(), lpExecutePlan);
	nFileTotalSize = m_lpMemoryFileHead->m_nFileTotalSize;
	nFileFreeSize  = m_lpMemoryFileHead->m_nFileFreeSize;
	
	nFreeBlockMapOffset = m_lpMemoryFileHead->m_nFreeBlockMapOffset;
	while(nFreeBlockMapOffset)
	{
		lpBlockMap  = (LPBASEFILEBLOCKMAP)(m_lpFileAddr + nFreeBlockMapOffset);
		lpBlockHead = (LPBASEBLOCKHEAD)(m_lpFileAddr + lpBlockMap->m_nBlockOffset);
		nFileFreeSize += lpBlockHead->m_nBlockSize;
		nFreeBlockMapOffset = lpBlockMap->m_nNextOffset;
	}

	nFileUseSize   = nFileTotalSize - nFileFreeSize;
	return MF_OK;
}

/************************************************************************
		功能说明:
			设置对象信息
		参数说明：
			lpExecutePlan：执行计划
			nIndexID：对象ID
			nDataNum：记录数
************************************************************************/
void CMemoryBTreeFile::SetObjectData(LPEXECUTEPLANBSON lpExecutePlan, int nIndexID, long long nDataNum)
{
	int i;
	CExecutePlanCriticalPtr cs(CSystemManage::instance().GetBTreeFileCritical(), lpExecutePlan);
	try
	{
		for(i = 0; i < MAX_OBJECT_NUM; i++)
		{
			if(m_lpMemoryFileHead->m_stFileObjectData[i].m_nID == nIndexID)
			{
				m_lpMemoryFileHead->m_stFileObjectData[i].m_nFinishedTimestamp = lpExecutePlan->m_nTimestamp;
				m_lpMemoryFileHead->m_stFileObjectData[i].m_nRecordNum += nDataNum;
			}
		}
	}
	catch (...)
	{
		Trace("CMemoryFile::SetObjectData", MF_TRACE_LEVEL_FAILED, 120001001, "设置对象信息异常，错误码：%d", GetLastError());
	}
}

/************************************************************************
		功能说明：
			获取子索引条件的索引范围
		参数说明：
			lpSubIndexPlan：子索引条件
************************************************************************/
int CMemoryBTreeFile::GetIndexScanScope(LPSUBINDEXPLAN lpSubIndexPlan)
{
	BYTE bFielNum;
	int nRet, nRootNo;
	LPBYTE lpRoot, bFildType;

	//根据nIndexID值在ROOT中找到索引的入口地址
	nRet = GetRootNo(NULL, nRootNo, lpSubIndexPlan->m_nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(nRootNo == 0)
	{
		return MF_OK;
	}
	else
	{
		lpRoot = ConvertBlockNotoAddr(nRootNo);
		if(NULL == lpRoot)
		{
			//没有找到RootNO对应的根节点
			return MF_BTREEINDEX_INVALIDROOTNO_ERROR;
		}
	}

	//获取字段信息
	nRet = GetFieldInfo(NULL, lpSubIndexPlan->m_nIndexID, bFielNum, bFildType);
	if(nRet != MF_OK)
	{
		return MF_OK;
	}

	//创建CMemoryMultiNum对象,并调用DeleteIndex进行索引删除操作
	switch(lpSubIndexPlan->m_bIndexType)
	{
	case MF_SYS_INDEXTYPE_TREE_INT:
	case MF_SYS_INDEXTYPE_TREE_BIGINT:
	case MF_SYS_INDEXTYPE_TREE_DOUBLE:
	case MF_SYS_INDEXTYPE_TREE_MULTINUM:
		{
			CMemoryMultiNum stMultiNum;
			stMultiNum.SetNodeAddr(lpRoot, lpSubIndexPlan->m_nIndexID, bFielNum, bFildType, this);
			nRet = stMultiNum.GetIndexScanScope(lpSubIndexPlan);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	case MF_SYS_INDEXTYPE_FUZZY_CHAR:
	case MF_SYS_INDEXTYPE_TREE_MULTISTR:
		{
			CMemoryMultiStr stMultiStr;
			//对pKey进行预处理去掉前后百分号
			RemovePercent(lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1.m_lpszValue, lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1.m_nStrLen, lpSubIndexPlan->m_ppCondition[0]->m_stIndexCondition.m_varCondition1);
			stMultiStr.SetNodeAddr(lpRoot, lpSubIndexPlan->m_nIndexID, bFielNum, bFildType, this);
			nRet = stMultiStr.GetIndexScanScope(lpSubIndexPlan);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	default:
		return MF_BTREEINDEX_INVALIDINDEXTYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取索引的最大关键字值和最小关键字值
		参数说明：
			lpSubIndexPlan：子索引条件
			varMaxKey：最大关键字值
			varMinKey：最小关键字值
************************************************************************/
int CMemoryBTreeFile::GetIndexRange(LPSUBINDEXPLAN lpSubIndexPlan, VARDATA& varMaxKey, VARDATA& varMinKey)
{
	BYTE bFielNum;
	int nRet, nRootNo;
	LPBYTE lpRoot, bFildType;

	//根据nIndexID值在ROOT中找到索引的入口地址
	nRet = GetRootNo(NULL, nRootNo, lpSubIndexPlan->m_nIndexID);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(nRootNo == 0)
	{
		return MF_OK;
	}
	else
	{
		lpRoot = ConvertBlockNotoAddr(nRootNo);
		if(NULL == lpRoot)
		{
			//没有找到RootNO对应的根节点
			return MF_BTREEINDEX_INVALIDROOTNO_ERROR;
		}
	}

	//获取字段信息
	nRet = GetFieldInfo(NULL, lpSubIndexPlan->m_nIndexID, bFielNum, bFildType);
	if(nRet != MF_OK)
	{
		return MF_OK;
	}

	//创建CMemoryMultiNum对象,并调用DeleteIndex进行索引删除操作
	switch(lpSubIndexPlan->m_bIndexType)
	{
	case MF_SYS_INDEXTYPE_TREE_INT:
	case MF_SYS_INDEXTYPE_TREE_BIGINT:
	case MF_SYS_INDEXTYPE_TREE_DOUBLE:
	case MF_SYS_INDEXTYPE_TREE_MULTINUM:
		{
			CMemoryMultiNum stMultiNum;
			stMultiNum.SetNodeAddr(lpRoot, lpSubIndexPlan->m_nIndexID, bFielNum, bFildType, this);
			nRet = stMultiNum.GetIndexRange(lpSubIndexPlan->m_nIndexID, varMaxKey, varMinKey);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	case MF_SYS_INDEXTYPE_FUZZY_CHAR:
	case MF_SYS_INDEXTYPE_TREE_MULTISTR:
		{
			CMemoryMultiStr stMultiStr;
			stMultiStr.SetNodeAddr(lpRoot, lpSubIndexPlan->m_nIndexID, bFielNum, bFildType, this);
			nRet = stMultiStr.GetIndexRange(lpSubIndexPlan->m_nIndexID, varMaxKey, varMinKey);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		break;
	default:
		return MF_BTREEINDEX_INVALIDINDEXTYPE_ERROR;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			备份文件数据
		参数说明：
			lpBuffer：文件头Buffer
			nBufferSize：Buffer大小
************************************************************************/
int CMemoryBTreeFile::BackUpFileData(LPBYTE lpBuffer, int nBufferSize)
{
	//上锁
	int nHeadBufferSize;
	LPBASEFILEBLOCKMAPHEAD lpMasterBaseFileBlockMapHead, lpSlaveBaseFileBlockMapHead;

	CExecutePlanCriticalPtr csFile(CSystemManage::instance().GetBTreeFileCritical(), NULL);
	CExecutePlanCriticalPtr csMap(CSystemManage::instance().GetBTreeFileBlockMapCritical(), NULL);
	if(m_lpMemoryFileHead->m_nFileHeaderSize > nBufferSize)
	{
		return MF_FLASHBACK_INVALID_BUFFER_SIZE;
	}
	else
	{
		//先备份文件头
		memcpy(lpBuffer, m_lpFileAddr, m_lpMemoryFileHead->m_nFileHeaderSize);
	}
	

	lpMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nBlockMapStartOffset);
	lpSlaveBaseFileBlockMapHead  = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + m_lpMemoryFileHead->m_nBlockMapStartOffset + m_lpMemoryFileHead->m_nBlockMapSize);
	while(TRUE)
	{
		nHeadBufferSize = sizeof(BASEFILEBLOCKMAPHEAD) + m_lpMemoryFileHead->m_nBlockMapStructSize*(lpMasterBaseFileBlockMapHead->m_nBlockMapNum - 1);

		//检测映射表大小
		if (nHeadBufferSize > (DWORD)m_lpMemoryFileHead->m_nBlockMapSize)
		{
			return MF_FLASHBACK_INVALID_MAP_SIZE;
		}

		memcpy((LPBYTE)lpSlaveBaseFileBlockMapHead, (LPBYTE)lpMasterBaseFileBlockMapHead, m_lpMemoryFileHead->m_nBlockMapSize);
		if(lpMasterBaseFileBlockMapHead->m_nNextBlockMapOffset != 0)
		{
			lpMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + lpMasterBaseFileBlockMapHead->m_nNextBlockMapOffset);
			lpMasterBaseFileBlockMapHead = (LPBASEFILEBLOCKMAPHEAD)(m_lpFileAddr + lpMasterBaseFileBlockMapHead->m_nNextBlockMapOffset + m_lpMemoryFileHead->m_nBlockMapSize);
		}
		else
		{
			break;
		}
	}
	return MF_OK;
}