﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#define SET_RECORDSECTION_ARRAY
class CInsertBson
{
public:
	CInsertBson(CServiceBson* stBson);
	~CInsertBson();
private:
	CServiceBson* m_pBson;

	LPBYTE		  m_lpBuffer;	
	UINT		  m_nBufferSize;		
	UINT		  m_nDataSize;			

private:
	/************************************************************************
		功能说明：
			为记录分配空间
	************************************************************************/
	int AllocRecordBuffer(UINT nBufferLen);

	/************************************************************************
		功能说明：
			从BSON缓存中分配空间
	************************************************************************/
	int AllocFromBsonBuffer(UINT nLen, UINT &nOffset, LPBYTE &lpAddr);

	/************************************************************************
		功能说明：
			将字段值写入指定位置
	************************************************************************/
	int WriteFieldData(MF_SYS_FIELDTYPE bFieldType, BYTE bFieldNo, VARDATA &varData, LPBYTE lpAddr = NULL);

	/************************************************************************
		功能说明：
			插入字符串类型数据
	************************************************************************/
	BOOL AppendBuffer(void* pData, int nLen);

public:
	/************************************************************************
		功能说明：
			计算Bson长度
	************************************************************************/
	static int GetBsonLen(LPOBJECTDEF lpObjectInfo, LPVARDATA lpDataArray, MF_RECORD_TYPE bRecordTpye);
	static int GetBsonLen(LPOBJECTDEF lpObjectInfo, LPXMLFIELDBSON* lpFieldBsonMap, MF_RECORD_TYPE bRecordTpye);

	/************************************************************************
		功能说明：
			创建记录Bson
	************************************************************************/
	int BuildBson(LPBASESTEPPARAM lpParam, LPOBJECTDEF lpObjectInfo,LPEXECUTEFIELDBSON* lpFieldBsonMap, LPVARDATA lpDataArray, RECORDHEAD& stuRecordHead);
	int BuildBson(LPBASESTEPPARAM lpParam, LPOBJECTDEF lpObjectInfo, LPXMLFIELDBSON* lpFieldBsonMap, RECORDHEAD& stuRecordHead);

};