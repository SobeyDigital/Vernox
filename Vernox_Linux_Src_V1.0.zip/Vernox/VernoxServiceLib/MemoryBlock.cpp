﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryBlock.h"
#include "FunctionManager.h"
#include "MemoryHashFile.h"
#include "MemoryFile.h"

#define DATA_STATUS_EXIST	0
#define DATA_STATUS_REMOVE	1
#define DATA_STATUS_DELETE	2

CMemoryBlock::CMemoryBlock(void)
{
	m_lpBlockAddr = NULL;
	m_lpBlockHead = NULL;
	m_lpBlockBody = NULL;
	m_pFile		  = NULL;
}

CMemoryBlock::~CMemoryBlock(void)
{
}
/************************************************************************
		功能说明：
			实现二分法
		参数说明:
			nInnerNo：数据的内部编号
		返回值说明:
			返回nInnerNo对应数据所在的位置(位置是指数据所在的顺序)
		特别说明：
			如果没有查找到nInnerNo对应数据则返回0
************************************************************************/
short CMemoryBlock::BinarySearch(short nInnerNo)
{
	int low,high,mid;
	LPBLOCKDATASTRUCT lpDataAddr;

	low  = 0;									
	high = m_lpBlockHead->m_nDataNum - 1;		
	mid  = 0;									
	//开始折半查找
	while(low <= high)
	{
		mid = (low + high) / 2;
		lpDataAddr =(LPBLOCKDATASTRUCT)(m_lpBlockBody + mid * m_lpBlockHead->m_nBlockDataStructSize);			//特别注意数据的位置mid * 数据的长度DATASIZE得到的是数据相对于块体的偏移量
		if(nInnerNo < (short)lpDataAddr->m_nInnerNo)
		{
			high = mid - 1;
		}
		else if(nInnerNo > (short)lpDataAddr->m_nInnerNo)
		{
			low  = mid + 1;
		}
		else
		{
			return mid;
		}
	}
	return 0;							
}

/************************************************************************
		功能说明：
			将nDataID转换成定长数据的地址指针
		参数说明：
			nDataID:数据唯一编号
		返回值说明：
			转换出来的地址，如果为NULL表示转换失败
		特别说明：
			nDataID中包括块号、文件编号、块内编号。转换时应校验是否本块编号，然后查找具体位置。
			查找位置的方法为，第一遍使用计算应该位置进行查找（只要未经过整理的数据块，命中率非常高），第二此以第一次找的点进行折半查找处理，直到找到正确数据为止。
			注意：块内的数据在定长数据放置部分，必须按照从小到大的顺序排列。
************************************************************************/
LPBYTE CMemoryBlock::ConvertDataIDtoDataAddr(long long nDataID)
{
	short nInnerPos, nDataPos;
	LPBLOCKDATASTRUCT lpDataAddr;
		
	nInnerPos = (short)GetInnerNoFromDataID(nDataID);	//从DataID中获取内部编号，然后直接转换成short类型，即位置	
	if(nInnerPos == 0)
	{
		return NULL;
	}
	lpDataAddr = (LPBLOCKDATASTRUCT)(m_lpBlockBody +  (nInnerPos-1) * m_lpBlockHead->m_nBlockDataStructSize);	//假设该数据的内部编号就是数据所在位置，计算其相对于块体的偏移，并获得该数据的位置指针
	
	//根据innerNo检验nInnerPos指向的是否是nDataID对应的定长数据
	if((short)lpDataAddr->m_nInnerNo == nInnerPos)
	{
		return (LPBYTE)lpDataAddr;						//校验成功则返回
	}
	else
	{
		//失败则用二分法进行查找,得到innerNo对应数据的位置
		nDataPos =  BinarySearch(nInnerPos);
		
		//将数据的位置转换成数据的地址并返回
		if(0 != nDataPos)
		{
			lpDataAddr = (LPBLOCKDATASTRUCT)(m_lpBlockBody +  nDataPos * m_lpBlockHead->m_nBlockDataStructSize);
			if((short)lpDataAddr->m_nInnerNo == nInnerPos)
			{
				return m_lpBlockBody + nDataPos * m_lpBlockHead->m_nBlockDataStructSize;	
			}
		}
	}
	return NULL;										//没有找到返回NULL
}

/************************************************************************
		功能说明：
			在变长数据头部增加一条数据块
		参数说明：
			nSize：需分配的内存块大小
			nAllocSize:实际分配的空间大小
		返回值说明：
			分配出来的内存的偏移,如果为0表示分配失败(这里将原来的指针返回类型，修改为偏移量，是为了方便以后使用)
		特别说明：
			新增变长数据，在向内存块中插入一条新数据和数据扩充时都需要使用
			这里的内存大小需要做如下几个处理，第一、内存按32字节整数倍进行多分配，第二、传入需要分配的内存是没有计算每一小块内存需要的头信息结构体，所以申请时需要把这个加上；
			定长数据直接位于块头后面，这儿在分配过程中需要判断块头中记录的定长和变长数据偏移，计算出是否能分配出足够的内存，如果不能则返回失败；
			如果分配成功，则在函数内部自动移动变长数据偏移。
************************************************************************/
int CMemoryBlock::AllocBlockVarData(int nSize, int& nAllocSize)
{
	int nFreeMemorySize, nVarDataHeadSize;
	LPBLOCKVARDATASTRUCT lpVarDataInsertAddr;

	nAllocSize	     = nSize;
	nVarDataHeadSize = sizeof(BLOCKVARDATASTRUCT) - sizeof(BYTE);
	//判断是否有足够的空间可供分配
	//如果空间足够则修改Block头的相关参数，并返回数据插入位置偏移
	//否则分配失败，返回0
	nFreeMemorySize  = m_lpBlockHead->m_nVarDataInsertOffset - m_lpBlockHead->m_nDataInsertOffset;				//计算块内空区的大小(变长数据偏移 - 定长数据偏移)
	nAllocSize += nVarDataHeadSize;													//将变长数据的长度 + 变长数据头，并且预留一个字节存放结束符
	nAllocSize = (nAllocSize/32 + 1) * 32;											//计算需要分配的内存大小,为32字节的整数倍
	
	if(nFreeMemorySize > nAllocSize)
	{
		m_lpBlockHead->m_nVarDataInsertOffset -= nAllocSize;						//修改变长数据插入位置偏移，注意变长数据内存块的分配是从块尾开始

		//初始化变长数据头
		lpVarDataInsertAddr = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + m_lpBlockHead->m_nVarDataInsertOffset);	//m_nVarDataInsertOffset定义的是相对于块头的偏移量
		lpVarDataInsertAddr->m_nActualLength = nSize;								
		lpVarDataInsertAddr->m_nDataLength	 = nAllocSize - nVarDataHeadSize;
		lpVarDataInsertAddr->m_nNextOffset	 = 0;
		lpVarDataInsertAddr->m_nDataFlag	 = MAKEHEADFLAG('S','B','B','V');		
		
		return m_lpBlockHead->m_nVarDataInsertOffset;
	}
	return 0;																		//分配失败返回0
}

/************************************************************************
		功能说明：
			在内存空间中分配一个定长数据空间和变长数据空间(在插入一条新数据的时候使用)
		参数说明：
			nSize：需分配的内存块大小(变长数据的大小)
			nDataID：数据ID
		返回值说明：
			返回定长数据的内存地址,如果为NULL表示分配失败
		特别说明：
			先插入变长数据，如果变长数据插入成功，则直接插入定长数据(由于定长数据占用空间很小，所以无需判断是否有足够的空间进行插入)
			注意：为什么要把AllocBlockNewData拆分成分AllocBlockVarData和AllocBlockData两个函数，因为在做数据修改的时候只会调用AllocBlockVarData函数
************************************************************************/
LPBYTE CMemoryBlock::AllocBlockNewData(int nSize, long long nDataID)
{
	short nDataPos;
	LPBLOCKDATASTRUCT lpDataAddr;
	LPBLOCKVARDATASTRUCT lpVarDataAddr;
	int nInnerNo, nDataOffset, nVarDataOffset, nAllocSize;

	//分配空间给变长数据部分
	nVarDataOffset = AllocBlockVarData(nSize, nAllocSize);
	if(0 == nVarDataOffset)
	{
		return NULL;
	}

	//分配空间给定长数据部分
	if(nDataID == 0)
	{
		return NULL;
	}
	else
	{
		//从指定位置分配定长数据
		nInnerNo = GetInnerNoFromDataID(nDataID);
		if(nInnerNo == 0)
		{
			return NULL;
		}
		nDataPos = short(nInnerNo);
		if((short)m_lpBlockHead->m_nInnerMaxNo <= nDataPos)
		{
			m_lpBlockHead->m_nInnerMaxNo = nInnerNo + 1;
		}		

		nDataOffset = sizeof(BLOCKHEAD) + (nDataPos-1) * m_lpBlockHead->m_nBlockDataStructSize;
		if(nDataOffset > m_lpBlockHead->m_nDataInsertOffset)
		{
			m_lpBlockHead->m_nDataInsertOffset = nDataOffset;
		}
		lpDataAddr  = (LPBLOCKDATASTRUCT)(m_lpBlockAddr +  nDataOffset);
		memset(lpDataAddr, 0, sizeof(BLOCKDATASTRUCT));
	

		lpVarDataAddr = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + nVarDataOffset);				//获得变长数据指针
		
		lpDataAddr->m_nInnerNo		 = nInnerNo;				
		lpDataAddr->m_nVarDataLength = lpVarDataAddr->m_nActualLength;						
		lpDataAddr->m_nVarDataOffset = nVarDataOffset;

		//nDataPos要和m_nDataNum匹配
		while(nDataPos - 1 > m_lpBlockHead->m_nDataNum)
		{
			LPBLOCKDATASTRUCT lpDataAddr2;

			nDataOffset = sizeof(BLOCKHEAD) + m_lpBlockHead->m_nDataNum * m_lpBlockHead->m_nBlockDataStructSize;
			lpDataAddr2 = (LPBLOCKDATASTRUCT)(m_lpBlockAddr +  nDataOffset);
			memset(lpDataAddr2, 0, sizeof(BLOCKDATASTRUCT));

			lpDataAddr2->m_nInnerNo = m_lpBlockHead->m_nDataNum;
			m_lpBlockHead->m_nDataNum++;
		}
		return (LPBYTE)lpDataAddr;
	}																						//返回定长数据部分的指针
}

/************************************************************************
		功能说明：
			获取变长数据（不考虑行迁移）
		参数说明：
			lpDataAddr：定长数据
			lpRecordInfo：记录数据
			lpVarDataAddr：变长数据
************************************************************************/
int CMemoryBlock::GetVarData(LPBLOCKDATASTRUCT lpDataAddr, LPRECORDDATAINFO lpRecordInfo, LPBLOCKVARDATASTRUCT& lpVarDataAddr, int &nNextOffset)
{
	LPBYTE lpRollBackData;
	long long nRollBackDataID;
	int nRet, nRollBackDataLen;
	nNextOffset		= 0;
	nRollBackDataID = lpDataAddr->m_nNextDataID;
	
	if(lpRecordInfo->m_bDataPosition == MF_DATAPOSITION_LOCAL)
	{
		//直接从本地获取数据
		if(lpDataAddr->m_bDataStatus == DATA_STATUS_DELETE)
		{
			lpVarDataAddr					= NULL;
			lpRecordInfo->m_nRecordLen		= 0;
			lpRecordInfo->m_lpRecordBuffer  = NULL;
		}
		else
		{
			lpVarDataAddr = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpDataAddr->m_nVarDataOffset);
			lpRecordInfo->m_nRecordLen		= lpDataAddr->m_nVarDataLength;
			lpRecordInfo->m_lpRecordBuffer	= lpVarDataAddr->m_lpDataContent;
			nNextOffset						= lpVarDataAddr->m_nNextOffset;
		}
		lpRecordInfo->m_bAcutalDataPosition = MF_DATAPOSITION_LOCAL;
	}
	else if(lpRecordInfo->m_bDataPosition == MF_DATAPOSITION_ROLLBACK)
	{
		//直接从回滚区获取数据
		lpRollBackData   = NULL;
		nRollBackDataLen = 0;
		nRet = CSystemManage::instance().GetRollBackData(nRollBackDataID, lpRecordInfo->m_nTimestamp, lpRollBackData, nRollBackDataLen);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpVarDataAddr = (LPBLOCKVARDATASTRUCT)lpRollBackData;
		lpRecordInfo->m_nRecordLen			= nRollBackDataLen - (sizeof(BLOCKVARDATASTRUCT) - sizeof(BYTE));
		lpRecordInfo->m_lpRecordBuffer		= lpVarDataAddr->m_lpDataContent;
		nNextOffset							= lpVarDataAddr->m_nNextOffset;
		lpRecordInfo->m_bAcutalDataPosition = MF_DATAPOSITION_ROLLBACK;
	}
	else
	{
		if(lpDataAddr->m_nTimestamp == 0 || (lpRecordInfo->m_nTimestamp == 0 && lpRecordInfo->m_lpTransactionArray == NULL))
		{
			if(lpDataAddr->m_bDataStatus == DATA_STATUS_DELETE)
			{
				lpVarDataAddr					= NULL;
				lpRecordInfo->m_nRecordLen		= 0;
				lpRecordInfo->m_lpRecordBuffer  = NULL;
			}
			else
			{
				lpVarDataAddr = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpDataAddr->m_nVarDataOffset);
				lpRecordInfo->m_lpRecordBuffer	= lpVarDataAddr->m_lpDataContent;
				lpRecordInfo->m_nRecordLen		= lpDataAddr->m_nVarDataLength;
				nNextOffset						= lpVarDataAddr->m_nNextOffset;
			}
			lpRecordInfo->m_bAcutalDataPosition = MF_DATAPOSITION_LOCAL;
			return MF_OK;
		}
		
		//比较当前时间戳和数据的时间戳，判断本地数据是否有效
		if((lpDataAddr->m_nTimestamp > lpRecordInfo->m_nTimestamp) || (lpRecordInfo->m_lpTransactionArray != NULL && !lpRecordInfo->m_lpTransactionArray->CheckDataVisiable(lpDataAddr->m_nTimestamp)))
		{
			//从回滚区中读取数据
			nRet = CSystemManage::instance().GetRollBackData(nRollBackDataID, lpRecordInfo->m_nTimestamp, lpRollBackData, nRollBackDataLen);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			lpVarDataAddr = (LPBLOCKVARDATASTRUCT)lpRollBackData;
			lpRecordInfo->m_nRecordLen			= nRollBackDataLen - (sizeof(BLOCKVARDATASTRUCT) - sizeof(BYTE));
			lpRecordInfo->m_lpRecordBuffer		= lpVarDataAddr->m_lpDataContent;
			nNextOffset							= lpVarDataAddr->m_nNextOffset;
			lpRecordInfo->m_bAcutalDataPosition = MF_DATAPOSITION_ROLLBACK;
		}
		else
		{	
			//读取本地数据
			//校验地址所对应的数据是否被删除
			if(lpDataAddr->m_bDataStatus == DATA_STATUS_DELETE)
			{
				//数据可见说明事物已经提交，那么如果数据被删除且事物已经提交，则该数据就不能被取出
				lpVarDataAddr					= NULL;
				lpRecordInfo->m_nRecordLen		= 0;
				lpRecordInfo->m_lpRecordBuffer  = NULL;
			}
			else
			{
				lpRecordInfo->m_nRecordLen		 = lpDataAddr->m_nVarDataLength;
				lpVarDataAddr = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpDataAddr->m_nVarDataOffset);
				lpRecordInfo->m_lpRecordBuffer   = lpVarDataAddr->m_lpDataContent;
				nNextOffset						 = lpVarDataAddr->m_nNextOffset;
			}
			lpRecordInfo->m_bAcutalDataPosition = MF_DATAPOSITION_LOCAL;
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			数据备份
		参数说明：
			lpDataAddr：原始定长数据
			nTimestamp:时间戳
************************************************************************/
int CMemoryBlock::DataBackup(long long nDataID, long long nTimestamp)
{
	int nDataHeadSize;
	long long nRollBackDataID;
	LPBLOCKDATASTRUCT lpDataAddr;
	LPBYTE lpRollBackAddr, lpInsertPos;
	LPBLOCKVARDATASTRUCT lpVarDataAddr, lpVarDataHead;

	lpDataAddr = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(nDataID);
	if(lpDataAddr == NULL)
	{
		return MF_MEMORYFILE_READDATA_INVALIDDATAID_ERROR;
	}

	lpRollBackAddr  = NULL;
	nDataHeadSize   = sizeof(BLOCKVARDATASTRUCT) - sizeof(BYTE);
	nRollBackDataID = CSystemManage::instance().InsertRollBackData(lpRollBackAddr, lpDataAddr->m_nVarDataLength + nDataHeadSize, nTimestamp, lpDataAddr->m_nNextDataID);
	lpDataAddr->m_nNextDataID = nRollBackDataID;
	lpInsertPos		= lpRollBackAddr;

	lpVarDataAddr	= (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpDataAddr->m_nVarDataOffset);			//获得变长数据
	//1.首先备份变长数据头
	memcpy(lpInsertPos, (LPBYTE)lpVarDataAddr, nDataHeadSize);
	lpVarDataHead	= (LPBLOCKVARDATASTRUCT)lpInsertPos;
	lpVarDataHead->m_nNextOffset	= 0;
	lpVarDataHead->m_nActualLength	= 0;
	lpVarDataHead->m_nDataLength	= lpDataAddr->m_nVarDataLength;

	lpInsertPos		+= nDataHeadSize;
	//2.遍历变长数据链表，找到对应的数据进行读取
	while(TRUE)
	{
		memcpy(lpInsertPos, lpVarDataAddr->m_lpDataContent, lpVarDataAddr->m_nActualLength);	
		lpInsertPos += lpVarDataAddr->m_nActualLength;	
		lpVarDataHead->m_nActualLength += lpVarDataAddr->m_nActualLength;
		//判断变长数据链表是否遍历完毕，如果遍历完毕则跳出循环
		if(!lpVarDataAddr->m_nNextOffset)
		{
			break;				//遍历完毕跳出循环
		}

		//将变长数据指针移动到下一个变长数据结点
		lpVarDataAddr = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpVarDataAddr->m_nNextOffset);
		if(!lpVarDataAddr->m_nActualLength)
		{	
			break;				//如果变长数据为空则跳出循环(链表后续结点的变长数据肯定也为空)	
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取回滚区中的数据，以条为单位
			nDataID：数据ID
			nDataLen：数据长度
			pData:实际数据
			nTimestamp：时间戳
************************************************************************/
int CMemoryBlock::GetRollBackData(long long nDataID, int& nDataLen, LPBYTE& lpData, long long nTimestamp)
{
	LPBYTE lpBuffer;
	int nRet, nBufferLen;	
	LPBLOCKDATASTRUCT lpDataAddr;
	LPBLOCKVARDATASTRUCT lpVarDataAddr;

	lpData		= NULL;
	nDataLen	= 0;
	//1.根据DataID获得定长数据的地址指针和变长数据的地址指针
	lpDataAddr = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(nDataID);						//根据DataID获得定长数据的地址
	if(lpDataAddr == NULL)
	{
		return MF_MEMORYFILE_READDATA_INVALIDDATAID_ERROR;
	}
	if(lpDataAddr->m_bDataStatus == DATA_STATUS_REMOVE)
	{
		CMemoryBlock* pBlock;
		nDataID = lpDataAddr->m_nNextDataID;
		pBlock  = m_pFile->ConvertDataIDtoBlockObject(nDataID);
		if(pBlock == NULL)
		{
			return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
		}
		return pBlock->GetRollBackData(nDataID, nDataLen, lpData, nTimestamp);
	}

	//2.获取回滚区数据
	if(lpDataAddr->m_nNextDataID == 0)
	{
		return MF_OK;
	}
	nRet = CSystemManage::instance().GetRollBackData(lpDataAddr->m_nNextDataID, nTimestamp, lpBuffer, nBufferLen);
	if(nRet != MF_OK)
	{
		//返回本地数据
		lpVarDataAddr = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpDataAddr->m_nVarDataOffset);

		lpData	 = lpVarDataAddr->m_lpDataContent;
		nDataLen = lpVarDataAddr->m_nActualLength;
	}
	else
	{
		lpVarDataAddr = (LPBLOCKVARDATASTRUCT)lpBuffer;

		lpData	 = lpVarDataAddr->m_lpDataContent;
		nDataLen = lpVarDataAddr->m_nActualLength;

	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			提供给Update的回滚		
		参数说明:
			nDataID:数据ID
			nTimestamp：时间戳
************************************************************************/
int CMemoryBlock::UpdateRollBack(long long nDataID, long long nTimestamp)
{
	LPBYTE lpUpdatePos, lpBuffer;
	LPBLOCKDATASTRUCT lpDataAddr;
	LPBLOCKVARDATASTRUCT lpVarDataAddr;
	int nRet, nNewDataLength, nInsertDataLength, nTempLen, nBufferLen;													

	//1.根据DataID获得定长数据的地址指针和变长数据的地址指针
	lpDataAddr = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(nDataID);						//根据DataID获得定长数据的地址
	if(lpDataAddr == NULL)
	{
		return MF_MEMORYFILE_UPDATEDATA_INVALIDDATAID_ERROR;
	}
	
	//2.获取回滚区数据
	nRet = CSystemManage::instance().GetRollBackData(lpDataAddr->m_nNextDataID, nTimestamp, lpBuffer, nBufferLen);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpVarDataAddr	= (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpDataAddr->m_nVarDataOffset);	//获得变长数据的地址																		
	//3.执行具体的修改操作
	nNewDataLength	= ((LPBLOCKVARDATASTRUCT)lpBuffer)->m_nActualLength;					//获取新数据长度
	lpUpdatePos		= ((LPBLOCKVARDATASTRUCT)lpBuffer)->m_lpDataContent;						//待更新数据的位置
	nInsertDataLength = nNewDataLength;														//待更新数据的长度
	
	//遍历原始数据的变长数据链表进行覆盖操作
	while(TRUE)
	{
		nTempLen = lpVarDataAddr->m_nDataLength;											//变长数据中内容区的长度
		//根据待更新数据的长度判断执行何种操作
		if(!nInsertDataLength)								
		{
			//如果待更新数据的长度为0，说明数据修改已经完毕，那么如果此时对于链表的遍历还没有完毕，则应该将后续链表清空
			memset(lpVarDataAddr->m_lpDataContent,0,nTempLen);
			lpVarDataAddr->m_nActualLength = 0;
		}
		else if(nInsertDataLength <= nTempLen)
		{
			//如果待更新数据的长度<=变长数据中内容区的长度，则直接插入
			memcpy(lpVarDataAddr->m_lpDataContent,lpUpdatePos,nInsertDataLength);
			lpVarDataAddr->m_nActualLength = nInsertDataLength;								//修改变长数据的实际长度
			nInsertDataLength = 0;															//将待更新数据的长度设为0
		}
		else
		{
			//如果待更新数据的长度>变长数据中内容区的长度,则将该数据的一部分插入该空间
			memcpy(lpVarDataAddr->m_lpDataContent,lpUpdatePos,nTempLen);
			lpVarDataAddr->m_nActualLength = nTempLen;					  					//修改变长数据的实际长度
			lpUpdatePos += nTempLen;										  				//修改新数据的更新位置指针
			nInsertDataLength -= nTempLen;								  					//修改待更新数据的长度

			//判断链表是否遍历完毕，如果链表已经遍历完毕，则应该分配一块变长数据空间存放剩余数据
			if(!lpVarDataAddr->m_nNextOffset)
			{
				//回滚更新操作一定不会发生记录增长，所以出现这种情况说明出现了异常
				return MF_MEMORYFILE_UPDATEROLLBACK_BUFFERSIZE_ERROR;

			}
		}

		//判断链表是否遍历完毕，如果链表已经遍历完毕，则跳出循环
		if(!(lpVarDataAddr->m_nNextOffset))
		{
			break;				//如果遍历到链表末尾，则跳出循环
		}

		//如果链表没有遍历完毕则将变长数据指针移动到下一个节点
		lpVarDataAddr = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpVarDataAddr->m_nNextOffset);
	}

	//数据更新操作完毕，将修改定长数据中变长数据的实际长度
	lpDataAddr->m_nVarDataLength = nNewDataLength;
	TimestampUpdate(nTimestamp);			//更新时间戳	
	return MF_OK;

}

/************************************************************************
		功能说明：
			提供给Delete的回滚
		参数说明:
			nDataID:数据ID
			nTimestamp：时间戳
************************************************************************/
int CMemoryBlock::DeleteRollBack(long long nDataID, long long nTimestamp)
{
	LPBLOCKDATASTRUCT lpDataAddr;
	//1.根据DataID获得定长数据的地址指针和变长数据的地址指针
	lpDataAddr = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(nDataID);						//根据DataID获得定长数据的地址
	if(lpDataAddr == NULL)
	{
		return MF_MEMORYFILE_DELETEDATA_INVALIDDATAID_ERROR;
	}

	//2.去掉删除标志
	lpDataAddr->m_bDataStatus = DATA_STATUS_EXIST;
	TimestampUpdate(nTimestamp);			//更新时间戳	
	return MF_OK;
}
/************************************************************************
		功能说明：
			提供给Insert的回滚
		参数说明：
			nDataID：数据ID
			nTimestamp：时间戳
************************************************************************/
int CMemoryBlock::InsertRollBack(long long nDataID, long long nTimestamp)
{
	LPBLOCKDATASTRUCT lpDataAddr;
	//1.根据DataID获得定长数据的地址指针和变长数据的地址指针
	lpDataAddr = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(nDataID);						//根据DataID获得定长数据的地址
	if(lpDataAddr == NULL)
	{
		return MF_MEMORYFILE_INSERTDATA_INVALIDDATAID_ERROR;
	}
	//插入回滚不会出现行迁移
	//2.添加删除标志
	lpDataAddr->m_bDataStatus = DATA_STATUS_DELETE;
	TimestampUpdate(nTimestamp);			//更新时间戳	
	return MF_OK;
}

/************************************************************************
		功能说明：
			锁定块
		参数说明：
			lpExecutePlan：执行计划
			dwMilliseconds：超时时间
************************************************************************/
int CMemoryBlock::LockBlock(LPEXECUTEPLANBSON lpExecutePlan, DWORD dwMilliseconds)
{
	return CSystemManage::instance().LockBlock(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpBlockHead, dwMilliseconds);
}

int CMemoryBlock::LockBlock(LPEXECUTEPLANBSON lpExecutePlan, long long& nDataID, DWORD dwMilliseconds)
{
	LPBLOCKDATASTRUCT lpDataAddr;
	//1.根据DataID获得定长数据的地址指针和变长数据的地址指针
	lpDataAddr = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(nDataID);						//根据DataID获得定长数据的地址
	if(lpDataAddr == NULL)
	{
		return MF_MEMORYFILE_INSERTDATA_INVALIDDATAID_ERROR;
	}
	if(lpDataAddr->m_bDataStatus == DATA_STATUS_REMOVE)
	{
		//2.如果记录发生行迁移，则锁定迁移后的块并返回迁移后的DataID
		nDataID = lpDataAddr->m_nNextDataID;
		return m_pFile->LockBlock(lpExecutePlan, nDataID, dwMilliseconds);
	}
	else
	{
		return CSystemManage::instance().LockBlock(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpBlockHead, dwMilliseconds);
	}
}

/************************************************************************
		功能说明：
			解锁块
		参数说明：
			lpExecutePlan：执行计划
************************************************************************/
void CMemoryBlock::UnLockBlock(LPEXECUTEPLANBSON lpExecutePlan)
{
	CSystemManage::instance().UnLockBlock(lpExecutePlan, (LPBASEBLOCKHEAD)m_lpBlockHead);
}

/************************************************************************
		功能说明：
			计算可回收区域的总大小，用于块内整理预判
************************************************************************/
double CMemoryBlock::FreeMemoryStat()
{
	double dblBlockBodySize;

	dblBlockBodySize = m_lpBlockHead->m_nBlockSize - m_lpBlockHead->m_nBlockHeadSize;
	return m_lpBlockHead->m_nRecyclableSpaceSize / dblBlockBodySize;
}

/************************************************************************
		功能说明：
			计算空闲区与块总大小的比例
		返回值说明:
			返回空闲区与块总大小的比例
		特别说明：
			该函数用于在文件级执行数据插入和数据修改时使用，在文件级进行数据插入和修改后，
			需要判断当前数据块属于可插链表还是属于满块链表(阀值：0.2)
************************************************************************/
double CMemoryBlock::RaitoStat()
{
	double dFreeMemorySize, dBlockBodySize;

	dFreeMemorySize = m_lpBlockHead->m_nVarDataInsertOffset - m_lpBlockHead->m_nDataInsertOffset;			//得到空闲区大小
	dBlockBodySize  = m_lpBlockHead->m_nBlockSize - m_lpBlockHead->m_nBlockHeadSize;						//得到块体使用的大小
	
	return dFreeMemorySize / dBlockBodySize;
}

/************************************************************************
		功能说明：
			判断插入数据后，块是否会满
		参数说明:
			nLen：数据的长度
			nRatio:系数
************************************************************************/
BOOL CMemoryBlock::IsFull(int nSize, double nRatio)
{
	double dblFreeMemorySize, dblAllocSize, dblBlockBodySize;

	dblFreeMemorySize = m_lpBlockHead->m_nVarDataInsertOffset - m_lpBlockHead->m_nDataInsertOffset;	//计算块内空区的大小(变长数据偏移 - 定长数据偏移)
	dblBlockBodySize = m_lpBlockHead->m_nBlockSize - m_lpBlockHead->m_nBlockHeadSize;					//得到块体使用的大小

	nSize += sizeof(BLOCKVARDATASTRUCT);								//将变长数据的长度 + 变长数据头
	dblAllocSize = (nSize/32 + 1) * 32;									//计算需要分配的内存大小,为32字节的整数倍
	dblAllocSize += m_lpBlockHead->m_nBlockDataStructSize;				//加上定长数据部分的大小

	if(dblFreeMemorySize < dblAllocSize)
	{
		return TRUE;
	}
	else
	{
		dblFreeMemorySize -= dblAllocSize;
	}
	return dblFreeMemorySize / dblBlockBodySize <= nRatio;
}

/************************************************************************
		功能说明：
			初始化数据块管理类，让整个实例是可执行的
		参数说明：
			pFilePtr:文件指针
			pBlockAddr：数据块的首地址指针，需要记录在m_pBlockAddr变量中
		特别说明：
			同时还需要把m_lpBlockHead成员变量也初始化出来，便于后续的写入和读取操作。
************************************************************************/
void CMemoryBlock::SetBlockAddr(CBaseMemoryFile* pFilePtr, LPBYTE pBlockAddr)
{
	m_lpBlockAddr = pBlockAddr;							//块指针
	m_lpBlockHead = (LPBLOCKHEAD)m_lpBlockAddr;			//块头指针
	m_lpBlockBody = m_lpBlockAddr + sizeof(BLOCKHEAD);	//块体指针	
	m_pFile = (CMemoryFile*)pFilePtr;
}

/************************************************************************
		功能说明：
			 创建一个内存块，并初始化m_pBlockAddr、m_pBlockHead成员变量
		参数说明：
			nBlockNo:块号
			nBlockSize: 块的总大小
			nObjectID:对象ID
			bFileNo:文件编号
		特别说明：
			在创建一个内存块时，需要初始化块头结构体,根据传入的参数，初始化块结构体信息，为将来写入数据做准备。
************************************************************************/
void CMemoryBlock::InitialBlock(int nObjectID)
{
	m_lpBlockHead->m_nObjectID				= nObjectID;
	m_lpBlockHead->m_nBlockDataStructSize	= sizeof(BLOCKDATASTRUCT);
	m_lpBlockHead->m_nInnerMaxNo			= 1;
	m_lpBlockHead->m_nDataInsertOffset		= sizeof(BLOCKHEAD);
	m_lpBlockHead->m_nBlockHeadSize		    = sizeof(BLOCKHEAD);
	m_lpBlockHead->m_nVarDataInsertOffset	= m_lpBlockHead->m_nBlockSize;
	m_lpBlockHead->m_nDataNum				= 0;	
	m_lpBlockHead->m_nFreeDataOffset		= 0;
	m_lpBlockHead->m_nRecyclableSpaceSize	= 0;
}

/************************************************************************
		功能说明：
			用于进行数据块内存整理。
		特别说明：
			当内存块空间不足时，需要对内存块中的内存碎片进行整理。
			在整理过程中，需要完成两个功能：
			1.变长数据中，如果数据的一部分被放在块中的其他位置，需要将其整理至一块连续的内存区域
			  并将下级指针设置为0
			2.需要修改定长数据中对应变长数据位置的偏移量
		整理原则：
			块内剩余数据小于10%时，启动块内整理预判可回收数据量，可回收大于10%的数据时启动块内整理
		整理方式：
			1.将原块中的数据拷贝到缓存中
			2.用缓存中的数据覆盖原块中的数据
************************************************************************/
int CMemoryBlock::MergeMemory()
{
	LPBYTE lpNewBlock;
	LPBLOCKHEAD lpNewBlockHead;
	LPBLOCKDATASTRUCT lpOldDataPos;
	LPBYTE lpNewVarDataPos,lpNewDataPos, lpInsertPos;	
	LPBLOCKVARDATASTRUCT lpOldVarDataPos, lpNewVarDataHead;
	int i, nNewBlockSize, nSize, nAllocSize, nVarDataHeadSize;

	//1.动态分配一块与块体大小相同缓存
	nNewBlockSize = m_lpBlockHead->m_nBlockSize;									//缓存大小 = 块大小
	lpNewBlock = CSystemManage::instance().AllocTemporaryMem(nNewBlockSize);		//动态分配一块缓存
	if(NULL == lpNewBlock)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	memset(lpNewBlock, 0, nNewBlockSize);											//清空缓存

	//2.初始化新块块头
	lpNewBlockHead = (LPBLOCKHEAD)lpNewBlock;
	memcpy(lpNewBlockHead, m_lpBlockHead, m_lpBlockHead->m_nBlockHeadSize);
	lpNewBlockHead->m_nDataInsertOffset		= sizeof(BLOCKHEAD);
	lpNewBlockHead->m_nVarDataInsertOffset  = nNewBlockSize;
	lpNewBlockHead->m_nDataNum				= 0;
	nVarDataHeadSize						= sizeof(BLOCKVARDATASTRUCT);
	
	//3.遍历原块中的定长数据将块中的数据拷贝到缓存中
	lpOldDataPos = (LPBLOCKDATASTRUCT)m_lpBlockBody;								//原定长数据位置指针
	for(i = 0; i < m_lpBlockHead->m_nDataNum; i++)
	{
		//如果变长数据部分不为空，则遍历变长数据链表，将变长数据复制到缓存
		//遍历完成后，将定长数据部分复制到缓存，并修改其部分数据(如变长数据偏移)
		if(lpOldDataPos[i].m_bDataStatus == DATA_STATUS_EXIST)
		{
			//根据变长数据的实际长度，在新块中分配一块变长数据区域(区域大小为32字节的整数倍)
			nSize				= lpOldDataPos[i].m_nVarDataLength + nVarDataHeadSize;			//将变长数据的长度 + 变长数据头
			nAllocSize			= (nSize / 32 + 1) * 32;										//计算需要分配的内存大小,为32字节的整数倍
			
			lpNewBlockHead->m_nVarDataInsertOffset -= nAllocSize;								//该区域首地址偏移
			lpNewVarDataPos		= lpNewBlock + lpNewBlockHead->m_nVarDataInsertOffset;			//该区域首地址指针
			lpNewVarDataHead	= (LPBLOCKVARDATASTRUCT)lpNewVarDataPos;
			
			//初始化新变长数据的块头	
			lpNewVarDataHead->m_nActualLength	= lpOldDataPos[i].m_nVarDataLength;
			lpNewVarDataHead->m_nDataLength		= nAllocSize - nVarDataHeadSize;
			lpNewVarDataHead->m_nNextOffset		= 0;
			lpNewVarDataHead->m_nDataFlag		= MAKEHEADFLAG('S','B','B','V');
			
			//下面就要将变长数据从原内存块拷贝到新块中
			lpInsertPos		= lpNewVarDataHead->m_lpDataContent;									    //新块中变长数据的插入位置指针
			lpOldVarDataPos = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpOldDataPos[i].m_nVarDataOffset);	//获得原块中变长数据的起始位置指针

			//遍历变长数据链表
			while(TRUE) 
			{
				//将原块的变长数据复制到新块中
				memcpy(lpInsertPos, lpOldVarDataPos->m_lpDataContent, lpOldVarDataPos->m_nActualLength);
				lpInsertPos += lpOldVarDataPos->m_nActualLength;					//移动插入位置指针

				//判断原块的变长数据链表是否遍历完毕
				if(0 == lpOldVarDataPos->m_nNextOffset)
				{
					break;															//遍历完毕跳出循环
				}
				else
				{
					//将变长数据指针移动到下一个变长数据结点
					lpOldVarDataPos = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpOldVarDataPos->m_nNextOffset);
					if(0 == lpOldVarDataPos->m_nActualLength)
					{	
						break;														//如果变长数据为空则跳出循环(链表后续结点的变长数据肯定也为空)	
					}
				}
			}
			
			//变长数据移动完毕,将定长数据写入缓存
			lpNewDataPos = lpNewBlock + lpNewBlockHead->m_nDataInsertOffset;
			memcpy(lpNewDataPos, &lpOldDataPos[i], m_lpBlockHead->m_nBlockDataStructSize);
			((LPBLOCKDATASTRUCT)lpNewDataPos)->m_nVarDataOffset = lpNewBlockHead->m_nVarDataInsertOffset; //将变长数据的实际偏移地址写到定长数据中
		}
		else if(lpOldDataPos[i].m_bDataStatus == DATA_STATUS_DELETE)
		{
			//将定长数据插入空闲定长数据链表，来实现定长数据复用
			lpNewDataPos = lpNewBlock + lpNewBlockHead->m_nDataInsertOffset;
			memset(lpNewDataPos, 0, sizeof(BLOCKDATASTRUCT));
			
			((LPBLOCKDATASTRUCT)lpNewDataPos)->m_nInnerNo			 = lpOldDataPos[i].m_nInnerNo;
			((LPBLOCKDATASTRUCT)lpNewDataPos)->m_nNextDataID		 = lpNewBlockHead->m_nFreeDataOffset;
			((LPBLOCKDATASTRUCT)lpNewDataPos)->m_bDataStatus		 = DATA_STATUS_DELETE;
			lpNewBlockHead->m_nFreeDataOffset						 = lpNewBlockHead->m_nDataInsertOffset;
		}

		//块整理不能使块内未删除数据的DataID发生变化，不论数据是否被删除，定长数据都要递增
		lpNewBlockHead->m_nDataInsertOffset += m_lpBlockHead->m_nBlockDataStructSize;	
		lpNewBlockHead->m_nDataNum++;	
	}

	//数据拷贝完毕，用缓存中的数据覆盖原数据
	memcpy(m_lpBlockAddr, lpNewBlock, nNewBlockSize);
	CSystemManage::instance().FreeTemporaryMem(lpNewBlock);
	lpNewBlock = NULL;

	m_lpBlockHead->m_nRecyclableSpaceSize = 0;

	//修改块头最大编号
	GetMaxInnerNo(m_lpBlockHead->m_nInnerMaxNo);
	return MF_OK;
}

/************************************************************************
		功能说明：
			分配数据ID
		参数说明：
			lpRecordHead：记录头
************************************************************************/
void CMemoryBlock::AllocDataID(LPRECORDHEAD lpRecordHead)
{
	 long long nDataID;
	 LPBLOCKDATASTRUCT lpDataStruct;
	 if(m_lpBlockHead->m_nFreeDataOffset)
	 {
		int nRound;
		lpDataStruct = (LPBLOCKDATASTRUCT)(m_lpBlockAddr + m_lpBlockHead->m_nFreeDataOffset);
		
		//DataID重用时首先从块头获取轮数，然后修改DataID的轮数
		nRound = GetRoundFromInnerNo(m_lpBlockHead->m_nInnerMaxNo);
		lpDataStruct->m_nInnerNo = MakeInnerNo(nRound, lpDataStruct->m_nInnerNo);
		
		nDataID = MakeDataID(m_lpBlockHead->m_bFileNo, m_lpBlockHead->m_nBlockNo, lpDataStruct->m_nInnerNo);
		m_lpBlockHead->m_nFreeDataOffset = (int)lpDataStruct->m_nNextDataID;

		lpRecordHead->m_bNewDataID = 0;
	 }
	 else
	 {
		 nDataID = MakeDataID(m_lpBlockHead->m_bFileNo, m_lpBlockHead->m_nBlockNo, m_lpBlockHead->m_nInnerMaxNo);
		 m_lpBlockHead->m_nInnerMaxNo++;

		 lpRecordHead->m_bNewDataID = 1;
	 }

	 lpRecordHead->m_nDataID = nDataID;
}

/************************************************************************
		功能说明：
			获取最大块内编号
		参数说明：
			nMaxInnerNo：最大块内编号
************************************************************************/
void CMemoryBlock::GetMaxInnerNo(int& nMaxInnerNo)
{
	int nRound;

	nRound = GetRoundFromInnerNo(nMaxInnerNo) + 1;
	if(nRound > 15)
	{
		nRound = 0;
	}
	
	nMaxInnerNo = MakeInnerNo(nRound, nMaxInnerNo);
}

/************************************************************************
		功能说明：
			清理块内数据
************************************************************************/
void CMemoryBlock::ClearBlockData()
{
	LPBYTE lpAddr;
	long long nDataID;
	LPBLOCKDATASTRUCT lpDataAddr;
	int i, nRet, nOffset, nDataLen;
	LPBLOCKVARDATASTRUCT lpVarDataAddr;

	//判断块内是否有活动事务
	if(CSystemManage::instance().CheckTransactionFinish(m_lpBlockHead->m_nTimestamp))
	{
		return;
	}

	lpDataAddr = (LPBLOCKDATASTRUCT)m_lpBlockBody;
	for(i = 0; i < m_lpBlockHead->m_nDataNum; i++)
	{	
		if(!CSystemManage::instance().CheckTransactionFinish(lpDataAddr[i].m_nTimestamp))
		{
			if(lpDataAddr[i].m_bDataStatus == DATA_STATUS_REMOVE)
			{	
				//行迁移
				continue;
			}
			else
			{
				if(lpDataAddr[i].m_nVarDataOffset != 0)
				{
					if(lpDataAddr[i].m_nNextDataID == 0)
					{
						//新插入数据，直接删除
						lpDataAddr[i].m_bDataStatus = DATA_STATUS_DELETE;
					}
					else
					{
						//从回滚区获取数据
						nDataID = MakeDataID(m_lpBlockHead->m_bFileNo, m_lpBlockHead->m_nBlockNo, lpDataAddr[i].m_nInnerNo);
						nRet = GetRollBackData(nDataID, nDataLen, lpAddr, lpDataAddr->m_nTimestamp);
						if(nRet != MF_OK)
						{
							Trace(_T("ClearBlockData"), 0, 40001001, _T("清理块内数据时，从回滚区获取数据失败，错误码：%d"), nRet);
							continue;
						}

						//用回滚区中的数据覆盖原始数据
						nOffset = lpDataAddr[i].m_nVarDataOffset;
						while(nOffset)
						{
							lpVarDataAddr = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + nOffset);
							if(nDataLen == 0)
							{
								lpVarDataAddr->m_nActualLength = 0;
								memset(lpVarDataAddr->m_lpDataContent, 0, lpVarDataAddr->m_nDataLength);
							}
							else
							{
								if(nDataLen > lpVarDataAddr->m_nDataLength)
								{
									lpVarDataAddr->m_nActualLength = lpVarDataAddr->m_nDataLength;
								}
								else
								{
									lpVarDataAddr->m_nActualLength = nDataLen; 
								}
								memcpy(lpVarDataAddr->m_lpDataContent, lpAddr, lpVarDataAddr->m_nActualLength);

								lpAddr	 += lpVarDataAddr->m_nActualLength;
								nDataLen -= lpVarDataAddr->m_nActualLength;
							}

							nOffset = lpVarDataAddr->m_nNextOffset;	
						}
					}
				}
			}
		}
	}
}

/************************************************************************
		功能说明：
			将定长数据写入内存
		参数说明：
			stBson：BSON对象
			lpRecordInfo：记录信息
			nDataID：数据ID
************************************************************************/
int CMemoryBlock::RemoveData(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo, long long& nDataID)
{
	int nLen;
	LPBYTE lpData;
	INDEXINFO stIndexInfo;
	RECORDHEAD stRecordHead;
	LPOBJECTDEF lpObjectInfo;
	long long nRollBackDataID;
	LPBLOCKDATASTRUCT lpDataAddr;
	LPBLOCKVARDATASTRUCT lpVarDataAddr;

	nLen   = lpRecordInfo->m_nRecordLen;
	lpData = lpRecordInfo->m_lpRecordBuffer;
	lpObjectInfo  = stBson.GetObjectInfo();

	nRollBackDataID = nDataID;
	//1.分配DataID
	memset(&stRecordHead, 0, sizeof(RECORDHEAD));
	AllocDataID(&stRecordHead);
	nDataID = stRecordHead.m_nDataID;
	
	//2.调用AllocBlockNewData为新数据分配空间
	lpDataAddr = (LPBLOCKDATASTRUCT)AllocBlockNewData(nLen, nDataID);	 
	if(NULL == lpDataAddr)
	{
		return MF_MEMORYFILE_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;	
	}
	
	//3.执行数据插入操作
	lpVarDataAddr = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpDataAddr->m_nVarDataOffset);		
	memcpy(lpVarDataAddr->m_lpDataContent, lpData, nLen);								//写入变长数据
	lpDataAddr->m_nNextDataID	   = nRollBackDataID;
	lpDataAddr->m_nTimestamp	   = lpRecordInfo->m_nTimestamp;
	
	if(stRecordHead.m_bNewDataID)
	{
		m_lpBlockHead->m_nDataNum++;
	}
	TimestampUpdate(lpRecordInfo->m_nTimestamp);			
	return MF_OK;
}

/************************************************************************
		功能说明：
			将定长数据写入内存
		参数说明：
			lpRecordInfo：记录信息
			lpRecordHead：记录头
		特别说明：
			 插入步骤：
			 1.调用AllocBlockNewData为新数据分配空间
			 2.生成一个DataID
			 3.执行数据插入操作
************************************************************************/
int CMemoryBlock::InsertData(LPRECORDDATAINFO lpRecordInfo, LPRECORDHEAD lpRecordHead)
{	
	int nLen;
	LPBYTE lpData;
	INDEXINFO stIndexInfo;
	LPBLOCKDATASTRUCT lpDataAddr;
	LPBLOCKVARDATASTRUCT lpVarDataAddr;

	nLen   = lpRecordInfo->m_nRecordLen;
	lpData = lpRecordInfo->m_lpRecordBuffer;
	
	//1.调用AllocBlockNewData为新数据分配空间
	lpDataAddr = (LPBLOCKDATASTRUCT)AllocBlockNewData(nLen, lpRecordHead->m_nDataID);	 
	if(NULL == lpDataAddr)
	{
		return MF_MEMORYFILE_ALLOCBLOCK_NOENOUGHMEMORY_ERROR;	
	}

	//2.执行数据插入操作
	lpVarDataAddr = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpDataAddr->m_nVarDataOffset);		
	memcpy(lpVarDataAddr->m_lpDataContent, lpData, nLen);									//写入变长数据
	

	if(lpRecordHead->m_bNewDataID)
	{
		m_lpBlockHead->m_nDataNum++;
	}
	lpDataAddr->m_nTimestamp = lpRecordInfo->m_nTimestamp;
	TimestampUpdate(lpRecordInfo->m_nTimestamp);			
	return MF_OK;
}

/************************************************************************
		功能说明：
			修改数据
		参数说明：
			stBson：Bson对象
			lpRecordInfo：记录信息
		特别说明：
			修改步骤：
			1.根据DataID获得定长数据的地址指针和变长数据的地址指针
			2.校验地址是否合法、校验地址所对应的数据是否被删除
			3.执行具体的修改操作
			修改操作需要执行以下步骤：
			比较原数据的长度和当前数据的空间的大小：
			(1) 如果当前数据大于原有数据空间大小
				a.将当前数据的一部分放入原数据所在空间
				b.使用AllocBlockVarData分配一块新的内存
				c.将当前数据的剩余部分放入新的内存空间
				d.将新的内存空间加入变长数据链表

			(2) 如果当前数据小于原有数据空间大小
			    a.将当前数据放入原有数据空间
				b.清空原有数据空间剩余的空间
************************************************************************/
int CMemoryBlock::UpdateData(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo)
{
	LPBLOCKDATASTRUCT lpDataAddr;
	LPBYTE lpUpdatePos, lpNewBuffer;
	VARDATA varOldPID, varNewPID, varOldID, varNewID;
	LPBLOCKVARDATASTRUCT lpVarDataAddr, lpVarDataAddr2, lpNewVarData;
	int nRet, nNewLen, nNewDataLength, nInsertDataLength, nTempLen, nNewVarData, nAllocSize;

	nNewLen		= lpRecordInfo->m_nRecordLen;
	lpNewBuffer = lpRecordInfo->m_lpRecordBuffer;
	
	//1.根据DataID获得定长数据的地址指针和变长数据的地址指针
	lpDataAddr  = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(lpRecordInfo->m_nDataID);						//根据DataID获得定长数据的地址
	if(lpDataAddr == NULL)
	{
		return MF_MEMORYFILE_UPDATEDATA_INVALIDDATAID_ERROR;
	}
	if(GetInnerNoFromDataID(lpRecordInfo->m_nDataID) != lpDataAddr->m_nInnerNo)
	{
		return MF_OK;
	}

	lpVarDataAddr =(LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpDataAddr->m_nVarDataOffset);					//获得变长数据的地址
	
	//2.执行具体的修改操作
	nNewDataLength    = nNewLen;											//获取新数据长度
	lpUpdatePos	      = lpNewBuffer;										//待更新数据的位置
	nInsertDataLength = nNewDataLength;										//待更新数据的长度
	//遍历原始数据的变长数据链表进行覆盖操作
	lpVarDataAddr2	  = lpVarDataAddr;
	while(TRUE)
	{
		nTempLen = lpVarDataAddr2->m_nDataLength;							//变长数据中内容区的长度
		//根据待更新数据的长度判断执行何种操作
		if(!nInsertDataLength)								
		{
			//如果待更新数据的长度为0，说明数据修改已经完毕，那么如果此时对于链表的遍历还没有完毕，则应该将后续链表清空
			memset(lpVarDataAddr2->m_lpDataContent,0,nTempLen);
			lpVarDataAddr2->m_nActualLength = 0;
		}
		else if(nInsertDataLength <= nTempLen)
		{
			//如果待更新数据的长度<=变长数据中内容区的长度，则直接插入
			memcpy(lpVarDataAddr2->m_lpDataContent,lpUpdatePos,nInsertDataLength);
			lpVarDataAddr2->m_nActualLength = nInsertDataLength;			//修改变长数据的实际长度
			nInsertDataLength = 0;											//将待更新数据的长度设为0
		}
		else
		{
			//如果待更新数据的长度>变长数据中内容区的长度,则将该数据的一部分插入该空间
			memcpy(lpVarDataAddr2->m_lpDataContent,lpUpdatePos,nTempLen);
			lpVarDataAddr2->m_nActualLength = nTempLen;						//修改变长数据的实际长度
			lpUpdatePos += nTempLen;										//修改新数据的更新位置指针
			nInsertDataLength -= nTempLen;									//修改待更新数据的长度

			//判断链表是否遍历完毕，如果链表已经遍历完毕，则应该分配一块变长数据空间存放剩余数据
			if(!(lpVarDataAddr2->m_nNextOffset))
			{
				nNewVarData = AllocBlockVarData(nInsertDataLength, nAllocSize);			//分配一块新变长数据空间  
				if(nNewVarData == 0)
				{
					//空间不足，发生行迁移
					long long nNextDataID;
					nNextDataID = lpDataAddr->m_nNextDataID;
					nRet = m_pFile->RecordRemove(stBson, lpRecordInfo, nNextDataID);		
					if(nRet != MF_OK)
					{
						return nRet;
					}
					lpDataAddr->m_bDataStatus = DATA_STATUS_REMOVE;
					lpDataAddr->m_nNextDataID = nNextDataID;
					break;
				}

				lpNewVarData = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + nNewVarData);		//获新内存空间地址

				memcpy(lpNewVarData->m_lpDataContent,lpUpdatePos,nInsertDataLength);	//将剩余数据写入新变长数据空间

				//修改新变长数据空间头相关变量
				lpNewVarData->m_nActualLength = nInsertDataLength;						//给变长数据实际长度赋值
			
				//将新分配的变长空间放入变长数据链表
				lpVarDataAddr2->m_nNextOffset = nNewVarData;
				break;
			}
		}
		
		//判断链表是否遍历完毕，如果链表已经遍历完毕，则跳出循环
		if(!(lpVarDataAddr2->m_nNextOffset))
		{
			break;				//如果遍历到链表末尾，则跳出循环
		}
		
		//如果链表没有遍历完毕则将变长数据指针移动到下一个节点
		lpVarDataAddr2 = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpVarDataAddr2->m_nNextOffset);
	}
	
	//数据更新操作完毕，将修改定长数据中变长数据的实际长度
	lpDataAddr->m_nVarDataLength = nNewDataLength;
	lpDataAddr->m_nTimestamp     = lpRecordInfo->m_nTimestamp;
	TimestampUpdate(lpRecordInfo->m_nTimestamp);
	return MF_OK;
}

/************************************************************************
		功能说明：
			从内存文件中删除数据
		参数说明：
			stBson：Bson对象
			lpRecordInfo：记录信息
		特别说明：
			1.根据DataID获得定长数据的地址指针
			2.校验地址是否合法
			3.执行具体的删除操作
************************************************************************/
int CMemoryBlock::DeleteData(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo)
{
	LPBLOCKDATASTRUCT lpDataAddr;
	//1.根据DataID获得定长数据的地址指针
	lpDataAddr = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(lpRecordInfo->m_nDataID);		//根据DataID获得定长数据的地址
	if(NULL == lpDataAddr)
	{		
		return MF_MEMORYFILE_DELETEDATA_INVALIDDATAID_ERROR;								//未找到该DataID对应的数据，删除失败
	}
	
	if(GetInnerNoFromDataID(lpRecordInfo->m_nDataID) != lpDataAddr->m_nInnerNo)
	{
		return MF_OK;
	}
	//2.执行具体的删除操作
	if(lpDataAddr->m_bDataStatus == DATA_STATUS_EXIST)
	{
		lpDataAddr->m_bDataStatus = DATA_STATUS_DELETE;
		lpDataAddr->m_nTimestamp  = lpRecordInfo->m_nTimestamp;
		m_lpBlockHead->m_nRecyclableSpaceSize	  += lpDataAddr->m_nVarDataLength + sizeof(BLOCKVARDATASTRUCT);
	}
	TimestampUpdate(lpRecordInfo->m_nTimestamp);				//更新时间戳	
	return MF_OK;
}	

/************************************************************************
	功能说明：
		获取块中的所有数据条数
	参数说明：
		lpTransactionArray：事务数组
		nTimestamp：时间戳
************************************************************************/
int CMemoryBlock::GetDataNum(LPTRANSACTIONARRAY lpTransactionArray, long long nTimestamp)
{
	BOOL bVisiable;
	int i,nDataNum;
	long long nDataID;
	LPBLOCKDATASTRUCT lpDataAddr;
	
	nDataNum = 0;
	lpDataAddr = (LPBLOCKDATASTRUCT)m_lpBlockBody;
	for(i = 0; i < m_lpBlockHead->m_nDataNum; i++, lpDataAddr++)
	{
		if(lpDataAddr->m_bDataStatus == DATA_STATUS_REMOVE)
		{
			continue;
		}
		nDataID   = MakeDataID(m_lpBlockHead->m_bFileNo, m_lpBlockHead->m_nBlockNo, lpDataAddr->m_nInnerNo);
		bVisiable = CheckDataVisiable(lpTransactionArray, nDataID, nTimestamp);
		if(bVisiable)
		{
			nDataNum++;
		}
	}
	return nDataNum;
}

/************************************************************************
		功能说明：
			判断数据是否可见
		参数说明：
			lpTransactionArray:事务数组
			nDataID：数据ID
************************************************************************/
BOOL CMemoryBlock::CheckDataVisiable(LPTRANSACTIONARRAY lpTransactionArray, long long nDataID, long long nTimestamp)
{
	BOOL bVisiable;
	long long nRollBackDataID;
	LPBLOCKDATASTRUCT lpDataAddr;

	lpDataAddr = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(nDataID);		//根据DataID获得定长数据的地址
	if(NULL == lpDataAddr)
	{
		return FALSE;
	}
	if(lpDataAddr->m_bDataStatus == DATA_STATUS_REMOVE)
	{
		CMemoryBlock* pBlock;
		nDataID = lpDataAddr->m_nNextDataID;
		pBlock = m_pFile->ConvertDataIDtoBlockObject(nDataID);
		if(pBlock == NULL)
		{
			return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
		}
		return pBlock->CheckDataVisiable(lpTransactionArray, nDataID, nTimestamp);
	}

	nRollBackDataID = lpDataAddr->m_nNextDataID;
	if(lpDataAddr->m_nTimestamp > nTimestamp)
	{
		//判断回滚区数据是否合法
		return CSystemManage::instance().CheckValidRollBackData(nRollBackDataID, nTimestamp);
	}
	else
	{
		bVisiable = lpTransactionArray->CheckDataVisiable(lpDataAddr->m_nTimestamp);
		if(lpDataAddr->m_bDataStatus == DATA_STATUS_DELETE && bVisiable)
		{
			//数据可见说明事物已经提交，那么如果数据被删除且事物已经提交，则该数据就不能被取出
			return FALSE;
		}
		else if(!bVisiable)
		{
			return CSystemManage::instance().CheckValidRollBackData(nRollBackDataID, nTimestamp);
		}
	}
	return TRUE;
}

/************************************************************************
	功能说明：
		闪回
	参数说明：
		lpBuffer：块Buffer
		nTimestamp：时间戳
************************************************************************/
int CMemoryBlock::FlashBack(LPBYTE lpBuffer, long long nTimestamp)
{
	LPBYTE lpAddr;
	long long nDataID;
	LPBLOCKHEAD lpNewBlockHead;
	int i, nRet, nOffset, nDataLen;
	LPBLOCKDATASTRUCT lpDataAddrOld, lpDataAddrNew;
	LPBLOCKVARDATASTRUCT lpVarDataAddrOld, lpVarDataAddrNew;
	
	//设置新块块头
	memcpy(lpBuffer, m_lpBlockAddr, m_lpBlockHead->m_nBlockHeadSize);
	lpNewBlockHead = (LPBLOCKHEAD)lpBuffer;

	lpNewBlockHead->m_nInnerMaxNo			= 1;
	lpNewBlockHead->m_nBlockHeadSize		= sizeof(BLOCKHEAD);
	lpNewBlockHead->m_nDataInsertOffset		= sizeof(BLOCKHEAD);
	lpNewBlockHead->m_nVarDataInsertOffset	= m_lpBlockHead->m_nBlockSize;
	lpNewBlockHead->m_nDataNum				= 0;	
	lpNewBlockHead->m_bDataStatus			= 0;
	lpNewBlockHead->m_bSaveFlag				= 1;
	lpNewBlockHead->m_bDataStatus			= 0;
	lpNewBlockHead->m_nTimestamp			= nTimestamp;
	
	lpDataAddrNew = (LPBLOCKDATASTRUCT)(lpBuffer + m_lpBlockHead->m_nBlockHeadSize);
	lpDataAddrOld = (LPBLOCKDATASTRUCT)m_lpBlockBody;
	for(i = 0; i < m_lpBlockHead->m_nDataNum; i++)
	{	
		if(lpDataAddrOld[i].m_nTimestamp <= nTimestamp)
		{
			lpDataAddrNew[i].m_bDataStatus		= lpDataAddrOld[i].m_bDataStatus;
			lpDataAddrNew[i].m_nInnerNo			= lpDataAddrOld[i].m_nInnerNo;
			lpDataAddrNew[i].m_nVarDataOffset	= lpDataAddrOld[i].m_nVarDataOffset;
			lpDataAddrNew[i].m_bLockStatus		= 0;
			lpDataAddrNew[i].m_nNextDataID   	= 0;
			lpDataAddrNew[i].m_nTimestamp		= nTimestamp;

			lpNewBlockHead->m_nDataNum++;
			lpNewBlockHead->m_nInnerMaxNo++;
			lpNewBlockHead->m_nDataInsertOffset += m_lpBlockHead->m_nBlockDataStructSize;

			if(lpDataAddrOld[i].m_bDataStatus == DATA_STATUS_REMOVE)
			{
				//行迁移
				lpDataAddrNew[i].m_nNextDataID  = lpDataAddrOld[i].m_nNextDataID;
				continue;
			}
			else
			{
				lpAddr = NULL;
				if(lpDataAddrOld[i].m_nVarDataOffset != 0)
				{
					nOffset = lpDataAddrOld[i].m_nVarDataOffset;
					if(lpDataAddrOld[i].m_nTimestamp > nTimestamp || !CSystemManage::instance().CheckTransactionFinish(lpDataAddrOld[i].m_nTimestamp))
					{
						//从回滚区中读取数据
						nDataID = MakeDataID(m_lpBlockHead->m_bFileNo, m_lpBlockHead->m_nBlockNo, lpDataAddrOld[i].m_nInnerNo);
						nRet = GetRollBackData(nDataID, nDataLen, lpAddr, nTimestamp);
						if(nRet != MF_OK)
						{
							return nRet;
						}
						if(lpAddr == NULL)
						{
							//新插入数据
							continue;
						}

						lpDataAddrNew[i].m_nVarDataLength = nDataLen;
					}
					else
					{
						//从本地获取数据
						if(lpDataAddrOld[i].m_bDataStatus == DATA_STATUS_DELETE)
						{
							continue;
						}

						lpVarDataAddrOld = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + nOffset);
						lpDataAddrNew[i].m_nVarDataLength	= lpDataAddrOld[i].m_nVarDataLength;
					}
					
					nDataLen = lpDataAddrNew[i].m_nVarDataLength;
					while(nOffset)
					{
						if(nDataLen == 0)
						{
							break;
						}

						lpVarDataAddrNew					 = (LPBLOCKVARDATASTRUCT)(lpBuffer + nOffset);
						lpVarDataAddrNew->m_nDataFlag		 = lpVarDataAddrOld->m_nDataFlag;
						lpVarDataAddrNew->m_nDataLength		 = lpVarDataAddrOld->m_nDataLength;
						lpVarDataAddrNew->m_nNextOffset		 = lpVarDataAddrOld->m_nNextOffset;

						if(lpAddr)
						{
							//获取回滚区数据
							if(nDataLen > lpVarDataAddrOld->m_nDataLength)
							{
								lpVarDataAddrNew->m_nActualLength = lpVarDataAddrOld->m_nDataLength;
							}
							else
							{
								lpVarDataAddrNew->m_nActualLength = nDataLen;
							}
							memcpy(lpVarDataAddrNew->m_lpDataContent, lpAddr, lpVarDataAddrNew->m_nActualLength);
							lpAddr += lpVarDataAddrNew->m_nActualLength;
						}
						else
						{
							//获取本地数据
							lpVarDataAddrNew->m_nActualLength	= lpVarDataAddrOld->m_nActualLength;
							memcpy(lpVarDataAddrNew->m_lpDataContent, lpVarDataAddrOld->m_lpDataContent, lpVarDataAddrOld->m_nActualLength);
						}
						nDataLen -= lpVarDataAddrNew->m_nActualLength;

						nOffset = lpVarDataAddrOld->m_nNextOffset;
						lpVarDataAddrOld = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + nOffset);
						if(lpNewBlockHead->m_nVarDataInsertOffset > nOffset)
						{
							lpNewBlockHead->m_nVarDataInsertOffset = nOffset;
						}
					}
				}	
			}
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取下一个DataID
		参数说明：
			nDataNo：数据编号
			nDataID：数据ID
************************************************************************/
int CMemoryBlock::GetNextDataID(int& nDataNo, long long& nDataID)
{
	LPBLOCKDATASTRUCT lpDataAddr;
	lpDataAddr = (LPBLOCKDATASTRUCT)m_lpBlockBody;
	nDataID = MakeDataID(m_lpBlockHead->m_bFileNo, m_lpBlockHead->m_nBlockNo, lpDataAddr[nDataNo].m_nInnerNo);
	nDataNo++;
	if(nDataNo >= m_lpBlockHead->m_nDataNum)
	{
		nDataNo = 0;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取记录指针
		参数说明：
			stBson：BSON对象提供缓存空间
			lpRecordInfo：记录信息
************************************************************************/
int CMemoryBlock::GetRecordBuffer(CServiceBson& stBson, LPRECORDDATAINFO lpRecordInfo)
{
	LPBYTE lpBuffer;
	long long nTimestamp;
	int nRet, nNextOffset;
	LPBLOCKDATASTRUCT lpDataAddr;
	LPBLOCKVARDATASTRUCT lpVarDataAddr;
	
	lpDataAddr = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(lpRecordInfo->m_nDataID);
	if(NULL == lpDataAddr)
	{
		return MF_MEMORYFILE_READDATA_INVALIDDATAID_ERROR;					//未找到该DataID对应的数据，读取失败
	}

	if(lpDataAddr->m_bDataStatus == DATA_STATUS_REMOVE)
	{
		//发生行迁移
		CMemoryBlock* pBlock;
		lpRecordInfo->m_nDataID = lpDataAddr->m_nNextDataID;
		pBlock = m_pFile->ConvertDataIDtoBlockObject(lpRecordInfo->m_nDataID);
		if(pBlock == NULL)
		{
			return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
		}
		return pBlock->GetRecordBuffer(stBson, lpRecordInfo);
	}
	nTimestamp = lpDataAddr->m_nTimestamp;

GetRecord:
	lpVarDataAddr = NULL;
	nRet = GetVarData(lpDataAddr, lpRecordInfo, lpVarDataAddr, nNextOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(lpVarDataAddr == NULL)
	{
		lpRecordInfo->m_nRecordLen     = 0;
		lpRecordInfo->m_lpRecordBuffer = NULL;
	}
	else
	{	
		nRet = stBson.AllocFromRecordBuffer(lpRecordInfo->m_nRecordLen, lpBuffer);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpRecordInfo->m_lpRecordBuffer	= lpBuffer;
		while(TRUE)
		{
			memcpy(lpBuffer, lpVarDataAddr->m_lpDataContent, lpVarDataAddr->m_nActualLength);
			if(lpVarDataAddr->m_nNextOffset)
			{
				lpBuffer	   = lpBuffer + lpVarDataAddr->m_nActualLength;
				lpVarDataAddr  = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpVarDataAddr->m_nNextOffset);
			}
			else
			{
				break;
			}
		}
		if(lpRecordInfo->m_bAcutalDataPosition == MF_DATAPOSITION_LOCAL && nTimestamp != lpDataAddr->m_nTimestamp)
		{
			lpRecordInfo->m_bDataPosition = MF_DATAPOSITION_ROLLBACK;
			goto GetRecord;
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取记录指针
		参数说明：
			lpRecordInfo：记录信息
************************************************************************/
int CMemoryBlock::GetRecordPtr(LPRECORDDATAINFO lpRecordInfo)
{
	int nRet, nNextOffset;
	LPBLOCKDATASTRUCT lpDataAddr;
	LPBLOCKVARDATASTRUCT lpVarDataAddr;

	lpDataAddr = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(lpRecordInfo->m_nDataID);
	if(NULL == lpDataAddr)
	{
		return MF_MEMORYFILE_READDATA_INVALIDDATAID_ERROR;					//未找到该DataID对应的数据，读取失败
	}

	if(lpDataAddr->m_bDataStatus == DATA_STATUS_REMOVE)
	{
		//发生行迁移
		CMemoryBlock* pBlock;
		lpRecordInfo->m_nDataID = lpDataAddr->m_nNextDataID;
		pBlock = m_pFile->ConvertDataIDtoBlockObject(lpRecordInfo->m_nDataID);
		if(pBlock == NULL)
		{
			return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
		}
		return pBlock->GetRecordPtr(lpRecordInfo);
	}

	nRet = GetVarData(lpDataAddr, lpRecordInfo, lpVarDataAddr, nNextOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(lpVarDataAddr == NULL)
	{
		lpRecordInfo->m_lpRecordBuffer	 = NULL;
	}
	else
	{
		lpRecordInfo->m_lpRecordBuffer	 = lpVarDataAddr->m_lpDataContent;
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取记录中的字段值
		参数说明：
			stBson：BSON对象提供缓存空间
			pExpression：表达式类
			lpRecordInfo：记录信息
			bFieldNo：字段编号
			varResult：字段值
************************************************************************/
int CMemoryBlock::GetRecordFieldValue(CServiceBson* pBson, CExpression* pExpression, LPRECORDDATAINFO lpRecordInfo, BYTE bFieldNo, VARDATA& varResult)
{
	LPBYTE lpBuffer;
	long long nTimestamp;
	int nRet, nNextOffset;
	LPBLOCKDATASTRUCT lpDataAddr;
	LPBLOCKVARDATASTRUCT lpVarDataAddr;

	lpDataAddr = (LPBLOCKDATASTRUCT)ConvertDataIDtoDataAddr(lpRecordInfo->m_nDataID);
	if(NULL == lpDataAddr)
	{
		return MF_MEMORYFILE_READDATA_INVALIDDATAID_ERROR;					//未找到该DataID对应的数据，读取失败
	}

	if(lpDataAddr->m_bDataStatus == DATA_STATUS_REMOVE)
	{
		//发生行迁移
		CMemoryBlock* pBlock;
		lpRecordInfo->m_nDataID = lpDataAddr->m_nNextDataID;
		pBlock = m_pFile->ConvertDataIDtoBlockObject(lpRecordInfo->m_nDataID);
		if(pBlock == NULL)
		{
			return MF_MEMORYFILE_CONVERTDATAID_INVALIDDATAID_ERROR;
		}
		return pBlock->GetRecordFieldValue(pBson, pExpression, lpRecordInfo, bFieldNo, varResult);
	}
	nTimestamp = lpDataAddr->m_nTimestamp;

GetRecord:
	lpVarDataAddr = NULL;
	nRet = GetVarData(lpDataAddr, lpRecordInfo, lpVarDataAddr, nNextOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	if(lpVarDataAddr != NULL)
	{	
		if(nNextOffset != 0)
		{
			//如果记录数据在不连续的Buffer中，则先将Buffer组成连续空间
			nRet = pBson->AllocFromRecordBuffer(lpRecordInfo->m_nRecordLen, lpBuffer);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpRecordInfo->m_lpRecordBuffer	 = lpBuffer;

			while(TRUE)
			{
				memcpy(lpBuffer, lpVarDataAddr->m_lpDataContent, lpVarDataAddr->m_nActualLength);
				if(lpVarDataAddr->m_nNextOffset)
				{
					lpBuffer	   = lpBuffer + lpVarDataAddr->m_nActualLength;
					lpVarDataAddr  = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpVarDataAddr->m_nNextOffset);
				}
				else
				{
					break;
				}
			}
		}

		nRet = pExpression->GetFieldValueFromRecordBuffer(lpRecordInfo->m_nDataID, lpRecordInfo->m_lpRecordBuffer, lpRecordInfo->m_nRecordLen, bFieldNo, varResult);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpRecordInfo->m_bAcutalDataPosition == MF_DATAPOSITION_LOCAL && nTimestamp != lpDataAddr->m_nTimestamp)
		{
			lpRecordInfo->m_bDataPosition = MF_DATAPOSITION_ROLLBACK;
			goto GetRecord;
		}
	}
	return MF_OK;
}


/************************************************************************
		功能说明：
			导出表
		参数说明：
			stBson：Bson对象
			nObjectID：对象ID
			nTimestamp：时间戳
			lpTransactionArray：事务数组
			nInnerDataPos：记录位置
			bFinish：块中数据是否导出完毕
************************************************************************/
int CMemoryBlock::ExportObject(CServiceBson& stBson, int nObjectID, long long nTimestamp, LPTRANSACTIONARRAY lpTransactionArray, int& nInnerDataPos, int& nRecordNum, BOOL& bFinish)
{
	LPBYTE lpBuffer;
	int nRet, nNextOffset;
	RECORDDATAINFO stRecordInfo;
	long long nRectTime, nDataID;
	LPBLOCKDATASTRUCT lpDataAddr;
	UINT nOffset, nOldBsonDataSize;
	LPBLOCKVARDATASTRUCT lpVarDataAddr;

	memset(&stRecordInfo, 0, sizeof(RECORDDATAINFO));
	stRecordInfo.m_nTimestamp		  = nTimestamp;
	stRecordInfo.m_lpTransactionArray = lpTransactionArray;

	lpDataAddr = (LPBLOCKDATASTRUCT)m_lpBlockBody;
	while(TRUE)
	{
		nRectTime  = lpDataAddr[nInnerDataPos].m_nTimestamp;
		if(lpDataAddr[nInnerDataPos].m_bDataStatus == DATA_STATUS_REMOVE)
		{
			nInnerDataPos++;
			if(nInnerDataPos < m_lpBlockHead->m_nDataNum)
			{
				continue;	
			}
			else
			{
				bFinish = TRUE;
				break;
			}
		}
		else
		{
GetRecord:
			nRet = GetVarData(&lpDataAddr[nInnerDataPos], &stRecordInfo, lpVarDataAddr, nNextOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			if(lpVarDataAddr != NULL)
			{
				nOldBsonDataSize = stBson.GetBsonDataSize();			//记录原始的BsonDataSize
				if(stRecordInfo.m_nRecordLen + sizeof(RECORDBUFFERHEAD) > stBson.GetBufferSize() - sizeof(OBJECTBUFFERHEAD))
				{
					return MF_COMMON_INVALID_BUFFERSIZE;
				}

				//分配空间存放记录长度和记录本身
				lpBuffer = NULL;
				nRet = stBson.AllocFromBsonBuffer(stRecordInfo.m_nRecordLen + sizeof(RECORDBUFFERHEAD), nOffset, lpBuffer);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				
				nDataID = MakeDataID(m_lpBlockHead->m_bFileNo, m_lpBlockHead->m_nBlockNo, lpDataAddr[nInnerDataPos].m_nInnerNo);
				((LPRECORDBUFFERHEAD)lpBuffer)->m_nRecordLen    = stRecordInfo.m_nRecordLen;
				((LPRECORDBUFFERHEAD)lpBuffer)->m_nRecordDataID = nDataID;
				lpBuffer += sizeof(RECORDBUFFERHEAD);
				while(TRUE)
				{
					memcpy(lpBuffer, lpVarDataAddr->m_lpDataContent, lpVarDataAddr->m_nActualLength);
					if(lpVarDataAddr->m_nNextOffset)
					{
						lpBuffer	   += lpVarDataAddr->m_nActualLength;
						lpVarDataAddr  = (LPBLOCKVARDATASTRUCT)(m_lpBlockAddr + lpVarDataAddr->m_nNextOffset);
					}
					else
					{
						break;
					}
				}
				if(stRecordInfo.m_bAcutalDataPosition == MF_DATAPOSITION_LOCAL && nRectTime != lpDataAddr[nInnerDataPos].m_nTimestamp)
				{
					stRecordInfo.m_bDataPosition = MF_DATAPOSITION_ROLLBACK;
					
					//将BsonDataSize回退为原始值
					stBson.SetDataLen(nOldBsonDataSize);				
					goto GetRecord;
				}
			}
			nRecordNum++;
			nInnerDataPos++;
			if(nInnerDataPos >= m_lpBlockHead->m_nDataNum)
			{
				bFinish = TRUE;
				break;
			}
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取记录数量
************************************************************************/
int CMemoryBlock::GetRecordNum()
{
	return m_lpBlockHead->m_nDataNum;
}