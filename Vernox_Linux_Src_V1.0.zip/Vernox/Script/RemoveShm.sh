#!/bin/bash

# Created on: 2015.10.19

service vernoxservice stop
service vernoxstorage stop

#Trace
ipcrm -M 0x53425452
if [ $? -eq 0 ]
then
	echo "remove key(0x53425452) success!"
fi

#Log
ipcrm -M 0x53424C4F
if [ $? = 0 ]
then
	echo "remove key(0x53424C4F) success!"
fi

#STORAGEMEMFILE
ipcrm -M 0x5342534D
if [ $? -eq 0 ]
then
	echo "remove key(0x5342534D) success!"
fi

#TEMPORARYMEM
ipcrm -M 0x5342544D
if [ $? -eq 0 ]
then
	echo "remove key(0x5342544D) success!"
fi

#SystemDataFile
ipcrm -M 0x53424601
if [ $? -eq 0 ]
then
	echo "remove key(0x53424601) success!"
fi

#DataFile
ipcrm -M 0x53424602
if [ $? -eq 0 ]
then
	echo "remove key(0x53424602) success!"
fi

#TreeFile
ipcrm -M 0x53424603
if [ $? -eq 0 ]
then
	echo "remove key(0x53424603) success!"
fi

#HashFile
ipcrm -M 0x53424604
if [ $? -eq 0 ]
then
	echo "remove key(0x53424604) success!"
fi

