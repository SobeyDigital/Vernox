/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "RecordIterator.h"

CRecordIterator::CRecordIterator(void)
{
	m_lpBuffer = NULL;
	m_nBufferSectionNum	= 0;
	m_lpExecutePlan		= NULL;
	m_lpCurrentSection	= NULL;		

	m_nCurrentBufferNo	= 0;
	m_nCurrentRecordNo  = 0;
	m_lpCurrentBuffer	= NULL;
	m_lpRecord			= NULL;
}

CRecordIterator::~CRecordIterator(void)
{
}


void CRecordIterator::Inital(LPBYTE lpBuffer)
{
	UINT i, nBufferNum;
	m_lpBuffer		= lpBuffer;
	m_lpExecutePlan = (LPEXECUTEPLANBSON)lpBuffer;
	if(m_lpExecutePlan->m_nFreeSectionAddrID != 0)
	{
		//UpDateReocrdset���
		lpBuffer   = m_lpBuffer + m_lpExecutePlan->m_nSectionStartOffset;
		nBufferNum = m_lpExecutePlan->m_nFreeSectionAddrID >> 16; 
		for(i = 0; i < nBufferNum; i++)
		{
			m_arrBufferSection[m_nBufferSectionNum] = lpBuffer;
			m_nBufferSectionNum++;
			if(i != nBufferNum - 1)
			{
				//���һ��Ƭ��
				lpBuffer		= m_lpBuffer + ((LPBUFFERSECTIONHEAD)lpBuffer)->m_nNextSectionOffset;
			}
		}
	}

}

//�ƶ�����һ����¼
void CRecordIterator::Move2FirstRecord()
{
	UINT nAddrID;
	USHORT nOffset;

	if(m_nBufferSectionNum != 0)
	{
		nAddrID					= m_lpExecutePlan->m_stSourceInfo.m_nRecordAddrID;
		m_nCurrentBufferNo		= nAddrID >> 16;
		nOffset					= (USHORT)nAddrID;
		m_lpCurrentBuffer		= m_arrBufferSection[m_nCurrentBufferNo - 1];

		m_lpRecord	= (LPRECORDHEAD)(m_lpCurrentBuffer + nOffset);
	}
}

//��һ����¼��Ϣ
void CRecordIterator::NextRecord(LPRECORDHEAD& lpRecordHead)
{
	USHORT nOffset;
	LPBYTE lpRecordAddr;

	m_nCurrentRecordNo++;
	if(m_nCurrentRecordNo > (int)m_lpExecutePlan->m_stSourceInfo.m_nRecordNum)
	{
		lpRecordHead = NULL;
	}
	else
	{
		nOffset			= (USHORT)((LPBYTE)m_lpRecord - m_lpCurrentBuffer);
		lpRecordHead    = m_lpRecord;
		if(lpRecordHead->m_bLast)
		{
			//�л�����һ������Ƭ��
			m_nCurrentBufferNo++;
			m_lpCurrentBuffer = m_arrBufferSection[m_nCurrentBufferNo - 1];
			lpRecordAddr	  = m_lpCurrentBuffer + sizeof(BUFFERSECTIONHEAD);

			m_lpRecord = (LPRECORDHEAD)lpRecordAddr;
		}
		else
		{
			m_lpRecord++;
		}
	}
}
