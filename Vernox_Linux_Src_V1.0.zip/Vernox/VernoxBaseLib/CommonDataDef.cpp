﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"

void st_VARDATA::Free()
{
	if(m_bAutoRelease)
	{
		if(m_vt == MF_VARDATA_STRING)
		{
			if(m_lpszValue != NULL)
			{
				delete [] m_lpszValue;
				m_lpszValue = NULL;
			}
		}
		else if(m_vt == MF_VARDATA_BINARY)
		{
			if(m_lpValue != NULL)
			{
				delete [] m_lpValue;
				m_lpValue = NULL;
			}
		}
		else if(m_vt == MF_VARDATA_ARRAYINT)
		{
			if(m_arrInt != NULL)
			{
				delete [] m_arrInt;
				m_arrInt = NULL;
			}
		}
		else if(m_vt == MF_VARDATA_ARRAYBIGINT)
		{
			if(m_arrBigInt != NULL)
			{
				delete [] m_arrBigInt;
				m_arrBigInt = NULL;
			}
		}
		else
		{
			m_llValue	= 0;
		}
	}
	else
	{
		m_llValue	= 0;
	}
	*(short*)(&m_vt)	= 0;
}

int st_VARDATA::GetStringLen()
{
	return m_nStrLen;
}

void st_VARDATA::SetDataLen(int nLen)
{
	m_nBufferLen = nLen + sizeof(BYTE);
}

void st_VARDATA::SetStringLen(int nLen)
{
	m_nStrLen = nLen;
	if(nLen < 250)
	{
		m_nBufferLen = sizeof(BYTE) + sizeof(BYTE) + nLen;
	}
	else
	{
		m_nBufferLen = sizeof(BYTE) + sizeof(BYTE) + sizeof(int) + nLen;
	}
}
BOOL st_VARDATA::operator >(const st_VARDATA& varData)
{
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		return FALSE;
	}
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_nValue > varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_nValue > varData.m_llValue;
		case MF_VARDATA_DOUBLE:
	    case MF_VARDATA_DATE:
			return (CompareDouble(m_nValue, varData.m_dblValue) > 0);
		case MF_VARDATA_BYTE:
			return m_nValue > varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_llValue > varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_llValue > varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_llValue > varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_llValue > varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_dblValue > varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_dblValue > varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return (CompareDouble(m_dblValue, varData.m_dblValue) > 0);
		case MF_VARDATA_BYTE:
			return m_dblValue > varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_STRING)
	{
		return stricmp(m_lpszValue, varData.m_lpszValue) > 0;	
	}
	else if(m_vt == MF_VARDATA_DATE && varData.m_vt == MF_VARDATA_DATE)
	{
		return m_dblValue > varData.m_dblValue;
	}
	return FALSE;
}

BOOL st_VARDATA::operator < (const st_VARDATA& varData)
{
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		return FALSE;
	}
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_nValue < varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_nValue < varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return (CompareDouble(m_nValue, varData.m_dblValue) < 0);
		case MF_VARDATA_BYTE:
			return m_nValue < varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_llValue < varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_llValue < varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_llValue < varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_llValue < varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_dblValue < varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_dblValue < varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return (CompareDouble(m_dblValue, varData.m_dblValue) < 0);
		case MF_VARDATA_BYTE:
			return m_dblValue < varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_STRING)
	{
		return stricmp(m_lpszValue, varData.m_lpszValue) < 0;
	}
	else if(m_vt == MF_VARDATA_DATE && varData.m_vt == MF_VARDATA_DATE)
	{
		return m_dblValue < varData.m_dblValue;
	}
	return FALSE;
}

BOOL st_VARDATA::operator == (const st_VARDATA& varData)
{
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		return FALSE;
	}
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_nValue == varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_nValue == varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return (CompareDouble(m_nValue, varData.m_dblValue) == 0);
		case MF_VARDATA_BYTE:
			return m_nValue == varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_llValue == varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_llValue == varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_llValue == varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_llValue == varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_dblValue == varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_dblValue == varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return (CompareDouble(m_dblValue, varData.m_dblValue) == 0);
		case MF_VARDATA_BYTE:
			return m_dblValue == varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_STRING)
	{
		return stricmp(m_lpszValue, varData.m_lpszValue) == 0;
	}
	else if(m_vt == MF_VARDATA_DATE && varData.m_vt == MF_VARDATA_DATE)
	{
		return m_dblValue == varData.m_dblValue;
	}
	return FALSE;
}

BOOL st_VARDATA::operator >= (const st_VARDATA& varData)
{
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		return FALSE;
	}
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_nValue >= varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_nValue >= varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return (CompareDouble(m_nValue, varData.m_dblValue) >= 0);
		case MF_VARDATA_BYTE:
			return m_nValue >= varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_llValue >= varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_llValue >= varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_llValue >= varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_llValue >= varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_dblValue >= varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_dblValue >= varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return (CompareDouble(m_dblValue, varData.m_dblValue) >= 0);
		case MF_VARDATA_BYTE:
			return m_dblValue >= varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_STRING)
	{
		return stricmp(m_lpszValue, varData.m_lpszValue) >= 0;
	}
	else if(m_vt == MF_VARDATA_DATE && varData.m_vt == MF_VARDATA_DATE)
	{
		return m_dblValue >= varData.m_dblValue;
	}
	return FALSE;
}

BOOL st_VARDATA::operator <= (const st_VARDATA& varData)
{
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		return FALSE;
	}
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_nValue <= varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_nValue <= varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return (CompareDouble(m_nValue, varData.m_dblValue) <= 0);
		case MF_VARDATA_BYTE:
			return m_nValue <= varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_llValue <= varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_llValue <= varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_llValue <= varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_llValue <= varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_dblValue <= varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_dblValue <= varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return (CompareDouble(m_dblValue, varData.m_dblValue) <= 0);
		case MF_VARDATA_BYTE:
			return m_dblValue <= varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_STRING)
	{
		return stricmp(m_lpszValue, varData.m_lpszValue) <= 0;
	}
	else if(m_vt == MF_VARDATA_DATE && varData.m_vt == MF_VARDATA_DATE)
	{
		return m_dblValue <= varData.m_dblValue;
	}
	return FALSE;
}


BOOL st_VARDATA::operator != (const st_VARDATA& varData)
{
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		return TRUE;
	}
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_nValue != varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_nValue != varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return (CompareDouble(m_nValue, varData.m_dblValue) != 0);
		case MF_VARDATA_BYTE:
			return m_nValue != varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_llValue != varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_llValue != varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_llValue != varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_llValue != varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_dblValue != varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_dblValue != varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return (CompareDouble(m_dblValue, varData.m_dblValue) != 0);
		case MF_VARDATA_BYTE:
			return m_dblValue != varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_STRING)
	{
		return stricmp(m_lpszValue, varData.m_lpszValue) != 0;
	}
	else if(m_vt == MF_VARDATA_DATE && varData.m_vt == MF_VARDATA_DATE)
	{
		return m_dblValue != varData.m_dblValue;
	}
	return FALSE;
}

BOOL st_VARDATA::operator || (const st_VARDATA& varData)
{
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		return FALSE;
	}
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_nValue || varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_nValue || varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_nValue || varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_nValue || varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_llValue || varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_llValue || varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_llValue || varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_llValue || varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_dblValue || varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_dblValue || varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_dblValue || varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_dblValue || varData.m_bValue; 
		}
	}
	return FALSE;
}

BOOL st_VARDATA::operator && (const st_VARDATA& varData)
{
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		return FALSE;
	}
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_nValue && varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_nValue && varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_nValue && varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_nValue && varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_llValue && varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_llValue && varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_llValue && varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_llValue && varData.m_bValue; 
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			return m_dblValue && varData.m_nValue;
		case MF_VARDATA_INT64:
			return m_dblValue && varData.m_llValue;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			return m_dblValue && varData.m_dblValue;
		case MF_VARDATA_BYTE:
			return m_dblValue && varData.m_bValue; 
		}
	}
	return FALSE;
}

BOOL st_VARDATA::operator ! ()
{
	if(m_vt == MF_VARDATA_NULL)
	{
		return FALSE;
	}
	switch(m_vt)
	{
	case MF_VARDATA_INT:
		return !m_nValue;
	case MF_VARDATA_INT64:
		return !m_llValue;
	case MF_VARDATA_DOUBLE:
	case MF_VARDATA_DATE:
		return !m_dblValue;
	case MF_VARDATA_BYTE:
		return !m_bValue;
	}
	return FALSE;
}

BOOL st_VARDATA::In(CBaseBson* pBaseBson, int* lpHashTable, int nTableSize)
{
	int nDataPos;
	LPDATANODE lpDataNode;
	if(m_vt <= 4)
	{
		long long llValue;
		nDataPos   = CalcKeyHash(m_llValue, nTableSize);
		lpDataNode = (LPDATANODE)pBaseBson->ConvertOffset2Addr(lpHashTable[nDataPos]);
		llValue    = *(long long*)lpDataNode->m_pDataBuffer;
		return m_llValue == llValue;
	}
	else
	{
		char* lpszValue;
		nDataPos = CalcKeyHash((LPBYTE)m_lpszValue, nTableSize);
		lpDataNode = (LPDATANODE)pBaseBson->ConvertOffset2Addr(lpHashTable[nDataPos]);
		lpszValue  = lpDataNode->m_pDataBuffer;
		return stricmp(m_lpszValue, lpszValue) == 0;
	}

}

void st_VARDATA::SetData(const st_VARDATA& varData)
{
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		m_vt = MF_VARDATA_NULL;
		return;
	}
	switch(varData.m_vt)
	{
	case MF_VARDATA_INT:
		Free();
		m_vt = MF_VARDATA_INT;
		m_nValue = varData.m_nValue;
		break;
	case MF_VARDATA_INT64:
		Free();
		m_vt = MF_VARDATA_INT64;
		m_llValue = varData.m_llValue;
		break;
	case MF_VARDATA_DOUBLE:
		Free();
		m_vt = MF_VARDATA_DOUBLE;
		m_dblValue = varData.m_dblValue;
		break;
	case MF_VARDATA_DATE:
		Free();
		m_vt = MF_VARDATA_DATE;
		m_dblValue = varData.m_dblValue;
		break;
	case MF_VARDATA_BYTE:
		Free();
		m_vt = MF_VARDATA_BYTE;
		m_bValue = varData.m_bValue;
		break;
	case MF_VARDATA_STRING:
		Free();
		m_vt = MF_VARDATA_STRING;
		m_nStrLen = varData.m_nStrLen;
		m_lpszValue = varData.m_lpszValue;
		break;
	case MF_VARDATA_BINARY:
		Free();
		m_vt = MF_VARDATA_BINARY;
		m_nStrLen = varData.m_nStrLen;
		m_lpValue = varData.m_lpValue;
		break;
	case MF_VARDATA_MAX:
		Free();
		m_vt = MF_VARDATA_MAX;
	}
	m_nBufferLen = varData.m_nBufferLen;
	m_bParam1	 = varData.m_bParam1;
	m_bParam2	 = varData.m_bParam2;
}

void st_VARDATA::SetData(const int nValue)
{
	Free();
	m_vt = MF_VARDATA_INT;
	m_nValue = nValue;
	m_nBufferLen = sizeof(int) + sizeof(BYTE);
}

void st_VARDATA::SetData(const long long llValue)
{
	Free();
	m_vt = MF_VARDATA_INT64;
	m_llValue = llValue;
	m_nBufferLen = sizeof(long long) + sizeof(BYTE);
}

void st_VARDATA::SetData(const double dblValue, MF_VARDATA_TYPE bType)
{
	Free();
	m_vt = bType;
	m_dblValue = dblValue;
	m_nBufferLen = sizeof(double) + sizeof(BYTE);
}

void st_VARDATA::SetData(const BYTE bValue)
{
	Free();
	m_vt = MF_VARDATA_BYTE;
	m_bValue = bValue;
	m_nBufferLen = sizeof(BYTE) + sizeof(BYTE);
}

void st_VARDATA::SetData(const char* lpszValue, int nLen)
{
	Free();
	m_vt = MF_VARDATA_STRING;
	m_lpszValue = const_cast<char*>(lpszValue);
	m_nStrLen	= nLen;
	if(m_nStrLen < 250)
	{
		m_nBufferLen = sizeof(BYTE)+sizeof(BYTE)+m_nStrLen;
	}
	else
	{
		m_nBufferLen = sizeof(BYTE)+ sizeof(BYTE)+ sizeof(int)+m_nStrLen;
	}
}

void st_VARDATA::SetData(const long long* arrayBigInt, USHORT nArrCount)
{
	Free();
	m_vt		= MF_VARDATA_ARRAYBIGINT;
	m_arrBigInt	= const_cast<long long*>(arrayBigInt);
	m_nArrCount = nArrCount;
}
void st_VARDATA::SetData(const int* arrayInt, USHORT nArrCount)
{
	Free();
	m_vt		= MF_VARDATA_ARRAYINT;
	m_arrInt	= const_cast<int*>(arrayInt);
	m_nArrCount = nArrCount;
}

void st_VARDATA::AttachBuffer(BYTE bType, char* lpszBuffer, int nLen)
{	
	Free();
	m_vt = bType;
	m_bAutoRelease = 1;
	if(lpszBuffer == NULL)
	{
		m_vt = MF_VARDATA_NULL;
	}
	else
	{
		if(bType == MF_VARDATA_STRING)
		{
			m_lpszValue = lpszBuffer;	
		}
		else if(bType == MF_VARDATA_BINARY)
		{
			m_lpValue = (LPBYTE)lpszBuffer;
		}
		SetStringLen(nLen);
	}
}

void st_VARDATA::DetachBuffer()
{
	if(m_vt == MF_VARDATA_STRING)
	{
		m_lpszValue = NULL;	
	}
	else if(m_vt == MF_VARDATA_BINARY)
	{
		m_lpValue = NULL;
	}
}
int st_VARDATA::GetFieldBufferLen()
{
	return m_nBufferLen;
}

void st_VARDATA::SetBinaryData(LPBYTE bValue, int nLen)
{
	Free();
	m_vt = MF_VARDATA_BINARY;
	m_lpValue = bValue;
	m_nStrLen = nLen;
	if(m_nStrLen < 250)
	{
		m_nBufferLen = sizeof(BYTE) + sizeof(BYTE) + m_nStrLen;
	}
	else
	{
		m_nBufferLen = sizeof(BYTE) + sizeof(BYTE) + sizeof(int) + m_nStrLen;
	}
}

void st_VARDATA::GetBinaryData(LPBYTE &bValue)
{
	bValue = m_lpValue;
}

void st_VARDATA::CovertStringData(BYTE bType, char* lpszData, int nLen)
{
	switch(bType)
	{
	case MF_SYS_FIELDTYPE_INT:
		Free();
		m_vt = MF_VARDATA_INT;
		m_nValue = atoi(lpszData);
		m_nBufferLen = sizeof(int) + sizeof(BYTE);
		break;
	case MF_SYS_FIELDTYPE_BIGINT:
		Free();
		m_vt = MF_VARDATA_INT64;
		m_llValue = _atoi64(lpszData);
		m_nBufferLen = sizeof(long long) + sizeof(BYTE);
		break;
	case MF_SYS_FIELDTYPE_DOUBLE:
		Free();
		m_vt = MF_VARDATA_DOUBLE;
		m_dblValue = atof(lpszData);
		m_nBufferLen = sizeof(double) + sizeof(BYTE);
		break;
	case MF_SYS_FIELDTYPE_DATE:
		Free();
		m_vt = MF_SYS_FIELDTYPE_DATE;
		m_dblValue = atof(lpszData);
		m_nBufferLen = sizeof(double) + sizeof(BYTE);
		break;
	case MF_SYS_FIELDTYPE_CHAR:
	case MF_SYS_FIELDTYPE_VARCHAR:
	case MF_SYS_FIELDTYPE_CLOB:
		Free();
		m_vt = MF_VARDATA_STRING;
		m_lpszValue = lpszData;
		m_nStrLen   = nLen;
		if(m_nStrLen < 250)
		{
			m_nBufferLen = sizeof(BYTE) + sizeof(BYTE) + nLen;
		}
		else
		{
			m_nBufferLen = sizeof(BYTE) + sizeof(BYTE) + sizeof(int) + nLen;
		}
		break;
	}
}

int st_VARDATA::Link(CBaseBson& stBson, st_VARDATA& varData, st_VARDATA& varResult)
{
	LPBYTE lpAddr;
	int nRet, nLen;
	string str1, str2,str3;
	char varBuffer[32] = {0};
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		varResult.m_vt = MF_VARDATA_NULL;
		return MF_OK;
	}

	varResult.m_vt = MF_VARDATA_STRING;
	if(m_vt == MF_VARDATA_STRING)
	{
		str1 = m_lpszValue;
		switch(varData.m_vt)
		{
		case MF_SYS_FIELDTYPE_INT:
			sprintf(varBuffer,"%d", varData.m_nValue);
			str2 = varBuffer;
			break;
		case MF_VARDATA_INT64:
			sprintf(varBuffer, "%lld", varData.m_llValue);
			str2 = varBuffer;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			sprintf(varBuffer, "%f", varData.m_dblValue);
			str2 = varBuffer;
			break;
		case MF_VARDATA_STRING:
			str2 = varData.m_lpszValue;
			break;
		}
	}
	else if(varData.m_vt == MF_VARDATA_STRING)
	{
		str2 = varData.m_lpszValue;
		switch(m_vt)
		{
		case MF_SYS_FIELDTYPE_INT:
			sprintf(varBuffer,"%d", m_nValue);
			str1 = varBuffer;
			break;
		case MF_VARDATA_INT64:
			sprintf(varBuffer, "%lld", m_llValue);
			str1 = varBuffer;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			sprintf(varBuffer, "%f", m_dblValue);
			str1 = varBuffer;
			break;
		case MF_VARDATA_STRING:
			str1 = m_lpszValue;
			break;
		}
	}
	str3   = str1 + " " +str2;
	nLen   = str3.length() + 1;

	lpAddr = NULL;
	nRet   = stBson.AllocBuffer(nLen, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	memcpy(lpAddr, str3.c_str(), nLen);
	
	varResult.m_vt			= MF_VARDATA_STRING;
	varResult.m_lpszValue	= (char*)lpAddr;
	varResult.m_nStrLen		= nLen;
	if(nLen < 250)
	{
		varResult.m_nBufferLen = sizeof(BYTE) + sizeof(BYTE) + nLen;
	}
	else
	{
		varResult.m_nBufferLen = sizeof(BYTE) + sizeof(BYTE) + sizeof(int) + nLen;
	}
	lpAddr = NULL;
	return MF_OK;
}

st_VARDATA st_VARDATA::operator + (const st_VARDATA& varData)
{
	st_VARDATA varResult;
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		varResult.m_vt = MF_VARDATA_NULL;
		return varResult;
	}
	varResult.m_vt = m_vt > varData.m_vt ? m_vt : varData.m_vt;
	varResult.m_nBufferLen = m_nBufferLen > varData.m_nBufferLen ? m_nBufferLen : varData.m_nBufferLen;
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_nValue = m_nValue + varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_llValue = m_nValue + varData.m_llValue;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			varResult.m_dblValue = m_nValue + varData.m_dblValue;
			break;
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_llValue = m_llValue + varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_llValue = m_llValue + varData.m_llValue;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			varResult.m_dblValue = m_llValue + varData.m_dblValue;
			break;
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_dblValue = m_dblValue + varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_dblValue = m_dblValue + varData.m_llValue;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			varResult.m_dblValue = m_dblValue + varData.m_dblValue;
			break;
		}
	}
	return varResult;
}

st_VARDATA st_VARDATA::operator - (const st_VARDATA& varData)
{
	st_VARDATA varResult;
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		varResult.m_vt = MF_VARDATA_NULL;
		return varResult;
	}
	varResult.m_vt = m_vt > varData.m_vt ? m_vt : varData.m_vt;
	varResult.m_nBufferLen = m_nBufferLen > varData.m_nBufferLen ? m_nBufferLen : varData.m_nBufferLen;
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_nValue = m_nValue - varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_llValue = m_nValue - varData.m_llValue;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			varResult.m_dblValue = m_nValue - varData.m_dblValue;
			break;
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_llValue = m_llValue - varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_llValue = m_llValue - varData.m_llValue;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			varResult.m_dblValue = m_llValue - varData.m_dblValue;
			break;
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_dblValue = m_dblValue - varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_dblValue = m_dblValue - varData.m_llValue;
			break;
		case MF_VARDATA_DATE:
		case MF_VARDATA_DOUBLE:
			varResult.m_dblValue = m_dblValue - varData.m_dblValue;
			break;
		}
	}

	return varResult;
}
st_VARDATA st_VARDATA::operator * (const st_VARDATA& varData)
{
	st_VARDATA varResult;
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		varResult.m_vt = MF_VARDATA_NULL;
		return varResult;
	}
	varResult.m_vt = m_vt > varData.m_vt ? m_vt : varData.m_vt;
	varResult.m_nBufferLen = m_nBufferLen > varData.m_nBufferLen ? m_nBufferLen : varData.m_nBufferLen;
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_nValue = m_nValue * varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_llValue = m_nValue * varData.m_llValue;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			varResult.m_dblValue = m_nValue * varData.m_dblValue;
			break;
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_llValue = m_llValue * varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_llValue = m_llValue * varData.m_llValue;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			varResult.m_dblValue = m_llValue * varData.m_dblValue;
			break;
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_dblValue = m_dblValue * varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_dblValue = m_dblValue * varData.m_llValue;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			varResult.m_dblValue = m_dblValue * varData.m_dblValue;
			break;
		}
	}
	return varResult;
}

st_VARDATA st_VARDATA::operator / (const st_VARDATA& varData)
{
	st_VARDATA varResult;
	if(m_vt == MF_VARDATA_NULL || varData.m_vt == MF_VARDATA_NULL)
	{
		varResult.m_vt = MF_VARDATA_NULL;
		return varResult;
	}
	varResult.m_vt = MF_VARDATA_DOUBLE;
	varResult.m_nBufferLen = sizeof(double)+sizeof(BYTE);
	if(m_vt == MF_VARDATA_INT)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_dblValue = (double)m_nValue / varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_dblValue = (double)m_nValue / varData.m_llValue;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			varResult.m_dblValue = (double)m_nValue / varData.m_dblValue;
			break;
		}
	}
	else if(m_vt == MF_VARDATA_INT64)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_dblValue = (double)m_llValue  / varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_dblValue = (double)m_llValue  / varData.m_llValue;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			varResult.m_dblValue = (double)m_llValue / varData.m_dblValue;
			break;
		}
	}
	else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
	{
		switch(varData.m_vt)
		{
		case MF_VARDATA_INT:
			varResult.m_dblValue = m_dblValue / varData.m_nValue;
			break;
		case MF_VARDATA_INT64:
			varResult.m_dblValue = m_dblValue / varData.m_llValue;
			break;
		case MF_VARDATA_DOUBLE:
		case MF_VARDATA_DATE:
			varResult.m_dblValue = m_dblValue / varData.m_dblValue;
			break;
		}
	}
	return varResult;
}


//获取兼容类型值(目前只支持数字型的兼容)
int st_VARDATA::GetCompatibleInt()
{    
	switch(m_vt)
	{
	case MF_VARDATA_INT64:
		return (int)m_llValue;
	case MF_VARDATA_DOUBLE:
	case MF_VARDATA_DATE:
		return (int)m_dblValue;
	}
	return m_nValue;
}

long long st_VARDATA::GetCompatibleBigInt()
{
	switch(m_vt)
	{
	case MF_VARDATA_INT:
		return m_nValue;		
	case MF_VARDATA_DOUBLE:
	case MF_VARDATA_DATE:
		return (long long)m_dblValue;
	}
	return m_llValue;
}

double st_VARDATA::GetCompatibleDouble()
{
	switch(m_vt)
	{
	case MF_VARDATA_INT:
		return (double)m_nValue;
	case MF_VARDATA_INT64:
		return (double)m_llValue;	
	}
	return m_dblValue;
}

int st_VARDATA::GetCompatableValue(MF_VARDATA_TYPE vt, st_VARDATA& varResult)
{
	if(m_vt == MF_VARDATA_NULL)
	{
		varResult.m_vt			= MF_VARDATA_NULL;
		varResult.m_llValue 	= 0;
		varResult.m_nStrLen 	= 0;
		varResult.m_nBufferLen	= 0;
		return MF_OK;
	}
	if(vt == MF_VARDATA_INT)
	{
		if(m_vt == MF_VARDATA_INT)
		{
			varResult.SetData(m_nValue);
		}
		else if(m_vt == MF_VARDATA_INT64)
		{
			varResult.SetData((int)m_llValue);
		}
		else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
		{
			varResult.SetData((int)m_dblValue);
		}
		else
		{
			return MF_PARSECMD_INVALID_DATACOMPATIBLE_ERROR;
		}
		
	}
	else if(vt == MF_VARDATA_INT64)
	{
		if(m_vt == MF_VARDATA_INT)
		{
			varResult.SetData((long long)m_nValue);
		}
		else if(m_vt == MF_VARDATA_INT64)
		{
			varResult.SetData(m_llValue);
		}
		else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
		{
			varResult.SetData((long long)m_dblValue);
		}
		else
		{
			return MF_PARSECMD_INVALID_DATACOMPATIBLE_ERROR;
		}
	}
	else if(vt == MF_VARDATA_DOUBLE || vt == MF_VARDATA_DATE)
	{
		if(m_vt == MF_VARDATA_INT)
		{
			varResult.SetData((double)m_nValue, vt);
		}
		else if(m_vt == MF_VARDATA_INT64)
		{
			varResult.SetData((double)m_llValue, vt);
		}
		else if(m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
		{
			varResult.SetData(m_dblValue, vt);
		}
		else
		{
			return MF_PARSECMD_INVALID_DATACOMPATIBLE_ERROR;
		}
	}
	else
	{
		if(m_vt == MF_VARDATA_INT || m_vt == MF_VARDATA_INT64 || m_vt == MF_VARDATA_DOUBLE || m_vt == MF_VARDATA_DATE)
		{
			return MF_PARSECMD_INVALID_DATACOMPATIBLE_ERROR;
		}
		else
		{
			if(vt == MF_VARDATA_BINARY)
			{
				varResult.SetBinaryData(m_lpValue, m_nStrLen);
			}	
			else
			{
				varResult.SetData(m_lpszValue, m_nStrLen);
			}
		}
	}

	return MF_OK;
}