﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#define DEF_BUFFER_SIZE 2048
#define MAX_SECTION_BUFFER 512
//基础BSON，作为其他BISO的基类，该类主要负责管理Bson的Buffer
class CBaseBson
{
public:
	CBaseBson(void);
	~CBaseBson(void);
protected:
	//缓存片段头
	typedef struct  
	{
		UINT			m_nNextSectionOffset;	//下一个缓存片段偏移
	}BUFFERSECTIONHEAD, *LPBUFFERSECTIONHEAD;
private:
	LPBYTE		m_lpBuf;						//缓存Buf
protected:
	LPBYTE		m_lpBuffer;						//缓存Buffer
	UINT		m_nFreeBufferSize;				//空闲缓存大小
	UINT        m_nExecutePlanDataSize;			//执行计划数据大小

	BOOL        m_bAutoRelease;					//是否自动释放

	UINT		m_nBsonBufferSize;				//Bson大小
	UINT		m_nBsonDataSize;				//Bson中的数据量

	LPBYTE		m_lpCurrentSection;			    //当前缓存片段
	USHORT		m_nCurrentDataSize;				//当前缓存中已有数据大小
	USHORT		m_nCurrentSectionNo;			//当前缓存片段编号
	UINT		m_nCurrentSectionSzie;			//当前缓存片段大小
	UINT	    m_nDefaultSectionSize;			//默认缓存大小
	
	LPBYTE		m_arrBufferSection[MAX_SECTION_BUFFER];		//缓存片段数组

	USHORT		m_nBufferSectionNum;
	UINT	    m_nSectionStartOffset;			//片段起始偏移

	BOOL		m_bChangeSection;				//是否新建了片段

	LPRECORDHEAD		m_lpPreRecordHead;		//上一条RecordHead指针
	LPEXECUTESTEP		m_lpPreExecuteStep;		//上一条步骤指针
public:
	inline UINT MakeAddrID(USHORT nBufferNo, USHORT nOffset)
	{
		UINT nAddrID;
		nAddrID	= nBufferNo;
		nAddrID = (nAddrID << 16) + nOffset;
		return nAddrID;
	}

	inline USHORT GetBufferNoFromAddrID(UINT nAddrID)
	{
		return (USHORT)(nAddrID >> 16);
	}

protected:
	//移动数据的插入位置
	inline LPBYTE GrowBufferLen(int nLen)
	{
		int nOldLen;

		nOldLen = m_nBsonDataSize;					//记录数据的原长度
		m_nBsonDataSize += nLen;					//递增现有长度
		
		//如果数据长度>Buffer长度则重新分配一块更大的内存
		if(m_nBsonDataSize > m_nBsonBufferSize)
		{
			return NULL;
		}

		return m_lpBuffer + nOldLen;			   //返回数据的插入位置
	}
			
	//判断是否可以插入数据	
	inline BOOL CheckInsert(int nLen)
	{
		return m_nBsonDataSize + nLen <= m_nBsonBufferSize;
	}
public:
	//释放内存
	virtual void Free();

protected:
	//插入BYTE类型数据
	BOOL AppendByte(BYTE bData);
	//插入短整型数据
	BOOL AppendShort(short nData);
	//插入32位整型数据
	BOOL AppendInt32(int nData);
	//插入64位整型数据
	BOOL AppendInt64(long long nData);
	//插入浮点数类型数据
	BOOL AppendDouble(double dData);
public:
	//插入字符串类型数据
	BOOL AppendBuffer(void* pData, int nLen);
public:
	//将字段值写入指定位置
	int WriteFieldData(MF_SYS_FIELDTYPE bFieldType, BYTE bFieldNo, VARDATA &varData, LPBYTE lpAddr = NULL);
	
	//分配总缓存
	int AllocBsonBuffer(UINT nBsonBufferSize);	

	//分配缓存片段
	virtual int AllocBufferSection();	

	//获取Buffer总大小
	virtual inline UINT GetExecutePlanDataSize()
	{
		return m_nExecutePlanDataSize;
	}
public:	
	//获取缓存数量
	int GetBufferSectionNum()
	{
		return m_nBufferSectionNum;
	}

	//获取缓存
	inline LPBYTE GetBufferSection(SHORT nSectionNo)
	{
		if(nSectionNo > m_nBufferSectionNum)
		{
			return NULL;
		}
		else
		{
			return m_arrBufferSection[nSectionNo - 1];
		}
	}

	int GetCurretDataSize()
	{
		return m_nCurrentDataSize;
	}

	//分配空间，用于运算时的空间开销（四则运算、函数运算等），客户端做四则运算的空间是从BsonBuffer中分配，服务端是从循环Buffer中分配
	virtual int AllocBuffer(UINT nLen, LPBYTE &lpAddr)
	{
		UINT nOffset;
		return AllocFromBsonBuffer(nLen, nOffset, lpAddr);
	}

	//从BsonBuffer中分配空间
	template<class T>
	int AllocFromBsonBuffer(T* &pBuffer, UINT& nOffset);
	int AllocFromBsonBuffer(UINT nLen, UINT &nOffset, LPBYTE &lpAddr);

	//从缓存片段中分配空间
	template<class T>
	int AllocFromBufferSection(T* &pBuffer, UINT& nAddrID);
	int AllocFromBufferSection(UINT nLen, UINT &nAddrID, LPBYTE &lpBuffer);

	//分离Buffer
	LPBYTE DetachBuffer();

	//分配记录头
	int AllocRecord(LPRECORDHEAD& lpRecordHead, UINT& nAddrID);

	//分配执行步骤
	int AllocStep(LPEXECUTESTEP& lpExecuteStep, UINT& nAddrID);

	//给缓存片段加上偏移
	void SetSectionOffset();

	//获取当前Buffer空闲区的首地址
	inline LPBYTE ConvertOffset2Addr(long long nOffset)
	{
		if(nOffset == 0 || nOffset == -1)
		{
			return NULL;
		}
		else
		{
			return m_lpBuffer + nOffset;
		}
	}
	
	//BsonBuffer中已有数据的大小
	inline int GetBsonDataSize()
	{
		return m_nBsonDataSize;
	}
	//设置数据的长度(主要用于在Buffer中预留空间)
	inline void SetDataLen(int nLen)
	{
		m_nBsonDataSize = nLen;
	}
	//增加数据长度
	inline void AddDataLen(int nLen)
	{
		m_nBsonDataSize += nLen;
	}
	//获取内存Buffer
	inline LPBYTE GetBuffer()
	{
		return m_lpBuffer;
	}

	//获取内存Buffer大小
	inline UINT GetBufferSize()
	{
		return m_nBsonBufferSize;
	}
	
	//设置Buffer(不能自动释放Buffer)
	void SetBuffer(LPBYTE lpBuffer, int nBufferLen = 0, int nDataLen = 0);
	
	//重置内存Buffer
	inline void ResetBuffer()
	{
		if(m_lpBuffer != NULL)
		{
			memset(m_lpBuffer, 0, m_nBsonBufferSize);
			m_nBsonDataSize = 0;
		}
	}

	//获取偏移
	inline long long GetOffset(LPVOID lpAddr)
	{
		return (LPBYTE)lpAddr - m_lpBuffer;
	}

	//获取空闲区地址ID
	inline UINT GetFreeSectionAddrID()
	{
		return MakeAddrID(m_nCurrentSectionNo, m_nCurrentDataSize);
	}
};

template<class T>
int CBaseBson::AllocFromBsonBuffer(T* &pBuffer, UINT& nOffset)
{
	int nLen, nRet;
		
	if(m_lpBuffer == NULL)
	{
		nRet = AllocBsonBuffer(MF_BUFFERSECTION_SIZE);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	nLen = sizeof(T);
	nOffset = m_nBsonDataSize;
	if(m_nBsonDataSize+nLen > m_nBsonBufferSize)
	{
		return MF_PARSECMD_EXECUTEPALN_LACKSPACE_ERROR;
	}
	m_nBsonDataSize			+= nLen;
	m_nExecutePlanDataSize	+= nLen;
	pBuffer = (T*)(m_lpBuffer + nOffset);
	memset(pBuffer, 0, nLen);
	m_nFreeBufferSize -= nLen;
	return MF_OK;
}

template<class T>
int CBaseBson::AllocFromBufferSection(T* &pBuffer, UINT& nAddrID)
{
	USHORT nOffset;
	UINT nLen, nRet;
	
	if(m_lpCurrentSection == NULL)
	{
		nRet = AllocBufferSection();
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	nLen = sizeof(T);
	if(m_nCurrentDataSize + nLen > m_nCurrentSectionSzie)
	{
		m_nExecutePlanDataSize += m_nCurrentSectionSzie - m_nCurrentDataSize;			//因为是以片段为单位分配空间，所以分配新片段时，需要将原始片段长度补齐
		nRet = AllocBufferSection();
		if(nRet != MF_OK)
		{
			return nRet;
		}
		m_bChangeSection = TRUE;
	}
	nOffset = m_nCurrentDataSize;
	
	m_nCurrentDataSize += nLen;
	m_nExecutePlanDataSize   += nLen;
	pBuffer = (T*)(m_lpCurrentSection + nOffset);
	memset(pBuffer, 0, nLen);
	nAddrID = MakeAddrID(m_nCurrentSectionNo, nOffset);
	return MF_OK;
}

