﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "CommonDataDef.h"
#include "MFString.h"
#include "BaseExpression.h"
#include "LinuxCommonAPI.h"
class CBaseBson;
class CCriticalSectionPtr
{
public:
	CCriticalSectionPtr(LPCRITICAL_SECTION lp);
	virtual ~CCriticalSectionPtr(void);
private:
	LPCRITICAL_SECTION m_lpcs;
};

class CExecutePlanCriticalPtr
{
public:
	CExecutePlanCriticalPtr(LPCRITICAL_SECTION lp, LPEXECUTEPLANBSON lpExecutePlan);
	virtual ~CExecutePlanCriticalPtr(void);
private:
	LPCRITICAL_SECTION m_lpcs;
	long long	*	   m_lpCritStack;
	LPEXECUTEPLANBSON m_lpExecutePlan;
};

//UTF8和UNICODE编码转换函数
char* ConvertToUTF8(const wchar_t * strData);
char* ConvertToUTF8(const wchar_t * strData, int &nLen);
char* ConvertBSTR2UTF8(const wchar_t * strData, int &nLen);
wchar_t* ConvertWCHAR(const char * lpszData, int nLength);
string ConvertString(const wchar_t * strData);
char* UTF8ConvertAnsi(const char * lpszData);
string UTF8ConvertASC(const char * lpszData);
//将UTF8转换成Unicode格式
wchar_t* ETConvertWCHAR(const char * lpszData, int nLen);

//判断是否数字，0表示含有非数字，1表示十进制数字，2表示十六进制数字，3表示浮点数
int IsNumber(const char* lpszData);
long long ToNumber(const char* lpszData, int nDataSize);
double ToDouble(const char* lpszData);

int GetIndexType(MF_SYS_FILETYPE bFileType, MF_SYS_FIELDTYPE bFieldType, MF_SYS_INDEXTYPE &bIndexType);

//判断名字规范，1表示前后都带双引号（意味着大小写敏感），2表示正常字段名，我们自动强制转换成大写，0表示不符合命名规范
int CopyNameFromSql(const char* lpszData, int nDataLen, char * lpszName);

int CopyUserNameFromSql(const char* pData, int nDataLen, char * pName);
//判断字符串规范，1表示按正确规范写的字符串（前后都带单引号），2表示传入的字符串太长，0表示不符合规范
int CopyStringFromSql(const char* lpszData, int nDataLen, char * lpszName, int nSize);
int CopyStringFromSql(const char* lpszData, int nDataLen, VARDATA &varValue);

//判断字符串是否合法
int CheckValidStr(const char* lpszData, int nDataLen);

//获取密码
int CopyPassWordFromSql(const char* pData, int nDataLen, BYTE* pPassWord);

//获取数据Buffer的长度
int GetFieldBufferLen(int& nLen, MF_SYS_FIELDTYPE bType, int nStringLen = 0);

//计算SQL语句的HASH值，为了统一，直接对放入执行计划的SQ语句进行计算（UTF8编码）
DWORD CalcSQLHash(const char * lpszSql, int nLen);
DWORD BKDRHash(char *str, int nLen);

//计算给的的Key数据，其中Key数据必须以\0作为结束符，nHashSize为HASH的大小，得出结果为除以它取余数
DWORD CalcKeyHash(LPBYTE lpKey, int nHashSize);
DWORD CalcKeyHash(long long nKey, int nHashSize);

//从字段Buffer中获取字段值
int GetValueFromFieldBuffer(BYTE bFieldType, LPBYTE lpFieldBuffer, VARDATA& varValue);

//二进制转换成字符串
int HexConvertChar(const LPBYTE lpBuf, const int nLen, char *lpszData);
int HexConvertWChar(const LPBYTE lpBuf, const int nLen, wchar_t *lpszData);

//字符串转换成二进制
int CharConvertHex(const char *lpszData, LPBYTE lpBuf, const int nBufsize);
int WCharConvertHex(const wchar_t *lpszData, LPBYTE lpBuf, const int nBufsize);


#define DAYSECONDS 86400
#define XDAY 134774
#define XSEC 11644473600
#define X100NSEC 116444736000000000

//时间转换函数
long long ConvertTimetoLongLong(struct timeval tTime);
void ConvertTimetoFileTime(struct timeval tTime, FILETIME &fTime);
struct timeval ConvertFileTimetoTime(FILETIME fTime);
DATE ConvertTimetoDate(time_t tTime);
time_t ConvertDateToTime(DATE dtTime);

//比较Double类型
int CompareDouble(double dblValue1, double dblValue2);

//加密
int Encryption(BYTE* pSrc, BYTE* pDest);

//获取错误码描述
char * GetErrorDescription(int nErrorNO);
wchar_t * GetErrorWDescription(int nErrorNO);

