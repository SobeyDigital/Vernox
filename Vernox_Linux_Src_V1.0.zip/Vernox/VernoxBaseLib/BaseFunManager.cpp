﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "BaseFunManager.h"
#include "Date.h"
CBaseFunManager::CBaseFunManager(void)
{
}

CBaseFunManager::~CBaseFunManager(void)
{
}

//时间函数
int	CBaseFunManager::SysData(VARDATA& varResult)
{
#ifdef WIN32
	SYSTEMTIME sysTime;
	GetLocalTime(&sysTime);
	DATE dtDate;
	if(!::SystemTimeToVariantTime(&sysTime, &dtDate))
	{
		return MF_COMMON_INVALID_DATA;
	}
	else
	{
		varResult.SetData(dtDate, MF_VARDATA_DATE);
	}
	return MF_OK;
#else
	return MF_OK;
#endif
}

//TODATE函数
int CBaseFunManager::ToDate(char* pDate, char* pDateFormat, VARDATA& varResult)
{
	int nRet = 0;
	DATE dtDate = 0;
	nRet = CDate::ToDate(pDate, pDateFormat, dtDate);
	varResult.SetData(dtDate, MF_VARDATA_DATE);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}
//TOCHAR函数
int CBaseFunManager::ToChar(CBaseBson& stBson, VARDATA varData, VARDATA& varResult, char* pDateFormat)
{
	int nRet;
	LPBYTE lpData;;
	if(varData.m_vt == MF_VARDATA_DATE)
	{
		nRet = CDate::ToChar(stBson, varData.m_dblValue, pDateFormat, lpData);
	}
	else
	{
		nRet = CDate::ToChar(stBson, varData, lpData);
	}
	if(nRet != MF_OK)
	{
		return nRet;
	}
	varResult.SetData((char*)lpData, 32);
	return MF_OK;
}

//获得普通函数的函数值
int CBaseFunManager::GetFunctionVal(CBaseBson& stBson, BYTE bFunType, const VARDATA& varValue1, const VARDATA& varValue2, VARDATA& varResult)
{
	int nRet = 0;
	if(MF_EXECUTEPLAN_OPERATOR_NEXTVAL == bFunType || MF_EXECUTEPLAN_OPERATOR_CURRVAL == bFunType)
	{
		return MF_COMMON_INVALID_DATATYPE;
	}
	switch(bFunType)
	{
	case MF_EXECUTEPLAN_OPERATOR_SYSDATE:
		nRet = SysData(varResult);
		break;
	case MF_EXECUTEPLAN_OPERATOR_TODATE:
		if(varValue1.m_vt == MF_VARDATA_DATE)
		{
			varResult.SetData(varValue1);
		}
		else
		{
			nRet = ToDate(varValue1.m_lpszValue, varValue2.m_lpszValue, varResult);
		}
		break;
	case MF_EXECUTEPLAN_OPERATOR_TOCHAR:
		nRet = ToChar(stBson, varValue1, varResult, varValue2.m_lpszValue);
		break;
	}
	return nRet;
}
//获取函数返回值类型
int CBaseFunManager::GetFunRetValType(BYTE bFunction, BYTE& bRetType)
{
	switch(bFunction)
	{
	case MF_EXECUTEPLAN_OPERATOR_COUNT:
	case MF_EXECUTEPLAN_OPERATOR_NEXTVAL:
	case MF_EXECUTEPLAN_OPERATOR_CURRVAL:
	case MF_EXECUTEPLAN_OPERATOR_CHECKCHILD:
		bRetType = MF_SYS_FIELDTYPE_INT;
		break;
	case MF_EXECUTEPLAN_OPERATOR_TODATE:
	case MF_EXECUTEPLAN_OPERATOR_SYSDATE:
		bRetType = MF_SYS_FIELDTYPE_DATE;
		break;
	case MF_EXECUTEPLAN_OPERATOR_TOCHAR:
		bRetType = MF_SYS_FIELDTYPE_CHAR;
		break;
	default:
		return MF_COMMON_INVALID_DATATYPE;
	}
	return MF_OK;
}

//获取函数返回值所需Buffer大小
int CBaseFunManager::GetFuncBufferLen(BYTE bFunction, int& nLen)
{
	switch(bFunction)
	{
	case MF_EXECUTEPLAN_OPERATOR_COUNT:					     
	case MF_EXECUTEPLAN_OPERATOR_CURRVAL:	
	case MF_EXECUTEPLAN_OPERATOR_NEXTVAL:
		nLen = sizeof(BYTE) + sizeof(int);
		break;
	case MF_EXECUTEPLAN_OPERATOR_SYSDATE:
	case MF_EXECUTEPLAN_OPERATOR_TODATE:
		nLen = sizeof(BYTE) + sizeof(double);
		break;
	case MF_EXECUTEPLAN_OPERATOR_TOCHAR:
		nLen = sizeof(BYTE) + 32;
		break;
	default: 
		return MF_COMMON_INVALID_DATATYPE;
	}
	return MF_OK;
}