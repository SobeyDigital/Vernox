﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MemoryBaseAnalysis.h"

#ifdef WIN32
CBaseMemoryAnalysis::CBaseMemoryAnalysis()
{
	m_pTinyXmlRoot    = NULL;
	m_pXmlObjectInfo  = NULL;
}

CBaseMemoryAnalysis::~CBaseMemoryAnalysis(void)
{
	if(m_pTinyXmlRoot != NULL)
	{
		delete m_pTinyXmlRoot;
		m_pTinyXmlRoot = NULL;
	}
	if(m_pXmlObjectInfo != NULL)
	{
		delete m_pXmlObjectInfo;
		m_pXmlObjectInfo = NULL;
	}
	//m_pTableMap = NULL;
}

/************************************************************************
		功能说明：
			创建xml
		参数说明：
			pRsXml:XML字符串
			lpBsonBuffer:BSONBuffer
		特别说明：
			创建XML的过程
			1.读取pField的第一个字节，得到字段编号
			2.调用GetFieldInfo()得到该编号对应的字段的类型和名称
			3.通过字段的类型获取字段值,并计算字段的总长度
			4.将字段名称和字段值写入XML
************************************************************************/
int CBaseMemoryAnalysis::BuildXML(std::string &pRsXml, LPBYTE lpBsonBuffer, LPEXECUTESTATISTICSINFO lpExecuteInfo)
{	
	BYTE bFieldNo;
	char pBuffer[32];
	long long nDataID;
	SYSTEMTIME sysTime;
	LPRECORDFIELD lpFieldInfo;
	LPRECORDSETHEAD lpRecordsetHead;
	LPBYTE lpRecordBuffer, lpTempBuffer;
	char* pHexBuffer, *pFieldName, *pRsName, *pTitle, *pObjectName;
	TiXmlElement *pAttributeType, *pDataType, *pData, *pRow, *pElementRootPtr, *pSchema,*pElementType;
	int i, j, nRet, nExecuteFieldNum, nDataNum, nRecordBufferLen, nTempRecordLen, nFieldBufferLen, nStrLen, nTempLen;

	memset(pBuffer, 0 ,32);
	//创建根结点
	m_pTinyXmlRoot = new TiXmlDocument;
	pElementRootPtr = new TiXmlElement("xml");
	m_pTinyXmlRoot->LinkEndChild(pElementRootPtr);

	//为根节点添加属性(带命名空间)
	pElementRootPtr->SetAttribute("xmlns:s", "uuid:BDC6E3F0-6DA3-11d1-A2A3-00AA00C14882");
	pElementRootPtr->SetAttribute("xmlns:dt", "uuid:C2F41010-65B3-11d1-A29F-00AA00C14882");
	pElementRootPtr->SetAttribute("xmlns:rs", "urn:schemas-microsoft-com:rowset");
	pElementRootPtr->SetAttribute("xmlns:z", "#RowsetSchema");

	//创建Schema结点
	pSchema = new TiXmlElement("s:Schema");
	pSchema->SetAttribute("id", "RowsetSchema");
	pElementRootPtr->LinkEndChild(pSchema);

	//创建ElementType结点
	pElementType = new TiXmlElement("s:ElementType");
	pElementType->SetAttribute("name", "row");
	pElementType->SetAttribute("content", "eltOnly");
	pElementType->SetAttribute("rs:updatable", "true");
	pSchema->LinkEndChild(pElementType);
	
	//解析BSON，获取字段数
	lpRecordsetHead  = (LPRECORDSETHEAD)lpBsonBuffer;
	nExecuteFieldNum = lpRecordsetHead->m_nFieldNum;
	nDataNum		 = lpRecordsetHead->m_nRowNum;
	lpFieldInfo		 = lpRecordsetHead->m_lpRecordField;
	lpRecordBuffer	 = lpBsonBuffer + lpRecordsetHead->m_nRecordBufferOffset;
	for(i = 0; i < nExecuteFieldNum; i++)
	{
		//创建AttributeType结点
		pAttributeType = new TiXmlElement("s:AttributeType");
		//////////////////////////////////////////////////////////////////////////
		//m_lpszName;		//name				XML中识别标识
		//m_lpszRsName;		//rs:name			用于显示的名称（原名\别名等）
		//m_lpszTitle;		//rs:basecolumn		数据库中原名
		pFieldName = (char*)(lpBsonBuffer + lpFieldInfo[i].m_nFieldNameOffset);
		pAttributeType->SetAttribute("name", pFieldName);
		pRsName	   = (char*)(lpBsonBuffer + lpFieldInfo[i].m_nRsNameOffset);
		pAttributeType->SetAttribute("rs:name", pRsName);
		pAttributeType->SetAttribute("rs:number", i+1);
		if(lpFieldInfo[i].m_bAllowNull)
		{
			pAttributeType->SetAttribute("rs:nullable", "true");
		}
		pAttributeType->SetAttribute("rs:writeunknown", "true");											
		pObjectName = (char*)(lpBsonBuffer + lpFieldInfo[i].m_nObjectNameOffset);
		pAttributeType->SetAttribute("rs:basetable", pObjectName);
		pTitle = (char*)(lpBsonBuffer + (lpFieldInfo[i].m_nTitleOffset));
		pAttributeType->SetAttribute("rs:basecolumn",pTitle);
		if(lpFieldInfo[i].m_bPrimaryKey)
		{
			pAttributeType->SetAttribute("rs:keycolumn", "true");
		}
		//////////////////////////////////////////////////////////////////////////
		pElementType->LinkEndChild(pAttributeType);
		
		//创建datatype结点
		pDataType = new TiXmlElement("s:datatype");
		switch(lpFieldInfo[i].m_bFieldType)
		{
		case MF_SYS_FIELDTYPE_INT:
			pDataType->SetAttribute("dt:type", "number");
			pDataType->SetAttribute("rs:dbtype", "numeric");
			pDataType->SetAttribute("dt:maxLength", "19");
			pDataType->SetAttribute("rs:scale", "0");
			pDataType->SetAttribute("rs:precision", "10");
			pDataType->SetAttribute("rs:fixedlength", "true");
			break;
		case MF_SYS_FIELDTYPE_BIGINT:
			pDataType->SetAttribute("dt:type", "number");
			pDataType->SetAttribute("rs:dbtype", "numeric");
			pDataType->SetAttribute("dt:maxLength", "19");
			pDataType->SetAttribute("rs:scale", "0");
			pDataType->SetAttribute("rs:precision", "20");
			pDataType->SetAttribute("rs:fixedlength", "true");
			break;
		case MF_SYS_FIELDTYPE_DOUBLE:
			pDataType->SetAttribute("dt:type", "number");
			pDataType->SetAttribute("rs:dbtype", "varnumeric");
			pDataType->SetAttribute("dt:maxLength","38");
			pDataType->SetAttribute("rs:scale","255");
			pDataType->SetAttribute("rs:precision","38");
			break;	
		case MF_SYS_FIELDTYPE_DATE:
			pDataType->SetAttribute("dt:type", "dateTime");
			pDataType->SetAttribute("rs:dbtype", "timestamp");
			pDataType->SetAttribute("dt:maxLength","16");
			pDataType->SetAttribute("rs:scale","0");
			pDataType->SetAttribute("rs:precision","19");
			pDataType->SetAttribute("rs:fixedlength","true");
			break;
		case MF_SYS_FIELDTYPE_CHAR:
			sprintf(pBuffer,"%d",(int)lpFieldInfo[i].m_bMaxLen);
			pDataType->SetAttribute("dt:type", "string");
			pDataType->SetAttribute("dt:maxLength", pBuffer);
			break;
		case MF_SYS_FIELDTYPE_VARCHAR:
			pDataType->SetAttribute("dt:type", "string");
			pDataType->SetAttribute("dt:maxLength", "256");
			break;
		case MF_SYS_FIELDTYPE_CLOB:
			pDataType->SetAttribute("dt:type", "string");
			pDataType->SetAttribute("dt:maxLength", "1073741823");
			pDataType->SetAttribute("rs:long","true");
			break;
		case MF_SYS_FIELDTYPE_BLOB:
			pDataType->SetAttribute("dt:type", "bin.hex");
			pDataType->SetAttribute("dt:maxLength", "2147483647");
			pDataType->SetAttribute("rs:long","true");
			break;
		default:
			return MF_COMMON_INVALID_DATATYPE;
		}
		pAttributeType->LinkEndChild(pDataType);
	}

	//创建ROWID列
	pAttributeType = new TiXmlElement("s:AttributeType");
	pAttributeType->SetAttribute("name", "ROWID");
	pAttributeType->SetAttribute("rs:number", nExecuteFieldNum+1);
	pAttributeType->SetAttribute("rs:nullable",0);
	pAttributeType->SetAttribute("rs:writeunknown", "true");

	pObjectName = (char*)(lpBsonBuffer + lpFieldInfo[0].m_nObjectNameOffset);
	pAttributeType->SetAttribute("rs:basetable", pObjectName);
	pAttributeType->SetAttribute("rs:basecolumn","ROWID");
	pAttributeType->SetAttribute("rs:hidden","true");
	pElementType->LinkEndChild(pAttributeType);
			
	//创建datatype结点
	pDataType = new TiXmlElement("s:datatype");
	pDataType->SetAttribute("dt:type", "number");
	pDataType->SetAttribute("rs:dbtype", "numeric");
	pDataType->SetAttribute("dt:maxLength", "19");
	pDataType->SetAttribute("rs:scale", "0");
	pDataType->SetAttribute("rs:precision", "20");
	pDataType->SetAttribute("rs:fixedlength", "true");
	pAttributeType->LinkEndChild(pDataType);
	
	//创建data结点
	pData = new TiXmlElement("rs:data");
	pElementRootPtr->LinkEndChild(pData);
	
	lpTempBuffer = lpRecordBuffer;
	for(i = 0; i < nDataNum; i++)
	{
		//创建z:row结点
		pRow				= new TiXmlElement("z:row");

		//获取记录长度
		nRecordBufferLen	= *(int*)lpTempBuffer;
		nTempRecordLen		= nRecordBufferLen;
		lpTempBuffer		+= sizeof(int);
		nTempRecordLen		-= sizeof(int);
		
		//获取DataID
		nDataID				= *(long long*)lpTempBuffer;
		lpTempBuffer		+= sizeof(long long);
		nTempRecordLen		-= sizeof(long long);
		
		pRow->SetAttribute("ROWID", nDataID);
		for(j = 0; j < nExecuteFieldNum; j++)
		{
			if(nTempRecordLen <= 1)
			{
				//最后一个字节是结束符
				break;				
			}

			//取出Buffer中的字段编号
			bFieldNo = *(BYTE*)lpTempBuffer;
			if(bFieldNo != j)
			{
				//如果字段编号和顺序不匹配(存在空字段时会出现这种情况，则continue)
				continue;			
			}
			pFieldName = (char*)(lpBsonBuffer + lpFieldInfo[j].m_nFieldNameOffset);
			switch(lpFieldInfo[j].m_bFieldType)
			{
			case MF_SYS_FIELDTYPE_INT:
				nFieldBufferLen = sizeof(BYTE) + sizeof(int);
				pRow->SetAttribute(pFieldName, *(int*)(lpTempBuffer + sizeof(BYTE)));
				break;
			case MF_SYS_FIELDTYPE_BIGINT:
				nFieldBufferLen = sizeof(BYTE) + sizeof(long long);
				pRow->SetAttribute(pFieldName, *(long long*)(lpTempBuffer + sizeof(BYTE)));
				break;
			case MF_SYS_FIELDTYPE_DOUBLE:
				nFieldBufferLen = sizeof(BYTE) + sizeof(double);
				sprintf(pBuffer, "%f", *(double*)(lpTempBuffer + sizeof(BYTE)));
				pRow->SetAttribute(pFieldName, pBuffer);
				break;
			case MF_SYS_FIELDTYPE_DATE:
				nFieldBufferLen = sizeof(BYTE) + sizeof(double);
				if(!VariantTimeToSystemTime(*(double*)(lpTempBuffer + sizeof(BYTE)), &sysTime))
				{
					//return MF_COMMON_INVALID_DATA;
					sprintf_s(pBuffer, 32, "1000-01-01T00:00:00");
					pRow->SetAttribute(pFieldName, pBuffer);
				}
				else
				{
					sprintf_s(pBuffer, 32, "%04d-%02d-%02dT%02d:%02d:%02d",sysTime.wYear,sysTime.wMonth,sysTime.wDay,sysTime.wHour,sysTime.wMinute,sysTime.wSecond);
					pRow->SetAttribute(pFieldName, pBuffer);
				}
				break;
			case MF_SYS_FIELDTYPE_CHAR:
			case MF_SYS_FIELDTYPE_VARCHAR:
			case MF_SYS_FIELDTYPE_CLOB:
				nStrLen = *(BYTE*)(lpTempBuffer + sizeof(BYTE));
				if(nStrLen == 0)
				{
					nTempLen		= sizeof(BYTE) + sizeof(BYTE);
					nFieldBufferLen	= nStrLen + sizeof(BYTE) + sizeof(BYTE);
					pRow->SetAttribute(pFieldName, "");
				}
				else
				{
					if(nStrLen == 255)
					{
						nTempLen		= sizeof(int) + sizeof(BYTE) + sizeof(BYTE);
						nStrLen			= *(int*)(lpTempBuffer + sizeof(BYTE) + sizeof(BYTE));	
						nFieldBufferLen	= nStrLen + nTempLen;
					}
					else
					{
						nTempLen		= sizeof(BYTE) + sizeof(BYTE);
						nFieldBufferLen	= nStrLen + sizeof(BYTE) + sizeof(BYTE);
					}
					pRow->SetAttribute(pFieldName, (char*)(lpTempBuffer + nTempLen));
				}
				break;	
			case MF_SYS_FIELDTYPE_BLOB:
				nStrLen = *(BYTE*)(lpTempBuffer + sizeof(BYTE));
				if(nStrLen == 0)
				{
					nTempLen		= sizeof(BYTE) + sizeof(BYTE);
					nFieldBufferLen	= nStrLen + sizeof(BYTE) + sizeof(BYTE);
					pRow->SetAttribute(pFieldName, "");
				}
				else
				{
					if(nStrLen == 255)
					{
						nTempLen		= sizeof(int) + sizeof(BYTE) + sizeof(BYTE);
						nStrLen			= *(int*)(lpTempBuffer + sizeof(BYTE) + sizeof(BYTE));	
						nFieldBufferLen	= nStrLen + nTempLen;
					}
					else
					{
						nTempLen		= sizeof(BYTE) + sizeof(BYTE);
						nFieldBufferLen	= nStrLen + sizeof(BYTE) + sizeof(BYTE);
					}

					pHexBuffer = new char[nFieldBufferLen*2+1];
					nRet = HexConvertChar(lpTempBuffer + nTempLen, nFieldBufferLen, pHexBuffer);
					if(nRet != MF_OK)
					{
						delete [] pHexBuffer;
						return nRet;
					}
					pRow->SetAttribute(pFieldName, pHexBuffer);
					delete [] pHexBuffer;
				}
				break;	
			}
			lpTempBuffer	+= nFieldBufferLen;
			nTempRecordLen	-= nFieldBufferLen;
		}

		pData->LinkEndChild(pRow);
		
		lpRecordBuffer += nRecordBufferLen;
		lpTempBuffer = lpRecordBuffer;
	}
	
	//m_pTinyXmlRoot->SaveFile("C:\\Users\\obvious\\Desktop\\myXML.xml");

	TiXmlPrinter stuXMLprinter;
	m_pTinyXmlRoot->Accept(&stuXMLprinter);
	pRsXml = stuXMLprinter.CStr();
	return MF_OK;
}

/************************************************************************
		功能说明：
			解析XML，填充执行计划
		参数说明：
			stBson：Bson对象
			bstrXML：XML字符串
			lpUpdateRecordsetBson：更新执行计划BSON
************************************************************************/
int CBaseMemoryAnalysis::ParseXML(CBaseBson& stBson, BSTR bstrXML, LPEXECUTEPLANBSON& lpExecutePlan)
{
	int nRet, nLen;
	char *lpszXML, *pObjectName;
	
	//转换XML格式
	nLen = 0;
	lpszXML = ConvertToUTF8(bstrXML, nLen);
	if(lpszXML == NULL)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	
	if(m_pXmlObjectInfo != NULL)
	{
		delete m_pXmlObjectInfo;
		m_pXmlObjectInfo = NULL;
	}
	if(m_pTinyXmlRoot != NULL)
	{
		delete m_pTinyXmlRoot;
		m_pTinyXmlRoot = NULL;
	}
	m_pTinyXmlRoot = new TiXmlDocument;

	//读取XML
	m_pTinyXmlRoot->Parse(lpszXML);
	if(m_pTinyXmlRoot->Error())
	{
		delete [] lpszXML;
		return MF_INNER_SYS_LOADXML_ERROR;			//XML字符串加载失败
	}

	//m_pTinyXmlRoot->SaveFile("C:\\Users\\obvious\\Desktop\\myXML.xml");

	//根据XML解析Object相关信息
	nRet = GetXmlObjectDef();
	if(nRet != MF_OK)
	{
		delete [] lpszXML;
		return nRet;
	}
	pObjectName = m_pXmlObjectInfo->m_pObjectName;
	nRet = ParseMemXML(stBson, lpszXML, nLen, lpExecutePlan);

	delete [] lpszXML;
	return nRet;
}

int CBaseMemoryAnalysis::ParseXML(CBaseBson& stBson, const char * lpszXML, int nXmlLen, LPEXECUTEPLANBSON& lpExecutePlan)
{
	int nRet;
	char *pObjectName;

	if(m_pXmlObjectInfo != NULL)
	{
		delete m_pXmlObjectInfo;
		m_pXmlObjectInfo = NULL;
	}
	if(m_pTinyXmlRoot != NULL)
	{
		delete m_pTinyXmlRoot;
		m_pTinyXmlRoot = NULL;
	}
	m_pTinyXmlRoot = new TiXmlDocument;

	//读取XML
	m_pTinyXmlRoot->Parse(lpszXML);
	if(m_pTinyXmlRoot->Error())
	{
		return MF_INNER_SYS_LOADXML_ERROR;			//XML字符串加载失败
	}

	//根据XML解析Object相关信息
	nRet = GetXmlObjectDef();
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pObjectName = m_pXmlObjectInfo->m_pObjectName;
	nRet = ParseMemXML(stBson, lpszXML, nXmlLen, lpExecutePlan);
	delete [] lpszXML;
	return nRet;
}

/************************************************************************
		功能说明：
			解析内存数据库XML，创建BSON
		参数说明：
			stBson：Bson对象
			lpszXML：XML字符串
			nXmlLen：XML长度
			lpExecutePlan：执行计划
************************************************************************/
int CBaseMemoryAnalysis::ParseMemXML(CBaseBson& stBson, const char * lpszXML, int nXmlLen, LPEXECUTEPLANBSON& lpExecutePlan)
{
	LPBYTE lpAddr;
	BYTE bFieldNum;
	UINT nOffset, nAddrID;
	LPRECORDHEAD lpRecordHead;
	TiXmlAttribute* pXmlAttribute;
	const char*	pObjectName, *pDataID;
	LPOBJECTNAMEBSON lpObjectNameBson;
	int	nRet, nRecordNum, nStepNo, nStepNum;
	LPUPDATERECORDSETPLANBSON lpUpdateRecordsetPlan;
	TiXmlElement* pXmlElementRoot, *pXmlElement, *pDataNodeElement, *pDeleteNode, *pInsertNode, *pUpdateNode;
	
	//m_pTinyXmlRoot->SaveFile("D:\\myXML3.xml");
	pObjectName = m_pXmlObjectInfo->m_pObjectName; 
	pXmlElementRoot = m_pTinyXmlRoot->FirstChildElement();

	//申请一块内存空间，用于存储执行计划的一系列预处理信息
	nRet = stBson.AllocBsonBuffer(2*nXmlLen + 1024);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = stBson.AllocFromBsonBuffer(lpExecutePlan, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = stBson.AllocFromBsonBuffer(lpUpdateRecordsetPlan, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlan->m_nCommandOffset = nOffset;
	
	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(sizeof(OBJECTNAMEBSON)+m_pXmlObjectInfo->m_nObjectNameLen, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpUpdateRecordsetPlan->m_nObjectNameOffset = nOffset;
	lpObjectNameBson = (LPOBJECTNAMEBSON)lpAddr;
	lpObjectNameBson->m_bLen = m_pXmlObjectInfo->m_nObjectNameLen;
	memcpy(lpObjectNameBson->m_pObjectName, pObjectName, m_pXmlObjectInfo->m_nObjectNameLen);

	//2.获取字段信息
	nRet = GetXmlFieldInfo(stBson, lpUpdateRecordsetPlan->m_nFieldInfoOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpUpdateRecordsetPlan->m_nFieldNum = m_pXmlObjectInfo->m_bFieldNum;
	//优化，先找到rs:data结点再从rs:data结点寻找操作类型，会比全表遍历开销更小
	nRet = SelectSingleNode(pXmlElementRoot, "rs:data", pDataNodeElement);
	if(nRet != MF_OK)
	{
		return MF_INNER_SYS_NOMATCHNODE_ERROR;
	}

	//3.获取结果集更新操作的所有记录条数(也就是步骤数)
	nRecordNum = 0;
	pDeleteNode = NULL;
	nRet = SelectSingleNode(pDataNodeElement, "rs:delete", pDeleteNode);
	if(nRet == MF_OK)
	{
		nStepNum = 0;
		pXmlElement = pDeleteNode->FirstChildElement();
		while(pXmlElement)
		{
			nRecordNum++;
			nStepNum++;
			pXmlElement = pXmlElement->NextElement();
		}
		lpUpdateRecordsetPlan->m_nDeleteStepNum = nStepNum;
	}
	pUpdateNode = NULL;
	nRet = SelectSingleNode(pDataNodeElement, "rs:update", pUpdateNode);
	if(nRet == MF_OK)
	{
		nStepNum = 0;
		pXmlElement = pUpdateNode;
		while(pUpdateNode != NULL && strcmp(pUpdateNode->Value(), "rs:update") == 0)
		{
			nRecordNum++;
			nStepNum++;
			pXmlElement = pXmlElement->NextElement();
		}
		lpUpdateRecordsetPlan->m_nUpdateStepNum = nStepNum;
	}
	pInsertNode = NULL;
	nRet = SelectSingleNode(pDataNodeElement, "rs:insert", pInsertNode);
	if(nRet == MF_OK)
	{
		nStepNum = 0;
		pXmlElement = pInsertNode->FirstChildElement();
		while(pXmlElement)
		{
			nRecordNum++;
			nStepNum++;
			pXmlElement = pXmlElement->NextElement();
		}
		lpUpdateRecordsetPlan->m_nInsertStepNum = nStepNum;
	}
	lpUpdateRecordsetPlan->m_nExecuteStepNum = nRecordNum;
	
	//4.分配空间存放记录信息
	nStepNo = 1;
	if(pDeleteNode != NULL)
	{
		//执行Delete步骤
		lpUpdateRecordsetPlan->m_nDeleteStepNo = nStepNo;
		pXmlElement = pDeleteNode->FirstChildElement();
		if(pXmlElement == NULL)
		{
			return MF_INNER_SYS_NULLNODE_ERROR;
		}
		//遍历XML的rs:delete结点找到需要删除的记录的相关信息
		while(pXmlElement != NULL)
		{
			nRet = stBson.AllocRecord(lpRecordHead, nAddrID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpUpdateRecordsetPlan->m_nRecordAddrID == 0)
			{
				lpUpdateRecordsetPlan->m_nRecordAddrID = nAddrID;
			}
	
			lpRecordHead->m_bType = MF_EXECUTE_STEP_DELETEDATA;
			pDataID = pXmlElement->Attribute("ROWID");
			if(pDataID == NULL)
			{
				return MF_INNER_SYS_NOMATCHNODE_ERROR;
			}
			lpRecordHead->m_nDataID = _atoi64(pDataID);
			
			nStepNo++;
			pXmlElement = pXmlElement->NextElement();
		}
	}
	
	//执行Update操作
	if(pUpdateNode != NULL)
	{
		//获取更新字段数
		lpUpdateRecordsetPlan->m_nUpdateStepNo = nStepNo + 1;
		nRet = GetFieldNum(pUpdateNode, bFieldNum);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		while(pUpdateNode)
		{
			nRet = stBson.AllocRecord(lpRecordHead, nAddrID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpUpdateRecordsetPlan->m_nRecordAddrID == 0)
			{
				lpUpdateRecordsetPlan->m_nRecordAddrID = nAddrID;
			}

			lpRecordHead->m_bType	  = MF_EXECUTE_STEP_UPDATEDATA;
			lpRecordHead->m_bFieldNum = bFieldNum;
			//找到<rs:update>下的<rs:original>结点下的z:row结点中的ROWID属性值
			nRet = SelectSingleNodeFromCurrentRoot(pUpdateNode->FirstChildElement(), "z:row", pXmlElement);
			if(nRet != MF_OK)
			{
				return MF_INNER_SYS_NOMATCHNODE_ERROR;
			}

			pDataID = pXmlElement->Attribute("ROWID");
			if(pDataID == NULL)
			{
				return MF_INNER_SYS_NOMATCHNODE_ERROR;
			}
			lpRecordHead->m_nDataID = _atoi64(pDataID);
			//找到<rs:update>下的z:row结点(即需要更新的字段)
			nRet = SelectSingleNodeFromCurrentRoot(pUpdateNode, "z:row", pXmlElement);
			if(nRet != MF_OK)
			{
				return MF_INNER_SYS_NOMATCHNODE_ERROR;
			}

			//5.获取记录中的字段信息
			pXmlAttribute = pXmlElement->FirstAttribute();
			nRet = GetXmlFieldBson(stBson, lpRecordHead, pXmlAttribute);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nStepNo++;
			pUpdateNode = pUpdateNode->NextElement();
		}
	}
	//执行Insert操作
	if(pInsertNode != NULL)
	{
		lpUpdateRecordsetPlan->m_nInsertStepNo = nStepNo + 1;
		//获取插入字段数
		nRet = GetFieldNum(pInsertNode, bFieldNum);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pXmlElement = pInsertNode->FirstChildElement();
		if(pXmlElement == NULL)
		{
			return MF_INNER_SYS_NULLNODE_ERROR;
		}
		//遍历XML的rs:delete结点找到需要删除的记录的相关信息
		while(pXmlElement != NULL)
		{
			nRet = stBson.AllocRecord(lpRecordHead, nAddrID);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(lpUpdateRecordsetPlan->m_nRecordAddrID == 0)
			{
				lpUpdateRecordsetPlan->m_nRecordAddrID = nAddrID;
			}

			lpRecordHead->m_bType	  = MF_EXECUTE_STEP_INSERTDATA;
			lpRecordHead->m_bFieldNum = bFieldNum;
				
			//获取字段值
			pXmlAttribute = pXmlElement->FirstAttribute();
			nRet = GetXmlFieldBson(stBson, lpRecordHead, pXmlAttribute);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nStepNo++;
			pXmlElement = pXmlElement->NextElement();
		}
	}


	//获取XML信息字符串
	nRet = GetXmlInfoStr(stBson, m_pXmlObjectInfo, lpUpdateRecordsetPlan->m_nDeleteStepNum, lpUpdateRecordsetPlan->m_nUpdateStepNum, lpUpdateRecordsetPlan->m_nInsertStepNum, lpExecutePlan->m_nSqlLen);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//给缓存片段加上偏移
	stBson.SetSectionOffset();

	lpExecutePlan->m_nType				 = MF_EXECUTEPLAN_CMDTYPE_UPDATERECORDSET;
	lpExecutePlan->m_nDefaultSectionSize = MF_BUFFERSECTION_SIZE;
	lpExecutePlan->m_nClientSectionNum	 = stBson.GetBufferSectionNum();
	lpExecutePlan->m_nClientBsonDataSize = stBson.GetBsonDataSize();
	lpExecutePlan->m_nSectionStartOffset = stBson.GetBsonDataSize(); 
	lpExecutePlan->m_nBsonDataSize		 = stBson.GetExecutePlanDataSize();					//对于UpdateRecordset来说BsonDataSize的大小为总大小
	lpExecutePlan->m_nTotalDataSize      = stBson.GetExecutePlanDataSize();
	lpExecutePlan->m_nFreeSectionAddrID  = stBson.GetFreeSectionAddrID();
	lpExecutePlan->m_bWriteLog			 = 1;
	return MF_OK;
}

/************************************************************************
	功能说明：
		创建字段BSON
	参数说明：
		bType：字段类型
		pszData：字段值字符串
		lpResult:字段BSON的缓存
		nLen：字符串长度
************************************************************************/
void CBaseMemoryAnalysis::CreateFieldBson(BYTE bType, const char* pszData, LPBYTE lpResult, int nLen)
{
	//将字符串转换对应类型的数据
	switch(bType)
	{
	case MF_SYS_FIELDTYPE_INT:
		lpResult += sizeof(BYTE);		//存放字段编号
		*(int*)lpResult = atoi(pszData);
		break;
	case MF_SYS_FIELDTYPE_BIGINT:
		lpResult += sizeof(BYTE);
		*(long long*)lpResult  = _atoi64(pszData);
		break;
	case MF_SYS_FIELDTYPE_DOUBLE:
	case MF_SYS_FIELDTYPE_DATE:
		lpResult += sizeof(BYTE);
		*(double*)lpResult  = atof(pszData);
		break;
	case MF_SYS_FIELDTYPE_CHAR:
	case MF_SYS_FIELDTYPE_VARCHAR:
	case MF_SYS_FIELDTYPE_CLOB:
	case MF_SYS_FIELDTYPE_BLOB:
		lpResult += sizeof(BYTE);
		if(nLen < 250)
		{
			*(BYTE*)lpResult = nLen;
			lpResult += sizeof(BYTE);
		}
		else
		{
			*(BYTE*)lpResult = 255;
			lpResult += sizeof(BYTE);
			*(int*)lpResult = nLen;
			lpResult += sizeof(int);
		}
		memcpy(lpResult, pszData, nLen);
		break;
	}
}

/************************************************************************
		功能说明：
			根据XML获取Object的相关信息
************************************************************************/
int CBaseMemoryAnalysis::GetXmlObjectDef()
{
	const char* lpszObjectName, *pType, *str, *pKey;
	int nRet, nObjectNameLen, nPrecision, nMaxLen;
	TiXmlElement* pXmlElementRoot, *pXmlElement, *pElementTypeNode, *pDataTypeNode;

	if(m_pXmlObjectInfo != NULL)
	{
		delete m_pXmlObjectInfo;
		m_pXmlObjectInfo = NULL;
	}
	m_pXmlObjectInfo = new XMLOBJECTDEF;
	//找到rs:basecolumn结点，取得对象名
	pXmlElementRoot = m_pTinyXmlRoot->FirstChildElement();
	pXmlElement = NULL;
	nRet = SelectSingleNode(pXmlElementRoot, "s:AttributeType", pXmlElement);
	if(nRet != MF_OK)
	{
		return MF_INNER_SYS_NOMATCHNODE_ERROR;
	}

	//根据对象名获取对象信息
	if(NULL != pXmlElement->Attribute("rs:basetable"))
	{
		lpszObjectName = pXmlElement->Attribute("rs:basetable");
	}
	else
	{
		return MF_INNER_SYS_NOMATCHNODE_ERROR;
	}
	nObjectNameLen = strlen(lpszObjectName)+1;
	m_pXmlObjectInfo->m_nObjectNameLen = nObjectNameLen;
	m_pXmlObjectInfo->m_pObjectName = new char[nObjectNameLen];
	memcpy(m_pXmlObjectInfo->m_pObjectName, lpszObjectName, nObjectNameLen);
	
	//找到s:ElementType结点
	nRet = SelectSingleNode(pXmlElementRoot, "s:ElementType", pElementTypeNode);
	if(nRet != MF_OK)
	{
		return MF_INNER_SYS_NOMATCHNODE_ERROR;
	}
	
	//获取s:ElementType结点的第一个子结点
	pXmlElement = pElementTypeNode->FirstChildElement();
	//获取字段数目
	while(pXmlElement)
	{
		str = pXmlElement->Value();
		if(strcmp(str, "s:AttributeType") ==0)
		{
			m_pXmlObjectInfo->m_bFieldNum++;	
		}
		pXmlElement = pXmlElement->NextElement();
	}
	m_pXmlObjectInfo->m_pField = (LPXMLFIELDDEF)(new XMLFIELDDEF[m_pXmlObjectInfo->m_bFieldNum]);
	memset(m_pXmlObjectInfo->m_pField, 0, sizeof(XMLFIELDDEF)*m_pXmlObjectInfo->m_bFieldNum);
	
	//获取每个字段的相关信息
	pXmlElement = pElementTypeNode->FirstChildElement();
	for(int i = 0; i < m_pXmlObjectInfo->m_bFieldNum; i++)
	{
		m_pXmlObjectInfo->m_pField[i].m_bTempNo = i+1;
		pDataTypeNode = pXmlElement->FirstChildElement();
		
		//获取字段名和字段名长度
		m_pXmlObjectInfo->m_pField[i].m_pFieldName = const_cast<char*>(pXmlElement->Attribute("name"));
		if(m_pXmlObjectInfo->m_pField[i].m_pFieldName == NULL)
		{
			return MF_INNER_SYS_NOMATCHNODE_ERROR; 
		}
		m_pXmlObjectInfo->m_pField[i].m_nFieldNameLen = strlen(m_pXmlObjectInfo->m_pField[i].m_pFieldName) + 1;
		
		//建立字段名和字段编号的映射表
		m_pXmlObjectInfo->m_mapNameToNo.insert(make_pair(m_pXmlObjectInfo->m_pField[i].m_pFieldName, i+1));
		//获取字段类型
		pType = pXmlElement->FirstChildElement()->Attribute("dt:type");
		if(pType == NULL)
		{
			return MF_INNER_SYS_NOMATCHNODE_ERROR; 
		}
		if(strcmp(pType, "number") == 0)
		{
			nPrecision = 0;
			if(NULL == pXmlElement->FirstChildElement()->Attribute("rs:precision", &nPrecision))
			{
				return MF_INNER_SYS_NOMATCHNODE_ERROR; 
			}
			if(nPrecision == 10)
			{
				m_pXmlObjectInfo->m_pField[i].m_bFieldType = MF_SYS_FIELDTYPE_INT;
			}
			else if(nPrecision == 20)
			{
				m_pXmlObjectInfo->m_pField[i].m_bFieldType = MF_SYS_FIELDTYPE_BIGINT;
			}
			else if(nPrecision == 38)
			{
				m_pXmlObjectInfo->m_pField[i].m_bFieldType = MF_SYS_FIELDTYPE_DOUBLE;
			}
		}
		else if(strcmp(pType,"dateTime") == 0)
		{
			m_pXmlObjectInfo->m_pField[i].m_bFieldType = MF_SYS_FIELDTYPE_DATE;
		}
		else if(strcmp(pType, "string") == 0)
		{
			nMaxLen = 0;
			if(NULL == pXmlElement->FirstChildElement()->Attribute("dt:maxLength", &nMaxLen))
			{
				return MF_INNER_SYS_NOMATCHNODE_ERROR; 
			}
			
			if(nMaxLen == 256)
			{
				m_pXmlObjectInfo->m_pField[i].m_bFieldType = MF_SYS_FIELDTYPE_VARCHAR;
			}
			else if(nMaxLen == 1073741823)
			{
				m_pXmlObjectInfo->m_pField[i].m_bFieldType = MF_SYS_FIELDTYPE_CLOB;
			}
			else
			{
				m_pXmlObjectInfo->m_pField[i].m_bFieldType = MF_SYS_FIELDTYPE_CHAR;
			}
			m_pXmlObjectInfo->m_pField[i].m_bMaxLen = nMaxLen;
		}
		else if(strcmp(pType, "bin.hex") == 0)
		{
			m_pXmlObjectInfo->m_pField[i].m_bFieldType = MF_SYS_FIELDTYPE_BLOB;
		}
		//检验是否主键
		pKey = pXmlElement->Attribute("rs:keycolumn");
		if(pKey != NULL && 0 == strcmp(pKey, "true"))
		{
			m_pXmlObjectInfo->m_pField[i].m_bPrimaryKey = 1;
		}
		else
		{
			m_pXmlObjectInfo->m_pField[i].m_bPrimaryKey = 0;
		}

		if(pXmlElement != NULL)
		{
			pXmlElement = pXmlElement->NextElement();
		}
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			根据XML的记录中的所有属性，创建字段信息Bson
		参数说明：
			stBson：BSON对象
			nFieldNum：字段数
			nFieldInfoOffset：字段信息偏移
			pXmlAttribute：XML属性
************************************************************************/
int CBaseMemoryAnalysis::GetXmlFieldInfo(CBaseBson& stBson, UINT& nFieldInfoOffset)
{
	UINT nOffset;
	LPBYTE lpAddr;
	char *pFieldName;
	int nRet, nLen, i;
	LPXMLFIELDINFO lpFieldInfo;
	map<string, BYTE>::iterator iter;

	//分配空间存放字段信息
	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(m_pXmlObjectInfo->m_bFieldNum*sizeof(XMLFIELDINFO), nFieldInfoOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpFieldInfo = (LPXMLFIELDINFO)lpAddr;

	for(i = 0; i < m_pXmlObjectInfo->m_bFieldNum; i++)
	{
		pFieldName = m_pXmlObjectInfo->m_pField[i].m_pFieldName;
		nLen = m_pXmlObjectInfo->m_pField[i].m_nFieldNameLen;
		
		//分配空间存放字段名
		lpAddr = NULL;
		nRet = stBson.AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		memcpy(lpAddr, pFieldName, nLen);
		lpFieldInfo[i].m_nFieldNameOffset = nOffset;
		lpFieldInfo[i].m_bFieldNameLen = nLen;
		lpFieldInfo[i].m_bTempNo = i+1;
	}
	return MF_OK;
}
/************************************************************************
		功能说明：
			根据XML的记录中的所有属性，创建字段Bson
		参数说明：
			stBson：Bson对象
			stXmlStep:Xml执行步骤
			pXmlAttribute：XML属性结点
************************************************************************/
int CBaseMemoryAnalysis::GetXmlFieldBson(CBaseBson& stBson, LPRECORDHEAD lpRecordHead, TiXmlAttribute* pXmlAttribute)
{
	UINT nOffset;
	BYTE bTempNo, bFieldNum;
	int nRet, nFieldDataLen, i;
	LPBYTE lpAddr, lpBlobBuffer;
	LPXMLFIELDBSON lpXmlFieldBson;
	map<string, BYTE>::iterator iter;
	const char* lpszFieldName, *lpszFieldValue;

	bFieldNum = lpRecordHead->m_bFieldNum;
	//分配空间存放字段BSON
	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(bFieldNum*sizeof(XMLFIELDBSON), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	lpRecordHead->m_nFieldOffset = nOffset;
	lpXmlFieldBson = (LPXMLFIELDBSON)lpAddr;
	for(i = 0; i < bFieldNum; i++)			
	{
		lpszFieldName = pXmlAttribute->Name();
		lpszFieldValue = pXmlAttribute->Value();
		if(strcmp(lpszFieldName,"ROWID") == 0)
		{
			pXmlAttribute = pXmlAttribute->Next();
			continue;
		}
		//填写字段信息
		iter = m_pXmlObjectInfo->m_mapNameToNo.find(lpszFieldName);
		if(iter == m_pXmlObjectInfo->m_mapNameToNo.end())
		{
			return MF_COMMON_INVALID_FIELD;
		}
		else
		{
			bTempNo = iter->second;
		}

		//获取字段值的Buffer长度
		if(m_pXmlObjectInfo->m_pField[bTempNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_VARCHAR || m_pXmlObjectInfo->m_pField[bTempNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_CHAR)
		{
			nFieldDataLen = strlen(lpszFieldValue)+1;
		}
		else if(m_pXmlObjectInfo->m_pField[bTempNo - 1].m_bFieldType == MF_SYS_FIELDTYPE_BLOB)
		{
			lpBlobBuffer = NULL;
			nFieldDataLen = strlen(lpszFieldValue)/2;			//二进制字符串转二进制数据，存放二进制数据的Buffer长度为二进制字符串长度的一半
			nRet = stBson.AllocFromBsonBuffer(nFieldDataLen, nOffset, lpBlobBuffer);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nRet = CharConvertHex(lpszFieldValue, (LPBYTE)lpBlobBuffer, nFieldDataLen);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpszFieldValue = (char*)lpBlobBuffer;
		}
		nRet = GetFieldBufferLen(lpXmlFieldBson[i].m_nFieldDataLen, m_pXmlObjectInfo->m_pField[bTempNo - 1].m_bFieldType, nFieldDataLen);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		
		//为字段值创建Buffer，并获取字段值   
		lpAddr = NULL;
		nRet = stBson.AllocFromBsonBuffer(lpXmlFieldBson[i].m_nFieldDataLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpXmlFieldBson[i].m_bModify = 1;
		lpXmlFieldBson[i].m_bTempNo = bTempNo;
		lpXmlFieldBson[i].m_nFieldDataOffset = nOffset;
		CreateFieldBson(m_pXmlObjectInfo->m_pField[bTempNo - 1].m_bFieldType, lpszFieldValue, lpAddr, nFieldDataLen);

		pXmlAttribute = pXmlAttribute->Next();
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			获取XML信息组成字符串(用于显示XML的一些基本信息)
		参数说明：
			stBson：Bson对象
			lpXmlObjectDef：XML对象信息
			nDeleteNum：删除数量
			nUpdateNum：更新数量
			nInsertNum：插入数量
			nStrLen：字段长度
************************************************************************/
int CBaseMemoryAnalysis::GetXmlInfoStr(CBaseBson& stBson, LPXMLOBJECTDEF lpXmlObjectDef, int nDeleteNum, int nUpdateNum, int nInsertNum, int& nStrLen)
{
	UINT nOffset;
	int nRet, nLen;
	LPBYTE lpAddr, lpTempAddr;
	//分配空间存放表名
	nLen = lpXmlObjectDef->m_nObjectNameLen+strlen("ObjectName[]");			//注意：最后一个字节用来存放空格而不是存放结束符0，并且这里不能+1，因为m_nObjectNameLen是包含了结束符的
	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(nLen, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nStrLen += nLen;
	sprintf((char*)lpAddr,"ObjectName[%s] ",lpXmlObjectDef->m_pObjectName);	//注意："OBJECTNAME[%s] "包含一个空格
	
	lpTempAddr = lpAddr; 
	//分配空间存放列名
	nLen = strlen("FieldName[]");
	lpAddr = NULL;
	for(int i = 0; i < lpXmlObjectDef->m_bFieldNum; i++)
	{
		nLen += lpXmlObjectDef->m_pField[i].m_nFieldNameLen;
	}
	nRet = stBson.AllocFromBsonBuffer(nLen, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nStrLen += nLen;

	nLen = strlen("FieldName[");
	memcpy(lpAddr, "FieldName[", nLen);
	lpAddr += nLen;
	for(int i = 0; i < lpXmlObjectDef->m_bFieldNum; i++)
	{
		nLen = lpXmlObjectDef->m_pField[i].m_nFieldNameLen;
		if(i != lpXmlObjectDef->m_bFieldNum-1)
		{
			sprintf((char*)lpAddr, "%s,", lpXmlObjectDef->m_pField[i].m_pFieldName);
			lpAddr += nLen;
		}
		else
		{
			sprintf((char*)lpAddr, "%s", lpXmlObjectDef->m_pField[i].m_pFieldName);
			lpAddr += nLen-1;
		}
	}
	nLen = strlen("] ");									//注意"] "包含一个空格
	memcpy(lpAddr, "] ", nLen);
	
	//分配空间存放删除记录数
	lpAddr = NULL;
	nLen = strlen("DeleteNumber[]")+sizeof(int)+1;			//最后存放结束符
	nRet = stBson.AllocFromBsonBuffer(nLen, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nStrLen += nLen;
	sprintf((char*)lpAddr, "DeleteNumber[%d]", nDeleteNum);

	//分配空间存放更新记录数
	lpAddr = NULL;
	nLen = strlen("UpdateNumber[]")+sizeof(int)+1;			//最后存放结束符
	nRet = stBson.AllocFromBsonBuffer(nLen, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nStrLen += nLen;
	sprintf((char*)lpAddr, "UpdateNumber[%d]", nUpdateNum);

	//分配空间存放插入记录数
	lpAddr = NULL;
	nLen = strlen("InsertNumber[]")+sizeof(int)+1;			//最后存放结束符
	nRet = stBson.AllocFromBsonBuffer(nLen, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nStrLen += nLen;
	sprintf((char*)lpAddr, "InsertNumber[%d]", nInsertNum);

	//分配空间存放Bson大小
	lpAddr = NULL;
	nLen = strlen("RecordsetSize[]")+sizeof(int)+1;			//最后存放结束符
	nRet = stBson.AllocFromBsonBuffer(nLen, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nStrLen += nLen;
	sprintf((char*)lpAddr, "RecordsetSize[%d]", stBson.GetBsonDataSize());

	return MF_OK;
}

/************************************************************************
		功能说明：
			获取字段数量
		参数说明：
			pNodeElement：结点指针
			bFieldNum：字段数
************************************************************************/
int CBaseMemoryAnalysis::GetFieldNum(TiXmlElement* pNodeElement, BYTE& bFieldNum)
{
	int nRet;
	TiXmlElement* pXmlElement;
	TiXmlAttribute* pXmlAttribute;
	
	nRet = SelectSingleNodeFromCurrentRoot(pNodeElement, "z:row", pXmlElement);
	if(nRet != MF_OK)
	{
		return MF_INNER_SYS_NOMATCHNODE_ERROR;
	}
	pXmlAttribute = pXmlElement->FirstAttribute();

	bFieldNum = 0;
	while(pXmlAttribute)
	{
		if(strcmp(pXmlAttribute->Name(),"ROWID") != 0)
		{
			bFieldNum++;
		}
		pXmlAttribute = pXmlAttribute->Next();
	}
	return MF_OK;
}

/************************************************************************
		功能说明：
			根据结点名称获取结点
		参数说明：
			pXmlRootElement：根节点属性
			pNodeName:结点名称
			pOutNode：返回结点
************************************************************************/
int CBaseMemoryAnalysis::SelectSingleNode(TiXmlElement* pXmlRootElement, char* pNodeName, TiXmlElement* &pOutNode)
{
	TiXmlElement* pChildElement;     
	//假如等于根节点名，就退出
	if(strcmp(pNodeName, pXmlRootElement->Value()) == 0)   
	{   
		pOutNode = pXmlRootElement;   
		return MF_OK;   
	} 

	for (pChildElement = pXmlRootElement->FirstChildElement(); pChildElement; pChildElement = pChildElement->NextSiblingElement())     
	{     
		//递归处理子节点，获取节点指针   
		if(MF_OK == SelectSingleNode(pChildElement, pNodeName, pOutNode))
		{
			return MF_OK;
		}
	}     
	return MF_FAILED;   
}

/************************************************************************
		功能说明：
			根据结点名称获取结点
		参数说明：
			pXmlRootElement：根节点属性
			pNodeName:结点名称
			pOutNode:返回结点
************************************************************************/
int CBaseMemoryAnalysis::SelectSingleNodeFromCurrentRoot(TiXmlElement* pXmlRootElement, char* pNodeName, TiXmlElement* &pOutNode)
{
	TiXmlElement* pChildElement;     

	//假如等于根节点名，就退出 
	for (pChildElement = pXmlRootElement->FirstChildElement(); pChildElement; pChildElement = pChildElement->NextSiblingElement())     
	{     
		//递归处理子节点，获取节点指针   
		if(strcmp(pNodeName, pChildElement->Value()) == 0)   
		{   
			pOutNode = pChildElement;   
			return MF_OK;   
		} 
	}     
	return MF_FAILED;   
}
#endif
