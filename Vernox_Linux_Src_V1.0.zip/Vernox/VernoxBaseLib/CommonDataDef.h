﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include <map>
#include <vector>
#include <string.h>
#include "MFString.h"
#include "../Include/MemDBCommonDef.h"
#include "../VernoxServiceLib/MapSimple.h"
using namespace std;
class CBaseBson;
class IVirtualMemoryFile;

#pragma pack(1)
//执行统计信息
typedef struct 
{
	int                 m_nObjectID;                                   //执行对象ID
	DWORD               m_dwHashID;                                    //SQL语句HASH值
	DWORD               m_dwTime;                                      //实际耗时，以微秒为单位
	FILETIME            m_ftStartTime;                                 //执行开始时间
	FILETIME            m_ftEndTime;                                   //执行结束时间
	LARGE_INTEGER       m_liStart;                                     //开始时间点
	LARGE_INTEGER       m_liFrequence;                                 //CPU频率
	LARGE_INTEGER       m_liParsePlanStart;                            //执行计划解析开始时间点
	LARGE_INTEGER       m_liPretreatmentStart;                         //预处理执行开始时间点
	LARGE_INTEGER       m_liExecuteStart;                              //开始执行时间点
	LARGE_INTEGER       m_liIndexSearchEnd;                            //索引扫描完成时间点
	LARGE_INTEGER       m_liExecuteEnd;                                //结束执行时间点
	LARGE_INTEGER       m_liWriteLogEnd;                               //写日志结束时间点
	LARGE_INTEGER       m_liEnd;                                       //结束时间点
	DWORD               m_lWorkLoad;                                   //服务端运算量
}EXECUTESTATISTICSINFO, *LPEXECUTESTATISTICSINFO;

//执行统计信息
typedef struct stu_SqlExecuteStatisticsInfo
{
	int                 m_nObjectID;                                   //执行对象ID
	DWORD               m_dwHashID;                                    //SQL语句HASH值
	LPSTR               m_lpszSql;                                     //SQL字符串，为UTF8的字符串
	DWORD               m_dwTime;                                      //实际耗时，以微秒为单位
	//运行统计信息
	DWORD               m_dwTotalExecuteCount;                         //总执行次数
	DWORD               m_dwTotalTime;                                 //累计调用时间
	DWORD               m_dwTotalPrepareTime;                          //累计准备时间
	DWORD				m_dwTotalApplyResourceTime;                    //累计资源申请时间
	DWORD               m_dwTotalIndexSearchTime;                      //累计索引时间
	DWORD               m_dwTotalExecuteTime;                          //累计执行时间
	DWORD               m_dwTotalLogTime;                              //累计日志时间
	DWORD               m_dwTotalReleaseResourceTime;                  //累计资源释放时间
	DWORD               m_dwTotalWorkLoad;                             //累计工作量
	FILETIME            m_ftFirstTime;                                 //首次执行时间
	stu_SqlExecuteStatisticsInfo * m_pNext;                            //下一条数据的指针
}SQLEXECUTESTATISTICSINFO, *LPSQLEXECUTESTATISTICSINFO;

//工作量统计信息
typedef struct stu_WorkloadStatisticsInfo
{
	long long           m_llBeginTime;                                 //统计开始时间，数据同FILETIME
	int                 m_nRunTime;                                    //时间段长度，单位：毫秒
	int                 m_nExecuteTime;                                //时间段内平均执行时长，单位：微秒
	int                 m_nMinExecuteTime;                             //时间段内最短执行时长，单位：微秒
	int                 m_nMaxExecuteTime;                             //时间段内最长执行时长，单位：微秒
	int                 m_nQueryCount;                                 //检索次数
	int                 m_nUpdateCount;                                //修改次数
}WORKLOADSTATISTICSINFO, *LPWORKLOADSTATISTICSINFO;

//TCP会话连接线程
typedef struct 
{
	DWORD               m_dwSessionID;                                 //会话ID
	char                m_lpszUserName[24];							   //登录用户名
	BYTE				m_bConnectType;								   //连接类型，0：普通连接；1：集群连接
	ULONG               m_ulClientIP;                                  //客户端IP
	ULONG               m_ulMachineIP;                                 //客户端机器IP
	char                m_lpszMachineIP[16];                           //客户端机IP字符串
	USHORT              m_usClientPort;                                //客户端端口
	USHORT              m_usMachinePort;                               //客户端机器端口
	BYTE                m_bStatus;                                     //会话状态，0：空闲、1：正在执行ExecuteCommand、2：正在执行检索、3、正在更新结果集
	BYTE                m_bTransaction;                                //执行事务标志，0：无事务、1：有事务
	char                m_lpszProgramName[24];                         //应用程序名字
	DWORD               m_dwProcessID;                                 //进程ID
	DWORD               m_dwThreadID;                                  //线程ID
	ULONGLONG           m_ullUserData;                                 //64位用户数据
	DWORD               m_dwUserData;                                  //32位用户数据
	FILETIME            m_ftLogonTime;                                 //登录时间
	FILETIME            m_ftLastCallTime;                              //最后调用时间
	long long			m_nUserID;									   //用户ID
	long long         	m_nTotalTime;								   //累计调用时间
	long long         	m_nTotalPrepareTime;                           //累计准备时间
	long long         	m_nTotalApplyResourceTime;                     //累计资源申请时间
	long long         	m_nTotalIndexSearchTime;                       //累计索引时间
	long long         	m_nTotalExecuteTime;                           //累计执行时间
	long long         	m_nTotalLogTime;                               //累计日志时间
	long long         	m_nTotalReleaseResourceTime;                   //累计资源释放时间
	long long         	m_nTotalWorkLoad;							   //累计工作量
	long long         	m_nTotalCallCount;                             //累计调用次数
}SESSIONINFO, *LPSESSIONINFO;

//可变类型结构体定义
typedef struct st_VARDATA
{
	MF_VARDATA_TYPE   m_vt;                                            //数据类型
	BYTE			  m_bAutoRelease; 
	BYTE              m_bParam1;									   //参数1
	BYTE              m_bParam2;									   //参数2
	int				  m_nStrLen;
	int				  m_nBufferLen;
	USHORT			  m_nArrCount;
	union 
	{					
		int           m_nValue;
		long long     m_llValue;
		double		  m_dblValue;
		BYTE		  m_bValue;									       //新加入:新增BYTE类型，用于存放字段编号
		char*		  m_lpszValue;
		LPBYTE        m_lpValue;
		int*		  m_arrInt;										   //int类型数组
		long long*    m_arrBigInt;									   //bigint数组
	};

	st_VARDATA()	
	{
		*(int*)(&m_vt) = 0;
	}

	~st_VARDATA()
	{
		Free();
	}
	void Free();
	int  GetStringLen();
	int  GetFieldBufferLen();
	void AttachBuffer(BYTE bType, char* lpszBuffer, int nLen);
	void DetachBuffer();
	void SetDataLen(int nLen);
	void SetStringLen(int nLen);
	void SetBinaryData(LPBYTE lpValue, int nLen);
	void GetBinaryData(LPBYTE &lpValue);
	void CovertStringData(BYTE bType, char* lpszData, int nLen);
	int  Link(CBaseBson& stBson, st_VARDATA& varData, st_VARDATA& varResult);
	//比较运算符
	BOOL operator > (const st_VARDATA& varData);
	BOOL operator < (const st_VARDATA& varData);
	BOOL operator == (const st_VARDATA& varData);
	BOOL operator >= (const st_VARDATA& varData);
	BOOL operator <= (const st_VARDATA& varData);
	BOOL operator != (const st_VARDATA& varData);
	BOOL operator || (const st_VARDATA& varData);
	BOOL operator && (const st_VARDATA& varData);
	BOOL operator ! ();
	BOOL In(CBaseBson* pBaseBson, int* lpHashTable, int nTableSize);

	void SetData(const int nValue);
	void SetData(const long long llValue);
	void SetData(const double dblValue, MF_VARDATA_TYPE bType);
	void SetData(const BYTE bValue);
	void SetData(const char* lpszValue, int nLen);
	void SetData(const long long* arrayBigInt, USHORT nArrCount);
	void SetData(const int* arrayInt, USHORT nArrCount);
	void SetData(const st_VARDATA& varData);
	
	//获取兼容类型值(目前只支持数字型的兼容)
	int  GetCompatibleInt();
	long long  GetCompatibleBigInt();
	double  GetCompatibleDouble();

	int GetCompatableValue(MF_VARDATA_TYPE vt, st_VARDATA& varResult);

	//算术运算符
	st_VARDATA operator + (const st_VARDATA& varData);
	st_VARDATA operator - (const st_VARDATA& varData);
	st_VARDATA operator * (const st_VARDATA& varData);
	st_VARDATA operator / (const st_VARDATA& varData);
}VARDATA,*LPVARDATA;

//系统对象列定义
typedef struct
{
	BYTE                m_bObjectFieldNo;                              //数据对象列编号
	MF_SYS_FIELDTYPE    m_bFieldType;                                  //列类型
	BYTE                m_bCharLen;                                    //定长字符串长度
	BYTE                m_bAllowNull;                                  //允许为空标志，1表示允许
	TCHAR               m_lpszName[32];                                //对象列名名称，系统外部来访问均用此名称
}OBJECTFIELDDEF, *LPOBJECTFIELDDEF;

//系统对象列定义BSON结构
typedef struct
{
	BYTE				m_bFieldNo;			                           //数据对象列编号
	MF_SYS_FIELDTYPE	m_bFieldType;								   //列类型
	BYTE				m_bCharLen;									   //定长字符串长度
	BYTE				m_bAllowNull;								   //允许为空标志，1表示允许
	char				m_bFieldName[32];							   //列名
	int					m_nNextOffset;								   //下一个列的偏移
}OBJECTFIELDDEFBSON, *LPOBJECTFIELDDEFBSON;

//记录字段信息定义
typedef struct 
{	
	MF_SYS_FIELDTYPE              m_bFieldType;							//列类型
	BYTE						  m_bAllowNull;							//是否允许为空	
	MF_PARAMETER_FIELDTYPE        m_bFieldNameType;						//字段名类型(逻辑字段或原始字段)，实际列此值为0，且m_lpszName、m_lpszObjectName是有值的，否则m_lpszName、m_lpszObjectName为空值，且m_lpszTitle为表达式内容，超过30字符直接截掉。
	BYTE						  m_bMaxLen;			     			//保留字段
	BYTE						  m_bPrimaryKey;						//是否主键
	BYTE						  m_bAutoIncrement;						//是否自增字段
	BYTE						  m_bReserved[2];						//保留字段

	int							  m_nFieldNameOffset;					//对象列名名称偏移
	int							  m_nRsNameOffset;						//rs:name用于存放没有别名的聚合函数和表达式偏移
	int							  m_nTitleOffset;						//对象列名返回名称，相当于SQL的AS功能，默认情况下m_lpszTitle和m_lpszName相同
	int							  m_nObjectNameOffset;					//对象名偏移
}RECORDFIELD,*LPRECORDFIELD;

//系统索引定义BSON结构
typedef struct 
{
	long long           m_nDataID;                               //数据ID
	int                 m_nIndexID;                              //索引ID
	char                m_pIndexName[32];                        //对象名称，系统外部来访问均用此名称
	int                 m_nBlockSize;                            //数据块大小
	MF_SYS_INDEXTYPE    m_bIndexType;                            //索引类型
	BYTE                m_bFileNo;                               //文件编号
	BYTE	            m_bFieldNo[4];                           //索引字段编号
	MF_CONSTRAINT_TYPE  m_bConstraintType;						 //约束类型
	int 				m_nNextOffset;                           //指向下一个索引
}INDEXDEFBSON, *LPINDEXDEFBSON;

//系统索引定义
typedef struct stu_INDEXDEF
{
	long long           m_nDataID;                          	 //数据ID
	int                 m_nIndexID;                         	 //索引ID
	int                 m_nObjectID;                        	 //对象ID
	char                m_lpszName[32];                     	 //对象名称，系统外部来访问均用此名称
	int                 m_nBlockSize;                       	 //数据块大小
	MF_SYS_INDEXTYPE    m_bIndexType;                       	 //索引类型
	BYTE                m_bFileNo;                          	 //文件编号
	MF_LOCK_STATUS_TYPE	m_bStatus;								 //锁状态
	int					m_nShareNum;							 //共享锁数量
	MF_CONSTRAINT_TYPE  m_bConstraintType;						 //约束类型
	BYTE	            m_bFieldNo[4];                      	 //索引字段编号
	long long			m_nTimestamp;							 //时间戳(用于给索引加锁)
	stu_INDEXDEF *      m_pNext;                            	 //指向下一个索引
}INDEXDEF, *LPINDEXDEF;

//系统对象定义BSON结构
typedef struct 
{
	long long           m_nDataID;                               //数据ID
	int                 m_nObjectID;                             //数据对象ID
	MF_OBJECT_TYPE	    m_bObjectType;							 //对象类型
	BYTE                m_bReserved[3];							 //保留字段
	char				m_bObjectName[32];						 //对象名
	int                 m_nBlockSize;                            //数据块大小
	BYTE                m_bFileNo;                               //文件编号
	BYTE                m_nFieldNum;                             //列数量
	BYTE                m_bImplementClass;                       //实现类序号，从0开始
	UINT				m_nFieldOffset;						 	 //列偏移
	UINT                m_nIndexOffset;							 //索引偏移
	UINT				m_nNextOffset;							 //下一个OBJECTDEF的偏移（提供给图数据库使用）
}OBJECTDEFBSON, *LPOBJECTDEFBSON;	

//用户对象定义BSON结构
typedef struct 
{
	char				m_pUserName[32];						 //用户名
	BYTE				m_pPassword[32];						 //用户密码
	MF_AUTHORITY_ID		m_bAuthorityID[64];						 //权限类型
	int					m_nAuthorityNum;						 //权限数量
	char				m_pAuthorityName[1][32];				 //用户权限名
}USERINFOBSON, *LPUSERINFOBSON;	

//系统对象定义
typedef struct stu_ObjectDef
{
	long long           m_nDataID;                               //数据ID
	int                 m_nObjectID;                             //数据对象ID
	MF_OBJECT_TYPE	    m_bObjectType;							 //对象类型
	char                m_lpszName[32];                          //对象名称，系统外部来访问均用此名称
	int                 m_nBlockSize;                            //数据块大小
	BYTE                m_bFileNo;                             	 //文件编号
	BYTE                m_nFieldNum;                             //列数量
	BYTE                m_bImplementClass;                       //实现类序号，从0开始
	BYTE				m_bStatus;								 //锁定状态
	BYTE                m_bReserved[2];	                         //保留数据
	BYTE				m_bMaxTransactionNum;					 //一个对象所能容纳并行事务的总量（即可以加共享锁的总数）
	long long*			m_lpTimestampArray;						 //时间戳数组
	long long*		 	m_pDataNum;								 //对象的记录数量
	LPINDEXDEF          m_lpIndex;                               //索引信息
	LPOBJECTFIELDDEF    m_lpField;                               //定义指针数组，原则上m_bObjectFieldNO和数组的编号只相差一（数组的下标以0开始，我们定义m_bObjectFieldNO以1开始）
	CMapString		    m_mapName2FieldNo;				   		 //列名和列序号对应
	stu_ObjectDef*		m_lpNext;								  //下一个OBJECTDEF的偏移（提供给图数据库使用）
	stu_ObjectDef()
	{
		m_nDataID			 = 0;
		m_nObjectID			 = 0;
		m_bObjectType		 = 0;
		m_nBlockSize		 = 0;
		m_bFileNo			 = 0;
		m_nFieldNum			 = 0;
		m_bImplementClass	 = 0;
		m_bStatus			 = 0;
		m_bReserved[0]		 = 0;
		m_bReserved[1]		 = 0;
		m_bMaxTransactionNum = 0;
		m_lpTimestampArray   = NULL;
		m_lpIndex			 = NULL;
		m_pDataNum			 = NULL;
		m_lpNext			 = NULL;
		m_lpField			 = NULL;
		memset(m_lpszName, 0, sizeof(m_lpszName));
	}
	
	~stu_ObjectDef()
	{
		if(m_lpTimestampArray != NULL)
		{
			delete [] m_lpTimestampArray;
			m_lpTimestampArray = NULL;
		}
	}
	void InitalMap()
	{
		m_mapName2FieldNo.Initialize(m_nFieldNum);
	}
}OBJECTDEF, *LPOBJECTDEF;

//用户信息
typedef struct st_USERINFODEF
{
	long long 			m_nUserID;									   //用户ID
	BYTE				m_bStatus;									   //状态：启动、停用
	BYTE				m_bReserved[3];								   //保留字段
	char				m_pUserName[24];							   //用户名
	BYTE				m_pPassword[24];							   //用户密码
	MF_AUTHORITY_ID	m_bAuthority[64];								   //权限类型
	st_USERINFODEF()
	{
		m_nUserID				= 0;
		m_bStatus				= 0;
		m_bReserved[0]			= 0;
		m_bReserved[1]			= 0;
		m_bReserved[2]			= 0;
		memset(m_pUserName, 0, 24);
		memset(m_pPassword, 0, 24);
		memset(m_bAuthority, 0 , 64);
	}	
}USERINFODEF, *LPUSERINFODEF;

typedef struct st_AUTHORITYINFO
{
	MF_AUTHORITY_ID		m_bAuthorityID;								   //权限ID
	BYTE				m_bReserved[3];								   //保留字段
	char				m_pAuthorityName[32];						   //权限名
	char				m_pAuthorityDesc[128];						   //权限描述

	st_AUTHORITYINFO()
	{
		m_bAuthorityID	= 0;
		m_bReserved[0]	= 0;
		m_bReserved[1]	= 0;
		m_bReserved[2]	= 0;
		memset(m_pAuthorityName, 0, 32);
		memset(m_pAuthorityDesc, 0, 128);
	}
}AUTHORITYINFO, *LPAUTHORITYINFO;

//索引条件
typedef struct 
{
	BYTE	                m_bFieldNo;                               //字段编号
	MF_EXECUTEPLAN_OPERATOR m_bOperator;				              //比较运算符定义
	MF_SYS_FIELDTYPE        m_bFieldType;                             //列类型
	BYTE                    m_bInequality;                            //恒不等
	VARDATA                 m_varCondition1;                          //条件1
	VARDATA                 m_varCondition2;                          //条件2
}INDEXCONDITION,*LPINDEXCONDITION;

//复合索引结构体
typedef struct
{
	UINT				    m_nIndexNum;							  //索引数
	INDEXCONDITION			m_lpIndexCondition[5];						  //索引字段信息
}MULTIINDEX, *LPMULTIINDEX;

//索引执行计划
typedef struct stu_INDEXEXECUTEPLAN
{
	int                            m_nIndexID;						  //索引ID
	BYTE						   m_bFieldNo[4];				      //索引字段编号
	MF_SYS_INDEXTYPE               m_bIndexType;                      //索引类型
	BYTE                           m_bFileNo;					      //文件编号
	MF_CONSTRAINT_TYPE			   m_bConstraintType;		   		  //约束条件
	BYTE						   m_bReserved;						  //保留字段
	MULTIINDEX					   m_stMultiIndex;		        	  //索引条件
	UINT					       m_nNextOffset;					  //指向下一个索引的偏移

	long long					   m_lpParamPtr1;					  //参数1：用于表示B树索引中起始节点指针	
	long long					   m_lpParamPtr2;					  //参数2：用于表示B树索引中起始节点元素指针	
	long long					   m_lpParamPtr3;					  //参数3：用于表示B树索引中结束节点元素指针	
	long long					   m_nParam4;						  //参数4：用于表示B树索引中起始关键字DataID(用于校验)
	long long					   m_nParam5;						  //参数5：用于表示B树索引中结束关键字DataID(用于校验)
}INDEXEXECUTEPLAN, *LPINDEXEXECUTEPLAN;

//删除：
//回滚记录定义
typedef struct stu_ROLLBACKRECORD
{
	long long			    		   m_nDataID;					  //数据ID
	LPINDEXEXECUTEPLAN  			   m_pIndexPlan;				  //索引执行计划
}ROLLBACKRECORD,*LPROLLBACKRECORD;

//表达式字段BSON定义
typedef struct
{
	MF_VARDATA_TYPE					   m_bDataType;					//数据类型
	BYTE							   m_bField;					//是否为字段
																	//注意：在客户端由于无法将列名翻译成列类型，所以BSON中统一用列名表示列。通过m_bField就可以区别列名和普通的字符串型数据
	BYTE							   m_bFieldNo;					//字段编号
	BYTE							   m_bReserved;					//保留数据
	int								   m_nDataLen;					//表达式的长度
	char							   m_bDataBuffer[1];			//表达式中字段的值
}MATHEXPELEMENTBSON,*LPMATHEXPELEMENTBSON;

//表达式字段BSON定义
typedef struct
{
	MF_VARDATA_TYPE					   m_bDataType;					//数据类型
	MF_PARAMETER_TYPE				   m_bParameterType;			//参数类型	
	BYTE							   m_bReserved[2];              //保留数据
	char							   m_pParameter[32];			//参数名称
	int								   m_nDataLen;					//数据长度，即m_bDataBuffer的长度
	char							   m_bDataBuffer[1];			//表达式中字段的值
}ALTERSETEXPFIELDBSON,*LPALTERSETEXPFIELDBSON;

//表达式BSON定义
typedef struct 
{
	BYTE                               m_bExpressionType1;		   //字段条件1类型，如果为0表示m_pExpression1有效，为1表示m_pFieldExpression1有效
	BYTE                               m_bExpressionType2;         //字段条件2类型，如果为0表示m_pExpression2有效，为1表示m_pFieldExpression2有效
	MF_EXECUTEPLAN_OPERATOR            m_bOperator;				   //算数运算符
	MF_SYS_FIELDTYPE				   m_bValType;				   //表达式结果值类型
	
	int								   m_nExpOffset1;			   //表达式偏移量（相对于BsonBuffer的起始地址）：该偏移量对应的Buffer可能是MATHEXPBSON结构体也可能是EXPFIELDBSON结构
	int								   m_nExpOffset2;			   //表达式偏移量
}MATHEXPBSON,*LPMATHEXPBSON;

//执行列BSON定义
typedef struct
{
	MF_EXPRESSIONTYPE					m_bExpressionType;		   //表达式类型
																   //定义表达式类型字段的原因：其实不论是单一字段、函数、还是四则运算表达式都可以归一化到表达式中，通过统一的算法计算出表达式的值，然后将其进行序列化
																   //但是，如果表达式只是一个单一字段，而单一字段已经被序列化并且存放在内存文件中，所以可以直接取得其内存Buffer，而且在实际应用中对于单一字段的查询会更多，
																   //因此可以对单一字段情况进行特别处理
	BYTE							    m_bFieldNo;				   //列编号
	BYTE							    m_bAllowNull;			   //是否允许为空
	BYTE								m_bNameLen;				   //列名的长度
	BYTE								m_bTitleLen;			   //别名的长度
	BYTE								m_bReserved;			   //保留字节
	int									m_nExpNameOffset;	       //表达式名称偏移
	int									m_nExpTitleOffset;		   //表达式别名偏移
	int									m_nExpOffset;			   //表达式偏移量
	int									m_nNextOffset;			   //下一个执行列的偏移
}EXECUTEFIELDBSON,*LPEXECUTEFIELDBSON;

//WHERE条件中比较表达式的BSON定义如SNO > 2
typedef struct stu_COMPAREEXPBSON
{
	MF_EXECUTEPLAN_OPERATOR	 m_bOperator;						   //比较运算符定义
	BYTE					 m_bLogicNot;                          //对结果做逻辑否运算

	MF_EXPRESSIONTYPE	     m_bExpressionType1;				   //表达式1类型
	MF_EXPRESSIONTYPE	     m_bExpressionType2;				   //表达式2类型
	MF_EXPRESSIONTYPE	     m_bExpressionType3;				   //表达式3类型
	
	BYTE					 m_bRowNum;							   //是否为RowNum表达式
	BYTE                     m_bReserved[2];                       //保留数据

	//1.一般形式：m_pMathExpression1 > m_pMathExpression2
	//2.BETWEEN AND 形式: m_pMathExpression1 BETWEEN m_pMathExpression2 AND m_pMathExpression3
	UINT					 m_nMathExpOffset1;					  //表达式1偏移
	UINT					 m_nMathExpOffset2;					  //表达式2偏移
	UINT					 m_nMathExpOffset3;					  //表达式3偏移

}COMPAREEXPBSON, *LPCOMPAREEXPBSON;

//WHERE条件BSON定义
typedef struct stu_WHERECONDITION
{
	MF_CONDITION_TYPE                  m_bConditionType1;           //字段条件1类型，如果为0表示条件为LPCOMPAREEXPBSON，为1表示条件为BASECONDITION，3表条件1无效
	MF_CONDITION_TYPE                  m_bConditionType2;           //字段条件1类型，如果为0表示条件为LPCOMPAREEXPBSON，为1表示条件为BASECONDITION，3表条件1无效
	BYTE                               m_bLogicNot;                 //对结果做逻辑否运算
	MF_EXECUTEPLAN_OPERATOR            m_bLogicOperator;            //逻辑运算符
	
	int								   m_nConditionOffset1;			//条件偏移量1(相对于BsonBuffer的起始地址的偏移，查询条件可能是BASECONDITION结构体或者FIELDCONDITIONBSON结构体)
	int								   m_nConditionOffset2;			//条件偏移量2
}BASECONDITIONBSON,*LPBASECONDITIONBSON;

//IN条件BSON
typedef struct 
{
	BYTE							   m_bDataType;					//数据类型
	BYTE							   m_bReserved[3];	     	    //保留字段
	int								   m_nDataNum;					//数据的数量，也是HASH表的长度
	int								   m_nExpOffset;				//IN之前的表达式偏移
	int								   m_nHashTableOffset;		    //哈希表偏移，哈希表上的没一个结点是一个int类型的偏移量，指向一个冲突链的起始位置即DATANODE
}INCONDITIONBSON,*LPINCONDITIONBSON;

typedef struct
{	
	MF_SYS_FIELDTYPE				   m_bDataType;					//数据类型
	BYTE							   m_bReserved[3];			    //保留字段
	int								   m_nNextOffset;				//下一个数据结点
	int								   m_nDataLen;					//数据长度，即m_bDataBuffer的长度
	char							   m_pDataBuffer[1];			//表达式中字段的值
}DATANODE,*LPDATANODE;

//Object名称的BSON定义
typedef struct
{
	BYTE							   m_bLen;						//表名的长度
	BYTE							   m_bReserved[3];              //保留字
	int								   m_nNextOffset;				//下一个名称的偏移
	BYTE							   m_pObjectName[1];			//实际名称
}OBJECTNAMEBSON,*LPOBJECTNAMEBSON;

//起始位置信息
typedef struct
{
	UINT						   m_nWhereOffset;				    //条件偏移
	UINT						   m_nIndexOffset;					//查询索引偏移
}STARTINFO,*LPSTARTINFO;

//递归查询信息
typedef struct
{
	BYTE					       m_bDrection;					    //递归方向
	BYTE						   m_bLevel;						//递归层数
	BYTE						   m_bIDFieldNo;					//当前结点的字段编号
	BYTE						   m_bPIDFieldNo;					//父亲结点的字段编号
	UINT						   m_nStartCondOffset;				//起始条件偏移
	UINT                           m_nConnectCondOffset;			//链接条件偏移
	UINT						   m_nReserved[3];					//保留字段
}RECURSION,*LPRECURSION;

//查询执行计划的BSON结构
typedef struct
{
	int							   m_nObjectID;						//对象ID
	BYTE					       m_bAggreFun;						//是否包含聚合函数
	BYTE						   m_bPageType;						//是否分页
	MF_QUERY_TYPE				   m_bQueryType;					//查询类型
	BYTE						   m_bReserved;						//保留字段
	int							   m_nPageSize;						//页面大小，以数据条数为单位
	int							   m_nPageNo;						//页面编号
	int							   m_nObjectNum;					//Object数量
	int							   m_nExcuteFieldNum;				//执行列数量
	UINT						   m_nObjectNameOffset;				//表名首地址偏移(可能是多张表)
	UINT						   m_nExcuteFieldOffset;			//执行列首地址偏移
	UINT						   m_nDataArrayOffset;				//字段值数组(一块可以共用的内存，避免频繁分配)
	
	UINT						   m_nConditionOffset;				//条件偏移
}QUERYEXECUTEPLANBSON,*LPQUERYEXECUTEPLANBSON;

//普通查询结构体
typedef struct
{
	BYTE						   m_bReserved[3];					//保留字段
	MF_QUERYPLAN_TYPE			   m_bQueryPlanType;				//查询计划类型
	long long					   m_nRowNum;						//扫描行数

	UINT						   m_nWhereOffset;					//查询条件偏移
	UINT						   m_nConnOffset;					//递归查询信息偏移
	UINT						   m_nIndexOffset;					//查询索引条件偏移
}COMMONCONDITION,*LPCOMMONCONDITION;

////HB树查询结构体
//typedef struct
//{
//	UINT						   m_nWhereOffset;					//查询条件偏移
//	UINT						   m_nConnOffset;					//递归查询信息偏移
//	UINT						   m_nIndexOffset;					//查询索引条件偏移
//}HBCONDITION,*LPHBCONDITION;

//图查询结构体
typedef struct
{
	BYTE						   m_bReserved[3];					//保留字段
	MF_QUERYPLAN_TYPE			   m_bQueryPlanType;				//查询计划类型
	long long					   m_nRowNum;						//扫描行数

	int							   m_nNodeNumber;					//节点数量
	int							   m_nRelationNumber;				//关系数量
	UINT						   m_nWhereOffset;					//查询条件偏移
	UINT						   m_nIndexOffset;					//查询索引条件偏移
	UINT						   m_nNodeCondOffset;				//节点条件偏移
	UINT						   m_nRelationCondOffset;			//关系条件偏移
}GRAPHCONDITION,*LPGRAPHCONDITION;

//节点条件BSON结构
typedef struct
{
	UINT						   m_nConditionOffset;				 //条件偏移
	UINT						   m_nIndexOffset;			         //索引偏移
}NODECONDITION,*LPNODECONDITION;

//关系条件BSON结构
typedef struct
{
	BYTE						   m_bDirection;					 //方向(0表示无向，1表示正向，2表示反向)
	BYTE						   m_bReserved[3];					 //保留字段
	int							   m_nStartLevel;					 //开始层次
	int							   m_nEndLevel;						 //结束层次
	UINT						   m_nConditionOffset;				 //条件偏移
	UINT						   m_nIndexOffset;			         //索引偏移
}RELATIONCONDITION,*LPRELATIONCONDITION;

//执行步骤时的基本参数
typedef struct
{
	long long					   m_nTimestamp;					//时间戳
	long long					   m_lpObjectInfo;					//对象ID
	MF_RECORD_TYPE		           m_bRecordType;					//记录类型
	BYTE						   m_bReserved[3];					//保留字段
	long long					   m_lpRecordBuffer;				//记录指针
}BASESTEPPARAM,*LPBASESTEPPARAM;

//执行步骤
typedef struct
{
	MF_EXECUTE_STEP				   m_bStepType;						//步骤名称
	BYTE						   m_bFlag;							//标志位：0：中间，1：起始，2：结束
	BYTE						   m_bReserved[2];					//保留字段
	long long					   m_nParam1;						//参数偏移
	long long					   m_nParam2;						//参数偏移
	long long					   m_nParam3;						//参数偏移
}EXECUTESTEP,*LPEXECUTESTEP;

//记录头信息
typedef struct
{
	MF_EXECUTE_STEP				   m_bType;							//操作类型						
	BYTE						   m_bFieldNum;						//字段数
	BYTE						   m_bNewDataID;					//是否是一个新建DataID
	BYTE						   m_bLast;							//是否为最后一条
	long long					   m_nDataID;						//数据ID
	int							   m_nRecordLen;					//记录长度
	UINT						   m_nFieldOffset;					//字段偏移
}RECORDHEAD,*LPRECORDHEAD;

//资源信息
typedef struct
{
	int							   m_nObjectID;						//对象ID
	long long					   m_nTimestamp;					//时间戳
	MF_RECORD_TYPE				   m_bRecordType;				    //记录的类型
	int							   m_nBTreeNodeNo;					//B树结点编号
	UINT						   m_nBlockSize;					//块大小
	UINT						   m_nBlockNoNum;				    //块的数量
	UINT						   m_nBlockOffset;					//块的地址ID(缓存片段编号+片段内偏移)
	UINT						   m_nRecordNum;					//记录数
	UINT						   m_nRecordAddrID;					//记录的地址ID(指向RECORDHEAD结构体)
}SOURCEINFO,*LPSOURCEINFO;

//步骤信息
typedef struct  
{
	UINT						   m_nExecuteStepNum;				//步骤数量
	UINT						   m_nStepAddrID;					//步骤地址偏移
	UINT						   m_nCurrentStepNo;				//当前执行到的步骤
}STEPINFO,*LPSTEPINFO;

//插入执行计划BSON结构
typedef struct
{
	int							   m_nObjectID;						//对象ID
	UINT						   m_nIndexNum;					    //索引数量
	BYTE						   m_bReserved[4];					//保留字段
	int                            m_nExecuteFieldNum;				//执行列数
	int                            m_nObjectNameOffset;             //表名首地址偏移(可能是多张表)
	int							   m_nExcuteFieldOffset;			//执行列首地址偏移
	UINT						   m_nCondOffset1;					//条件1偏移（用于图数据库插入关系）
	UINT						   m_nCondOffset2;					//条件2偏移（用于图数据库插入关系）
	UINT						   m_nInsertIndexOffset;			//需要插入的索引的偏移
	UINT						   m_nFieldMapOffset;				//字段映射数组偏移(一块可以共用的内存，避免频繁分配)
	int							   m_nDataArrayOffset;				//字段值数组(一块可以共用的内存，避免频繁分配)
}INSERTEXECUTEPLANBSON,*LPINSERTEXECUTEPLANBSON;

//删除执行计划BSON结构
typedef struct
{
	int							   m_nObjectID;						//对象ID
	UINT						   m_nIndexNum;					    //索引数量
	UINT                           m_nObjectNameOffset;             //表名首地址偏移(可能是多张表)
	UINT						   m_nWhereOffset;				    //Where条件偏移
	UINT						   m_nIndexOffset;				    //查询索引偏移
	UINT			               m_nDeleteIndexOffset;            //需要删除的索引的偏移

	UINT						   m_nConditionOffset;
}DELETEEXECUTEPLANBSON, *LPDELETEEXECUTEPLANBSON;

//更新执行计划BSON结构
typedef struct
{
	int                            m_nObjectID;                     //操作对象ID
	UINT						   m_nIndexNum;						//索引数量
	UINT                           m_nExecuteFieldNum;              //执行列数
	UINT                           m_nObjectNameOffset;             //表名首地址偏移(可能是多张表)
	UINT						   m_nExcuteFieldOffset;			//执行列首地址偏移
	UINT						   m_nWhereOffset;					//Where条件偏移
	UINT						   m_nIndexOffset;					//查询索引偏移
	UINT						   m_nUpdateIndexOffset;			//更新索引偏移
	UINT						   m_nFieldMapOffset;				//字段映射数组偏移(一块可以共用的内存，避免频繁分配)
	UINT						   m_nDataArrayOffset;				//字段值数组(一块可以共用的内存，避免频繁分配)

	UINT						   m_nConditionOffset;				//条件偏移
}UPDATEEXECUTEPLANBSON, *LPUPDATEEXECUTEPLANBSON;

//执行计划BSON结构
typedef struct
{
	UINT						   m_nTotalDataSize;			   //缓存中数据总大小
	UINT						   m_nBsonDataSize;				   //Bson缓存中数据大小
	UINT                           m_nDefaultSectionSize;		   //默认缓存片段大小
	UINT						   m_nFreeSectionAddrID;		   //空闲缓存片段的地址ID
	UINT						   m_nSectionStartOffset;		   //片段起始地址偏移
	UINT						   m_nClientSectionNum;			   //客户端片段数
	UINT                           m_nClientBsonDataSize;          //客户端Bson数据大小
	int                            m_nDataFlag;                    //数据标志，目前定为‘PLAN’
	MF_EXECUTEPLAN_CMDTYPE		   m_nType;						   //命令类型
	BYTE                           m_bVersion;                     //版本号，目前为1
	BYTE						   m_bWriteLog;					   //为1表示需要写重做日志，否则不用处理。BSON脚本是否需要写入数据库的重做日志，判断规则为：所有DDL语句（表结构、数据文件等系统修改语句），所有DML语句（插入、修改、删除），DQL语句中的查询序列。
	BYTE						   m_bFieldNum;					   //字段数量
	MF_DATABASE_TYPE			   m_bDBType;					   //数据库类型
	MF_OBJECT_TYPE				   m_bObjectType;				   //对象类型
	BYTE						   m_bReserved[2];				   //保留字段
	long long                      m_nTimestamp;                   //当前时间戳
	ULONG                          m_dwClientIP;                   //客户端IP地址
	DWORD                          m_dwHashID;                     //SQL语句HASH值
	DWORD						   m_dwWhereHash;				   //Where条件HASH值
	SOURCEINFO				       m_stSourceInfo;				   //资源信息
	STEPINFO					   m_stStepInfo;				   //步骤信息
	BASESTEPPARAM				   m_stBaseParam;				   //公共参数
	long long					   m_pCritStack[20];			   //临界区栈
	int						       m_nCritPos;					   //临界区位置
	int                            m_nObjectID;                    //执行计划对应的对象ID
	int                            m_nSqlLen;		 			   //SQL数据的长度（也可能是Recodset的XML）
	UINT                           m_nSqlOffset;                   //SQL偏移（也可能是Recodset的XML）
	long long					   m_nUserID;					   //用户ID
	int                            m_nReserve;	 				   //保留数据
	UINT			               m_nSessionID;				   //会话ID
	int                            m_nReserveLen;				   //保留数据的长度，为0表示无此数据
	UINT                           m_nReserveOffset;               //保留数据偏移，为0表示无此数据
	UINT                           m_nCommandOffset;			   //实际命令偏移
	int						       m_nTransactionNum;			   //事务数
	UINT					       m_nTransactionOffset;		   //事务数组地址ID
	int				               m_nRetValue;					   //返回值
}EXECUTEPLANBSON,*LPEXECUTEPLANBSON;

//创建执行计划BSON结构
typedef struct
{
	MF_EXECUTEPLAN_OBJECTTYPE     m_nType;                        //创建数据结构类型，1、OBJECT，2、SEQUENCE
	int							  m_nPlanOffset;				  //实际创建数据结构体偏移
	int							  m_nDataFilePathOffset;	      //数据文件路径偏移
	int							  m_nTreeFilePathOffset;          //树索引文件路径偏移
	int							  m_nKVFilePathOffset;			  //KV索引文件路径偏移	
}CREATEEXECUTEPLANBSON,*LPCREATEEXECUTEPLANBSON;

//创建执行计划
typedef struct
{
	MF_EXECUTEPLAN_OBJECTTYPE     m_nType;                        //创建数据结构类型，1、OBJECT，2、SEQUENCE
	LPVOID                        m_lpPlanData;                   //实际创建数据结构体指针
	CMFString                     m_strDataFile;                  //数据文件路径
	CMFString                     m_strTreeFile;                  //树索引文件路径
	CMFString                     m_strKVFile;                    //KV索引文件路径
}CREATEEXECUTEPLAN, *LPCREATEEXECUTEPLAN;

//销毁执行计划BSON结构
typedef struct
{
	MF_EXECUTEPLAN_OBJECTTYPE     m_nType;                        //创建数据结构类型，1、OBJECT，2、SEQUENCE
	char						  m_pDataName[32];                //销毁的OBJECT或SEQUENCE名称
}DROPEXECUTEPLANBSON, *LPDROPEXECUTEPLANBSON;

//销毁执行计划
typedef struct
{
	MF_EXECUTEPLAN_OBJECTTYPE     m_nType;                        //创建数据结构类型，1、OBJECT，2、SEQUENCE
	CMFString                     m_strData;                      //销毁数据
}DROPEXECUTEPLAN, *LPDROPEXECUTEPLAN;

//修改列BSON结构
typedef struct
{
	int                 m_nObjectID;                              //数据对象ID
	MF_OBJECT_TYPE		m_bObjectType;							  //对象类型
	int                 m_nFieldNum;                              //列数量
	char	            m_pObjectName[32];                        //数据对象名	
	int				    m_nFieldOffset;                           //OBJECTFIELDDEFBSON结构体的偏移
	int					m_nNextOffset;							  //下一个结构体偏移（提供给图数据库使用）
}ALTEROBJECTFIELDBSON, *LPALTEROBJECTFIELDBSON;

typedef struct
{
	int                 m_nObjectID;                              //数据对象ID
	int                 m_nFieldNum;                              //列数量
	CMFString           m_strObjectName;                          //数据对象名
	LPOBJECTFIELDDEF    m_pField;                                 //定义指针数组，原则上m_bObjectFieldNO和数组的编号只相差一（数组的下标以0开始，我们定义m_bObjectFieldNO以1开始）
	int					m_nNextOffset;							  //下一个结构体偏移（提供给图数据库使用）
}ALTEROBJECTFIELD, *LPALTEROBJECTFIELD;

//修改执行计划BSON结构
typedef struct
{
	BYTE                          m_bObjectType;				  //修改对象的类型
	MF_EXECUTEPLAN_ALTERTYPE      m_nType;                        //修改数据结构类型
	int							  m_nPlanOffset;                  //实际修改数据结构体指针
	char						  m_pFilePath[256];				  //修改文件路径
}ALTEREXECUTEPLANBSON, *LPALTEREXECUTEPLANBSON;

//修改执行计划
typedef struct
{
	MF_EXECUTEPLAN_ALTERTYPE      m_nType;                        //修改数据结构类型
	LPVOID                        m_lpPlanData;                   //实际修改数据结构体指针
	CMFString                     m_strData;                      //实际修改的数据描述
}ALTEREXECUTEPLAN, *LPALTEREXECUTEPLAN;

//XML相关结构体定义
//字段信息结构体
typedef struct
{
	BYTE			 m_bFieldNo;								  //字段编号
	BYTE			 m_bTempNo;									  //临时编号，用于和XMLFIELDBSON对应
	BYTE			 m_bFieldType;								  //字段类型
	BYTE			 m_bFieldNameLen;							  //字段名长度,包含结束符
	int				 m_nFieldNameOffset;						  //字段名偏移
}XMLFIELDINFO,*LPXMLFIELDINFO;

//字段值结构
typedef struct
{
	BYTE			 m_bFieldNo;								  //字段编号
	BYTE			 m_bTempNo;									  //临时编号，用于和XMLFIELDINFO对应
	BYTE			 m_bReserved;								  //保留字段
	BYTE			 m_bModify;									  //是否修改
	int				 m_nFieldDataLen;							  //数据长度，即m_lpData的数据长度，包含字符串结束符
	int				 m_nFieldDataOffset;				          //数据偏移
}XMLFIELDBSON,*LPXMLFIELDBSON;

//对象BUFFER头用于导入导出
typedef struct
{
	BYTE			m_bBufferType;								  //Buffer类型,为1表示该Buffer存放了ObjectInfo信息，为0表示只存放了数据值
	MF_OBJECT_TYPE  m_bObjectType;								  //对象类型
	BYTE			m_bComplete;								  //是否结束
	BYTE			m_bReserved;								  //保留字段
	int				m_nDataNum;									  //记录数量
	int				m_nFlag;									  //标志位
	UINT			m_bObjectInfoOffset;						  //对象信息偏移
	UINT			m_nDataOffset;								  //数据偏移
	UINT			m_nBufferLen;								  //缓存长度，不包含OBJECTBUFFERHEAD的长度
}OBJECTBUFFERHEAD, *LPOBJECTBUFFERHEAD;

typedef struct
{
	int				m_nRecordLen;								  //记录长度
	long long		m_nRecordDataID;							  //记录DataID
}RECORDBUFFERHEAD, *LPRECORDBUFFERHEAD;

//记录结构体
typedef struct stu_RECORD
{
	LPVARDATA		m_lpFieldData;								  //字段值
	wchar_t**		m_pFieldStr;								  //字段字符串(用于显示字段值)
	int				m_nFieldNum;								  //字段数
	long long		m_nDataID;									  //数据ID
	BYTE			m_bRecordStatus;							  //记录状态
	BYTE*			m_pFieldModify;

	void Initial(int nFieldNum)
	{
		m_nDataID		= 0;
		m_nFieldNum		= nFieldNum;
		m_lpFieldData	= new VARDATA[m_nFieldNum];
		m_pFieldStr		= new wchar_t*[m_nFieldNum];
		m_pFieldModify  = new BYTE[m_nFieldNum];	
		memset(m_pFieldStr, 0, m_nFieldNum*sizeof(wchar_t*));
		memset(m_pFieldModify, 0, m_nFieldNum*sizeof(BYTE));
	}

	wchar_t* FieldStr(int nNum)
	{
		return m_pFieldStr[nNum];
	}

	LPVARDATA FieldValue(int nNum)
	{
		return &m_lpFieldData[nNum];
	}

	stu_RECORD()
	{
		m_lpFieldData	= NULL;
		m_pFieldStr		= NULL;
		m_nFieldNum		= 0;
		m_nDataID		= 0;
		m_bRecordStatus	= 0;
		m_pFieldModify  = NULL;
	}
	~stu_RECORD()
	{
		if(m_lpFieldData != NULL)
		{
			delete [] m_lpFieldData;
			m_lpFieldData = NULL;
		}

		if(m_pFieldStr != NULL)
		{
			int i;
			for(i = 0; i < m_nFieldNum; i++)
			{
				if(m_pFieldStr[i] != NULL)
				{
					delete [] m_pFieldStr[i];
					m_pFieldStr[i] = NULL;
				}
			}
			delete [] m_pFieldStr;
			m_pFieldStr = NULL;
		}

		if(m_pFieldModify != NULL)
		{
			delete [] m_pFieldModify;
			m_pFieldModify = NULL;
		}
	}
}RECORD,*LPRECORD;

//UpdateRecordSet执行计划
typedef struct 
{
	UINT		m_nObjectID;							   		  //对象ID
	UINT	    m_nIndexNum;							   		  //索引数量
	UINT		m_nExecuteStepNum;						   		  //执行总步骤
	UINT		m_nFieldNum;							   		  //字段数量
	UINT		m_nDeleteStepNum;								  //删除步骤数
	UINT		m_nUpdateStepNum;								  //更新步骤数
	UINT        m_nInsertStepNum;								  //插入步骤数
	UINT        m_nDeleteStepNo;						   		  //删除步骤
	UINT		m_nUpdateStepNo;						   		  //更新步骤
	UINT        m_nInsertStepNo;						   		  //插入步骤
	UINT		m_nObjectNameOffset;					   		  //对象名偏移
	UINT		m_nFieldInfoOffset;						   		  //字段信息偏移(指向XMLFIELDINFO结构体)
	UINT	    m_nRecordAddrID;							   	  //记录信息地址ID
	UINT		m_nIndexOffset;							   		  //索引计划地址ID
	UINT        m_nFieldMapOffset;   				   		      //字段映射数组偏移(一块可以共用的内存，避免频繁分配)
}UPDATERECORDSETPLANBSON,*LPUPDATERECORDSETPLANBSON;
//内存中文件定义
typedef struct
{
	long long m_nDataID;										  //数据ID
	BYTE    m_bFileNo;											  //文件编号
	MF_SYS_FILETYPE m_bFileType;								  //文件类型，1：系统文件、2：数据文件、3：B树索引文件、4：KV索引文件
	TCHAR   m_lpszFilePath[256];								  //物理文件路径
	TCHAR   m_lpszMemFileName[64];								  //内存文件名
	long long m_nFileSize;										  //文件大小
	long long * m_pLoadSize;									  //文件加载大小指针
	IVirtualMemoryFile* m_pInstance;							  //指向实例类
}MEMDBFILEDEF, *LPMEMDBFILEDEF;

//块信息
typedef struct
{
	int						m_nBlockNo;							   //块编号
	int						m_nBlockSize;						   //块大小
	BYTE					m_bAlloc;							   //是否需要分配
	MF_OBJECT_TYPE			m_bObjectType;						   //对象类型
	MF_BLOCK_SOURCE			m_bSource;							   //块来源
}BLOCKINFO,*LPBLOCKINFO;

//结果信息
typedef struct
{
	int				m_nRecordsetOffset;							  //记录集偏移
	int				m_nExecutePlanOffset;						  //执行计划偏移
	int				m_nReserved1;								  //保留字段1
	int				m_nReserved2;								  //保留字段2
	int				m_nReserved3;								  //保留字段3
	int				m_nReserved4;								  //保留字段4
}RESULTINFO, *LPRESULTINFO;

//结果集头
typedef struct  
{
	int					m_nFieldNum;								 //字段数
	int					m_nRowNum;									 //行数
	int					m_nRecordBufferOffset;						 //结果集缓存偏移
	MF_DATABASE_TYPE	m_bDatabaseType;							 //数据库类型
	BYTE				m_bModify;									 //是否可以被修改
	BYTE				m_bStartBufferNo;							 //结果集缓存片段的起始编号
	BYTE				m_bReserved;								 //保留字段							
	RECORDFIELD			m_lpRecordField[1];							 //字段值
}RECORDSETHEAD, *LPRECORDSETHEAD;

//执行计划结构体
typedef struct
{
	char				m_pObjectName[32];							 //对象名
	MF_OBJECT_TYPE		m_bObjectType;							     //对象类型
	char				m_pIndexName[32];							 //索引名
	MF_SYS_INDEXTYPE	m_bIndexType;								 //索引类型
	BYTE				m_bDrection;								 //递归方向
	BYTE				m_bRecursionLevel;							 //递归深度
	int					m_nRowNumber;								 //记录数量
	char				m_pDescribe[100];							 //描述信息
}EXECUTEPLANINFO, *LPEXECUTEPLANINFO;

//SHORTESTPATH函数
typedef struct
{
	 int				m_nLevel;									 //层次数
	 UINT				m_nStartCondOffset;						     //起始节点条件
	 UINT				m_nEndCondOffset;							 //结束节点条件
	 UINT				m_nStartIndexOffset;						 //起始节点索引条件
	 UINT				m_nEndIndexOffset;							 //结束节点索引条件
}SHORTESTPATH, *LPSHORTESTPATH;

//整型数组
typedef struct
{
	short				m_nArrayNum;
	short				m_nReserved;
	int					m_arrData[1];
}INTARRAY,*LPINTARRAY;

//BIGINT数组
typedef struct
{	
	short				m_nArrayNum;
	short				m_nReserved;
	long long			m_arrData[1];
}BIGINTARRAY,*LPBIGINTARRAY;
#pragma pack()

//内存文件虚类定义
class IVirtualMemoryFile
{
public:
	//函数名：析构函数
	//描  述：
	//参  数：无
	//返回值：无
	virtual ~IVirtualMemoryFile() {};

	//函数名：打开实例，初始化对应数据
	//描  述：
	//参  数：pFileAddr：内存文件数据块的首地址指针，需要记录在m_pFileAddr变量中
	//返回值：执行结果
	virtual int Open(LPMEMDBFILEDEF lpMemDBFileDef)                                            = 0;

	//函数名：关闭实例，清理释放内存
	//描  述：释放实例对应的资源，一般发生在服务关闭时
	//参  数：无
	//返回值：执行结果
	virtual int Close()                                                                        = 0;

	//函数名：内存整理
	//描  述：对文件及文件中的对象进行内存整理，目的是释放空间提高系统性能
	//参  数：无
	//返回值：执行结果
	virtual int MergeMemory()                                                                  = 0;

	//函数名：创建对象并初始化数据
	//描  述：创建对象时，调此函数分配初始的内存块并初始化数据
	//参  数：nID为对象ID，可能是索引也可能是对象；
	//        nBlockSize为定义的块大小；
	//        bType对象类型，详细定义见索引类型定义
	//        nDataNum为预估的数据量，对于KV索引可根据此初始化HASH块大小
	//返回值：执行结果
	virtual int CreateObject(int nID, int nBlockSize, MF_SYS_INDEXTYPE bType, int nDataNum)    = 0;

	//函数名：对象删除回收内存
	//描  述：删除对象时，调此函数释放对应内存块
	//参  数：nID为对象ID，可能是索引也可能是对象
	//返回值：执行结果
	virtual int DropObject(LPEXECUTEPLANBSON lpExecutePlan, int nID)                           = 0;

	//函数名：获取文件空间信息
	//描  述：获取文件的总空间、已用空间和剩余空间
	//参  数：
	//返回值：
	virtual int GetFileSpace(LPEXECUTEPLANBSON lpExecutePlan, long long &nFileTotalSize, long long &nFileUseSize, long long &nFileFreeSize)   = 0;

	//函数名：获取文件头
	//描  述：获取文件的头信息
	//参  数：
	//返回值：
	virtual LPBASEFILEHEAD GetFileHead() = 0;

	//函数名：备份文件数据
	//描  述：
	//参  数：lpBuffer用于备份文件头，nBufferSize为lpBuffer的长度
	//返回值：
	virtual int BackUpFileData(LPBYTE lpBuffer, int nBufferSize)								= 0;
};
