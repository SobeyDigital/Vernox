/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "stdafx.h"
#include "LinuxCommonAPI.h"
#ifndef WIN32


pthread_mutex_t g_sutMutex;

pid_t gettid()
{
	return syscall(SYS_gettid);
}

DWORD GetCurrentProcessId()
{
	return getpid();
}

DWORD GetCurrentThreadId()
{
	return (DWORD)gettid();
}

int GetLastError()
{
	return errno;
}

int WSAGetLastError()
{
	return errno;
}


int GetModuleFileName(TCHAR* sModuleName, TCHAR* sFileName, int nSize)
{
	int nRet = -1;

	if(sModuleName == NULL)
	{
		readlink("/proc/self/exe", sFileName, nSize);
		return MF_OK;
	}
	if(_tcschr(sModuleName, '/') != NULL)
	{
		_tcscpy(sFileName, sModuleName);
	}
	else
	{
		char* sPath = getenv("PATH");
		char* pHead = sPath;
		char* pTail = NULL;
		while(pHead != NULL && *pHead != '\x0')
		{
			pTail = strchr(pHead,':');
			if(pTail != NULL)
			{
				_tcsncpy( sFileName, pHead, pTail-pHead );
				sFileName[pTail-pHead] = '\x0';
				pHead = pTail+1;
			}
			else
			{
				_tcscpy( sFileName, pHead );
				pHead = NULL;
			}

			int nLen = _tcslen(sFileName);
			if(sFileName[nLen] != '/')
			{
				sFileName[nLen] = '/';
			}
			_tcscpy(sFileName+nLen+1,sModuleName);

			//判断文件是否存在
			if(0 == _taccess(sFileName, F_OK))
			{
				nRet = 0;
				break;
			}
		}
	}
	return nRet;
}

void _tcscpy_s(TCHAR* pSrc, int nNum, TCHAR* pDest)
{
	_tcscpy(pSrc, pDest);
}

long long GetFileSize(FILE* pFile, LPDWORD lpFileSizeHigh)
{
	long long llPointer, llSize;
	llPointer = ftell(pFile);
	fseek(pFile, 0, SEEK_END);
	llSize = ftell(pFile);
	fseek(pFile, llPointer, SEEK_SET);
	return llSize;
}

void CreateDirectory(char* lpFilePath, void* lpParam)
{
	mkdir(lpFilePath, 0777);
}

void TimeraddMS(struct timeval *a, uint ms)
{
	a->tv_usec += ms * 1000;
	if(a->tv_usec >= 1000000)
	{
		a->tv_sec += a->tv_usec / 1000000;
		a->tv_usec %= 1000000;
	}
}

int WaitForSingleObject(sem_t* semMutex, int nTime)
{
	int nRet = WAIT_OBJECT_0;
	timeval tTime;
	timespec tTimespec;
	gettimeofday(&tTime, NULL);
	TimeraddMS(&tTime, nTime);

	tTimespec.tv_sec = tTime.tv_sec;
	tTimespec.tv_nsec = tTime.tv_usec*1000;

	nRet = sem_timedwait(semMutex, &tTimespec);
	if(nRet != WAIT_OBJECT_0)
	{
		nRet = GetLastError();
	}
	return nRet;
}

int WaitForSingleObject(sem_t& semMutex, int nTime)
{
	int nRet = WAIT_OBJECT_0;
		timeval tTime;
		timespec tTimespec;
		gettimeofday(&tTime, NULL);
		TimeraddMS(&tTime, nTime);

		tTimespec.tv_sec = tTime.tv_sec;
		tTimespec.tv_nsec = tTime.tv_usec*1000;

		nRet = sem_timedwait(&semMutex, &tTimespec);
		if(nRet != WAIT_OBJECT_0)
		{
			nRet = GetLastError();
		}
		return nRet;
}

int WaitForSingleObject(pthread_t& thThread, int nTime)
{
	int nRet = WAIT_OBJECT_0;
	timeval tTime;
	timespec tTimespec;
	gettimeofday(&tTime, NULL);
	TimeraddMS(&tTime, nTime);

	tTimespec.tv_sec = tTime.tv_sec;
	tTimespec.tv_nsec = tTime.tv_usec*1000;

	nRet = pthread_timedjoin_np(thThread, NULL, &tTimespec);
	if(nRet != WAIT_OBJECT_0)
	{
		nRet = GetLastError();
	}
	return nRet;
}

int InterlockedIncrement(int* lData)
{
	pthread_mutex_lock(&g_sutMutex);
	(*lData)++;
	pthread_mutex_unlock(&g_sutMutex);

	return *lData;
}

int InterlockedDecrement(int* lData)
{
	pthread_mutex_lock(&g_sutMutex);
	(*lData)--;
	pthread_mutex_unlock(&g_sutMutex);

	return *lData;
}

BOOL QueryPerformanceCounter(LARGE_INTEGER *lpCounter)
{
	struct timeval timeCounter;
	gettimeofday(&timeCounter, 0);
	lpCounter->QuadPart = timeCounter.tv_sec*1000000 + timeCounter.tv_usec;
	return TRUE;
}

BOOL QueryPerformanceFrequency(LARGE_INTEGER *lpFrequency)
{
	lpFrequency->QuadPart = 1000000;
	return TRUE;
}

void GetSystemTimeAsFileTime(FILETIME* pFileTime)
{
	timeval tTime;
	gettimeofday(&tTime, 0);
	ConvertTimetoFileTime(tTime, *pFileTime);
}

void GetLocalTime(LPSYSTEMTIME lpSystemTime)
{
	timeval tTime;
	tm* pLoalTime;
	gettimeofday(&tTime, NULL);
	pLoalTime = localtime(&tTime.tv_sec);

	lpSystemTime->wYear = pLoalTime->tm_year + 1900;
	lpSystemTime->wMonth = pLoalTime->tm_mon + 1;
	lpSystemTime->wDay = pLoalTime->tm_mday;
	lpSystemTime->wHour = pLoalTime->tm_hour;
	lpSystemTime->wMinute = pLoalTime->tm_min;
	lpSystemTime->wSecond = pLoalTime->tm_sec;
	lpSystemTime->wMilliseconds = (int)(tTime.tv_usec/1000);
}

//字符串转换
int CodeConvert(const char* pSrcCode, const char* pDestCode, char *pSrcBuf, size_t nSrcLen, char *pDestBuf, size_t nDestLen)
{
	iconv_t cd;
	char **pIn, **pOut;

	pIn = &pSrcBuf;
	pOut = &pDestBuf;

	cd = iconv_open(pDestCode, pSrcCode);
	if(cd == 0)
	{
		return MF_FAILED;
	}

	memset(pDestBuf, 0, nDestLen);
	if((int)iconv(cd, pIn, &nSrcLen, pOut, &nDestLen) == -1)
	{
		return MF_FAILED;
	}

	iconv_close(cd);
	return 0;
}

char* UTF8ConvertAnsi(char* pSrc)
{
	char* pDest;
	int nSrc, nDest;

	nSrc = strlen(pSrc);
	nDest = nSrc*2;
	pDest = new char[nDest + 1];
	memset(pDest, 0, nDest + 1);

	if(CodeConvert("utf-8", "gb2312", pSrc, nSrc, pDest, nDest) != MF_OK)
	{
		return NULL;
	}

	return pDest;
}

void InitializeCriticalSection(LPCRITICAL_SECTION lpCs)
{
	pthread_mutexattr_t mattr;
	pthread_mutexattr_init(&mattr);
	pthread_mutexattr_settype(&mattr, PTHREAD_MUTEX_RECURSIVE_NP);
	pthread_mutex_init(lpCs, &mattr);
}

void DeleteCriticalSection(LPCRITICAL_SECTION lpCs)
{
	pthread_mutex_destroy(lpCs);
}

void EnterCriticalSection(LPCRITICAL_SECTION lpCs)
{
	pthread_mutex_lock(lpCs);
}

void LeaveCriticalSection(LPCRITICAL_SECTION lpCs)
{
	pthread_mutex_unlock(lpCs);
}

BOOL InitializeSecurityDescriptor(PSECURITY_DESCRIPTOR pSecurityDescriptor, DWORD dwRevision)
{
	return TRUE;
}

BOOL SetSecurityDescriptorDacl(PSECURITY_DESCRIPTOR pSecurityDescriptor, BOOL bDaclPresent, void* pDacl, BOOL bDaclDefaulted)
{
	return TRUE;
}

BOOL IsCharacter(char c)
{
	if ((c >= 48 && c <= 57) || (c>= 65 && c <= 90) || (c >= 97 && c <= 122) || c == '_' || c == '.' || c == '/')		//数字，大写字母，小写字母，下划线，小数点
	{
		return TRUE;
	} 
	else
	{
		return FALSE;
	}
}


UINT GetPrivateProfileInt(LPCSTR lpAppName, LPCSTR lpKeyName, int nDefault, LPCSTR lpFileName)
{
	char lpReturnedString[256], lpDefault[256];
	memset(lpDefault, 0, sizeof(lpDefault));
	memset(lpReturnedString, 0, sizeof(lpReturnedString));
	sprintf(lpDefault, "%d", nDefault);
	GetPrivateProfileString(lpAppName, lpKeyName, lpDefault, lpReturnedString, 256, lpFileName);

	return atoi(lpReturnedString);
}

DWORD GetPrivateProfileString(LPCSTR lpAppName, LPCSTR lpKeyName, LPCSTR lpDefault, LPSTR lpReturnedString, DWORD nSize, LPCSTR lpFileName)
{
	FILE *fp;
	BOOL bValue;
	char *lpBuffer;
	int i, nLineLength, nEqualSign, nStrLength, nValueLength;
	char arrayLine[1024];

	fp = fopen(lpFileName, "r");
	if (fp == NULL)
	{
		nValueLength = strlen(lpDefault);
		if(nValueLength > nSize-1)
		{
			nValueLength = nSize-1;
		}
		memcpy(lpReturnedString, lpDefault, nValueLength);
		lpReturnedString[nValueLength] = 0;
		return nValueLength;
	}

	nStrLength = strlen(lpKeyName);
	while(!feof(fp))
	{
		memset(arrayLine, 0, sizeof(arrayLine));
		if(fgets(arrayLine, 1000, fp))		//读取一行
		{
			nLineLength = strlen(arrayLine);
			i = 0;
			nEqualSign = 0;
			bValue = FALSE;
			while (i < nLineLength)
			{
				if (arrayLine[i] == ' ' || arrayLine[i] == '\t')
				{
					i++;
					continue;
				}
				if (arrayLine[i] == '#' || arrayLine[i] == '\n' || arrayLine[i] == '\r')		//注释
				{
					break;
				}
				if (arrayLine[i] == '=')
				{
					nEqualSign++;
					if (nEqualSign > 1)
					{
						break;
					}
					i++;
					continue;
				}

				if (!IsCharacter(arrayLine[i]))
				{
					break;
				}

				if (!bValue)
				{
					if (nEqualSign == 0)
					{
						lpBuffer = arrayLine+i;
						if (i + nStrLength < nLineLength)
						{
							if (strncasecmp(lpBuffer, lpKeyName, nStrLength) == 0)
							{
								i = i+nStrLength;
								bValue = TRUE;
							} 
							else
							{
								break;
							}
						}
						else
						{
							break;
						}
					} 
					else
					{
						break;
					}
				} 
				else
				{
					if (nEqualSign == 1)
					{
						nValueLength = 0;
						lpBuffer = arrayLine+i;
						while (i < nLineLength)
						{
							if (IsCharacter(arrayLine[i]))
							{
								i++;
								nValueLength++;
								continue;
							}
							if(nValueLength > nSize-1)
							{
								nValueLength = nSize-1;
							}
							memcpy(lpReturnedString, lpBuffer, nValueLength);
							lpReturnedString[nValueLength] = 0;

							if (fp != NULL)
							{
								fclose(fp);
							}
							return nValueLength;
						}
					} 
					else
					{
						break;
					}
				}
			}
			if (bValue && nEqualSign == 1)
			{
				memset(lpReturnedString, 0, nSize);
				nValueLength = 0;
				if (fp != NULL)
				{
					fclose(fp);
				}
				return nValueLength;
			}
		}
		else
		{
			break;
		}
	}

	if (fp != NULL)
	{
		fclose(fp);
	}

	nValueLength = strlen(lpDefault);
	if(nValueLength > nSize-1)
	{
		nValueLength = nSize-1;
	}
	memcpy(lpReturnedString, lpDefault, nValueLength);
	lpReturnedString[nValueLength] = 0;
	return nValueLength;
}

bool WritePrivateProfileString(LPCSTR lpAppName, LPCSTR lpKeyName, LPCSTR lpString, LPCSTR lpFileName)
{
	FILE *fp;
	char *lpBuffer;
	int i, nLineLength, nStrLength, nPosEnd, nPosBegin;
	char arrayLine[1024];

	fp = fopen(lpFileName, "r+");
	if (fp == NULL)
	{
		return false;
	}

	nPosEnd = 0;
	nPosBegin = 0;
	nStrLength = strlen(lpKeyName);
	while(!feof(fp))
	{
		memset(arrayLine, 0, sizeof(arrayLine));
		if(fgets(arrayLine, 1000, fp))		//读取一行
		{
			nLineLength = strlen(arrayLine);
			nPosBegin = nPosEnd;
			nPosEnd += nLineLength;

			i = 0;
			while (i < nLineLength)
			{
				if (arrayLine[i] == ' ' || arrayLine[i] == '\t')
				{
					i++;
					continue;
				}
				if (arrayLine[i] == '#' || arrayLine[i] == '\n' || arrayLine[i] == '\r')		//注释
				{
					break;
				}

				if (!IsCharacter(arrayLine[i]))
				{
					break;
				}


				lpBuffer = arrayLine+i;
				if (i + nStrLength < nLineLength)
				{
					if (strncasecmp(lpBuffer, lpKeyName, nStrLength) == 0)
					{
						if ('\t' == lpBuffer[nStrLength] || lpBuffer[nStrLength] == ' ' || lpBuffer[nStrLength] == '=')
						{
							char* pBuffer;
							LONGLONG llFileSize, llBufferSize;
							fseek(fp, 0, SEEK_END);
							llFileSize = ftell(fp);

							llBufferSize = llFileSize - nPosEnd;
							pBuffer = new char[llBufferSize];
							if (pBuffer == NULL)
							{
									return false;
							}
							fseek(fp, nPosEnd, SEEK_SET);
							fread(pBuffer, 1, llBufferSize, fp);

							memset(arrayLine, 0, sizeof(arrayLine));
							sprintf(arrayLine, "%s = %s\r\n", lpKeyName, lpString);
							fseek(fp, nPosBegin, SEEK_SET);
							fwrite(arrayLine, 1, strlen(arrayLine), fp);
							fwrite(pBuffer, 1, llBufferSize, fp);

							if (pBuffer != NULL)
							{
								delete[] pBuffer;
							}
							if (fp != NULL)
							{
								fclose(fp);
							}
							return true;
						}
						else
						{
							break;
						}
					} 
					else
					{
						break;
					}
				}
				else
				{
					break;
				}
			}
		}
		else
		{
			break;
		}
	}

	if (fp != NULL)
	{
		fclose(fp);
	}

	return false;
}

int SetEvent(sem_t* pSem)
{
	return sem_post(pSem);
}

int SetEvent(sem_t& pSem)
{
	return sem_post(&pSem);
}

BOOL VariantTimeToSystemTime(DATE dtDate, tm* &pTime)
{
	time_t tTime;
	tTime = ConvertDateToTime(dtDate);
	pTime = localtime(&tTime);
	if(pTime == NULL)
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

void strupr(char* pStr)
{
	int nLen, i;
	nLen = strlen(pStr);
	for(i = 0; i < nLen; i++)
	{
		if(pStr[i] >= 'a' && pStr[i] <= 'z')
		{
			pStr[i] = pStr[i] - 32;
		}
	}
}

long long _abs64(long long nData)
{
	return llabs(nData);
}

#endif
