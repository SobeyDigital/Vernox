﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
CBaseBson::CBaseBson(void)
{
	m_lpBuf					= NULL;						//缓存Buf
	m_lpBuffer				= NULL;						//缓存Buffer
	m_nFreeBufferSize		= 0;					    //缓存总大小
	m_nExecutePlanDataSize	= 0;						//数据总大小

	m_bAutoRelease			= TRUE;						//是否自动释放

	m_nBsonBufferSize		= 0;						//Bson大小
	m_nBsonDataSize			= 0;						//Bson中的数据量

	m_lpCurrentSection		= NULL;					    //当前缓存片段
	m_nCurrentDataSize		= 0;						//当前缓存中已有数据大小
	m_nCurrentSectionNo		= 0;						//当前缓存片段编号
	m_nCurrentSectionSzie	= 0;						//当前缓存片段大小
	m_nDefaultSectionSize	= MF_BUFFERSECTION_SIZE;	//默认缓存大小	

	m_nBufferSectionNum		= 0;
	m_bChangeSection		= FALSE;	
	m_lpPreRecordHead		= NULL;
	m_lpPreExecuteStep		= NULL;

	memset(m_arrBufferSection, 0, sizeof(LPBYTE)*MAX_SECTION_BUFFER);
}

CBaseBson::~CBaseBson(void)
{
	Free();
}

/************************************************************************
		功能说明：
			释放内存
************************************************************************/
void CBaseBson::Free()
{
	if(m_bAutoRelease)
	{
		if(m_lpBuf != NULL)
		{
			delete [] m_lpBuf;
			m_lpBuf = NULL;
		}
		m_lpBuffer = NULL;
	}

	for(short i = 0; i < m_nBufferSectionNum; i++)
	{
		if(m_arrBufferSection[i] != NULL)
		{
			delete [] m_arrBufferSection[i];
			m_arrBufferSection[i] = NULL;
		}
	} 

	m_nFreeBufferSize		= 0;					    //空闲缓存大小
	m_nExecutePlanDataSize		= 0;						//数据总大小
	m_bAutoRelease			= TRUE;						//是否自动释放
	m_nBsonBufferSize		= 0;						//Bson大小
	m_nBsonDataSize			= 0;						//Bson中的数据量
	m_lpCurrentSection		= NULL;					    //当前缓存片段
	m_nCurrentDataSize		= 0;						//当前缓存中已有数据大小
	m_nCurrentSectionNo		= 0;						//当前缓存片段编号
	m_nCurrentSectionSzie	= 0;						//当前缓存片段大小
	m_nDefaultSectionSize	= MF_BUFFERSECTION_SIZE;	//默认缓存大小	
	m_nBufferSectionNum		= 0;
	m_bChangeSection		= FALSE;	
	m_lpPreRecordHead		= NULL;
	m_lpPreExecuteStep		= NULL;

	memset(m_arrBufferSection, 0, sizeof(LPBYTE)*MAX_SECTION_BUFFER);
}

/************************************************************************
		功能说明：
			创建存放BSON的BUFFER
		参数说明：
			nBufferSize：Buffer大小
			bSection：是否分配缓存片段
************************************************************************/
int CBaseBson::AllocBsonBuffer(UINT nBsonBufferSize)
{
	int nTcpSize;
	if(m_lpBuf != NULL)
	{
		delete [] m_lpBuf;
		m_lpBuf = NULL;
	}
	nTcpSize		= sizeof(MF_SERVICE_TCP_COMMAND);
	nBsonBufferSize = (nBsonBufferSize / MF_BUFFERSECTION_SIZE + 1) * MF_BUFFERSECTION_SIZE;

	m_lpBuf = new BYTE[nBsonBufferSize + nTcpSize];
	if(NULL == m_lpBuf)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	m_lpBuffer = m_lpBuf + nTcpSize;
	memset(m_lpBuf, 0, nBsonBufferSize + nTcpSize);
	m_nBsonBufferSize = nBsonBufferSize;
	m_nFreeBufferSize = nBsonBufferSize;
	return MF_OK;
}

/************************************************************************
		功能说明：
			分配缓存片段
************************************************************************/
int CBaseBson::AllocBufferSection()
{
	m_lpCurrentSection   = new BYTE[m_nDefaultSectionSize];
	m_arrBufferSection[m_nBufferSectionNum] = m_lpCurrentSection;


	m_nExecutePlanDataSize+= sizeof(BUFFERSECTIONHEAD);
	m_nCurrentDataSize	  = sizeof(BUFFERSECTIONHEAD);				//预留空间存放偏移
	m_nCurrentSectionSzie = m_nDefaultSectionSize;
	m_nBufferSectionNum++;
	if(m_nBufferSectionNum > MAX_SECTION_BUFFER)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	m_nCurrentSectionNo++;
	return MF_OK;
}

/************************************************************************
		功能说明：
			从BSON缓存中分配空间
		参数说明：
			nLen：空间大小
			nOffset：偏移
			lpAddr：地址指针
************************************************************************/
int CBaseBson::AllocFromBsonBuffer(UINT nLen, UINT &nOffset, LPBYTE &lpAddr)
{
	int nRet, nNewDataLen, nOldDataLen;

	nNewDataLen = 0;						//分配后的数据长度
	nOldDataLen = 0;						//如果在分配的时候，发生因内存不足引起的Buffer重分配，
											//那么原始插入位置的指针(pInsertAddr)也就会发生变化，所以要记录插入位置的偏移，以便重新计算插入位置
	if(m_lpBuffer == NULL)
	{
		nRet = AllocBsonBuffer(MF_BUFFERSECTION_SIZE);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	if(lpAddr == NULL)
	{
		nNewDataLen = m_nBsonDataSize;		//在现有数据局末尾插入新数据
		nOldDataLen = nNewDataLen;
		if(nNewDataLen+nLen > m_nBsonBufferSize)
		{	
			return MF_PARSECMD_EXECUTEPALN_LACKSPACE_ERROR;
		}
	}
	else
	{
		nNewDataLen = (int)(lpAddr - m_lpBuffer);	//在现有数据中间某处插入数据
		nOldDataLen = nNewDataLen;
		if(nNewDataLen+nLen > m_nBsonBufferSize)
		{	
			return MF_PARSECMD_EXECUTEPALN_LACKSPACE_ERROR;
		}
	}

	nNewDataLen += nLen;
	if((UINT)nNewDataLen > m_nBsonDataSize)
	{
		m_nBsonDataSize  =  nNewDataLen;
		m_nExecutePlanDataSize += nLen;
	}

	nOffset = nOldDataLen;
	lpAddr  = m_lpBuffer + nOldDataLen;
	memset(lpAddr, 0, nLen);
	m_nFreeBufferSize -= nLen;
	return MF_OK;
}

/************************************************************************
		功能说明：
			从BSON缓存片段中分配空间
		参数说明：
			nLen：空间大小
			nAddrID：地址ID
			lpAddr：地址指针
************************************************************************/
int CBaseBson::AllocFromBufferSection(UINT nLen, UINT &nAddrID, LPBYTE &lpBuffer)
{
	int nRet;
	USHORT nNewDataSize, nOldDataSize, nOffset;

	if(m_lpCurrentSection == NULL)
	{
		nRet = AllocBufferSection();
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	if(lpBuffer == NULL)
	{
		nNewDataSize = m_nCurrentDataSize;									//在现有数据局末尾插入新数据
	}
	else
	{
		nNewDataSize = (int)(lpBuffer - m_lpCurrentSection);				//在现有数据中间某处插入数据
	}

	nOldDataSize = nNewDataSize;
	if(nNewDataSize + nLen > m_nCurrentSectionSzie)
	{	
		m_nExecutePlanDataSize += m_nCurrentSectionSzie - m_nCurrentDataSize;		//因为是以片段为单位分配空间，所以分配新片段时，需要将原始片段长度补齐
		nRet = AllocBufferSection();
		if(nRet != MF_OK)
		{
			return nRet;
		}

		m_bChangeSection = TRUE;
		nNewDataSize	 = m_nCurrentDataSize;		
		nOldDataSize	 = m_nCurrentDataSize;		
	}

	nNewDataSize += nLen;
	if(nNewDataSize > m_nCurrentDataSize)
	{
		m_nCurrentDataSize = nNewDataSize;
		m_nExecutePlanDataSize   += nLen;
	}

	nOffset  = nOldDataSize;
	lpBuffer = m_lpCurrentSection + nOffset;
	memset(lpBuffer, 0, nLen);
	nAddrID = MakeAddrID(m_nCurrentSectionNo, nOffset);
	return MF_OK;
}

/************************************************************************
		功能说明：
			分离Buffer
************************************************************************/
LPBYTE CBaseBson::DetachBuffer()
{
	LPBYTE lpRetBuffer;
	lpRetBuffer			= m_lpBuffer;
	m_lpBuffer			= NULL;
	m_nBsonBufferSize	= 0;
	m_nBsonDataSize		= 0;
	return lpRetBuffer;
}

/************************************************************************
		功能说明：
			设置Buffer(不能自动释放Buffer)
************************************************************************/
void CBaseBson::SetBuffer(LPBYTE lpBuffer, int nBufferLen, int nDataLen)
{
	m_lpBuffer			= lpBuffer;
	m_nBsonBufferSize	= nBufferLen;
	m_nBsonDataSize		= nDataLen;
	m_bAutoRelease		= FALSE;
}

/************************************************************************
	功能说明：
		分配记录头
	参数说明：
		lpRecordHead：记录头指针
		nAddrID：地址ID
************************************************************************/
int CBaseBson::AllocRecord(LPRECORDHEAD& lpRecordHead, UINT& nAddrID)
{
	int nRet;
	nRet = AllocFromBufferSection(lpRecordHead, nAddrID);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(m_bChangeSection)
	{
		if(m_lpPreRecordHead != NULL)
		{
			m_lpPreRecordHead->m_bLast = 1;
		}
		m_bChangeSection = FALSE;
	}
	
	m_lpPreRecordHead = lpRecordHead;
	return MF_OK;
}

/************************************************************************
	功能说明：
		分配执行步骤
	参数说明：
		lpExecuteStep：执行步骤
		nAddrID：地址ID
************************************************************************/
int CBaseBson::AllocStep(LPEXECUTESTEP& lpExecuteStep, UINT& nAddrID)
{
	int nRet;
	nRet = AllocFromBufferSection(lpExecuteStep, nAddrID);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(m_bChangeSection)
	{
		if(m_lpPreExecuteStep != NULL)
		{
			m_lpPreExecuteStep->m_bFlag = 2;
		}
		m_bChangeSection	   = FALSE;
		lpExecuteStep->m_bFlag = 1;
	}

	m_lpPreExecuteStep = lpExecuteStep;
	return MF_OK;
}

/************************************************************************
	功能说明：
		给缓存片段加上偏移
	参数说明：
		lpExecuteStep：执行步骤
		nAddrID：地址ID
************************************************************************/
void CBaseBson::SetSectionOffset()
{
	int nBufferNo;
	UINT nOffset;
	LPBYTE lpBufferSection;

	nOffset = m_nBsonDataSize;
	for(nBufferNo = 1; nBufferNo <= m_nBufferSectionNum; nBufferNo++)
	{
		lpBufferSection = m_arrBufferSection[nBufferNo - 1];

		if(nBufferNo == m_nBufferSectionNum)
		{
			//最后一个片段偏移为0
			((LPBUFFERSECTIONHEAD)lpBufferSection)->m_nNextSectionOffset = 0;
		}
		else
		{
			((LPBUFFERSECTIONHEAD)lpBufferSection)->m_nNextSectionOffset = nOffset + nBufferNo*m_nDefaultSectionSize;
		}
	}

}
/************************************************************************
		功能说明：
			将字段值写入指定位置
		参数说明：
			pInsertAddr：指定的位置
			bFieldType：字段类型
			bFieldNo：字段编号
			varData：字段值
************************************************************************/
int CBaseBson::WriteFieldData(MF_SYS_FIELDTYPE bFieldType, BYTE bFieldNo, VARDATA &varData, LPBYTE lpAddr)
{
	UINT nOffset;
	int nRet, nLen;
	switch(bFieldType)
	{
	case MF_SYS_FIELDTYPE_NULL:
		break;
	case MF_SYS_FIELDTYPE_INT:
		nLen = sizeof(BYTE) + sizeof(int);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((int*)lpAddr) = varData.m_nValue;
		break;
	case MF_SYS_FIELDTYPE_BIGINT:
		nLen = sizeof(BYTE) + sizeof(long long);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((long long*)lpAddr) = varData.m_llValue;
		break;
	case MF_SYS_FIELDTYPE_DATE:
	case MF_SYS_FIELDTYPE_DOUBLE:
		nLen = sizeof(BYTE) + sizeof(double);
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((double*)lpAddr) = varData.m_dblValue;
		break;
	case MF_SYS_FIELDTYPE_CHAR:
	case MF_SYS_FIELDTYPE_VARCHAR:
	case MF_SYS_FIELDTYPE_CLOB:
	case MF_SYS_FIELDTYPE_BLOB:
		nLen = sizeof(BYTE) + sizeof(int) + varData.m_nStrLen;
		nRet = AllocFromBsonBuffer(nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		*((BYTE*)lpAddr) = bFieldNo;
		lpAddr += sizeof(BYTE);
		*((int*)lpAddr) = varData.m_nStrLen;
		lpAddr += sizeof(int);
		memcpy(lpAddr, varData.m_lpszValue, varData.m_nStrLen);
		break;
	}
	return MF_OK;
}

//插入BYTE类型数据
BOOL CBaseBson::AppendByte(BYTE bData)
{
	if(CheckInsert(sizeof(BYTE)))
	{
		*((BYTE*)GrowBufferLen(sizeof(BYTE))) = bData;					//插入int值
		return TRUE;
	}
	return FALSE;
}
//插入短整型数据
BOOL CBaseBson::AppendShort(short nData)
{
	if(CheckInsert(sizeof(short)))
	{
		//插入短整型数据
		*((short*)GrowBufferLen(sizeof(short))) = nData;				//插入int值
		return TRUE;
	}
	return FALSE;
}
//插入32位整型数据
BOOL CBaseBson::AppendInt32(int nData)
{
	if(CheckInsert(sizeof(int)))
	{
		*((int*)GrowBufferLen(sizeof(int))) = nData;					//插入int值
		return TRUE;
	}
	return FALSE;
}
//插入64位整型数据
BOOL CBaseBson::AppendInt64(long long nData)
{
	if(CheckInsert(sizeof(long long)))
	{
		*((long long*)GrowBufferLen(sizeof(long long))) = nData;		//插入long long值
		return TRUE;
	}
	return FALSE;
}
//插入浮点数类型
BOOL CBaseBson::AppendDouble(double dData)
{
	if(CheckInsert(sizeof(double)))
	{
		*((double*)GrowBufferLen(sizeof(double))) = dData;				//插入double值
		return TRUE;
	}
	return FALSE;
}
//插入字符串类型
BOOL CBaseBson::AppendBuffer(void* pData, int nLen)
{
	if(CheckInsert(nLen))
	{
		memcpy(GrowBufferLen(nLen),pData,nLen);							//插入字符串
		return TRUE;
	}
	return FALSE;
}

