/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#ifndef	WIN32

#include "../Include/MemDBCommonDef.h"
#include <stdio.h>
#include <pthread.h>
#include <sys/time.h>
#include <semaphore.h>
#include "ShareMemory.h"
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <iconv.h>

pid_t gettid();

DWORD GetCurrentProcessId();

DWORD GetCurrentThreadId();

int GetLastError();

int WSAGetLastError();

long long GetFileSize(FILE* pFile, LPDWORD lpFileSizeHigh = NULL);

void _tcscpy_s(TCHAR* pSrc, int nNum, TCHAR* pDest);

void CreateDirectory(char* lpFilePath, void* lpParam);

int GetModuleFileName(TCHAR* sModuleName, TCHAR* sFileName, int nSize);

int InterlockedIncrement(int* lData);

int InterlockedDecrement(int* lData);

void TimeraddMS(struct timeval *a, uint ms);

int WaitForSingleObject(sem_t* semMutex, int nTime);

int WaitForSingleObject(sem_t& semMutex, int nTime);

int WaitForSingleObject(pthread_t& thThread, int nTime);

BOOL QueryPerformanceCounter(LARGE_INTEGER *lpCounter);

BOOL QueryPerformanceFrequency(LARGE_INTEGER *lpFrequency);

char* UTF8ConvertAnsi(char* pSrc);

//字符串转换
void GetSystemTimeAsFileTime(FILETIME* pFileTime);

void GetLocalTime(LPSYSTEMTIME lpSystemTime);

void InitializeCriticalSection(LPCRITICAL_SECTION lpCs);

void DeleteCriticalSection(LPCRITICAL_SECTION lpCs);

void EnterCriticalSection(LPCRITICAL_SECTION lpCs);

void LeaveCriticalSection(LPCRITICAL_SECTION lpCs);


typedef int *PSECURITY_DESCRIPTOR;
BOOL InitializeSecurityDescriptor(PSECURITY_DESCRIPTOR pSecurityDescriptor, DWORD dwRevision);

BOOL SetSecurityDescriptorDacl(PSECURITY_DESCRIPTOR pSecurityDescriptor, BOOL bDaclPresent, void* pDacl, BOOL bDaclDefaulted);


BOOL IsCharacter(char c);

UINT GetPrivateProfileInt(LPCSTR lpAppName, LPCSTR lpKeyName, int nDefault, LPCSTR lpFileName);

DWORD GetPrivateProfileString(LPCSTR lpAppName, LPCSTR lpKeyName, LPCSTR lpDefault, LPSTR lpReturnedString, DWORD nSize, LPCSTR lpFileName);

bool WritePrivateProfileString(LPCSTR lpAppName, LPCSTR lpKeyName, LPCSTR lpString, LPCSTR lpFileName);

int SetEvent(sem_t* pSem);

int SetEvent(sem_t& pSem);

BOOL VariantTimeToSystemTime(DATE dtDate, tm* &pTime);

void strupr(char* pStr);

long long _abs64(long long nData);

#endif
