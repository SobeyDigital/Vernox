﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
/************************************************************************
	完成数据的解析，对数据进行序列化和反序列化
************************************************************************/
#ifdef WIN32
#include <map>
using namespace std;

class CTableMap;
class TiXmlElement;
class TiXmlDocument;
class TiXmlAttribute;
class CBaseMemoryAnalysis
{
protected:
	//字段数据结构体(用于在序列化和反序列化时临时存放数据)
	#pragma pack(1)
	typedef struct 
	{
		MF_SYS_FIELDTYPE m_bFieldType;
		BYTE			 m_bFieldNo;
		VARDATA			 m_varData;	
	}FIELDDATA,*LPFIELDDATA;

	//XML中的字段定义
	typedef struct stu_XMLFIELDDEF
	{
		BYTE			 m_bTempNo;			    //字段的临时编号(用于方便的查询字段信息)
		BYTE			 m_bFieldType;			//字段的类型
		BYTE			 m_bMaxLen;				//最大长度
		BYTE		     m_bPrimaryKey;			//是否主键
		int				 m_nFieldNameLen;		//字段名长度,包含结束符
		char*			 m_pFieldName;		    //字段名，直接指向XML中对应的字段名，所以不需要释放

		stu_XMLFIELDDEF()
		{
			m_bTempNo		= 0;
			m_bFieldType	= 0;
			m_bPrimaryKey	= 0;
			m_bMaxLen		= 0;
			m_nFieldNameLen = 0;
			m_pFieldName	= NULL;
		}
	}XMLFIELDDEF,*LPXMLFIELDDEF;

	//XML中的表定义
	typedef struct stu_XMLOBJECTDEF
	{
		BYTE			 m_bFieldNum;			//列数量
		BYTE             m_bReserved[3];        //保留数据
		int				 m_nObjectNameLen;		//Object名称长度,包含结束符
		char*			 m_pObjectName;			//对象名，直接指向XML中对应的字段名，所以不需要释放
		LPXMLFIELDDEF	 m_pField;				//列数组
		map<string, BYTE> m_mapNameToNo;		//字段名与字段编号的映射表
		stu_XMLOBJECTDEF()
		{
			m_bFieldNum			= 0;
			m_bReserved[0]		= 0;
			m_bReserved[1]		= 0;
			m_bReserved[2]		= 0;
			m_nObjectNameLen	= 0;
			m_pObjectName		= NULL;
			m_pField			= NULL;
		}
		~stu_XMLOBJECTDEF()
		{
			if(m_pObjectName != NULL)
			{
				delete [] m_pObjectName;
				m_pObjectName = NULL;
			}
			if(m_pField != NULL)
			{
				delete [] m_pField;
				m_pField = NULL;
			}
			m_mapNameToNo.clear();
		}
	}XMLOBJECTDEF,*LPXMLOBJECTDEF;

	//MYSQL
	enum mf_enum_mysql_timestamp_type
	{
		MYSQL_TIMESTAMP_NONE= -2, MYSQL_TIMESTAMP_ERROR= -1,
		MYSQL_TIMESTAMP_DATE= 0, MYSQL_TIMESTAMP_DATETIME= 1, MYSQL_TIMESTAMP_TIME= 2
	};

	typedef struct mf_st_mysql_time
	{
		unsigned int  year, month, day, hour, minute, second;
		unsigned long second_part;  /**< microseconds */
		char       neg;
		enum mf_enum_mysql_timestamp_type time_type;
	} MF_MYSQL_TIME;

	#pragma pack()
protected:
	/************************************************************************
		功能说明：
			创建字段BSON
	************************************************************************/
	void CreateFieldBson(BYTE bType, const char* pszData, LPBYTE lpResult, int nLen);

	/************************************************************************
		功能说明：
			根据XML获取Object的相关信息
	************************************************************************/
	int GetXmlObjectDef();
	
	/************************************************************************
		功能说明：
			根据XML的记录中的所有属性，创建字段信息Bson
	************************************************************************/
	int GetXmlFieldInfo(CBaseBson& stBson, UINT& nFieldInfoOffset);

	/************************************************************************
		功能说明：
			根据XML的记录中的所有属性，创建字段Bson
	************************************************************************/
	int GetXmlFieldBson(CBaseBson& stBson, LPRECORDHEAD lpRecordHead, TiXmlAttribute* pXmlAttribute);
	
	/************************************************************************
		功能说明：
			获取XML信息组成字符串
	************************************************************************/
	int GetXmlInfoStr(CBaseBson& stBson, LPXMLOBJECTDEF pXmlObjectDef, int nDeleteNum, int nUpdateNum, int nInsertNum, int& nStrLen);

public:
	/************************************************************************
		功能说明：
			创建xml
	************************************************************************/
	int BuildXML(std::string &pRsXml, LPBYTE pBsonBuffer, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	
	/************************************************************************
		功能说明：
			根据结点名称获取结点
	************************************************************************/
	int SelectSingleNode(TiXmlElement* pXmlRootElement, char* pNodeName, TiXmlElement* &pOutNode);
	
	/************************************************************************
		功能说明：
			根据结点名称获取结点
	************************************************************************/
	int SelectSingleNodeFromCurrentRoot(TiXmlElement* pXmlRootElement, char* chNodeName, TiXmlElement* &pOutNode);

	/************************************************************************
		功能说明：
			获取字段数量
	************************************************************************/
	int GetFieldNum(TiXmlElement* pNodeElement, BYTE& bFieldNum);

	/************************************************************************
		功能说明：
			解析内存数据库XML，创建BSON
	************************************************************************/
	int ParseMemXML(CBaseBson& stBson, const char * lpszXML, int nXmlLen, LPEXECUTEPLANBSON& lpExecutePlan);

private:
	TiXmlDocument*			m_pTinyXmlRoot;						//XML根结点
	LPXMLOBJECTDEF	        m_pXmlObjectInfo;					//XMLObject对象
public:
	CBaseMemoryAnalysis();
	~CBaseMemoryAnalysis(void);
	/************************************************************************
		功能说明：
			解析XML，创建BSON
	************************************************************************/
	int ParseXML(CBaseBson& stBson, BSTR bstrXML, LPEXECUTEPLANBSON& lpExecutePlan);
	int ParseXML(CBaseBson& stBson, const char * lpszXML, int nXmlLen, LPEXECUTEPLANBSON& lpExecutePlan);
};
#endif
