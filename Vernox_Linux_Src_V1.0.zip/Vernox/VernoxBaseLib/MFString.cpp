﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "MFString.h"
#include <stdarg.h>
#ifdef WIN32
#include "wtypes.h"
#endif
CMFString::CMFString(void)
{
}

CMFString::CMFString(char* pData)
{
	assign(pData);
}

CMFString::CMFString(const char* pData)
{
	assign(pData);
}

CMFString::~CMFString(void)
{
}

void CMFString::Format(const char *fmt, ... )
{
	va_list args;
	char lpBuffer[20480];

	va_start(args, fmt);
	vsnprintf(lpBuffer, 20480, fmt, args);
	lpBuffer[20479] = 0;
	va_end(args);

	assign(lpBuffer, 20480);
}

int CMFString::CompareNoCase(const CMFString & chDest)
{
	int i,nLen,nDLen;
	DWORD * pDes,*pSrc;
	char*pchDes,*pchSrc;
	nLen = min(length(), chDest.length()) + 1;
	const char* chSrc = c_str();
	const char* chDes = chDest.c_str();
	pSrc = (DWORD *)chSrc;
	pDes = (DWORD *)chDes;
	nDLen = nLen>>2;
	for(i = 0;i < nDLen;i++)
	{
		if(pSrc[i] == pDes[i])
			continue;
		else
		{
			pchDes = (char*)(pDes+i);
			pchSrc = (char*)(pSrc+i);
			if(pchDes[0] == pchSrc[0])
			{
			}
			else if(pchDes[0] >= 'a' && pchDes[0] <= 'z')
			{
				if(pchDes[0] - pchSrc[0] != 32)
				{
					return pchDes[0] - pchSrc[0];
				}
			}
			else if(pchSrc[0] >= 'a' && pchSrc[0] <= 'z')
			{
				if(pchSrc[0] - pchDes[0] != 32)
				{
					return pchDes[0] - pchSrc[0];
				}
			}
			else
			{
				return pchDes[0] - pchSrc[0];
			}

			if(pchDes[1] == pchSrc[1])
			{
			}
			else if(pchDes[1] >= 'a' && pchDes[1] <= 'z')
			{
				if(pchDes[1] - pchSrc[1] != 32)
				{
					return pchDes[1] - pchSrc[1];
				}
			}
			else if(pchSrc[1] >= 'a' && pchSrc[1] <= 'z')
			{
				if(pchSrc[1] - pchDes[1] != 32)
				{
					return pchDes[1] - pchSrc[1];
				}
			}
			else
			{
				return pchDes[1] - pchSrc[1];
			}

			if(pchDes[2] == pchSrc[2])
			{
			}
			else if(pchDes[2] >= 'a' && pchDes[2] <= 'z')
			{
				if(pchDes[2] - pchSrc[2] != 32)
				{
					return pchDes[2] - pchSrc[2];
				}
			}
			else if(pchSrc[2] >= 'a' && pchSrc[2] <= 'z')
			{
				if(pchSrc[2] - pchDes[2] != 32)
				{
					return pchDes[2] - pchSrc[2];
				}
			}
			else
			{
				return pchDes[2] - pchSrc[2];
			}

			if(pchDes[3] == pchSrc[3])
			{
			}
			else if(pchDes[3] >= 'a' && pchDes[3] <= 'z')
			{
				if(pchDes[3] - pchSrc[3] != 32)
				{
					return pchDes[3] - pchSrc[3];
				}
			}
			else if(pchSrc[3] >= 'a' && pchSrc[3] <= 'z')
			{
				if(pchSrc[3] - pchDes[3] != 32)
				{
					return pchDes[3] - pchSrc[3];
				}
			}
			else
			{
				return pchDes[3] - pchSrc[3];
			}
		}
	}

	pchDes = (char*)(pDes+i);
	pchSrc = (char*)(pSrc+i);
	for(i =0;i < 4;i++)
	{
		if(pchSrc[i] == 0)
		{
			return pchDes[i] - pchSrc[i];
		}
		else if(pchSrc[i] == pchDes[i])
		{
			continue;
		}
		else
		{
			if(pchDes[i] >= 'a' && pchDes[i] <= 'z')
			{
				if(pchDes[i] - pchSrc[i] != 32)
				{
					return pchDes[i] - pchSrc[i];
				}
			}
			else if(pchSrc[i] >= 'a' && pchSrc[i] <= 'z')
			{
				if(pchSrc[i] - pchDes[i] != 32)
				{
					return pchDes[i] - pchSrc[i];
				}
			}
			else
			{
				return pchDes[i] - pchSrc[i];
			}
		}
	}
	return 0;
}

int CMFString::CompareNoCase(const char* chDest)
{
	int i,nLen,nDLen;
	const char* chSrc;
	DWORD * pDes,*pSrc;
	char*pchDes,*pchSrc;
	
	if(chDest == NULL)
	{
		return -1;
	}
	nLen = length();
	chSrc = c_str();
	pSrc = (DWORD *)chSrc;
	pDes = (DWORD *)chDest;
	nDLen = nLen>>2;
	for(i = 0;i < nDLen;i++)
	{
		if(pSrc[i] == pDes[i])
			continue;
		else
		{
			pchDes = (char*)(pDes+i);
			pchSrc = (char*)(pSrc+i);
			if(pchDes[0] == pchSrc[0])
			{
			}
			else if(pchDes[0] >= 'a' && pchDes[0] <= 'z')
			{
				if(pchDes[0] - pchSrc[0] != 32)
				{
					return pchDes[0] - pchSrc[0];
				}
			}
			else if(pchSrc[0] >= 'a' && pchSrc[0] <= 'z')
			{
				if(pchSrc[0] - pchDes[0] != 32)
				{
					return pchDes[0] - pchSrc[0];
				}
			}
			else
			{
				return pchDes[0] - pchSrc[0];
			}

			if(pchDes[1] == pchSrc[1])
			{
			}
			else if(pchDes[1] >= 'a' && pchDes[1] <= 'z')
			{
				if(pchDes[1] - pchSrc[1] != 32)
				{
					return pchDes[1] - pchSrc[1];
				}
			}
			else if(pchSrc[1] >= 'a' && pchSrc[1] <= 'z')
			{
				if(pchSrc[1] - pchDes[1] != 32)
				{
					return pchDes[1] - pchSrc[1];
				}
			}
			else
			{
				return pchDes[1] - pchSrc[1];
			}

			if(pchDes[2] == pchSrc[2])
			{
			}
			else if(pchDes[2] >= 'a' && pchDes[2] <= 'z')
			{
				if(pchDes[2] - pchSrc[2] != 32)
				{
					return pchDes[2] - pchSrc[2];
				}
			}
			else if(pchSrc[2] >= 'a' && pchSrc[2] <= 'z')
			{
				if(pchSrc[2] - pchDes[2] != 32)
				{
					return pchDes[2] - pchSrc[2];
				}
			}
			else
			{
				return pchDes[2] - pchSrc[2];
			}

			if(pchDes[3] == pchSrc[3])
			{
			}
			else if(pchDes[3] >= 'a' && pchDes[3] <= 'z')
			{
				if(pchDes[3] - pchSrc[3] != 32)
				{
					return pchDes[3] - pchSrc[3];
				}
			}
			else if(pchSrc[3] >= 'a' && pchSrc[3] <= 'z')
			{
				if(pchSrc[3] - pchDes[3] != 32)
				{
					return pchDes[3] - pchSrc[3];
				}
			}
			else
			{
				return pchDes[3] - pchSrc[3];
			}
		}
	}
	pchDes = (char*)(pDes+i);
	pchSrc = (char*)(pSrc+i);
	for(i =0;i < 4;i++)
	{
		if(pchSrc[i] == 0)
		{
			return pchDes[i] - pchSrc[i];
		}
		else if(pchSrc[i] == pchDes[i])
		{
			continue;
		}
		else
		{
			if(pchDes[i] >= 'a' && pchDes[i] <= 'z')
			{
				if(pchDes[i] - pchSrc[i] != 32)
				{
					return pchDes[i] - pchSrc[i];
				}
			}
			else if(pchSrc[i] >= 'a' && pchSrc[i] <= 'z')
			{
				if(pchSrc[i] - pchDes[i] != 32)
				{
					return pchDes[i] - pchSrc[i];
				}
			}
			else
			{
				return pchDes[i] - pchSrc[i];
			}
		}
	}
	return 0;
}

int CMFString::Replace(const char* chOld, const char* chNew)
{
	BOOL bFound = FALSE;
	char * lpNewBuf;
	int i,j,k,nLen, nOldLen, nNewLen, nNew, nActualNewLen;
	nLen = length();
	nOldLen = strlen(chOld);
	nNewLen = strlen(chNew);
	//加2个字节放字符串结束符
	if(nNewLen > nOldLen)
		nNew = nLen * nNewLen / nOldLen + 2;
	else
		nNew = nLen + 2;
	lpNewBuf = new char[nNew];
	const char* chSrc = c_str();
	nActualNewLen = nLen;
	for(i = 0,j = 0;i < nLen;i++,j++)
	{
		if(chSrc[i] == chOld[0])
		{
			for(k = 1;k < nOldLen;k++)
			{
				if(chSrc[i+k] != chOld[k])
					break;
			}
			if(k >= nOldLen)
			{
				nActualNewLen = nActualNewLen - nOldLen + nNewLen;
				for(k = 0;k < nNewLen;k++)
				{
					lpNewBuf[j+k] = chNew[k];
				}
				j = j + nNewLen - 1;
				i = i + nOldLen - 1;
				bFound = TRUE;
			}
			else
			{
				lpNewBuf[j] = chSrc[i];
			}
		}
		else
		{
			lpNewBuf[j] = chSrc[i];
		}
	}
	lpNewBuf[j] = 0;

	if(bFound)
	{
		assign(lpNewBuf, nActualNewLen);
	}
	delete [] lpNewBuf;
	return 0;
}

void CMFString::MakeUpper()
{
	int nLen = length();
	const char* pData = c_str();
	for(int i = 0; i < nLen; i++)
	{
		if(pData[i] >= 'a' && pData[i] <= 'z')
		{

			replace(i,1, 1,pData[i]-32);	
		}
	}
}

void CMFString::MakeLower()
{
	int nLen = length();
	const char* pData = c_str();
	for(int i = 0; i < nLen; i++)
	{
		if(pData[i] >= 'A' && pData[i] <= 'Z')
		{

			replace(i,1, 1,pData[i]+32);	
		}
	}
}
