﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "../Include/SobeyMemBaseExport.h"
#include "MemDBRecordset.h"
#include "Date.h"

#define RECORD_DELETE 1
#define RECORD_INSERT 2
#define RECORD_UPDATE 3

CMemDBRecordset::CMemDBRecordset()
{
	m_lpBuffer				= NULL;
	m_nRowNum			    = 0;
	m_nFieldNum				= 0;
	m_lpFieldInfo			= NULL;
	m_lpRecordset			= NULL;
	m_bAutoRelease			= TRUE;
	m_bRecordsetCanModify	= FALSE;
	m_bDatabaseType			= MF_DATABASE_MEMDB;
	m_nQueryRowNum			= 0;
	m_nCurrentRowNo			= 0;
	m_nInsertDataID			= -1;			//插入DataID为负数
	m_lpCurrentRecord		= NULL;
	memset(&m_stUpdateReocrdsetBson, 0, sizeof(UPDATERECORDSETPLANBSON));
}

CMemDBRecordset::~CMemDBRecordset(void)
{
	Free();
}

WCHAR* CMemDBRecordset::ConvertNumber2Char(long long nValue)
{
	WCHAR* pString;
	char lpszValue[32];

	memset(lpszValue, 0, sizeof(lpszValue));
	sprintf(lpszValue, "%lld", nValue);

	pString = ETConvertWCHAR(lpszValue, strlen(lpszValue));
	return pString;
}

WCHAR* CMemDBRecordset::ConvertNumber2Char(double dblValue)
{
	WCHAR* pString;
	char lpszValue[32];

	memset(lpszValue, 0, sizeof(lpszValue));
	sprintf(lpszValue, "%.4f", dblValue);

	pString = ETConvertWCHAR(lpszValue, strlen(lpszValue));
	return pString;
}

WCHAR* CMemDBRecordset::ConvertDate(DATE dtValue)
{
	WCHAR* pString;
	char lpszValue[32];
	memset(lpszValue, 0, sizeof(lpszValue));
#ifdef WIN32
	SYSTEMTIME sysTime;
	if(!VariantTimeToSystemTime(dtValue, &sysTime))
	{
		return NULL;
	}
	sprintf(lpszValue, "%04d-%02d-%02d %02d:%02d:%02d",sysTime.wYear,sysTime.wMonth,sysTime.wDay,sysTime.wHour,sysTime.wMinute,sysTime.wSecond);
#else
	tm* pTime;
	if(!VariantTimeToSystemTime(dtValue, pTime))
	{
		return NULL;
	}
	sprintf(lpszValue, "%d-%02d-%02d %02d:%02d:%02d",pTime->tm_year+1900,pTime->tm_mon+1, pTime->tm_mday, pTime->tm_hour, pTime->tm_min, pTime->tm_sec);
#endif
	pString = ETConvertWCHAR(lpszValue, 31);
	return pString;
}

WCHAR* CMemDBRecordset::ConvertBinary(LPBYTE pValue, int nLen)
{
	WCHAR* pString;
	char* lpszValue;

	lpszValue = new char[nLen*2+1];
	if(lpszValue == NULL)
	{
		return NULL;
	}
	HexConvertChar(pValue, nLen, lpszValue);
	if(nLen > 32)
	{
		lpszValue[32] = 0;
	}
	pString = ETConvertWCHAR(lpszValue, 33);
	delete [] lpszValue;
	lpszValue = NULL;
	return pString;
}

WCHAR* CMemDBRecordset::ConvertStr(char* pValue, int nLen)
{
	WCHAR* pString;
	char* lpszValue;
	lpszValue = new char[nLen];
	strcpy(lpszValue, pValue);

	pString = ETConvertWCHAR(lpszValue, nLen);
	delete [] lpszValue;
	lpszValue = NULL;
	return pString;
}

BOOL CMemDBRecordset::ConvertStr(char* pSrc, WCHAR* pDest, int nLen)
{
	int nSrcLen;
	nSrcLen = strlen(pSrc);
	if(nSrcLen == 0)
	{
		return TRUE;
	}
#ifdef WIN32
	if(!MultiByteToWideChar(CP_UTF8, NULL, pSrc, nSrcLen, pDest, nLen))
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
#else
	if(-1 == mbstowcs(pDest, pSrc, nLen))
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
#endif
}

long long CMemDBRecordset::ConvertWChar2Number(WCHAR* lpszValue)
{
	char pValue[32];
	long long nResult;
	memset(pValue, 0, sizeof(pValue));
#ifdef WIN32
	WideCharToMultiByte(CP_ACP, NULL, lpszValue,  30, pValue, 32, NULL, NULL);
#else
	wcstombs(pValue, lpszValue, 32);
#endif
	nResult = _atoi64(pValue);
	return nResult;
}

double CMemDBRecordset::ConvertWChar2Double(WCHAR* lpszValue)
{
	char pValue[32];
	double dblResult;
	memset(pValue, 0, sizeof(pValue));
#ifdef WIN32
	WideCharToMultiByte(CP_ACP, NULL, lpszValue,  30, pValue, 32, NULL, NULL);
#else
	wcstombs(pValue, lpszValue, 32);
#endif
	dblResult	= atof(pValue);
	return dblResult;
}

int CMemDBRecordset::ConvertWChar2Date(WCHAR* lpszValue, DATE& dtResult)
{
	char pValue[32], pFormat[32] = "YYYY-MM-DD HH24:MI:SS";
	memset(pValue, 0, sizeof(pValue));
#ifdef WIN32
	WideCharToMultiByte(CP_ACP, NULL, lpszValue,  30, pValue, 32, NULL, NULL);
#else
	wcstombs(pValue, lpszValue, 32);
#endif
	return CDate::ToDate(pValue, pFormat, dtResult);
}

char* CMemDBRecordset::ConvertWChar2Str(WCHAR* lpszValue, int& nLen)
{
	char* pValue;
	pValue	 = ConvertToUTF8(lpszValue, nLen);

	return pValue;
}

#ifdef WIN32
char* CMemDBRecordset::ConvertBSTR2Str(BSTR bstrValue, int& nLen)
{
	char* pValue;
	pValue	 = ConvertBSTR2UTF8(bstrValue, nLen);

	return pValue;
}
#endif

int CMemDBRecordset::AnalysisRow(LPBYTE lpRowBuffer, int nRowLen, RECORD& stRecord)
{
	BYTE bFieldNo;
	char* pValueStr;
	long long *pBigIntArray;
	int nLen, i, nFieldLen, nStrLen, nTempLen, nArrayLen, *pIntArray;

	stRecord.Initial(m_nFieldNum);
	nLen = nRowLen;
	
	//去掉长度
	lpRowBuffer += sizeof(int);
	nLen		-= sizeof(int);

	//去掉DataID
	stRecord.m_nDataID = *(long long*)lpRowBuffer;
	nLen				  -= sizeof(long long);
	lpRowBuffer			  += sizeof(long long);
	for(i = 0; i < stRecord.m_nFieldNum; i++)
	{
		if(nLen <= 1)
		{
			//最后一个字节是结束符
			break;				
		}
		//取出Buffer中的字段编号
		bFieldNo = *(BYTE*)lpRowBuffer;
		if(bFieldNo != i)
		{
			//如果字段编号和顺序不匹配(存在空字段时会出现这种情况，则continue)
			continue;			
		}			
		switch(m_lpFieldInfo[i].m_bFieldType)
		{
		case MF_SYS_FIELDTYPE_INT:
			nFieldLen = sizeof(BYTE) + sizeof(int);
			stRecord.m_lpFieldData[i].SetData(*(int*)(lpRowBuffer + sizeof(BYTE)));
			stRecord.m_pFieldStr[i] = ConvertNumber2Char((long long)stRecord.m_lpFieldData[i].m_nValue);
			break;
		case MF_SYS_FIELDTYPE_BIGINT:
			nFieldLen = sizeof(BYTE) + sizeof(long long);
			stRecord.m_lpFieldData[i].SetData(*(long long*)(lpRowBuffer + sizeof(BYTE)));
			stRecord.m_pFieldStr[i] = ConvertNumber2Char(stRecord.m_lpFieldData[i].m_llValue);
			break;
		case MF_SYS_FIELDTYPE_DOUBLE:
			nFieldLen = sizeof(BYTE) + sizeof(double);
			stRecord.m_lpFieldData[i].SetData(*(double*)(lpRowBuffer + sizeof(BYTE)), MF_SYS_FIELDTYPE_DOUBLE);
			stRecord.m_pFieldStr[i] = ConvertNumber2Char(stRecord.m_lpFieldData[i].m_dblValue);
			break;
		case MF_SYS_FIELDTYPE_DATE:
			nFieldLen = sizeof(BYTE) + sizeof(double);
			stRecord.m_lpFieldData[i].SetData(*(double*)(lpRowBuffer + sizeof(BYTE)), MF_SYS_FIELDTYPE_DATE);
			stRecord.m_pFieldStr[i] = ConvertDate(stRecord.m_lpFieldData[i].m_dblValue);
			if(stRecord.m_pFieldStr[i] == NULL)
			{
				return MF_COMMON_INVALID_DATA;
			}
			break;
		case MF_SYS_FIELDTYPE_CHAR:
		case MF_SYS_FIELDTYPE_VARCHAR:
		case MF_SYS_FIELDTYPE_CLOB:
			nStrLen = *(BYTE*)(lpRowBuffer + sizeof(BYTE));
			if(nStrLen == 0)
			{
				nTempLen	= sizeof(BYTE) + sizeof(BYTE);
				nFieldLen	= nStrLen + sizeof(BYTE) + sizeof(BYTE);
				stRecord.m_lpFieldData[i].m_vt = MF_VARDATA_NULL;
			}
			else
			{
				if(nStrLen == 255)
				{
					nTempLen	= sizeof(int) + sizeof(BYTE) + sizeof(BYTE);
					nStrLen		= *(int*)(lpRowBuffer + sizeof(BYTE) + sizeof(BYTE));	
					nFieldLen	= nStrLen + nTempLen;
				}
				else
				{
					nTempLen	= sizeof(BYTE) + sizeof(BYTE);
					nFieldLen	= nStrLen + sizeof(BYTE) + sizeof(BYTE);
				}
				pValueStr = new char[nStrLen];
				memcpy(pValueStr, lpRowBuffer + nTempLen, nStrLen);
				stRecord.m_lpFieldData[i].m_bAutoRelease = TRUE;
				stRecord.m_lpFieldData[i].SetData(pValueStr, nStrLen);
				stRecord.m_pFieldStr[i] = ConvertStr(pValueStr, nStrLen);
			}
			break;	
		case MF_SYS_FIELDTYPE_BLOB:
			nStrLen = *(BYTE*)(lpRowBuffer + sizeof(BYTE));
			if(nStrLen == 255)
			{
				nTempLen	= sizeof(int) + sizeof(BYTE) + sizeof(BYTE);
				nStrLen		= *(int*)(lpRowBuffer + sizeof(BYTE) + sizeof(BYTE));	
				nFieldLen	= nStrLen + sizeof(int) + sizeof(BYTE) + sizeof(BYTE);
			}
			else
			{
				nTempLen	= sizeof(BYTE) + sizeof(BYTE);
				nFieldLen	= nStrLen + sizeof(BYTE) + sizeof(BYTE);
			}
			pValueStr = new char[nStrLen];
			memcpy(pValueStr, lpRowBuffer + nTempLen, nStrLen);
			stRecord.m_lpFieldData[i].m_bAutoRelease = TRUE;
			stRecord.m_lpFieldData[i].SetBinaryData((LPBYTE)pValueStr, nStrLen);
			stRecord.m_pFieldStr[i] = ConvertBinary((LPBYTE)pValueStr, nStrLen);
			break;	
		case MF_SYS_FIELDTYPE_ARRAYINT:
			nArrayLen = *(USHORT*)(lpRowBuffer + sizeof(BYTE));
			pIntArray = new int[nArrayLen];
			memcpy((LPBYTE)pIntArray, lpRowBuffer + sizeof(BYTE) + sizeof(USHORT), nArrayLen*sizeof(int));
			stRecord.m_lpFieldData[i].m_bAutoRelease = TRUE;
			stRecord.m_lpFieldData[i].SetData(pIntArray, nArrayLen);
			nFieldLen = sizeof(BYTE) + sizeof(USHORT) + nArrayLen*sizeof(int);
			break;
		case MF_SYS_FIELDTYPE_ARRAYBIGINT:
			nArrayLen = *(USHORT*)(lpRowBuffer + sizeof(BYTE));
			pBigIntArray = new long long[nArrayLen];
			memcpy((LPBYTE)pBigIntArray, lpRowBuffer + sizeof(BYTE) + sizeof(USHORT), nArrayLen*sizeof(long long));
			stRecord.m_lpFieldData[i].m_bAutoRelease = TRUE;
			stRecord.m_lpFieldData[i].SetData(pBigIntArray, nArrayLen);
			nFieldLen = sizeof(BYTE) + sizeof(USHORT) + nArrayLen*sizeof(long long);
			break;
		}
		lpRowBuffer += nFieldLen;
		nLen -= nFieldLen;
	}
	return MF_OK;
}

int CMemDBRecordset::GetExecuteField(CBaseBson& stBson, LPRECORD lpRecord, LPRECORDHEAD lpRecordHead)
{
	int nRet, i;
	UINT nOffset;
	LPBYTE lpAddr;
	BYTE bFieldNum;
	LPXMLFIELDBSON lpXmlFieldBson;

	bFieldNum = lpRecordHead->m_bFieldNum;

	//分配空间存放字段BSON
	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(bFieldNum*sizeof(XMLFIELDBSON), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	lpRecordHead->m_nFieldOffset = nOffset;
	lpXmlFieldBson = (LPXMLFIELDBSON)lpAddr;
	for(i = 0; i < bFieldNum; i++)			
	{
		lpXmlFieldBson[i].m_bTempNo	= i+1;
		if(lpRecord->m_pFieldModify[i] == 1)
		{
			lpXmlFieldBson[i].m_bModify = 1;
			if(lpRecord->m_lpFieldData[i].m_vt == MF_VARDATA_NULL)
			{
				lpXmlFieldBson[i].m_nFieldDataLen		= 0;
				lpXmlFieldBson[i].m_nFieldDataOffset	= 0;
			}
			else
			{
				//为字段值创建Buffer，并获取字段值   
				lpAddr = NULL;
				nRet = stBson.AllocFromBsonBuffer(lpRecord->m_lpFieldData[i].m_nBufferLen, nOffset, lpAddr);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpXmlFieldBson[i].m_nFieldDataLen		= lpRecord->m_lpFieldData[i].m_nBufferLen;
				lpXmlFieldBson[i].m_nFieldDataOffset	= nOffset;
				switch(m_lpFieldInfo[i].m_bFieldType)
				{
				case MF_SYS_FIELDTYPE_INT:
					lpAddr += sizeof(BYTE);		//存放字段编号
					*((int*)lpAddr) = lpRecord->m_lpFieldData[i].m_nValue;
					break;
				case MF_SYS_FIELDTYPE_BIGINT:
					lpAddr += sizeof(BYTE);
					*((long long*)lpAddr)  = lpRecord->m_lpFieldData[i].m_llValue;
					break;
				case MF_SYS_FIELDTYPE_DOUBLE:
				case MF_SYS_FIELDTYPE_DATE:
					lpAddr += sizeof(BYTE);
					*((double*)lpAddr)  = lpRecord->m_lpFieldData[i].m_dblValue;
					break;
				case MF_SYS_FIELDTYPE_CHAR:
				case MF_SYS_FIELDTYPE_VARCHAR:
				case MF_SYS_FIELDTYPE_CLOB:
					lpAddr += sizeof(BYTE);
					if(lpRecord->m_lpFieldData[i].m_nStrLen < 250)
					{
						*((BYTE*)lpAddr)  = lpRecord->m_lpFieldData[i].m_nStrLen;
						lpAddr += sizeof(BYTE);
					}
					else
					{
						*((BYTE*)lpAddr)  = 255;
						lpAddr += sizeof(BYTE);
						*((int*)lpAddr) = lpRecord->m_lpFieldData[i].m_nStrLen;
						lpAddr += sizeof(int);
					}
					memcpy(lpAddr, lpRecord->m_lpFieldData[i].m_lpszValue, lpRecord->m_lpFieldData[i].m_nStrLen);
					break;
				case MF_SYS_FIELDTYPE_BLOB:
					lpAddr += sizeof(BYTE);
					if(lpRecord->m_lpFieldData[i].m_nStrLen < 250)
					{
						*((BYTE*)lpAddr)  = lpRecord->m_lpFieldData[i].m_nStrLen;
						lpAddr += sizeof(BYTE);
					}
					else
					{
						*((BYTE*)lpAddr)  = 255;
						lpAddr += sizeof(BYTE);
						*((int*)lpAddr) = lpRecord->m_lpFieldData[i].m_nStrLen;
						lpAddr += sizeof(int);
					}
					memcpy(lpAddr, lpRecord->m_lpFieldData[i].m_lpValue, lpRecord->m_lpFieldData[i].m_nStrLen);
					break;
				}
			}
		}
	}
	return MF_OK;
}

//解析结果集，获取MemDB格式的UpdateRecordset执行计划
int CMemDBRecordset::ParseRecordsetMemDB(CBaseBson& stBson, LPEXECUTEPLANBSON& lpExecutePlan)
{
	LPBYTE lpAddr;
	char lpszName[64];
	int nRet, i, nStepNo;
	UINT nOffset, nAddrID;
	LPRECORDHEAD lpRecordHead;
	LPXMLFIELDINFO lpFieldInfo;
	LPOBJECTNAMEBSON lpObjectNameBson;
	LPUPDATERECORDSETPLANBSON lpUpdateRecordsetPlan;

	nRet = stBson.AllocFromBsonBuffer(lpExecutePlan, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nRet = stBson.AllocFromBsonBuffer(lpUpdateRecordsetPlan, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlan->m_nCommandOffset = nOffset;

	//1.获取表名
	memset(lpszName, 0, sizeof(lpszName));
#ifdef WIN32
	WideCharToMultiByte(CP_ACP, NULL, m_lpFieldInfo[0].m_lpszObjectName,  32, lpszName, 64, NULL, NULL);
#else
	wcstombs(lpszName, m_lpFieldInfo[0].m_lpszObjectName, 64);
#endif
	lpAddr	 = NULL;
	nRet	 = stBson.AllocFromBsonBuffer(sizeof(OBJECTNAMEBSON)+ 32, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpUpdateRecordsetPlan->m_nObjectNameOffset = nOffset;
	lpObjectNameBson						   = (LPOBJECTNAMEBSON)lpAddr;
	lpObjectNameBson->m_bLen				   = 32;
	strcpy((char *)lpObjectNameBson->m_pObjectName, lpszName);

	//2.获取字段信息
	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(m_nFieldNum*sizeof(XMLFIELDINFO), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpFieldInfo = (LPXMLFIELDINFO)lpAddr;
	lpUpdateRecordsetPlan->m_nFieldInfoOffset = nOffset;

	lpUpdateRecordsetPlan->m_nFieldNum = m_nFieldNum;
	for(i = 0; i < m_nFieldNum; i++)
	{
		lpAddr = NULL;
		nRet = stBson.AllocFromBsonBuffer(32, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		memset(lpszName, 0, sizeof(lpszName));
#ifdef WIN32
		WideCharToMultiByte(CP_ACP, NULL, m_lpFieldInfo[i].m_lpszTitle,  32, lpszName, 64, NULL, NULL);
#else
		wcstombs(lpszName, m_lpFieldInfo[i].m_lpszTitle, 64);
#endif
		strcpy((char *)lpAddr, lpszName);
		lpFieldInfo[i].m_nFieldNameOffset	= nOffset;
		lpFieldInfo[i].m_bFieldNameLen		= 32;
		lpFieldInfo[i].m_bTempNo			= i+1;
	}

	//3.获取结果集更新操作的所有记录条数(也就是步骤数)
	for(i = 0; i < m_nQueryRowNum; i++)
	{
		if(m_lpRecordset[i].m_bRecordStatus == RECORD_DELETE)
		{
			lpUpdateRecordsetPlan->m_nDeleteStepNum++;
		}
		else if(m_lpRecordset[i].m_bRecordStatus == RECORD_UPDATE)
		{
			lpUpdateRecordsetPlan->m_nUpdateStepNum++;
		}
	}
	for(i = 0; i < m_vecInsertRecord.size(); i++)
	{
		if(m_vecInsertRecord[i]->m_bRecordStatus == RECORD_INSERT)
		{
			lpUpdateRecordsetPlan->m_nInsertStepNum++;
		}
	}

	//4.分配空间存放记录信息
	nStepNo = 1;
	if(lpUpdateRecordsetPlan->m_nDeleteStepNum != 0)
	{
		//创建Delete操作步骤
		lpUpdateRecordsetPlan->m_nDeleteStepNo = nStepNo;
		for(i = 0; i < m_nQueryRowNum; i++)
		{
			if(m_lpRecordset[i].m_bRecordStatus == RECORD_DELETE)
			{
				nRet = stBson.AllocRecord(lpRecordHead, nAddrID);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				if(lpUpdateRecordsetPlan->m_nRecordAddrID == 0)
				{
					lpUpdateRecordsetPlan->m_nRecordAddrID = nAddrID;
				}
				lpRecordHead->m_bType   = MF_EXECUTE_STEP_DELETEDATA;
				lpRecordHead->m_nDataID = m_lpRecordset[i].m_nDataID;
				nStepNo++;
			}
		}
	}

	//执行Update操作
	if(lpUpdateRecordsetPlan->m_nUpdateStepNum != 0)
	{
		lpUpdateRecordsetPlan->m_nUpdateStepNo = nStepNo + 1;
		//创建Update操作步骤
		for(i = 0; i < m_nQueryRowNum; i++)
		{
			if(m_lpRecordset[i].m_bRecordStatus == RECORD_UPDATE)
			{
				nRet = stBson.AllocRecord(lpRecordHead, nAddrID);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				if(lpUpdateRecordsetPlan->m_nRecordAddrID == 0)
				{
					lpUpdateRecordsetPlan->m_nRecordAddrID = nAddrID;
				}

				lpRecordHead->m_bType	  = MF_EXECUTE_STEP_UPDATEDATA;
				lpRecordHead->m_nDataID   = m_lpRecordset[i].m_nDataID;
				lpRecordHead->m_bFieldNum = (BYTE)m_nFieldNum;
				//获取更新字段
				nRet					  = GetExecuteField(stBson, &m_lpRecordset[i], lpRecordHead);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				nStepNo++;
			}
		}
	}

	//执行Insert操作
	lpUpdateRecordsetPlan->m_nInsertStepNo = nStepNo + 1;
	for(i = 0; i < m_vecInsertRecord.size(); i++)
	{
		if(m_vecInsertRecord[i]->m_bRecordStatus != RECORD_INSERT)
		{
			continue;
		}

		nRet = stBson.AllocRecord(lpRecordHead, nAddrID);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(lpUpdateRecordsetPlan->m_nRecordAddrID == 0)
		{
			lpUpdateRecordsetPlan->m_nRecordAddrID = nAddrID;
		}

		lpRecordHead->m_bType	  = MF_EXECUTE_STEP_INSERTDATA;
		lpRecordHead->m_bFieldNum = (BYTE)m_nFieldNum;
		nRet					  = GetExecuteField(stBson, m_vecInsertRecord[i], lpRecordHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		//获取插入字段
		nStepNo++;
	}
	lpUpdateRecordsetPlan->m_nExecuteStepNum = lpUpdateRecordsetPlan->m_nDeleteStepNum + lpUpdateRecordsetPlan->m_nUpdateStepNum + lpUpdateRecordsetPlan->m_nInsertStepNum;

	//给缓存片段加上偏移
	stBson.SetSectionOffset();

	lpExecutePlan->m_nType				 = MF_EXECUTEPLAN_CMDTYPE_UPDATERECORDSET;
	lpExecutePlan->m_nDefaultSectionSize = MF_BUFFERSECTION_SIZE;
	lpExecutePlan->m_nClientSectionNum	 = stBson.GetBufferSectionNum();
	lpExecutePlan->m_nClientBsonDataSize = stBson.GetBsonDataSize();
	lpExecutePlan->m_nSectionStartOffset = stBson.GetBsonDataSize(); 
	lpExecutePlan->m_nBsonDataSize		 = stBson.GetExecutePlanDataSize();					//对于UpdateRecordset来说BsonDataSize的大小为总大小
	lpExecutePlan->m_nTotalDataSize      = stBson.GetExecutePlanDataSize();
	lpExecutePlan->m_nFreeSectionAddrID  = stBson.GetFreeSectionAddrID();
	lpExecutePlan->m_bWriteLog			 = 1;
	return MF_OK;
}

//设置列
int CMemDBRecordset::SetFieldValue(int nFieldNo, WCHAR* lpszValue)
{
	DATE dtDate;
	char* pBuffer;
	int nLen, nRet;

	nLen = 0;
	if(nFieldNo >= m_lpCurrentRecord->m_nFieldNum)
	{
		//未找到相应字段，失败
		return MF_UPDATERECORDSET_FIELDNOTEXIT_ERROR;
	}
	if(!m_bRecordsetCanModify)
	{
		return MF_UPDATERECORDSET_RECORDSETCANNOTMODIFY_ERROR;
	}
	if(m_lpFieldInfo[nFieldNo].m_bFieldNameType != MF_PARAMETER_FIELDTYPE_ORIGINAL)
	{
		//不是原始字段，不能修改
		return MF_UPDATERECORDSET_FIELDCANNOTMODIFY_ERROR;
	}

	if(lpszValue == NULL || wcslen(lpszValue) == 0)
	{
		m_lpCurrentRecord->m_lpFieldData[nFieldNo].m_vt = MF_VARDATA_NULL;
	}
	else
	{
		switch(m_lpFieldInfo[nFieldNo].m_bFieldType)
		{
		case MF_SYS_FIELDTYPE_INT:
			m_lpCurrentRecord->m_lpFieldData[nFieldNo].SetData((int)ConvertWChar2Number(lpszValue));
			break;
		case MF_SYS_FIELDTYPE_BIGINT:
			m_lpCurrentRecord->m_lpFieldData[nFieldNo].SetData((long long)ConvertWChar2Number(lpszValue));
			break;
		case MF_SYS_FIELDTYPE_DOUBLE:
			m_lpCurrentRecord->m_lpFieldData[nFieldNo].SetData(ConvertWChar2Double(lpszValue), MF_VARDATA_DOUBLE);
			break;
		case MF_SYS_FIELDTYPE_DATE:
			nRet = ConvertWChar2Date(lpszValue, dtDate);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			m_lpCurrentRecord->m_lpFieldData[nFieldNo].SetData(dtDate, MF_VARDATA_DATE);
			break;
		case MF_SYS_FIELDTYPE_CHAR:
		case MF_SYS_FIELDTYPE_VARCHAR:
		case MF_SYS_FIELDTYPE_CLOB:
			pBuffer = ConvertWChar2Str(lpszValue, nLen);
			m_lpCurrentRecord->m_lpFieldData[nFieldNo].AttachBuffer(MF_VARDATA_STRING, pBuffer, nLen);
			break;	
		default:
			return MF_COMMON_INVALID_FIELDTYPE;			
		}
	}

	m_lpCurrentRecord->m_pFieldModify[nFieldNo] = 1;
	if(m_lpCurrentRecord->m_bRecordStatus == 0)
	{
		m_lpCurrentRecord->m_bRecordStatus = RECORD_UPDATE;
	}
	return MF_OK;
}

//释放结果集资源函数
void CMemDBRecordset::Free()
{	
	m_nQueryRowNum	= 0;		
	m_nFieldNum		= 0;

	if(m_lpFieldInfo != NULL)
	{
		delete [] m_lpFieldInfo;
		m_lpFieldInfo   = NULL;
	}
	if(m_lpRecordset != NULL)
	{
		delete [] m_lpRecordset;
		m_lpRecordset = NULL;
	}	
	if(m_lpBuffer != NULL)
	{
		if(m_bAutoRelease)
		{
			delete [] m_lpBuffer;
		}
		m_lpBuffer = NULL;
	}
	m_bAutoRelease  = FALSE;

	for(int i = 0; i < m_vecInsertRecord.size(); i++)
	{
		delete m_vecInsertRecord[i];
	}
	m_vecInsertRecord.clear();

	m_lpCurrentRecord = NULL;
}

//获取结果集字段名
wchar_t* CMemDBRecordset::FieldName(int nIndex)
{
	if(nIndex < 0 || nIndex >= m_nFieldNum)
	{
		return NULL;
	}

	switch(m_lpFieldInfo[nIndex].m_bFieldNameType)
	{
	case MF_PARAMETER_FIELDTYPE_ORIGINAL:
	case MF_PARAMETER_FIELDTYPE_COMMFUN:
	case MF_PARAMETER_FIELDTYPE_AGGREFUN:
	case MF_PARAMETER_FIELDTYPE_EXPRESSION:
		//原始字段形式
		if(m_lpFieldInfo[nIndex].m_lpszRsName[0] != 0)
		{
			return m_lpFieldInfo[nIndex].m_lpszRsName;
		}
		else
		{
			return m_lpFieldInfo[nIndex].m_lpszTitle;
		}
	}
	return NULL;
}

//获取结果集字段类型
MF_SYS_FIELDTYPE CMemDBRecordset::FieldType(int nIndex)
{
	if(nIndex < 0 || nIndex >= m_nFieldNum)
	{
		return MF_SYS_FIELDTYPE_UNKNOWN;
	}
	return m_lpFieldInfo[nIndex].m_bFieldType;
}

//向结果集中添加一行
int CMemDBRecordset::AddNew(long long &nGetDataId)
{
	LPRECORD lpRecord;
	
	if(!m_bRecordsetCanModify)
	{
		return MF_UPDATERECORDSET_RECORDSETCANNOTMODIFY_ERROR;
	}

	lpRecord = new RECORD;
	if(lpRecord == NULL)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	m_vecInsertRecord.push_back(lpRecord);

	lpRecord->Initial(m_nFieldNum);
	lpRecord->m_nDataID		= m_nInsertDataID;
	nGetDataId				= m_nInsertDataID;

	m_lpCurrentRecord		= lpRecord;
	m_lpCurrentRecord->m_bRecordStatus = RECORD_INSERT;

	m_nInsertDataID--;
	m_nRowNum++;
	return MF_OK;
}

//删除结果集中的当前行
int CMemDBRecordset::Delete()
{
	if(!m_bRecordsetCanModify)
	{
		return MF_UPDATERECORDSET_RECORDSETCANNOTMODIFY_ERROR;
	}

	m_lpCurrentRecord->m_bRecordStatus = RECORD_DELETE;
	m_nRowNum--;
	return MF_OK;
}

//判断结果集中当前行是否第一行
BOOL CMemDBRecordset::bof()
{
	if(m_nRowNum == 0)
	{
		return TRUE;
	}
	if(m_nCurrentRowNo == 0)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

//判断结果集中当前行是否最后一行后一行
BOOL CMemDBRecordset::eof()
{
	if(m_nRowNum == 0)
	{
		return TRUE;
	}
	if(m_nCurrentRowNo >= m_nRowNum)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

//设置结果集中的第一行为当前行
int CMemDBRecordset::MoveFirst()
{
	m_nCurrentRowNo = 0;
	if(m_nRowNum == 0)
	{
		m_lpCurrentRecord = NULL;
	}
	else
	{
		m_lpCurrentRecord = &m_lpRecordset[0];
	}
	return MF_OK;
}

//设置结果集中的下一行为当前行
int CMemDBRecordset::MoveNext()
{
	m_nCurrentRowNo++;
	if(m_nCurrentRowNo >= m_nRowNum)
	{
		m_nCurrentRowNo = m_nRowNum;
		m_lpCurrentRecord = NULL;					//溢出
	}
	else if(m_nCurrentRowNo >= m_nQueryRowNum)
	{
		m_lpCurrentRecord = m_vecInsertRecord[m_nCurrentRowNo - m_nQueryRowNum];
	}
	else
	{
		m_lpCurrentRecord = &m_lpRecordset[m_nCurrentRowNo];
	}
	return MF_OK;
}

//设置结果集中的前一行为当前行
int CMemDBRecordset::MovePrevious()
{
	m_nCurrentRowNo--;
	if(m_nCurrentRowNo < 0)
	{
		m_nCurrentRowNo = 0;
		m_lpCurrentRecord = NULL;				 //溢出
	}
	else if(m_nCurrentRowNo >= m_nQueryRowNum)
	{
		m_lpCurrentRecord = m_vecInsertRecord[m_nCurrentRowNo - m_nQueryRowNum];
	}
	else
	{
		m_lpCurrentRecord = &m_lpRecordset[m_nCurrentRowNo];
	}
	return MF_OK;
}

//设置结果集中的最后一行为当前行
int CMemDBRecordset::MoveLast()
{
	m_nCurrentRowNo = m_nRowNum - 1;
	if(m_nRowNum == 0)
	{
		m_lpCurrentRecord = NULL;
	}
	else if(m_nRowNum > m_nQueryRowNum)
	{
		m_lpCurrentRecord = m_vecInsertRecord[m_nRowNum - m_nQueryRowNum - 1];
	}
	else 
	{
		m_lpCurrentRecord = &m_lpRecordset[m_nRowNum - 1];
	}
	return MF_OK;
}

//设置给定的DataID行为当前行
int CMemDBRecordset::SetCurrentRow(long long nDataID)
{
	int i;
	if(nDataID < 0)
	{
		//插入操作
		for(i = 0; i < m_vecInsertRecord.size(); i++)
		{
			if(m_vecInsertRecord[i]->m_nDataID == nDataID)
			{
				m_lpCurrentRecord = m_vecInsertRecord[i];
				break;
			}
		}
	}
	else
	{
		for(i = 0; i < m_nQueryRowNum; i++)
		{
			if(m_lpRecordset[i].m_nDataID == nDataID)
			{
				m_lpCurrentRecord = &m_lpRecordset[i];
				break;
			}
		}
	}
	return MF_OK;
}

int CMemDBRecordset::SetCurrentRow(int nRowNo)
{
	if(nRowNo < m_nQueryRowNum)
	{
		m_lpCurrentRecord = &m_lpRecordset[nRowNo];
	}
	else if(nRowNo < m_nQueryRowNum + m_vecInsertRecord.size())
	{
		m_lpCurrentRecord = m_vecInsertRecord[nRowNo - m_nQueryRowNum];
	}
	else
	{
		return MF_FAILED;
	}
	return MF_OK;
}

//获取结果集中当前行的DataID
int CMemDBRecordset::GetDataID(long long &llDataID)
{
	llDataID = m_lpCurrentRecord->m_nDataID;
	return MF_OK;
}

//获取结果集中当前行指定列的值(32位整数)
int CMemDBRecordset::FieldValue(int nIndex, int &nValue)
{
	if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_BIGINT)
	{
		if((m_lpCurrentRecord->m_lpFieldData[nIndex].m_llValue & 0X7FFFFFFF00000000) == 0)
		{
			nValue = (int)m_lpCurrentRecord->m_lpFieldData[nIndex].m_llValue;
		}
		else
		{
			nValue = (int)m_lpCurrentRecord->m_lpFieldData[nIndex].m_llValue;
			return MF_FAILED;
		}
	}
	else if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_INT)
	{
		nValue = m_lpCurrentRecord->m_lpFieldData[nIndex].m_nValue;
	}
	else if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_DOUBLE)
	{
		nValue = (int)m_lpCurrentRecord->m_lpFieldData[nIndex].m_dblValue;
	}
	else if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_CHAR || m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_VARCHAR || m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_CLOB)
	{
		char * lpValue;
		int i, nDotCount, nCharCount;
		//判断一下是不是数字
		nDotCount = 0;
		nCharCount = 0;
		lpValue = m_lpCurrentRecord->m_lpFieldData[nIndex].m_lpszValue;
		for(i = 0;lpValue[i] != 0;i++)
		{
			if(lpValue[i] >= '0' && lpValue[i] <= '9')
			{
			}
			else if(lpValue[i] == ',')
			{
			}
			else if(lpValue[i] == '.')
			{
				nDotCount++;
				if(nDotCount > 1)
				{
					return MF_FAILED;
				}
			}
			else if((lpValue[i] >= 'A' && lpValue[i] <= 'F') || (lpValue[i] >= 'a' && lpValue[i] <= 'f'))
			{
				nCharCount++;
			}
			else
			{
				return MF_FAILED;
			}
		}
		if(nCharCount > 0)
		{
			return MF_FAILED;
		}
		else
		{
			nValue = atoi(lpValue);
		}
	}
	else
	{
		return MF_FAILED;
	}

	return MF_OK;
}

//获取结果集中当前行指定列的值(64位整数)
int CMemDBRecordset::FieldValue(int nIndex, __int64 &nValue)
{
	if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_BIGINT)
	{	
		nValue = m_lpCurrentRecord->m_lpFieldData[nIndex].m_llValue;
	}
	else if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_INT)
	{
		nValue = m_lpCurrentRecord->m_lpFieldData[nIndex].m_nValue;
	}
	else if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_DOUBLE)
	{
		nValue = (__int64)m_lpCurrentRecord->m_lpFieldData[nIndex].m_dblValue;
	}
	else if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_CHAR || m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_VARCHAR || m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_CLOB)
	{
		char * lpValue;
		int i, nDotCount, nCharCount;
		//判断一下是不是数字
		nDotCount = 0;
		nCharCount = 0;
		lpValue = m_lpCurrentRecord->m_lpFieldData[nIndex].m_lpszValue;
		for(i = 0;lpValue[i] != 0;i++)
		{
			if(lpValue[i] >= '0' && lpValue[i] <= '9')
			{
			}
			else if(lpValue[i] == ',')
			{
			}
			else if(lpValue[i] == '.')
			{
				nDotCount++;
				if(nDotCount > 1)
				{
					return MF_FAILED;
				}
			}
			else if((lpValue[i] >= 'A' && lpValue[i] <= 'F') || (lpValue[i] >= 'a' && lpValue[i] <= 'f'))
			{
				nCharCount++;
			}
			else
			{
				return MF_FAILED;
			}
		}
		if(nCharCount > 0)
		{
			return MF_FAILED;
		}
		else
		{
			nValue = _atoi64(lpValue);
		}
	}
	else
	{
		return MF_FAILED;
	}
	
	return MF_OK;
}

//获取结果集中当前行指定列的值(浮点数)
int CMemDBRecordset::FieldValue(int nIndex, double &dblValue)
{
	if(m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_DOUBLE && m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_DATE)
	{	
		return MF_FAILED;
	}
	dblValue = m_lpCurrentRecord->m_lpFieldData[nIndex].m_dblValue;
	return MF_OK;
}

//获取结果集中当前行指定列的值(字符串数)
int CMemDBRecordset::FieldValue(int nIndex, char* &pValue)
{
	if(m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_CHAR && m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_VARCHAR && m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_CLOB)
	{	
		return MF_FAILED;
	}
	pValue = m_lpCurrentRecord->m_lpFieldData[nIndex].m_lpszValue;
	return MF_OK;
}

int CMemDBRecordset::FieldValue(int nIndex, wchar_t* &pValue)
{
	pValue = m_lpCurrentRecord->FieldStr(nIndex);
	return MF_OK;
}

//获取结果集中当前行指定列的值(字符串数)
int CMemDBRecordset::FieldValue(int nIndex, string &strValue)
{
	if(m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_CHAR && m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_VARCHAR && m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_CLOB)
	{	
		return MF_FAILED;
	}
	strValue = UTF8ConvertASC(m_lpCurrentRecord->m_lpFieldData[nIndex].m_lpszValue);
	
	return MF_OK;
}

//获取结果集中当前行指定列的值(二进制数)
int CMemDBRecordset::FieldValue(int nIndex, LPBYTE &lpValue, int &nSize)
{
	if(m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_BLOB)
	{	
		return MF_FAILED;
	}
	lpValue = m_lpCurrentRecord->m_lpFieldData[nIndex].m_lpValue;
	return MF_OK;
}

//设置结果集中当前行指定列的值(32位整数)
int CMemDBRecordset::SetField(int nIndex, int nValue)
{
	if(nIndex >= m_lpCurrentRecord->m_nFieldNum)
	{
		//未找到相应字段，失败
		return MF_UPDATERECORDSET_FIELDNOTEXIT_ERROR;
	}
	if(!m_bRecordsetCanModify)
	{
		return MF_UPDATERECORDSET_RECORDSETCANNOTMODIFY_ERROR;
	}
	if(m_lpFieldInfo[nIndex].m_bFieldNameType != MF_PARAMETER_FIELDTYPE_ORIGINAL)
	{
		//不是原始字段，不能修改
		return MF_UPDATERECORDSET_FIELDCANNOTMODIFY_ERROR;
	}
	if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_INT)
	{
		m_lpCurrentRecord->m_pFieldModify[nIndex]  = 1;
		m_lpCurrentRecord->m_lpFieldData[nIndex].SetData(nValue);
	}
	else if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_BIGINT)
	{
		m_lpCurrentRecord->m_pFieldModify[nIndex]  = 1;
		m_lpCurrentRecord->m_lpFieldData[nIndex].SetData((long long)nValue);
	}
	else
	{	
		return MF_FAILED;
	}
	
	if(m_lpCurrentRecord->m_bRecordStatus == 0)
	{
		m_lpCurrentRecord->m_bRecordStatus = RECORD_UPDATE;
	}
	return MF_OK;
}

//设置结果集中当前行指定列的值(64位整数)
int CMemDBRecordset::SetField(int nIndex, __int64 nValue)
{
	if(nIndex >= m_lpCurrentRecord->m_nFieldNum)
	{
		//未找到相应字段，失败
		return MF_UPDATERECORDSET_FIELDNOTEXIT_ERROR;
	}
	if(!m_bRecordsetCanModify)
	{
		return MF_UPDATERECORDSET_RECORDSETCANNOTMODIFY_ERROR;
	}
	if(m_lpFieldInfo[nIndex].m_bFieldNameType != MF_PARAMETER_FIELDTYPE_ORIGINAL)
	{
		//不是原始字段，不能修改
		return MF_UPDATERECORDSET_FIELDCANNOTMODIFY_ERROR;
	}

	if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_INT)
	{
		if(nValue > INT_MAX || nValue < INT_MIN)
		{
			return MF_FAILED;
		}
		m_lpCurrentRecord->m_pFieldModify[nIndex]  = 1;
		m_lpCurrentRecord->m_lpFieldData[nIndex].SetData((int)nValue);
	}
	else if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_BIGINT)
	{
		m_lpCurrentRecord->m_pFieldModify[nIndex]  = 1;
		m_lpCurrentRecord->m_lpFieldData[nIndex].SetData(nValue);
	}
	else
	{	
		return MF_FAILED;
	}

	if(m_lpCurrentRecord->m_bRecordStatus == 0)
	{
		m_lpCurrentRecord->m_bRecordStatus = RECORD_UPDATE;
	}
	return MF_OK;
}

//设置结果集中当前行指定列的值(浮点数)
int CMemDBRecordset::SetField(int nIndex, double dblValue)
{
	if(nIndex >= m_lpCurrentRecord->m_nFieldNum)
	{
		//未找到相应字段，失败
		return MF_UPDATERECORDSET_FIELDNOTEXIT_ERROR;
	}
	if(!m_bRecordsetCanModify)
	{
		return MF_UPDATERECORDSET_RECORDSETCANNOTMODIFY_ERROR;
	}
	if(m_lpFieldInfo[nIndex].m_bFieldNameType != MF_PARAMETER_FIELDTYPE_ORIGINAL)
	{
		//不是原始字段，不能修改
		return MF_UPDATERECORDSET_FIELDCANNOTMODIFY_ERROR;
	}
	if(m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_DOUBLE && m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_DATE)
	{	
		return MF_FAILED;
	}

	m_lpCurrentRecord->m_pFieldModify[nIndex]  = 1;

	if(m_lpFieldInfo[nIndex].m_bFieldType == MF_SYS_FIELDTYPE_DOUBLE)
	{
		m_lpCurrentRecord->m_lpFieldData[nIndex].SetData(dblValue, MF_VARDATA_DOUBLE);
	}
	else
	{
		m_lpCurrentRecord->m_lpFieldData[nIndex].SetData(dblValue, MF_VARDATA_DATE);
	}

	if(m_lpCurrentRecord->m_bRecordStatus == 0)
	{
		m_lpCurrentRecord->m_bRecordStatus = RECORD_UPDATE;
	}
	return MF_OK;
}	

//设置结果集中当前行指定列的值(字符串数)
int CMemDBRecordset::SetField(int nIndex, char* lpValue)
{
	if(nIndex >= m_lpCurrentRecord->m_nFieldNum)
	{
		//未找到相应字段，失败
		return MF_UPDATERECORDSET_FIELDNOTEXIT_ERROR;
	}
	if(!m_bRecordsetCanModify)
	{
		return MF_UPDATERECORDSET_RECORDSETCANNOTMODIFY_ERROR;
	}
	if(m_lpFieldInfo[nIndex].m_bFieldNameType != MF_PARAMETER_FIELDTYPE_ORIGINAL)
	{
		//不是原始字段，不能修改
		return MF_UPDATERECORDSET_FIELDCANNOTMODIFY_ERROR;
	}
	if(m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_CHAR && m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_VARCHAR && m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_CLOB)
	{	
		return MF_FAILED;
	}

	m_lpCurrentRecord->m_pFieldModify[nIndex]  = 1;
	m_lpCurrentRecord->m_lpFieldData[nIndex].SetData(lpValue, strlen(lpValue));

	if(m_lpCurrentRecord->m_bRecordStatus == 0)
	{
		m_lpCurrentRecord->m_bRecordStatus = RECORD_UPDATE;
	}
	return MF_OK;
}

//设置结果集中当前行指定列的值(字符串数)
int CMemDBRecordset::SetField(int nIndex, wchar_t* wlpValue)
{
	return SetFieldValue(nIndex, wlpValue);
}

//设置结果集中当前行指定列的值(二进制数)
int CMemDBRecordset::SetField(int nIndex, LPBYTE lpValue, int nSize)
{
	if(nIndex >= m_lpCurrentRecord->m_nFieldNum)
	{
		//未找到相应字段，失败
		return MF_UPDATERECORDSET_FIELDNOTEXIT_ERROR;
	}
	if(!m_bRecordsetCanModify)
	{
		return MF_UPDATERECORDSET_RECORDSETCANNOTMODIFY_ERROR;
	}
	if(m_lpFieldInfo[nIndex].m_bFieldNameType != MF_PARAMETER_FIELDTYPE_ORIGINAL)
	{
		//不是原始字段，不能修改
		return MF_UPDATERECORDSET_FIELDCANNOTMODIFY_ERROR;
	}
	if(m_lpFieldInfo[nIndex].m_bFieldType != MF_SYS_FIELDTYPE_BLOB)
	{
		return MF_FAILED;		//字段类型不匹配
	}

	m_lpCurrentRecord->m_pFieldModify[nIndex]  = 1;
	m_lpCurrentRecord->m_lpFieldData[nIndex].SetBinaryData(lpValue, nSize);

	if(m_lpCurrentRecord->m_bRecordStatus == 0)
	{
		m_lpCurrentRecord->m_bRecordStatus = RECORD_UPDATE;
	}
	return MF_OK;
}

#ifdef WIN32
//设置结果集中当前行指定列的值(BSTR)
int CMemDBRecordset::SetField(int nIndex, const BSTR& bstrValue, int nLen)
{
	int nRet;
	DATE dtDate;
	char* pBuffer;
	if(nIndex >= m_lpCurrentRecord->m_nFieldNum)
	{
		//未找到相应字段，失败
		return MF_UPDATERECORDSET_FIELDNOTEXIT_ERROR;
	}
	if(!m_bRecordsetCanModify)
	{
		return MF_UPDATERECORDSET_RECORDSETCANNOTMODIFY_ERROR;
	}
	if(m_lpFieldInfo[nIndex].m_bFieldNameType != MF_PARAMETER_FIELDTYPE_ORIGINAL)
	{
		//不是原始字段，不能修改
		return MF_UPDATERECORDSET_FIELDCANNOTMODIFY_ERROR;
	}
	
	switch(m_lpFieldInfo[nIndex].m_bFieldType)
	{
	case MF_SYS_FIELDTYPE_INT:
		m_lpCurrentRecord->m_lpFieldData[nIndex].SetData((int)ConvertWChar2Number(bstrValue));
		break;
	case MF_SYS_FIELDTYPE_BIGINT:
		m_lpCurrentRecord->m_lpFieldData[nIndex].SetData((long long)ConvertWChar2Number(bstrValue));
		break;
	case MF_SYS_FIELDTYPE_DOUBLE:
		m_lpCurrentRecord->m_lpFieldData[nIndex].SetData(ConvertWChar2Double(bstrValue), MF_VARDATA_DOUBLE);
		break;
	case MF_SYS_FIELDTYPE_DATE:
		nRet = ConvertWChar2Date(bstrValue, dtDate);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		m_lpCurrentRecord->m_lpFieldData[nIndex].SetData(dtDate, MF_VARDATA_DATE);
		break;
	case MF_SYS_FIELDTYPE_CHAR:
	case MF_SYS_FIELDTYPE_VARCHAR:
	case MF_SYS_FIELDTYPE_CLOB:
		pBuffer = ConvertBSTR2Str(bstrValue, nLen);
		//把后面多余的空格去掉
		for(nLen--;nLen > 0;nLen--)
		{
			if(pBuffer[nLen] == 0 || pBuffer[nLen] == ' ' || pBuffer[nLen] == '	' || pBuffer[nLen] == '\r' || pBuffer[nLen] == '\n')
			{
				pBuffer[nLen] = 0;
			}
			else
			{
				nLen += 2;
				break;
			}
		}
		m_lpCurrentRecord->m_lpFieldData[nIndex].AttachBuffer(MF_VARDATA_STRING, pBuffer, nLen);
		break;	
	default:
		return MF_COMMON_INVALID_FIELDTYPE;			
	}

	m_lpCurrentRecord->m_pFieldModify[nIndex]  = 1;
	if(m_lpCurrentRecord->m_bRecordStatus == 0)
	{
		m_lpCurrentRecord->m_bRecordStatus = RECORD_UPDATE;
	}
	return MF_OK;
}
//设置结果集中当前行指定列的值(可变类型)
int CMemDBRecordset::SetField(int nIndex, const VARIANT& varSrc)
{

	int hr;
	switch(varSrc.vt)
	{
	case VT_NULL:
	case VT_EMPTY:
		hr = MF_OK;
		break;
	case VT_I2:
	case VT_I4:
	case VT_BOOL:
	case VT_I1:
	case VT_UI1:
	case VT_UI2:
	case VT_UI4:
	case VT_INT:
	case VT_UINT:
		//整数
		hr = SetField(nIndex, varSrc.lVal);
		break;
	case VT_I8:
	case VT_UI8:
		//长整型
		hr = SetField(nIndex, varSrc.llVal);
		break;
	case VT_R4:
	case VT_R8:
	case VT_DATE:
		hr = SetField(nIndex, varSrc.dblVal);
		break;
	case VT_DECIMAL:
		{
			VARIANT varDes;
			VariantInit(&varDes);
			hr = ::VariantChangeType(&varDes, &varSrc, 0, VT_I8);
			if(FAILED(hr))
			{
				//失败
			}
			else
			{
				hr = SetField(nIndex, varDes.llVal);
			}
		}
		break;
	case VT_LPSTR:
	case VT_LPWSTR:
	case VT_BSTR:
		//字符串
		hr = SetField(nIndex, varSrc.bstrVal, SysStringLen(varSrc.bstrVal));
		break;
	case VT_ARRAY | VT_UI1:
		{
			int iSize;
			char* pBuf;
			void* pByte;;
			iSize = SafeArrayGetElemsize(varSrc.parray);
			if(pBuf = new char[iSize+1])
			{	
				pByte = NULL;
				SafeArrayAccessData(varSrc.parray,(void **)&pByte);
				memcpy(pBuf,pByte,iSize);
				SafeArrayUnaccessData(varSrc.parray);
			}
		}
		break;
	default:
		hr = MF_COMMON_INVALID_DATATYPE;
	}
	return hr;
}
#endif
//解析结果集
int	CMemDBRecordset::AnalysisRecordset(LPBYTE lpRecordsetBuffer, BOOL bAutoRelease)
{
	int i, nRowLen, nRet;
	LPBYTE	lpRecordBuffer;
	LPRECORDFIELD	lpFieldInfo;
	LPRECORDSETHEAD lpRecordsetHead;
	char* pFieldName, *pRsName, *pTitle, *pObjectName;

	Free();
	m_lpBuffer				= lpRecordsetBuffer;
	m_bAutoRelease			= bAutoRelease;
	lpRecordsetHead			= (LPRECORDSETHEAD)m_lpBuffer;
	m_bRecordsetCanModify	= lpRecordsetHead->m_bModify;
	m_bDatabaseType			= lpRecordsetHead->m_bDatabaseType;

	m_nFieldNum				= lpRecordsetHead->m_nFieldNum;
	m_lpFieldInfo			= new FIELD[m_nFieldNum];

	m_nQueryRowNum			= lpRecordsetHead->m_nRowNum;
	m_nRowNum				= m_nQueryRowNum;
	m_lpRecordset   		= new RECORD[m_nQueryRowNum];
	lpFieldInfo				= lpRecordsetHead->m_lpRecordField;

	lpRecordBuffer  = m_lpBuffer + lpRecordsetHead->m_nRecordBufferOffset;
	for(i = 0; i < m_nFieldNum; i++)
	{
		m_lpFieldInfo[i].m_bAllowNull		= lpFieldInfo[i].m_bAllowNull;
		m_lpFieldInfo[i].m_bAutoIncrement	= lpFieldInfo[i].m_bAutoIncrement;
		m_lpFieldInfo[i].m_bFieldNameType	= lpFieldInfo[i].m_bFieldNameType;
		m_lpFieldInfo[i].m_bFieldType		= lpFieldInfo[i].m_bFieldType;
		m_lpFieldInfo[i].m_bMaxLen			= lpFieldInfo[i].m_bMaxLen;
		m_lpFieldInfo[i].m_bPrimaryKey		= lpFieldInfo[i].m_bPrimaryKey;

		pFieldName = (char*)(m_lpBuffer + lpFieldInfo[i].m_nFieldNameOffset);
		if(!ConvertStr(pFieldName, m_lpFieldInfo[i].m_lpszName, 32*sizeof(wchar_t)))
		{
			return MF_FAILED;
		}
		pObjectName = (char*)(m_lpBuffer + lpFieldInfo[i].m_nObjectNameOffset);
		if(!ConvertStr(pObjectName, m_lpFieldInfo[i].m_lpszObjectName, 32*sizeof(wchar_t)))
		{
			return MF_FAILED;
		}
		pRsName = (char*)(m_lpBuffer + lpFieldInfo[i].m_nRsNameOffset);
		if(!ConvertStr(pRsName, m_lpFieldInfo[i].m_lpszRsName, 32*sizeof(wchar_t)))
		{
			return MF_FAILED;
		}
		pTitle = (char*)(m_lpBuffer + lpFieldInfo[i].m_nTitleOffset);
		if(!ConvertStr(pTitle, m_lpFieldInfo[i].m_lpszTitle, 32*sizeof(wchar_t)))
		{
			return MF_FAILED;
		}
	}            
	for(i = 0; i < m_nQueryRowNum; i++)
	{
		nRowLen = *(int*)lpRecordBuffer;
		nRet = AnalysisRow(lpRecordBuffer, nRowLen, m_lpRecordset[i]);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpRecordBuffer += nRowLen;
	}
	return MF_OK;
}

//解析结果集，获取UpdateRecordset执行计划
int CMemDBRecordset::ParseRecordset(CBaseBson& stBson, LPEXECUTEPLANBSON& lpExecutePlan)
{
	return ParseRecordsetMemDB(stBson, lpExecutePlan);
}

void CMemDBRecordset::Release()
{
	Free();
	delete this;
}

int CMemDBRecordset::CreateInstance(ISobeyDBRecordset * &pRecordset)
{
	pRecordset = new CMemDBRecordset;
	return MF_OK;
}

void CMemDBRecordset::ClearState()
{
	int i;
	for(i = 0; i < m_nQueryRowNum; i++)
	{
		m_lpRecordset[i].m_bRecordStatus = 0;
	}
	for(i = 0; i < m_vecInsertRecord.size(); i++)
	{
		m_vecInsertRecord[i]->m_bRecordStatus = 0;
	}
}
