﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "ParseSql.h"
#include "Date.h"

CParseSql::CParseSql()
{

}

CParseSql::~CParseSql(void)
{
	//m_pTableMap = NULL;
}

BYTE CParseSql::GetCompatibleValueType(MF_VARDATA_TYPE bType)
{
	switch(bType)
	{
	case MF_VARDATA_INT:
	case MF_VARDATA_INT64:
	case MF_VARDATA_DOUBLE:
	case MF_VARDATA_DATE:
		return MF_COMPATIBLE_DATA_NUMBER;
	case MF_VARDATA_STRING:
		return MF_COMPATIBLE_DATA_STRING;
	case MF_VARDATA_BINARY:
		return MF_COMPATIBLE_DATA_BINARY;
	case MF_VARDATA_BYTE:
		return MF_COMPATIBLE_DATA_BYTE;
	default:
		return MF_COMPATIBLE_DATA_UNKNOWN;
	}
}

BYTE CParseSql::GetCompatibleFieldType(MF_SYS_FIELDTYPE bType)
{
	switch(bType)
	{
	case MF_SYS_FIELDTYPE_INT:                            
	case MF_SYS_FIELDTYPE_BIGINT:                         
	case MF_SYS_FIELDTYPE_DOUBLE:
	case MF_SYS_FIELDTYPE_DATE:
		return MF_COMPATIBLE_DATA_NUMBER;
	case MF_SYS_FIELDTYPE_CHAR:                           
	case MF_SYS_FIELDTYPE_VARCHAR:                        
	case MF_SYS_FIELDTYPE_CLOB:
		return MF_COMPATIBLE_DATA_STRING;
	case MF_SYS_FIELDTYPE_BLOB:
		return MF_COMPATIBLE_DATA_BINARY;
	default:
		return MF_COMPATIBLE_DATA_UNKNOWN;
	}
}

BYTE CParseSql::ConvertMathOperatorStrtoByte(CMFString OP)
{
	OP.MakeUpper();
	if(OP == "+")
	{
		return MF_EXECUTEPLAN_OPERATOR_PLUS;
	}
	else if(OP == "-")
	{
		return MF_EXECUTEPLAN_OPERATOR_MINUS;
	}
	else if(OP == "*")
	{
		return MF_EXECUTEPLAN_OPERATOR_MULTIPLY;
	}
	else if(OP == "/")
	{
		return MF_EXECUTEPLAN_OPERATOR_DIVIDE;
	}
	else if(OP == "||")
	{
		return MF_EXECUTEPLAN_OPERATOR_LINK;
	}
	else if(OP == "LIKE")
	{
		return MF_EXECUTEPLAN_OPERATOR_LIKE;
	}
	else if(OP == "IN")
	{
		return MF_EXECUTEPLAN_OPERATOR_IN;
	}
	else if(OP == ">")
	{
		return MF_EXECUTEPLAN_OPERATOR_GREATER;
	}
	else if(OP == ">=")
	{
		return MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL;
	}
	else if(OP == "<")
	{
		return MF_EXECUTEPLAN_OPERATOR_LESS;
	}
	else if(OP == "<=")
	{
		return MF_EXECUTEPLAN_OPERATOR_LESSEQUAL;
	}
	else if(OP == "=")
	{
		return MF_EXECUTEPLAN_OPERATOR_EQUAL;
	}
	else if(OP == "<>")
	{
		return MF_EXECUTEPLAN_OPERATOR_NOTEQUAL;
	}
	else if(OP == "BETWEEN")
	{
		return MF_EXECUTEPLAN_OPERATOR_BETWEEN;
	}
	else if(OP == "AND")
	{
		return MF_EXECUTEPLAN_OPERATOR_AND;
	}
	else if(OP == "OR")
	{
		return MF_EXECUTEPLAN_OPERATOR_OR;
	}
	else if(OP == "NOT")
	{
		return MF_EXECUTEPLAN_OPERATOR_NOT;
	}
	return MF_EXECUTEPLAN_OPERATOR_NULL;
}

// 校验操作符有效性，暂时只支持 + - * / %，不支持正负号
int CParseSql::CheckValidOperator(vector<CMFString>& vecString, int nPos, BOOL bCondition)
{
	CMFString strOperator;
	
	strOperator = vecString[nPos];
	if(strOperator.length() > 7)
	{
		return 0;
	}

	strOperator.MakeUpper();
	if(strOperator == ">" || strOperator == ">=" || strOperator == "<" ||  strOperator == "<=" || strOperator == "<>" || strOperator == "BETWEEN" ||
		strOperator == "=" || strOperator == "OR" ||  strOperator == "AND" || strOperator == "NOT" || strOperator == "LIKE" || strOperator == "IN")
	{
		if(bCondition)
		{
			if(strOperator == "NOT")
			{
				if(vecString[nPos + 1].CompareNoCase("IN"))
				{
					return MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE;
				}
				else 
				{
					return MF_EXECUTEPLAN_OPERATORTYPE_SINGLE;
				}
			}
			else
			{
				//双目运算符
				return MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE;
			}
		}
		else
		{
			return MF_EXECUTEPLAN_OPERATORTYPE_INVALID;
		}
	}
	else if(strOperator == "+" ||  strOperator == "*" ||  strOperator == "/" ||  strOperator == "||")
	{
		return MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE;
	}
	else if(strOperator == "-" )
	{
		return MF_EXECUTEPLAN_OPERATORTYPE_MINUS;
	}
	else if(strOperator == "PRIOR")
	{
		return MF_EXECUTEPLAN_OPERATORTYPE_PRIOR;
	}
	else
	{
		return MF_EXECUTEPLAN_OPERATORTYPE_UNKNOWN;
	}
}

//判断是否为函数
int CParseSql::CheckValidFunction(vector<CMFString>& vecString, int nPos)
{
	char lpszName[32];
	CMFString strFunction;

	memset(lpszName, 0, 32);
	strFunction = vecString[nPos];
	strFunction.MakeUpper();
	if(strFunction == "COUNT")
	{
		return MF_EXECUTEPLAN_OPERATOR_COUNT;
	}
	else if(strFunction == "TO_CHAR")
	{
		return MF_EXECUTEPLAN_OPERATOR_TOCHAR;
	}
	else if(strFunction == "TO_DATE")
	{
		return MF_EXECUTEPLAN_OPERATOR_TODATE;
	}
	else if(strFunction == "SYSDATE")
	{
		return MF_EXECUTEPLAN_OPERATOR_SYSDATE;
	}
	else if(strFunction == "CHECKCHILD")
	{
		return MF_EXECUTEPLAN_OPERATOR_CHECKCHILD;
	}
	else if(CopyNameFromSql(strFunction.c_str(), strFunction.length(), lpszName))
	{
		if(vecString[nPos+1] == ".")
		{
			return MF_EXECUTEPLAN_OPERATOR_SEQUENCE;
		}
	}	
	return 0;
}

BOOL CParseSql::CheckConnectCondition(CBaseBson& stBson, LPBASECONDITIONBSON lpConditon, BOOL& bPiror)
{
	LPCOMPAREEXPBSON lpCompareExp1,lpCompareExp2;
	LPBASECONDITIONBSON lpConditon1, lpConditon2;

	if(lpConditon->m_bConditionType1 == MF_CONDITION_LOGIC)
	{
		lpConditon1 = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpConditon->m_nConditionOffset1);
		if(!CheckConnectCondition(stBson, lpConditon1, bPiror))
		{
			return FALSE;
		}

		if(bPiror == TRUE)
		{
			if(lpConditon->m_bLogicOperator == MF_EXECUTEPLAN_OPERATOR_OR)
			{
				return FALSE;
			}
			return TRUE;
		}
	}
	else if(lpConditon->m_bConditionType1 == MF_CONDITION_COMPARE)
	{
		lpCompareExp1 = (LPCOMPAREEXPBSON)stBson.ConvertOffset2Addr(lpConditon->m_nConditionOffset1);
		if(lpCompareExp1->m_bOperator == MF_EXECUTEPLAN_OPERATOR_PRIOR)
		{
			bPiror = TRUE;
			if(lpConditon->m_bLogicOperator == MF_EXECUTEPLAN_OPERATOR_OR)
			{
				return FALSE;
			}
			else 
			{
				return TRUE;
			}
		}
	}

	if(lpConditon->m_bConditionType2 == MF_CONDITION_LOGIC)
	{
		lpConditon2 = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpConditon->m_nConditionOffset2);
		if(!CheckConnectCondition(stBson, lpConditon2, bPiror))
		{
			return FALSE;
		}
		
		if(bPiror == TRUE)
		{
			if(lpConditon->m_bLogicOperator == MF_EXECUTEPLAN_OPERATOR_OR)
			{
				return FALSE;
			}
			return TRUE;
		}
	}
	else if(lpConditon->m_bConditionType2 == MF_CONDITION_COMPARE)
	{
		lpCompareExp2 = (LPCOMPAREEXPBSON)stBson.ConvertOffset2Addr(lpConditon->m_nConditionOffset2);
		if(lpCompareExp2->m_bOperator == MF_EXECUTEPLAN_OPERATOR_PRIOR)
		{
			bPiror = TRUE;
			if(lpConditon->m_bLogicOperator == MF_EXECUTEPLAN_OPERATOR_OR)
			{
				return FALSE;
			}
			else 
			{
				return TRUE;
			}
		}
	}
	return TRUE;
}

//处理通配符
//	%	通配符，匹配任意个（0个或多个）字符
//		连续百分号按单个百分号处理
//	\%	转义字符,匹配百分号'%'
//
//	_	通配符，匹配任意单个字符
//	\_	转义字符，匹配下划线'_'
//
//	\	转义符，转义符后的符号按原义表示。斜杠转义符后必须跟有任意字符，不能单独使用
//		例如：ab\	字符串进行匹配时会报错
//	\\	转义字符，匹配单个斜杠'\'
//
//	输入长度nStrLen包含结束符
int CParseSql::StrPretreatment(char* pStr, int &nStrLen)
{
	if (0)
	{
		//只支持%通配符
		//不处理字符串中间的百分号通配符
		//例如：ab%cd
		//		应匹配以'ab'开头'cd'结尾的字符串
		//		这里匹配字符串'ab%cd'
		BOOL bPercent;
		int i, nLeftPercentPos, nRightPercentPos;
		nLeftPercentPos = 0;
		nRightPercentPos = 0;
		//处理前百分号
		bPercent = FALSE;
		for(i = 0; i < nStrLen-1; i++)
		{
			if(pStr[i] != '%')
			{
				break;
			}
			else
			{
				pStr[i] = MF_OPERATOR_PERCENT;
				nLeftPercentPos = i;
				bPercent = TRUE;
			}	
		}
		if(bPercent)
		{
			for (i = nLeftPercentPos; i < nStrLen-1; i++)
			{
				pStr[i-nLeftPercentPos] = pStr[i];
			}
			nStrLen -= (nLeftPercentPos);
		}

		//处理后百分号
		bPercent = FALSE;
		for(i = nStrLen - 2; i > nLeftPercentPos; i--)
		{
			if(pStr[i] != '%')
			{
				break;
			}
			else
			{
				pStr[i] = MF_OPERATOR_PERCENT;
				nRightPercentPos = i;
				bPercent = TRUE;
			}
		}
		if(bPercent)
		{
			pStr[nRightPercentPos] = MF_OPERATOR_PERCENT;
			pStr[nRightPercentPos+1] = 0;
			nStrLen = nRightPercentPos + 2;
		}
	} 
	//////////////////////////////////////////////////////////////////////////
	else
	{
		int i, j;
		for(i=0, j=0; i < nStrLen-1; i++, j++)
		{
			if(pStr[i] == '%')				//通配符 '%'
			{
				pStr[j] = MF_OPERATOR_PERCENT;
			}
			else if (pStr[i] == '_')		//通配符 '_'
			{
				pStr[j] = MF_OPERATOR_UNDERLINE;
			}
			else if (pStr[i] == '\\')		//转义符 '\'
			{
				if (i < nStrLen - 1)
				{
					i++;
					pStr[j] = pStr[i];
				} 
				else
				{
					//字符串最后一位是转义斜杠'\'的情况
					return MF_OPERATOR_ERROR_SLASH;
				}
			} 
			else
			{
				pStr[j] = pStr[i];
			}
		}
		nStrLen = j;		//转义后的字符串长度，不包含结束符
		for(i=0, j=0; i < nStrLen; i++)
		{
			if (MF_OPERATOR_PERCENT == pStr[i] && pStr[i] == pStr[i+1])
			{
				//连续百分号通配符，合并为一个
				;
			} 
			else
			{
				pStr[j] = pStr[i];
				j++;
			}
		}
		pStr[j] = 0;
		nStrLen = j+1;		//返回长度，包含结束符
	}
	return 0;
}

//转换为大写
void CParseSql::MakeUpper(char* pStr, int nStrLen)
{
	int i;
	BOOL bQuote;			
	bQuote = FALSE;
	for(i = 0; i < nStrLen; i++)
	{
		if(pStr[i] == '\'')
		{
			if(bQuote)
			{
				bQuote = FALSE;
			}
			else
			{
				bQuote = TRUE;
			}
		}
		if(bQuote)
		{
			continue;
		}	
		if(pStr[i] >= 'a' && pStr[i] <= 'z')
		{
			pStr[i] -= 32;
		}
	}
}
//解析COUNT函数
int CParseSql::ParseCount(vector<CMFString>& vecString, CBaseBson& stBson, BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos)
{
	BYTE bField;
	UINT nOffset;
	LPBYTE lpAddr;
	MF_VARDATA_TYPE bType;
	LPMATHOPERATOR lpMathOp;
	CMFString strItem, strTemp;
	char lpszFieldName[32], *pData;
	LPMATHEXPELEMENTBSON pExpFieldBson;
	int nRet, nPos, nDataLen, nBufferLen;
	LPEXPFIELDBSON_MIXQUEUENODE lpQueueNode;

	nDataLen = 0;
	strItem	 = vecString[nStartPos];
	nPos	 = nStartPos;
	strTemp  = "COUNT";
	pData    = NULL;
	bType	 = MF_VARDATA_UNKNOWN;
	//COUNT后面一定是括号
	nPos++;
	if(vecString[nPos] == "(")
	{
		strTemp += "(";
		//括号后一定是字段名或者*
		nPos++;
		//判断COUNT中的参数是字段名，还是*
		if(CopyNameFromSql(vecString[nPos].c_str(), vecString[nPos].length(), lpszFieldName))
		{
			//如果是字段名，则将对应的字段编号放入m_varValueAarray
			strTemp += lpszFieldName;
			bField = 1;
			nDataLen = vecString[nPos].length();
			pData = lpszFieldName;
		}
		else if(vecString[nPos] == "*")
		{
			//如果是*则字段号为0
			bField = 1;
			strTemp += "*";
		}
		else
		{
			return MF_COMMON_INVALID_FUNTYPE;
		}

		//参数列表后面一定是")"
		nPos++;
		if(vecString[nPos] == ")")
		{
			//语法正确填充MATHEXPRESSIONFIELD
			lpMathOp = new MATHOPERATOR(bFunType); 
			skOperatorStack.push(lpMathOp);
			
			nBufferLen = sizeof(MATHEXPELEMENTBSON) + nDataLen;
			lpAddr = NULL;
			nRet = stBson.AllocFromBsonBuffer(nBufferLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				delete lpMathOp;
				return nRet;
			}
			pExpFieldBson = LPMATHEXPELEMENTBSON(lpAddr);
			pExpFieldBson->m_bField = bField;
			pExpFieldBson->m_bDataType = bType;
			pExpFieldBson->m_nDataLen = nDataLen;
			if(pData == NULL)
			{
				pExpFieldBson->m_bDataBuffer[0] = 0;
			}
			else
			{
				memcpy(pExpFieldBson->m_bDataBuffer, pData, nDataLen);
			}
		
			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_nExpFieldOffset = nOffset;
			queMixQueue.push(lpQueueNode);

			strTemp += ")";
			strExpression += strTemp;
			bRetValueType = MF_COMPATIBLE_DATA_NUMBER;
		}
		else
		{	
			return MF_COMMON_INVALID_FUNTYPE;
		}
	}
	else
	{
		return MF_COMMON_INVALID_FUNTYPE;
	}
	nEndPos = nPos;
	return MF_OK;
}

//解析SYSDATE函数
int CParseSql::ParseSysDate(BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos)
{
	int nPos;
	LPMATHOPERATOR lpMathOp;
	//SYSDATE函数
	nPos = nStartPos;
	lpMathOp = new MATHOPERATOR(bFunType);
	skOperatorStack.push(lpMathOp);

	strExpression += "SYSDATE";
	bRetValueType = MF_COMPATIBLE_DATA_NUMBER;

	nEndPos = nPos;
	return MF_OK;
}
//解析序列
int CParseSql::ParseSEQ(vector<CMFString>& vecString, CBaseBson& stBson, BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos)
{
	char *pData;
	UINT nOffset;
	BOOL bNextval;
	LPBYTE lpAddr;
	LPMATHOPERATOR lpMathOp;
	CMFString strItem, strTemp;
	int nRet, nPos, nDataLen;
	LPMATHEXPELEMENTBSON pExpFieldBson;
	LPEXPFIELDBSON_MIXQUEUENODE lpQueueNode;

	nPos = nStartPos;
	strItem = vecString[nStartPos];
	strTemp = strItem;
	nDataLen = strItem.length();
	pData = const_cast<char*>(strItem.c_str());
	
	//序列名后面一定是"."号
	nPos++;
	if(vecString[nPos] != ".")
	{
		return 0;
	}
	strTemp += ".";
	nPos++;
	//"."后面一定是序列函数
	bNextval = FALSE;
	if(vecString[nPos].CompareNoCase("NEXTVAL") == 0)
	{
		bNextval = TRUE;
	}
	else if(vecString[nPos].CompareNoCase("CURRVAL") == 0)
	{
		bNextval = FALSE;
	}
	else 
	{
		return MF_PARSESELECT_INVALID_SEQUENCE_ERROR;
	}

	//语法正确填充MATHEXPRESSIONFIELD
	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(nDataLen+sizeof(MATHEXPELEMENTBSON), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr;
	pExpFieldBson->m_bDataType = MF_VARDATA_STRING;
	pExpFieldBson->m_nDataLen = nDataLen;
	memcpy(pExpFieldBson->m_bDataBuffer, pData, nDataLen);
	
	lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
	lpQueueNode->m_nExpFieldOffset = nOffset;
	queMixQueue.push(lpQueueNode);

	if(bNextval)
	{
		lpMathOp = new MATHOPERATOR(MF_EXECUTEPLAN_OPERATOR_NEXTVAL);
		skOperatorStack.push(lpMathOp);
		strTemp += "NEXTVAL";
	}
	else
	{
		lpMathOp = new MATHOPERATOR(MF_EXECUTEPLAN_OPERATOR_CURRVAL);
		skOperatorStack.push(lpMathOp);
		strTemp += "CURRVAL";
	}
	strExpression += strTemp;
	bRetValueType = MF_COMPATIBLE_DATA_NUMBER;

	nEndPos = nPos;
	return MF_OK;
}

//解析TO_DATE
int CParseSql::ParseToDate(vector<CMFString>& vecString, CBaseBson& stBson, BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos)
{
	DATE dtDate;
	UINT nOffset;
	LPBYTE lpAddr;
	BOOL bDouble, bHour24;
	LPMATHOPERATOR lpMathOp;
	CMFString strItem, strTemp;
	vector<CMFString> vecFormat;
	VARDATA varValue, varFormat;
	int nRet, nPos, nDataLen; 
	LPMATHEXPELEMENTBSON pExpFieldBson;
	LPEXPFIELDBSON_MIXQUEUENODE lpQueueNode;
	char *pData, *pDate, *pFormat, lpszFieldName[32];
	char pDefaultFormat[] = "YYYY-MM-DD HH24:MI:SS";

	strItem = vecString[nStartPos];
	nPos = nStartPos;
	strTemp = "TO_DATE";
	//ToDate函数
	nPos++;
	//ToDate后面一定是括号
	if(vecString[nPos] == "(")
	{
		strTemp += "(";
		//括号后面有两种情况1.字段名 2.字符串"2015-1-22 17:05:23"
		//对于字段情况，只有在执行的时候做解析，对于字符串情况直接解析并计算出Date值
		nPos++;
		strItem = vecString[nPos];
		if(CopyNameFromSql(strItem.c_str(), strItem.length(), lpszFieldName))
		{
			//字段名形式
			strTemp += strItem.c_str();
			nDataLen = strItem.length();
			pData = const_cast<char*>(strItem.c_str());
			nRet = stBson.AllocFromBsonBuffer(nDataLen+sizeof(MATHEXPELEMENTBSON), nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr;
			pExpFieldBson->m_bField = 1;
			pExpFieldBson->m_nDataLen = nDataLen;
			pExpFieldBson->m_bDataType = MF_VARDATA_STRING;
			memcpy(pExpFieldBson->m_bDataBuffer, pData, nDataLen+1);

			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_nExpFieldOffset = nOffset;
			queMixQueue.push(lpQueueNode);
			//字段名后面有两种情况：1.逗号说明采用输入的字段 2.括号采用默认字段
			nPos++;
			strItem = vecString[nPos];
			if(strItem == ",")
			{
				strTemp += ",";
				//逗号后面一定是日期格式
				nPos++;
				strItem = vecString[nPos];
				if(CopyStringFromSql(strItem.c_str(), strItem.length(), varValue))
				{
					strTemp += strItem.c_str();
					//判断日期格式是否正确
					nRet = CDate::ParseFormat(varValue.m_lpszValue, vecFormat, bDouble, bHour24);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					nDataLen = strItem.length();
				}
				//日期格式后面一定是")"
				nPos++;
				strItem = vecString[nPos];
				if(strItem == ")")
				{
					strTemp += ")";
				}
				else
				{
					return MF_COMMON_INVALID_FUNTYPE;
				}
			}
			else if(strItem == ")")
			{
				//默认格式
				varValue.SetData("YYYY-MM-DD HH24:MI:SS", strlen("YYYY-MM-DD HH24:MI:SS"));
				nDataLen = strlen("YYYY-MM-DD HH24:MI:SS");
			}	
			else
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}

			//语法正确填充LPMATHEXPRESSIONFIELD结构体
			nRet = stBson.AllocFromBsonBuffer(nDataLen+sizeof(MATHEXPELEMENTBSON), nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr;
			pExpFieldBson->m_bDataType = varValue.m_vt;
			pExpFieldBson->m_nDataLen  = nDataLen;
			memcpy(pExpFieldBson->m_bDataBuffer, varValue.m_lpszValue, nDataLen);

			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_nExpFieldOffset = nOffset;
			queMixQueue.push(lpQueueNode);
		}
		else if(CopyStringFromSql(strItem.c_str(), strItem.length(), varValue))
		{
			//字符串形式，直接计算日期值
			strTemp += strItem.c_str();
			pDate = varValue.m_lpszValue;

			//字段名后面有两种情况：1.逗号说明采用输入的字段 2.括号采用默认字段
			nPos++;
			strItem = vecString[nPos];
			if(strItem == ",")
			{
				strTemp += ",";
				//逗号后面一定是日期格式
				nPos++;
				strItem = vecString[nPos];
				if(CopyStringFromSql(strItem.c_str(), strItem.length(), varFormat))
				{
					strTemp += strItem.c_str();
					pFormat = varFormat.m_lpszValue;
				}
				//日期格式后面一定是")"
				nPos++;
				strItem = vecString[nPos];
				if(strItem == ")")
				{
					strTemp += ")";
				}
				else
				{
					return MF_COMMON_INVALID_FUNTYPE;
				}
			}
			else if(strItem == ")")
			{
				//默认格式
				pFormat = pDefaultFormat;
			}
			else
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			//计算日期
			nRet = CDate::ToDate(pDate, pFormat, dtDate);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			//语法正确填充LPMATHEXPFIELDBSON结构体
			nDataLen = sizeof(double);
			
			lpAddr = NULL;
			nRet = stBson.AllocFromBsonBuffer(sizeof(MATHEXPELEMENTBSON)+nDataLen-1, nOffset, lpAddr);
			if(nRet != MF_OK)	
			{
				return nRet;
			}
			pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr;
			pExpFieldBson->m_bDataType = MF_VARDATA_DATE; 
			pExpFieldBson->m_nDataLen = nDataLen;
			*(double*)pExpFieldBson->m_bDataBuffer = dtDate;

			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_nExpFieldOffset = nOffset;
			queMixQueue.push(lpQueueNode);			
		
			lpAddr = NULL;
			nRet = stBson.AllocFromBsonBuffer(sizeof(MATHEXPELEMENTBSON), nOffset, lpAddr);
			pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr;
			pExpFieldBson->m_bDataBuffer[0] = 0;

			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_nExpFieldOffset = nOffset;
			queMixQueue.push(lpQueueNode);
		}
		lpMathOp = new MATHOPERATOR(bFunType); 
		skOperatorStack.push(lpMathOp);

		strExpression += strTemp;
		bRetValueType = MF_COMPATIBLE_DATA_NUMBER;
	}
	else
	{
		return MF_COMMON_INVALID_FUNTYPE;
	}
	nEndPos = nPos;
	return MF_OK;
}

//解析TO_CHAR
int CParseSql::ParseToChar(vector<CMFString>& vecString, CBaseBson& stBson, BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos)
{
	UINT nOffset;
	LPBYTE lpAddr;
	BYTE bOperator;
	VARDATA varValue;
	LPMATHOPERATOR lpMathOp;
	int nRet, nPos, nDataLen;
	CMFString strTemp, strItem;
	char lpszFieldName[32],*pFormat;
	LPMATHEXPELEMENTBSON pExpFieldBson;
	LPEXPFIELDBSON_MIXQUEUENODE lpQueueNode;

	nPos = nStartPos;
	strItem = vecString[nStartPos];
	memset(lpszFieldName, 0, 32);
	strTemp += "TO_CHAR";

	lpMathOp = new MATHOPERATOR(bFunType); 
	skOperatorStack.push(lpMathOp);
	//TO_CHAR后面一定是括号
	nPos++;
	pFormat = NULL;
	if(vecString[nPos] == "(")
	{
		strTemp += "(";
		lpMathOp = new MATHOPERATOR(MF_EXECUTEPLAN_OPERATOR_LEFTBRACKET);
		skOperatorStack.push(lpMathOp);
		//左括号后面有4种形式：1.数字型常量 2.字段名 3.SYSDATE函数 4.TO_DATE函数
		nPos++;
		strItem = vecString[nPos];
		strItem.MakeUpper();
		if(nRet = IsNumber(strItem.c_str()))
		{
			if(1 == nRet)
			{
				lpAddr = NULL;
				nRet = stBson.AllocFromBsonBuffer(sizeof(int)+sizeof(MATHEXPELEMENTBSON)-1, nOffset, lpAddr);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr;
				pExpFieldBson->m_bDataType = MF_VARDATA_INT;
				pExpFieldBson->m_nDataLen = sizeof(int);
				*(int*)pExpFieldBson->m_bDataBuffer = atoi(strItem.c_str());
			}
			else
			{
				lpAddr = NULL;
				nRet = stBson.AllocFromBsonBuffer(sizeof(double)+sizeof(MATHEXPELEMENTBSON)-1, nOffset, lpAddr);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr;
				pExpFieldBson->m_bDataType = MF_VARDATA_DOUBLE;
				pExpFieldBson->m_nDataLen = sizeof(double);
				*(double*)pExpFieldBson->m_bDataBuffer = atof(strItem.c_str());
			}
	
			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_nExpFieldOffset = nOffset;
			queMixQueue.push(lpQueueNode);
		}
		else if(strItem == "SYSDATE")
		{
			strTemp += "SYSDATE";
			nRet = ParseSysDate(MF_EXECUTEPLAN_OPERATOR_SYSDATE, skOperatorStack, strTemp, bRetValueType, nPos, nEndPos);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nPos = nEndPos;
		}
		else if(strItem == "TO_DATE")
		{
			strTemp += "TO_DATE";
			nRet = ParseToDate(vecString, stBson, MF_EXECUTEPLAN_OPERATOR_TODATE, skOperatorStack, queMixQueue,
							   strTemp, bRetValueType, nPos, nEndPos);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			nPos = nEndPos;
		}
		else if(CopyNameFromSql(strItem.c_str(), strItem.length(), lpszFieldName))
		{
			lpAddr = NULL;
			strTemp += lpszFieldName;
			nRet = stBson.AllocFromBsonBuffer(strItem.length()+sizeof(MATHEXPELEMENTBSON), nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr;
			pExpFieldBson->m_bField = 1;
			pExpFieldBson->m_nDataLen = strItem.length();
			memcpy(pExpFieldBson->m_bDataBuffer, lpszFieldName, strItem.length());
		
			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_nExpFieldOffset = nOffset;
			queMixQueue.push(lpQueueNode);
		}
		else
		{
			return MF_COMMON_INVALID_FUNTYPE;
		}
	}
	else
	{
		return MF_COMMON_INVALID_FUNTYPE;
	}

	//TO_CHAR值字段后面有2中情况:1.逗号，表示按照指定格式进行转换 2.")"表示按照默认格式进行转换
	nPos++;
	if(vecString[nPos] == ",")
	{
		strTemp += ",";
		//将"("之前的所有符号弹出符号栈
		while((bOperator = skOperatorStack.top()->m_bMathOp) != MF_EXECUTEPLAN_OPERATOR_LEFTBRACKET)
		{
			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_bOperator = 1;
			lpQueueNode->m_bMathOp = bOperator;
			queMixQueue.push(lpQueueNode);				//将逻辑运算符压入混合队列中
			delete skOperatorStack.top();
			skOperatorStack.pop();						//弹栈
		}

		//逗号后面一定是格式字符串
		nPos++;
		strItem = vecString[nPos];
		if(CopyStringFromSql(strItem.c_str(), strItem.length(), varValue))
		{
			//指定格式
			strTemp += varValue.m_lpszValue;
			pFormat  = varValue.m_lpszValue;
		}
		nPos++;
	}
	if(vecString[nPos] == ")")
	{
		//将"("之前的所有符号弹出符号栈
		while((bOperator = skOperatorStack.top()->m_bMathOp) != MF_EXECUTEPLAN_OPERATOR_LEFTBRACKET)
		{
			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_bOperator = 1;
			lpQueueNode->m_bMathOp = bOperator;
			queMixQueue.push(lpQueueNode);				//将逻辑运算符压入混合队列中
			delete skOperatorStack.top();
			skOperatorStack.pop();						//弹栈
		}
		//将"弹出"之前的所有符号弹出符号栈
		delete skOperatorStack.top();
		skOperatorStack.pop();							//将左括号弹栈	
		strTemp += ",";

		if(pFormat == NULL)
		{
			//默认格式
			pFormat = "YYYY-MM-DD HH24:MI:SS";
			strTemp += pFormat;
			strTemp += ")";
		}
		nDataLen = strlen(pFormat);
		lpAddr	 = NULL;
		nRet = stBson.AllocFromBsonBuffer(sizeof(MATHEXPELEMENTBSON)+nDataLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr;
		pExpFieldBson->m_bDataType = MF_VARDATA_STRING;
		pExpFieldBson->m_nDataLen = nDataLen;
		memcpy(pExpFieldBson->m_bDataBuffer, pFormat, nDataLen);
		
		lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
		lpQueueNode->m_bOperator = 0;
		lpQueueNode->m_nExpFieldOffset = nOffset;
		queMixQueue.push(lpQueueNode);
	}
	else
	{
		return MF_COMMON_INVALID_FUNTYPE;
	}
	strExpression += strTemp;
	nEndPos = nPos;
	return MF_OK;
}

//解析CheckChild
int CParseSql::ParseCheckChild(vector<CMFString>& vecString, CBaseBson& stBson, BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos)
{
	UINT nOffset;
	LPBYTE lpAddr;
	VARDATA varValue;
	char lpszFieldName[32];
	LPMATHOPERATOR lpMathOp;
	int nRet, nPos, nBufferLen;
	CMFString strTemp, strItem;
	LPMATHEXPELEMENTBSON pExpFieldBson;
	LPEXPFIELDBSON_MIXQUEUENODE lpQueueNode;

	nPos = nStartPos;
	strItem = vecString[nStartPos];
	memset(lpszFieldName, 0, 32);
	strTemp += "CheckChild";

	lpMathOp = new MATHOPERATOR(bFunType); 
	skOperatorStack.push(lpMathOp);
	//CheckChild后面一定是括号
	nPos++;
	if(vecString[nPos] == "(")
	{
		strTemp += "(";
		//左括号后面一定是字段名
		nPos++;
		strItem = vecString[nPos];
		strItem.MakeUpper();
		if(CopyNameFromSql(strItem.c_str(), strItem.length(), lpszFieldName))
		{
			lpAddr = NULL;
			strTemp += lpszFieldName;
			nRet = stBson.AllocFromBsonBuffer(strItem.length()+sizeof(MATHEXPELEMENTBSON), nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr;
			pExpFieldBson->m_bField = 1;
			pExpFieldBson->m_nDataLen = strItem.length();
			memcpy(pExpFieldBson->m_bDataBuffer, lpszFieldName, strItem.length());

			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_nExpFieldOffset = nOffset;
			queMixQueue.push(lpQueueNode);
		}
		else
		{
			return MF_COMMON_INVALID_FUNTYPE;
		}
	}
	else
	{
		return MF_COMMON_INVALID_FUNTYPE;
	}

	//字段名后面一定是逗号
	nPos++;
	if(vecString[nPos] == ",")
	{
		strTemp += ",";

		//逗号后面一定是值
		nPos++;
		strItem = vecString[nPos];
		if(nRet = IsNumber(strItem.c_str()))
		{
			//纯数字字段情况
			if(MF_SYS_NUMBER_TYPE_INT == nRet)
			{
				varValue.SetData(atoi(strItem.c_str()));
				nBufferLen = sizeof(MATHEXPELEMENTBSON) + sizeof(int) - 1;   //注意：这里的-1，由于结构体中存放了BYTE[1]，所以BUFFER的实际长度需要减去1，但是对于字符串型数据因为本身结尾需要存放结束符所以不用-1，但是数值型数据不存放结束符，那么就需要减去一个字节
				lpAddr = NULL;
				nRet = stBson.AllocFromBsonBuffer(nBufferLen, nOffset, lpAddr);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr; 
				pExpFieldBson->m_bDataType = MF_VARDATA_INT;
				pExpFieldBson->m_nDataLen = sizeof(int);
				*(int*)pExpFieldBson->m_bDataBuffer = varValue.m_nValue;
			}
			else if(MF_SYS_NUMBER_TYPE_DOUBLE == nRet)
			{	
				varValue.SetData(atof(strItem.c_str()), MF_SYS_FIELDTYPE_DATE);
				nBufferLen = sizeof(MATHEXPELEMENTBSON) + sizeof(double) - 1;   //注意：这里的-1，由于结构体中存放了BYTE[1]，所以BUFFER的实际长度需要减去1，但是对于字符串型数据因为本身结尾需要存放结束符所以不用-1，但是数值型数据部存放结束符，那么就需要减去一个字节
				lpAddr = NULL;
				nRet = stBson.AllocFromBsonBuffer(nBufferLen, nOffset, lpAddr);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr; 
				pExpFieldBson->m_bDataType = MF_VARDATA_DOUBLE;
				pExpFieldBson->m_nDataLen = sizeof(double);
				*(double*)pExpFieldBson->m_bDataBuffer = varValue.m_dblValue;
			}
			else
			{
				return MF_PARSECMD_INVALID_NUMBER_ERROR;
			}
		}
		else if(CopyStringFromSql(strItem.c_str(), strItem.length(), varValue))
		{
			nBufferLen = sizeof(MATHEXPELEMENTBSON) + varValue.m_nStrLen;
			lpAddr = NULL;
			nRet = stBson.AllocFromBsonBuffer(nBufferLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			pExpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr; 
			pExpFieldBson->m_bDataType = MF_VARDATA_STRING;
			pExpFieldBson->m_nDataLen = varValue.m_nStrLen;
			memcpy(pExpFieldBson->m_bDataBuffer, varValue.m_lpszValue, varValue.m_nStrLen);
		}
		strTemp += strItem;

		lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
		lpQueueNode->m_nExpFieldOffset = nOffset;
		queMixQueue.push(lpQueueNode);
	}
	else
	{
		return MF_COMMON_INVALID_FUNTYPE;
	}
	
	//值后面一定是右括号
	nPos++;
	if(vecString[nPos] != ")")
	{
		return MF_COMMON_INVALID_FUNTYPE;
	}
	strTemp += ")";
	bRetValueType = MF_COMPATIBLE_DATA_NUMBER;
	strExpression += strTemp;
	nEndPos = nPos;
	return MF_OK;
}

int CParseSql::ParseShortestPath(vector<CMFString>& vecString, CBaseBson& stBson, LPQUERYEXECUTEPLANBSON lpQueryPlan, CMFString& strExpression, int nStartPos, int& nEndPos)
{
	UINT nOffset;
	LPBYTE lpAddr;
	VARDATA varValue;
	queue<int> queCompareQueue;
	CMFString strTemp, strItem;
	LPSHORTESTPATH lpShortestPath;
	LPMATHEXPBSON lpExpBson;
	LPEXECUTEFIELDBSON lpExecuteField;
	stack<LPMATHOPERATOR> skOperatorStack;
	queue<LPEXPFIELDBSON_MIXQUEUENODE> queMathQueue;
	int i, nRet, nStartNode, nTo, nEndNode, nLevelPos;		
	queue<LPCONDITIONBSON_MIXQUEUENODE> queConditionQueue; 

	strTemp += "SHORTESTPATH";
	//SHORTESTPATH后面一定是“(”
	if(vecString[nStartPos + 1] != "(")
	{
		return MF_COMMON_INVALID_FUNTYPE;
	}
	//结束位置一定是“)”
	if(vecString[nEndPos] != ")")
	{
		return MF_COMMON_INVALID_FUNTYPE;
	}
	
	nRet = stBson.AllocFromBsonBuffer(lpExecuteField, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpQueryPlan->m_nExcuteFieldNum    = 0;
	lpQueryPlan->m_nExcuteFieldOffset = nOffset;
	lpExecuteField->m_bExpressionType = MF_EXPRESSION_COMMFUN;

	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(32, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecuteField->m_nExpNameOffset = nOffset;
	lpExecuteField->m_bNameLen       = 32;
	strcpy((char*)lpAddr, "SHORTESTPATH");

	nRet = stBson.AllocFromBsonBuffer(lpExpBson, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}	
	lpExecuteField->m_nExpOffset = nOffset;
	lpExpBson->m_bValType		 = MF_SYS_FIELDTYPE_INT;
	lpExpBson->m_bOperator		 = MF_EXECUTEPLAN_OPERATOR_SHORTESTPATH;

	nRet = stBson.AllocFromBsonBuffer(lpShortestPath, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}	
	lpExpBson->m_nExpOffset1 = nOffset;
	
	nStartNode = 0;
	nTo        = 0;
	nEndNode   = 0;
	nLevelPos  = 0;
	for(i = nStartPos + 2; i < nEndPos; i++)
	{
		strItem  = vecString[i];
		strItem.MakeUpper();
		if(strItem == "STARTNODE")
		{
			if(nStartNode != 0)
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			nStartNode = i;
			//STARTNODE后面一定是“(”
			i++;
			if(i >= nEndPos)
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			strItem = vecString[i];
			if(strItem != "(")
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
		}
		else if(strItem == "TO")
		{
			if(nTo != 0 || nStartNode == 0)
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			nTo = i;
			//TO前面一定是“)”
			strItem = vecString[i-1];
			if(strItem != ")")
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			nRet = ParseCondition(vecString, stBson, lpShortestPath->m_nStartCondOffset, NULL, skOperatorStack, 
				queMathQueue, queCompareQueue, queConditionQueue, nStartNode+2, nTo - 1);
			FreeStack(skOperatorStack);
			FreeQueue(queMathQueue);
			FreeQueue(queConditionQueue);
			if(nRet != MF_OK)
			{
				return nRet;
			}

		}
		else if(strItem == "ENDNODE")
		{
			if(nEndNode != 0 || nTo == 0)
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}		
			nEndNode = i;
			//ENDNODE前一定是TO
			strItem = vecString[i-1];
			strItem.MakeUpper();
			if(strItem != "TO")
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			//ENDNODE后一定是“(”
			i++;
			if(i >= nEndPos)
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			strItem = vecString[i];
			if(strItem != "(")
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
		}
		else if(strItem == "LEVEL")
		{
			if(nLevelPos != 0 || nEndNode == 0)
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			nLevelPos = i;
			//LEVEL后一定是“[”
			i++;
			if(i >= nEndPos)
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			strItem = vecString[i];
			if(strItem != "[")
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			
			//“[”后一定是数字
			i++;
			if(i >= nEndPos)
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			strItem = vecString[i];
			if(1 != IsNumber(strItem.c_str()))
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			lpShortestPath->m_nLevel = ToNumber(strItem.c_str(), strItem.length());

			//数字后面一定是“]”
			i++;
			if(i >= nEndPos)
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
			strItem = vecString[i];
			if(strItem != "]")
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}

			//数字后面一定是结束
			i++;
			if(i != nEndPos)
			{
				return MF_COMMON_INVALID_FUNTYPE;
			}
		}	
	}
	if(nLevelPos == 0)
	{
		i = nEndPos - 1;
	}
	else
	{
		i = nLevelPos - 1;
	}

	nRet = ParseCondition(vecString, stBson, lpShortestPath->m_nEndCondOffset, NULL, skOperatorStack, 
		queMathQueue, queCompareQueue, queConditionQueue, nEndNode+2, i);
	FreeStack(skOperatorStack);
	FreeQueue(queMathQueue);
	FreeQueue(queConditionQueue);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	return MF_OK;
}
/************************************************************************   
	功能说明：
		解析表信息
	参数说明：
		vecString：SQL语句字符串
		objectName：表名
		nStartPos：表名子句的起始位置
		nEndPos：表名子句的结束位置
************************************************************************/
int CParseSql::ParseObjectInfo(vector<CMFString>& vecString, char* pObjectName, char* pObjectTitle, int nStartPos, int nEndPos)
{
	//如果FROM和WHERE的位置相差不为1，则报错
	CMFString strName;
	strName = vecString[nStartPos];
	if(!CopyNameFromSql(strName.c_str(), strName.length(), pObjectName))
	{
		return MF_PARSESELECT_INVALID_OBJECT_ERROR;			//非法表名
	}
	
	nStartPos++;
	if(nStartPos > nEndPos)
	{
		return MF_PARSESELECT_INVALID_OBJECT_ERROR;
	}

	if(nStartPos != nEndPos)
	{
		//表的别名
		strName = vecString[nStartPos];
		if(strName.CompareNoCase("AS") == 0)
		{
			nStartPos++;
			strName = vecString[nStartPos];
		}
		if(CopyNameFromSql(strName.c_str(), strName.length(), pObjectTitle))
		{
			nStartPos++;
		}	
		else
		{
			return MF_PARSESELECT_INVALID_OBJECT_ERROR;
		}
		if(nStartPos != nEndPos)
		{
			return MF_PARSESELECT_INVALID_OBJECT_ERROR;
		}
	}
	
	return MF_OK;
}

/************************************************************************   
	功能说明：
		解析算数运算表达式中的字段值
	参数说明：
		vecString：SQL语句字符串
		stBson：Bson对象
		nExpFieldOffset：表达式字段偏移
		strExpression：表达式字符串
		bFiled：是否包含列
		nValueStartPos：字段值的起始位置
		nExpressionEndPos：表达式子句的结束位置
	特别说明：
		算数运算中包括，纯数字、系统函数、字段
************************************************************************/
int CParseSql::ParseMathFieldValue(vector<CMFString>& vecString,  CBaseBson& stBson, int& nExpFieldOffset,char* pObjectTitle, 
								   CMFString& strExpression, BOOL& bFiled, int& nValueStartPos, int nExpressionEndPos)
{
	UINT nOffset;
	LPBYTE lpAddr;
	VARDATA varValue;
	char pFieldName[32];
	int nRet, nPos, nBufferLen;
	CMFString strItem, strItem2;
	LPMATHEXPELEMENTBSON lpFieldBson;

	nPos = nValueStartPos;
	strItem = vecString[nPos];
	memset(pFieldName, 0 ,32);

	if(strItem.CompareNoCase("NULL") == 0)
	{
		nRet = stBson.AllocFromBsonBuffer(lpFieldBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpFieldBson->m_bDataType = MF_SYS_FIELDTYPE_NULL;
	}
	else if(strItem.length() == 0)
	{
		nRet = stBson.AllocFromBsonBuffer(lpFieldBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpFieldBson->m_bDataType = MF_SYS_FIELDTYPE_NULL;
	}
	else if(pObjectTitle != NULL && strItem.CompareNoCase(pObjectTitle) == 0)
	{
		//表别名形式：select s.sno from student as s where s.sno < 1;
		nPos++;
		if(vecString[nPos] == ".")
		{
			nPos++;
			strItem = vecString[nPos];
			if(CopyNameFromSql(strItem.c_str(), strItem.length(), pFieldName))
			{
				//字段情况
				nBufferLen = sizeof(MATHEXPELEMENTBSON) + strItem.length();
				lpAddr = NULL;
				nRet = stBson.AllocFromBsonBuffer(nBufferLen, nOffset, lpAddr);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr; 
				lpFieldBson->m_bField = 1;
				lpFieldBson->m_nDataLen = strItem.length();
				memcpy(lpFieldBson->m_bDataBuffer, pFieldName, strItem.length());

				bFiled = TRUE;
				strExpression += strItem;
			}
			else
			{
				return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
			}
		}
		else
		{
			return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
		}
	}
	else if(CopyNameFromSql(strItem.c_str(),strItem.length(),pFieldName))
	{
		//字段情况
		nBufferLen = sizeof(MATHEXPELEMENTBSON) + strItem.length();
		lpAddr = NULL;
		nRet = stBson.AllocFromBsonBuffer(nBufferLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr; 
		lpFieldBson->m_bField = 1;
		lpFieldBson->m_nDataLen = strItem.length();
		memcpy(lpFieldBson->m_bDataBuffer, pFieldName, strItem.length());
	
		bFiled = TRUE;
		strExpression += strItem;
	}
	else if(nRet = IsNumber(strItem.c_str()))
	{
		//纯数字字段情况
		if(MF_SYS_NUMBER_TYPE_INT == nRet)
		{
			//varValue.SetData(atoi(strItem.c_str()));
			//nBufferLen = sizeof(MATHEXPELEMENTBSON) + sizeof(int) - 1;   //注意：这里的-1，由于结构体中存放了BYTE[1]，所以BUFFER的实际长度需要减去1，但是对于字符串型数据因为本身结尾需要存放结束符所以不用-1，但是数值型数据不存放结束符，那么就需要减去一个字节
			//lpAddr = NULL;
			//nRet = stBson.AllocFromBsonBuffer(nBufferLen, nOffset, lpAddr);
			//if(nRet != MF_OK)
			//{
			//	return nRet;
			//}
			//lpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr; 
			//lpFieldBson->m_bDataType = MF_VARDATA_INT;
			//lpFieldBson->m_nDataLen = sizeof(int);
			//*(int*)lpFieldBson->m_bDataBuffer = varValue.m_nValue;

			varValue.SetData(_atoi64(strItem.c_str()));
			nBufferLen = sizeof(MATHEXPELEMENTBSON) + sizeof(long long) - 1;   //注意：这里的-1，由于结构体中存放了BYTE[1]，所以BUFFER的实际长度需要减去1，但是对于字符串型数据因为本身结尾需要存放结束符所以不用-1，但是数值型数据不存放结束符，那么就需要减去一个字节
			lpAddr = NULL;
			nRet = stBson.AllocFromBsonBuffer(nBufferLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr; 
			lpFieldBson->m_bDataType = MF_VARDATA_INT64;
			lpFieldBson->m_nDataLen = sizeof(long long);
			*(long long*)lpFieldBson->m_bDataBuffer = varValue.m_llValue;
		}
		else if(MF_SYS_NUMBER_TYPE_DOUBLE == nRet)
		{	
			varValue.SetData(atof(strItem.c_str()), MF_SYS_FIELDTYPE_DATE);
			nBufferLen = sizeof(MATHEXPELEMENTBSON) + sizeof(double) - 1;   //注意：这里的-1，由于结构体中存放了BYTE[1]，所以BUFFER的实际长度需要减去1，但是对于字符串型数据因为本身结尾需要存放结束符所以不用-1，但是数值型数据部存放结束符，那么就需要减去一个字节
			lpAddr = NULL;
			nRet = stBson.AllocFromBsonBuffer(nBufferLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr; 
			lpFieldBson->m_bDataType = MF_VARDATA_DOUBLE;
			lpFieldBson->m_nDataLen = sizeof(double);
			*(double*)lpFieldBson->m_bDataBuffer = varValue.m_dblValue;
		}
		else
		{
			return MF_PARSECMD_INVALID_NUMBER_ERROR;
		}
		strExpression += strItem;
	}
	else if(CopyStringFromSql(strItem.c_str(), strItem.length(), varValue))
	{
		if(nPos > 1)
		{
			strItem2 = vecString[nPos - 1];
			strItem2.MakeUpper();
			if(strItem2 == "LIKE")
			{
				nRet = StrPretreatment(varValue.m_lpszValue, varValue.m_nStrLen);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
		}
		nBufferLen = sizeof(MATHEXPELEMENTBSON) + varValue.m_nStrLen+1;
		lpAddr = NULL;
		nRet = stBson.AllocFromBsonBuffer(nBufferLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpFieldBson = (LPMATHEXPELEMENTBSON)lpAddr; 
		lpFieldBson->m_bDataType = MF_VARDATA_STRING;
		lpFieldBson->m_nDataLen = varValue.m_nStrLen;
		memcpy(lpFieldBson->m_bDataBuffer, varValue.m_lpszValue, varValue.m_nStrLen);

		strExpression += strItem;
	}
	else
	{
		return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
	}

	//判断语法是否正确：数据值后面只能是运算符、")"、结束符
	if(nPos+1 != nExpressionEndPos && !CheckValidOperator(vecString, nPos+1) && vecString[nPos+1] != ")")
	{
		return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
	}
	nExpFieldOffset = nOffset;
	nValueStartPos = nPos;
	return MF_OK;
}
/************************************************************************   
	功能说明：
		解析算数运算表达式
	参数说明：
		vecString：SQL语句字符串
		stBson：BSON
		nExpOffset：表达式偏移
		strExpression：表达式字符串
		bFiled：表达式中是否包含字段
		bAggregateFun：表达式中是否包含聚合函数(字段和聚合函数不能同时出现在表达式中)
		pObjectTitle：对象别名
		nStartPos：字段起始位置
		nEndPos：字段结束位置
	特别说明：
		算数运算中包括，纯数字、系统函数、字段
************************************************************************/
int	CParseSql::ParseMathExpression(vector<CMFString>& vecString, CBaseBson& stBson, UINT& nExpBsonOffset, 
								   CMFString& strExpression, BOOL& bFiled, BOOL& bAggregateFun,char* pObjectTitle, 
								   stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue,
								   int nStartPos, int nEndPos, int &nModifyFlag)
{
	BOOL bExpression;
	CMFString strItem;
	LPMATHOPERATOR lpMathOp;
	LPEXPFIELDBSON_MIXQUEUENODE lpQueueNode;
	BYTE bFunType, bOperator, bMathOP, bRetValueType;
	int j, nRet, nLeftBracketNum, nRightBracketNum, nFunEndPos, nExpFieldOffset;
	//将条件字段转换成EXECUTEPLANFIELDCONDITION结构体
	//同时将字段表达式转换为后缀表达式
	strItem = vecString[nStartPos];

	//查询字段不能为空
	nRightBracketNum	= 0;
	nLeftBracketNum		= 0;
	bFiled				= FALSE;
	bAggregateFun		= FALSE;
	if(nEndPos == nStartPos)
	{
		return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
	}
	//表达式第一位不能是双目运算符或右括号
	if(MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE == CheckValidOperator(vecString, nStartPos) || strItem == ")")
	{
		return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
	}

	for(j = nStartPos; j < nEndPos; j++)
	{
		strItem = vecString[j];
		if(strItem == (")"))							
		{
			//")"的左边，不能是"("运算符，")"的右边不能是单目运算符
			if(CheckValidOperator(vecString, j - 1) || "(" == vecString[j - 1] || MF_EXECUTEPLAN_OPERATORTYPE_SINGLE == CheckValidOperator(vecString, j + 1))
			{
				return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
			}
			nRightBracketNum++;
			//如果字段为右括号，则对符号栈中左括号之前的所有符号进行弹栈，并压入混合队列中
			strExpression += ")";
			if(skOperatorStack.size() == 0)
			{
				return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
			}
			while((bOperator = skOperatorStack.top()->m_bMathOp) != MF_EXECUTEPLAN_OPERATOR_LEFTBRACKET)
			{
				lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
				lpQueueNode->m_bOperator = 1;
				lpQueueNode->m_bMathOp = bOperator;
				queMixQueue.push(lpQueueNode);				//将逻辑运算符压入混合队列中
				delete skOperatorStack.top();
				skOperatorStack.pop();						//弹栈
			}
			delete skOperatorStack.top();
			skOperatorStack.pop();							//将左括号弹栈	
		}
		else if(strItem == ("("))
		{	
			//"("的右边，不能是")"或双目运算符
			if(MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE == CheckValidOperator(vecString, j + 1) || ")" == vecString[j + 1])
			{
				return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
			}
			nLeftBracketNum++;
			strExpression += "(";
			lpMathOp = new MATHOPERATOR(MF_EXECUTEPLAN_OPERATOR_LEFTBRACKET);
			skOperatorStack.push(lpMathOp);						//左括号直接进行压栈
		}
		else if(nRet = CheckValidOperator(vecString, j))
		{
			bExpression = TRUE;
			if(nRet == MF_EXECUTEPLAN_OPERATORTYPE_INVALID)
			{
				return MF_COMMON_INVALID_OPERATOR;
			}

			//所有运算符的右边都不能是运算符或者")"
			if(CheckValidOperator(vecString, j + 1) || vecString[j + 1] == ")")
			{
				return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
			}

			//其中单目运算符左边不能是")"
			if(nRet == MF_EXECUTEPLAN_OPERATORTYPE_SINGLE)
			{
				if(vecString[j - 1] == ")")
				{
					return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
				}
			}
			else if(nRet == MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE)
			{
				if(CheckValidOperator(vecString, j - 1) || vecString[j - 1] == "(")
				{
					//双目运算符左边不能是运算符或"("
					return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
				}
			}

			bMathOP = ConvertMathOperatorStrtoByte(strItem);
			if(!bMathOP)
			{
				return MF_PARSECMD_INVALID_OPERATOR_ERROR;
			}

			//"-"存在单目运算符情况，所以要加以判断
			if(MF_EXECUTEPLAN_OPERATOR_MINUS == bMathOP)
			{
				if(j == nStartPos || vecString[j-1] == "(" || CheckValidOperator(vecString, j-1))
				{
					bMathOP = MF_EXECUTEPLAN_OPERATOR_SIGNMINUS;
				}
			}

			lpMathOp = new MATHOPERATOR(bMathOP);
			strExpression += strItem;

			//对运算符执行压栈操作
			//步骤：1、比较当前运算符与符号栈顶运算符的优先级，如果优先级高于栈顶运算符，则直接压栈
			//		2、如果优先级比栈顶运算符低，则将栈中所有优先级高于当前运算符的运算符弹栈，同时压入混合队列
			if(skOperatorStack.empty() || lpMathOp->m_bPriority > skOperatorStack.top()->m_bPriority || MF_EXECUTEPLAN_OPERATOR_LEFTBRACKET == skOperatorStack.top()->m_bMathOp)
			{
				skOperatorStack.push(lpMathOp);
			}
			else
			{
				do 
				{
					lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
					lpQueueNode->m_bOperator = 1;
					lpQueueNode->m_bMathOp = skOperatorStack.top()->m_bMathOp;
					queMixQueue.push(lpQueueNode);

					delete skOperatorStack.top();
					skOperatorStack.pop();
				} while ((!skOperatorStack.empty()) && lpMathOp->m_bPriority <= skOperatorStack.top()->m_bPriority);
				skOperatorStack.push(lpMathOp);
			}
		}
		else if(strItem.CompareNoCase(pObjectTitle) != 0 && (bFunType = CheckValidFunction(vecString, j)))
		{
			if(bFunType == MF_EXECUTEPLAN_OPERATOR_COUNT)
			{
				bAggregateFun = TRUE;
			}
			nRet = ParseFunction(vecString, bFunType, stBson, skOperatorStack, queMixQueue, strExpression, 
								 bRetValueType, j, nFunEndPos);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			
			//序列
			if(MF_EXECUTEPLAN_OPERATOR_SEQUENCE == bFunType)
			{
				nModifyFlag = 1;
			}

			//返回值类型为空的函数不能存在于四则运算中
			if(MF_COMPATIBLE_DATA_NULL == bRetValueType)
			{
				if(bExpression || nEndPos != nFunEndPos+1)
				{
					return MF_PARSECMD_INVALID_OPERATOR_ERROR;
				}
			}
			//判断语法是否正确：函数后面只能是运算符、")"、结束符
			if(nFunEndPos+1 > nEndPos)
			{
				return MF_PARSECMD_INVALID_OPERATOR_ERROR;
			}
			else if(nFunEndPos+1 != nEndPos && !CheckValidOperator(vecString, nFunEndPos+1) && vecString[nFunEndPos+1] != ")")
			{
				return MF_PARSECMD_INVALID_OPERATOR_ERROR;
			}
			j = nFunEndPos;
		}
		else																		//字段为执行条件
		{
			//解析表达式值并填充LPMATHEXPRESSIONFIELD结构体然后将LPMATHEXPRESSIONFIELD压入混合队列
			nRet = ParseMathFieldValue(vecString, stBson, nExpFieldOffset, pObjectTitle, strExpression, bFiled, j, nEndPos);	
			if(nRet != MF_OK)
			{
				return nRet;
			}
			//将LPMATHEXPRESSIONFIELD压入混合队列
			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_bOperator = 0;
			lpQueueNode->m_nExpFieldOffset = nExpFieldOffset;
			queMixQueue.push(lpQueueNode);
		}
	}

	//括号不匹配错误
	if(nLeftBracketNum != nRightBracketNum)
	{
		return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
	}

	//将符号栈中剩余符号压人混合队列
	while(!skOperatorStack.empty())
	{
		lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
		lpQueueNode->m_bOperator = 1;
		lpQueueNode->m_bMathOp = skOperatorStack.top()->m_bMathOp;
		queMixQueue.push(lpQueueNode);

		delete skOperatorStack.top();
		skOperatorStack.pop();
	}

	//聚合函数和字段不能同时出现(目前暂不支持GroupBy)
	if(bFiled && bAggregateFun)
	{
		return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
	}

	//创建四则运算表达式
	nRet = CreateMathExpression(nExpBsonOffset, stBson, queMixQueue);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	return MF_OK;
}

/************************************************************************   
	功能说明：
		解析函数子句
	参数说明：
		vecString：SQL语句字符串
		pExecuteField：字段结构体
		strFunction：函数字段
		bRetValueType：返回值兼容类型
		lpObjectInfo：表信息
		nStartPos：函数的起始位置
	特别说明：
		函数的处理步骤：
		1.函数名作为运算符，拥有最高优先级
		2.函数的参数处理
		  i.按照正常的表达式来处理函数参数
		  ii.如果遇到，则将符号栈中的元素弹栈，直到遇到“)”为止
************************************************************************/
int CParseSql::ParseFunction(vector<CMFString>& vecString, BYTE bFunType, CBaseBson& stuBaseBson, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue,
							 CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos)
{
	int nRet;
	if(MF_EXECUTEPLAN_OPERATOR_COUNT == bFunType)
	{
		nRet = ParseCount(vecString, stuBaseBson, bFunType, skOperatorStack, queMixQueue, strExpression, 
						  bRetValueType, nStartPos, nEndPos);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(MF_EXECUTEPLAN_OPERATOR_SYSDATE == bFunType)
	{
		nRet = ParseSysDate(bFunType, skOperatorStack, strExpression, 
							bRetValueType, nStartPos, nEndPos);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(MF_EXECUTEPLAN_OPERATOR_SEQUENCE == bFunType)
	{
		nRet = ParseSEQ(vecString, stuBaseBson, bFunType, skOperatorStack, queMixQueue, strExpression, 
					    bRetValueType, nStartPos, nEndPos);
		if(nRet != MF_OK)
		{
			return nRet;
		}

	}
	else if(MF_EXECUTEPLAN_OPERATOR_TODATE == bFunType)
	{
		nRet = ParseToDate(vecString, stuBaseBson, bFunType, skOperatorStack, queMixQueue, strExpression, 
						   bRetValueType, nStartPos, nEndPos);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(MF_EXECUTEPLAN_OPERATOR_TOCHAR == bFunType)
	{
		nRet = ParseToChar(vecString, stuBaseBson, bFunType, skOperatorStack, queMixQueue, strExpression, 
						   bRetValueType, nStartPos, nEndPos);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(MF_EXECUTEPLAN_OPERATOR_CHECKCHILD == bFunType)
	{
		nRet = ParseCheckChild(vecString, stuBaseBson, bFunType, skOperatorStack, queMixQueue, strExpression, 
			bRetValueType, nStartPos, nEndPos);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		return MF_COMMON_INVALID_FUNTYPE;
	}
	return MF_OK;
}

/************************************************************************   
	功能说明：
		解析查询字段信息
	参数说明：
		vecString：SQL语句字符串
		stBson:BSON结构体
		lpQueryExecutePlanBson：执行计划BSON
		pObjectTitle：对象别名
		nStartPos：查询字段子句的起始位置
		nEndPos：查询字段句的结束位置
************************************************************************/
int CParseSql::ParseSelectField(vector<CMFString>& vecString, CBaseBson& stBson, LPQUERYEXECUTEPLANBSON lpQueryExecutePlanBson, char* pObjectTitle, int nStartPos, int nEndPos, int &nModifyFlag)
{
	LPBYTE lpAddr;
	char pFieldTitle[32];
	BYTE bExpressionType;
	BOOL bFiled, bAggregateFun;		
	CMFString strItem, strExpression;
	stack<LPMATHOPERATOR> skOperatorStack;
	LPEXECUTEFIELDBSON pExecuteFieldBson;
	UINT nOffset, nExpBsonOffset, nPreOffset;
	queue<LPEXPFIELDBSON_MIXQUEUENODE> queMixQueue;
	int i, nRet, nFieldNum, nBracket, nFieldEndPos, nDotPos, nFieldStartPos, nExpNameLen;
	
	//至少有一个查询字段
	if(nEndPos - nStartPos < 1)
	{
		return MF_PARSECMD_INVALID_SELECT_SYNTAX_ERROR;
	}
	//语法条件：1.要有一个或多个查询字段
	//			2.字段形式只能是sname,sno 或 sname 姓名, sno 学号 或 sname AS 姓名,sno AS 学号 
	nPreOffset = 0;
	nBracket = 0;
	strItem = vecString[nStartPos];
	if(strItem == "*")					
	{
 		lpQueryExecutePlanBson->m_nExcuteFieldNum = 0;				//0代表SELECT*
		return MF_OK;
	}
	else if(strItem.CompareNoCase(pObjectTitle) == 0)
	{
		//判断是否是表别名.*的情况
		strItem = vecString[nStartPos + 1];
		if(strItem != ".")
		{
			return MF_PARSECMD_INVALID_SELECT_SYNTAX_ERROR;
		}
		strItem = vecString[nStartPos + 2];
		if(strItem == "*")
		{
			lpQueryExecutePlanBson->m_nExcuteFieldNum = 0;				//0代表SELECT*
			return MF_OK;
		}
	}

	//计算字段数量(逗号数量+1)
	nFieldNum = 1;
	for(i = nStartPos; i <= nEndPos; i++)
	{	
		//由于函数中可能包含“,”但函数只能作为表达式的一部分，所以要排除函数中“,”的影响
		strItem = vecString[i];
		if(strItem == "(")
		{
			nBracket++;
		}
		else if(strItem == ")")
		{
			nBracket--;
		}
		if(nBracket)
		{
			continue;
		}
		if(strItem == ",")
		{
			nFieldNum++;
		}
	}
	//解析查询字段
	nFieldStartPos = nStartPos;
	for(i = nStartPos; i <= nEndPos; i++)
	{
		strItem = vecString[i];
		if(strItem == "(")
		{
			nBracket++;
		}
		else if(strItem == ")")
		{
			nBracket--;
		}
		if(nBracket)
		{
			continue;
		}
		if(strItem == "," || i == nEndPos)
		{
			nRet = stBson.AllocFromBsonBuffer(pExecuteFieldBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(0 == nPreOffset)
			{
				lpQueryExecutePlanBson->m_nExcuteFieldOffset = nOffset;
				nPreOffset = nOffset;
			}
			else
			{
				((LPEXECUTEFIELDBSON)stBson.ConvertOffset2Addr(nPreOffset))->m_nNextOffset = nOffset;
				nPreOffset = nOffset;
			}
			nFieldEndPos = i;
			nDotPos = i;
			
			//判断表达式是否有别名，注意别名值可能以“AS 别名”形式或“别名”形式位于表达式末尾
			strItem = vecString[nFieldEndPos - 1];
			//如果nFieldEndPos == 1则说明 select 和 from之间只有一个字段
			if(nFieldEndPos != 1 && CopyNameFromSql(strItem.c_str(), strItem.length(), pFieldTitle))
			{
				//如果Title前不是运算符、逗号(单一字段情况)、"."（序列情况），则Title一定是别名
				strItem = vecString[nFieldEndPos - 2];
				if("." != strItem && "," != strItem && !CheckValidOperator(vecString, nFieldEndPos - 1) && !CheckValidOperator(vecString, nFieldEndPos - 2))
				{
					nFieldEndPos--;									//去掉别名
					lpAddr = NULL;
					nRet = stBson.AllocFromBsonBuffer(strlen(pFieldTitle) + 1, nOffset, lpAddr);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					memcpy(lpAddr, pFieldTitle, strlen(pFieldTitle) + 1);
					pExecuteFieldBson->m_bTitleLen = strlen(pFieldTitle) + 1;
					pExecuteFieldBson->m_nExpTitleOffset = nOffset;
					if(strItem.CompareNoCase("AS") == 0)
					{
						nFieldEndPos--;								//去掉AS
					}
				}
			}
			//解析算数表达式
			bFiled = FALSE;
			bAggregateFun = FALSE;
			nRet = ParseMathExpression(vecString, stBson, nExpBsonOffset, strExpression, bFiled, bAggregateFun, pObjectTitle,
									   skOperatorStack, queMixQueue, nFieldStartPos, nFieldEndPos, nModifyFlag);
			
			//不论是否执行成功，都需要先释放skOperatorStack和queMixQueue
			FreeStack(skOperatorStack);
			FreeQueue(queMixQueue);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			//聚合函数和字段不能同时出现(目前暂不支持GroupBy)
			if(bFiled && bAggregateFun)
			{
				return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
			}

			bExpressionType = CBaseExpression::GetExpressionType(nExpBsonOffset, stBson);
			pExecuteFieldBson->m_bExpressionType = bExpressionType;
			pExecuteFieldBson->m_nExpOffset = nExpBsonOffset;
			
			//分配空间存放表达式名称
			nExpNameLen = strExpression.length() + 1 < 32 ? strExpression.length() + 1 : 31;
			lpAddr = NULL;
			nRet = stBson.AllocFromBsonBuffer(nExpNameLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			memcpy(lpAddr, strExpression.c_str(), nExpNameLen-1);

			pExecuteFieldBson->m_nExpNameOffset = nOffset;
			pExecuteFieldBson->m_bNameLen = nExpNameLen;
			nFieldStartPos = nDotPos + 1;

			lpAddr = NULL;
		}
		strExpression = _T("");
	}
	lpQueryExecutePlanBson->m_nExcuteFieldNum = nFieldNum;
	lpQueryExecutePlanBson->m_bAggreFun = bAggregateFun;
	return MF_OK;
}

/************************************************************************
	功能说明：
		解析更新字段信息
	参数说明：
		vecString：SQL语句字符串
		stBson:BSON结构体
		pUpdateExecutePlanBson：执行计划BSON
		nStartPos：查询字段子句的起始位置
		nEndPos：查询字段句的结束位置
************************************************************************/
int CParseSql::ParseUpdateField(vector<CMFString>& vecString, CBaseBson& stBson, LPUPDATEEXECUTEPLANBSON lpUpdatePlan, int nStartPos, int nEndPos)
{
	LPBYTE lpAddr;
	CMFString strItem;
	char pFieldName[32];
	CMFString strExpression;
	UINT nOffset, nPreOffset;
	BOOL bFiled, bAggregateFun;		
	stack<LPMATHOPERATOR> skOperatorStack;
	LPEXECUTEFIELDBSON lpFieldBson, lpPreFieldBson;
	queue<LPEXPFIELDBSON_MIXQUEUENODE> queMixQueue;
	int nRet, nFieldStartPos, nFieldNum, nFieldPos, nModifyFlag;

	//计算字段数量(逗号数量+1)
	nPreOffset = 0;
	nFieldPos = 0;
	nFieldNum = 1;
	for(int j = nStartPos; j <= nEndPos; j++)
	{
		strItem = vecString[j];
		if(strItem == ",")
		{
			nFieldNum++;
		}
	}
	lpUpdatePlan->m_nExecuteFieldNum = nFieldNum;

	nFieldStartPos = nStartPos;					
	for(int j = nStartPos; j <= nEndPos; j++)
	{
		strItem = vecString[j];
		if(strItem == "," || j == nEndPos)
		{
			nRet = stBson.AllocFromBsonBuffer(lpFieldBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(nPreOffset != 0)
			{ 
				lpPreFieldBson = (LPEXECUTEFIELDBSON)stBson.ConvertOffset2Addr(nPreOffset);
				lpPreFieldBson->m_nNextOffset = nOffset;
			}
			else
			{
				//将第一个列的偏移量赋值给lpUpdatePlan
				lpUpdatePlan->m_nExcuteFieldOffset = nOffset;
			}
			nPreOffset = nOffset;
			strItem = vecString[nFieldStartPos];				  //起始字段必须是列名
			if(CopyNameFromSql(strItem.c_str(), strItem.length(), pFieldName))			
			{
				//分配空间存放列名
				lpAddr = NULL;
				nRet = stBson.AllocFromBsonBuffer(strItem.length()+1, nOffset, lpAddr);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				memcpy(lpAddr, pFieldName, strItem.length()+1);
				lpFieldBson->m_nExpNameOffset = nOffset;
				lpFieldBson->m_bNameLen = strItem.length()+1;
				//字段后面一定是等号
				strItem = vecString[nFieldStartPos + 1];
				if(strItem == "=")
				{	
					//等号后面一定是一个表达式
					nModifyFlag = 0;
					nRet = ParseMathExpression(vecString, stBson, nOffset, strExpression, bFiled, bAggregateFun, NULL,
											   skOperatorStack, queMixQueue, nFieldStartPos + 2, j, nModifyFlag);
					//不论是否执行成功，都需要先释放skOperatorStack和queMixQueue
					FreeStack(skOperatorStack);
					FreeQueue(queMixQueue);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					lpFieldBson->m_nExpOffset = nOffset;
					lpFieldBson->m_bExpressionType = CBaseExpression::GetExpressionType(nOffset, stBson);
					if(MF_EXPRESSION_AGGREFUN == lpFieldBson->m_bExpressionType)
					{
						return MF_PARSEUPDATE_INVALID_EXPRESSION_ERROR;				//表达式不能是聚合函数
					}
				}
				else
				{
					return MF_PARSECMD_INVALID_UPDATE_SYNTAX_ERROR;
				}
			}
			else
			{
				return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
			}
			nFieldStartPos = j + 1;
			nFieldPos++;
		}
		strExpression = _T("");
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		解析建表语句的字符串部分
	参数说明：
		vecString：SQL语句字符串
		stBson:BSON结构体
		lpObjectBson：对象信息
		nStartPos：建表字段子句的起始位置
		nEndPos：建表字段句的结束位置
************************************************************************/
int CParseSql::ParseCreateField(vector<CMFString>& vecString, CBaseBson& stBson, LPOBJECTDEFBSON lpObjectBson, int nStartPos, int& nEndPos)
{
	UINT nOffset;
	CMFString strItem;
	BOOL bPrimaryIndex;
	set<int> setPrimaryKey;
	set<string> setIndexName;
	LPINDEXDEFBSON lpIndexBson;
	map<BYTE, int> mapNoToField;
	map<string, int> mapFieldMap;
	map<string, BYTE> mapNameToNo;
	MF_SYS_FILETYPE bIndexFileType; 
	map<string ,BYTE>::iterator iter;
	LPOBJECTFIELDDEFBSON lpFieldBson;
	set<int>::iterator iterPrimaryKey;
	set<string>::iterator iterIndexName;
	MF_SYS_FIELDTYPE bPrimaryType, bParentType;
	int i, j, nFieldCount, nRet, nFieldPreOffset;

	lpIndexBson     = NULL;
	lpFieldBson		= NULL;
	nFieldPreOffset = 0;

	strItem = vecString[nStartPos];
	if(strItem != "(")
	{
		//这里应该是括号
		return MF_PARSECMD_CREATE_LACK_BRACE_ERROR;
	}

	//先预算一下可能会出现几个列，简单方式就是数逗号个数，当然可能会包含有索引，但多分配几个问题不太大
	nFieldCount = 1;
	for(i = nStartPos + 1; i < nEndPos; i++)
	{
		strItem = vecString[i];
		if(strItem == ",")
		{
			nFieldCount++;
		}
	}

	if(nFieldCount >= 255)
		nFieldCount = 255;

	//开始具体字段解析
	lpObjectBson->m_nFieldNum = 0;
	for(i = nStartPos + 1;i < nEndPos; i++)
	{
		strItem = vecString[i];
		//首先判断是否保留字
		strItem.MakeUpper();
		if(strItem == "INDEX")
		{
			nRet = stBson.AllocFromBsonBuffer(lpIndexBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			//插头法
			lpIndexBson->m_nNextOffset   = lpObjectBson->m_nIndexOffset;
			lpObjectBson->m_nIndexOffset = nOffset;

			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			strItem.MakeUpper();
			if(strItem == "UNIQUE")
			{
				lpIndexBson->m_bConstraintType = MF_CONSTRAINT_UNIQUE;
				i++;
				if(i >= nEndPos)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				strItem = vecString[i];
				strItem.MakeUpper();
			}

			if(strItem == "TREE")
			{
				bIndexFileType = MF_SYS_FILETYPE_TREEINDEXFILE;
			}
			else if(strItem == "KV")
			{
				bIndexFileType = MF_SYS_FILETYPE_KVINDEXFILE;
			}
			else if(strItem == "HBTREE")
			{
				bIndexFileType = MF_SYS_FILETYPE_HBTREEINDEXFILE;
			}
			else
			{
				return MF_PARSECMD_CREATE_LACK_KEYWORD_ERROR;
			}

			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			
			//获取索引名
			strItem = vecString[i];
			if(CopyNameFromSql(strItem.c_str(), strItem.length(), lpIndexBson->m_pIndexName) == 0)
			{
				return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
			}

			//判断是否存在重名索引
			iterIndexName = setIndexName.find(lpIndexBson->m_pIndexName);
			if(iterIndexName == setIndexName.end())
			{
				setIndexName.insert(lpIndexBson->m_pIndexName);
			}
			else
			{
				return MF_PARSECMD_CREATE_INDEXNAME_EXIST_ERROR;
			}

			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			if(strItem != "(")
			{
				return MF_PARSECMD_CREATE_LACK_BRACE_ERROR;
			}

			//解析HB树索引
			if(bIndexFileType == MF_SYS_FILETYPE_HBTREEINDEXFILE)
			{
				i++;
				if(i >= nEndPos)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				strItem = vecString[i];

				//括号中有且只有两列，并且必须是主键列和双亲列
				if(strItem == "PRIMARY")
				{
					i++;
					if(i >= nEndPos)
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					strItem = vecString[i];
					strItem.MakeUpper();
					iter = mapNameToNo.find(strItem.c_str());
					if(iter == mapNameToNo.end())
					{
						return MF_PARSECMD_CREATE_FIELD_NOTEXISTS_ERROR;
					}
					else
					{
						lpIndexBson->m_bFieldNo[0] = mapNameToNo[strItem.c_str()];
					}

					lpFieldBson  = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(mapFieldMap[strItem.c_str()]);
					bPrimaryType = lpFieldBson->m_bFieldType;
					nRet = GetIndexType(bIndexFileType, bPrimaryType, lpIndexBson->m_bIndexType);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					i++;
					if(i >= nEndPos)
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					if(vecString[i] != ",")
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					i++;
					if(i >= nEndPos)
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					strItem = vecString[i];
					if(strItem == "PARENT")
					{
						i++;
						if(i >= nEndPos)
						{
							return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
						}
						strItem = vecString[i];
						strItem.MakeUpper();

						iter = mapNameToNo.find(strItem.c_str());
						if(iter == mapNameToNo.end())
						{
							return MF_PARSECMD_CREATE_FIELD_NOTEXISTS_ERROR;
						}
						else
						{
							lpIndexBson->m_bFieldNo[1] = mapNameToNo[strItem.c_str()];
						}
						lpFieldBson = (LPOBJECTFIELDDEFBSON)(stBson.ConvertOffset2Addr(mapFieldMap[strItem.c_str()]));
						if(lpFieldBson->m_bFieldType != bPrimaryType)
						{
							return MF_PARSECMD_CREATE_HBINDEX_FIELDTYPE_NOTQUEAL;
						}
					}
					else
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					i++;
					if(i >= nEndPos)
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					if(vecString[i] != ")")
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
				}
				else if(strItem == "PARENT")
				{
					i++;
					if(i >= nEndPos)
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					strItem = vecString[i];
					strItem.MakeUpper();
					iter = mapNameToNo.find(strItem.c_str());
					if(iter == mapNameToNo.end())
					{
						return MF_PARSECMD_CREATE_FIELD_NOTEXISTS_ERROR;
					}
					else
					{
						lpIndexBson->m_bFieldNo[1] = mapNameToNo[strItem.c_str()];
					}
					lpFieldBson = (LPOBJECTFIELDDEFBSON)(stBson.ConvertOffset2Addr(mapFieldMap[strItem.c_str()]));
					bParentType = lpFieldBson->m_bFieldType;

					i++;
					if(i >= nEndPos)
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					if(vecString[i] != ",")
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					i++;
					if(i >= nEndPos)
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					strItem = vecString[i];
					if(strItem == "PRIMARY")
					{
						i++;
						if(i >= nEndPos)
						{
							return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
						}
						strItem = vecString[i];
						strItem.MakeUpper();
						iter = mapNameToNo.find(strItem.c_str());
						if(iter == mapNameToNo.end())
						{
							return MF_PARSECMD_CREATE_FIELD_NOTEXISTS_ERROR;
						}
						else
						{
							lpIndexBson->m_bFieldNo[0] = mapNameToNo[strItem.c_str()];
						}
						lpFieldBson = (LPOBJECTFIELDDEFBSON)(stBson.ConvertOffset2Addr(mapFieldMap[strItem.c_str()]));
						if(bParentType != lpFieldBson->m_bFieldType)
						{
							return MF_PARSECMD_CREATE_HBINDEX_FIELDTYPE_NOTQUEAL;
						}
						nRet = GetIndexType(bIndexFileType, lpFieldBson->m_bFieldType, lpIndexBson->m_bIndexType);
						if(nRet != MF_OK)
						{
							return nRet;
						}
					}
					else
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					i++;
					if(i >= nEndPos)
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					if(vecString[i] != ")")
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
				}
				else
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}

				if(setPrimaryKey.size() == 1)
				{
					iterPrimaryKey = setPrimaryKey.find(lpIndexBson->m_bFieldNo[0]);
					if(iterPrimaryKey != setPrimaryKey.end())
					{
						lpIndexBson->m_bConstraintType = MF_CONSTRAINT_PRIMARYKEY;
						bPrimaryIndex = TRUE;
					}
				}
			}
			else
			{
				int n;
				BOOL bPrimaryKey;
				bPrimaryKey = TRUE;
				n			= 0;		
				while(TRUE)
				{
					i++;
					if(i >= nEndPos)
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					strItem = vecString[i];
					strItem.MakeUpper();
					//查找创建索引的列是否是该表的列
					iter = mapNameToNo.find(strItem.c_str());
					if(iter == mapNameToNo.end())
					{
						return MF_PARSECMD_CREATE_FIELD_NOTEXISTS_ERROR;
					}
					else
					{
						lpIndexBson->m_bFieldNo[n] = mapNameToNo[strItem.c_str()];
						if(bPrimaryKey)
						{
							iterPrimaryKey = setPrimaryKey.find(lpIndexBson->m_bFieldNo[n]);
							if(iterPrimaryKey == setPrimaryKey.end())
							{
								bPrimaryKey = FALSE;
							}
						}
						n++;
					}
					if(n > 1)
					{
						//复合索引
						if(bIndexFileType == MF_SYS_FILETYPE_KVINDEXFILE)
						{
							return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
						}
						else
						{
							lpIndexBson->m_bIndexType = MF_SYS_INDEXTYPE_TREE_MULTINUM;
						}
					}
					else
					{
						//单字段索引
						lpFieldBson = (LPOBJECTFIELDDEFBSON)(stBson.ConvertOffset2Addr(mapFieldMap[strItem.c_str()]));
						nRet = GetIndexType(bIndexFileType, lpFieldBson->m_bFieldType, lpIndexBson->m_bIndexType);
						if(nRet != MF_OK)
						{
							return nRet;
						}
					}

					i++;
					if(i >= nEndPos)
					{
						return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
					}
					strItem = vecString[i];
					if(strItem == ",")
					{
						continue;
					}
					else if(strItem == ")")
					{
						break;
					}
				}

				if(lpIndexBson->m_bIndexType == MF_SYS_INDEXTYPE_TREE_MULTINUM)
				{
					//复合索引，调整索引顺序，将字符串型的关键字放在最前面
					BOOL bTemp;
					BYTE bTempNo;
					int nCount, nCharCount;
					nCount		= 0;
					nCharCount	= 0;
					for(j = 0; j < 4; j++)
					{
						if(lpIndexBson->m_bFieldNo[j] == 0)
						{
							break;
						}

						lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(mapNoToField[lpIndexBson->m_bFieldNo[j]]);
						if(lpFieldBson->m_bFieldType == MF_SYS_FIELDTYPE_CHAR || lpFieldBson->m_bFieldType == MF_SYS_FIELDTYPE_VARCHAR)
						{
							nCharCount++;
							if(nCharCount > 2)
							{
								//符合索引中字符串字段数不能大于2个
								return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
							}
						}
						nCount++;
					}
					nCount--;
					bTemp = TRUE;
					for(j = 0; j <= nCount; j++)
					{
						lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(mapNoToField[lpIndexBson->m_bFieldNo[j]]);
						if(lpFieldBson->m_bFieldType == MF_SYS_FIELDTYPE_CHAR || lpFieldBson->m_bFieldType == MF_SYS_FIELDTYPE_VARCHAR)
						{
							lpIndexBson->m_bIndexType = MF_SYS_INDEXTYPE_TREE_MULTISTR;
							if(bTemp)
							{
								bTempNo = lpIndexBson->m_bFieldNo[0];
								lpIndexBson->m_bFieldNo[0] = lpIndexBson->m_bFieldNo[j];
								lpIndexBson->m_bFieldNo[j] = bTempNo;
								bTemp = FALSE;
							}
							else
							{
								while(nCount > j)
								{
									lpFieldBson = (LPOBJECTFIELDDEFBSON)stBson.ConvertOffset2Addr(mapNoToField[lpIndexBson->m_bFieldNo[nCount]]);
									if(lpFieldBson->m_bFieldType < 5)
									{
										bTempNo = lpIndexBson->m_bFieldNo[nCount];
										lpIndexBson->m_bFieldNo[nCount] = lpIndexBson->m_bFieldNo[j];
										lpIndexBson->m_bFieldNo[j] = bTempNo;
										break;
									}
									nCount--;
								}
							}
						}
					}
				}

				if(bPrimaryKey && n == setPrimaryKey.size())
				{
					lpIndexBson->m_bConstraintType = MF_CONSTRAINT_PRIMARYKEY;
					bPrimaryIndex = TRUE;
				}
			}
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			if(strItem == ",")
			{
				continue;
			}
			else if(strItem == ")")
			{
				break;
			}
		}
		else if(strItem == "PRIMARY")
		{
			int nCount;
			char pFieldName[32];
			memset(pFieldName, 0, 32);
			if(lpIndexBson != NULL)
			{
				//PRIMARY只能出现在INDEX之前
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			//PRIMARY后面一定是Key
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			strItem.MakeUpper();
			if(strItem != "KEY")
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}

			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			if(strItem != "(")
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}

			nCount = 0;
			while(TRUE)
			{
				i++;
				if(i >= nEndPos)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				strItem = vecString[i];
				if(!CopyNameFromSql(strItem.c_str(), 32, pFieldName))
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				iter = mapNameToNo.find(pFieldName);
				if(iter == mapNameToNo.end())
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				setPrimaryKey.insert(mapNameToNo[pFieldName]);

				nCount++;
				if(nCount > 4)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}

				i++;
				if(i >= nEndPos)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				strItem = vecString[i];
				if(strItem == ")")
				{
					break;
				}
				else if(strItem != ",")
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
			}
			if(nCount == 0)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			if(strItem == ",")
			{
				continue;
			}
			else if(strItem == ")")
			{
				break;
			}
		}
		else if(strItem == ")")
		{
			break;
		}
		else
		{
			//字段情况
			LPOBJECTFIELDDEFBSON lpPreFieldBson;
			nRet = stBson.AllocFromBsonBuffer(lpFieldBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			if(nFieldPreOffset != 0)
			{
				lpPreFieldBson = (LPOBJECTFIELDDEFBSON)(stBson.ConvertOffset2Addr(nFieldPreOffset));
				lpPreFieldBson->m_nNextOffset = nOffset;
			}
			else
			{
				lpObjectBson->m_nFieldOffset = nOffset;
			}
			nFieldPreOffset = nOffset;
			lpFieldBson->m_bFieldNo   = lpObjectBson->m_nFieldNum+1;
			lpFieldBson->m_bAllowNull = 1;									//默认情况字段可以为空
			if(CopyNameFromSql(strItem.c_str(), strItem.length(), lpFieldBson->m_bFieldName) == 0)
			{
				return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
			}
			mapNoToField.insert(make_pair(lpFieldBson->m_bFieldNo, nOffset));
			mapFieldMap.insert(make_pair(lpFieldBson->m_bFieldName, nOffset));
			mapNameToNo.insert(make_pair(lpFieldBson->m_bFieldName, lpFieldBson->m_bFieldNo));
			//接下来就是取类型字段了
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			strItem.MakeUpper();
			if(strItem == "INT")
			{
				lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_INT;
			}
			else if(strItem == "BIGINT")
			{
				lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_BIGINT;
			}
			else if(strItem == "DOUBLE")
			{
				lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_DOUBLE;
			}
			else if(strItem == "DATE")
			{
				lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_DATE;
			}
			else if(strItem == "VARCHAR")
			{
				lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_VARCHAR;
			}
			else if(strItem == "CLOB")
			{
				lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_CLOB;
			}
			else if(strItem == "BLOB")
			{
				lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_BLOB;
			}
			else if(strItem == "CHAR")
			{
				lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_CHAR;
				i++;
				if(i >= nEndPos)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				strItem = vecString[i];
				if(strItem != "(")
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				i++;
				if(i >= nEndPos)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				strItem = vecString[i];
				if(IsNumber(strItem.c_str()) == 1)
				{
					long long nCharLen;
					nCharLen = _atoi64(strItem.c_str());
					if(nCharLen > 255)
					{
						return MF_COMMON_INVALID_STRINGLEN;
					}
					else
					{
						lpFieldBson->m_bCharLen = (BYTE)nCharLen;
					}
				}
				else
				{
					return MF_PARSECMD_INVALID_NUMBER_ERROR;
				}
				i++;
				if(i >= nEndPos)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				strItem = vecString[i];
				if(strItem != ")")
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
			}
			else
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}

			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			strItem.MakeUpper();
			if(strItem == ",")
			{
				lpObjectBson->m_nFieldNum++;
			}
			else if(strItem == ")")
			{
				lpObjectBson->m_nFieldNum++;
				break;
			}
			else if(strItem == "NOT")
			{
				//NOT NULL情况
				i++;
				if(i >= nEndPos)
				{
					return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
				}
				strItem = vecString[i];
				strItem.MakeUpper();
				if(strItem != "NULL")
				{
					return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
				}
				else
				{
					lpFieldBson->m_bAllowNull = 0;
				}

				i++;
				if(i >= nEndPos)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				strItem = vecString[i];
				if(strItem == ",")
				{
					lpObjectBson->m_nFieldNum++;
				}
				else if(strItem == ")")
				{
					lpObjectBson->m_nFieldNum++;
					break;
				}
			}
			else if(strItem == "NULL")
			{
				//NULL情况
				lpFieldBson->m_bAllowNull = 1; 
				i++;
				if(i >= nEndPos)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				strItem = vecString[i];
				if(strItem == ",")
				{
					lpObjectBson->m_nFieldNum++;
				}
				else if(strItem == ")")
				{
					lpObjectBson->m_nFieldNum++;
					break;
				}
			}
			else
			{
				return MF_PARSECMD_CREATE_LACK_BRACE_ERROR;
			}
		}
	}

	//判断是否为主键创建了索引（主键必须创建索引）
	if(setPrimaryKey.size() != 0 && !bPrimaryIndex)
	{
		return MF_PARSECMD_CREATE_LACK_PRIMARYINDEX_ERROR;
	}

	nEndPos = i;
	return MF_OK;
}

/************************************************************************
	功能说明：
		解析普通插入语句
	参数说明：
		vecString：字符串数组
		stBson：Bson对象
		lpExecutePlan：执行计划
************************************************************************/
int CParseSql::ParseCommonInsert(vector<CMFString> vecString, CBaseBson& stBson, LPEXECUTEPLANBSON lpExecutePlan)
{
	BYTE bExpType;
	LPBYTE lpAddr;
	vector<BYTE> vecExpType;
	LPEXECUTEFIELDBSON lpFieldBson;
	CMFString strItem, strExpression;
	LPOBJECTNAMEBSON pObjectNameBson;
	char pObjectName[32], pFieldName[32];
	LPINSERTEXECUTEPLANBSON lpInsertPlan;
	stack<LPMATHOPERATOR> skOperatorStack;
	UINT i, nOffset, nExpOffset, nPreOffset;
	vector<int> vecFieldOffset, vecExpOffset;
	BOOL nFlag, isDot, bFiled, bAggregateFun;
	queue<LPEXPFIELDBSON_MIXQUEUENODE> queMixQueue;
	int nRet, nBracketPos, nBracket, nExpStartPos, nModifyFlag;

	lpInsertPlan = (LPINSERTEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
	if(lpInsertPlan == NULL)
	{
		return MF_PARSEISNERT_INVALID_NULLPOINTER_ERROR;
	}
	
	lpExecutePlan->m_bObjectType = MF_OBJECT_COMMON;
	//INTO后面一定是表名
	strItem = vecString[1];
	if(!CopyNameFromSql(strItem.c_str(), 31, pObjectName))
	{
		return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;			//非法表名
	}

	lpAddr = NULL; 
	nRet = stBson.AllocFromBsonBuffer(sizeof(OBJECTNAMEBSON)+strItem.length(), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	pObjectNameBson = (LPOBJECTNAMEBSON)lpAddr;
	pObjectNameBson->m_bLen = strItem.length()+1;
	memcpy(pObjectNameBson->m_pObjectName, pObjectName, strItem.length()+1);
	lpInsertPlan->m_nObjectNameOffset = nOffset;
	//表名后面一定是左括号
	strItem = vecString[2];
	if(strItem == "(")
	{
		isDot = FALSE;										//是否是逗号(在括号内，逗号和字段名是相间的)
		//如果有左括号那么一定有右括号，并且右括号后面一定是VALUES(用nBracketPos记录右括号的位置)
		for(i = 3; i < vecString.size() - 1; i++)
		{
			strItem = vecString[i];
			if(strItem == ")")
			{
				nFlag = TRUE;
				nBracketPos = i;
				break;
			}
			else
			{
				if(isDot && strItem == ",")
				{
					isDot = FALSE;
				}
				else if (!isDot && CopyNameFromSql(strItem.c_str(), strItem.length(), pFieldName))
				{	
					lpAddr = NULL;
					isDot = TRUE;
					//列名
					nRet = stBson.AllocFromBsonBuffer(lpFieldBson, nOffset);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					vecFieldOffset.push_back(nOffset);
					//分配空间存放列名
					lpAddr = NULL;
					nRet = stBson.AllocFromBsonBuffer(strItem.length()+1, nOffset, lpAddr);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					memcpy(lpAddr, pFieldName, strItem.length()+1);
					lpFieldBson->m_nExpNameOffset = nOffset;
					lpFieldBson->m_bNameLen = strItem.length()+1;
				}
				else
				{
					return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
				}
			}
		}
		if(nFlag == FALSE)
		{
			return MF_PARSECMD_INVALID_INSERT_SYNTAX_ERROR;			//没有右括号语法错误
		}
	}
	else
	{
		return MF_PARSECMD_INVALID_INSERT_SYNTAX_ERROR;				//表名后一定是左括号
	}
	nBracket = 0;
	strItem = vecString[nBracketPos + 1];
	if(0 == strItem.CompareNoCase("VALUES"))
	{
		//VALUES后面一定是左括号
		strItem = vecString[nBracketPos + 2];
		if(strItem == "(")
		{
			//有左括号一定有右括号，且右括号一定在语句最后
			if(vecString[vecString.size() - 1] != ")")
			{
				return MF_PARSECMD_INVALID_INSERT_SYNTAX_ERROR;	
			}
			nExpStartPos = nBracketPos + 3;
			for(i = nBracketPos + 3; i <= vecString.size() - 1; i++)
			{
				strItem = vecString[i];
				//由于函数中可能包含“,”但函数只能作为表达式的一部分，所以要排除函数中“,”的影响
				if(strItem == "(")
				{
					nBracket++;
				}
				else if(strItem == ")")
				{
					nBracket--;
					if(nBracket < 0)
					{
						nBracket = 0;
					}
				}
				if(nBracket > 0)
				{
					continue;
				}
				if(strItem == "," || i == vecString.size() - 1)
				{
					nModifyFlag = 0;
					nRet = ParseMathExpression(vecString, stBson, nExpOffset,strExpression, bFiled, bAggregateFun, NULL,
						skOperatorStack, queMixQueue, nExpStartPos, i, nModifyFlag);
					//不论是否执行成功，都需要先释放skOperatorStack和queMixQueue
					FreeStack(skOperatorStack);
					FreeQueue(queMixQueue);
					if(nRet != MF_OK)
					{
						return nRet;
					}
					//执行插入操作的表达式只能是常量表达式或普通函数
					bExpType = CBaseExpression::GetExpressionType(nExpOffset, stBson);
					if(bExpType != MF_EXPRESSION_COMMFUN && bExpType != MF_EXPRESSION_CONSTMATH)
					{
						return MF_PARSECMD_INVALID_INSERT_SYNTAX_ERROR;
					}			
					vecExpType.push_back(bExpType);
					vecExpOffset.push_back(nExpOffset);
					nExpStartPos = i + 1;
				}
			}
		}
		else
		{
			return MF_PARSECMD_INVALID_INSERT_SYNTAX_ERROR;			//VALUES后面不是左括号错误
		}
	}
	else
	{
		return MF_PARSECMD_INVALID_INSERT_SYNTAX_ERROR;				//nBracketPos后面不是VALUES错误
	}

	//语法检测完毕
	if(vecFieldOffset.size() != vecExpOffset.size())
	{
		return MF_PARSECMD_INVALID_INSERT_SYNTAX_ERROR;				//nBracketPos后面不是VALUES错误
	}
	else
	{
		lpInsertPlan->m_nExcuteFieldOffset = vecFieldOffset[0];
		lpInsertPlan->m_nExecuteFieldNum = vecFieldOffset.size();
	}

	//获取数据类型
	nPreOffset = 0;
	for(i = 0; i < vecFieldOffset.size(); i++)
	{
		lpFieldBson = (LPEXECUTEFIELDBSON)(stBson.ConvertOffset2Addr(vecFieldOffset[i]));				
		lpFieldBson->m_bExpressionType = vecExpType[i];
		lpFieldBson->m_nExpOffset = vecExpOffset[i];
		if(nPreOffset != 0)
		{
			lpFieldBson = (LPEXECUTEFIELDBSON)(stBson.ConvertOffset2Addr(nPreOffset));
			lpFieldBson->m_nNextOffset = vecFieldOffset[i];
		}
		nPreOffset = vecFieldOffset[i];
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		解析添加字段
	参数说明：
		vecString：字符串数组
		stBson：Bson对象
		lpAlterObjectFieldBson：修改对象字段
		nStartPos：起始位置
		nEndPos：结束位置
************************************************************************/
int CParseSql::ParseAddField(vector<CMFString> vecString, CBaseBson& stBson, LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson, int nStartPos, int nEndPos)
{
	CMFString strItem;
	long long nCharLen;
	int nRet, i, nFieldNum;
	UINT nPreOffset, nOffset;
	LPOBJECTFIELDDEFBSON lpFieldBson, lpPreFieldBson;
	
	//计算添加的列数量
	nFieldNum = 1;
	for(i = nStartPos;i < nEndPos;i++)
	{
		strItem = vecString[i];
		if(strItem == ",")
		{
			nFieldNum++;
		}
	}

	nPreOffset = 0;
	lpAlterObjectFieldBson->m_nFieldNum = 0;
	for(i = nStartPos;i < nEndPos && lpAlterObjectFieldBson->m_nFieldNum < nFieldNum;i++)
	{
		//创建对象列结构体
		nRet = stBson.AllocFromBsonBuffer(lpFieldBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(nPreOffset != 0)
		{
			lpPreFieldBson  = (LPOBJECTFIELDDEFBSON)(stBson.ConvertOffset2Addr(nPreOffset));
			lpPreFieldBson->m_nNextOffset = nOffset;
		}
		else
		{
			lpAlterObjectFieldBson->m_nFieldOffset = nOffset;
		}
		nPreOffset = nOffset;
		
		lpFieldBson->m_bAllowNull = 1;
		//获取字段名
		strItem = vecString[i];
		if(CopyNameFromSql(strItem.c_str(), strItem.length(), lpFieldBson->m_bFieldName) == 0)
		{
			return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
		}
		//接下来就是取字段类型了
		i++;
		if(i >= nEndPos)
		{
			return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
		}
		strItem = vecString[i];
		strItem.MakeUpper();
		if(strItem == "INT")
		{
			lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_INT;
		}
		else if(strItem == "BIGINT")
		{
			lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_BIGINT;
		}
		else if(strItem == "DOUBLE")
		{
			lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_DOUBLE;
		}
		else if(strItem == "DATE")
		{
			lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_DATE;
		}
		else if(strItem == "VARCHAR")
		{
			lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_VARCHAR;
		}
		else if(strItem == "CLOB")
		{
			lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_CLOB;
		}
		else if(strItem == "BLOB")
		{
			lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_BLOB;
		}
		else if(strItem == "CHAR")
		{
			lpFieldBson->m_bFieldType = MF_SYS_FIELDTYPE_CHAR;
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			if(strItem != "(")
			{
				return MF_PARSECMD_ALTER_LACK_BRACE_ERROR;
			}
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			if(IsNumber(strItem.c_str()) == 1)
			{
				nCharLen = _atoi64(strItem.c_str());
				if(nCharLen > 255)
				{
					return MF_COMMON_INVALID_STRINGLEN;
				}
				else
				{
					lpFieldBson->m_bCharLen = (BYTE)nCharLen;
				}
			}
			else
			{
				return MF_PARSECMD_INVALID_NUMBER_ERROR;
			}
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			if(strItem != ")")
			{
				return MF_PARSECMD_ALTER_LACK_BRACE_ERROR;
			}
		}
		else
		{
			//字段类型错误
			return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
		}
		i++;
		if(i >= nEndPos)
		{
			return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
		}
		strItem = vecString[i];
		strItem.MakeUpper();
		if(strItem == "NOT")
		{
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			strItem.MakeUpper();
			if(strItem == "NULL")
			{
				lpFieldBson->m_bAllowNull = 0;
			}
			else
			{
				return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
			}
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
			}
			strItem = vecString[i];
		}
		if(strItem == ",")
		{
			lpAlterObjectFieldBson->m_nFieldNum++;
		}
		else if(strItem == ")")
		{
			lpAlterObjectFieldBson->m_nFieldNum++;
			if(i + 1 < nEndPos)
			{
				return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
			}
			break;
		}
		else
		{
			return MF_PARSECMD_ALTER_LACK_BRACE_ERROR;
		}
	}
	
	return MF_OK;
}	


/************************************************************************
	功能说明：
		解析添加字段
	参数说明：
		vecString：字符串数组
		stBson：Bson对象
		lpAlterObjectFieldBson：修改对象字段
		nStartPos：起始位置
		nEndPos：结束位置
************************************************************************/
int CParseSql::ParseDropField(vector<CMFString> vecString, CBaseBson& stBson, LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson, int nStartPos, int nEndPos)
{
	//为删除列命令
	CMFString strItem;
	int nFieldNum, i, nRet;
	UINT nOffset, nPreOffset;
	LPOBJECTFIELDDEFBSON lpFieldBson;
	
	nFieldNum = 1;
	for(i = nStartPos;i < nEndPos;i++)
	{
		strItem = vecString[i];
		if(strItem == ",")
		{
			nFieldNum++;
		}
	}
	lpAlterObjectFieldBson->m_nFieldNum = nFieldNum;

	nPreOffset = 0;
	for(i = nStartPos;i < nEndPos;i++)
	{
		//创建字段结构体
		nRet = stBson.AllocFromBsonBuffer(lpFieldBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(nPreOffset != 0)
		{
			LPOBJECTFIELDDEFBSON lpPreFieldBson = (LPOBJECTFIELDDEFBSON)(stBson.ConvertOffset2Addr(nPreOffset));
			lpPreFieldBson->m_nNextOffset = nOffset;
		}
		else
		{
			lpAlterObjectFieldBson->m_nFieldOffset = nOffset;
		}
		nPreOffset = nOffset;

		//获取字段名
		strItem = vecString[i];
		if(CopyNameFromSql(strItem.c_str(), strItem.length(), lpFieldBson->m_bFieldName) == 0)
		{
			return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
		}

		i++;
		if(i >= nEndPos)
		{
			return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		解析对象删除
	参数说明：
		vecString：字符串数组
		stBson：Bson对象
************************************************************************/
int CParseSql::ParseCommonDelete(vector<CMFString> &vecString, CBaseBson& stBson)
{
	UINT nOffset;
	string strSql;
	LPBYTE lpAddr;
	int i, nRet, nLen;
	CMFString strItem;
	char pObjectName[32];
	queue<int> queCompareQueue;	
	LPEXECUTEPLANBSON lpExecutePlan;
	LPOBJECTNAMEBSON pObjectNameBson;
	stack<LPMATHOPERATOR> skOperatorStack;
	queue<LPEXPFIELDBSON_MIXQUEUENODE> queMathQueue;
	LPDELETEEXECUTEPLANBSON lpDeleteExecutePlanBson;
	queue<LPCONDITIONBSON_MIXQUEUENODE> queConditionQueue;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	nRet = stBson.AllocFromBsonBuffer(lpDeleteExecutePlanBson, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlan->m_nCommandOffset = nOffset;
	lpExecutePlan->m_bObjectType    = MF_OBJECT_COMMON;

	//FROM后面一定是对象名
	strItem = vecString[1];
	if(0 == CopyNameFromSql(strItem.c_str(), strItem.length(), pObjectName))
	{
		return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
	}
	else
	{
		nLen = strItem.length();
		lpAddr = NULL;
		nRet = stBson.AllocFromBsonBuffer(sizeof(OBJECTNAMEBSON)+nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pObjectNameBson = (LPOBJECTNAMEBSON)lpAddr;
		pObjectNameBson->m_bLen = nLen+1;
		memcpy(pObjectNameBson->m_pObjectName, pObjectName, nLen+1);
		lpDeleteExecutePlanBson->m_nObjectNameOffset = nOffset;
	}
	//对象名后面一定是WHERE或者EOF
	strItem = vecString[2];
	strItem.MakeUpper();
	if(strItem == "EOF")
	{
		return MF_OK;
	}
	else if(strItem == "WHERE")
	{
		i = 3;
		nRet = ParseCondition(vecString, stBson, nOffset, NULL, skOperatorStack, queMathQueue, 
			queCompareQueue, queConditionQueue, i, vecString.size()-1);
		//不论是否执行成功，都需要先释放skOperatorStack、queMathQueue和queConditionQueue
		FreeStack(skOperatorStack);
		FreeQueue(queMathQueue);
		FreeQueue(queConditionQueue);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpDeleteExecutePlanBson->m_nWhereOffset = nOffset;
	}
	else
	{
		return MF_PARSECMD_INVALID_DELETE_SYNTAX_ERROR;
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		创建查询条件树
	参数说明：
		pFieldCondition：查询条件
		queMixQueue：混合队列
************************************************************************/
int CParseSql::CreateCondition(UINT& nConditionOffset, CBaseBson& stBson, queue<LPCONDITIONBSON_MIXQUEUENODE>& queMixQueue)
{
	int nRet;
	UINT nOffset;
	LPCOMPAREEXPBSON lpCompareExpBson;
	LPBASECONDITIONBSON lpConditonBson;
	LPCONDITIONBSON_MIXQUEUENODE lpQueueNode;
	stack<LPCONDITIONSTACKNODEBSON> skConditionStack;
	LPCONDITIONSTACKNODEBSON lpConditionNode, lpLogicNode1, lpLogicNode2, lpLogicNode;

	if(queMixQueue.empty())
	{
		//没有查询条件
		nConditionOffset = 0;
		return MF_OK;
	}
	
	while(!queMixQueue.empty())
	{
		lpQueueNode = queMixQueue.front();	
		if(1 == lpQueueNode->m_bOperator)
		{
			if(MF_EXECUTEPLAN_OPERATOR_NOT == lpQueueNode->m_bLogicOP)
			{
				lpConditionNode = skConditionStack.top();
				if(lpConditionNode->m_bConditionType == 0)
				{
					lpCompareExpBson = (LPCOMPAREEXPBSON)stBson.ConvertOffset2Addr(lpConditionNode->m_nCompareExpOffset);
					lpCompareExpBson->m_bLogicNot = 1;
				}
				else
				{
					lpConditonBson = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpConditionNode->m_nWhereOffset);
					lpConditonBson->m_bLogicNot = 1;		
				}
			}
			else
			{	
				//如果不是NOT，则需要将逻辑栈的前两个元素弹栈，然后根据根据逻辑运算符填充LPEXECUTEPLANLOGICOPERATOR结构体
				//并将LPEXECUTEPLANLOGICOPERATOR再压入逻辑栈
				nRet = stBson.AllocFromBsonBuffer(lpConditonBson, nOffset);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpConditonBson->m_bLogicNot = 0;
				lpConditonBson->m_bLogicOperator = lpQueueNode->m_bLogicOP;

				//将栈顶的两个元素弹栈(注意：先出栈的是条件二，后出栈的是条件1)
				lpLogicNode2 = skConditionStack.top();
				skConditionStack.pop();
				lpLogicNode1 = skConditionStack.top();
				skConditionStack.pop();

				//条件一
				if(lpLogicNode1->m_bConditionType == 0)								//m_FieldCondition有效
				{
					lpConditonBson->m_bConditionType1	= MF_CONDITION_COMPARE;
					lpConditonBson->m_nConditionOffset1 = lpLogicNode1->m_nCompareExpOffset;
				}
				else
				{
					lpConditonBson->m_bConditionType1	= MF_CONDITION_LOGIC;		//m_pCondition有效
					lpConditonBson->m_nConditionOffset1 = lpLogicNode1->m_nWhereOffset;
				}

				//条件二
				if(lpLogicNode2->m_bConditionType == 0)								//m_FieldCondition有效
				{
					lpConditonBson->m_bConditionType2	= MF_CONDITION_COMPARE;
					lpConditonBson->m_nConditionOffset2 = lpLogicNode2->m_nCompareExpOffset;
				}
				else
				{
					lpConditonBson->m_bConditionType2	= MF_CONDITION_LOGIC;		//m_pCondition有效
					lpConditonBson->m_nConditionOffset2 = lpLogicNode2->m_nWhereOffset;
				}
				delete lpLogicNode1;
				lpLogicNode1 = NULL;
				delete lpLogicNode2;
				lpLogicNode2 = NULL;

				lpLogicNode = new CONDITIONSTACKNODEBSON;
				lpLogicNode->m_bConditionType = 1;
				lpLogicNode->m_nWhereOffset = nOffset;
				skConditionStack.push(lpLogicNode);				//将pExecuteOP压栈
			}
		}
		else
		{
			//如果不是符号，则直接将元素弹出混合队列，并压入逻辑栈
			lpLogicNode = new CONDITIONSTACKNODEBSON;
			lpLogicNode->m_bConditionType = 0;
			lpLogicNode->m_nCompareExpOffset = lpQueueNode->m_nCompareExpOffset;
			skConditionStack.push(lpLogicNode);
		}
		queMixQueue.pop();									//将该元素弹出混合队列
		delete lpQueueNode;
		lpQueueNode = NULL;
	}

	//循环完毕后，逻辑栈中一定有且仅有一个结点，将该结点弹出
	if(1 != skConditionStack.size())
	{
		FreeStack(skConditionStack);
		FreeQueue(queMixQueue);
		return MF_CREATELOGIC_INVALID_LOGICSTACK_ERROR;
	}
	else
	{
		lpLogicNode = skConditionStack.top();
		if(lpLogicNode->m_bConditionType == 0)
		{
			//说明该结点是一个EXECUTEPLANFIELDCONDITION结构体，那么应该将其封装成LPEXECUTEPLANLOGICOPERATOR结构体
			nRet = stBson.AllocFromBsonBuffer(lpConditonBson, nConditionOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpConditonBson->m_bConditionType1	= MF_CONDITION_COMPARE;
			lpConditonBson->m_bConditionType2	= MF_CONDITION_INVALID;
			lpConditonBson->m_bLogicNot			= 0;
			lpConditonBson->m_bLogicOperator	= 0;
			lpConditonBson->m_nConditionOffset1 = lpLogicNode->m_nCompareExpOffset;
		}
		else
		{
			nConditionOffset = lpLogicNode->m_nWhereOffset;
		}
		skConditionStack.pop();
		delete lpLogicNode;
		lpLogicNode = NULL;
	}
	return MF_OK;
}
/************************************************************************   
	功能说明：
		符号弹栈处理
	特别说明：
		处理符号弹栈后的一系列操作
************************************************************************/
int CParseSql::OperatorPop(CBaseBson &stBson, BOOL& bCompareOp, BOOL& bBetween, BOOL& bAnd, BOOL& bFiled, 
						   stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMathQueue, 
						   queue<int>& queCompareQueue, queue<LPCONDITIONBSON_MIXQUEUENODE>& queConditionQueue)
{
	int nRet;
	UINT nOffset;
	LPCOMPAREEXPBSON lpCompareExp;
	LPEXPFIELDBSON_MIXQUEUENODE lpMixNode;
	LPCONDITIONBSON_MIXQUEUENODE lpConditonNode;

	if(skOperatorStack.top()->m_bType == OPERATOR_COMPARE)
	{
		bCompareOp = FALSE;
		nRet = stBson.AllocFromBsonBuffer(lpCompareExp, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpCompareExp->m_bOperator = skOperatorStack.top()->m_bMathOp;
		if(skOperatorStack.top()->m_bMathOp == MF_EXECUTEPLAN_OPERATOR_BETWEEN)
		{
			bBetween = FALSE;
			//BETWEEN弹栈，那么之前一定有AND
			if(!bAnd)
			{
				return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
			}
			bAnd = FALSE;
			//BETWEEN弹栈，那么queCompareQueue中一定有两个元素
			if(2 != queCompareQueue.size())
			{
				return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
			}

			lpCompareExp->m_nMathExpOffset1 = queCompareQueue.front();
			lpCompareExp->m_bExpressionType1 = CBaseExpression::GetExpressionType(lpCompareExp->m_nMathExpOffset1, stBson);
			queCompareQueue.pop();
			lpCompareExp->m_nMathExpOffset2 = queCompareQueue.front();
			lpCompareExp->m_bExpressionType2 = CBaseExpression::GetExpressionType(lpCompareExp->m_nMathExpOffset2, stBson);
			queCompareQueue.pop();

			//计算queMathQueue中的表达式，作为pFieldConditon的表达式3
			nRet = CreateMathExpression(lpCompareExp->m_nMathExpOffset3, stBson, queMathQueue);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpCompareExp->m_bExpressionType3 = CBaseExpression::GetExpressionType(lpCompareExp->m_nMathExpOffset3, stBson);
		}
		else if(skOperatorStack.top()->m_bMathOp == MF_EXECUTEPLAN_OPERATOR_IN || skOperatorStack.top()->m_bMathOp == MF_EXECUTEPLAN_OPERATOR_NOTIN)
		{
			int nOffset1, nOffset2;
			MF_EXPRESSIONTYPE bType1, bType2;
			//比较运算符弹栈，那么queCompareQueue中一定只有1个元素
			if(2 != queCompareQueue.size())
			{
				return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
			}
			nOffset1 = queCompareQueue.front();
			bType1 = CBaseExpression::GetExpressionType(nOffset1, stBson);
			queCompareQueue.pop();
			nOffset2 = queCompareQueue.front();
			bType2 = MF_EXPRESSION_AGGREMATH;
			queCompareQueue.pop();

			lpCompareExp->m_nMathExpOffset1 = nOffset1;
			lpCompareExp->m_nMathExpOffset2 = nOffset2;
			lpCompareExp->m_bExpressionType1 = bType1;
			lpCompareExp->m_bExpressionType2 = bType2;
		}
		else
		{
			UINT nOffset1, nOffset2;
			MF_EXPRESSIONTYPE bType1, bType2;
			LPMATHEXPBSON lpMathBson1, lpMathBson2;
			LPMATHEXPELEMENTBSON lpFieldBson1, lpFieldBson2;
			//比较运算符弹栈，那么queCompareQueue中一定只有1个元素
			if(1 != queCompareQueue.size())
			{
				return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
			}
			nOffset1 = queCompareQueue.front();
			bType1 = CBaseExpression::GetExpressionType(nOffset1, stBson);
			queCompareQueue.pop();
			//计算queMathQueue中的表达式，作为pFieldConditon的表达式2
			nRet = CreateMathExpression(nOffset2, stBson, queMathQueue);
			if(nRet != MF_OK)
			{
				return nRet;
			}
	
			if(lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_RPRIOR)
			{
				bType2 = CBaseExpression::GetExpressionType(nOffset2, stBson);
				lpMathBson1 = (LPMATHEXPBSON)stBson.ConvertOffset2Addr(nOffset1);
				if(lpMathBson1->m_bOperator != MF_EXECUTEPLAN_OPERATOR_NULL)
				{
					return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
				}
				lpFieldBson1 = (LPMATHEXPELEMENTBSON)stBson.ConvertOffset2Addr(lpMathBson1->m_nExpOffset1);

				lpMathBson2 = (LPMATHEXPBSON)stBson.ConvertOffset2Addr(nOffset2);
				if(lpMathBson2->m_bOperator != MF_EXECUTEPLAN_OPERATOR_NULL)
				{
					return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
				}
				lpFieldBson2 = (LPMATHEXPELEMENTBSON)stBson.ConvertOffset2Addr(lpMathBson2->m_nExpOffset1);
				if(strcmp(lpFieldBson1->m_bDataBuffer, lpFieldBson2->m_bDataBuffer) == 0)
				{
					//PID和ID的字段名不能相同
					return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
				}
				
				lpCompareExp->m_bOperator = MF_EXECUTEPLAN_OPERATOR_PRIOR;
				lpCompareExp->m_nMathExpOffset1 = nOffset2;
				lpCompareExp->m_nMathExpOffset2 = nOffset1;
				lpCompareExp->m_bExpressionType1 = bType2;
				lpCompareExp->m_bExpressionType2 = bType1;
			}
			else 
			{
				bType2 = CBaseExpression::GetExpressionType(nOffset2, stBson);
				if(lpCompareExp->m_bOperator == MF_EXECUTEPLAN_OPERATOR_LPRIOR)
				{
					lpMathBson1 = (LPMATHEXPBSON)stBson.ConvertOffset2Addr(nOffset1);
					if(lpMathBson1->m_bOperator != MF_EXECUTEPLAN_OPERATOR_NULL)
					{
						return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
					}
					lpFieldBson1 = (LPMATHEXPELEMENTBSON)stBson.ConvertOffset2Addr(lpMathBson1->m_nExpOffset1);

					lpMathBson2 = (LPMATHEXPBSON)stBson.ConvertOffset2Addr(nOffset2);
					if(lpMathBson2->m_bOperator != MF_EXECUTEPLAN_OPERATOR_NULL)
					{
						return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
					}
					lpFieldBson2 = (LPMATHEXPELEMENTBSON)stBson.ConvertOffset2Addr(lpMathBson2->m_nExpOffset1);
					if(strcmp(lpFieldBson1->m_bDataBuffer, lpFieldBson2->m_bDataBuffer) == 0)
					{
						//PID和ID的字段名不能相同
						return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
					}
					lpCompareExp->m_bOperator = MF_EXECUTEPLAN_OPERATOR_PRIOR;
				}
				lpCompareExp->m_nMathExpOffset1 = nOffset1;
				lpCompareExp->m_nMathExpOffset2 = nOffset2;
				lpCompareExp->m_bExpressionType1 = bType1;
				lpCompareExp->m_bExpressionType2 = bType2;
			}
		}
		lpConditonNode = new CONDITIONBSON_MIXQUEUENODE;

		lpConditonNode->m_bOperator = 0;
		lpConditonNode->m_nCompareExpOffset = nOffset;
		queConditionQueue.push(lpConditonNode);
	}
	else if(skOperatorStack.top()->m_bType == OPERATOR_MATH || skOperatorStack.top()->m_bType == OPERATOR_FUNCTION)
	{
		lpMixNode = new EXPFIELDBSON_MIXQUEUENODE;
		lpMixNode->m_bOperator = 1;
		lpMixNode->m_bMathOp = skOperatorStack.top()->m_bMathOp;
		queMathQueue.push(lpMixNode);
	}
	else
	{
		//逻辑运算符弹栈，直接压入
		lpConditonNode = new CONDITIONBSON_MIXQUEUENODE;
		lpConditonNode->m_bOperator = 1;
		lpConditonNode->m_bLogicOP = skOperatorStack.top()->m_bMathOp;
		queConditionQueue.push(lpConditonNode);
	}
	delete skOperatorStack.top();
	skOperatorStack.pop();

	return MF_OK;
}

/************************************************************************   
	功能说明：
		符号入栈处理
	特别说明：
		处理符号入栈后的一系列操作
************************************************************************/
int CParseSql::OperatorPush(LPMATHOPERATOR lpMathOp, CBaseBson& stBson, BOOL& bCompareOp, BOOL& bBetween, BOOL& bAnd, BOOL& bExpression, 
							stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMathQueue, queue<int>& queCompareQueue,
							queue<LPCONDITIONBSON_MIXQUEUENODE>& queConditionQueue)
{
	int nRet;
	UINT nExpBsonOffset;
	//判断运算符类型
	if(OPERATOR_COMPARE == lpMathOp->m_bType)
	{
		//比较运算符有两种情况:1.A > B 2.A BETWEEN B AND C
		//1.A > B 形式：运算符入栈时计算A 运算符出栈时计算B
		//2.A BETWEEN B AND C 形式：BETWEEN入栈时候 计算表达式A AND入栈时计算表达式B BETWEEN出栈时计算表达式C
		if(bCompareOp)
		{
			//一个比较表达式中只能有一个比较运算符
			return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;		
		} 
		else
		{
			bCompareOp = TRUE;
			if(lpMathOp->m_bMathOp == MF_EXECUTEPLAN_OPERATOR_BETWEEN)
			{
				bBetween = TRUE;
			}
			nRet = CreateMathExpression(nExpBsonOffset, stBson, queMathQueue);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			queCompareQueue.push(nExpBsonOffset);
		}
	}
	else if(bBetween && MF_EXECUTEPLAN_OPERATOR_AND == lpMathOp->m_bMathOp)
	{	
		//BETWEEN AND 形式如果有BETWEEN的话，一定有AND
		bBetween = FALSE;
		bAnd = TRUE;		
		nRet = CreateMathExpression(nExpBsonOffset, stBson, queMathQueue);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		queCompareQueue.push(nExpBsonOffset);	
		return MF_OK;
	}
	else if(MF_EXECUTEPLAN_OPERATOR_AND == lpMathOp->m_bMathOp || MF_EXECUTEPLAN_OPERATOR_OR == lpMathOp->m_bMathOp)
	{
		if(queMathQueue.size() != 0)
		{
			return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
		}
	}
	bExpression = TRUE;
	skOperatorStack.push(lpMathOp);
	return MF_OK;
}
/************************************************************************
	功能说明：
		解析查询条件
	参数说明：
		vecString：SQL语句字符串
		stBson：Bson
		nConditionOffset:查询条件偏移
		skOperatorStack:符号栈
		queMathQueue：算数表达式队列
		queCompareQueue：比较表达式队列(存放COMPAREEXPBSON的偏移)
		queConditionQueue：查询条件队列
		nStartPos：查询字段子句的起始位置
		nEndPos：查询字段句的结束位置
************************************************************************/
int CParseSql::ParseCondition(vector<CMFString>& vecString, CBaseBson& stBson, UINT& nConditionOffset, char* pObjectTitle,
							  stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMathQueue,
							  queue<int>& queCompareQueue, queue<LPCONDITIONBSON_MIXQUEUENODE>& queConditionQueue,
							  int nStartPos, int nEndPos)
{
	char pFieldName[32];
	LPMATHOPERATOR lpMathOp;
	LPBASECONDITIONBSON lpWhereConditon;
	LPEXPFIELDBSON_MIXQUEUENODE lpQueueNode;
	CMFString strExpression, strItem, strTempItem;
	BYTE bFunType, bOperator, bMathOP, bRetValueType, bPriorNum;
	int  i, nRet, nLeftBracketNum, nRightBracketNum, nFunEndPos, nExpFieldOffset;
	BOOL bFiled, bAggregateFun, bCompareOp, bBetween, bAnd, bExpression, bTemp, bFun, bPrior;
	//将条件字段转换成EXECUTEPLANFIELDCONDITION结构体
	//同时将字段表达式转换为后缀表达式
	//查询字段不能为空

	bFiled				= FALSE;
	bAggregateFun		= FALSE;
	bCompareOp			= FALSE;
	bBetween			= FALSE;
	bAnd				= FALSE;
	bExpression			= FALSE;
	bTemp				= FALSE;
	bBetween			= FALSE;
	bFun				= FALSE;
	bPrior				= FALSE;
	bPriorNum			= 0;
	nLeftBracketNum		= 0;
	nRightBracketNum	= 0;
	if(nEndPos == nStartPos)
	{
		return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
	}
	
	//表达式第一位不能是双目运算符或右括号
	if(MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE == CheckValidOperator(vecString, nStartPos) || vecString[nStartPos] == ")")
	{
		return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
	}

	for(i = nStartPos; i < nEndPos; i++)
	{
		strItem = vecString[i];
		if(strItem == (")"))							
		{
			//")"的左边，不能是"("运算符，")"的右边不能是单目运算符
			if(CheckValidOperator(vecString, i - 1) || "(" == vecString[i - 1] || MF_EXECUTEPLAN_OPERATORTYPE_SINGLE == CheckValidOperator(vecString, i + 1))
			{
				return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
			}
			nRightBracketNum++;
			//如果字段为右括号，则对符号栈中左括号之前的所有符号进行弹栈，并压入混合队列中
			strExpression += ")";
			while((bOperator = skOperatorStack.top()->m_bMathOp) != MF_EXECUTEPLAN_OPERATOR_LEFTBRACKET)
			{
				nRet = OperatorPop(stBson, bCompareOp, bBetween, bAnd, bFiled, skOperatorStack, 
								   queMathQueue, queCompareQueue, queConditionQueue);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}

			//将左括号弹栈	
			delete skOperatorStack.top();
			skOperatorStack.pop();							
		}
		else if(strItem == ("("))
		{	
			//"("的右边，不能是")"或双目运算符或结束符
			if(MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE == CheckValidOperator(vecString, i+1) || ")" == vecString[i + 1] || i == nEndPos)
			{
				return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
			}
			nLeftBracketNum++;
			strExpression += "(";
			lpMathOp = new MATHOPERATOR(MF_EXECUTEPLAN_OPERATOR_LEFTBRACKET);
			skOperatorStack.push(lpMathOp);						//左括号直接进行压栈
		}
		else if(nRet = CheckValidOperator(vecString, i ,TRUE))
		{
			if(nRet == MF_EXECUTEPLAN_OPERATORTYPE_INVALID)
			{
				return MF_COMMON_INVALID_OPERATOR;
			}

			//所有运算符的右边都不能是双目运算符或者")" 或者结束符
			if(MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE == CheckValidOperator(vecString, i + 1) || vecString[i + 1] == ")" || i == nEndPos)
			{
				return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
			}

			//其中单目运算符左边不能是")"
			if(nRet == MF_EXECUTEPLAN_OPERATORTYPE_SINGLE)
			{
				if(vecString[i - 1] == ")")
				{
					return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
				}
			}
			else if(nRet == MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE)
			{
				if(CheckValidOperator(vecString, i - 1) == MF_EXECUTEPLAN_OPERATORTYPE_DOUBLE && vecString[i - 1] == "(")
				{
					//双目运算符左边不能是运算符或"("
					return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
				}
			}
			else if(nRet == MF_EXECUTEPLAN_OPERATORTYPE_PRIOR)
			{
				if(vecString[i - 1] != "BY")
				{
					//PRIOR的左边一定是BY
					return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
				}
				else
				{
					bPrior = TRUE;
					continue;
				}
			}
			
			bMathOP = ConvertMathOperatorStrtoByte(strItem);
			if(!bMathOP)
			{
				return MF_PARSECMD_INVALID_OPERATOR_ERROR;
			}
			if(bPrior)
			{
				//PRIOR之后的第一个运算符一定是等号
				if(bMathOP != MF_EXECUTEPLAN_OPERATOR_EQUAL)
				{
					return MF_PARSECMD_INVALID_OPERATOR_ERROR;
				}
				else
				{
					bMathOP = MF_EXECUTEPLAN_OPERATOR_LPRIOR;
					bPrior = FALSE;
				}
			}
			if(MF_EXECUTEPLAN_OPERATOR_EQUAL == bMathOP)
			{
				//等号右边有可能存在PIROR运算符
				if(vecString[i + 1] == "PRIOR")
				{
					if(bPriorNum != 0)
					{
						//只能有一个PRIOR符号
						return MF_PARSECMD_INVALID_OPERATOR_ERROR;
					}
					i++;
					bPriorNum++;
					bMathOP = MF_EXECUTEPLAN_OPERATOR_RPRIOR;
				}
			}
			else if(MF_EXECUTEPLAN_OPERATOR_MINUS == bMathOP)
			{
				//"-"存在单目运算符情况，所以要加以判断
				if(i == nStartPos || vecString[i-1] == "(" || CheckValidOperator(vecString, i-1))
				{
					bMathOP = MF_EXECUTEPLAN_OPERATOR_SIGNMINUS;
				}
			}
			else if(MF_EXECUTEPLAN_OPERATOR_LIKE == bMathOP)
			{
				//LIKE情况不支持四则运算，并且只能是字段名LIKE字符串形式
				//LIKE前必须是字段名
				if(!CopyNameFromSql(vecString[i - 1].c_str(), vecString[i - 1].length(), pFieldName))
				{
					return MF_PARSECMD_FIELDNAME_SYNTAX_ERROR;
				}
				//字段名前面必须是WHERE，AND,OR 或者'('
				strTempItem = vecString[i - 2];
				strTempItem.MakeUpper();
				if(strTempItem != "WHERE" && strTempItem != "OR" && strTempItem != "AND" && strTempItem != "(")
				{
					return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
				}
				//LIKE后必须是字符串
				if(!CheckValidStr(vecString[i + 1].c_str(), vecString[i + 1].length()))
				{
					return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
				}
			
				//字符串后必须是AND、OR或者结束符
				strTempItem = vecString[i + 2];
				strTempItem.MakeUpper();
				if(i+2 != nEndPos && strTempItem != "OR" && strTempItem != "AND")
				{
					return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
				}
			}
			else if(bMathOP == MF_EXECUTEPLAN_OPERATOR_NOT)
			{
				if(vecString[i + 1] == "IN")
				{
					i++;
					bMathOP = MF_EXECUTEPLAN_OPERATOR_NOTIN;
				}
			}
			lpMathOp = new MATHOPERATOR(bMathOP);
			strExpression += strItem;

			//对逻辑运算符执行压栈操作
			//步骤：1、比较当前运算符与符号栈顶运算符的优先级，如果优先级高于栈顶运算符，则直接压栈
			//		2、如果优先级比栈顶运算符低，则将栈中所有优先级高于当前运算符的运算符弹栈，同时压入混合队列
			if(skOperatorStack.empty() || lpMathOp->m_bPriority > skOperatorStack.top()->m_bPriority || MF_EXECUTEPLAN_OPERATOR_LEFTBRACKET == skOperatorStack.top()->m_bMathOp)
			{
				nRet = OperatorPush(lpMathOp, stBson, bCompareOp, bBetween, bAnd, bExpression,
								    skOperatorStack, queMathQueue, queCompareQueue, queConditionQueue);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
			else if(bBetween && MF_EXECUTEPLAN_OPERATOR_AND == lpMathOp->m_bMathOp)
			{
				//将符号栈中BETWEEN之前的符号弹栈并压入混合栈，然后将AND符号压入混合栈
				while((!skOperatorStack.empty()) && skOperatorStack.top()->m_bMathOp != MF_EXECUTEPLAN_OPERATOR_BETWEEN)
				{
					nRet = OperatorPop(stBson, bCompareOp, bBetween, bAnd, bFiled, 
						skOperatorStack, queMathQueue, queCompareQueue, queConditionQueue);
					if(nRet != MF_OK)
					{
						return nRet;
					}
				}
				nRet = OperatorPush(lpMathOp, stBson, bCompareOp, bBetween, bAnd, bExpression,
					skOperatorStack, queMathQueue, queCompareQueue, queConditionQueue);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
			else
			{
				do 
				{
					nRet = OperatorPop(stBson, bCompareOp, bBetween, bAnd, bFiled, 
									   skOperatorStack, queMathQueue, queCompareQueue, queConditionQueue);
					if(nRet != MF_OK)
					{
						return nRet;
					}
				}while ((!skOperatorStack.empty()) && lpMathOp->m_bPriority <= skOperatorStack.top()->m_bPriority);
				//符号压栈
				nRet = OperatorPush(lpMathOp, stBson, bCompareOp, bBetween, bAnd, bExpression,
									skOperatorStack, queMathQueue, queCompareQueue, queConditionQueue);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}

			if(bMathOP == MF_EXECUTEPLAN_OPERATOR_IN || bMathOP == MF_EXECUTEPLAN_OPERATOR_NOTIN)
			{
				//IN或者NOTIN的情况，对后面表达式进行单独解析
				i++;
				nRet = ParseInCondition(vecString, stBson, queCompareQueue, i);
				if(nRet != MF_OK)
				{
					return nRet;
				}
			}
		}
		else if(bFunType = CheckValidFunction(vecString, i))
		{
			bFun = TRUE;			//注意bFun和bAggregateFun的区别：bFun用于标识是否包含函数，bAggregateFun用于标识是否包含聚合函数，bAggregateFun用于判断SQL语句是否出现集合函数和字段同时出现的情况，bFun用于判断是否进行查询条件的优化
			if(bFunType == MF_EXECUTEPLAN_OPERATOR_COUNT)
			{	
				bAggregateFun = TRUE;
			}
			nRet = ParseFunction(vecString, bFunType, stBson, skOperatorStack, queMathQueue, 
								 strExpression, bRetValueType, i, nFunEndPos);
			if(nRet != MF_OK)
			{
				return nRet;
			}

			//返回值类型为空的函数不能存在于四则运算中
			if(MF_COMPATIBLE_DATA_NULL == bRetValueType)
			{
				if(bExpression || nEndPos != nFunEndPos+1)
				{
					return MF_PARSECMD_INVALID_OPERATOR_ERROR;
				}
			}
			//判断语法是否正确：函数后面只能是运算符、")"、结束符
			if(nFunEndPos+1 != nEndPos && !CheckValidOperator(vecString, nFunEndPos+1) && vecString[nFunEndPos+1] != ")")
			{
				return MF_PARSECMD_INVALID_OPERATOR_ERROR;
			}
			i = nFunEndPos;
		}
		else																		//字段为执行条件
		{
			//解析表达式值并填充LPMATHEXPRESSIONFIELD结构体然后将LPMATHEXPRESSIONFIELD压入混合队列
			nRet = ParseMathFieldValue(vecString, stBson, nExpFieldOffset, pObjectTitle, strExpression, bFiled, i, nEndPos);	
			if(nRet != MF_OK)
			{
				return nRet;
			}
			//将LPMATHEXPRESSIONFIELD压入混合队列
			lpQueueNode = new EXPFIELDBSON_MIXQUEUENODE;
			lpQueueNode->m_bOperator = 0;
			lpQueueNode->m_nExpFieldOffset = nExpFieldOffset;
			queMathQueue.push(lpQueueNode);
		}
	}

	//括号不匹配错误
	if(nLeftBracketNum != nRightBracketNum)
	{
		return MF_PARSECMD_INVALID_SELECT_SYNTAX_ERROR;
	}

	//将符号栈中剩余符号压人混合队列
	while(!skOperatorStack.empty())
	{
		nRet = OperatorPop(stBson, bCompareOp, bBetween, bAnd, bFiled, 
						   skOperatorStack, queMathQueue, queCompareQueue, queConditionQueue);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}

	//聚合函数和字段不能同时出现(目前暂不支持GroupBy)
	if(bFiled && bAggregateFun)
	{
		return MF_PARSECMD_INVALID_EXPRESSION_ERROR;
	}

	//查询条件表达式
	nRet = CreateCondition(nConditionOffset, stBson, queConditionQueue);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	
	//如果查询条件中包含字段或者函数(不论是否为聚合函数)不考虑进行优化
	if(!bFiled && !bFun)
	{
		if(nConditionOffset == 0)
		{
			return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
		}	
		lpWhereConditon = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(nConditionOffset);
		nRet = GetConditionResult(stBson, lpWhereConditon, bTemp);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		if(bTemp)
		{
			//如果查询条件恒为真，则在服务端直接进行全表遍历
			nConditionOffset = 0;
		}
		else
		{
			//如果查询条件恒为假，则在服务端直接返回空结果集
			nConditionOffset = -1;
		}
	}
	return MF_OK;
}

/************************************************************************
	功能说明：
		解析分页
	参数说明：
		vecString：SQL语句字符串
		lpQueryPlan：查询执行计划
		nStartPos：开始位置
		nEndPos：结束位置
************************************************************************/
int CParseSql::ParsePaging(vector<CMFString>& vecString, LPQUERYEXECUTEPLANBSON lpQueryPlan, int nStartPos, int nEndPos)
{
	int i;
	CMFString strItem;

	lpQueryPlan->m_bPageType = MF_PAGING_FIRST;

	i = nStartPos;
	strItem = vecString[i];
	if(strItem != "(")
	{
		return MF_PARSESELECT_INVALID_PAGING_ERROR;
	}
	i++;
	strItem = vecString[i];
	strItem.MakeUpper();
	if(strItem == "PAGESIZE")
	{
		i++;
		strItem = vecString[i];
		if(strItem != "=")
		{
			return MF_PARSESELECT_INVALID_PAGING_ERROR;
		}
		i++;
		strItem = vecString[i];
		if(1 == IsNumber(strItem.c_str()))
		{
			lpQueryPlan->m_nPageSize = atoi(strItem.c_str());
		}
		else
		{
			return MF_PARSESELECT_INVALID_PAGING_ERROR;
		}
		
		i++;
		strItem = vecString[i];
		if(strItem != ",")
		{
			return MF_PARSESELECT_INVALID_PAGING_ERROR;
		}

		i++;
		strItem = vecString[i];
		if(strItem == "PAGENO")
		{
			i++;
			strItem = vecString[i];
			if(strItem != "=")
			{
				return MF_PARSESELECT_INVALID_PAGING_ERROR;
			}

			i++;
			strItem = vecString[i];
			if(1 == IsNumber(strItem.c_str()))
			{
				lpQueryPlan->m_nPageNo = atoi(strItem.c_str());
			}
			else
			{
				return MF_PARSESELECT_INVALID_PAGING_ERROR;
			}
		}
		else
		{
			return MF_PARSESELECT_INVALID_PAGING_ERROR;
		}
	}
	else if(strItem == "PAGENO")
	{
		i++;
		strItem = vecString[i];
		if(strItem != "=")
		{
			return MF_PARSESELECT_INVALID_PAGING_ERROR;
		}

		i++;
		strItem = vecString[i];
		if(1 == IsNumber(strItem.c_str()))
		{
			lpQueryPlan->m_nPageNo = atoi(strItem.c_str());
		}
		else
		{
			return MF_PARSESELECT_INVALID_PAGING_ERROR;
		}
		
		i++;
		strItem = vecString[i];
		if(strItem != ",")
		{
			return MF_PARSESELECT_INVALID_PAGING_ERROR;
		}

		i++;
		strItem = vecString[i];
		if(strItem == "PAGESIZE")
		{
			i++;
			strItem = vecString[i];
			if(strItem != "=")
			{
				return MF_PARSESELECT_INVALID_PAGING_ERROR;
			}

			i++;
			strItem = vecString[i];
			if(1 == IsNumber(strItem.c_str()))
			{
				lpQueryPlan->m_nPageSize = atoi(strItem.c_str());
			}
			else
			{
				return MF_PARSESELECT_INVALID_PAGING_ERROR;
			}
		}
		else
		{
			return MF_PARSESELECT_INVALID_PAGING_ERROR;
		}
	}
	else
	{
		return MF_PARSESELECT_INVALID_PAGING_ERROR;
	}
	i++;
	strItem = vecString[i];
	if(strItem != ")")
	{
		return MF_PARSESELECT_INVALID_PAGING_ERROR;
	}


	return MF_OK;
}
/************************************************************************
	功能说明：
		解析查询条件
	参数说明：
		vecString：SQL语句字符串
		stBson：Bson
		nConditionOffset:查询条件偏移
		skOperatorStack:符号栈
		queMathQueue：算数表达式队列
		nStartPos：查询字段子句的起始位置
		nEndPos：查询字段句的结束位置
************************************************************************/
int CParseSql::ParseInCondition(vector<CMFString>& vecString, CBaseBson& stBson, queue<int>& queCompareQueue, int& nStartPos)
{
	UINT nOffset;
	LPBYTE lpAddr;
	BYTE bDataType;
	VARDATA varValue;
	LPDATANODE lpDataNode;
	LPINCONDITIONBSON lpCondition;
	CMFString strItem, strExpression;
	int i, nEndPos, nRet, nDataPos, *lpHashTable;

	i = nStartPos;
	nRet = stBson.AllocFromBsonBuffer(lpCondition, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	queCompareQueue.push(nOffset);
	//1.如果IN后面不是括号，则错误
	if(vecString[i] != "(")
	{
		return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
	}
	//2.判断逗号个数
	i++;
	lpCondition->m_nDataNum = 1;
	for(; i < vecString.size(); i++)
	{
		if(vecString[i] == ",")
		{
			lpCondition->m_nDataNum++;
		}
		else if(vecString[i] == ")")
		{
			nEndPos = i;
			break;
		}
	}

	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(lpCondition->m_nDataNum*sizeof(int), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpCondition->m_nHashTableOffset = nOffset;
	lpHashTable = (int*)lpAddr;
	//3.获取值
	for(i = nStartPos + 1; i <= nEndPos; i++)
	{
		strItem = vecString[i];
		if(bDataType = IsNumber(strItem.c_str()))
		{
			if(bDataType == MF_SYS_NUMBER_TYPE_INT)
			{
				bDataType = MF_SYS_FIELDTYPE_BIGINT;
				lpAddr = NULL;
				nRet = stBson.AllocFromBsonBuffer(sizeof(DATANODE)+ sizeof(long long), nOffset, lpAddr);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpDataNode = (LPDATANODE)lpAddr;
				lpDataNode->m_bDataType = bDataType;
				*(int*)lpDataNode->m_pDataBuffer = atoi(strItem.c_str());

			}
			else if(bDataType == MF_SYS_NUMBER_TYPE_DOUBLE)
			{
				bDataType   = MF_SYS_FIELDTYPE_DOUBLE;
				lpAddr = NULL;
				nRet = stBson.AllocFromBsonBuffer(sizeof(DATANODE)+ sizeof(double), nOffset, lpAddr);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				lpDataNode = (LPDATANODE)lpAddr;
				lpDataNode->m_bDataType = bDataType;
				*(double*)lpDataNode->m_pDataBuffer = atof(strItem.c_str());
			}
		}
		else if(CopyStringFromSql(strItem.c_str(), strItem.length(),varValue))
		{
			bDataType = MF_VARDATA_STRING;
			lpAddr = NULL;
			nRet = stBson.AllocFromBsonBuffer(sizeof(DATANODE)+ varValue.m_nStrLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpDataNode = (LPDATANODE)lpAddr;
			lpDataNode->m_bDataType = bDataType;
			lpDataNode->m_nDataLen = varValue.m_nStrLen;
			memcpy(lpDataNode->m_pDataBuffer, varValue.m_lpszValue, varValue.m_nStrLen);
		}
		else
		{
			return MF_PARSESELECT_INVALID_DATATYPE_ERROR; 
		}

		//判断数据兼容性(括号中的数据必须兼容)
		if(lpCondition->m_bDataType == 0)
		{
			lpCondition->m_bDataType = bDataType;
		}
		else
		{
			if(GetCompatibleFieldType(lpCondition->m_bDataType) != GetCompatibleFieldType(bDataType))
			{
				return MF_PARSESELECT_INVALID_COMPATIBLETYPE_ERROR;
			}
			else
			{
				lpCondition->m_bDataType = lpCondition->m_bDataType > bDataType ? lpCondition->m_bDataType : bDataType;
			}
		}

		//获取数据的HASH值
		if(lpCondition->m_bDataType != MF_VARDATA_STRING)
		{
			nDataPos = CalcKeyHash(*(long long*)lpDataNode->m_pDataBuffer, lpCondition->m_nDataNum);
		}
		else
		{
			nDataPos = CalcKeyHash((LPBYTE)lpDataNode->m_pDataBuffer, lpCondition->m_nDataNum);
		}
		lpDataNode->m_nNextOffset = lpHashTable[nDataPos];
		lpHashTable[nDataPos] = nOffset;
	
		i++;
		if(vecString[i] != "," && vecString[i] != ")")
		{
			return MF_PARSESELECT_INVALID_WHERECONDITION_ERROR;
		}
	}
	nStartPos = nEndPos;
	return MF_OK;
}

/************************************************************************
	功能说明：
		解析Connection条件
	参数说明：
		vecString：SQL语句
		stBson:Bson对象
		nConditionOffset:条件偏移
		skOperatorStack:符号栈
		queMathQueue：字段混合队列
		nStartPos：起始位置
		nEndPos：结束位置
************************************************************************/
int CParseSql::ParseConnect(vector<CMFString>& vecString, CBaseBson& stBson, UINT& nConditionOffset, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMathQueue, queue<int>& queCompareQueue, queue<LPCONDITIONBSON_MIXQUEUENODE>& queConditionQueue, int nStartPos, int nEndPos)
{
	BOOL bPiror;
	UINT nOffset;
	CMFString strItem;
	char pFieldName[32];
	LPSTARTINFO lpStartInfo;
	LPRECURSION lpRecursionInfo;
	int nRet, i, nWhithPos, nLevelPos;
	LPBASECONDITIONBSON lpWhereCondition;

	nRet = stBson.AllocFromBsonBuffer(lpRecursionInfo, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	nConditionOffset = nOffset;

	nRet = stBson.AllocFromBsonBuffer(lpStartInfo, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpRecursionInfo->m_nStartCondOffset = nOffset;

	i = nStartPos;
	//递归查询
	strItem = vecString[i];
	strItem.MakeUpper();
	if(strItem != "WITH")
	{
		return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
	}

	i++;
	if(i > nEndPos)
	{
		return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
	}
	nWhithPos = i;
	strItem = vecString[i];
	strItem.MakeUpper();
	if(!CopyNameFromSql(strItem.c_str(), strItem.length(), pFieldName))
	{
		return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
	}
	i++;
	if(i > nEndPos)
	{
		return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
	}
	strItem = vecString[i];
	strItem.MakeUpper();
	if(strItem != "=" && strItem != "IN")
	{
		return MF_PARSESELECT_INVALID_CONNECTION_ERROR; 
	}
	
	nLevelPos = 0; 
	//找到Connect
	for(; i < nEndPos; i++)
	{
		strItem = vecString[i];
		strItem.MakeUpper();
		if(strItem == "LEVELS")
		{
			//深度
			i++;
			nLevelPos++;
			strItem = vecString[i];
			if(strItem != "=")
			{
				return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
			}
			i++;
			nLevelPos++;
			strItem = vecString[i];
			if(IsNumber(strItem.c_str()) == 1)
			{
				int nLevel;
				nLevel = atoi(strItem.c_str());
				if(nLevel > 255)
				{
					return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
				}
				lpRecursionInfo->m_bLevel = (BYTE)nLevel;

			}
			else
			{
				return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
			}
			nLevelPos++;
		}
		else if(strItem == "CONNECT")
		{
			break;
		}
	}
	if(i == nEndPos)
	{
		return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
	}

	//解析START条件
	nRet = ParseCondition(vecString, stBson, lpStartInfo->m_nWhereOffset, NULL, skOperatorStack, 
						  queMathQueue, queCompareQueue, queConditionQueue, nWhithPos, i - nLevelPos);

	//不论是否执行成功，都需要先释放skOperatorStack、queMathQueue和queConditionQueue
	FreeStack(skOperatorStack);
	FreeQueue(queMathQueue);
	FreeQueue(queConditionQueue);
	if(nRet != MF_OK)
	{
		return nRet;
	}
		
	i++;
	if(i > nEndPos)
	{
		return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
	}
	strItem = vecString[i];
	strItem.MakeUpper();
	if(strItem != "BY")
	{
		return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
	}

	i++;
	if(i > nEndPos)
	{
		return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
	}

	//解析CONNECT条件
	nRet = ParseCondition(vecString, stBson, lpRecursionInfo->m_nConnectCondOffset, NULL,
						  skOperatorStack, queMathQueue, queCompareQueue, queConditionQueue, i, nEndPos);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	//判断CONNECT条件是否正确
	lpWhereCondition = (LPBASECONDITIONBSON)stBson.ConvertOffset2Addr(lpRecursionInfo->m_nConnectCondOffset);
	bPiror = FALSE;
	if(!CheckConnectCondition(stBson, lpWhereCondition, bPiror))
	{
		return MF_PARSESELECT_INVALID_CONNECTION_ERROR;
	}

	if(0 == lpRecursionInfo->m_bLevel)
	{
		 lpRecursionInfo->m_bLevel = 255;
	}
	return MF_OK;
}


/************************************************************************
	功能说明：
		获取查询条件(仅在查询条件只包含常量表达式时使用)
	参数说明：
		lpCondition：查询条件
		bResult:结果
************************************************************************/
int CParseSql::GetConditionResult(CBaseBson& stBson, LPBASECONDITIONBSON lpCondition, BOOL& bResult)
{
	int nRet;
	BOOL bResult1, bResult2;
	LPCOMPAREEXPBSON lpCompareExp;
	LPBASECONDITIONBSON lpWhereCondition;
	
	if(lpCondition->m_bConditionType1 == MF_CONDITION_INVALID || lpCondition->m_bConditionType1 == MF_CONDITION_ROWNUM)
	{
		bResult1 = TRUE;
	}
	else if(lpCondition->m_bConditionType1 == MF_CONDITION_LOGIC)
	{
		lpWhereCondition = (LPBASECONDITIONBSON)(stBson.ConvertOffset2Addr(lpCondition->m_nConditionOffset1));
		nRet = GetConditionResult(stBson, lpWhereCondition, bResult1);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else 
	{
		lpCompareExp = (LPCOMPAREEXPBSON)(stBson.ConvertOffset2Addr(lpCondition->m_nConditionOffset1));
		bResult1 = Compare(stBson, lpCompareExp);
	}

	if(lpCondition->m_bConditionType2 == MF_CONDITION_INVALID || lpCondition->m_bConditionType2 == MF_CONDITION_ROWNUM)
	{
		bResult2 = TRUE;
	}
	else if(lpCondition->m_bConditionType2 == MF_CONDITION_LOGIC)
	{
		lpWhereCondition = (LPBASECONDITIONBSON)(stBson.ConvertOffset2Addr(lpCondition->m_nConditionOffset2));
		nRet = GetConditionResult(stBson, lpWhereCondition, bResult2);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else 
	{
		lpCompareExp = (LPCOMPAREEXPBSON)(stBson.ConvertOffset2Addr(lpCondition->m_nConditionOffset2));
		bResult2 = Compare(stBson, lpCompareExp);
	}

	//计算总的逻辑结果
	switch(lpCondition->m_bLogicOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_OR:
		bResult = (bResult1 || bResult2);
		break;
	default:
		bResult = (bResult1 && bResult2);
		break;
	}

	//最后计算一次非（NOT运算）
	if(lpCondition->m_bLogicNot)
	{
		bResult =  !bResult;
		return MF_OK;
	}
	else
	{
		return MF_OK;
	}
	return MF_FAILED;
}


BOOL CParseSql::Compare(CBaseBson& stBson, LPCOMPAREEXPBSON lpCompareExp)
{
	LPMATHEXPBSON lpMathExp;
	VARDATA varData1, varData2, varData3;
	if(lpCompareExp->m_nMathExpOffset1 != NULL)
	{
		lpMathExp = (LPMATHEXPBSON)(stBson.ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset1));
		CBaseExpression::GetExpressionResult(stBson, lpMathExp, varData1);
	}
	if(lpCompareExp->m_nMathExpOffset2 != NULL)
	{
		lpMathExp = (LPMATHEXPBSON)(stBson.ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset2));
		CBaseExpression::GetExpressionResult(stBson, lpMathExp, varData2);

	}
	if(lpCompareExp->m_nMathExpOffset3 != NULL)
	{
		lpMathExp = (LPMATHEXPBSON)(stBson.ConvertOffset2Addr(lpCompareExp->m_nMathExpOffset3));
		CBaseExpression::GetExpressionResult(stBson, lpMathExp, varData3);
	}
	switch(lpCompareExp->m_bOperator)
	{
	case MF_EXECUTEPLAN_OPERATOR_BETWEEN:
		return (varData2 <= varData1) && (varData3 >=  varData1);
	case MF_EXECUTEPLAN_OPERATOR_BETWEENB:
		return (varData2 <= varData1) && (varData3 >  varData1);
	case MF_EXECUTEPLAN_OPERATOR_BETWEENE:
		return  (varData2 < varData1) && (varData3 >=  varData1);
	case MF_EXECUTEPLAN_OPERATOR_BETWEENBE:
		return (varData2 < varData1) && (varData3 >  varData1);
	case MF_EXECUTEPLAN_OPERATOR_EQUAL:
		return varData1 == varData2;
	case MF_EXECUTEPLAN_OPERATOR_NOTEQUAL:
		return varData1 != varData2;
	case MF_EXECUTEPLAN_OPERATOR_GREATER:
		return varData1 > varData2;
	case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
		return varData1 >= varData2;
	case MF_EXECUTEPLAN_OPERATOR_LESS:
		return varData1 < varData2;
	case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
		return varData1 <= varData2;
	}
	return FALSE;
}
/************************************************************************
	功能说明：
		创建四则运算表达式
	参数说明：
		nExpBsonOffset：表达式偏移
		stBson：BSON
		queMixQueue：混合队列
************************************************************************/
int CParseSql::CreateMathExpression(UINT& nExpBsonOffset, CBaseBson& stBson, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue)
{
	int nRet;
	LPMATHEXPBSON lpExpBson;
	LPEXPFIELDBSON_MIXQUEUENODE lpQueueNode;
	stack<LPEXPBSONSTACKNODE> skExpressionStack;
	LPEXPBSONSTACKNODE pExpressionNode, pExpressionNode2;
	if(queMixQueue.empty())
	{
		//表达式中没有元素异常
		return MF_CREATELOGIC_INVALID_NULLQUEUE_ERROR;
	}
	while(!queMixQueue.empty())
	{
		lpQueueNode = queMixQueue.front();	
		if(lpQueueNode->m_bOperator)
		{
			//若为符号，则需要将表达式栈的前两个元素弹栈，然后根据根据运算符填充LPMATHEXPRESSIONDEF结构体
			//并将LPMATHEXPRESSIONDEF再压入逻辑栈
			nRet = stBson.AllocFromBsonBuffer(lpExpBson, nExpBsonOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpExpBson->m_bOperator = lpQueueNode->m_bMathOp;
			if(MF_EXECUTEPLAN_OPERATOR_SYSDATE == lpQueueNode->m_bMathOp)
			{
				//无参函数类型
				lpExpBson->m_bExpressionType1 = 3;
				lpExpBson->m_bExpressionType2 = 3;
			}
			else if(MF_EXECUTEPLAN_OPERATOR_SIGNMINUS == lpQueueNode->m_bMathOp || MF_EXECUTEPLAN_OPERATOR_COUNT == lpQueueNode->m_bMathOp  || MF_EXECUTEPLAN_OPERATOR_SEQUENCE == lpQueueNode->m_bMathOp || 
				MF_EXECUTEPLAN_OPERATOR_CURRVAL == lpQueueNode->m_bMathOp || MF_EXECUTEPLAN_OPERATOR_NEXTVAL == lpQueueNode->m_bMathOp) 
			{
				if(skExpressionStack.size() < 1)
				{
					return MF_CREATELOGIC_INVALID_LOGICSTACK_ERROR;
				}
				//如果是单目运算符就只弹一个元素
				pExpressionNode = skExpressionStack.top();
				skExpressionStack.pop();

				//条件一
				if(!pExpressionNode->m_bExpressionType)			//m_pExpressionField有效
				{	
					lpExpBson->m_bExpressionType1 = 0;
					lpExpBson->m_nExpOffset1 = pExpressionNode->m_nExpFieldOffset;
				}
				else
				{
					lpExpBson->m_bExpressionType1 = 1;			//m_pExpression1有效
					lpExpBson->m_nExpOffset1 = pExpressionNode->m_nExpOffset;
				}
				//条件二(无效)
				lpExpBson->m_bExpressionType2 = 3;
				delete pExpressionNode;
			}
			else
			{
				if(skExpressionStack.size() < 2)
				{
					return MF_CREATELOGIC_INVALID_LOGICSTACK_ERROR;
				}
				//将栈顶的两个元素弹栈(注意：先出栈的是条件二，后出栈的是条件1)
				pExpressionNode2 = skExpressionStack.top();
				skExpressionStack.pop();

				pExpressionNode= skExpressionStack.top();
				skExpressionStack.pop();

				//条件一
				if(!pExpressionNode->m_bExpressionType)		//m_pExpressionField有效
				{	
					lpExpBson->m_bExpressionType1 = 0;
					lpExpBson->m_nExpOffset1 = pExpressionNode->m_nExpFieldOffset;
				}
				else
				{
					lpExpBson->m_bExpressionType1 = 1;			//m_pExpression1有效
					lpExpBson->m_nExpOffset1 = pExpressionNode->m_nExpOffset;
				}

				//条件二
				if(!pExpressionNode2->m_bExpressionType)		//m_pExpressionField有效
				{	
					lpExpBson->m_bExpressionType2 = 0;
					lpExpBson->m_nExpOffset2 = pExpressionNode2->m_nExpFieldOffset;
				}
				else
				{
					lpExpBson->m_bExpressionType2 = 1;			//m_pExpression2有效
					lpExpBson->m_nExpOffset2 = pExpressionNode2->m_nExpOffset;
				}
				delete pExpressionNode2;
				delete pExpressionNode;
			}
			pExpressionNode = new EXPBSONSTACKNODE;
			pExpressionNode->m_bExpressionType = 1;
			pExpressionNode->m_nExpOffset = nExpBsonOffset;
			skExpressionStack.push(pExpressionNode);			//将pStackNode压栈
		}
		else
		{
			//如果不是符号，则直接将元素弹出混合队列，并压入逻辑栈
			pExpressionNode = new EXPBSONSTACKNODE;
			pExpressionNode->m_bExpressionType = 0;
			pExpressionNode->m_nExpFieldOffset  = lpQueueNode->m_nExpFieldOffset;
			skExpressionStack.push(pExpressionNode);
		}
		queMixQueue.pop();										//将该元素弹出混合队列
		delete lpQueueNode;
	}

	//循环完毕后，逻辑栈中一定有且仅有一个结点，将该结点弹出
	if(1 != skExpressionStack.size())
	{
		FreeStack(skExpressionStack);
		FreeQueue(queMixQueue);
		return MF_CREATEEXPRESSION_INVALID_EXPRESSIONSTACK_ERROR;
	}
	else
	{
		pExpressionNode = skExpressionStack.top();
		if(!pExpressionNode->m_bExpressionType)
		{
			//说明该结点是一个LPMATHEXPRESSIONFIELD结构体，那么应该将其封装成LPMATHEXPRESSIONDEF结构体
			nRet = stBson.AllocFromBsonBuffer(lpExpBson, nExpBsonOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpExpBson->m_bExpressionType1 = 0;
			lpExpBson->m_bExpressionType2 = 3;
			lpExpBson->m_bOperator = 0;
			lpExpBson->m_nExpOffset1 = pExpressionNode->m_nExpFieldOffset;
		}
		else
		{
			nExpBsonOffset = pExpressionNode->m_nExpOffset;
		}
		skExpressionStack.pop();
		delete pExpressionNode;
		pExpressionNode = NULL;
	}
	return MF_OK;
}

void CParseSql::Parse(const char* lpszData, int nPos, vector<CMFString> &vecString)
{
	int i,nNumber;
	char *pData, *pWord;
	CMFString strItem, strSql;
	BOOL bSingleQuote, bSeriesSingleQuote, bDoubleQuote;

	strSql = lpszData;
	pData  = (char*)strSql.c_str();
	pWord  = NULL;
	nNumber = 1; //1表示小数点前为纯数字，0表示有非数字，2表示确认为浮点数
	bSingleQuote = FALSE;
	bDoubleQuote = FALSE;
	bSeriesSingleQuote = FALSE;
	for(i = nPos;pData[i] != 0;i++)
	{
		if(nNumber == 2)
		{
			if(pData[i] < '0' || pData[i] > '9')
			{
				//把浮点数取出来
				char cData;
				cData = pData[i];
				pData[i] = 0;
				strItem = pWord;
				pData[i] = cData;
				bDoubleQuote = FALSE;
				vecString.push_back(strItem);
				nNumber = 1;
				pWord = NULL;
				i--;
				continue;
			}
			else
			{
				continue;
			}
		}
		else if(pData[i] == '\'')
		{
			if(!bSingleQuote)
			{
				bSingleQuote = TRUE;
				bSeriesSingleQuote = FALSE;
				if(pWord != NULL)
				{
					pData[i] = 0;
					strItem = pWord;
					vecString.push_back(strItem);
					pData[i] = '\'';
					pWord = NULL;
					nNumber = 1;
				}
				pWord = pData + i;
			}
			else
			{
				if(pData[i + 1] == '\'')
				{
					bSeriesSingleQuote = TRUE;
					i++;
				}
				else
				{
					//截取出对应字符串
					if(pWord == pData + i - 1)
					{
						strItem = "";

					}
					else
					{
						char cData;
						cData = pData[i + 1];
						pData[i + 1] = 0;
						strItem = pWord;
						pData[i + 1] = cData;
						if(bSeriesSingleQuote)
						{
							strItem.Replace("''","'");
							bSeriesSingleQuote = FALSE;
						}
					}
					bSingleQuote = FALSE;
					vecString.push_back(strItem);
					pWord = NULL;
					nNumber = 1;
				}
			}
		}
		else if(bSingleQuote)
		{
			continue;
		}
		else if(pData[i] == '\"')
		{
			if(bDoubleQuote)
			{
				//截取出对应字符串
				char cData;
				cData = pData[i + 1];
				pData[i + 1] = 0;
				strItem = pWord;
				pData[i + 1] = cData;
				bDoubleQuote = FALSE;
				vecString.push_back(strItem);
				nNumber = 1;
				pWord = NULL;
			}
			else
			{
				if(pWord == NULL)
				{
					//单词开始的双引号，可能表示字段大小写敏感
					bDoubleQuote = TRUE;
					pWord = pData + i;
					continue;
				}
				else
				{
					//单词中间的双引号，不用理会
				}
			}
		}
		else if(bDoubleQuote)
		{
			continue;
		}
		else if(pData[i] == ',')
		{
			char cData[2];
			cData[0] = pData[i];
			cData[1] = 0;
			if(pWord != NULL)
			{
				pData[i] = 0;
				strItem = pWord;
				vecString.push_back(strItem);
				pWord = NULL;
				nNumber = 1;
			}
			strItem = cData;
			vecString.push_back(strItem);
		}
		else if(pData[i] == '.')
		{
			if(nNumber == 1)
			{
				if(pData[i + 1] < '0' || pData[i + 1] > '9')
				{
					//语法错误
				}
				else
				{
					nNumber = 2;
					continue;
				}
			}

			char cData[2];
			cData[0] = pData[i];
			cData[1] = 0;
			if(pWord != NULL)
			{
				pData[i] = 0;
				strItem = pWord;
				vecString.push_back(strItem);
				pWord = NULL;
				nNumber = 1;
			}
			strItem = cData;
			vecString.push_back(strItem);
		}
		else if(pData[i] == ' ' || pData[i] == '	' || pData[i] == '\r' || pData[i] == '\n')
		{
			//作为分隔符
			if(pWord == NULL)
			{
				//直接忽略多余的空格及分隔符
				continue;
			}
			else
			{
				pData[i] = 0;
				strItem = pWord;
				vecString.push_back(strItem);
				pWord = NULL;
				nNumber = 1;
			}
		}
		else if(pData[i] == '(' || pData[i] == ')' || pData[i] == '[' || pData[i] == ']')
		{
			char cData[2];
			cData[0] = pData[i];
			cData[1] = 0;
			if(pWord != NULL)
			{
				pData[i] = 0;
				strItem = pWord;
				vecString.push_back(strItem);
				pWord = NULL;
				nNumber = 1;
			}
			strItem = cData;
			vecString.push_back(strItem);
		}
		else if(pData[i] == '|' && pData[i+1] == '|')
		{
			char cData[3];
			cData[0] = pData[i];
			cData[1] = pData[i + 1];
			cData[2] = 0;
			if(pWord != NULL)
			{
				pData[i] = 0;
				strItem = pWord;
				vecString.push_back(strItem);
				pWord = NULL;
				nNumber = 1;
			}
			strItem = cData;
			vecString.push_back(strItem);
			i++;
		}
		else if(pData[i] == '+' || pData[i] == '-' || pData[i] == '*' || pData[i] == '/' ||
			pData[i] == '!' || pData[i] == '=' || pData[i] == '>' || pData[i] == '<' || pData[i] == ',')
		{
			if(pData[i] == '*' && pData[i - 1] == '.' && pData[i - 1] == ',')
			{
			}
			else
			{
				char cData[3];
				cData[0] = pData[i];
				if(pData[i+1] == '=' || pData[i+1] == '>' || pData[i+1] == '-')
				{
					cData[1] = pData[i+1];
					cData[2] = 0;
					pData[i] = 0;
					i++;
				}
				else
				{
					cData[1] = 0;
				}
				if(pWord != NULL)
				{
					pData[i] = 0;
					strItem = pWord;
					vecString.push_back(strItem);
					pWord = NULL;
					nNumber = 1;
				}
				strItem = cData;
				vecString.push_back(strItem);
			}
		}
		else if(pData[i] != 0)
		{
			if(pWord == NULL)
			{
				pWord = pData + i;
			}
			if(pData[i] < '0' || pData[i] > '9')
			{
				nNumber = 0;
			}
		}
	}
	if(pWord != NULL)
	{
		strItem = pWord;
		vecString.push_back(strItem);
		pWord = NULL;
	}
}

int CParseSql::PraseSqlHead(const char* lpszSql, int& nPos, char* pCommandHead)
{
	int j;

	j = 0;
	for(nPos = 0;lpszSql[nPos] != 0;nPos++)
	{
		if((lpszSql[nPos] >= 'A' && lpszSql[nPos] <= 'Z') || (lpszSql[nPos] >= L'a' && lpszSql[nPos] <= L'z'))
		{
			pCommandHead[j] = (char)lpszSql[nPos];
			j++;
			//没有含有8个字符以上的命令，所以直接失败
			if(j >= 8)
			{
				//直接报错，属于非法字符
				return MF_PARSECMD_INVALID_COMMAND_ERROR;
			}
		}
		else if(j == 0)
		{
			//处于第一个字符前，如果是空格、TAB键或者回车换行符就直接去除
			if(lpszSql[nPos] == ' ' || lpszSql[nPos] == '	' || lpszSql[nPos] == '\r' || lpszSql[nPos] == '\n')
			{
			}
			else
			{
				//直接报错，属于非法字符
				return MF_PARSECMD_INVALID_START_ERROR;
			}
		}
		else
		{
			//处于第一个字符前，如果是空格、TAB键或者回车换行符就直接去除
			if(lpszSql[nPos] == ' ' || lpszSql[nPos] == '	' || lpszSql[nPos] == '\r' || lpszSql[nPos] == '\n' || lpszSql[nPos] == ':')
			{
				//命令结束，可根据命令分别解析
				nPos++;
				break;
			}
			else
			{
				//直接报错，属于非法字符
				return MF_PARSECMD_INVALID_CHAR_ERROR;
			}
		}
	}
	if(j == 0)
	{
		return MF_PARSECMD_INVALID_NULL_ERROR;
	}
	else
	{
		pCommandHead[j] = 0;
	}

	return MF_OK;
}
#ifdef WIN32
int CParseSql::ParseSql(CBaseBson& stBson, BSTR bstrSql, LPEXECUTEPLANBSON& lpExecutePlan)
{
	char* lpszSQL;
	int nSqlLen, nRet;

	nSqlLen = 0;
	lpszSQL = ConvertToUTF8(bstrSql, nSqlLen);
	if(lpszSQL == NULL)
	{
		return MF_INNER_ALLOCMEM_FAILED;
	}
	nRet = ParseSql(stBson, lpszSQL, nSqlLen, lpExecutePlan);
	delete [] lpszSQL;
	lpszSQL = NULL;
	return nRet;
}
#endif
int CParseSql::ParseSql(CBaseBson& stBson, const char* lpszSql, int nSqlLen, LPEXECUTEPLANBSON& lpExecutePlan)
{
	UINT nOffset;
	LPBYTE lpAddr;
	CMFString strCommandHead;
	int nRet, i, j, nLen, nBufferSize;
	char lpCommandHead[10], *pWhereBegin, *pWhereEnd;

	j = 0;
	i = 0;
	memset(lpCommandHead, 0, sizeof(lpCommandHead));
	nRet = PraseSqlHead(lpszSql, i, lpCommandHead);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	strCommandHead = lpCommandHead;
	strCommandHead.MakeUpper();
	
	//分配空间
	nBufferSize = MF_BUFFERSECTION_SIZE;

ParseSql_ReallocBuffer:
	if(lpExecutePlan == NULL)
	{
		stBson.AllocBsonBuffer(nBufferSize);
		//为lpExecutePlan分配空间
		nRet = stBson.AllocFromBsonBuffer(lpExecutePlan, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		stBson.SetBuffer((LPBYTE)lpExecutePlan, lpExecutePlan->m_nClientBsonDataSize,sizeof(EXECUTEPLANBSON));
	}

	//为原始SQL语句分配空间
	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(nSqlLen, nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlan->m_nSqlLen = nSqlLen;
	lpExecutePlan->m_nSqlOffset = nOffset;
	memcpy(lpAddr, lpszSql, nSqlLen);
	MakeUpper((char*)lpAddr, nSqlLen);
	//计算SQL的HASH值
	lpExecutePlan->m_dwHashID = CalcSQLHash(lpszSql, nSqlLen);
	//计算WHERE条件的位置
	pWhereBegin = strstr((char*)lpAddr, "WHERE");	
	if(pWhereBegin == NULL)
	{
		lpExecutePlan->m_dwWhereHash = 0;
	}
	else
	{
		pWhereEnd = strstr((char*)lpAddr, "PAGING");
		if(pWhereEnd == NULL)
		{
			nLen = ((char*)lpAddr + nSqlLen - 1) - pWhereBegin;
		}
		else
		{
			nLen = pWhereEnd - pWhereBegin;
		}
		lpExecutePlan->m_dwWhereHash = BKDRHash(pWhereBegin, nLen);
	}

	if(strCommandHead == "MEMDB")
	{
		lpszSql += i;
		nRet = PraseSqlHead(lpszSql, i, lpCommandHead);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		strCommandHead = lpCommandHead;
		strCommandHead.MakeUpper();
	}
	//判断命令类型，调不同的命令解析函数
	if(strCommandHead == "SELECT")
	{
		//检索语句
		lpExecutePlan->m_nType		= MF_EXECUTEPLAN_CMDTYPE_QUERY;
		lpExecutePlan->m_bWriteLog	= 0;
		nRet = ParseQuery(lpszSql, stBson, i, lpExecutePlan);
	}
	else if(strCommandHead == "INSERT")
	{
		lpExecutePlan->m_nType		= MF_EXECUTEPLAN_CMDTYPE_INSERT;
		lpExecutePlan->m_bWriteLog	= 1;
		nRet = ParseInsert(lpszSql, stBson, i, lpExecutePlan);
	}
	else if(strCommandHead == "DELETE")
	{
		lpExecutePlan->m_nType		= MF_EXECUTEPLAN_CMDTYPE_DELETE;
		lpExecutePlan->m_bWriteLog	= 1;
		nRet = ParseDelete(lpszSql, stBson, i, lpExecutePlan);
	}
	else if(strCommandHead == "UPDATE")
	{
		lpExecutePlan->m_nType		= MF_EXECUTEPLAN_CMDTYPE_UPDATE;
		lpExecutePlan->m_bWriteLog	= 1;
		nRet = ParseUpdate(lpszSql, stBson, i, lpExecutePlan);
	}
	else if(strCommandHead == "CREATE")
	{
		lpExecutePlan->m_nType		= MF_EXECUTEPLAN_CMDTYPE_CREATE;
		lpExecutePlan->m_bWriteLog	= 1;
		nRet = ParseCreate(lpszSql, stBson, i, lpExecutePlan);
	}
	else if(strCommandHead == "DROP")
	{
		lpExecutePlan->m_nType		= MF_EXECUTEPLAN_CMDTYPE_DROP;
		lpExecutePlan->m_bWriteLog	= 1;
		nRet = ParseDrop(lpszSql, stBson, i, lpExecutePlan);
	}
	else if(strCommandHead == "ALTER")
	{
		lpExecutePlan->m_nType		= MF_EXECUTEPLAN_CMDTYPE_ALTER;
		lpExecutePlan->m_bWriteLog	= 1;
		nRet = ParseAlter(lpszSql, stBson, i, lpExecutePlan);
	}
	else if(strCommandHead == "GRANT")
	{
		lpExecutePlan->m_nType		= MF_EXECUTEPLAN_CMDTYPE_ALTER;
		lpExecutePlan->m_bWriteLog	= 1;
		nRet = ParseGrant(lpszSql, stBson, i, lpExecutePlan);
	}
	else if(strCommandHead == "REVOKE")
	{
		lpExecutePlan->m_nType		= MF_EXECUTEPLAN_CMDTYPE_ALTER;
		lpExecutePlan->m_bWriteLog	= 1;
		nRet = ParseRevoke(lpszSql, stBson, i, lpExecutePlan);
	}
	else
	{
		//非法数据库命令
		return MF_PARSECMD_INVALID_COMMAND_ERROR;
	}

	if(nRet == MF_PARSECMD_EXECUTEPALN_LACKSPACE_ERROR)
	{
		//重新分配空间进行解析
		nBufferSize = nBufferSize*4;
		stBson.Free();
		lpExecutePlan = NULL;
		goto ParseSql_ReallocBuffer;
	}
	else
	{
		return nRet;
	}
}

int CParseSql::ParseQuery(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan)
{
	int i;
	UINT nOffset;
	LPBYTE lpAddr;
	string strSql;
	CMFString strItem;
	queue<int> queCompareQueue;		
	vector<CMFString> vecString;
	LPQUERYEXECUTEPLANBSON lpQueryPlan;
	LPOBJECTNAMEBSON lpObjecetNameBson;		
	LPCOMMONCONDITION lpCommonCondition;
	stack<LPMATHOPERATOR> skOperatorStack;	
	char pObjectName[32], pObjectTitle[32];
	queue<LPEXPFIELDBSON_MIXQUEUENODE> queMathQueue;		
	queue<LPCONDITIONBSON_MIXQUEUENODE> queConditionQueue; 
	int nRet, nModifyFlag, nObjectNameLen, nFROMPos, nConditionPos, nConnectPos, nPagingPos;
	
	lpExecutePlan->m_bObjectType = MF_OBJECT_COMMON;
	strSql = lpszSql;
	//首先对SQL语句进行拆分成一个一个的单词
 	Parse(lpszSql, nPos, vecString);
	vecString.push_back("EOF");

	//遍历vecString，将查询条件又中缀表达式转换成后缀表达式，注意vecString不包含SELECT
	//首先对SQL语句进行拆分成一个一个的单词	
	//遍历vecString从vecString中分离出几个子字段
	//例：select * from student where sno >'001' and sname ='obvious'
	//	  select 和 from 之间是一个子字段queryField 
	//	  from 和 where 之间是一个子字段objectName
	//	  对于where之后的条件字段直接进行处理

	nFROMPos		= 0;
	nModifyFlag		= 0;
	nConditionPos	= 0;
	nConnectPos		= 0;
	nPagingPos		= 0;

	for(i = 0; i < (int)vecString.size(); i++)
	{
		strItem = vecString[i];
		if(0 == strItem.CompareNoCase("FROM"))							
		{			
			//找到了FROM的位置
			if(nFROMPos == 0)
			{
				nFROMPos = i;
			}
			else
			{
				//多个from
				return MF_PARSECMD_INVALID_SELECT_SYNTAX_ERROR;		
			}
		}
		else if(0 == nConditionPos && nConnectPos == 0 && 0 == nPagingPos && (0 == strItem.CompareNoCase("WHERE") || 0 == strItem.CompareNoCase("EOF") || 0 == strItem.CompareNoCase("START") || 0 == strItem.CompareNoCase("PAGING")))
		{
			if(0 == nFROMPos)
			{
				//说明没有找到FROM字段出现异常
				return MF_PARSECMD_INVALID_SELECT_SYNTAX_ERROR;		
			}
			
			if(0 == strItem.CompareNoCase("WHERE"))
			{
				nConditionPos = i+1;
			}
			else if(0 == strItem.CompareNoCase("START"))
			{
				nConnectPos = i+1;
			}
			else if(0 == strItem.CompareNoCase("PAGING"))
			{
				nPagingPos = i+1;
			}

			//获取Object信息
			memset(pObjectTitle, 0 ,32);
			nRet = ParseObjectInfo(vecString, pObjectName, pObjectTitle, nFROMPos + 1, i);		
			if(nRet != MF_OK)
			{
				return nRet;
			}
			
			nRet = stBson.AllocFromBsonBuffer(lpQueryPlan, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpExecutePlan->m_nCommandOffset = nOffset;
			
			nRet = stBson.AllocFromBsonBuffer(lpCommonCondition, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpQueryPlan->m_nConditionOffset = nOffset;

			nObjectNameLen	= strlen(pObjectName);
			lpAddr			= NULL;
			nRet = stBson.AllocFromBsonBuffer(sizeof(OBJECTNAMEBSON)+nObjectNameLen, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpObjecetNameBson = (LPOBJECTNAMEBSON)lpAddr;
			lpObjecetNameBson->m_bLen = nObjectNameLen + 1;
			memcpy(lpObjecetNameBson->m_pObjectName, pObjectName, nObjectNameLen+1);
			
			lpQueryPlan->m_nObjectNameOffset = nOffset;			
			lpQueryPlan->m_nObjectNum = 1;

			//查询默认分页，一页最多1W条数据
			lpQueryPlan->m_bPageType = MF_PAGING_FIRST;
			lpQueryPlan->m_nPageNo   = 1;
			lpQueryPlan->m_nPageSize = 10000;

			//先解析表名，再解析字段名
			nRet = ParseSelectField(vecString, stBson, lpQueryPlan, pObjectTitle, 0, nFROMPos, nModifyFlag);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else if(0 == nConditionPos && 0 == nPagingPos && (0 == strItem.CompareNoCase("WHERE") || 0 == strItem.CompareNoCase("PAGING") || 0 == strItem.CompareNoCase("EOF")))
		{
			if(0 == nConnectPos)
			{
				//说明没有找到CONNECT字段出现异常
				return MF_PARSECMD_INVALID_SELECT_SYNTAX_ERROR;		
			}
			if(0 == strItem.CompareNoCase("WHERE"))
			{
				nConditionPos = i+1;
			}
			else if(0 == strItem.CompareNoCase("PAGING"))
			{
				nPagingPos = i+1;
			}

			nRet = ParseConnect(vecString, stBson, lpCommonCondition->m_nConnOffset, skOperatorStack, queMathQueue, queCompareQueue, queConditionQueue, nConnectPos, i);
			//不论是否执行成功，都需要先释放skOperatorStack、queMathQueue和queConditionQueue
			FreeStack(skOperatorStack);
			FreeQueue(queMathQueue);
			FreeQueue(queConditionQueue);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else if(0 != nConditionPos && 0 == nPagingPos && (0 == strItem.CompareNoCase("EOF") || 0 == strItem.CompareNoCase("PAGING")))
		{
			if(0 == strItem.CompareNoCase("PAGING"))
			{
				nPagingPos = i+1;
			}

			nRet = ParseCondition(vecString, stBson, lpCommonCondition->m_nWhereOffset, pObjectTitle,skOperatorStack, 
				queMathQueue, queCompareQueue, queConditionQueue, nConditionPos, i);
			//不论是否执行成功，都需要先释放skOperatorStack、queMathQueue和queConditionQueue
			FreeStack(skOperatorStack);
			FreeQueue(queMathQueue);
			FreeQueue(queConditionQueue);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else if(0 != nPagingPos && 0 == strItem.CompareNoCase("EOF"))
		{
			nRet = ParsePaging(vecString, lpQueryPlan, nPagingPos, i);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
	}

	if(nModifyFlag == 1)
	{
		lpExecutePlan->m_bWriteLog	= 1;
	}

	lpExecutePlan->m_bDBType				= MF_DATABASE_MEMDB;
	lpExecutePlan->m_nBsonDataSize			= stBson.GetBsonDataSize();
	lpExecutePlan->m_nClientBsonDataSize	= stBson.GetBsonDataSize();
	lpExecutePlan->m_nTotalDataSize			= stBson.GetExecutePlanDataSize();
	if(lpExecutePlan->m_nBsonDataSize != lpExecutePlan->m_nTotalDataSize)
	{
		return MF_PARSECMD_EXECUTEPALN_INVALID_SIZE_ERROR;
	}
	return MF_OK;
}

int CParseSql::ParseInsert(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan)
{
	int nRet;
	UINT nOffset;
	string strSql;
	CMFString strItem;
	vector<CMFString> vecString;
	LPINSERTEXECUTEPLANBSON lpInsertPlan;
			
	strSql = lpszSql;
	//首先对SQL语句进行拆分成一个一个的单词	
	Parse(lpszSql, nPos, vecString);
	//vecString.push_back("EOF");
	
	//语法检测部分
	nRet = stBson.AllocFromBsonBuffer(lpInsertPlan, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlan->m_nCommandOffset = nOffset;
	//语句最后一定是右括号
	strItem = vecString[vecString.size() - 1];
	if(strItem != ")")
	{
		return MF_PARSECMD_INVALID_INSERT_SYNTAX_ERROR;
	}

	strItem = vecString[0];
	strItem.MakeUpper();
	if(strItem == "INTO")
	{
		//普通数据库
		nRet = ParseCommonInsert(vecString, stBson, lpExecutePlan);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		return MF_PARSECMD_INVALID_INSERT_SYNTAX_ERROR;
	}
	
	lpExecutePlan->m_bDBType = MF_DATABASE_MEMDB;
	lpExecutePlan->m_bDBType				= MF_DATABASE_MEMDB;
	lpExecutePlan->m_nBsonDataSize			= stBson.GetBsonDataSize();
	lpExecutePlan->m_nClientBsonDataSize	= stBson.GetBsonDataSize();
	lpExecutePlan->m_nTotalDataSize			= stBson.GetExecutePlanDataSize();
	if(lpExecutePlan->m_nBsonDataSize != lpExecutePlan->m_nTotalDataSize)
	{
		return MF_PARSECMD_EXECUTEPALN_INVALID_SIZE_ERROR;
	}
	return MF_OK;
}

int CParseSql::ParseUpdate(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan)
{
	UINT nOffset;
	LPBYTE lpAddr;
	string strSql;
	BOOL bCondition;
	CMFString strItem;
	char pObjectName[32];
	queue<int> queCompareQueue;
	vector<CMFString> vecString;
	int nRet, i, nConditionPos, nLen;
	LPOBJECTNAMEBSON pObjectNameBson;
	LPUPDATEEXECUTEPLANBSON lpUpdatePlan;
	stack<LPMATHOPERATOR> skOperatorStack;
	queue<LPEXPFIELDBSON_MIXQUEUENODE> queMathQueue;	
	queue<LPCONDITIONBSON_MIXQUEUENODE> queConditionQueue;

	bCondition = FALSE;
	nRet = stBson.AllocFromBsonBuffer(lpUpdatePlan, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlan->m_nCommandOffset = nOffset;
	lpExecutePlan->m_bObjectType    = MF_OBJECT_COMMON;

	strSql = lpszSql;
	//首先对SQL语句进行拆分成一个一个的单词
	Parse(lpszSql, nPos, vecString);
	vecString.push_back("EOF");
	nConditionPos = vecString.size() - 1;			    
	
	strItem = vecString[0];
	if(CopyNameFromSql(strItem.c_str(), strItem.length(), pObjectName))
	{
	
		nLen = strItem.length();
		lpAddr = NULL;
		nRet = stBson.AllocFromBsonBuffer(sizeof(OBJECTNAMEBSON)+nLen, nOffset, lpAddr);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		pObjectNameBson = (LPOBJECTNAMEBSON)lpAddr;
		pObjectNameBson->m_bLen = nLen+1;
		memcpy(pObjectNameBson->m_pObjectName, pObjectName, nLen+1);
		lpUpdatePlan->m_nObjectNameOffset = nOffset;
	}
	else
	{
		return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
	}

	//对象名后面一定是SET
	strItem = vecString[1];
	strItem.MakeUpper();
	if(strItem != "SET")
	{
		return MF_PARSECMD_INVALID_UPDATE_SYNTAX_ERROR;
	}
	//寻找WHERE的位置，WHERE作为更新字段的结束、查询条件的开始，
	for(i = 2; i < (int)vecString.size() - 1; i ++)
	{
		strItem = vecString[i];
		strItem.MakeUpper();
		if(strItem == "WHERE")
		{
			bCondition = TRUE;
			nConditionPos = i;
			break;
		}
	}
	//解析更新字段
	nRet = ParseUpdateField(vecString, stBson, lpUpdatePlan, 2, nConditionPos);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	//解析WHERE条件
	if(bCondition)
	{	
		i++;
		nRet = ParseCondition(vecString, stBson, nOffset, NULL, skOperatorStack, queMathQueue, 
							  queCompareQueue, queConditionQueue, i, vecString.size()-1);
		//不论是否执行成功，都需要先释放skOperatorStack、queMathQueue和queConditionQueue
		FreeStack(skOperatorStack);
		FreeQueue(queMathQueue);
		FreeQueue(queConditionQueue);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpUpdatePlan->m_nWhereOffset = nOffset;
	}

	lpExecutePlan->m_bDBType				= MF_DATABASE_MEMDB;
	lpExecutePlan->m_nBsonDataSize			= stBson.GetBsonDataSize();
	lpExecutePlan->m_nClientBsonDataSize	= stBson.GetBsonDataSize();
	lpExecutePlan->m_nTotalDataSize			= stBson.GetExecutePlanDataSize();
	if(lpExecutePlan->m_nBsonDataSize != lpExecutePlan->m_nTotalDataSize)
	{
		return MF_PARSECMD_EXECUTEPALN_INVALID_SIZE_ERROR;
	}
	return MF_OK;
}

int CParseSql::ParseDelete(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan)
{
	int nRet;
	string strSql;
	CMFString strItem;
	vector<CMFString> vecString;

	//首先对SQL语句进行拆分成一个一个的单词
	strSql = lpszSql;
	Parse(lpszSql, nPos, vecString);
	vecString.push_back("EOF");

	//vecString的第一个字段一定是FROM
	strItem = vecString[0];
	strItem.MakeUpper();
	if(strItem == "FROM")
	{
		nRet = ParseCommonDelete(vecString, stBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	
	lpExecutePlan->m_bDBType				= MF_DATABASE_MEMDB;
	lpExecutePlan->m_nBsonDataSize			= stBson.GetBsonDataSize();
	lpExecutePlan->m_nClientBsonDataSize	= stBson.GetBsonDataSize();
	lpExecutePlan->m_nTotalDataSize			= stBson.GetExecutePlanDataSize();
	if(lpExecutePlan->m_nBsonDataSize != lpExecutePlan->m_nTotalDataSize)
	{
		return MF_PARSECMD_EXECUTEPALN_INVALID_SIZE_ERROR;
	}
	return MF_OK;
}

int CParseSql::ParseCreate(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan)
{
	int nRet;
	UINT nOffset;
	CMFString strItem;
	vector<CMFString> vecString;
	LPCREATEEXECUTEPLANBSON  lpCreateExecutePlanBson;
	//数据库结构创建命令
	//语法原型为CREATE 类型 对象名(具体参数)，比如：
	//创建对象为CREATE OBJECT OBJECTNAME(A INT,B VARCHAR, INDEX TREE INAME(A)) DATAFILE '文件路径' TREEFILE '文件路径' KVFILE '文件路径';
	//创建序列为CREATE SEQUENCE SEQNAME MINVALUE 1 MAXVALUE  9223372036854775807 START WITH  1 INCREMENT BY  1 CACHE  20 CYCLE
	//首先对SQL语句进行拆分成一个一个的单词
	Parse(lpszSql, nPos, vecString);

	strItem = vecString[0];
	strItem.MakeUpper();
	if(strItem == "SEQUENCE")
	{
		LPFILE_SEQUENCEDEFBSON lpSeqBson;
		nRet = stBson.AllocFromBsonBuffer(lpCreateExecutePlanBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpExecutePlan->m_nCommandOffset = nOffset;
		nRet = stBson.AllocFromBsonBuffer(lpSeqBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpCreateExecutePlanBson->m_nPlanOffset = nOffset;
		//默认为通用对象
		lpCreateExecutePlanBson->m_nType	= MF_EXECUTEPLAN_OBJECTTYPE_SEQUECNE;
		lpExecutePlan->m_nObjectID			= MF_SYS_OBJECTTYPE_SEQUENCE;
		nRet = ParseCreateSequence(vecString, stBson, lpCreateExecutePlanBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(strItem == "OBJECT")
	{
		LPOBJECTDEFBSON lpObjectBson;
		nRet = stBson.AllocFromBsonBuffer(lpCreateExecutePlanBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpExecutePlan->m_nCommandOffset = nOffset;
		nRet = stBson.AllocFromBsonBuffer(lpObjectBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpCreateExecutePlanBson->m_nPlanOffset	= nOffset;
		lpObjectBson->m_bImplementClass			= MF_MEMOBJECT_IMPLEMENTCLASS_COMMON;
		lpObjectBson->m_bObjectType				= MF_OBJECT_COMMON;
		//默认为通用对象
		lpCreateExecutePlanBson->m_nType		= MF_EXECUTEPLAN_OBJECTTYPE_OBJECT;
		lpExecutePlan->m_nObjectID				= MF_SYS_OBJECTTYPE_OBJECT;
		nRet = ParseCreateObject(vecString, stBson, lpCreateExecutePlanBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(strItem == "USER")
	{
		LPUSERINFOBSON lpUserInfo;
		nRet = stBson.AllocFromBsonBuffer(lpCreateExecutePlanBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpExecutePlan->m_nCommandOffset = nOffset;

		nRet = stBson.AllocFromBsonBuffer(lpUserInfo, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpCreateExecutePlanBson->m_nPlanOffset	= nOffset;

		//默认为通用对象
		lpCreateExecutePlanBson->m_nType		= MF_EXECUTEPLAN_OBJECTTYPE_USER;
		lpExecutePlan->m_nObjectID				= MF_SYS_OBJECTTYPE_USERINFO;
		lpExecutePlan->m_bObjectType			= MF_OBJECT_COMMON;
		nRet = ParseCreateUser(vecString, stBson, lpCreateExecutePlanBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	lpExecutePlan->m_bDBType				= MF_DATABASE_MEMDB;
	lpExecutePlan->m_nBsonDataSize			= stBson.GetBsonDataSize();
	lpExecutePlan->m_nClientBsonDataSize	= stBson.GetBsonDataSize();
	lpExecutePlan->m_nTotalDataSize			= stBson.GetExecutePlanDataSize();
	if(lpExecutePlan->m_nBsonDataSize != lpExecutePlan->m_nTotalDataSize)
	{
		return MF_PARSECMD_EXECUTEPALN_INVALID_SIZE_ERROR;
	}
	return MF_OK;
}

int CParseSql::ParseDrop(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan)
{
	int nRet;
	UINT nOffset;
	string strSql;
	char* pObjectName;
	CMFString strItem;
	vector<CMFString> vecString;
	LPDROPEXECUTEPLANBSON lpDropExecutePlanBson;
	nRet = stBson.AllocFromBsonBuffer(lpDropExecutePlanBson, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlan->m_nCommandOffset = nOffset;
	//语法原型为DROP 类型 对象名，比如：
	//删除对象为DROP OBJECT OBJECTNAME
	//删除序列为DROP SEQUENCE SEQNAME
	strSql = lpszSql;
	Parse(lpszSql, nPos, vecString);
	if(vecString.size() != 2)
	{
		return MF_PARSECMD_INVALID_DROP_SYNTAX_ERROR;
	}
	strItem = vecString[0];
	strItem.MakeUpper();
	if(strItem == "SEQUENCE")
	{
		strItem = vecString[1];
		strItem.MakeUpper();
		lpDropExecutePlanBson->m_nType	 = MF_EXECUTEPLAN_OBJECTTYPE_SEQUECNE;
		lpExecutePlan->m_nObjectID = MF_SYS_OBJECTTYPE_SEQUENCE;
		memcpy(lpDropExecutePlanBson->m_pDataName, strItem.c_str(), 32);
	}
	else if(strItem == "OBJECT")
	{
		strItem = vecString[1];
		strItem.MakeUpper();
		pObjectName = (char *)strItem.c_str();
	
		lpDropExecutePlanBson->m_nType	 = MF_EXECUTEPLAN_OBJECTTYPE_OBJECT;
		lpExecutePlan->m_nObjectID		 = MF_SYS_OBJECTTYPE_OBJECT;
		memcpy(lpDropExecutePlanBson->m_pDataName, strItem.c_str(), 32);

	}
	else if(strItem == "USER")
	{
		char pUserName[32];
		strItem = vecString[1];
		if(!CopyUserNameFromSql(strItem.c_str(), strItem.length(), pUserName))
		{
			return MF_PARSECMD_INVALID_DROP_SYNTAX_ERROR;
		}
		
		lpDropExecutePlanBson->m_nType	 = MF_EXECUTEPLAN_OBJECTTYPE_USER;
		lpExecutePlan->m_nObjectID		 = MF_SYS_OBJECTTYPE_USERINFO;
		memcpy(lpDropExecutePlanBson->m_pDataName, pUserName, 32);
	}
	else
	{
		return MF_PARSECMD_DROP_LACK_KEYWORD_ERROR;
	}

	lpExecutePlan->m_bDBType					= MF_DATABASE_MEMDB;
	lpExecutePlan->m_nBsonDataSize				= stBson.GetBsonDataSize();
	lpExecutePlan->m_nClientBsonDataSize		= stBson.GetBsonDataSize();
	lpExecutePlan->m_nTotalDataSize				= stBson.GetExecutePlanDataSize();
	if(lpExecutePlan->m_nBsonDataSize != lpExecutePlan->m_nTotalDataSize)
	{
		return MF_PARSECMD_EXECUTEPALN_INVALID_SIZE_ERROR;
	}
	return MF_OK;
}

int CParseSql::ParseAlter(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan)
{
	int nRet;
	UINT nOffset;
	CMFString strItem;
	vector<CMFString> vecString;
	LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson;

	//语法原型为ALTER 类型 对象名(具体参数)，比如：
	Parse(lpszSql, nPos, vecString);
	strItem = vecString[0];
	strItem.MakeUpper();

	nRet = stBson.AllocFromBsonBuffer(lpAlterExecutePlanBson, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlan->m_nCommandOffset = nOffset;
	if(strItem == "OBJECT")
	{
		lpAlterExecutePlanBson->m_bObjectType = MF_EXECUTEPLAN_ALTERTYPE_OBJECT;
		lpExecutePlan->m_nObjectID = MF_EXECUTEPLAN_OBJECTTYPE_OBJECT;
		nRet = ParseAlterObject(vecString, stBson, lpAlterExecutePlanBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(strItem == "SYSTEM")
	{
		lpAlterExecutePlanBson->m_bObjectType = MF_EXECUTEPLAN_ALTERTYPE_SYSTEM;
		lpExecutePlan->m_nObjectID = MF_SYS_OBJECTTYPE_FILE;
		nRet = ParseAlterSystem(vecString, stBson, lpAlterExecutePlanBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else if(strItem == "USER")
	{
		lpAlterExecutePlanBson->m_bObjectType = MF_EXECUTEPLAN_ALTERTYPE_USER;
		lpExecutePlan->m_nObjectID = MF_SYS_OBJECTTYPE_USERINFO;
		nRet = ParseAlterUser(vecString, stBson, lpAlterExecutePlanBson);
		if(nRet != MF_OK)
		{
			return nRet;
		}
	}
	else
	{
		return MF_PARSECMD_ALTER_LACK_KEYWORD_ERROR;
	}

	lpExecutePlan->m_bDBType					= MF_DATABASE_MEMDB;
	lpExecutePlan->m_nBsonDataSize				= stBson.GetBsonDataSize();
	lpExecutePlan->m_nClientBsonDataSize		= stBson.GetBsonDataSize();
	lpExecutePlan->m_nTotalDataSize				= stBson.GetExecutePlanDataSize();
	if(lpExecutePlan->m_nBsonDataSize != lpExecutePlan->m_nTotalDataSize)
	{
		return MF_PARSECMD_EXECUTEPALN_INVALID_SIZE_ERROR;
	}
	return MF_OK;
}

int CParseSql::ParseGrant(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan)
{
	UINT nOffset;
	LPBYTE lpAddr;
	CMFString strItem;
	int nRet, i, nEnd, nNum;
	LPUSERINFOBSON lpUserInfo;
	vector<CMFString> vecString;
	LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson;

	Parse(lpszSql, nPos, vecString);

	nEnd = vecString.size();
	nRet = stBson.AllocFromBsonBuffer(lpAlterExecutePlanBson, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlan->m_nCommandOffset = nOffset;
	
	//计算权限个数
	nNum = 0;
	for(i = 0; i < nEnd; i++)
	{
		if(strItem == "TO")
		{
			break;
		}
		else if(strItem != ",")
		{
			nNum++;
		}
	}
	
	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(sizeof(USERINFOBSON) + 32*(nNum - 1), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpAlterExecutePlanBson->m_nPlanOffset = nOffset;
	lpAlterExecutePlanBson->m_bObjectType = MF_EXECUTEPLAN_ALTERTYPE_USER;
	lpAlterExecutePlanBson->m_nType		  = MF_EXECUTEPLAN_ALTERTYPE_ADD_AUTHORITY;
	lpUserInfo = (LPUSERINFOBSON)lpAddr;

	for(i = 0; i < nEnd; i++)
	{
		strItem = vecString[i];
		if(!CopyNameFromSql(strItem.c_str(), strItem.length(), lpUserInfo->m_pAuthorityName[lpUserInfo->m_nAuthorityNum]))
		{
			return MF_PARSECMD_INVALID_GRANT_SYNTAX_ERROR;
		}
		lpUserInfo->m_nAuthorityNum++;
		i++;
		if(i >= nEnd)
		{
			return MF_PARSECMD_INVALID_GRANT_SYNTAX_ERROR;
		}
		strItem = vecString[i];
		strItem.MakeUpper();
		if(strItem == "TO")
		{
			break;
		}
		else if(strItem != ",")
		{
			return MF_PARSECMD_INVALID_GRANT_SYNTAX_ERROR;
		}
	}

	//TO后面一定是用户名
	i++;
	strItem = vecString[i];
	if(!CopyUserNameFromSql(strItem.c_str(), strItem.length(), lpUserInfo->m_pUserName))
	{
		return MF_PARSECMD_INVALID_GRANT_SYNTAX_ERROR;
	}

	i++;
	if(i != nEnd)
	{
		return MF_PARSECMD_INVALID_GRANT_SYNTAX_ERROR;
	}

	lpExecutePlan->m_bDBType					= MF_DATABASE_MEMDB;
	lpExecutePlan->m_nBsonDataSize				= stBson.GetBsonDataSize();
	lpExecutePlan->m_nClientBsonDataSize		= stBson.GetBsonDataSize();
	lpExecutePlan->m_nTotalDataSize		= stBson.GetExecutePlanDataSize();
	if(lpExecutePlan->m_nBsonDataSize != lpExecutePlan->m_nTotalDataSize)
	{
		return MF_PARSECMD_EXECUTEPALN_INVALID_SIZE_ERROR;
	}
	return MF_OK;
}

int CParseSql::ParseRevoke(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan)
{
	UINT nOffset;
	LPBYTE lpAddr;
	CMFString strItem;
	int nRet, i, nEnd, nNum;
	LPUSERINFOBSON lpUserInfo;
	vector<CMFString> vecString;
	LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson;

	Parse(lpszSql, nPos, vecString);

	nEnd = vecString.size();
	nRet = stBson.AllocFromBsonBuffer(lpAlterExecutePlanBson, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpExecutePlan->m_nCommandOffset = nOffset;

	//计算权限个数
	nNum = 0;
	for(i = 0; i < nEnd; i++)
	{
		if(strItem == "TO")
		{
			break;
		}
		else if(strItem != ",")
		{
			nNum++;
		}
	}

	lpAddr = NULL;
	nRet = stBson.AllocFromBsonBuffer(sizeof(USERINFOBSON) + 32*(nNum - 1), nOffset, lpAddr);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpAlterExecutePlanBson->m_nPlanOffset = nOffset;
	lpAlterExecutePlanBson->m_bObjectType = MF_EXECUTEPLAN_ALTERTYPE_USER;
	lpAlterExecutePlanBson->m_nType		  = MF_EXECUTEPLAN_ALTERTYPE_DROP_AUTHORITY;
	lpUserInfo = (LPUSERINFOBSON)lpAddr;

	for(i = 0; i < nEnd; i++)
	{
		strItem = vecString[i];
		if(!CopyNameFromSql(strItem.c_str(), strItem.length(), lpUserInfo->m_pAuthorityName[lpUserInfo->m_nAuthorityNum]))
		{
			return MF_PARSECMD_INVALID_GRANT_SYNTAX_ERROR;
		}
		lpUserInfo->m_nAuthorityNum++;
		i++;
		if(i >= nEnd)
		{
			return MF_PARSECMD_INVALID_GRANT_SYNTAX_ERROR;
		}
		strItem = vecString[i];
		strItem.MakeUpper();
		if(strItem == "FROM")
		{
			break;
		}
		else if(strItem != ",")
		{
			return MF_PARSECMD_INVALID_GRANT_SYNTAX_ERROR;
		}
	}

	//TO后面一定是用户名
	i++;
	strItem = vecString[i];
	if(!CopyUserNameFromSql(strItem.c_str(), strItem.length(), lpUserInfo->m_pUserName))
	{
		return MF_PARSECMD_INVALID_GRANT_SYNTAX_ERROR;
	}

	i++;
	if(i != nEnd)
	{
		return MF_PARSECMD_INVALID_GRANT_SYNTAX_ERROR;
	}

	lpExecutePlan->m_bDBType					= MF_DATABASE_MEMDB;
	lpExecutePlan->m_nBsonDataSize				= stBson.GetBsonDataSize();
	lpExecutePlan->m_nClientBsonDataSize		= stBson.GetBsonDataSize();
	lpExecutePlan->m_nTotalDataSize				= stBson.GetExecutePlanDataSize();
	if(lpExecutePlan->m_nBsonDataSize   != lpExecutePlan->m_nTotalDataSize)
	{
		return MF_PARSECMD_EXECUTEPALN_INVALID_SIZE_ERROR;
	}
	return MF_OK;
}

int CParseSql::ParseCreateSequence(vector<CMFString> &vecString, CBaseBson& stBson, LPCREATEEXECUTEPLANBSON lpCreateObjectBson)
{
	int i, nSize;
	CMFString strItem;
	LPFILE_SEQUENCEDEFBSON lpSeqBson;
	nSize = vecString.size();
	if(nSize < 2)
	{
		//只有一个CREATE的语句，肯定是有问题的。
		return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
	}

	lpSeqBson = (LPFILE_SEQUENCEDEFBSON)(stBson.ConvertOffset2Addr(lpCreateObjectBson->m_nPlanOffset));
	strItem = vecString[1];
	if(CopyNameFromSql(strItem.c_str(), strItem.length(), lpSeqBson->m_lpszName) == 0)
	{
		return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
	}
	//给序列设置初始值
	lpSeqBson->m_nMinVal		= 1;
	lpSeqBson->m_nCurrentVal	= 1;
	lpSeqBson->m_nMaxVal		= 0x7FFFFFFFFFFFFFFF;
	lpSeqBson->m_nIncrementBy	= 1;
	lpSeqBson->m_bCacheFlag	= 20;

	//再根据命令修正默认值
	for(i = 2;i < nSize;i++)
	{
		strItem = vecString[i];
		strItem.MakeUpper();
		if(strItem == "MINVALUE")
		{
			i++;
			if(i < nSize)
			{
				strItem = vecString[i];
				if(IsNumber(strItem.c_str()) == 1)
				{
					lpSeqBson->m_nMinVal = _atoi64(strItem.c_str());
				}
				else
				{
					return MF_PARSECMD_INVALID_NUMBER_ERROR;
				}
			}
			else
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
		}
		else if(strItem == "MAXVALUE")
		{
			i++;
			if(i < nSize)
			{
				strItem = vecString[i];
				if(IsNumber(strItem.c_str()) == 1)
				{
					lpSeqBson->m_nMaxVal = _atoi64(strItem.c_str());
				}
				else
				{
					return MF_PARSECMD_INVALID_NUMBER_ERROR;
				}
			}
			else
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
		}
		else if(strItem == "START")
		{
			i++;
			if(i + 1 < nSize)
			{
				strItem = vecString[i];
				strItem.MakeUpper();
				if(strItem != "WITH")
				{
					return MF_PARSECMD_CREATE_LACK_WITH_ERROR;
				}
				i++;
				strItem = vecString[i];
				if(IsNumber(strItem.c_str()) == 1)
				{
					lpSeqBson->m_nCurrentVal = _atoi64(strItem.c_str());
				}
				else
				{
					return MF_PARSECMD_INVALID_NUMBER_ERROR;
				}
			}
			else
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
		}
		else if(strItem == "INCREMENT")
		{
			i++;
			if(i + 1 < nSize)
			{
				strItem = vecString[i];
				strItem.MakeUpper();
				if(strItem != "BY")
				{
					return MF_PARSECMD_CREATE_LACK_BY_ERROR;
				}
				i++;
				strItem = vecString[i];
				if(IsNumber(strItem.c_str()) == 1)
				{
					lpSeqBson->m_nIncrementBy = atoi(strItem.c_str());
				}
				else
				{
					return MF_PARSECMD_INVALID_NUMBER_ERROR;
				}
			}
			else
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
		}
		else if(strItem == "CACHE")
		{
			i++;
			if(i < nSize)
			{
				strItem = vecString[i];
				if(IsNumber(strItem.c_str()) == 1)
				{
					lpSeqBson->m_bCacheFlag = (BYTE)_atoi64(strItem.c_str());
				}
				else
				{
					return MF_PARSECMD_INVALID_NUMBER_ERROR;
				}
			}
			else
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
		}
		else if(strItem == "CYCLE")
		{
			lpSeqBson->m_bCycleFlag = 1;
		}
	}

	return MF_OK;
}

int CParseSql::ParseCreateObject(vector<CMFString> &vecString, CBaseBson& stBson, LPCREATEEXECUTEPLANBSON lpCreateObjectBson)
{
	UINT nOffset;
	LPBYTE lpAddr;
	CMFString strItem;
	int i, nEndPos, nRet;
	LPOBJECTDEFBSON lpObjectBson;
	char pFileName[256], pObjectName[32];

	lpObjectBson	= (LPOBJECTDEFBSON)stBson.ConvertOffset2Addr(lpCreateObjectBson->m_nPlanOffset);
	nEndPos = vecString.size();
	if(nEndPos < 3)
	{
		//只有一个CREATE的语句，肯定是有问题的。
		return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
	}

	//分配空间存放表名
	memset(pObjectName, 0, 32);
	strItem = vecString[1];
	if(CopyNameFromSql(strItem.c_str(), strItem.length(), pObjectName) == 0)
	{
		return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
	}
	
	/*nRet = m_pTableMap->FindObject(pObjectName);
	if(MF_DATABASE_FAIL != nRet)
	{
		//表存在
		return MF_PARSECREATE_OBJECT_EXIT_ERROR;
	}*/
	memcpy(lpObjectBson->m_bObjectName, pObjectName, 32);
	
	//解析表中字段
	i = nEndPos;
	nRet = ParseCreateField(vecString, stBson, lpObjectBson, 2, i);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	i++;
	for(;i < nEndPos;i++)
	{
		strItem = vecString[i];
		strItem.MakeUpper();
		if(strItem == "DATAFILE")
		{
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			strItem.Replace("\r", "");
			strItem.Replace("\n", "");
			if(CopyStringFromSql(strItem.c_str(), strItem.length(), pFileName, 256) != 1)
			{
				return MF_PARSECMD_INVALID_STRING_ERROR;
			}
			//分配空间存放数据文件路径
			lpAddr = NULL;
			nRet = stBson.AllocFromBsonBuffer(strItem.length()+1, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			memcpy(lpAddr, pFileName, strItem.length()+1);
			lpCreateObjectBson->m_nDataFilePathOffset = nOffset;
		}
		else if(strItem == "TREEFILE")
		{
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			strItem.Replace("\r", "");
			strItem.Replace("\n", "");
			if(CopyStringFromSql(strItem.c_str(), strItem.length(), pFileName, 256) != 1)
			{
				return MF_PARSECMD_INVALID_STRING_ERROR;
			}
			//分配空间存放B树索引文件路径
			lpAddr = NULL;
			nRet = stBson.AllocFromBsonBuffer(strItem.length()+1, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			memcpy(lpAddr, pFileName, strItem.length()+1);
			lpCreateObjectBson->m_nTreeFilePathOffset = nOffset;
		}
		else if(strItem == "KVFILE")
		{
			i++;
			if(i >= nEndPos)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			strItem = vecString[i];
			strItem.Replace("\r", "");
			strItem.Replace("\n", "");
			if(CopyStringFromSql(strItem.c_str(), strItem.length(), pFileName, 256) != 1)
			{
				return MF_PARSECMD_INVALID_STRING_ERROR;
			}
			//分配空间存放KV索引文件路径
			lpAddr = NULL;
			nRet = stBson.AllocFromBsonBuffer(strItem.length()+1, nOffset, lpAddr);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			memcpy(lpAddr, pFileName, strItem.length()+1);
			lpCreateObjectBson->m_nKVFilePathOffset = nOffset;
		}
	}
	return MF_OK;
}

int CParseSql::ParseCreateUser(vector<CMFString> &vecString, CBaseBson& stBson, LPCREATEEXECUTEPLANBSON lpCreateObjectBson)
{
	int nEnd;
	CMFString strItem;
	char pUserName[32];
	BYTE pPassWord[32];
	LPUSERINFOBSON lpUserInfo;
	
	memset(pUserName, 0, 32);
	memset(pPassWord, 0, 32);
	nEnd = vecString.size();
	if(nEnd < 5)
	{
		return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
	}
	lpUserInfo  = (LPUSERINFOBSON)stBson.ConvertOffset2Addr(lpCreateObjectBson->m_nPlanOffset);
	
	//USER后面一定是用户名
	strItem = vecString[1];
	if(!CopyUserNameFromSql(strItem.c_str(), strItem.length(), pUserName))
	{
		return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
	}
	memcpy(lpUserInfo->m_pUserName, pUserName, 32);
	
	//用户名后面一定是IDENTIFIED 
	strItem = vecString[2];
	strItem.MakeUpper();
	if(strItem != "IDENTIFIED")
	{
		return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
	}

	//IDENTIFIED后面一定是BY
	strItem = vecString[3];
	strItem.MakeUpper();
	if(strItem != "BY")
	{
		return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
	}

	//BY后面一定是密码
	strItem = vecString[4];
	if(!CopyPassWordFromSql(strItem.c_str(), strItem.length(), pPassWord))
	{
		return MF_PARSECREATE_USER_PASSWORDFORMAT_ERROR;
	}
	memcpy(lpUserInfo->m_pPassword, pPassWord, 32);
	return MF_OK;
}	

int CParseSql::ParseAlterSystem(vector<CMFString> &vecString, CBaseBson& stBson, LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson)
{
	//增加数据文件为ALTER SYSTEM ADD DATAFILE '文件路径' MEMFILE '内存文件名' 16MB;
	//增加B树文件为ALTER SYSTEM ADD TREEFILE '文件路径' MEMFILE '内存文件名' 16MB;
	//增加KV文件为ALTER SYSTEM ADD KVFILE '文件路径' MEMFILE '内存文件名' 16MB;
	//删除数据文件ALTER SYSTEM DROP DATAFILE '文件路径';
	//删除B树文件ALTER SYSTEM DROP TREEFILE '文件路径';
	//删除KV文件文件ALTER SYSTEM DROP KVFILE '文件路径';
	//修改数据文件大小ALTER SYSTEM MODIFY DATAFILE '文件路径' 24MB;
	//修改数据文件大小ALTER SYSTEM MODIFY TREEFILE '文件路径' 24MB;
	//修改数据文件大小ALTER SYSTEM MODIFY KVFILE '文件路径' 24MB;
	//修改数据文件路径ALTER SYSTEM MODIFY DATAFILE '文件路径' TO '文件新路径';
	//修改数据文件路径ALTER SYSTEM MODIFY TREEFILE '文件路径' TO '文件新路径';
	//修改数据文件路径ALTER SYSTEM MODIFY KVFILE '文件路径' TO '文件新路径';

	UINT nOffset;
	LPBYTE lpAddr;
	char pFieldName[32];
	CMFString strItem, strTemp;
	int i, nSize, nRet, nBufferLen, nValue;
	LPFILE_MEMDBFILEINFOBSON lpMemDBFileBson;
	LPALTERSETEXPFIELDBSON lpMemDBFileSetBson;

	nSize = vecString.size();
	if(nSize < 2)
	{
		//只有一个CREATE的语句，肯定是有问题的。
		return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
	}
	strItem = vecString[1];
	strItem.MakeUpper();


	if(strItem == "ADD")
	{
		nRet = stBson.AllocFromBsonBuffer(lpMemDBFileBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpAlterExecutePlanBson->m_nPlanOffset = nOffset;

		lpAlterExecutePlanBson->m_nType		 = MF_EXECUTEPLAN_ALTERTYPE_ADD_DBFILE;
		for(i = 2;i < nSize;i++)
		{
			strItem = vecString[i];
			strItem.MakeUpper();
			if(strItem == "DATAFILE" || strItem == "TREEFILE" || strItem == "KVFILE")
			{
				if(strItem == "DATAFILE")
					lpMemDBFileBson->m_bFileType = MF_SYS_FILETYPE_DATAFILE;
				else if(strItem == "TREEFILE")
					lpMemDBFileBson->m_bFileType = MF_SYS_FILETYPE_TREEINDEXFILE;
				else
					lpMemDBFileBson->m_bFileType = MF_SYS_FILETYPE_KVINDEXFILE;

				i++;
				if(i < nSize)
				{
					strItem = vecString[i];
					strItem.Replace("\r", "");
					strItem.Replace("\n", "");
					if(CopyStringFromSql(strItem.c_str(), strItem.length(), lpMemDBFileBson->m_pAlterFilePath, 256) != 1)
					{
						return MF_PARSECMD_INVALID_STRING_ERROR;
					}
				}
				else
				{
					return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
				}
			}
			else if(strItem == "MEMFILE")
			{
				i++;
				if(i < nSize)
				{
					strItem = vecString[i];
					strItem.Replace("\r", "");
					strItem.Replace("\n", "");
					if(CopyStringFromSql(strItem.c_str(), strItem.length(), lpMemDBFileBson->m_lpszMemFileName, 64) != 1)
					{
						return MF_PARSECMD_INVALID_STRING_ERROR;
					}
				}
				else
				{
					return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
				}
			}
			else
			{
				//16MB
				lpMemDBFileBson->m_nFileSize = ToNumber(strItem.c_str(), strItem.length());
			}
		}
	}
	else if(strItem == "DROP")
	{
		nRet = stBson.AllocFromBsonBuffer(lpMemDBFileBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpAlterExecutePlanBson->m_nPlanOffset = nOffset;

		lpAlterExecutePlanBson->m_nType = MF_EXECUTEPLAN_ALTERTYPE_DROP_DBFILE;
		for(i = 2;i < nSize;i++)
		{
			strItem = vecString[i];
			strItem.MakeUpper();
			if(strItem == "DATAFILE" || strItem == "TREEFILE" || strItem == "KVFILE")
			{
				if(strItem == "DATAFILE")
				{
					lpMemDBFileBson->m_bFileType = MF_SYS_FILETYPE_DATAFILE;
				}
				else if(strItem == "TREEFILE")
				{
					lpMemDBFileBson->m_bFileType = MF_SYS_FILETYPE_TREEINDEXFILE;
				}
				else
				{
					lpMemDBFileBson->m_bFileType = MF_SYS_FILETYPE_KVINDEXFILE;
				}

				i++;
				if(i < nSize)
				{
					strItem = vecString[i];
					strItem.Replace("\r", "");
					strItem.Replace("\n", "");
					if(CopyStringFromSql(strItem.c_str(), strItem.length(), lpMemDBFileBson->m_pOriginFilePath, 256) != 1)
					{
						return MF_PARSECMD_INVALID_STRING_ERROR;
					}
				}
				else
				{
					return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
				}
			}
			else if(strItem == "MEMFILE")
			{
				i++;
				if(i < nSize)
				{
					strItem = vecString[i];
					strItem.Replace("\r", "");
					strItem.Replace("\n", "");
					if(CopyStringFromSql(strItem.c_str(), strItem.length(), lpMemDBFileBson->m_lpszMemFileName, 64) != 1)
					{
						return MF_PARSECMD_INVALID_STRING_ERROR;
					}
				}
				else
				{
					return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
				}
			}
			else
			{
				return MF_PARSECMD_ALTER_LACK_KEYWORD_ERROR;
			}
		}
	}
	else if(strItem == "MODIFY")
	{
		nRet = stBson.AllocFromBsonBuffer(lpMemDBFileBson, nOffset);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpAlterExecutePlanBson->m_nPlanOffset = nOffset;
		lpAlterExecutePlanBson->m_nType = MF_EXECUTEPLAN_ALTERTYPE_MODIFY_DBFILE;
		for(i = 2;i < nSize;i++)
		{
			strItem = vecString[i];
			strItem.MakeUpper();
			if(strItem == "DATAFILE" || strItem == "TREEFILE" || strItem == "KVFILE")
			{
				if(strItem == "DATAFILE")
				{
					lpMemDBFileBson->m_bFileType = MF_SYS_FILETYPE_DATAFILE;
				}
				else if(strItem == "TREEFILE")
				{
					lpMemDBFileBson->m_bFileType = MF_SYS_FILETYPE_TREEINDEXFILE;
				}
				else
				{
					lpMemDBFileBson->m_bFileType = MF_SYS_FILETYPE_KVINDEXFILE;
				}

				i++;
				if(i < nSize)
				{
					strItem = vecString[i];
					strItem.Replace("\r", "");
					strItem.Replace("\n", "");
					if(CopyStringFromSql(strItem.c_str(), strItem.length(), lpMemDBFileBson->m_pOriginFilePath, 256) != 1)
					{
						return MF_PARSECMD_INVALID_STRING_ERROR;
					}
				}
				else
				{
					return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
				}
			}
			else if(strItem == "MEMFILE")
			{
				i++;
				if(i < nSize)
				{
					strItem = vecString[i];
					strItem.Replace("\r", "");
					strItem.Replace("\n", "");
					if(CopyStringFromSql(strItem.c_str(), strItem.length(), lpMemDBFileBson->m_pOriginFilePath, 64) != 1)
					{
						return MF_PARSECMD_INVALID_STRING_ERROR;
					}
				}
				else
				{
					return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
				}
			}
			else if(strItem == "TO")
			{
				i++;
				if(i < nSize)
				{
					strItem = vecString[i];
					strItem.Replace("\r", "");
					strItem.Replace("\n", "");
					if(CopyStringFromSql(strItem.c_str(), strItem.length(), lpMemDBFileBson->m_pAlterFilePath, 256) != 1)
					{
						return MF_PARSECMD_INVALID_STRING_ERROR;
					}
				}
				else
				{
					return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
				}
			}
			else
			{
				//16MB
				lpMemDBFileBson->m_nFileSize = ToNumber(strItem.c_str(), strItem.length());
			}
		}
	}
	else if(strItem == "SET")
	{
		nBufferLen = sizeof(ALTERSETEXPFIELDBSON) + sizeof(int) - 1;
		lpAddr = NULL;
		nRet   = stBson.AllocFromBsonBuffer(nBufferLen, nOffset, lpAddr);
		lpMemDBFileSetBson = (LPALTERSETEXPFIELDBSON)lpAddr;
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpAlterExecutePlanBson->m_nPlanOffset = nOffset;

		lpAlterExecutePlanBson->m_nType = MF_EXECUTEPLAN_ALTERTYPE_SET_PARAMETER;

		strItem = vecString[vecString.size() - 3 ];

		if (CopyNameFromSql(strItem.c_str(), strItem.length(), pFieldName))
		{
			memcpy(lpMemDBFileSetBson->m_pParameter, pFieldName, strItem.length());
		}
		else
		{
			return MF_PARSECMD_INVALID_STRING_ERROR;
		}

		lpMemDBFileSetBson->m_bDataType = MF_VARDATA_INT;
		strItem = vecString[vecString.size() - 1 ];
		if (IsNumber(strItem.c_str()) == 1)
		{
			nValue = atoi(strItem.c_str());
			*(int*)(lpMemDBFileSetBson->m_bDataBuffer) = nValue;
		}
		else
		{
			return MF_PARSECMD_INVALID_STRING_ERROR;
		}
		lpMemDBFileSetBson->m_bParameterType = MF_PARAMETER_UNKNOWN;
	}
	return MF_OK;
}

int CParseSql::ParseAlterObject(vector<CMFString> &vecString, CBaseBson& stBson, LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson)
{
	UINT nOffset;
	char pObjectName[32];
	CMFString strItem, strTemp;
	LPEXECUTEPLANBSON lpExecutePlan;
	int i, nEnd, nRet, n, nRelationPos;

	lpExecutePlan = (LPEXECUTEPLANBSON)stBson.GetBuffer();
	//修改对象增加列为ALTER OBJECT OBJECTNAME ADD(A INT,B VARCHAR);
	//修改对象修改列为ALTER OBJECT OBJECTNAME MODIFY(A INT,B VARCHAR);
	//修改对象删除列为ALTER OBJECT OBJECTNAME DROP(A);
	//修改对象增加索引为ALTER OBJECT OBJECTNAME ADD INDEX NAME(A) TREEFILE '文件路径' BLOCKSIZE 32KB;
	//修改对象增加索引为ALTER OBJECT OBJECTNAME ADD INDEX NAME(A) KVFILE '文件路径' BLOCKSIZE 512KB;
	//修改对象增加索引为ALTER OBJECT OBJECTNAME DROP INDEX NAME;
	//对象内存整理（包括索引）为ALTER OBJECT OBJECTNAME REBUILD;
	//索引内存整理为ALTER INDEX INDEXNAME REBUILD;
	nEnd = vecString.size();
	if(nEnd < 4)
	{
		//只有一个ALTER的语句，肯定是有问题的。
		return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
	}
	strItem = vecString[1];
	strItem.MakeUpper();
	//Object名称
	memcpy(pObjectName, strItem.c_str(), 32);

	nRelationPos = 0;
	strItem		 = vecString[2];
	strItem.MakeUpper();
	if(strItem == "ADD")
	{
		strItem = vecString[3];
		strItem.MakeUpper();
		if(strItem == "(")
		{	
			LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson;
			nRet = stBson.AllocFromBsonBuffer(lpAlterObjectFieldBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpAlterExecutePlanBson->m_nPlanOffset = nOffset;
			lpAlterExecutePlanBson->m_nType	      = MF_EXECUTEPLAN_ALTERTYPE_ADD_FIELD;

			memcpy(lpAlterObjectFieldBson->m_pObjectName, pObjectName, 32);

			lpExecutePlan->m_bObjectType		  = MF_OBJECT_COMMON;
			lpAlterObjectFieldBson->m_bObjectType = MF_OBJECT_COMMON;
			nRet = ParseAddField(vecString, stBson, lpAlterObjectFieldBson, 4, nEnd);
			if(nRet != MF_OK)
			{
				return nRet;
			}
		}
		else
		{
			//添加索引情况
			LPFILE_INDEXDEFBSON lpIndexBson;
		
			strItem.MakeUpper();
			if(strItem != "INDEX")
			{
				return MF_PARSECMD_ALTER_LACK_KEYWORD_ERROR;
			}
			if(nEnd < 9)
			{
				//只有一个ALTER的语句，肯定是有问题的。
				return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
			}
			
			nRet = stBson.AllocFromBsonBuffer(lpIndexBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			memcpy(lpIndexBson->m_pObjectName, pObjectName, 32);
			lpAlterExecutePlanBson->m_nPlanOffset = nOffset;
			lpAlterExecutePlanBson->m_nType	      = MF_EXECUTEPLAN_ALTERTYPE_ADD_INDEX;
			
			i = 4;
			strItem = vecString[i];
			if(strItem.CompareNoCase("UNIQUE") == 0)
			{
				lpIndexBson->m_bConstraintType = MF_CONSTRAINT_UNIQUE;
				i++;
			}
			else if(strItem.CompareNoCase("PRIMARY") == 0)
			{
				i++;
				strItem = vecString[i];
				strItem.MakeUpper();
				if(strItem != "KEY")
				{
					return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
				}
				lpIndexBson->m_bConstraintType = MF_CONSTRAINT_PRIMARYKEY;
				i++;
			}
			
			//取索引名
			strItem = vecString[i];
			if(CopyNameFromSql(strItem.c_str(), strItem.length(), lpIndexBson->m_pIndexName) == 0)
			{
				return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
			}

			i++;
			strItem = vecString[i];
			if(strItem != "(")
			{
				return MF_PARSECMD_ALTER_LACK_BRACE_ERROR;
			}	
			
			//取出字段名
			n = 0;
			i++;
			while(TRUE)
			{
				if(i >= nEnd)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				strItem = vecString[i];
				if(CopyNameFromSql(strItem.c_str(), strItem.length(), lpIndexBson->m_pFieldName[n]) == 0)
				{
					return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
				}
				n++;
				if(n > 4)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}

				i++;
				if(i >= nEnd)
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
				strItem = vecString[i];
				if(strItem == ",")
				{
					i++;
					continue;
				}
				else if(strItem == ")")
				{
					break;
				}
				else
				{
					return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
				}
			}
			
			lpIndexBson->m_bObjectType		= MF_OBJECT_COMMON;
			lpExecutePlan->m_bObjectType	= MF_OBJECT_COMMON;

			i++;
			if(i > nEnd)
			{
				return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
			}
			for(;i < nEnd;i++)
			{
				//索引文件名
				strItem = vecString[i];
				strItem.MakeUpper();
				if(strItem == "BLOCKSIZE")
				{
					i++;
					if(i >= nEnd)
					{
						return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
					}
					strItem = vecString[i];
					lpIndexBson->m_nBlockSize = (int)ToNumber(strItem.c_str(), strItem.length());
				}
				else if(strItem == "TREEFILE")
				{
					lpIndexBson->m_bFileType = MF_SYS_FILETYPE_TREEINDEXFILE;
					i++;
					if(i >= nEnd)
					{
						return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
					}
					strItem = vecString[i];
					if(CopyStringFromSql(strItem.c_str(), strItem.length(), lpIndexBson->m_pFilePath, 256) != 1)
					{
						return MF_PARSECMD_INVALID_STRING_ERROR;
					}
				}
				else if(strItem == "KVFILE")
				{
					lpIndexBson->m_bFileType = MF_SYS_FILETYPE_KVINDEXFILE;
					i++;
					if(i >= nEnd)
					{
						return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
					}

					strItem = vecString[i];
					if(CopyStringFromSql(strItem.c_str(), strItem.length(), lpIndexBson->m_pFilePath, 256) != 1)
					{
						return MF_PARSECMD_INVALID_STRING_ERROR;
					}
				}
				else
				{
					return MF_PARSECMD_ALTER_LACK_KEYWORD_ERROR;
				}
			}
		}
	}
	else if(strItem == "DROP")
	{
		strItem = vecString[3];
		strItem.MakeUpper();
		if(strItem == "(")
		{
			LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson;

			nRet = stBson.AllocFromBsonBuffer(lpAlterObjectFieldBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			lpAlterExecutePlanBson->m_nPlanOffset = nOffset;
			lpAlterExecutePlanBson->m_nType		 = MF_EXECUTEPLAN_ALTERTYPE_DROP_FIELD;
			memcpy(lpAlterObjectFieldBson->m_pObjectName, pObjectName, 32);

			lpExecutePlan->m_bObjectType		  = MF_OBJECT_COMMON;
			lpAlterObjectFieldBson->m_bObjectType = MF_OBJECT_COMMON;
			nRet = ParseDropField(vecString, stBson, lpAlterObjectFieldBson, 4, nEnd);
			if(nRet != MF_OK)
			{
				return nRet;
			}

		}
		else
		{
			LPFILE_INDEXDEFBSON lpIndexBson;

			lpExecutePlan->m_bObjectType		  = MF_OBJECT_COMMON;
			//为删除索引命令
			strItem.MakeUpper();
			if(strItem != "INDEX")
			{
				return MF_PARSECMD_ALTER_LACK_KEYWORD_ERROR;
			}
			if(nEnd != 5)
			{
				//只有一个CREATE的语句，肯定是有问题的。
				return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
			}

			nRet = stBson.AllocFromBsonBuffer(lpIndexBson, nOffset);
			if(nRet != MF_OK)
			{
				return nRet;
			}
			memcpy(lpIndexBson->m_pObjectName, pObjectName, 32);
			lpAlterExecutePlanBson->m_nPlanOffset = nOffset;
			lpAlterExecutePlanBson->m_nType	   = MF_EXECUTEPLAN_ALTERTYPE_DROP_INDEX;

			//取名字数据
			strItem = vecString[4];
			if(CopyNameFromSql(strItem.c_str(), strItem.length(), lpIndexBson->m_pIndexName) == 0)
			{
				return MF_PARSECMD_OBJECTNAME_SYNTAX_ERROR;
			}
		}
	}
	else
	{
		return MF_PARSECMD_INVALID_ALTER_SYNTAX_ERROR;
	}
	return MF_OK;
}

int CParseSql::ParseAlterUser(vector<CMFString> &vecString, CBaseBson& stBson, LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson)
{
	UINT nOffset;
	int nRet, nEnd;
	CMFString strItem;
	char pUserName[32];
	BYTE pPassWord[32];
	LPUSERINFOBSON lpUserInfo;

	memset(pUserName, 0, 32);
	memset(pPassWord, 0, 32);
	nEnd = vecString.size();
	if(nEnd < 3)
	{
		return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
	}
	nRet = stBson.AllocFromBsonBuffer(lpUserInfo, nOffset);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	lpAlterExecutePlanBson->m_nPlanOffset = nOffset;

	//USER后面一定是用户名
	strItem = vecString[1];
	if(!CopyUserNameFromSql(strItem.c_str(), strItem.length(), pUserName))
	{
		return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
	}
	memcpy(lpUserInfo->m_pUserName, pUserName, 32);

	
	strItem = vecString[2];
	strItem.MakeUpper();
	if(strItem == "IDENTIFIED")
	{
		lpAlterExecutePlanBson->m_nType = MF_EXECUTEPLAN_ALTERTYPE_CHANGE_PASSWORD;
		//IDENTIFIED后面一定是BY
		strItem = vecString[3];
		strItem.MakeUpper();
		if(strItem != "BY")
		{
			return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
		}

		//BY后面一定是密码
		strItem = vecString[4];
		if(!CopyPassWordFromSql(strItem.c_str(), strItem.length(), pPassWord))
		{
			return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
		}
		memcpy(lpUserInfo->m_pPassword, pPassWord, 32);	
	}
	else if(strItem == "ENABLE")
	{
		lpAlterExecutePlanBson->m_nType = MF_EXECUTEPLAN_ALTERTYPE_ENABLE_USER;
	}
	else if(strItem == "DISABLE")
	{
		lpAlterExecutePlanBson->m_nType = MF_EXECUTEPLAN_ALTERTYPE_DISABLE_USER;
	}
	else
	{
		return MF_PARSECMD_INVALID_CREATE_SYNTAX_ERROR;
	}
	return MF_OK;
}