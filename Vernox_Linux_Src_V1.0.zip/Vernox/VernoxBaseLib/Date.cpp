﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "Date.h"

CDate::CDate(void)
{
}

CDate::~CDate(void)
{
}

//时间转换函数
DATE CDate::ConvertToDateTime(int nYear, int nMonth, int nDay, int nHour, int nMin, int nSec)
{
	tm tmTime;
	DATE dtDate;
	time_t tTime;
	dtDate = 0;

	tmTime.tm_year = nYear - 1900;
	tmTime.tm_mon  = nMonth - 1;
	tmTime.tm_mday = nDay;
	tmTime.tm_hour = nHour;
	tmTime.tm_min  = nMin;
	tmTime.tm_sec  = nSec;

	tTime = mktime(&tmTime);
	dtDate = ConvertTimetoDate(tTime);

	return dtDate;
}


//拆分日期字符串或日期格式字符串
int CDate::ParseString(char* pDate, vector<CMFString>& vecString, BOOL bFormat)
{
	int i = 0;
	char* pData = NULL, *pWord = NULL;
	CMFString strItem;

	pData = pDate;
	pWord = NULL;
	for(i = 0; pData[i] != 0; i++)
	{		
		if(pData[i] == ' ' || pData[i] == '	' || pData[i] == '\r' || pData[i] == '\n')			//注意：第一个条件是空格，第二个条件是TAB
		{
			//作为分隔符
			if(pWord == NULL)
			{
				//直接忽略多余的空格及分隔符
				continue;
			}
			else
			{
				char cData = pData[i];
				pData[i] = 0;
				strItem = pWord;
				vecString.push_back(strItem);
				pData[i] = cData;
				pWord = NULL;
			}
		}
		else if(pData[i] == '-' || pData[i] == '/' || pData[i] == ':')
		{
			//分隔符直接忽略掉
			char cData[2];
			cData[0] = pData[i];
			cData[1] = 0;
			if(pWord != NULL)
			{
				char cData = pData[i];
				pData[i] = 0;
				strItem = pWord;
				vecString.push_back(strItem);
				pData[i] = cData;
				pWord = NULL;
			}
		}
		else if(pData[i] != 0)
		{
			if(bFormat)
			{
				if((pData[i] >= 'a' && pData[i] <= 'z') || (pData[i] >= 'A' && pData[i] <= 'Z'))
				{
					if(pWord == NULL)
					{
						pWord = pData + i;
					}
				}
			}
			else if(pData[i] >= '0' && pData[i] <= '9')
			{
				if(pWord == NULL)
				{
					pWord = pData + i;
				}
			}
			else
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
		}
	}
	if(pWord != NULL)
	{
		char cData = pData[i];
		pData[i] = 0;
		strItem = pWord;
		vecString.push_back(strItem);
		pData[i] = cData;
		pWord = NULL;
	}
	return MF_OK;
}
//解析日期格式
int CDate::ParseFormat(char* pFormat, vector<CMFString>& vecString, BOOL& bDouble, BOOL& bHour24)
{
	int nRet;
	nRet = ParseString(pFormat, vecString, TRUE);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	CMFString strItem;
	for(unsigned int i = 0; i < vecString.size(); i++)
	{
		strItem = vecString[i];
		strItem.MakeUpper();
		switch(i)
		{
		case YEAR:
			if(strItem == "YYYY" )
			{
				bDouble = TRUE;
			}
			else if(strItem != "YY")
			{
				bDouble = FALSE;
			}	
			else
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			break;
		case MONTH:
			if(strItem != "MM")
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			break;
		case DAY:
			if(strItem != "DD")
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			break;
		case HOUR:
			if(strItem == "HH24")
			{
				bHour24 = TRUE;
			}
			else if(strItem == "HH")
			{
				bHour24 = FALSE;
			}
			else
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			break;
		case MIN:
			if(strItem != "MI")
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			break;
		case SEC:
			if(strItem != "SS")
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			break;
		}
	}
	return MF_OK;
}

//获取日期
int CDate::ToDate(char* pDate, char* pFormat, DATE& dtDate)
{
	int nRet		= 0;
	int nYear		= 0;
	int nMonth		= 0;
	int nDay		= 0;
	int nHour		= 0;
	int nMin		= 0;
	int nSec		= 0;
	CMFString		strItem;

	vector<CMFString> vecFormat;
	BOOL bDouble = FALSE;
	BOOL bHour24 = FALSE;
	nRet = ParseFormat(pFormat, vecFormat, bDouble, bHour24);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	vector<CMFString> vecDate;
	nRet = ParseString(pDate, vecDate, FALSE);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	if(vecFormat.size() != vecDate.size())
	{
		return MF_COMMON_INVALID_DATEFORMAT;
	}

	BOOL bLeapYear = FALSE;
	for(unsigned int i = 0; i < vecDate.size(); i++)
	{
		strItem = vecDate[i];
		switch(i)
		{
		case YEAR:
			if(strItem.length() < 1)
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			if(!bDouble)
			{
				if(strItem.length() > 2)
				{
					return MF_COMMON_INVALID_DATEFORMAT;
				}
			}
			nYear = atoi(strItem.c_str());
			bLeapYear = (nYear % 4 == 0); 
			break;
		case MONTH:
			//月
			nMonth = atoi(strItem.c_str());
			if(nMonth < 1 || nMonth > 12)
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			break;
		case DAY:
			//日
			nDay = atoi(strItem.c_str());
			if(nDay < 1)
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			if(nMonth == 2)
			{
				if(bLeapYear)
				{
					if(nDay > 29)
					{
						return MF_COMMON_INVALID_DATEFORMAT;
					}
				}
				else
				{
					if(nDay > 28)
					{
						return MF_COMMON_INVALID_DATEFORMAT;
					}
				}
			}
			else if(nMonth == 1 || nMonth == 3 || nMonth == 5 || nMonth == 7 ||
				nMonth == 8 || nMonth == 10|| nMonth == 12)
			{
				if(nDay > 31)
				{
					return MF_COMMON_INVALID_DATEFORMAT;
				}
			}
			else 
			{
				if(nDay > 30)
				{
					return MF_COMMON_INVALID_DATEFORMAT;
				}
			}
			break;
		case HOUR:
			//时
			nHour = atoi(strItem.c_str());
			if(nHour < 0)
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			if(bHour24)
			{
				if(nHour > 24)
				{
					return MF_COMMON_INVALID_DATEFORMAT;
				}
			}
			else
			{
				if(nHour > 12)
				{
					return MF_COMMON_INVALID_DATEFORMAT;
				}
			}
			break;
		case MIN:
			nMin = atoi(strItem.c_str());
			if(nMin < 0 || nMin > 60)
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			break;
		case SEC:
			//秒
			nSec = atoi(strItem.c_str());
			if(nSec < 0 || nSec > 60)
			{
				return MF_COMMON_INVALID_DATEFORMAT;
			}
			break;
		}
	}
	dtDate = ConvertToDateTime(nYear, nMonth, nDay, nHour, nMin, nSec);
	if(0 == dtDate)
	{
		return MF_COMMON_INVALID_DATEFORMAT;
	}
	return MF_OK;
}

//将数据转换为字符串
int CDate::ToChar(CBaseBson& stBson, DATE dtDate, char* pFormat, LPBYTE & lpDate)
{
	int nRet;
	tm* pTime;
	time_t tTime;
	BOOL bDouble, bHour24;
	vector<CMFString> vecFormat;

	lpDate = NULL;
	nRet = stBson.AllocBuffer(32, lpDate);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	nRet = CDate::ParseFormat(pFormat, vecFormat, bDouble, bHour24);
	if(nRet != MF_OK)
	{
		return nRet;
	}

	tTime = ConvertDateToTime(dtDate);
	pTime = localtime(&tTime);

	sprintf((char*)lpDate, "%d-%02d-%02d %02d:%02d:%02d",pTime->tm_year+1900,pTime->tm_mon+1, pTime->tm_mday, pTime->tm_hour, pTime->tm_min, pTime->tm_sec);
	return MF_OK;
}

//将数据转换为字符串
int CDate::ToChar(CBaseBson& stBson, VARDATA varData, LPBYTE &lpData)
{
	int nRet;

	lpData = NULL;
	nRet = stBson.AllocBuffer(32, lpData);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	switch(varData.m_vt)
	{
	case MF_VARDATA_INT:
		sprintf((char*)lpData, "%d", varData.m_nValue);
		break;
	case MF_VARDATA_INT64:
		sprintf((char*)lpData, "%lld", varData.m_llValue);
		break;
	case MF_VARDATA_DOUBLE:
		sprintf((char*)lpData, "%f", varData.m_dblValue);
		break;
	}
	return MF_OK;
}