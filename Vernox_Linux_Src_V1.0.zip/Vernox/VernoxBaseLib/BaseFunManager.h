﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

class CBaseFunManager
{
protected:
	CBaseFunManager(void);
	~CBaseFunManager(void);

	//时间函数
	static int SysData(VARDATA& varResult);
	//TODATE函数
	static int ToDate(char* pDate, char* pDateFormat, VARDATA& varResult);
	//TOCHAR函数
	static int ToChar(CBaseBson& stBson, VARDATA varDate, VARDATA& varResult, char* pDateFormat = NULL);
public:
	//获取函数返回值类型
	static int GetFunRetValType(BYTE bFunction, BYTE& bRetType);
	//获取函数返回值所需Buffer大小
	static int GetFuncBufferLen(BYTE bFunction, int& nLen);
	//获得普通函数的函数值
	static int GetFunctionVal(CBaseBson& stBson, BYTE bFunType, const VARDATA& varValue1, const VARDATA& varValue2, VARDATA& varResult);
};
