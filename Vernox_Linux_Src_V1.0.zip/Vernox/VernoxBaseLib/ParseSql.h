﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "BaseBson.h"
#include <stack>
#include <queue>
using namespace std;
//定义运算符类型
#define OPREATOR_BRACKET        0               //括号类型
#define OPERATOR_MATH			1				//算数运算符
#define OPERATOR_COMPARE		2				//比较运算符
#define OPERATOR_LOGIC          3	            //逻辑运算符
#define OPERATOR_FUNCTION       4	            //函数运算符

//定义运算符类型(数字型或字符串型)
class CTableMap;
class CParseSql
{
protected:
	#pragma pack(1)
	/************************************************************************
	处理查询条件的数据结构
	************************************************************************/
	//用于BSON的混合队列(用于存放条件或运算符)
	typedef struct stu_CONDITIONBSION_MIXQUEUENODE
	{
		BYTE m_bOperator;												  //是否为运算符
		union
		{
			MF_EXECUTEPLAN_OPERATOR m_bLogicOP;							  //逻辑运算符
			int					    m_nCompareExpOffset;				  //比较表达式的偏移(指向LPCOMPAREEXPBSON)	
		};

		stu_CONDITIONBSION_MIXQUEUENODE()
		{
			m_bOperator = 0;
			m_nCompareExpOffset = 0;
		}
	}CONDITIONBSON_MIXQUEUENODE,*LPCONDITIONBSON_MIXQUEUENODE;
	//逻辑栈中的结点结构体
	typedef struct stu_CONDITIONSTACKNODEBSON
	{
		BYTE m_bConditionType;						//字段条件类型，如果为0表示m_nCompareExpOffset有效，为1表示m_nWhereOffset有效
		union
		{
			int 	m_nCompareExpOffset;
			int     m_nWhereOffset;
		};
		stu_CONDITIONSTACKNODEBSON()
		{
			m_bConditionType = 0;
			m_nCompareExpOffset = 0;
		}
	}CONDITIONSTACKNODEBSON,*LPCONDITIONSTACKNODEBSON;
	/************************************************************************
		处理字段四则表达式的数据结构
	************************************************************************/
	//定义算数运算符结构体
	typedef struct stu_MATHOPERATOR
	{
		MF_EXECUTEPLAN_OPERATOR		   m_bMathOp;				//运算符
		BYTE						   m_bPriority;				//优先级
		BYTE						   m_bType;					//运算符类型
		//重载赋值运算符
		stu_MATHOPERATOR(MF_EXECUTEPLAN_OPERATOR bMathOp)
		{
			m_bMathOp = bMathOp;
			switch(bMathOp)
			{
			case MF_EXECUTEPLAN_OPERATOR_COUNT:
			case MF_EXECUTEPLAN_OPERATOR_SYSDATE:
			case MF_EXECUTEPLAN_OPERATOR_NEXTVAL:
			case MF_EXECUTEPLAN_OPERATOR_CURRVAL:
			case MF_EXECUTEPLAN_OPERATOR_TOCHAR:
			case MF_EXECUTEPLAN_OPERATOR_TODATE:
			case MF_EXECUTEPLAN_OPERATOR_SEQUENCE:
			case MF_EXECUTEPLAN_OPERATOR_CHECKCHILD:
				m_bPriority = 11;
				m_bType = OPERATOR_FUNCTION;
				break;
			case MF_EXECUTEPLAN_OPERATOR_SIGNMINUS:
				m_bPriority = 10;
				m_bType = OPERATOR_MATH;
				break;
			case MF_EXECUTEPLAN_OPERATOR_MULTIPLY:
			case MF_EXECUTEPLAN_OPERATOR_DIVIDE:
				m_bPriority = 9;
				m_bType = OPERATOR_MATH;
				break;
			case MF_EXECUTEPLAN_OPERATOR_PLUS:
			case MF_EXECUTEPLAN_OPERATOR_MINUS:
				m_bPriority = 8;
				m_bType = OPERATOR_MATH;
				break;
			case MF_EXECUTEPLAN_OPERATOR_LINK:
				m_bPriority = 7;
				m_bType = OPERATOR_MATH;
				break;
			case MF_EXECUTEPLAN_OPERATOR_EQUAL:
			case MF_EXECUTEPLAN_OPERATOR_NOTEQUAL:
			case MF_EXECUTEPLAN_OPERATOR_GREATER:
			case MF_EXECUTEPLAN_OPERATOR_GREATEREQUAL:
			case MF_EXECUTEPLAN_OPERATOR_LESS:
			case MF_EXECUTEPLAN_OPERATOR_LESSEQUAL:
			case MF_EXECUTEPLAN_OPERATOR_BETWEEN:
			case MF_EXECUTEPLAN_OPERATOR_LIKE:
			case MF_EXECUTEPLAN_OPERATOR_IN:
			case MF_EXECUTEPLAN_OPERATOR_NOTIN:
			case MF_EXECUTEPLAN_OPERATOR_PRIOR:
			case MF_EXECUTEPLAN_OPERATOR_LPRIOR:
			case MF_EXECUTEPLAN_OPERATOR_RPRIOR:
				m_bPriority = 6;
				m_bType = OPERATOR_COMPARE;
				break;
			case MF_EXECUTEPLAN_OPERATOR_NOT:
				m_bPriority = 5;
				m_bType = OPERATOR_LOGIC;
				break;
			case MF_EXECUTEPLAN_OPERATOR_AND:
				m_bPriority = 4;
				m_bType = OPERATOR_LOGIC;
				break;
			case MF_EXECUTEPLAN_OPERATOR_OR:
				m_bPriority = 3;
				m_bType = OPERATOR_LOGIC;
				break;
			default:
				m_bPriority = 0;
				m_bType = OPREATOR_BRACKET;
				break;
			}
		}
	}MATHOPERATOR,*LPMATHOPERATOR;

	//定义表达式BSON字段混合队列
	typedef struct stu_EXPFIELDBSON_MIXQUEUENODE
	{
		BYTE m_bOperator;												   //是否为运算符
		union
		{
			MF_EXECUTEPLAN_OPERATOR		m_bMathOp;						   //字段运算符
			int						    m_nExpFieldOffset;				   //表达式结构体
		};

		stu_EXPFIELDBSON_MIXQUEUENODE()
		{
			m_bOperator = 0;
			m_nExpFieldOffset = 0;
		}
	}EXPFIELDBSON_MIXQUEUENODE,*LPEXPFIELDBSON_MIXQUEUENODE;
	//定义表达式BSON栈结点
	typedef struct stu_EXPBSONSTACKNODE
	{
		BYTE m_bExpressionType;		   //表达式类型，如果为0表示m_pExpressionField有效，为1表示m_pExpression有效		
		union
		{
			int						   m_nExpFieldOffset;
			int					       m_nExpOffset;
		};

		stu_EXPBSONSTACKNODE()
		{
			m_bExpressionType = 0;
			m_nExpFieldOffset = 0;
		}
	}EXPBSONSTACKNODE,*LPEXPBSONSTACKNODE;
	#pragma pack()
	
public:
	CParseSql();
	virtual ~CParseSql(void);

protected:
	//CTableMap*  m_pTableMap;

protected:
	template<typename T>
	void FreeStack(stack<T*>& tempSatck);

	template<typename T>
	void FreeQueue(queue<T*>& tempQueue);
protected:
	//字符串预处理(去掉百分号)
	int StrPretreatment(char* pStr, int &nStrLen);
	void MakeUpper(char* pStr, int nStrLen);
protected:
	//解析函数
	int ParseCount(vector<CMFString>& vecString, CBaseBson& stBson, BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos);						
	int ParseSysDate(BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos);																															
	int ParseSEQ(vector<CMFString>& vecString, CBaseBson& stBson, BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos);						
	int ParseToDate(vector<CMFString>& vecString, CBaseBson& stBson, BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos);					
	int ParseToChar(vector<CMFString>& vecString, CBaseBson& stBson, BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos);			
	int ParseCheckChild(vector<CMFString>& vecString, CBaseBson& stBson, BYTE bFunType, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue, CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos);
	int ParseShortestPath(vector<CMFString>& vecString, CBaseBson& stBson, LPQUERYEXECUTEPLANBSON lpQueryPlan, CMFString& strExpression, int nStartPos, int& nEndPos);

protected:
	//判断兼容性函数
	BYTE GetCompatibleValueType(MF_VARDATA_TYPE bType);
	BYTE GetCompatibleFieldType(MF_SYS_FIELDTYPE bType);
	//运算符相关函数
	BYTE ConvertMathOperatorStrtoByte(CMFString OP);
	int  CheckValidOperator(vector<CMFString>& vecString, int nPos, BOOL bCondition = FALSE);
	int  CheckValidFunction(vector<CMFString>& vecString, int nPos);
	//判断CONNETCT条件是否正确
	BOOL CheckConnectCondition(CBaseBson& stBson, LPBASECONDITIONBSON pConditon, BOOL& bPiror);
protected:
	int ParseFunction(vector<CMFString>& vecString, BYTE bFunType, CBaseBson& stuBaseBson, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue,CMFString& strExpression, MF_COMPATIBLE_DATATYPE& bRetValueType, int nStartPos, int& nEndPos);
	int ParseMathFieldValue(vector<CMFString>& vecString,  CBaseBson& stBson, int& nExpFieldOffset, char* pObjectTitle, CMFString& strExpression, BOOL& bFiled, int& nValueStartPos, int nExpressionEndPos);
	int CreateMathExpression(UINT& nExpBsonOffset, CBaseBson& stBson, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue);	
	int	ParseMathExpression(vector<CMFString>& vecString, CBaseBson& stBson, UINT& nExpOffset, CMFString& strExpression, BOOL& bFiled, BOOL& bAggregateFun, char* pObjectTitle, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMixQueue, int nStartPos, int nEndPos, int &nModifyFlag);
protected:
	int CreateCondition(UINT& nConditionOffset, CBaseBson& stBson, queue<LPCONDITIONBSON_MIXQUEUENODE>& queMixQueue);
	int OperatorPop(CBaseBson &stBson, BOOL& bCompareOp, BOOL& bBetween, BOOL& bAnd, BOOL& bFiled, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMathQueue, queue<int>& queCompareQueue, queue<LPCONDITIONBSON_MIXQUEUENODE>& queConditionQueue);
	int OperatorPush(LPMATHOPERATOR lpMathOp, CBaseBson& stBson, BOOL& bCompareOp, BOOL& bBetween, BOOL& bAnd, BOOL& bExpression, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMathQueue, queue<int>& queCompareQueue, queue<LPCONDITIONBSON_MIXQUEUENODE>& queConditionQueue);
	int ParseInCondition(vector<CMFString>& vecString, CBaseBson& stBson, queue<int>& queCompareQueue, int& nStartPos);
	int ParseConnect(vector<CMFString>& vecString, CBaseBson& stBson, UINT& nConditionOffset, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMathQueue, queue<int>& queCompareQueue, queue<LPCONDITIONBSON_MIXQUEUENODE>& queConditionQueue, int nStartPos, int nEndPos);
	int ParseCondition(vector<CMFString>& vecString, CBaseBson& stBson, UINT& nConditionOffset, char* pObjectTitle, stack<LPMATHOPERATOR>& skOperatorStack, queue<LPEXPFIELDBSON_MIXQUEUENODE>& queMathQueue, queue<int>& queCompareQueue, queue<LPCONDITIONBSON_MIXQUEUENODE>& queConditionQueue, int nStartPos, int nEndPos);
	int ParsePaging(vector<CMFString>& vecString, LPQUERYEXECUTEPLANBSON lpQueryPlan, int nStartPos, int nEndPos);
	int GetConditionResult(CBaseBson& stBson, LPBASECONDITIONBSON lpCondition, BOOL& bResult);
	BOOL Compare(CBaseBson& stBson, LPCOMPAREEXPBSON lpCompareExp);

protected:
	int ParseObjectInfo(vector<CMFString>& vecString, char* pObjectName, char* pObjectTitle, int nStartPos, int nEndPos);
	int ParseSelectField(vector<CMFString>& vecString, CBaseBson& stBson, LPQUERYEXECUTEPLANBSON lpQueryExecutePlanBson, char* pObjectTitle, int nStartPos, int nEndPos, int &nModifyFlag);
	int ParseUpdateField(vector<CMFString>& vecString, CBaseBson& stBson, LPUPDATEEXECUTEPLANBSON lpUpdatePlan,int nStartPos, int nEndPos);
	int ParseCreateField(vector<CMFString>& vecString, CBaseBson& stBson, LPOBJECTDEFBSON lpObjectBson,int nStartPos, int& nEndPos);
protected:
	int ParseCommonInsert(vector<CMFString> vecString, CBaseBson& stBson, LPEXECUTEPLANBSON lpExecutePlan);

protected:
	int ParseAddField(vector<CMFString> vecString, CBaseBson& stBson, LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson, int nStartPos, int nEndPos);
	int ParseDropField(vector<CMFString> vecString, CBaseBson& stBson, LPALTEROBJECTFIELDBSON lpAlterObjectFieldBson, int nStartPos, int nEndPos);

protected:
	int ParseCommonDelete(vector<CMFString> &vecString, CBaseBson& stBson);

protected:
	void Parse(const char* lpszData, int nPos, vector<CMFString> &vecString);
	virtual int ParseQuery(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan);
	virtual int ParseInsert(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan);
	virtual int ParseUpdate(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan);
	virtual int ParseDelete(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan);
	virtual int ParseCreate(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan);
	virtual int ParseDrop(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan);
	virtual int ParseAlter(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan);
	virtual int ParseGrant(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan);
	virtual int ParseRevoke(const char* lpszSql, CBaseBson& stBson, int nPos, LPEXECUTEPLANBSON lpExecutePlan);
protected:
	int ParseCreateSequence(vector<CMFString> &vecString, CBaseBson& stBson, LPCREATEEXECUTEPLANBSON lpCreateObjectBson);
	int ParseCreateObject(vector<CMFString> &vecString, CBaseBson& stBson, LPCREATEEXECUTEPLANBSON lpCreateObjectBson);
	int ParseCreateUser(vector<CMFString> &vecString, CBaseBson& stBson, LPCREATEEXECUTEPLANBSON lpCreateObjectBson);
protected:
	int ParseAlterSystem(vector<CMFString> &vecString, CBaseBson& stBson, LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson);
	int ParseAlterObject(vector<CMFString> &vecString, CBaseBson& stBson, LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson);
	int ParseAlterUser(vector<CMFString> &vecString, CBaseBson& stBson, LPALTEREXECUTEPLANBSON lpAlterExecutePlanBson);
	int PraseSqlHead(const char* lpszSql, int& nPos, char* pCommandHead);
public:
#ifdef WIN32
	int ParseSql(CBaseBson& stBson, BSTR bstrSql, LPEXECUTEPLANBSON& lpExecutePlan);
#endif
	int ParseSql(CBaseBson& stBson, const char* lpszSql, int nSqlLen, LPEXECUTEPLANBSON& lpExecutePlan);
	
	/*void SetTableMap(CTableMap* pTableMap)
	{
		m_pTableMap = pTableMap;
	}*/
};

//函数模板用于释放栈和队列
template<typename T>
void CParseSql::FreeStack(stack<T*>& tempSatck)
{
	while(!tempSatck.empty())
	{
		if(NULL != tempSatck.top())
		{
			delete tempSatck.top();
			tempSatck.pop();
		}
	}
}

template<typename T>
void CParseSql::FreeQueue(queue<T*>& tempQueue)
{
	while(!tempQueue.empty())
	{
		if(NULL != tempQueue.front())
		{
			delete tempQueue.front();
			tempQueue.pop();
		}
	}
}
