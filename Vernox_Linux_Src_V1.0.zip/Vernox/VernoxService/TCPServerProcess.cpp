﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "TCPServerProcess.h"
#include "SobeyMemServiceManage.h"

//////////////////////////////////////////////////////////////////////////////////////////////
//								日志定义													//
//																							//
//     日志等级请参见MF_TRACE_LEVEL系列的宏定义，日志错误码建议每条日志都独立一个编码，按此 //
//思路，对于每个函数都会有一个错误码的范围。文件占3位，函数占3位，函数内编码占3位			//
//     此文件的日志错误码定义为300000000～300999000，请按照函数的先后顺序合理申请错误码，当 //
//前使用最大的错误码为：																	//
//																							//
//																				  吴春中	//
//																				  2015-3-11 //
//////////////////////////////////////////////////////////////////////////////////////////////

LONG  g_lSessionID = 1;

extern CSobeyMemServiceManage * g_pSobeyMemServiceManage;
CTCPServerProcess::CTCPServerProcess(void)
{
	m_skSocket			 = NULL;
	m_hStopEvent		 = NULL;
	m_usPort			 = 0;
	m_ulRemoteIP		 = 0;
	memset(m_strIP, 0, 256);
	m_nBufferCacheSize	 = GetSystemParameterValue(MF_MEMORY_PROCESS_SIZE);
	m_nExecutePlanSize	 = GetSystemParameterValue(MF_MEMORY_PLAN_REMAINSIZE);
	m_nSQLPlanMaxSize	 = GetSystemParameterValue(MF_MEMORY_SQLPLAN_MAXSIZE);
	m_nRecordsetPlanMaxSize = GetSystemParameterValue(MF_MEMORY_RECORDSETPLAN_MAXSIZE);

	m_lpBuffer			 = new BYTE[m_nBufferCacheSize];
	m_lpExecuteInfo		 = new EXECUTESTATISTICSINFO;
	m_lpSessionInfo		 = new SESSIONINFO;
	memset(m_lpExecuteInfo, 0, sizeof(EXECUTESTATISTICSINFO));
	memset(m_lpSessionInfo, 0, sizeof(SESSIONINFO));
}

CTCPServerProcess::~CTCPServerProcess(void)
{
	if(m_skSocket)
	{
		closesocket(m_skSocket);
	}
	if(g_pSobeyMemServiceManage != NULL)
	{
		g_pSobeyMemServiceManage->RemoveSessionInfo(m_lpSessionInfo, FALSE);
	}
	else
	{
		delete m_lpSessionInfo;
		m_lpSessionInfo = NULL;
	}
	if(m_lpExecuteInfo != NULL)
	{
		delete m_lpExecuteInfo;
		m_lpExecuteInfo = NULL;
	}
	if (m_lpBuffer != NULL)
	{
		delete[] m_lpBuffer;
		m_lpBuffer = NULL;
	}
}

void CTCPServerProcess::ClearSocket()
{
#ifdef WIN32
	//这块耗时大约在500毫秒左右
	int nRet;
	int nReceiveTimeOut = 1;
	char lpTempBuffer[1024];
	try
	{
		//清空接收队列的所有数据，首先修改超时时间，然后无限次的接收，直到接收完以后才返回
		setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&nReceiveTimeOut, sizeof(int));
		while(TRUE)
		{
			nRet = recv(m_skSocket, lpTempBuffer, 1024, 0);
			if(nRet == -1)
			{
				break;
			}
		}
		nReceiveTimeOut = GetSystemParameterValue(MF_TCP_TIMEOUT)*1000;
		setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&nReceiveTimeOut, sizeof(int));
	}
	catch (...)
	{
		Trace(_T("CTCPServerProcess::ClearSocket"), MF_TRACE_LEVEL_FAILED ,300001001, _T("清理客户端[%d.%d.%d.%d:%u]连接缓存数据出现异常，异常编码：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, GetLastError());
	}
#else
	//这块耗时大约在500毫秒左右
	int nRet;
	struct timeval timeout;
	char lpTempBuffer[1024];
	try
	{
		//清空接收队列的所有数据，首先修改超时时间，然后无限次的接收，直到接收完以后才返回
		timeout.tv_sec = 0;
		timeout.tv_usec = 1;
		setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(struct timeval));
		while(TRUE)
		{
			nRet = recv(m_skSocket, lpTempBuffer, 1024, 0);
			if(nRet == -1)
			{
				break;
			}
		}
		timeout.tv_sec = INT_MAX;
		timeout.tv_usec = 0;
		setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(struct timeval));
	}
	catch (...)
	{
		Trace(_T("CTCPServerProcess::ClearSocket"), MF_TRACE_LEVEL_FAILED ,300001001, _T("清理客户端[%d.%d.%d.%d:%u]连接缓存数据出现异常，异常编码：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, GetLastError());
	}
#endif
}

//接收Socket的数据，主要用于大数据量的接收
BOOL CTCPServerProcess::ReceiveBuffer(char *pBuffer, int nSize)
{
	char *pBuf;
	int nLeft, nCount, nRet;
#ifdef WIN32
	CString strErrorDesc;
#else
	TCHAR strErrorDesc[256];
	memset(strErrorDesc, 0, sizeof(TCHAR) * 256);
#endif

	//由于可能一次收不完，所以循环接收，直到收够指定的数据量后才停止
	nCount 	= 0;
	pBuf 	= pBuffer;
	nLeft 	= nSize;
	memset(pBuffer, 0, nSize);
	while (nLeft > 0)
	{
		nRet = recv(m_skSocket, pBuf, nLeft, 0);
		if(nRet == 0)
		{
			//连接被关闭了
		#ifdef WIN32
			strErrorDesc = _T("连接被关闭了，返回值为0");
		#else
			_tcscpy(strErrorDesc, _T("连接被关闭了，返回值为0"));
		#endif
			break;
		}
		else if (nRet == SOCKET_ERROR)
		{
			//失败了，需要处理一些情况
			nRet = WSAGetLastError();
			if(nRet == WSAETIMEDOUT) //超时情况，我们需要再等待一下
			{
				nCount++;
				if(nCount > 10)
				{
				#ifdef WIN32
					strErrorDesc = _T("重试了10次都出现接收超时");
				#else
					_tcscpy(strErrorDesc, _T("重试了10次都出现接收超时"));
				#endif
					break;
				}
				Sleep(1);
			}
			else if(nRet == WSAECONNRESET) //连接已经断开了
			{
			#ifdef WIN32
				strErrorDesc = _T("连接被关闭了，返回值为-1");
			#else
				_tcscpy(strErrorDesc, _T("连接被关闭了，返回值为-1"));
			#endif
				return FALSE;
			}
			else //其他情况，可以在重试一下
			{
				nCount++;
				if(nCount > 10)
				{
				#ifdef WIN32
					strErrorDesc.Format(_T("重试了10次都出现接收错误，返回值为-1，但是WSAGetLastError的返回值为：0x%x"), nRet);
				#else
					_stprintf(strErrorDesc, _T("重试了10次都出现接收错误，返回值为-1，但是WSAGetLastError的返回值为：0x%x"), nRet);
				#endif
					break;
				}
				Sleep(1);
			}
		}
		else
		{
			nCount = 0;
			nLeft -= nRet;
			pBuf += nRet;
		}
	}

	if(nLeft != 0)
	{
		Trace(_T("CTCPServerProcess::ReceiveBuffer"), MF_TRACE_LEVEL_FAILED ,300002001 , _T("接收客户端[%d.%d.%d.%d:%u]发送消息体数据长度不正确！消息头描述长度：%d，剩下：%d未收到！错误描述：%s"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nSize, nLeft, strErrorDesc);
		return FALSE;
	}
	return TRUE;
}

#ifdef WIN32
BOOL CTCPServerProcess::Run(SOCKET sk, HANDLE hStopEvent, HANDLE hExitProcessEvent, ULONG ulRemoteIP, USHORT usPort)
#else
BOOL CTCPServerProcess::Run(SOCKET sk, sem_t* hStopEvent, sem_t* hExitProcessEvent, ULONG ulRemoteIP, USHORT usPort)
#endif
{
	BOOL bExit;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	int nHeadLength, nRet, nFailedCount,nBufferSize,nNetTimeout;

	m_skSocket	 = sk;
	m_hStopEvent = hStopEvent;
	m_ulRemoteIP = ulRemoteIP;
	m_usPort	 = usPort;
	sprintf(m_strIP, "%d.%d.%d.%d", FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP));

	m_lpSessionInfo->m_dwSessionID  = InterlockedIncrement(&g_lSessionID);
	m_lpSessionInfo->m_ulClientIP   = ulRemoteIP;
	m_lpSessionInfo->m_usClientPort = usPort;
#ifdef WIN32
	GetSystemTimeAsFileTime(&m_lpSessionInfo->m_ftLogonTime);
#else
	timeval tTime;
	gettimeofday(&tTime, NULL);
	ConvertTimetoFileTime(tTime, m_lpSessionInfo->m_ftLogonTime);
#endif
	if(g_pSobeyMemServiceManage != NULL)
	{
		g_pSobeyMemServiceManage->SetSessionInfo(m_lpSessionInfo, FALSE);
	}

	//按照经验，发送Buffer设置为1M，接收Buffer设置为32K可以得到最佳效果
#ifdef WIN32
	nBufferSize = 1024*1024;
	setsockopt(m_skSocket, SOL_SOCKET, SO_SNDBUF,(const char FAR *)&nBufferSize, sizeof(nBufferSize));
	nBufferSize = 32*1024;
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVBUF,(const char FAR *)&nBufferSize, sizeof(nBufferSize));
#else
	nBufferSize = 1024 * 1024;
	setsockopt(m_skSocket, SOL_SOCKET, SO_SNDBUF, &nBufferSize, sizeof(nBufferSize));
	nBufferSize = 32 * 1024;
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVBUF, &nBufferSize, sizeof(nBufferSize));
#endif
	
	//屏蔽TCP的Nagle算法，可以提高TCP的响应速度，默认下是关闭的
#ifdef WIN32
	const char chOpt=1;
	setsockopt(m_skSocket, IPPROTO_TCP, TCP_NODELAY, &chOpt, sizeof(char));
#else
	int nOpt = 1;
	setsockopt(m_skSocket, IPPROTO_TCP, TCP_NODELAY, &nOpt, sizeof(int));
#endif

#ifdef WIN32
	nNetTimeout = GetSystemParameterValue(MF_TCP_TIMEOUT)*1000;
	setsockopt(m_skSocket, SOL_SOCKET, SO_SNDTIMEO, (char *)&nNetTimeout, sizeof(int));
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&nNetTimeout, sizeof(int));
#else
	struct timeval timeout;
	timeout.tv_sec = GetSystemParameterValue(MF_TCP_TIMEOUT);
	timeout.tv_usec = 0;
	setsockopt(m_skSocket, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout, sizeof(struct timeval));
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(struct timeval));
#endif

	//开始循环接收数据
	bExit           = FALSE;
	nFailedCount	= 0;
	nHeadLength		= sizeof(MF_SERVICE_TCP_COMMAND);
	while(TRUE)
	{
		//为了能保证线程一直运转，我们必须加异常捕获
		__try
		{
			//检查退出标志
			if(WaitForSingleObject(m_hStopEvent, 0) == WAIT_OBJECT_0)
			{
				//向主节点发送服务退出消息
				if(WaitForSingleObject(hExitProcessEvent, 0) == WAIT_OBJECT_0)
				{
					break;
				}
				bExit = TRUE;
			}
			//先接收消息头
			memset(&stTcpCmd, 0, nHeadLength);
			//数据量小，一次性肯定能收下来
			nRet = recv(m_skSocket, (char *)&stTcpCmd, nHeadLength, 0);
			if(nRet == 0)
			{
				//此链接已经被关闭了
				return TRUE;
			}
			else if(nRet == SOCKET_ERROR)
			{
				nRet = WSAGetLastError();
				if(nRet == WSAETIMEDOUT)
				{
					continue;
				}
				if(WSAECONNRESET == nRet)
				{
					//客户端已经被强行关闭了
					return TRUE;
				}
				else
				{
					//开始计数出现异常的次数，如果连续出现10次就直接关闭
					nFailedCount++;
					if(nFailedCount >= 10)
					{
						return TRUE;
					}
					else
					{
						Sleep(10);
					}
				}
			}

			//长度不对，肯定是接收的数据不正确
			if(nRet != nHeadLength)
			{
				continue;
			}
	
			if(bExit)
			{
				continue;
			}
			memset(m_lpExecuteInfo, 0, sizeof(EXECUTESTATISTICSINFO));
			nFailedCount = 0;
			switch(stTcpCmd.m_bType)
			{
			case MF_INTERFACE_TCPCOMMAND_EXECUTECOMMAND: //调SQL执行命令
				GetSystemTimeAsFileTime(&m_lpSessionInfo->m_ftLastCallTime);
				m_lpSessionInfo->m_bStatus = MF_INTERFACE_TCPCOMMAND_EXECUTECOMMAND;
				ExecuteCommand(&stTcpCmd);
				break;
			case MF_INTERFACE_TCPCOMMAND_GETRECORDSET:	//检索执行命令
				GetSystemTimeAsFileTime(&m_lpSessionInfo->m_ftLastCallTime);
				m_lpSessionInfo->m_bStatus = MF_INTERFACE_TCPCOMMAND_GETRECORDSET;
				GetRecordset(&stTcpCmd);
				break;
			case MF_INTERFACE_TCPCOMMAND_GETEXECUTEPLANINFO:
				GetSystemTimeAsFileTime(&m_lpSessionInfo->m_ftLastCallTime);
				m_lpSessionInfo->m_bStatus = MF_INTERFACE_TCPCOMMAND_GETEXECUTEPLANINFO;
				GetExecutePlan(&stTcpCmd);
				break;	
			case MF_INTERFACE_TCPCOMMAND_UPDATERECORDSET: //更新结果集命令
				GetSystemTimeAsFileTime(&m_lpSessionInfo->m_ftLastCallTime);
				m_lpSessionInfo->m_bStatus = MF_INTERFACE_TCPCOMMAND_UPDATERECORDSET;
				UpdateRecordset(&stTcpCmd);
				break;
			case MF_INTERFACE_TCPCOMMAND_STARTTRANSACTIONLOGIC://开始短事务锁
				GetSystemTimeAsFileTime(&m_lpSessionInfo->m_ftLastCallTime);
				m_lpSessionInfo->m_bStatus = MF_INTERFACE_TCPCOMMAND_STARTTRANSACTIONLOGIC;
				StartTransactionLogic(&stTcpCmd);
				break;
			case MF_INTERFACE_TCPCOMMAND_STOPTRANSACTIONLOGIC://结束短事务锁
				GetSystemTimeAsFileTime(&m_lpSessionInfo->m_ftLastCallTime);
				m_lpSessionInfo->m_bStatus = MF_INTERFACE_TCPCOMMAND_STOPTRANSACTIONLOGIC;
				StopTransactionLogic(&stTcpCmd);
				break;
			case MF_INTERFACE_TCPCOMMAND_EXPORTOBJECT:		//对象导出
				GetSystemTimeAsFileTime(&m_lpSessionInfo->m_ftLastCallTime);
				m_lpSessionInfo->m_bStatus = MF_INTERFACE_TCPCOMMAND_EXPORTOBJECT;
				ExportObject(&stTcpCmd);
				break;
			case MF_INTERFACE_TCPCOMMAND_IMPORTOBJECT:		//对象导入
				GetSystemTimeAsFileTime(&m_lpSessionInfo->m_ftLastCallTime);
				m_lpSessionInfo->m_bStatus = MF_INTERFACE_TCPCOMMAND_IMPORTOBJECT;
				ImportObject(&stTcpCmd);
				break;
			case MF_INTERFACE_COMMAND_USERLOGIN:
				UserLogin(&stTcpCmd);
				break;
			case MF_INTERFACE_COMMAND_USERLOGOUT:
				UserLogOut(&stTcpCmd);
				break;
			default:
				Trace(_T("CTCPServerProcess::Run"), MF_TRACE_LEVEL_FAILED , 300003002, _T("处理客户端[%d.%d.%d.%d:%u]调用时出现未知命令，系统将自动清除本链接的所有网络数据！命令：%d、版本：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, stTcpCmd.m_bType, stTcpCmd.m_bVersion);
				//回一个失败的消息，以免出现异常就让客户端挂死
				stTcpCmd.m_bVersion			= 1;
				stTcpCmd.m_lDataLength		= 0;
				stTcpCmd.m_bType			= MF_INTERFACE_TCPCOMMAND_FAIL;
				stTcpCmd.m_lDigitalData		= MF_INNER_SYS_INVALID_PARAMETER_ERROR;
				ClearSocket();
				send(m_skSocket, (char *)&stTcpCmd , sizeof(MF_SERVICE_TCP_COMMAND) ,0);
				break;
			}
		}
	#ifdef WIN32
		__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	#else
		catch(...)
	#endif
		{
			if(m_lpAddr != NULL)
			{
				if(m_lpSessionInfo->m_bStatus != MF_INTERFACE_TCPCOMMAND_EXPORTOBJECT && m_lpSessionInfo->m_bStatus != MF_INTERFACE_TCPCOMMAND_IMPORTOBJECT)
				{
					LPEXECUTEPLANBSON lpExecutePlan;
					lpExecutePlan = (LPEXECUTEPLANBSON)m_lpAddr;
					g_pSobeyMemServiceManage->ResourceAndLockRelease(lpExecutePlan, MF_FAILED);
				}
			
				if(m_lpAddr != m_lpBuffer)
				{
					delete [] m_lpAddr;
				}
				m_lpAddr = NULL;
			}
			Trace(_T("CTCPServerProcess::Run"), MF_TRACE_LEVEL_FAILED , 300003099, _T("处理客户端[%d.%d.%d.%d:%u]调用时出现未知异常失败！返回值：%d，错误号：%d，执行命令：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, WSAGetLastError(), stTcpCmd.m_bType);
			//回一个失败的消息，以免出现异常就让客户端挂死
			stTcpCmd.m_bVersion			= 1;
			stTcpCmd.m_lDataLength		= 0;
			stTcpCmd.m_bType			= MF_INTERFACE_TCPCOMMAND_FAIL;
			stTcpCmd.m_lDigitalData		= MF_INNER_EXPCETION_FAILED;
			ClearSocket();
			send(m_skSocket , (char *)&stTcpCmd , sizeof(MF_SERVICE_TCP_COMMAND) ,0);
		}
	}
	return TRUE;
}

BOOL CTCPServerProcess::ExecuteCommand(MF_SERVICE_TCP_COMMAND * pTcpCmd)
{
	CServiceBson stBson;
	int nRet, nBufferCacheSize;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	CExecutePlanManager stExecutePlanManager;
	MF_EXECUTESTATISTICSINFO stExecuteStatistics;

	memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
	stTcpCmd.m_bVersion			= 1;
	stTcpCmd.m_lDataLength		= 0;
	stTcpCmd.m_bToken			= pTcpCmd->m_bToken;

	nBufferCacheSize = (pTcpCmd->m_lDataLength / MF_BUFFERSECTION_SIZE + 1) * MF_BUFFERSECTION_SIZE + MF_BUFFERSECTION_SIZE + MF_TEMPBUFFER_SIZE + MF_RECYCLESECTION_SIZE + MF_RECORDBUFFER_SIZE;		//缓存总大小
	if(pTcpCmd->m_bVersion != 1)
	{
		//不支持的命令版本，直接失败并清理
		Trace(_T("CTCPServerProcess::ExecuteCommand"), MF_TRACE_LEVEL_FAILED ,300004001 , _T("处理客户端[%d.%d.%d.%d:%u]传入的执行命令版本号(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_bVersion);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else if(pTcpCmd->m_lDataLength > m_nSQLPlanMaxSize)
	{
		//数据肯定出现了错乱，直接失败并清理
		Trace(_T("CTCPServerProcess::ExecuteCommand"), MF_TRACE_LEVEL_FAILED ,300004002 , _T("处理客户端[%d.%d.%d.%d:%u]传入的执行命令长度(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_lDataLength);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else
	{
		if(nBufferCacheSize > m_nBufferCacheSize)
		{
			//超过每个会话本身的缓存，直接重新分配指定大小的数据
			m_lpAddr = new BYTE[nBufferCacheSize ];
			if(m_lpAddr == NULL)
			{
				Trace(_T("CTCPServerProcess::ExecuteCommand"), MF_TRACE_LEVEL_FAILED ,300004003 , _T("处理客户端[%d.%d.%d.%d:%u]命令时分配内存失败，分配长度%d，错误码：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nBufferCacheSize, GetLastError());
				stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
				ClearSocket();
			}
		}
		else
		{
			nBufferCacheSize = m_nBufferCacheSize;
			m_lpAddr = m_lpBuffer;
		}

		if(m_lpAddr != NULL)
		{
			if(!ReceiveBuffer((char *)(m_lpAddr), pTcpCmd->m_lDataLength))
			{
				stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
			}
			else
			{
				QueryPerformanceFrequency(&m_lpExecuteInfo->m_liFrequence);
				QueryPerformanceCounter(&m_lpExecuteInfo->m_liStart);
				GetSystemTimeAsFileTime(&m_lpExecuteInfo->m_ftStartTime);
				if(g_pSobeyMemServiceManage == NULL)
				{
					//理论上不存在这种情况
					stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
				}
				else
				{
					LPEXECUTEPLANBSON lpExecutePlan;
					lpExecutePlan = (LPEXECUTEPLANBSON)m_lpAddr;
					lpExecutePlan->m_nDefaultSectionSize = MF_BUFFERSECTION_SIZE;
					lpExecutePlan->m_dwClientIP			 = m_ulRemoteIP;
					lpExecutePlan->m_nUserID			 = m_lpSessionInfo->m_nUserID;
					lpExecutePlan->m_nSessionID			 = m_lpSessionInfo->m_dwSessionID;

					nRet = stBson.Initial(m_lpAddr, nBufferCacheSize);
					if(nRet != MF_OK)
					{
						stTcpCmd.m_lDigitalData = nRet;
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
						goto EXECUTECOMMAND_EXIT;
					}
					stExecutePlanManager.Initial(lpExecutePlan, &stBson);
				
					nRet = g_pSobeyMemServiceManage->TCPExecuteCommand(stBson, stExecutePlanManager, stTcpCmd.m_lDigitalData, m_lpExecuteInfo);
					if (nRet == MF_OK)
					{
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_OK;
					} 
					else
					{
						stTcpCmd.m_lDigitalData = nRet;
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
					}
EXECUTECOMMAND_EXIT:
					g_pSobeyMemServiceManage->SetExecuteStatistics(stExecutePlanManager, m_lpExecuteInfo);
				}
			}
			if(m_lpAddr != m_lpBuffer)
			{
				delete [] m_lpAddr;
			}
			m_lpAddr = NULL;
		}
	}

	GetExecuteStatistics(stExecuteStatistics);
	memcpy(stTcpCmd.m_lpszParam, &stExecuteStatistics, sizeof(stExecuteStatistics));

	nRet = send(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
	if(nRet  != sizeof(MF_SERVICE_TCP_COMMAND))
	{
		Trace(_T("CTCPServerProcess::ExecuteCommand"), MF_TRACE_LEVEL_FAILED ,300004004 , _T("客户端[%d.%d.%d.%d:%u]返回处理结果失败！返回值：%d，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, WSAGetLastError());
		return FALSE;
	}

	return TRUE;
}

BOOL CTCPServerProcess::UpdateRecordset(MF_SERVICE_TCP_COMMAND * pTcpCmd)
{
	CServiceBson stBson;
	int nRet, nBufferCacheSize;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	CExecutePlanManager stExecutePlanManager;
	MF_EXECUTESTATISTICSINFO stExecuteStatistics;

	memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
	stTcpCmd.m_bVersion			= 1;
	stTcpCmd.m_lDataLength		= 0;
	stTcpCmd.m_bToken			= pTcpCmd->m_bToken;

	nBufferCacheSize = (pTcpCmd->m_lDataLength / MF_BUFFERSECTION_SIZE + 1) * MF_BUFFERSECTION_SIZE + MF_BUFFERSECTION_SIZE + MF_TEMPBUFFER_SIZE + MF_RECYCLESECTION_SIZE + MF_RECORDBUFFER_SIZE;			//缓存总大小
	if(pTcpCmd->m_bVersion != 1)
	{
		//不支持的命令版本，直接失败并清理
		Trace(_T("CTCPServerProcess::UpdateRecordset"), MF_TRACE_LEVEL_FAILED ,300005001 , _T("处理客户端[%d.%d.%d.%d:%u]传入的更新命令版本号(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_bVersion);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else if(pTcpCmd->m_lDataLength > m_nRecordsetPlanMaxSize)
	{
		//数据肯定出现了错乱，直接失败并清理
		Trace(_T("CTCPServerProcess::UpdateRecordset"), MF_TRACE_LEVEL_FAILED ,300005002 , _T("处理客户端[%d.%d.%d.%d:%u]传入的更新命令长度(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_lDataLength);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else
	{
		if(nBufferCacheSize > m_nBufferCacheSize)
		{
			//超过每个会话本身的缓存，直接重新分配指定大小的数据
			m_lpAddr = new BYTE[nBufferCacheSize];
			if(m_lpAddr == NULL)
			{
				Trace(_T("CTCPServerProcess::UpdateRecordset"), MF_TRACE_LEVEL_FAILED ,300005003 , _T("处理客户端[%d.%d.%d.%d:%u]更新命令分配内存失败，分配长度%d，错误码：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nBufferCacheSize, GetLastError());
				stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
				ClearSocket();
			}
		}
		else
		{
			nBufferCacheSize = m_nBufferCacheSize;
			m_lpAddr = m_lpBuffer;
		}

		if(m_lpAddr != NULL)
		{
			if(!ReceiveBuffer((char *)(m_lpAddr), pTcpCmd->m_lDataLength))
			{
				stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
			}
			else
			{
				QueryPerformanceFrequency(&m_lpExecuteInfo->m_liFrequence);
				QueryPerformanceCounter(&m_lpExecuteInfo->m_liStart);
				GetSystemTimeAsFileTime(&m_lpExecuteInfo->m_ftStartTime);
				if(g_pSobeyMemServiceManage == NULL)
				{
					//理论上不存在这种情况
					stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
				}
				else
				{
					LPEXECUTEPLANBSON lpExecutePlan;
					lpExecutePlan = (LPEXECUTEPLANBSON)m_lpAddr;
					lpExecutePlan->m_nDefaultSectionSize	= MF_BUFFERSECTION_SIZE;
					lpExecutePlan->m_dwClientIP				= m_ulRemoteIP;
					lpExecutePlan->m_nUserID				= m_lpSessionInfo->m_nUserID;
					lpExecutePlan->m_nSessionID				= m_lpSessionInfo->m_dwSessionID;
					nRet = stBson.Initial(m_lpAddr, nBufferCacheSize);
					if(nRet != MF_OK)
					{	
						stTcpCmd.m_lDigitalData = nRet;
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
						goto UPDATERECORDSET_EXIT;
					}
					stExecutePlanManager.Initial(lpExecutePlan, &stBson);
					nRet = g_pSobeyMemServiceManage->TCPUpdateRecordset(stBson,stExecutePlanManager, m_lpExecuteInfo);
					if(nRet == MF_OK)
					{
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_OK;
					} 
					else
					{
						stTcpCmd.m_lDigitalData = nRet;
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
					}
UPDATERECORDSET_EXIT:
					g_pSobeyMemServiceManage->SetExecuteStatistics(stExecutePlanManager, m_lpExecuteInfo);
				}
			}
			if(m_lpAddr != m_lpBuffer)
			{
				delete [] m_lpAddr;
			}
			m_lpAddr = NULL;
		}
	}

	GetExecuteStatistics(stExecuteStatistics);
	memcpy(stTcpCmd.m_lpszParam, &stExecuteStatistics, sizeof(stExecuteStatistics));

	nRet = send(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
	if(nRet  != sizeof(MF_SERVICE_TCP_COMMAND))
	{
		Trace(_T("CTCPServerProcess::UpdateRecordset"), MF_TRACE_LEVEL_FAILED ,300005004 , _T("客户端[%d.%d.%d.%d:%u]返回处理结果记录失败！返回值：%d，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, WSAGetLastError());
		return FALSE;
	}

	return TRUE;
}

BOOL CTCPServerProcess::GetRecordset(MF_SERVICE_TCP_COMMAND * pTcpCmd)
{
	CServiceBson stBson;
	LPBYTE lpBsonRs;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	LPEXECUTEPLANBSON lpExecutePlan;
	BYTE bDatabaseType = MF_DATABASE_MEMDB;
	CExecutePlanManager stExecutePlanManager;
	MF_EXECUTESTATISTICSINFO stExecuteStatistics;
	int i, nRet, nBsonRsSize, nBufferCacheSize, nLen;
	memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
	stTcpCmd.m_bVersion			= 1;
	stTcpCmd.m_lDataLength		= 0;
	stTcpCmd.m_bToken			= pTcpCmd->m_bToken;

	nBufferCacheSize = (pTcpCmd->m_lDataLength / MF_BUFFERSECTION_SIZE + 1) * MF_BUFFERSECTION_SIZE + MF_BUFFERSECTION_SIZE + MF_TEMPBUFFER_SIZE + MF_RECYCLESECTION_SIZE + MF_RECORDBUFFER_SIZE;			//缓存总大小
	if(pTcpCmd->m_bVersion != 1)
	{
		//不支持的命令版本，直接失败并清理
		Trace(_T("CTCPServerProcess::GetRecordset"), MF_TRACE_LEVEL_FAILED ,300006001 , _T("处理客户端[%d.%d.%d.%d:%u]传入的查询命令版本号(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_bVersion);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else if(pTcpCmd->m_lDataLength > m_nSQLPlanMaxSize)
	{
		//数据肯定出现了错乱，直接失败并清理
		Trace(_T("CTCPServerProcess::GetRecordset"), MF_TRACE_LEVEL_FAILED ,300006002 , _T("处理客户端[%d.%d.%d.%d:%u]传入的执行命令长度(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_lDataLength);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else
	{
		lpBsonRs = NULL;
		nBsonRsSize = 0;
		if(nBufferCacheSize > m_nBufferCacheSize)
		{
			//超过每个会话本身的缓存，直接重新分配指定大小的数据
			m_lpAddr = new BYTE[nBufferCacheSize];
			if(m_lpAddr == NULL)
			{
				Trace(_T("CTCPServerProcess::GetRecordset"), MF_TRACE_LEVEL_FAILED ,300006003 , _T("处理客户端[%d.%d.%d.%d:%u]查询命令分配内存失败，分配长度%d，错误码：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nBufferCacheSize, GetLastError());
				stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
				ClearSocket();
			}
		}
		else
		{
			nBufferCacheSize = m_nBufferCacheSize;
			m_lpAddr = m_lpBuffer;
		}

		if(m_lpAddr != NULL)
		{

			if(!ReceiveBuffer((char *)(m_lpAddr), pTcpCmd->m_lDataLength))
			{
				stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
			}
			else
			{
				QueryPerformanceFrequency(&m_lpExecuteInfo->m_liFrequence);
				QueryPerformanceCounter(&m_lpExecuteInfo->m_liStart);
				GetSystemTimeAsFileTime(&m_lpExecuteInfo->m_ftStartTime);
				if(g_pSobeyMemServiceManage == NULL)
				{
					//理论上不存在这种情况
					stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
				}
				else
				{
					lpExecutePlan = (LPEXECUTEPLANBSON)m_lpAddr;
					lpExecutePlan->m_nDefaultSectionSize	= MF_BUFFERSECTION_SIZE;
					lpExecutePlan->m_dwClientIP				= m_ulRemoteIP;
					lpExecutePlan->m_nUserID				= m_lpSessionInfo->m_nUserID;
					lpExecutePlan->m_nSessionID				= m_lpSessionInfo->m_dwSessionID;

					nRet = stBson.Initial(m_lpAddr, nBufferCacheSize);
					if(nRet != MF_OK)
					{
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_OK;
						stTcpCmd.m_lDataLength = nBsonRsSize;
						goto GETRECORDSET_EXIT;
					}
					stExecutePlanManager.Initial(lpExecutePlan, &stBson);
					bDatabaseType							= lpExecutePlan->m_bDBType;
					lpBsonRs = NULL;
					nBsonRsSize = nBufferCacheSize - lpExecutePlan->m_nBsonDataSize;
					nRet = g_pSobeyMemServiceManage->TCPGetRecordset(stBson, stExecutePlanManager, lpBsonRs, nBsonRsSize, m_lpExecuteInfo);
					if(nRet == MF_OK)
					{
						long long nRowNum;
						LPBYTE lpCondition;
						LPRECORDSETHEAD lpRecordsetHead;
						LPQUERYEXECUTEPLANBSON lpQueryPlan;
						lpQueryPlan = (LPQUERYEXECUTEPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);

						stTcpCmd.m_bType		= MF_INTERFACE_TCPCOMMAND_OK;
						stTcpCmd.m_lDataLength  = nBsonRsSize;
						
						lpCondition = stBson.ConvertOffset2Addr(lpQueryPlan->m_nConditionOffset);
						lpRecordsetHead = (LPRECORDSETHEAD)(lpBsonRs + sizeof(int));
						if(lpRecordsetHead->m_nRowNum < lpQueryPlan->m_nPageSize)
						{
							nRowNum = (lpQueryPlan->m_nPageNo - 1)*lpQueryPlan->m_nPageSize + lpRecordsetHead->m_nRowNum;
						}
						else
						{
							nRowNum = *(long long*)(lpCondition + sizeof(BYTE)*4);
						}

						if(nRowNum > INT_MAX)
						{
							stTcpCmd.m_lDigitalData = INT_MAX;
						}
						else
						{
							stTcpCmd.m_lDigitalData = nRowNum;
						}
					}
					else
					{
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
						stTcpCmd.m_lDigitalData = nRet;
					}
GETRECORDSET_EXIT:
					g_pSobeyMemServiceManage->SetExecuteStatistics(stExecutePlanManager, m_lpExecuteInfo);
				}
			}
		}
	}

	GetExecuteStatistics(stExecuteStatistics);
	memcpy(stTcpCmd.m_lpszParam, &stExecuteStatistics, sizeof(stExecuteStatistics));

	if(stTcpCmd.m_lDataLength == 0)
	{
		nRet = send(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
		if(nRet  != sizeof(MF_SERVICE_TCP_COMMAND))
		{
			Trace(_T("CTCPServerProcess::GetRecordset"), MF_TRACE_LEVEL_FAILED ,300006004 , _T("客户端[%d.%d.%d.%d:%u]返回处理结果命令失败！返回值：%d，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, WSAGetLastError());
		}
	}
	else
	{
		LPBYTE lpBuffer;
		MF_SERVICE_TCP_COMMAND * pCmd;
		LPRECORDSETHEAD lpRecordsetHead;
		nLen			= *(int*)lpBsonRs - sizeof(int) + sizeof(MF_SERVICE_TCP_COMMAND);						//第一包数据长度
		pCmd			= (MF_SERVICE_TCP_COMMAND *)(lpBsonRs - sizeof(MF_SERVICE_TCP_COMMAND) + sizeof(int));	//命令头数据
		lpRecordsetHead = (LPRECORDSETHEAD)(lpBsonRs + sizeof(int));
		memcpy(pCmd, &stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND));
		nRet = send(m_skSocket, (char *)pCmd, nLen, 0);															//发送第一包数据
		if(nRet  != nLen)
		{
			Trace(_T("CTCPServerProcess::GetRecordset"), MF_TRACE_LEVEL_FAILED ,300006005 , _T("客户端[%d.%d.%d.%d:%u]返回处理结果记录失败！返回值：%d(%d)，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, stTcpCmd.m_lDataLength, WSAGetLastError());
		}
		else
		{
			for(i = lpRecordsetHead->m_bStartBufferNo; i < stBson.GetTempSectionNum(); i++)
			{
				lpBuffer = stBson.GetTempSectionBuffer(i);
				nLen     = *(int*)lpBuffer - sizeof(int);
				lpBuffer += sizeof(int);
				nRet = send(m_skSocket, (char *)lpBuffer, nLen, 0);
				if(nRet != nLen)
				{
					Trace(_T("CTCPServerProcess::GetRecordset"), MF_TRACE_LEVEL_FAILED ,300006006 , _T("客户端[%d.%d.%d.%d:%u]返回处理结果记录失败！返回值：%d(%d)，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, stTcpCmd.m_lDataLength, WSAGetLastError());
					break;
				}
			}
		}
	}

	if(m_lpAddr != m_lpBuffer)
	{
		delete [] m_lpAddr;
	}
	m_lpAddr = NULL;
	return TRUE;
}

BOOL CTCPServerProcess::GetExecutePlan(MF_SERVICE_TCP_COMMAND * pTcpCmd)
{
	CServiceBson stBson;
	int nRet, nBufferCacheSize;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	EXECUTEPLANINFO stExecutePlanInfo;
	CExecutePlanManager stExecutePlanManager;
	MF_EXECUTESTATISTICSINFO stExecuteStatistics;

	memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
	stTcpCmd.m_bVersion			= 1;
	stTcpCmd.m_lDataLength		= 0;
	stTcpCmd.m_bToken			= pTcpCmd->m_bToken;

	nBufferCacheSize = (pTcpCmd->m_lDataLength / MF_BUFFERSECTION_SIZE + 1) * MF_BUFFERSECTION_SIZE + MF_BUFFERSECTION_SIZE + MF_TEMPBUFFER_SIZE + MF_RECYCLESECTION_SIZE + MF_RECORDBUFFER_SIZE;		//缓存总大小
	if(pTcpCmd->m_bVersion != 1)
	{
		//不支持的命令版本，直接失败并清理
		Trace(_T("CTCPServerProcess::ExecuteCommand"), MF_TRACE_LEVEL_FAILED ,300004001 , _T("处理客户端[%d.%d.%d.%d:%u]传入的执行命令版本号(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_bVersion);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else if(pTcpCmd->m_lDataLength > m_nSQLPlanMaxSize)
	{
		//数据肯定出现了错乱，直接失败并清理
		Trace(_T("CTCPServerProcess::ExecuteCommand"), MF_TRACE_LEVEL_FAILED ,300004002 , _T("处理客户端[%d.%d.%d.%d:%u]传入的执行命令长度(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_lDataLength);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else
	{
		if(nBufferCacheSize > m_nBufferCacheSize)
		{
			//超过每个会话本身的缓存，直接重新分配指定大小的数据
			m_lpAddr = new BYTE[nBufferCacheSize];
			if(m_lpAddr == NULL)
			{
				Trace(_T("CTCPServerProcess::ExecuteCommand"), MF_TRACE_LEVEL_FAILED ,300004003 , _T("处理客户端[%d.%d.%d.%d:%u]命令时分配内存失败，分配长度%d，错误码：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nBufferCacheSize, GetLastError());
				stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
				ClearSocket();
			}
		}
		else
		{
			nBufferCacheSize = m_nBufferCacheSize;
			m_lpAddr = m_lpBuffer;
		}

		if(m_lpAddr != NULL)
		{
			if(!ReceiveBuffer((char *)(m_lpAddr), pTcpCmd->m_lDataLength))
			{
				stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
			}
			else
			{
				if(g_pSobeyMemServiceManage == NULL)
				{
					//理论上不存在这种情况
					stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
				}
				else
				{
					LPEXECUTEPLANBSON lpExecutePlan;
					lpExecutePlan = (LPEXECUTEPLANBSON)m_lpAddr;
					lpExecutePlan->m_nDefaultSectionSize = MF_BUFFERSECTION_SIZE;
					lpExecutePlan->m_dwClientIP			 = m_ulRemoteIP;
					lpExecutePlan->m_nUserID			 = m_lpSessionInfo->m_nUserID;
					lpExecutePlan->m_nSessionID			 = m_lpSessionInfo->m_dwSessionID;

					nRet = stBson.Initial(m_lpAddr, nBufferCacheSize);
					if (nRet != MF_OK)
					{
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_OK;
						stTcpCmd.m_lDataLength = sizeof(EXECUTEPLANINFO);
						goto GETEXECUTEPLAN_EXIT;
					} 
					stExecutePlanManager.Initial(lpExecutePlan, &stBson);
		
					nRet = g_pSobeyMemServiceManage->TCPGetExecutePlan(stBson, stExecutePlanManager, &stExecutePlanInfo, m_lpExecuteInfo);
					if (nRet == MF_OK)
					{
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_OK;
						stTcpCmd.m_lDataLength = sizeof(EXECUTEPLANINFO);
					} 
					else
					{
						stTcpCmd.m_lDigitalData = nRet;
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
					}
				}
			}
GETEXECUTEPLAN_EXIT:
			if(m_lpAddr != m_lpBuffer)
			{
				delete [] m_lpAddr;
			}
			m_lpAddr = NULL;
		}
	}

	GetExecuteStatistics(stExecuteStatistics);
	memcpy(stTcpCmd.m_lpszParam, &stExecuteStatistics, sizeof(stExecuteStatistics));

	nRet = send(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
	if(nRet  != sizeof(MF_SERVICE_TCP_COMMAND))
	{
		Trace(_T("CTCPServerProcess::ExecuteCommand"), MF_TRACE_LEVEL_FAILED ,300004004 , _T("客户端[%d.%d.%d.%d:%u]返回处理结果失败！返回值：%d，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, WSAGetLastError());
		return FALSE;
	}
	
	if(stTcpCmd.m_lDataLength != 0)
	{
		nRet = send(m_skSocket, (char *)&stExecutePlanInfo, stTcpCmd.m_lDataLength ,0);
		if(nRet  != stTcpCmd.m_lDataLength)
		{
			Trace(_T("CTCPServerProcess::GetRecordset"), MF_TRACE_LEVEL_FAILED ,300006005 , _T("客户端[%d.%d.%d.%d:%u]返回处理结果记录失败！返回值：%d(%d)，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, stTcpCmd.m_lDataLength, WSAGetLastError());
			return FALSE;
		}
	}
	return TRUE;
}

void CTCPServerProcess::GetExecuteStatistics(MF_EXECUTESTATISTICSINFO &stExecuteStatistics)
{
	memset(&stExecuteStatistics, 0, sizeof(stExecuteStatistics));
	stExecuteStatistics.m_ftStartTime					= m_lpExecuteInfo->m_ftStartTime;
	stExecuteStatistics.m_ftEndTime						= m_lpExecuteInfo->m_ftEndTime;
	stExecuteStatistics.m_liStart.QuadPart				= m_lpExecuteInfo->m_liStart.QuadPart;
	stExecuteStatistics.m_liFrequence.QuadPart			= m_lpExecuteInfo->m_liFrequence.QuadPart;
	stExecuteStatistics.m_liParsePlanStart.QuadPart		= m_lpExecuteInfo->m_liParsePlanStart.QuadPart;
	stExecuteStatistics.m_liPretreatmentStart.QuadPart	= m_lpExecuteInfo->m_liPretreatmentStart.QuadPart;
	stExecuteStatistics.m_liExecuteStart.QuadPart		= m_lpExecuteInfo->m_liExecuteStart.QuadPart;
	stExecuteStatistics.m_liIndexSearchEnd.QuadPart		= m_lpExecuteInfo->m_liIndexSearchEnd.QuadPart;
	stExecuteStatistics.m_liExecuteEnd.QuadPart			= m_lpExecuteInfo->m_liExecuteEnd.QuadPart;
	stExecuteStatistics.m_liWriteLogEnd.QuadPart		= m_lpExecuteInfo->m_liWriteLogEnd.QuadPart;
	stExecuteStatistics.m_liEnd.QuadPart				= m_lpExecuteInfo->m_liEnd.QuadPart;
	stExecuteStatistics.m_lWorkLoad						= m_lpExecuteInfo->m_lWorkLoad;
	//计算每个阶段的耗时
	if(stExecuteStatistics.m_liEnd.QuadPart > stExecuteStatistics.m_liStart.QuadPart && stExecuteStatistics.m_liStart.QuadPart != 0)
	{
		m_lpSessionInfo->m_nTotalTime					+= (DWORD)(1000000 * (stExecuteStatistics.m_liEnd.QuadPart - stExecuteStatistics.m_liStart.QuadPart) / stExecuteStatistics.m_liFrequence.QuadPart );
	}
	if(stExecuteStatistics.m_liPretreatmentStart.QuadPart > stExecuteStatistics.m_liStart.QuadPart && stExecuteStatistics.m_liStart.QuadPart != 0)
	{
		m_lpSessionInfo->m_nTotalPrepareTime			+= (DWORD)(1000000 * (stExecuteStatistics.m_liPretreatmentStart.QuadPart - stExecuteStatistics.m_liStart.QuadPart) / stExecuteStatistics.m_liFrequence.QuadPart );
	}
	if(stExecuteStatistics.m_liIndexSearchEnd.QuadPart == stExecuteStatistics.m_liExecuteStart.QuadPart && stExecuteStatistics.m_liEnd.QuadPart != stExecuteStatistics.m_liWriteLogEnd.QuadPart)
	{
		if(stExecuteStatistics.m_liExecuteStart.QuadPart > stExecuteStatistics.m_liPretreatmentStart.QuadPart && stExecuteStatistics.m_liPretreatmentStart.QuadPart != 0)
		{
			m_lpSessionInfo->m_nTotalApplyResourceTime	= (DWORD)(1000000 * (stExecuteStatistics.m_liExecuteStart.QuadPart - stExecuteStatistics.m_liPretreatmentStart.QuadPart) / stExecuteStatistics.m_liFrequence.QuadPart );
		}
		if(stExecuteStatistics.m_liExecuteEnd.QuadPart > stExecuteStatistics.m_liExecuteStart.QuadPart && stExecuteStatistics.m_liExecuteStart.QuadPart != 0)
		{
			m_lpSessionInfo->m_nTotalExecuteTime		= (DWORD)(1000000 * (stExecuteStatistics.m_liExecuteEnd.QuadPart - stExecuteStatistics.m_liExecuteStart.QuadPart) / stExecuteStatistics.m_liFrequence.QuadPart );
		}
		if(stExecuteStatistics.m_liWriteLogEnd.QuadPart > stExecuteStatistics.m_liExecuteEnd.QuadPart && stExecuteStatistics.m_liExecuteEnd.QuadPart != 0)
		{
			m_lpSessionInfo->m_nTotalLogTime			= (DWORD)(1000000 * (stExecuteStatistics.m_liWriteLogEnd.QuadPart - stExecuteStatistics.m_liExecuteEnd.QuadPart) / stExecuteStatistics.m_liFrequence.QuadPart );
		}
		if(stExecuteStatistics.m_liEnd.QuadPart > stExecuteStatistics.m_liWriteLogEnd.QuadPart && stExecuteStatistics.m_liWriteLogEnd.QuadPart != 0)
		{
			m_lpSessionInfo->m_nTotalReleaseResourceTime= (DWORD)(1000000 * (stExecuteStatistics.m_liEnd.QuadPart - stExecuteStatistics.m_liWriteLogEnd.QuadPart) / stExecuteStatistics.m_liFrequence.QuadPart );
		}
	}
	else
	{
		//查询方式计算耗时
		if(stExecuteStatistics.m_liIndexSearchEnd.QuadPart > stExecuteStatistics.m_liExecuteStart.QuadPart && stExecuteStatistics.m_liExecuteStart.QuadPart != 0)
		{
			m_lpSessionInfo->m_nTotalIndexSearchTime	= (DWORD)(1000000 * (stExecuteStatistics.m_liIndexSearchEnd.QuadPart - stExecuteStatistics.m_liExecuteStart.QuadPart) / stExecuteStatistics.m_liFrequence.QuadPart );
		}
		if(stExecuteStatistics.m_liExecuteEnd.QuadPart > stExecuteStatistics.m_liIndexSearchEnd.QuadPart && stExecuteStatistics.m_liIndexSearchEnd.QuadPart != 0)
		{
			m_lpSessionInfo->m_nTotalExecuteTime		= (DWORD)(1000000 * (stExecuteStatistics.m_liExecuteEnd.QuadPart - stExecuteStatistics.m_liIndexSearchEnd.QuadPart) / stExecuteStatistics.m_liFrequence.QuadPart );
		}
	}
	m_lpSessionInfo->m_nTotalWorkLoad					+= stExecuteStatistics.m_lWorkLoad;
	m_lpSessionInfo->m_nTotalCallCount++;
	QueryPerformanceCounter(&stExecuteStatistics.m_liEnd);
}

BOOL CTCPServerProcess::ExportObject(MF_SERVICE_TCP_COMMAND * pTcpCmd)
{
	CServiceBson stBson;
	char pObjectName[32];
	long long nTimestamp;
	EXPORTPARAM stExportParam;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	int nRet, nBufferSize, nTcpHeadLen;
	
	memset(&stExportParam, 0, sizeof(EXPORTPARAM));
	nTcpHeadLen			= sizeof(MF_SERVICE_TCP_COMMAND);
	//初始化Bson对象
	m_lpAddr			= m_lpBuffer;
	nBufferSize			= m_nBufferCacheSize;
	nRet = stBson.Initial(m_lpAddr + nTcpHeadLen, nBufferSize - nTcpHeadLen, MF_TEMPBUFFER_SIZE, 0, 0);				//需要分配临时空间来备份事务链表
	if(nRet != MF_OK)
	{
		return nRet;
	}

	memset(pObjectName, 0, sizeof(pObjectName));
	memcpy(pObjectName, pTcpCmd->m_lpszParam, 32);

	memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
	stTcpCmd.m_bVersion			= 1;
	stTcpCmd.m_bToken			= pTcpCmd->m_bToken;

	if(pTcpCmd->m_bVersion != 1)
	{
		//不支持的命令版本，直接失败并清理
		Trace(_T("CTCPServerProcess::ExportObject"), MF_TRACE_LEVEL_FAILED ,300010001 , _T("处理客户端[%d.%d.%d.%d:%u]传入的执行命令版本号(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_bVersion);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else if (pTcpCmd->m_lDataLength != 0)
	{
		Trace(_T("CTCPServerProcess::ExportObject"), MF_TRACE_LEVEL_FAILED, 300010002, 
			_T("客服端[%s:%u]发送的数据内容不正确，服务端自动清理TCP缓存数据，期望为0，但实际收到：%d！"), m_strIP, m_usPort, pTcpCmd->m_lDataLength);
		ClearSocket();
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
	}
	else
	{
		//时间戳申请
		nTimestamp = GetSystemTimestamp();
	
		LPOBJECTBUFFERHEAD lpObjectBufferHead;
		EXPORTOBJECTFILEHEAD stExportFileHead;
		memset(&stExportFileHead, 0, sizeof(EXPORTOBJECTFILEHEAD));
		stExportFileHead.m_llObjectDataSize = 0;
		stExportFileHead.m_nVersion			= 1;
		stExportFileHead.m_nFileFlag		= MAKEHEADFLAG('E','X','O','B');
		stExportFileHead.m_llTimeStamp		= nTimestamp;
		stExportFileHead.m_ulHostIP			= m_ulRemoteIP;
		stExportFileHead.m_nObjectCount		= 1;
		memcpy(stExportFileHead.m_pDataFlag,	"Vernox", 6);
		memcpy(stExportFileHead.m_pObjectName,	pObjectName, 32);
		memset(stExportFileHead.m_pMachineName,	0, 32);
		memset(stExportFileHead.m_pUserName, 0, 24);

		//获取对象GUID
		nRet = g_pSobeyMemServiceManage->GetDatabaseGuid(stExportFileHead.m_usDataBaseGuid);
		if(nRet != MF_OK)
		{
			stTcpCmd.m_lDataLength  = 0;
			stTcpCmd.m_lDigitalData = MF_EXPORTOBJECT_DATALEN_ERROR;
			stTcpCmd.m_bType		= MF_INTERFACE_TCPCOMMAND_FAIL;
			goto EXPORT_ERROR;
		}
		
		//获取记录总数
		nRet = g_pSobeyMemServiceManage->GetObjectDataNum(pObjectName, stExportFileHead.m_nTotalDataNum);
		if(nRet != MF_OK)
		{
			stTcpCmd.m_lDataLength  = 0;
			stTcpCmd.m_lDigitalData = MF_EXPORTOBJECT_DATALEN_ERROR;
			stTcpCmd.m_bType		= MF_INTERFACE_TCPCOMMAND_FAIL;
			goto EXPORT_ERROR;
		}

		stTcpCmd.m_bType		= MF_INTERFACE_TCPCOMMAND_OK;
		stTcpCmd.m_lDataLength	= sizeof(EXPORTOBJECTFILEHEAD);
		stTcpCmd.m_lDigitalData = 1;
		nRet = send(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
		if(nRet  != sizeof(MF_SERVICE_TCP_COMMAND))
		{
			Trace(_T("CTCPServerProcess::ExportObject"), MF_TRACE_LEVEL_FAILED, 300010003, _T("客户端[%d.%d.%d.%d:%u]返回处理结果记录失败！返回值：%d(%d)，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, sizeof(EXPORTOBJECTFILEHEAD), WSAGetLastError());
			return FALSE;
		}

		nRet = send(m_skSocket, (char *)&stExportFileHead, sizeof(EXPORTOBJECTFILEHEAD), 0);
		if(nRet  != sizeof(EXPORTOBJECTFILEHEAD))
		{
			Trace(_T("CTCPServerProcess::ExportObject"), MF_TRACE_LEVEL_FAILED, 300010004, _T("客户端[%d.%d.%d.%d:%u]返回处理结果记录失败！返回值：%d(%d)，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, sizeof(EXPORTOBJECTFILEHEAD), WSAGetLastError());
			return FALSE;
		}

		//stTcpCmd.m_lDataLength == 0 代表完成，客户端停止接收
		//数据发送完成或者出现异常失败了
		while(TRUE)
		{
			memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
			stTcpCmd.m_bVersion			= 1;
			stTcpCmd.m_bToken			= pTcpCmd->m_bToken;

			//重置BSON对象中数据的长度
			stBson.SetDataLen(0);
			stExportParam.m_nRecordNum = 0;
			nRet = g_pSobeyMemServiceManage->ExportObject(stBson, pObjectName, &stExportParam, nTimestamp);
			if(nRet != MF_OK)
			{
				if(nRet == MF_COMMON_INVALID_BUFFERSIZE)
				{
					//m_lpAddr不够大，需要重新申请buffer,按照2倍进行膨胀
					if(m_lpAddr != m_lpBuffer)
					{
						delete [] m_lpAddr;
						m_lpAddr = NULL;
					}

					nBufferSize = nBufferSize*2;
					m_lpAddr	= new BYTE[nBufferSize];
					if(m_lpAddr == NULL)
					{
						stTcpCmd.m_lDataLength	= 0;
						stTcpCmd.m_lDigitalData = MF_INNER_ALLOCMEM_FAILED;
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
						break;
					}
					nRet = stBson.Initial(m_lpAddr + nTcpHeadLen, nBufferSize - nTcpHeadLen, MF_TEMPBUFFER_SIZE, 0, 0);				//需要分配临时空间来备份事务链表
					if(nRet != MF_OK)
					{
						stTcpCmd.m_lDataLength	= 0;
						stTcpCmd.m_lDigitalData = nRet;
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
						break;
					}
					continue;
				} 
				else
				{
					stTcpCmd.m_lDataLength = 0;
					stTcpCmd.m_lDigitalData = nRet;
					stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
					break;
				}
			}
			else
			{
				lpObjectBufferHead = (LPOBJECTBUFFERHEAD)(m_lpAddr + nTcpHeadLen);
				lpObjectBufferHead->m_nDataNum = stExportParam.m_nRecordNum;
				if(lpObjectBufferHead->m_nBufferLen == 0 && !stExportParam.m_bComplete)
				{
					//出错
					stTcpCmd.m_lDataLength  = 0;
					stTcpCmd.m_lDigitalData = MF_EXPORTOBJECT_DATALEN_ERROR;
					stTcpCmd.m_bType		= MF_INTERFACE_TCPCOMMAND_FAIL;
					break;
				}
				else
				{
					//将TCP头与数据BUFFER合并发送
					stTcpCmd.m_lDataLength  = lpObjectBufferHead->m_nBufferLen + sizeof(OBJECTBUFFERHEAD);
					stTcpCmd.m_bType		= MF_INTERFACE_TCPCOMMAND_OK;
					if(stExportParam.m_bComplete)
					{
						stTcpCmd.m_lDigitalData = 2;
					}
					else
					{
						stTcpCmd.m_lDigitalData = 0;
					}
					memcpy(m_lpAddr, &stTcpCmd, nTcpHeadLen);

					nRet = send(m_skSocket, (char*)m_lpAddr, stTcpCmd.m_lDataLength + nTcpHeadLen, 0);
					if(nRet  != stTcpCmd.m_lDataLength + nTcpHeadLen)
					{
						Trace(_T("CTCPServerProcess::ExportObject"), MF_TRACE_LEVEL_FAILED, 300010005, _T("客户端[%d.%d.%d.%d:%u]返回处理结果记录失败！返回值：%d(%d)，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, stTcpCmd.m_lDataLength, WSAGetLastError());
						
						if(m_lpAddr != m_lpBuffer)
						{
							delete [] m_lpAddr;
							m_lpAddr = NULL;
						}
						return FALSE;
					}

					if(stExportParam.m_bComplete)
					{
						if(m_lpAddr != m_lpBuffer)
						{
							delete [] m_lpAddr;
							m_lpAddr = NULL;
						}
						return TRUE;
					}
				}
			}
		}
	}

EXPORT_ERROR:
	if(m_lpAddr != m_lpBuffer)
	{
		delete [] m_lpAddr;
		m_lpAddr = NULL;
	}

	nRet = send(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
	if(nRet  != stTcpCmd.m_lDataLength)
	{
		Trace(_T("CTCPServerProcess::ExportObject"), MF_TRACE_LEVEL_FAILED, 300010006, _T("客户端[%d.%d.%d.%d:%u]返回处理结果记录失败！返回值：%d(%d)，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, sizeof(MF_SERVICE_TCP_COMMAND), WSAGetLastError());
		return FALSE;
	}
	return FALSE;
}

BOOL CTCPServerProcess::ImportObject(MF_SERVICE_TCP_COMMAND * pTcpCmd)
{
	char *lpObjectName;
	CServiceBson stBson;
	long long nTimestamp;
	IMPORTPARAM stImportParam;
	int nRet, nBufferCacheSize;
	MF_SERVICE_TCP_COMMAND stTcpCmd;		//返回信息
	LPOBJECTBUFFERHEAD lpObjectBufferHead;
	CSystemTimestampTransactionManage stTransaction;

	memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
	stTcpCmd.m_bVersion			= 1;
	stTcpCmd.m_lDataLength		= 0;
	stTcpCmd.m_bToken			= pTcpCmd->m_bToken;

	lpObjectName = pTcpCmd->m_lpszParam;
	if(pTcpCmd->m_bVersion != 1)
	{
		//不支持的命令版本，直接失败并清理
		Trace(_T("CTCPServerProcess::ImportObject"), MF_TRACE_LEVEL_FAILED, 300011001, 
			_T("客户端[%s:%u]传入的执行命令版本号(%d)不支持"), m_strIP, m_usPort, pTcpCmd->m_bVersion);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else if(pTcpCmd->m_lDataLength > m_nSQLPlanMaxSize)
	{
		//数据肯定出现了错乱，直接失败并清理
		Trace(_T("CTCPServerProcess::ImportObject"), MF_TRACE_LEVEL_FAILED, 300011002, 
			_T("客户端[%s:%u]传入的执行命令长度(%d)不支持"), m_strIP, m_usPort, pTcpCmd->m_lDataLength);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else
	{
		nBufferCacheSize = pTcpCmd->m_lDataLength + MF_TEMPBUFFER_SIZE + MF_RECYCLESECTION_SIZE;		//缓存总大小
		if(nBufferCacheSize > m_nBufferCacheSize)
		{
			//超过每个会话本身的缓存，直接重新分配指定大小的数据
			m_lpAddr = new BYTE[nBufferCacheSize];
			if(m_lpAddr == NULL)
			{
				Trace(_T("CTCPServerProcess::ImportObject"), MF_TRACE_LEVEL_FAILED, 300011003, 
					_T("处理客户端[%s:%u]命令时分配内存失败，分配长度%d，错误码：%d"), m_strIP, m_usPort, nBufferCacheSize, GetLastError());
				stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
				ClearSocket();
			}
		}
		else
		{
			nBufferCacheSize = m_nBufferCacheSize;
			m_lpAddr = m_lpBuffer;
		}

		if(m_lpAddr != NULL)
		{
			if(!ReceiveBuffer((char *)(m_lpAddr), pTcpCmd->m_lDataLength))
			{
				stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
			}
			else
			{
				if(g_pSobeyMemServiceManage == NULL)
				{
					//理论上不存在这种情况
					stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
					Trace(_T("CTCPServerProcess::ImportObject"), MF_TRACE_LEVEL_FAILED, 300011004, _T("系统没有初始化起来！"));
				}
				else
				{
					nRet = stBson.Initial(m_lpAddr, nBufferCacheSize, MF_TEMPBUFFER_SIZE, MF_RECYCLESECTION_SIZE, 0);			//需要分配临时空间来备份事务链表
					if(nRet != MF_OK)
					{
						return nRet;
					}
					nTimestamp = GetSystemTimestamp();
					stTransaction.StartTransaction(nTimestamp);

					lpObjectBufferHead = (LPOBJECTBUFFERHEAD)m_lpAddr;
					nRet = g_pSobeyMemServiceManage->ImportObject(stBson, lpObjectName, &stImportParam, nTimestamp);
					if(nRet == MF_OK)
					{
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_OK;
					}
					else
					{
						stTcpCmd.m_lDigitalData = nRet;
						stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
						Trace(_T("CTCPServerProcess::ImportObject"), MF_TRACE_LEVEL_FAILED, 300011005, _T("客户端[%s:%u]传入的ImportObject命令执行失败，返回值：%d"), m_strIP, m_usPort, nRet);
					}
				}
			}

			if(m_lpAddr != m_lpBuffer)
			{
				delete [] m_lpAddr;
			}
			m_lpAddr = NULL;

		}
	}

	stTransaction.CommitTransaction(nTimestamp);
	nRet = send(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
	if(nRet  != sizeof(MF_SERVICE_TCP_COMMAND))
	{
		Trace(_T("CTCPServerProcess::ImportObject"), MF_TRACE_LEVEL_FAILED, 300011006, 
			_T("向客户端[%s:%u]返回处理结果失败！返回值：%d，错误号：%d"), m_strIP, m_usPort, nRet, WSAGetLastError());
		return FALSE;
	}

	return TRUE;
}


int CTCPServerProcess::GetUserInfo(char* pUserName, LPUSERINFODEF& lpUserInfo)
{
	return g_pSobeyMemServiceManage->GetUserInfo(pUserName, lpUserInfo);
}

BOOL CTCPServerProcess::CheckPassword(LPUSERINFODEF lpUserInfo, BYTE* pPassword)
{
	int nRet;
	BYTE bPasswordSrc[24];
	memset(bPasswordSrc, 0, 24);
	if(lpUserInfo->m_pPassword[0] == 0 && pPassword[0] == 0)
	{
		return TRUE;
	}
	nRet = Encryption(pPassword, bPasswordSrc);
	if(nRet != MF_OK)
	{
		return FALSE;
	}

	if(memcmp(bPasswordSrc, lpUserInfo->m_pPassword, 24)!= 0)
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

BOOL CTCPServerProcess::StartTransactionLogic(MF_SERVICE_TCP_COMMAND * pTcpCmd)
{
	int nRet;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	MF_EXECUTESTATISTICSINFO stExecuteStatistics;

	memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
	stTcpCmd.m_bVersion			= 1;
	stTcpCmd.m_lDataLength		= 0;
	stTcpCmd.m_bToken			= pTcpCmd->m_bToken;
	if(pTcpCmd->m_bVersion != 1)
	{
		//不支持的命令版本，直接失败并清理
		Trace(_T("CTCPServerProcess::StartTransactionLogic"), MF_TRACE_LEVEL_FAILED ,300030001 , _T("处理客户端[%d.%d.%d.%d:%u]传入的开启短事务锁命令版本号(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_bVersion);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else if(pTcpCmd->m_lDataLength != 0)
	{
		//数据肯定出现了错乱，直接失败并清理
		Trace(_T("CTCPServerProcess::StartTransactionLogic"), MF_TRACE_LEVEL_FAILED ,300030002 , _T("处理客户端[%d.%d.%d.%d:%u]传入的开启短事务锁命令(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_lDataLength);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else
	{
		nRet = g_pSobeyMemServiceManage->TCPStartTransactionLogic(m_ulRemoteIP, pTcpCmd->m_lpszParam, stTcpCmd.m_lDigitalData, m_lpExecuteInfo);
		if(nRet == MF_OK)
		{
			stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_OK;
		}
		else
		{
			stTcpCmd.m_lDigitalData = nRet;
			stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		}
	}

	GetExecuteStatistics(stExecuteStatistics);
	memcpy(stTcpCmd.m_lpszParam, &stExecuteStatistics, sizeof(stExecuteStatistics));

	nRet = send(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
	if(nRet  != sizeof(MF_SERVICE_TCP_COMMAND))
	{
		Trace(_T("CTCPServerProcess::StartTransactionLogic"), MF_TRACE_LEVEL_FAILED ,300030004 , _T("客户端[%d.%d.%d.%d:%u]返回处理结果失败！返回值：%d，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, WSAGetLastError());
		return FALSE;
	}

	return TRUE;
}

BOOL CTCPServerProcess::StopTransactionLogic(MF_SERVICE_TCP_COMMAND * pTcpCmd)
{
	int nRet;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	MF_EXECUTESTATISTICSINFO stExecuteStatistics;

	memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
	stTcpCmd.m_bVersion			= 1;
	stTcpCmd.m_lDataLength		= 0;
	stTcpCmd.m_bToken			= pTcpCmd->m_bToken;
	if(pTcpCmd->m_bVersion != 1)
	{
		//不支持的命令版本，直接失败并清理
		Trace(_T("CTCPServerProcess::TCPStopTransactionLogic"), MF_TRACE_LEVEL_FAILED ,300031001 , _T("处理客户端[%d.%d.%d.%d:%u]传入的结束短事务锁命令版本号(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_bVersion);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else if(pTcpCmd->m_lDataLength != 0)
	{
		//数据肯定出现了错乱，直接失败并清理
		Trace(_T("CTCPServerProcess::TCPStopTransactionLogic"), MF_TRACE_LEVEL_FAILED ,300031002 , _T("处理客户端[%d.%d.%d.%d:%u]传入的结束短事务锁命令(%d)不支持"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, pTcpCmd->m_lDataLength);
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		ClearSocket();
	}
	else
	{
		nRet = g_pSobeyMemServiceManage->TCPStopTransactionLogic(m_ulRemoteIP, pTcpCmd->m_lDigitalData, m_lpExecuteInfo);
		if(nRet == MF_OK)
		{
			stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_OK;
		}
		else
		{
			stTcpCmd.m_lDigitalData = nRet;
			stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_FAIL;
		}
	}

	GetExecuteStatistics(stExecuteStatistics);
	memcpy(stTcpCmd.m_lpszParam, &stExecuteStatistics, sizeof(stExecuteStatistics));

	nRet = send(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
	if(nRet  != sizeof(MF_SERVICE_TCP_COMMAND))
	{
		Trace(_T("CTCPServerProcess::TCPStopTransactionLogic"), MF_TRACE_LEVEL_FAILED ,300031004 , _T("客户端[%d.%d.%d.%d:%u]返回处理结果失败！返回值：%d，错误号：%d"), FIRST_IPADDRESS(m_ulRemoteIP), SECOND_IPADDRESS(m_ulRemoteIP), THIRD_IPADDRESS(m_ulRemoteIP), FOURTH_IPADDRESS(m_ulRemoteIP), m_usPort, nRet, WSAGetLastError());
		return FALSE;
	}

	return TRUE;
}

BOOL CTCPServerProcess::UserLogin(MF_SERVICE_TCP_COMMAND * pTcpCmd)
{
	int nRet;
	char pUserName[24];
	BYTE pPassword[24];
	LPUSERINFODEF lpUserInfo;
	MF_CLIENTINFO *lpClientInfo;
	MF_SERVICE_TCP_COMMAND stTcpCmd;		//返回信息

	lpClientInfo = (MF_CLIENTINFO*)pTcpCmd->m_lpszParam;
	if(pTcpCmd->m_bVersion == 1)
	{
		if(lpClientInfo->m_bCmdType == 1)
		{
			m_lpSessionInfo->m_bConnectType  = 0;
			m_lpSessionInfo->m_ulMachineIP	 = lpClientInfo->m_ulIP;
			m_lpSessionInfo->m_usMachinePort = lpClientInfo->m_usPort;
			m_lpSessionInfo->m_dwProcessID	 = lpClientInfo->m_dwProcessID;
			m_lpSessionInfo->m_dwThreadID	 = lpClientInfo->m_dwThreadID;
			m_lpSessionInfo->m_ullUserData	 = lpClientInfo->m_ullUserData;
			m_lpSessionInfo->m_dwUserData	 = lpClientInfo->m_dwUserData;
			sprintf(m_lpSessionInfo->m_lpszMachineIP, "%d.%d.%d.%d", FIRST_IPADDRESS(lpClientInfo->m_ulIP), SECOND_IPADDRESS(lpClientInfo->m_ulIP), THIRD_IPADDRESS(lpClientInfo->m_ulIP), FOURTH_IPADDRESS(lpClientInfo->m_ulIP));
			memcpy(m_lpSessionInfo->m_lpszProgramName, lpClientInfo->m_lpszProgramName, 23);
			memcpy(m_lpSessionInfo->m_lpszUserName, lpClientInfo->m_pUserName, 24);	
		}
		else if(lpClientInfo->m_bCmdType == 2)
		{
			m_lpSessionInfo->m_ullUserData	 = lpClientInfo->m_ullUserData;
			memcpy(m_lpSessionInfo->m_lpszUserName, lpClientInfo->m_pUserName, 24);
		}
		else if(lpClientInfo->m_bCmdType == 3)
		{
			m_lpSessionInfo->m_dwUserData	 = lpClientInfo->m_dwUserData;
			memcpy(m_lpSessionInfo->m_lpszUserName, lpClientInfo->m_pUserName, 24);
		}
		memcpy(pUserName, lpClientInfo->m_pUserName, 24);
		memcpy(pPassword, lpClientInfo->m_pPassword, 24);

		memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
		stTcpCmd.m_bVersion			= 1;
		stTcpCmd.m_lDataLength		= 0;
		stTcpCmd.m_bToken			= pTcpCmd->m_bToken;

		lpUserInfo = NULL;
		nRet = GetUserInfo(pUserName, lpUserInfo);
		if(nRet != MF_OK)
		{
			stTcpCmd.m_bType		= MF_INTERFACE_TCPCOMMAND_FAIL;
			stTcpCmd.m_lDigitalData = MF_USERLOGIN_INVALIDUSERNAME_FAILED;
		}
		else
		{
			if(0 == lpUserInfo->m_bStatus)
			{
				stTcpCmd.m_bType		= MF_INTERFACE_TCPCOMMAND_FAIL;
				stTcpCmd.m_lDigitalData = MF_USERLOGIN_DISABLE_USER;
			}
			else
			{
				if(CheckPassword(lpUserInfo, pPassword))
				{
					stTcpCmd.m_bType				= MF_INTERFACE_TCPCOMMAND_OK;
					m_lpSessionInfo->m_nUserID		= lpUserInfo->m_nUserID;
				}
				else
				{
					stTcpCmd.m_bType		= MF_INTERFACE_TCPCOMMAND_FAIL;
					stTcpCmd.m_lDigitalData = MF_USERLOGIN_INVALIDPASSWORD_FAILED;
				}
			}
		}

		nRet = send(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
		if(nRet != sizeof(MF_SERVICE_TCP_COMMAND))
		{
			Trace(_T("CTCPServerProcess::UserLogin"), MF_TRACE_LEVEL_FAILED, 300058008, 
				_T("向主服务器端[%s:%u]返回处理结果失败！返回值：%d，错误号：%d"), m_strIP, m_usPort, nRet, WSAGetLastError());
			return FALSE;
		}
	}
	else
	{
		//版本号不对
		Trace(_T("CTCPServerProcess::UserLogin"), MF_TRACE_LEVEL_FAILED, 300058008, 
			_T("客户端[%s:%u]传入的登录命令版本号(%d)不支持！客户端版本号：%d"), m_strIP, m_usPort, pTcpCmd->m_bVersion);
	}

	return FALSE;
}

BOOL CTCPServerProcess::UserLogOut(MF_SERVICE_TCP_COMMAND * pTcpCmd)
{
	int nRet;
	char pUserName[24];
	BYTE pPassword[24];
	LPUSERINFODEF lpUserInfo;
	MF_SERVICE_TCP_COMMAND stTcpCmd;		//返回信息

	memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
	stTcpCmd.m_bVersion			= 1;
	stTcpCmd.m_lDataLength		= 0;
	stTcpCmd.m_bToken			= pTcpCmd->m_bToken;

	memcpy(pUserName, pTcpCmd->m_lpszParam, 24);
	memcpy(pPassword, pTcpCmd->m_lpszParam + 24, 24);

	lpUserInfo = NULL;
	nRet = GetUserInfo(pUserName, lpUserInfo);
	if(nRet != MF_OK)
	{
		stTcpCmd.m_bType		= MF_INTERFACE_TCPCOMMAND_FAIL;
		stTcpCmd.m_lDigitalData = MF_USERLOGIN_INVALIDUSERNAME_FAILED;
	}
	else
	{
		if(CheckPassword(lpUserInfo, pPassword))
		{
			stTcpCmd.m_bType				= MF_INTERFACE_TCPCOMMAND_OK;
			m_lpSessionInfo->m_nUserID		= 0;
		}
		else
		{
			stTcpCmd.m_bType		= MF_INTERFACE_TCPCOMMAND_FAIL;
			stTcpCmd.m_lDigitalData = MF_USERLOGIN_INVALIDPASSWORD_FAILED;
		}
	}

	nRet = send(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
	if(nRet  != sizeof(MF_SERVICE_TCP_COMMAND))
	{
		Trace(_T("CTCPServerProcess::UserLogOut"), MF_TRACE_LEVEL_FAILED, 300058009, 
			_T("向主服务器端[%s:%u]返回处理结果失败！返回值：%d，错误号：%d"), m_strIP, m_usPort, nRet, WSAGetLastError());
		return FALSE;
	}

	return TRUE;
}
