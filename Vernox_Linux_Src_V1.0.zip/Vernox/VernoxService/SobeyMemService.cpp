﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include <stdio.h>
#include "SobeyMemServiceManage.h"
#include "TCPServerProcess.h"
#include "../VernoxServiceLib/ServiceCommonDef.h"
#include "../VernoxServiceLib/SystemManage.h"

#ifdef WIN32
#include <WinBase.h>
#pragma comment(lib, "Kernel32.lib")
#else
#include <signal.h>
#include <execinfo.h>

static bool g_bExit;
void stopsignal(int signalnum)
{
	g_bExit = true;
}
#endif

#ifdef WIN32
HANDLE 					g_hExitEvent			= NULL;
HANDLE 					g_hProcessExitEvent		= NULL;
CRITICAL_SECTION 		g_CritServerParallel;
CRITICAL_SECTION 		g_critThread;
#else
sem_t					g_hExitEvent;
sem_t					g_hProcessExitEvent;
pthread_mutex_t 		g_CritServerParallel;
pthread_mutex_t 		g_critThread;
#endif

BOOL   g_bWriteEfficiencyTrace	= FALSE;
int	   g_nServerParallelMode	= 0;
LONG   g_lConnectNum			= 0;

CSobeyMemServiceManage* 	g_pSobeyMemServiceManage 	= NULL;
extern LONG g_lSessionID;

#ifdef WIN32
map<DWORD, HANDLE> g_mapProcessThead;
#else
map<pthread_t, pthread_t> g_mapProcessThead;
#endif

#define  MF_BACKLOG    100
#define  MF_MAX_THR    10 

#ifdef WIN32
UINT SoapServiceThread(LPVOID lpParam);
int CreateTCPListenThread(HANDLE &hThreadHandle, LPVOID data);
#else
void* SoapServiceThread(LPVOID lpParam);
int CreateTCPListenThread(pthread_t &thThread, LPVOID data);
#endif

CServiceModule _Module;
#ifdef WIN32
BEGIN_OBJECT_MAP(ObjectMap)
END_OBJECT_MAP()

LPCTSTR FindOneOf(LPCTSTR p1, LPCTSTR p2)
{
    while (p1 != NULL && *p1 != NULL)
    {
        LPCTSTR p = p2;
        while (p != NULL && *p != NULL)
        {
            if (*p1 == *p)
                return CharNext(p1);
            p = CharNext(p);
        }
        p1 = CharNext(p1);
    }
    return NULL;
}

// Although some of these functions are big they are declared inline since they are only used once
inline HRESULT CServiceModule::RegisterServer(BOOL bRegTypeLib, BOOL bService)
{
    HRESULT hr = CoInitialize(NULL);
    if (FAILED(hr))
        return hr;

    // Remove any previous service since it may point to
    // the incorrect file
    Uninstall();

    // Add service entries
    UpdateRegistryFromResource(IDR_SOBEYMEMSERVICE, TRUE);

    // Adjust the AppID for Local Server or Service
    CRegKey keyAppID;
    LONG lRes = keyAppID.Open(HKEY_CLASSES_ROOT, _T("AppID"), KEY_WRITE);
    if (lRes != ERROR_SUCCESS)
        return lRes;

    CRegKey key;
    lRes = key.Open(keyAppID, _T("{9C59875F-F72B-4C55-B60F-3B789DE66795}"), KEY_WRITE);
    if (lRes != ERROR_SUCCESS)
	{
		lRes = key.Create(keyAppID, _T("{9C59875F-F72B-4C55-B60F-3B789DE66795}"));
		if(lRes != ERROR_SUCCESS)
		{
			return lRes;
		}
	}
    key.DeleteValue(_T("LocalService"));
    
    if (bService)
    {
        key.SetStringValue(_T("VernoxService"), _T("LocalService"));
        key.SetStringValue(_T("-Service"), _T("ServiceParameters"));
        // Create service
        Install();
    }

    // Add object entries
    hr = CComModule::RegisterServer(bRegTypeLib);

    CoUninitialize();
    return hr;
}

inline HRESULT CServiceModule::UnregisterServer()
{
    HRESULT hr = CoInitialize(NULL);
    if (FAILED(hr))
        return hr;

    // Remove service entries
    UpdateRegistryFromResource(IDR_SOBEYMEMSERVICE, FALSE);
    // Remove service
    Uninstall();
    // Remove object entries
    CComModule::UnregisterServer(TRUE);
    CoUninitialize();
    return S_OK;
}

inline void CServiceModule::Init(_ATL_OBJMAP_ENTRY* p, HINSTANCE h, UINT nServiceNameID, const GUID* plibid)
{
    CComModule::Init(p, h, plibid);

    m_bService = TRUE;

    LoadString(h, nServiceNameID, m_szServiceName, sizeof(m_szServiceName) / sizeof(TCHAR));

    // set up the initial service status 
    m_hServiceStatus					= NULL;
    m_status.dwServiceType				= SERVICE_WIN32_OWN_PROCESS;
    m_status.dwCurrentState				= SERVICE_STOPPED;
    m_status.dwControlsAccepted			= SERVICE_ACCEPT_STOP;
    m_status.dwWin32ExitCode			= 0;
    m_status.dwServiceSpecificExitCode	= 0;
    m_status.dwCheckPoint				= 0;
    m_status.dwWaitHint					= 0;
}

LONG CServiceModule::Unlock()
{
    LONG l = CComModule::Unlock();
    if (l == 0 && !m_bService)
        PostThreadMessage(dwThreadID, WM_QUIT, 0, 0);
    return l;
}

BOOL CServiceModule::IsInstalled()
{
    BOOL bResult = FALSE;

    SC_HANDLE hSCM = ::OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);

    if (hSCM != NULL)
    {
        SC_HANDLE hService = ::OpenService(hSCM, m_szServiceName, SERVICE_QUERY_CONFIG);
        if (hService != NULL)
        {
            bResult = TRUE;
            ::CloseServiceHandle(hService);
        }
        ::CloseServiceHandle(hSCM);
    }
    return bResult;
}

inline BOOL CServiceModule::Install()
{
    if (IsInstalled())
        return TRUE;

    SC_HANDLE hSCM = ::OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    if (hSCM == NULL)
    {
        MessageBox(NULL, _T("Couldn't open service manager"), m_szServiceName, MB_OK);
        return FALSE;
    }

    // Get the executable file path
    TCHAR szFilePath[_MAX_PATH];
    ::GetModuleFileName(NULL, szFilePath, _MAX_PATH);

#ifdef _DEBUG
    SC_HANDLE hService = ::CreateService(
        hSCM, m_szServiceName, m_szServiceName,
        SERVICE_ALL_ACCESS, SERVICE_WIN32_OWN_PROCESS | SERVICE_INTERACTIVE_PROCESS,
        SERVICE_AUTO_START, SERVICE_ERROR_NORMAL,
        szFilePath, NULL, NULL, _T("VernoxStorage\0"), NULL, NULL);
#else
    SC_HANDLE hService = ::CreateService(
        hSCM, m_szServiceName, m_szServiceName,
        SERVICE_ALL_ACCESS, SERVICE_WIN32_OWN_PROCESS,
        SERVICE_AUTO_START, SERVICE_ERROR_NORMAL,
        szFilePath, NULL, NULL, _T("VernoxStorage\0"), NULL, NULL);
#endif

    if (hService == NULL)
    {
        ::CloseServiceHandle(hSCM);
        MessageBox(NULL, _T("Couldn't create service"), m_szServiceName, MB_OK);
        return FALSE;
    }

	SERVICE_DESCRIPTION InfoDescription;
	InfoDescription.lpDescription = _T("索贝内存数据服务");
	ChangeServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION, &InfoDescription);

    ::CloseServiceHandle(hService);
    ::CloseServiceHandle(hSCM);
    return TRUE;
}

inline BOOL CServiceModule::Uninstall()
{
    if (!IsInstalled())
        return TRUE;

    SC_HANDLE hSCM = ::OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);

    if (hSCM == NULL)
    {
        MessageBox(NULL, _T("Couldn't open service manager"), m_szServiceName, MB_OK);
        return FALSE;
    }

    SC_HANDLE hService = ::OpenService(hSCM, m_szServiceName, SERVICE_STOP | DELETE);

    if (hService == NULL)
    {
        ::CloseServiceHandle(hSCM);
        MessageBox(NULL, _T("Couldn't open service"), m_szServiceName, MB_OK);
        return FALSE;
    }
    SERVICE_STATUS status;
    ::ControlService(hService, SERVICE_CONTROL_STOP, &status);

    BOOL bDelete = ::DeleteService(hService);
    ::CloseServiceHandle(hService);
    ::CloseServiceHandle(hSCM);

    if (bDelete)
        return TRUE;

    MessageBox(NULL, _T("Service could not be deleted"), m_szServiceName, MB_OK);
    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////////////
// Logging functions
void CServiceModule::LogEvent(LPCTSTR pFormat, ...)
{
    TCHAR    chMsg[256];
    HANDLE  hEventSource;
    LPTSTR  lpszStrings[1];
    va_list pArg;

    va_start(pArg, pFormat);
    _vstprintf(chMsg, pFormat, pArg);
    va_end(pArg);

    lpszStrings[0] = chMsg;

    if (m_bService)
    {
        /* Get a handle to use with ReportEvent(). */
        hEventSource = RegisterEventSource(NULL, m_szServiceName);
        if (hEventSource != NULL)
        {
            /* Write to event log. */
            ReportEvent(hEventSource, EVENTLOG_INFORMATION_TYPE, 0, 0, NULL, 1, 0, (LPCTSTR*) &lpszStrings[0], NULL);
            DeregisterEventSource(hEventSource);
        }
    }
    else
    {
        // As we are not running as a service, just write the error to the console.
		OutputDebugString(chMsg);	
        //_putts(chMsg);
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////
// Service startup and registration
inline void CServiceModule::Start()
{
    SERVICE_TABLE_ENTRY st[] =
    {
        { m_szServiceName, _ServiceMain },
        { NULL, NULL }
    };
    if (m_bService && !::StartServiceCtrlDispatcher(st))
    {
        m_bService = FALSE;
    }
    if (m_bService == FALSE)
        Run();
}

inline void CServiceModule::ServiceMain(DWORD /* dwArgc */, LPTSTR* /* lpszArgv */)
{
    // Register the control request handler
    m_status.dwCurrentState = SERVICE_START_PENDING;
    m_hServiceStatus = RegisterServiceCtrlHandler(m_szServiceName, _Handler);
    if (m_hServiceStatus == NULL)
    {
        LogEvent(_T("Handler not installed"));
        return;
    }
    SetServiceStatus(SERVICE_START_PENDING);

    m_status.dwWin32ExitCode = S_OK;
    m_status.dwCheckPoint = 0;
    m_status.dwWaitHint = 0;

    // When the Run function returns, the service has stopped.
    Run();

    SetServiceStatus(SERVICE_STOPPED);
    LogEvent(_T("Service stopped"));
}

inline void CServiceModule::Handler(DWORD dwOpcode)
{
    switch (dwOpcode)
    {
    case SERVICE_CONTROL_STOP:
        SetServiceStatus(SERVICE_STOP_PENDING);
        PostThreadMessage(dwThreadID, WM_QUIT, 0, 0);
        break;
    case SERVICE_CONTROL_PAUSE:
        break;
    case SERVICE_CONTROL_CONTINUE:
        break;
    case SERVICE_CONTROL_INTERROGATE:
        break;
    case SERVICE_CONTROL_SHUTDOWN:
        break;
    default:
        LogEvent(_T("Bad service request"));
    }
}

void WINAPI CServiceModule::_ServiceMain(DWORD dwArgc, LPTSTR* lpszArgv)
{
    _Module.ServiceMain(dwArgc, lpszArgv);
}
void WINAPI CServiceModule::_Handler(DWORD dwOpcode)
{
    _Module.Handler(dwOpcode); 
}

void CServiceModule::SetServiceStatus(DWORD dwState)
{
    m_status.dwCurrentState = dwState;
    ::SetServiceStatus(m_hServiceStatus, &m_status);
}
#endif

typedef struct stu_TCP_THREAD_PRARM
{
	HANDLE m_hStopEvent;				//停止处理消息事件
	HANDLE m_hProcessExitEvent;	//处理线程退出时间
	SOCKET m_socket;					//处理的SOCKET连接
	USHORT m_usPort;					//端口号
	ULONG  m_ulRemoteIP;				//对方IP地址
}TCP_THREAD_PRARM;

void RemoveThreadFromSet(DWORD dwThreadID)
{
	CCriticalSectionPtr cs(&g_critThread);
	g_mapProcessThead.erase(dwThreadID);
}

void ReleaseResource()
{
#ifdef WIN32
	if(g_hExitEvent != NULL)
	{
		CloseHandle(g_hExitEvent);
		g_hExitEvent = NULL;
	}
	if(g_hProcessExitEvent != NULL)
	{
		CloseHandle(g_hProcessExitEvent);
		g_hProcessExitEvent = NULL;
	}
#else
	sem_destroy(&g_hExitEvent);
	sem_destroy(&g_hProcessExitEvent);
#endif

	if(g_pSobeyMemServiceManage != NULL)
	{
		g_pSobeyMemServiceManage->Uninitialize();
		delete g_pSobeyMemServiceManage;
		g_pSobeyMemServiceManage = NULL;
	}
#ifdef WIN32	
	::DeleteCriticalSection(&g_CritServerParallel);
	::DeleteCriticalSection(&g_critThread);
	_Module.RevokeClassObjects();
	CoUninitialize();
#else
	pthread_mutex_destroy(&g_CritServerParallel);
	pthread_mutex_destroy(&g_critThread);
#endif
}

void CServiceModule::Run()
{
	DWORD dwTime;
	SOCKET skSocket;
	BOOL bTransactionEnd;
	struct sockaddr_in sa;
	long long nStart, nEnd;
	TCP_THREAD_PRARM stParam;
	int nRet, nPort, nTCPPort;
#ifdef WIN32
	WSADATA sWSAData;
	DWORD dwThreadID;
	map<DWORD, HANDLE>::iterator iter;
	HANDLE hThreadHandle  = INVALID_HANDLE_VALUE;
	HANDLE hProcessThread = INVALID_HANDLE_VALUE;
	
	WSAStartup(MAKEWORD(2, 2), &sWSAData);
   CoInitialize(NULL);
	CSecurityDescriptor sd;
   sd.InitializeFromThreadToken();
   CoInitializeSecurity(sd, -1, NULL, NULL,RPC_C_AUTHN_LEVEL_PKT, RPC_C_IMP_LEVEL_IMPERSONATE, NULL, EOAC_NONE, NULL);
   _Module.RegisterClassObjects(CLSCTX_LOCAL_SERVER | CLSCTX_REMOTE_SERVER, REGCLS_MULTIPLEUSE);

   LogEvent(_T("Service started"));
   if (m_bService)
       SetServiceStatus(SERVICE_RUNNING);
#else
   pthread_t dwThreadID;
	pthread_t hThreadHandle  = 0;
	pthread_t hProcessThread = 0;
	map<pthread_t, pthread_t>::iterator iter;
	signal(SIGTERM, stopsignal);
	signal(SIGINT, stopsignal);
#endif	
	
	_Module.dwThreadID = GetCurrentThreadId();
	//初始化系统环境，如果失败的话服务就停止
	g_pSobeyMemServiceManage = new CSobeyMemServiceManage;
	nRet = g_pSobeyMemServiceManage->Initialize();
	if(nRet != MF_OK)
	{
		ReleaseResource();
#ifdef WIN32	
		if (m_bService)
			Handler(SERVICE_CONTROL_STOP);
#endif
		return;
	}

	g_bWriteEfficiencyTrace = GetSystemParameterValue(MF_SERVER_EFFICIENCY_TRACE);
	g_nServerParallelMode   = GetSystemParameterValue(MF_SERVER_PARALLELMODE);
#ifdef WIN32
	::InitializeCriticalSection(&g_CritServerParallel);
	::InitializeCriticalSection(&g_critThread);
	
	g_hExitEvent 		= CreateEvent(NULL, TRUE, FALSE, NULL);
	g_hProcessExitEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
#else
	pthread_mutex_init(&g_CritServerParallel, NULL);
	pthread_mutex_init(&g_critThread, NULL);
#endif

	//重作日志恢复
	nRet = g_pSobeyMemServiceManage->RecoverByRedo();
	if (nRet != MF_OK)
	{
		ReleaseResource();
#ifdef WIN32
		if (m_bService)
			Handler(SERVICE_CONTROL_STOP);
#endif
		return;
	}

	//开始监听
#ifdef WIN32
	if(g_hExitEvent != INVALID_HANDLE_VALUE)
#else
	if(-1 != sem_init(&g_hExitEvent, 0, 0))
#endif 
	{
		nPort			= GetSystemParameterValue(MF_SERVICE_PORT);
		nTCPPort		= GetSystemParameterValue(MF_TCP_LISTEN_PORT);
		//开启TCP监听线程
	#ifdef WIN32
		stParam.m_hStopEvent = g_hExitEvent;
		stParam.m_hProcessExitEvent = g_hProcessExitEvent;
	#else
		stParam.m_hStopEvent = &g_hExitEvent;
		stParam.m_hProcessExitEvent = &g_hProcessExitEvent;
	#endif

		//开启监听线程
		nRet = CreateTCPListenThread(hThreadHandle, (void*)&stParam);
		if(nRet != 0)
		{
			ReleaseResource();
#ifdef WIN32
			if (m_bService)
				Handler(SERVICE_CONTROL_STOP);
#endif
			return;
		}

	#ifdef WIN32
		MSG msg;
		while (GetMessage(&msg, 0, 0, 0))
			DispatchMessage(&msg);
	#else
		//
		FILE* fpServiceStart = NULL;
		fpServiceStart = fopen("/ServiceStart", "w");
		if(fpServiceStart != NULL)
		{
			fclose(fpServiceStart);
			fpServiceStart = NULL;
		}
		//
		Trace0(_T("Run"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10001111,_T("开始索贝数据服务！"));
		while(!g_bExit)
		{
			Sleep(100);
		}
	#endif
		//	Signal each thread to stop
		SetEvent(g_hExitEvent);
		Sleep(1);
		//连接一下本地TCP监听，否则事件无法判断
		memset(&sa,0,sizeof(sa));
		sa.sin_family=AF_INET;
		sa.sin_port=htons(nTCPPort);
		sa.sin_addr.s_addr=inet_addr("127.0.0.1");
		skSocket = socket(AF_INET,SOCK_STREAM, 0);
		if(skSocket != INVALID_SOCKET)
		{
			connect(skSocket, (const sockaddr*)&sa, sizeof(sa));
			closesocket(skSocket);
		}
	#ifdef WIN32
		//连接一下本地soap监听，否则事件无法判断
		memset(&sa,0,sizeof(sa));
		sa.sin_family=AF_INET;
		sa.sin_port=htons(nPort);
		sa.sin_addr.s_addr=inet_addr("127.0.0.1");
		skSocket = socket(AF_INET,SOCK_STREAM, 0);
		if(skSocket != INVALID_SOCKET)
		{
			connect(skSocket, (const sockaddr*)&sa, sizeof(sa));
			closesocket(skSocket);
		}
	
	#endif
		//等待TCP监听线程的退出
		WaitForSingleObject(hThreadHandle, 60*1000);

		//判断事务是否结束
		GetSystemTimeAsFileTime((LPFILETIME)&nStart);
		while(TRUE)
		{
			bTransactionEnd = CSystemManage::instance().CheckTransactionActive();

			//转换到毫秒
			GetSystemTimeAsFileTime((LPFILETIME)&nEnd);
			dwTime = (DWORD)(nEnd - nStart) / 10000;
			
			if(bTransactionEnd)
			{
				if(dwTime < 100)
				{
					Sleep(100 - dwTime);
					break;
				}
				else
				{
					break;
				}
			}
			else if(dwTime < 1000)
			{
				Sleep(1);
			}
			else
			{
				break;
			}
		}
		if(bTransactionEnd)
		{
			SetEvent(g_hProcessExitEvent);
		}
		else
		{
			SetEvent(g_hProcessExitEvent);
			CSystemManage::instance().ClearDataFile();
		}

		//等待处理线程退出
	#ifdef WIN32
		for(iter = g_mapProcessThead.begin(); iter != g_mapProcessThead.end(); )
		{
			hProcessThread = iter->second;
			iter++;
			if(hProcessThread != INVALID_HANDLE_VALUE)
			{
				WaitForSingleObject(hProcessThread, 1000);
				dwThreadID = GetThreadId(hProcessThread);
				RemoveThreadFromSet(dwThreadID);
			}
		}
	#else
		for(iter = g_mapProcessThead.begin(); iter != g_mapProcessThead.end(); )
		{
			dwThreadID		= iter->first;
			hProcessThread = iter->second;
			iter++;
			if(dwThreadID != 0)
			{
				WaitForSingleObject(hProcessThread, 1000);
				RemoveThreadFromSet(dwThreadID);
			}
		}
	#endif
		g_mapProcessThead.clear();
	}

	ReleaseResource();
}

#ifdef WIN32
/////////////////////////////////////////////////////////////////////////////
//
//虚拟一个应用程序模板的GUID
const IID LIBID_SobeyMemServiceLib = {0x9ac38857, 0xef5c, 0x494e, { 0xb9, 0x21, 0x54, 0x25, 0xb6, 0xe3, 0xa4, 0x97}};

extern "C" int WINAPI _tWinMain(HINSTANCE hInstance, 
    HINSTANCE /*hPrevInstance*/, LPTSTR lpCmdLine, int /*nShowCmd*/)
{
    lpCmdLine = GetCommandLine(); //this line necessary for _ATL_MIN_CRT
    _Module.Init(ObjectMap, hInstance, IDS_SERVICENAME, &LIBID_SobeyMemServiceLib);
    _Module.m_bService = TRUE;

    TCHAR szTokens[] = _T("-/");

    LPCTSTR lpszToken = FindOneOf(lpCmdLine, szTokens);
	while (lpszToken != NULL)
    {
        if (lstrcmpi(lpszToken, _T("UnregServer"))==0)
            return _Module.UnregisterServer();

        // Register as Local Server
        if (lstrcmpi(lpszToken, _T("RegServer"))==0)
            return _Module.RegisterServer(TRUE, FALSE);
        
        // Register as Service
        if (lstrcmpi(lpszToken, _T("Service"))==0)
            return _Module.RegisterServer(TRUE, TRUE);
        
        lpszToken = FindOneOf(lpszToken, szTokens);
    }

    // Are we Service or Local Server
    CRegKey keyAppID;
    LONG lRes = keyAppID.Open(HKEY_CLASSES_ROOT, _T("AppID"), KEY_READ);
    if (lRes != ERROR_SUCCESS)
        return lRes;
     _Module.m_bService = TRUE;

	HANDLE hEvent;
	hEvent = ::CreateMutex(NULL, FALSE, _T("Global\\SobeyMemoryService"));
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		::CloseHandle(hEvent);
		::MessageBox(NULL,_T("另外一个内存服务已经启动，软件退出！"),_T("提示"),MB_OK|MB_ICONSTOP);
		return FALSE;
	}

    _Module.Start();

	::CloseHandle(hEvent);
	// When we get here, the service has been stopped
    return _Module.m_status.dwWin32ExitCode;
}
#else
int main()
{
	_Module.Run();
    return 0;
}

#endif


//TCP接收数据处理线程
#ifdef WIN32
void TCPProcessThread(LPVOID data)
#else
void* TCPProcessThread(LPVOID data)
#endif
{
	ULONG  ulIP;
	USHORT usPort;
	SOCKET socket;
	DWORD  dwThreadID;
	
#ifdef WIN32
	HANDLE hStopEvent;
	HANDLE hExitProcessEvent;
#else
	sem_t* hStopEvent;
	sem_t* hExitProcessEvent;
#endif

	ulIP	= 0;
	usPort	= 0;
	InterlockedIncrement(&g_lConnectNum);
#ifdef WIN32
	CoInitialize(NULL);
#endif
	try
	{
		TCP_THREAD_PRARM *lpParam = (TCP_THREAD_PRARM *)data;
		if(lpParam != NULL)
		{
			CTCPServerProcess ServerProcess;
			socket				= lpParam->m_socket;
#ifdef WIN32
			hStopEvent			= lpParam->m_hStopEvent;
			hExitProcessEvent	= lpParam->m_hProcessExitEvent;
#else
			hStopEvent			= (sem_t*)lpParam->m_hStopEvent;
			hExitProcessEvent	= (sem_t*)lpParam->m_hProcessExitEvent;
#endif
			ulIP					= lpParam->m_ulRemoteIP;
			usPort				= lpParam->m_usPort;
			delete lpParam;
			Trace(_T("TCPProcessThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10005001, _T("客户端[%d.%d.%d.%d:%u]连接处理线程启动！"), FIRST_IPADDRESS(ulIP), SECOND_IPADDRESS(ulIP), THIRD_IPADDRESS(ulIP), FOURTH_IPADDRESS(ulIP), usPort);

			ServerProcess.Run(socket, hStopEvent, hExitProcessEvent, ulIP, usPort);
		}
	}
	catch(...)
	{
		Trace(_T("TCPProcessThread"), MF_TRACE_LEVEL_FAILED, 10005002, _T("客户端[%d.%d.%d.%d:%u]连接处理线程出现未知异常，错误码：%d！"), FIRST_IPADDRESS(ulIP), SECOND_IPADDRESS(ulIP), THIRD_IPADDRESS(ulIP), FOURTH_IPADDRESS(ulIP), usPort, GetLastError());
	}

	InterlockedDecrement(&g_lConnectNum);
	Trace(_T("TCPProcessThread"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10005003, _T("客户端[%d.%d.%d.%d:%u]连接处理线程退出！"), FIRST_IPADDRESS(ulIP), SECOND_IPADDRESS(ulIP), THIRD_IPADDRESS(ulIP), FOURTH_IPADDRESS(ulIP), usPort);
#ifdef WIN32	
	CoUninitialize();
#endif
	
	dwThreadID = GetCurrentThreadId();
	RemoveThreadFromSet(dwThreadID);
#ifdef WIN32
	_endthread();
#else
	return NULL;
#endif
}

#ifdef WIN32
DWORD __stdcall TCPListenerThreadProc(LPVOID data)
#else
void* TCPListenerThreadProc(LPVOID data)
#endif
{
	//TCP监听处理线程	
	SOCKET mSocket = INVALID_SOCKET;
#ifdef WIN32
	DWORD dwThreadID;
	HANDLE hThread 				= INVALID_HANDLE_VALUE;
	HANDLE hStopEvent 			= INVALID_HANDLE_VALUE;
	HANDLE hProcessExitEvent 	= INVALID_HANDLE_VALUE;
#else
	pthread_t hThread;
	sem_t* hStopEvent;
	sem_t* hProcessExitEvent;
#endif
	TCP_THREAD_PRARM *lpParam = (TCP_THREAD_PRARM *)data;
	if(lpParam == NULL)
	{
		return 0;
	}
	mSocket				= lpParam->m_socket;
#ifdef WIN32
	hStopEvent			= lpParam->m_hStopEvent;
	hProcessExitEvent	= lpParam->m_hProcessExitEvent;
#else
	hStopEvent			= (sem_t*)lpParam->m_hStopEvent;
	hProcessExitEvent	= (sem_t*)lpParam->m_hProcessExitEvent;
#endif
	delete lpParam;

	try
	{
		//侦听
		for(;;)
		{
			try
			{
				ULONG ulIP;
				int addrLen;
				USHORT usPort;
				SOCKET socketClient;
				SOCKADDR_IN addrClient;
				addrLen = sizeof(SOCKADDR_IN);
			#ifdef WIN32
				socketClient = accept(mSocket, (LPSOCKADDR)&addrClient, &addrLen);
			#else
				socketClient = accept(mSocket, (LPSOCKADDR)&addrClient, (socklen_t*)&addrLen);
			#endif
				if(socketClient != INVALID_SOCKET)
				{
					if(WaitForSingleObject(hStopEvent, 0) == WAIT_OBJECT_0)
					{
						break;
					}

					ulIP = ntohl(addrClient.sin_addr.s_addr);
					usPort = ntohs(addrClient.sin_port);
					if(g_bWriteEfficiencyTrace)
					{
						Trace(_T("TCPListenerThreadProc"), MF_TRACE_LEVEL_INNER_DEBUG, 10006001, _T("收到客户端连接请求，正在开启接收线程，客户端IP地址：%d.%d.%d.%d，端口：%u"), FIRST_IPADDRESS(ulIP), SECOND_IPADDRESS(ulIP), THIRD_IPADDRESS(ulIP), FOURTH_IPADDRESS(ulIP), usPort);
					}

					//开启工作者线程处理客户端命令
					TCP_THREAD_PRARM *lpParam		= new TCP_THREAD_PRARM;
					lpParam->m_hStopEvent			= hStopEvent;
					lpParam->m_hProcessExitEvent	= hProcessExitEvent;
					lpParam->m_socket					= socketClient;
					lpParam->m_usPort					= usPort;
					lpParam->m_ulRemoteIP			= ulIP;
				#ifdef WIN32
					hThread 		= (HANDLE)_beginthread(TCPProcessThread, 0, (void *)lpParam);
					SetThreadPriority(hThread, THREAD_PRIORITY_TIME_CRITICAL);
					dwThreadID 	= GetThreadId(hThread);
					g_mapProcessThead.insert(make_pair<DWORD, HANDLE>(dwThreadID, hThread));
				#else
					if(-1 == pthread_create(&hThread, NULL, TCPProcessThread, (void *)lpParam))
					{
						g_mapProcessThead.insert(make_pair<pthread_t, pthread_t>(0, hThread));
					}
					else
					{
						g_mapProcessThead.insert(make_pair<pthread_t, pthread_t>(hThread, hThread));
					}
				#endif
				}
				else
				{
					if(WaitForSingleObject(hStopEvent, 0) == WAIT_OBJECT_0)
					{
						break;
					}
				}
			}
			catch(...)
			{
				Trace(_T("TCPListenerThreadProc"), MF_TRACE_LEVEL_FAILED, 10006002, _T("TCP监听线程处理连入操作时出现异常错误，错误码：%d"), GetLastError());
			}
		}
	}
	catch(...)
	{
		Trace(_T("TCPListenerThreadProc"), MF_TRACE_LEVEL_FAILED, 10006003, _T("TCP监听线程出现异常错误，错误码：%d"), GetLastError());
	#ifdef WIN32
		TerminateProcess(GetCurrentProcess(), 0);
	#else
		exit(0);
	#endif
	}
	closesocket(mSocket);
	Trace0(_T("TCPListenerThreadProc"), MF_TRACE_LEVEL_IMPORTANT_INFORMATION, 10006004, _T("关闭TCP监听线程！"));
	return 0;
}

//创建TCP监听线程
#ifdef WIN32
int CreateTCPListenThread(HANDLE &hThreadHandle, LPVOID data)
#else
int CreateTCPListenThread(pthread_t &hThreadHandle, LPVOID data)
#endif
{
	int iRet = 0;
	SOCKET socketServer;
#ifdef WIN32
	CString strLog;
	DWORD dwThreadId;
#endif
	
	try
	{
		socketServer = socket(AF_INET,SOCK_STREAM,0);
		if(socketServer == INVALID_SOCKET)
		{
			Trace(_T("CreateTCPListenThread"), MF_TRACE_LEVEL_FAILED, 10007001, _T("索贝数据服务创建Socket失败，错误码：%d"), WSAGetLastError());
			return 1;
		}

		SOCKADDR_IN addrServer		= {0};
		addrServer.sin_port			= htons(GetSystemParameterValue(MF_TCP_LISTEN_PORT));
		addrServer.sin_family		= AF_INET;
		addrServer.sin_addr.s_addr  = htonl(GetSystemParameterValue(MF_TCP_LISTEN_IP));


		//绑定socket到地址
		iRet = bind(socketServer, (LPSOCKADDR)&addrServer, sizeof(addrServer));
		if(iRet == SOCKET_ERROR)
		{
			Sleep(10000);
			iRet = bind(socketServer, (LPSOCKADDR)&addrServer, sizeof(addrServer));
			if(iRet == SOCKET_ERROR)
			{
				Sleep(10000);
				iRet = bind(socketServer, (LPSOCKADDR)&addrServer, sizeof(addrServer));
				if(iRet == SOCKET_ERROR)
				{
					iRet = WSAGetLastError();
					closesocket(socketServer);
#ifdef WIN32
					strLog.Format(_T("索贝数据服务的TCP监听端口绑定失败！，请检查TCP端口(%d)是否被占用"), GetSystemParameterValue(MF_TCP_LISTEN_PORT));
					_Module.LogEvent(strLog);
#endif
					Trace(_T("CreateTCPListenThread"), MF_TRACE_LEVEL_FAILED, 10007002, _T("索贝数据服务绑定监听端口失败，错误码：%d"), iRet);
					return 2;
				}
			}
		}

		iRet = listen(socketServer, SOMAXCONN);
		if(iRet == SOCKET_ERROR)
		{
			iRet = WSAGetLastError();
			closesocket(socketServer);
			Trace(_T("CreateTCPListenThread"), MF_TRACE_LEVEL_FAILED, 10007003, _T("索贝数据服务启动TCP监听失败，错误码：%d"), iRet);
			return 3;
		}

		TCP_THREAD_PRARM *lpParam = new TCP_THREAD_PRARM();
		if(lpParam == NULL)
		{
			closesocket(socketServer);
			return 4;
		}
		lpParam->m_hStopEvent		 = ((TCP_THREAD_PRARM*)data)->m_hStopEvent;
		lpParam->m_hProcessExitEvent = ((TCP_THREAD_PRARM*)data)->m_hProcessExitEvent;
		lpParam->m_socket			 = socketServer;
		//开启TCP监听开始接收客户端连接
	#ifdef WIN32
		hThreadHandle = (HANDLE)CreateThread(NULL, 0, TCPListenerThreadProc, (void*)lpParam, 0, &dwThreadId);
		if (hThreadHandle == INVALID_HANDLE_VALUE)
		{
			closesocket(socketServer);
			delete lpParam;
			//线程创建失败
			Trace0(_T("CreateTCPListenThread"), MF_TRACE_LEVEL_FAILED, 10007004, _T("创建线程 TCPListenerThreadProc 失败"));
			return 5;
		}
	#else
		iRet = pthread_create(&hThreadHandle, NULL, TCPListenerThreadProc, (void*)lpParam);
		if (iRet != MF_OK)
		{
			closesocket(socketServer);
			delete lpParam;
			//线程创建失败
			Trace0(_T("CreateTCPListenThread"), MF_TRACE_LEVEL_FAILED, 10007004, _T("创建线程 TCPListenerThreadProc 失败"));
			return 5;
		}
	#endif
		return 0;
	}
	catch(...)
	{
		Trace(_T("CreateTCPListenThread"), MF_TRACE_LEVEL_FAILED, 10007003, _T("索贝数据服务启动TCP监听出现异常，错误码：%d"), GetLastError());
	}
	return 10;
}
