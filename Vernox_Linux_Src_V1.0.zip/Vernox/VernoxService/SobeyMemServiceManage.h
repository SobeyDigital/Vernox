﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
#include "../VernoxServiceLib/ServiceCommonDef.h"
class CSobeyMemServiceManage
{
protected:
	CContainerManage * m_pContainerManage;
	char m_arrayDatabasePath[MAX_PATH];
	char m_arrayConfigPath[MAX_PATH];
	LPBYTE m_pFileBuffer;
protected:
	BOOL InitPinYinTable();
	int StartTransactionLogic(DWORD dwIP, const char * lpszTransactionData, int &lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int StopTransactionLogic(DWORD dwIP, int lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int WriteTraceLog(LPCTSTR szFuncationName, LONG lLogLevel, LONG lLogErrorCode, LPEXECUTEPLANBSON lpExecutePlan, LPEXECUTESTATISTICSINFO lpExecuteInfo, int nRet);
	int SetExecuteStatistics(LPEXECUTEPLANBSON lpExecutePlan, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	void ConvertExecuteStatistics(char *lpszStatistics,const EXECUTESTATISTICSINFO &stExecuteInfo);
	int GetRecordNum(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, int& nRecordNum, LPEXECUTESTATISTICSINFO lpExecuteInfo);

public:
	void ResourceAndLockRelease(LPEXECUTEPLANBSON lpExecutePlan, int nRetValue);
	int GetRecordset(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int UpdateRecordset(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int ExecuteCommand(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	CSobeyMemServiceManage(void);
	virtual ~CSobeyMemServiceManage(void);

public:
	int Initialize();
	int Uninitialize();
	
	//导入、导出	
	int	ExportObject(CServiceBson& stBson, char* pObjectName, LPEXPORTPARAM lpExportParam, long long nTimestamp);
	int	ImportObject(CServiceBson& stBson, char* pObjectName, LPIMPORTPARAM lpImportParam, long long nTimestamp);
	
	int GetDatabaseGuid(USHORT& usGuid);
	int GetObjectDataNum(char* pObjectName, int& nDataNum);
	int	RecoverByRedo();
	//属于TCP的函数入口系列
	int TCPExecuteCommand(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int TCPGetRecordset(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, LPBYTE &lpBsonRs, int &nBsonRsSize, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int TCPUpdateRecordset(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int TCPStartTransactionLogic(DWORD dwIP, char * lpszTransactionData, int &lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int TCPStopTransactionLogic(DWORD dwIP, int lTransactionID, LPEXECUTESTATISTICSINFO lpExecuteInfo);

	int TCPGetExecutePlan(CServiceBson &stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTEPLANINFO lpExecutePlanInfo, LPEXECUTESTATISTICSINFO lpExecuteInfo);

	void SetSessionInfo(LPSESSIONINFO lpSessionInfo, BOOL bSaop);
	void RemoveSessionInfo(LPSESSIONINFO &lpSessionInfo, BOOL bSaop);
	void SetExecuteStatistics(CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
public:
	int SystemRecover(CServiceBson& stBson, int &lAffectCount, LPEXECUTESTATISTICSINFO lpExecuteInfo);
	int Preprocess(CServiceBson& stBson, CExecutePlanManager& stExecutePlanManager, LPEXECUTESTATISTICSINFO lpExecuteInfo);
public:
	int GetUserInfo(char* pUserName, LPUSERINFODEF& lpUserInfo);
};
