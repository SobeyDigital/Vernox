﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#ifdef WIN32
	#ifdef _M_X64
		#ifdef DEBUG
			#pragma comment(lib, "..\\LibX64\\VernoxServiceLibD.lib")
		#else
			#pragma comment(lib, "..\\LibX64\\VernoxServiceLib.lib")
		#endif
	#else
		#ifdef DEBUG
			#pragma comment(lib, "..\\Lib\\VernoxServiceLibD.lib")
		#else
			#pragma comment(lib, "..\\Lib\\VernoxServiceLib.lib")
		#endif
	#endif
	#include "SobeyMemBaseExport.h"
	#include "..\VernoxServiceLib\CommonAPI.h"
	#include "..\VernoxServiceLib\ContainerManage.h"
#else
	#include "SobeyMemBaseExport.h"
	#include "../VernoxServiceLib/CommonAPI.h"
	#include "../VernoxServiceLib/ContainerManage.h"
#endif