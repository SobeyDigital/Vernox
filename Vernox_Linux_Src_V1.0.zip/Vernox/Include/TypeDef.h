/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#pragma once

#ifdef WIN32
#define sleep(x) Sleep(1000*x)
#define usleep(x) Sleep(x/1000)

typedef int							key_t;
typedef HANDLE						MFID;
typedef HANDLE						EVENTTYPE;
typedef HANDLE						THREADTYPE;
typedef HANDLE						FILETYPE;

#else
#include "auto_tchar.h"
#include <semaphore.h>

typedef long long 					__int64;
typedef int							MFID;
typedef sem_t*						EVENTTYPE;
typedef pthread_t					THREADTYPE;
typedef FILE*						FILETYPE;

typedef const char					*LPCSTR;
typedef char							*LPSTR;
typedef unsigned char       		BYTE, *LPBYTE;

typedef int 							LONG;
typedef unsigned int 				ULONG;
typedef long long		    			LONGLONG;
typedef unsigned long long			ULONGLONG;

typedef unsigned short      		WORD;
typedef unsigned int       			DWORD, *LPDWORD;

typedef unsigned int        		UINT;
typedef double 						DATE;
typedef unsigned short 				USHORT;
typedef int       					BOOL;
typedef void						*HANDLE;
typedef void						*LPVOID;
typedef int							LONG_PTR;
typedef int 						HRESULT;
typedef unsigned int		   		UINT_PTR;
typedef unsigned int		   		UINT_PTR;
typedef short						SHORT;

typedef int							SOCKET;
typedef wchar_t 					WCHAR;

#define INT_MAX       				2147483647
#define INT_MIN						(-2147483647 - 1)

#define MAXLONGLONG                 (0x7fffffffffffffff)

#define MAX_PATH          			260
#define S_OK						((HRESULT) 0)
#define S_FALSE						((HRESULT) 1)
#define E_FAIL						(0x80004005)

#define WAIT_OBJECT_0 				0

#define INVALID_SOCKET				~0
#define SOCKET_ERROR				-1

#define SUCCEEDED(hr)				(((HRESULT)(hr)) >= 0)
#define FAILED(hr)					(((HRESULT)(hr)) < 0)

#define FIRST_IPADDRESS(x)			(((x) >> 24) & 0xff)
#define SECOND_IPADDRESS(x)			(((x) >> 16) & 0xff)
#define THIRD_IPADDRESS(x)			(((x) >> 8) & 0xff)
#define FOURTH_IPADDRESS(x)			((x) & 0xff)

#define Sleep(u)					usleep(u*1000)
	
#define _atoi64(str)				atoll(str)

#define _MAX_PATH					260

#ifndef _I64_MAX
#define _I64_MAX					9223372036854775807
#endif

#undef FALSE
#undef TRUE
#undef NULL

#define FALSE						0
#define TRUE 						1
#define NULL						0
#define INFINITE            	0xFFFFFFFF
#define ASSERT						assert

#ifndef INVALID_HANDLE_VALUE
#define INVALID_HANDLE_VALUE		((HANDLE)(LONG_PTR)-1)
#endif

#define SOCKADDR_IN					sockaddr_in
#define LPSOCKADDR               sockaddr*
#define SOCKADDR						sockaddr
#define IN_ADDR						in_addr
#define closesocket					close
#define WSAETIMEDOUT					ETIMEDOUT
#define WSAECONNRESET				ECONNRESET

typedef int							SECURITY_DESCRIPTOR, *PISECURITY_DESCRIPTOR;
typedef pthread_mutex_t			CRITICAL_SECTION, *LPCRITICAL_SECTION;

typedef struct _FILETIME
{
    DWORD dwLowDateTime;
    DWORD dwHighDateTime;
} FILETIME, *PFILETIME, *LPFILETIME;

typedef struct _SYSTEMTIME 
{
	WORD wYear;
	WORD wMonth;
	WORD wDayOfWeek;
	WORD wDay;
	WORD wHour;
	WORD wMinute;
	WORD wSecond;
	WORD wMilliseconds;
} SYSTEMTIME, *PSYSTEMTIME, *LPSYSTEMTIME;

typedef union _LARGE_INTEGER
{
   struct
	{
        DWORD LowPart;
        LONG HighPart;
    };
   struct
	{
        DWORD LowPart;
        LONG HighPart;
   }u;
   LONGLONG QuadPart;
} LARGE_INTEGER;

typedef struct _SECURITY_ATTRIBUTES {
	DWORD nLength;
	LPVOID lpSecurityDescriptor;
	BOOL bInheritHandle;
} SECURITY_ATTRIBUTES, *PSECURITY_ATTRIBUTES, *LPSECURITY_ATTRIBUTES;


typedef union _ULARGE_INTEGER {
    struct {
        DWORD LowPart;
        DWORD HighPart;
    };
    struct {
        DWORD LowPart;
        DWORD HighPart;
    } u;
    ULONGLONG QuadPart;
} ULARGE_INTEGER,*PULARGE_INTEGER;

#define stricmp strcasecmp

#endif


