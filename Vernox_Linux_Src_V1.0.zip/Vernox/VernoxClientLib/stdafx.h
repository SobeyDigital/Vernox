﻿// stdafx.h : 标准系统包含文件的包含文件，
// 或是经常使用但不常更改的
// 特定于项目的包含文件
//

#pragma once

//屏蔽C语言警告信息
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_NONSTDC_NO_DEPRECATE 

#include "targetver.h"
#ifdef WIN32
#include <windows.h>
#include <process.h>
#include <tchar.h>
#include <io.h>

#else
#include <pthread.h>
#include <semaphore.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <uuid/uuid.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#endif

#include <list>
using namespace std;
#include "../Include/SobeyMemBaseExport.h"

#define WIN32_LEAN_AND_MEAN             // 从 Windows 头中排除极少使用的资料



// TODO: 在此处引用程序需要的其他头文件
extern void Trace0(LPCTSTR szFuncationName, LONG  lLogLevel, LONG lLogErrorCode, LPCTSTR szLog);
extern void Trace(LPCTSTR szFuncationName, LONG  lLogLevel, LONG lLogErrorCode, const char *fmt, ... );
extern void ExitTraceSystem();
extern void InitTraceSystem();

#ifdef WIN32
extern int MyExceptionHandler(ULONG ulCode, EXCEPTION_POINTERS* lpExceptionPointer);
#endif


