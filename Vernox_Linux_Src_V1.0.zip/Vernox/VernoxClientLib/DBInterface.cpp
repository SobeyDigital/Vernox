﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "DBInterface.h"
#include "../VernoxBaseLib/LinuxCommonAPI.h"

#ifdef WIN32
HINSTANCE g_hVernoxInstance = NULL;
#endif

CDBInterface::CDBInterface()
{
	m_bOpenFlag			  = FALSE;
	m_nNodeNum			  = 0;
	m_lWriteEfficiencyLog = 0;
	m_uServiceTCPIP		  = inet_addr("127.0.0.1");
	m_uServiceTCPPort	  = htons(8000);
	m_skSocket			  = INVALID_SOCKET;
	m_bRandomFactor		  = 0;

	m_ulHostIP = INADDR_NONE;
	m_usHostPort = 0;
	
	memset(m_pUserName, 0, 24);
	memset(m_pPassword, 0, 24);
	memset(m_lpConnectInfo, 0, 10*sizeof(CONNECTINFO));
#ifdef WIN32
	::InitializeCriticalSection(&m_csInterFace); 

	WORD		wVersionRequested;   
	WSADATA		wsaData;
	wVersionRequested = MAKEWORD(2, 0);
	WSAStartup(wVersionRequested, &wsaData);
#else
	InitializeCriticalSection(&m_csInterFace);
#endif
}

CDBInterface::~CDBInterface()
{
	Close();
#ifdef WIN32
	::DeleteCriticalSection(&m_csInterFace);
	WSACleanup();
#else
    DeleteCriticalSection(&m_csInterFace);
#endif	
}

#define CONNECT_THRESHOLD  5

#ifdef WIN32
BYTE CDBInterface::CreateRandomFactor()
{
	GUID guid;
	LPBYTE lpBuf;
	lpBuf = (LPBYTE)&guid;
	while(TRUE)
	{
		::CoCreateGuid(&guid);
		//去掉两次相同的随机因子
		if(lpBuf[0] != m_bRandomFactor && lpBuf[0] != 0)
		{
			break;
		}
	}
	m_bRandomFactor = lpBuf[0];
	return m_bRandomFactor;
}
#else
BYTE CDBInterface::CreateRandomFactor()
{
	uuid_t guid;
	LPBYTE lpBuf;
	lpBuf = (LPBYTE)&guid;
	while(TRUE)
	{
		 uuid_generate(guid);
		//去掉两次相同的随机因子
		if(lpBuf[0] != m_bRandomFactor && lpBuf[0] != 0)
		{
			break;
		}
	}
	m_bRandomFactor = lpBuf[0];
	return m_bRandomFactor;
}
#endif

BOOL CDBInterface::ConvertStr(char* pSrc, WCHAR* pDest, int nLen)
{
	int nSrc;
	nSrc = strlen(pSrc);
	if(nSrc == 0)
	{
		return TRUE;
	}
#ifdef WIN32
	if(!MultiByteToWideChar(CP_UTF8, NULL, pSrc, nSrc, pDest, nLen))
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
#else
	if(-1 == mbstowcs(pDest, pSrc, nLen))
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
#endif
}

int CDBInterface::OpenDatabase(BOOL bRetry)
{
	int nRet;
	nRet = ConnectToService(bRetry);
	if (nRet != MF_OK)
	{
		return nRet;
	}
	nRet = UserLogin();
	if (nRet != MF_OK)
	{
		return nRet;
	}
	m_bOpenFlag = TRUE;
	return MF_OK;
}

int CDBInterface::ConnectToService(BOOL bRetry)
{
	return Connect(bRetry);
}

int CDBInterface::UserLogin()
{
	BYTE bToken;
	char lpFilePath[MAX_PATH];
	MF_CLIENTINFO *lpClientInfo;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	int i, nRet, nSize, nSocketError, nIndex;

	bToken = CreateRandomFactor();
	nSize = sizeof(MF_SERVICE_TCP_COMMAND);
	memset(&stTcpCmd, 0, nSize);

	//发送客户端信息及用户登录信息
	stTcpCmd.m_bVersion		= 1;
	stTcpCmd.m_bToken		= bToken;
	stTcpCmd.m_bType		= MF_INTERFACE_COMMAND_USERLOGIN;
	stTcpCmd.m_lDataLength	= 0;
	stTcpCmd.m_lDigitalData	= 0;
	lpClientInfo = (MF_CLIENTINFO*)stTcpCmd.m_lpszParam;

	lpClientInfo->m_bCmdType     = 1;
	GetModuleFileName(NULL, lpFilePath, 256);
	nIndex = (int)strlen(lpFilePath) - 1;
	for(;nIndex > 0;nIndex--)
	{
		if(lpFilePath[nIndex] == _T('\\') || lpFilePath[nIndex] == _T('/'))
		{
			memcpy(lpClientInfo->m_lpszProgramName, lpFilePath + nIndex + 1, 23);
			break;
		}
	}
	lpClientInfo->m_dwProcessID = GetCurrentProcessId();
	lpClientInfo->m_dwThreadID  = GetCurrentThreadId();
	lpClientInfo->m_ullUserData = 0;
	lpClientInfo->m_dwUserData  = 0;
	GetSocketInfo(lpClientInfo->m_ulIP, lpClientInfo->m_usPort);

	memcpy(lpClientInfo->m_pUserName, m_pUserName, 23);
	memcpy(lpClientInfo->m_pPassword, m_pPassword, 23);
	nRet = send(m_skSocket, (char *)&stTcpCmd , nSize, 0);
	if(nRet  != nSize)
	{
		nSocketError = WSAGetLastError();
		Trace(_T("UserLogin"), 0, 888002001, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, nSocketError);
		return MF_INTERFACE_SENDDATA_FAILED;
	}
	//接收服务端返回数据
	i = 0;
	while(TRUE)
	{
		memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
		nRet = recv(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
		if(nRet == 0)
		{
			//连接被关闭了
			nSocketError = WSAGetLastError();
			Trace(_T("UserLogin"), 0, 888002002, _T("接收服务端数据时出现连接被关闭的错误，返回值：%d，错误码：%d"), nRet, nSocketError);
			return MF_INTERFACE_RECEIVEDATA_FAILED;
		}
		else if (nRet == SOCKET_ERROR)
		{
			//收到Socket错误
			nSocketError = WSAGetLastError();
			Trace(_T("UserLogin"), 0, 888002003, _T("接收服务端数据时出现Socket错误，返回值：%d，错误码：%d"), nRet, nSocketError);
			if(nSocketError == WSAETIMEDOUT)
			{
				return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
			}
			else if(WSAECONNRESET == nSocketError)
			{
				return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
			}
			return MF_INTERFACE_RECEIVEDATA_FAILED;
		}
		else if(nRet == sizeof(MF_SERVICE_TCP_COMMAND))
		{
			//判断返回的是否正确数据
			if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_TEST)
			{
				continue;
			}
			else if(stTcpCmd.m_bToken != bToken)
			{
				i++;
				if(i < 5)
				{
					if(stTcpCmd.m_lDataLength == 0)
					{
						continue;
					}
					else
					{
						char* lpBuffer;
						lpBuffer = new char[stTcpCmd.m_lDataLength];
						if(lpBuffer != NULL)
						{
							ReceiveBuffer(lpBuffer, stTcpCmd.m_lDataLength);
							delete [] lpBuffer;
							continue;
						}
						else
						{
							//已经没办法自动恢复了
							ClearSocket();
							break;
						}
					}
				}
				else
				{
					break;
				}
			}
			else
			{
				break;
			}
		}
		else
		{
			nSocketError = WSAGetLastError();
			Trace(_T("UserLogin"), 0, 888002004, _T("接收服务端数据时返回值不是所期望的，有可能是服务端等待超时，客户端自动清理TCP缓存数据，返回值：%d，错误码：%d"), nRet, nSocketError);
			if(nSocketError == WSAETIMEDOUT)
			{
				return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
			}
			else if(WSAECONNRESET == nRet)
			{
				return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
			}
			return MF_INTERFACE_RECEIVEDATA_DATAERROR;
		}
	}

	//判断返回数据
	if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_FAIL)
	{
		//为失败结果处理
		Trace(_T("UserLogin"), 0, 888002005, _T("用户登录失败，用户名%s"), m_pUserName);
		return stTcpCmd.m_lDigitalData;
	}
	else if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_OK)
	{
		return S_OK;
	}
	else
	{
		//错误的返回值
		ClearSocket();
		Trace(_T("UserLogin"), 0, 888002006, _T("服务端返回的命令类型不正确，客户端自动清理TCP缓存数据，收到的命令类型：%d"), stTcpCmd.m_bType);
		return MF_INTERFACE_RECEIVEDATA_DATAERROR;
	}
	return MF_FAILED;
}

//根据线程ID获取一个可用的套接字
int CDBInterface::Connect(BOOL bRetry)
{
	string strIP;
	int i, nRet, nBufferSize, nNetTimeout, nLastError;
	//服务器地址结构，目前在SDK中定义为本机
	SOCKADDR_IN sa;
	memset(&sa, 0, sizeof(sa));
	sa.sin_family		=AF_INET;
	sa.sin_port			=m_uServiceTCPPort;
	sa.sin_addr.s_addr	=m_uServiceTCPIP;

	//创建套接字
	m_skSocket = socket(AF_INET,SOCK_STREAM, 0);
	if(m_skSocket == INVALID_SOCKET)
	{
#ifdef WIN32
		if(WSANOTINITIALISED == WSAGetLastError())
		{
			WORD		wVersionRequested;   
			WSADATA		wsaData;
			wVersionRequested = MAKEWORD(2, 0);
			WSAStartup(wVersionRequested, &wsaData);
			m_skSocket = socket(AF_INET,SOCK_STREAM, 0);
			if(m_skSocket == INVALID_SOCKET)
			{
				Trace(_T("Connect"), 0, 888003001, _T("创建socket连接失败，错误码：%d"), WSAGetLastError());
				return MF_INTERFACE_SOCKET_CREATE_FAILED;
			}
		}
#else
		Trace(_T("Connect"), 0, 888003001, _T("创建socket连接失败，错误码：%d"), GetLastError());
		return MF_INTERFACE_SOCKET_CREATE_FAILED;
#endif
	}

	// 连接指定服务器
	nRet = connect(m_skSocket,(const sockaddr*)&sa,sizeof(sa));
	if(nRet == SOCKET_ERROR)
	{
		if(!bRetry)
		{
			char lpszBuffer[256];
#ifdef WIN32
			nLastError = WSAGetLastError();
			sprintf_s(lpszBuffer, 256, "%d.%d.%d.%d", FIRST_IPADDRESS(m_uServiceTCPIP),SECOND_IPADDRESS(m_uServiceTCPIP), THIRD_IPADDRESS(m_uServiceTCPIP), FOURTH_IPADDRESS(m_uServiceTCPIP));
#else
			nLastError = GetLastError();
			sprintf(lpszBuffer, "%d.%d.%d.%d", FIRST_IPADDRESS(m_uServiceTCPIP),SECOND_IPADDRESS(m_uServiceTCPIP), THIRD_IPADDRESS(m_uServiceTCPIP), FOURTH_IPADDRESS(m_uServiceTCPIP));
#endif
			strIP = lpszBuffer;
			Trace(_T("Connect"), 0, 888003002, _T("连接服务器失败，错误码：%d，服务器IP：%s，端口：%d"), nLastError, strIP.c_str(), m_uServiceTCPPort);
			return MF_INTERFACE_SOCKET_CONNECT_FAILED;
		}

		//重试连接，可能是网络原因
		i = 0;
		while(TRUE)
		{
			Sleep(100);
			nRet = connect(m_skSocket,(const sockaddr*)&sa,sizeof(sa));
			if(nRet == SOCKET_ERROR)
			{
				i++;
				if(i > 3)
				{
					char lpszBuffer[256];
#ifdef WIN32
					nLastError = WSAGetLastError();
					sprintf_s(lpszBuffer, 256, "%d.%d.%d.%d", FIRST_IPADDRESS(m_uServiceTCPIP),SECOND_IPADDRESS(m_uServiceTCPIP), THIRD_IPADDRESS(m_uServiceTCPIP), FOURTH_IPADDRESS(m_uServiceTCPIP));
#else
					nLastError = GetLastError();
					sprintf(lpszBuffer, "%d.%d.%d.%d", FIRST_IPADDRESS(m_uServiceTCPIP),SECOND_IPADDRESS(m_uServiceTCPIP), THIRD_IPADDRESS(m_uServiceTCPIP), FOURTH_IPADDRESS(m_uServiceTCPIP));
#endif
					strIP = lpszBuffer;
					Trace(_T("Connect"), 0, 888003003, _T("连接服务器失败，错误码：%d，服务器IP：%s，端口：%d"), nLastError, strIP.c_str(), m_uServiceTCPPort);
					return MF_INTERFACE_SOCKET_CONNECT_FAILED;
				}
			}
			else
			{
				break;
			}
		}
	}

	//按照经验，发送Buffer设置为1M，接收Buffer设置为32K可以得到最佳效果
#ifdef WIN32
	nBufferSize = 1024*1024;
	setsockopt(m_skSocket, SOL_SOCKET, SO_SNDBUF,(const char FAR *)&nBufferSize, sizeof(nBufferSize));
	nBufferSize = 32*1024;
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVBUF,(const char FAR *)&nBufferSize, sizeof(nBufferSize));
#else
	nBufferSize = 1024*1024;
	setsockopt(m_skSocket, SOL_SOCKET, SO_SNDBUF,&nBufferSize, sizeof(nBufferSize));
	nBufferSize = 32*1024;
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVBUF,&nBufferSize, sizeof(nBufferSize));
#endif
	//屏蔽TCP的Nagle算法，可以提高TCP的响应速度，默认下是关闭的
	const char chOpt=1;
	setsockopt(m_skSocket, IPPROTO_TCP, TCP_NODELAY, &chOpt, sizeof(char));

	//设置接收超时
#ifdef WIN32
	nNetTimeout = INT_MAX;//30秒，
	setsockopt(m_skSocket, SOL_SOCKET, SO_SNDTIMEO, (char *)&nNetTimeout, sizeof(int));
	nNetTimeout = INT_MAX;//180秒，
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&nNetTimeout, sizeof(int));
#else
	struct timeval timeout;
	timeout.tv_sec = INT_MAX;
	timeout.tv_usec = 0;
	setsockopt(m_skSocket, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout, sizeof(struct timeval));
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(struct timeval));
#endif
	return MF_OK;
}

void CDBInterface::ClearSocket()
{
#ifdef WIN32
	long nRet;
	//这块耗时大约在500毫秒左右
	int nReceiveTimeOut = 1;
	char lpTempBuffer[1024];
	//清空接收队列的所有数据，首先修改超时时间，然后无限次的接收，直到接收完以后才返回
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&nReceiveTimeOut, sizeof(int));
	while(TRUE)
	{
		nRet = recv(m_skSocket, lpTempBuffer, 1024, 0);
		if(nRet == -1)
		{
			break;
		}
	}
	nReceiveTimeOut = INT_MAX;//180秒，
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&nReceiveTimeOut, sizeof(int));
#else
	long nRet;
	//这块耗时大约在500毫秒左右
	struct timeval timeout;
	char lpTempBuffer[1024];
	//清空接收队列的所有数据，首先修改超时时间，然后无限次的接收，直到接收完以后才返回
	timeout.tv_sec = 0;
	timeout.tv_usec = 1;
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(struct timeval));
	while(TRUE)
	{
		nRet = recv(m_skSocket, lpTempBuffer, 1024, 0);
		if(nRet == -1)
		{
			break;
		}
	}
	timeout.tv_sec = INT_MAX;
	timeout.tv_usec = 0;
	setsockopt(m_skSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(struct timeval));
#endif
}

void CDBInterface::GetSocketInfo(ULONG &ulIP, USHORT &usPort)
{
	int i, nLen;
	ULONG uLocalIP;
	sockaddr_in sIn;
#ifdef WIN32
	int nSkLen;
#else
	socklen_t nSkLen;
#endif
	
	nLen	 = sizeof(sockaddr_in);
	uLocalIP = ntohl(inet_addr("127.0.0.1"));
	memset(&sIn, 0, nLen);
	getsockname(m_skSocket, (sockaddr*)&sIn, &nSkLen);
	usPort	= ntohs(sIn.sin_port);
	ulIP	= ntohl(sIn.sin_addr.s_addr);
	if(ulIP == uLocalIP)
	{
		hostent *phostent;
		char szHostName[256];
		memset(szHostName, 0, 256);
		if(gethostname(szHostName, 256) == SOCKET_ERROR)
		{
			return ;
		}

		phostent = gethostbyname(szHostName);
		if(phostent == NULL)
		{
			return ;
		}
		for(i = 0; phostent != NULL && phostent->h_addr_list[i] != NULL; i++)
		{
			memcpy(&ulIP, phostent->h_addr_list[i], 4);
			ulIP = ntohl(ulIP);
			if(ulIP != uLocalIP)
			{
				break;
			}
		}
	}
}

//接收Socket的数据，主要用于大数据量的接收
BOOL CDBInterface::ReceiveBuffer(char *pBuffer, int nSize)
{
	string strErrorDesc;
	int nLeft, nCount, nRet;
	char *pBuf, lpszBuffer[256];

	//由于可能一次收不完，所以循环接收，直到收够指定的数据量后才停止
	nCount	= 0;
	pBuf	= pBuffer;
	nLeft	= nSize;
	memset(lpszBuffer,0, 256);
	memset(pBuffer, 0, nSize);
	while (nLeft > 0)
	{
		nRet = recv(m_skSocket, pBuf, nLeft, 0);
		if(nRet == 0)
		{
			//连接被关闭了
			strErrorDesc = "连接被关闭了，返回值为0";
			break;
		}
		else if (nRet == SOCKET_ERROR)
		{
			//失败了，需要处理一些情况
			nRet = WSAGetLastError();
			if(nRet == WSAETIMEDOUT) //超时情况，我们需要再等待一下
			{
				nCount++;
				if(nCount > 10)
				{
					strErrorDesc = "重试了10次都出现接收超时";
					break;
				}
				Sleep(1);
			}
			else if(nRet == WSAECONNRESET) //连接已经断开了
			{
				strErrorDesc = "连接被关闭了，返回值为-1";
				break;
			}
			else //其他情况，可以在重试一下
			{
				nCount++;
				if(nCount > 10)
				{
					sprintf(lpszBuffer, "重试了10次都出现接收错误，返回值为-1，但是WSAGetLastError的返回值为：0x%x", nRet);
					strErrorDesc = lpszBuffer;
					break;
				}
				Sleep(1);
			}
		}
		else
		{
			nCount = 0;
			nLeft -= nRet;
			pBuf += nRet;
		}
	}

	if(nLeft != 0)
	{
		Trace(_T("ReceiveBuffer"), 0, 888010099, _T("接收发送消息体数据长度不正确！消息头描述长度：%d，剩下：%d未收到！错误描述：%s"), nSize, nLeft, strErrorDesc.c_str());
		return FALSE;
	}
	return TRUE;
}

int CDBInterface::GetStatisticsData(MF_EXECUTE_STATISTICS* pStatisticsInfo, char * lpszParam)
{
	MF_EXECUTESTATISTICSINFO stServerStatistics;
	memcpy(&stServerStatistics, lpszParam, sizeof(stServerStatistics));
	memcpy(&pStatisticsInfo->m_ftServerStartTime, &stServerStatistics.m_ftStartTime, sizeof(stServerStatistics.m_ftStartTime));
	memcpy(&pStatisticsInfo->m_ftServerEndTime, &stServerStatistics.m_ftEndTime, sizeof(stServerStatistics.m_ftEndTime));
	pStatisticsInfo->m_llServerFrequence		= stServerStatistics.m_liFrequence.QuadPart;
	pStatisticsInfo->m_llServerStart			= stServerStatistics.m_liStart.QuadPart;
	pStatisticsInfo->m_llServerParsePlanStart	= stServerStatistics.m_liParsePlanStart.QuadPart;
	pStatisticsInfo->m_llServerPretreatmentStart	= stServerStatistics.m_liPretreatmentStart.QuadPart;
	pStatisticsInfo->m_llServerExecuteStart		= stServerStatistics.m_liExecuteStart.QuadPart;
	pStatisticsInfo->m_llServerIndexSearchEnd	= stServerStatistics.m_liIndexSearchEnd.QuadPart;
	pStatisticsInfo->m_llServerExecuteEnd		= stServerStatistics.m_liExecuteEnd.QuadPart;
	pStatisticsInfo->m_llServerWriteLogEnd		= stServerStatistics.m_liWriteLogEnd.QuadPart;
	pStatisticsInfo->m_llServerEnd				= stServerStatistics.m_liEnd.QuadPart;
	pStatisticsInfo->m_ulServerWorkLoad			= stServerStatistics.m_lWorkLoad;
	return S_OK;
}

int CDBInterface::ConvertStatisticsData(MF_EXECUTE_STATISTICS* pStatisticsInfo, LPCTSTR lpszStatistics)
{
	MF_EXECUTESTATISTICSINFO stServerStatistics;
	memset(&stServerStatistics, 0, sizeof(stServerStatistics));
	CharConvertHex(lpszStatistics, (LPBYTE)&stServerStatistics, sizeof(stServerStatistics));
	memcpy(&pStatisticsInfo->m_ftServerStartTime, &stServerStatistics.m_ftStartTime, sizeof(stServerStatistics.m_ftStartTime));
	memcpy(&pStatisticsInfo->m_ftServerEndTime, &stServerStatistics.m_ftEndTime, sizeof(stServerStatistics.m_ftEndTime));
	pStatisticsInfo->m_llServerFrequence		= stServerStatistics.m_liFrequence.QuadPart;
	pStatisticsInfo->m_llServerStart			= stServerStatistics.m_liStart.QuadPart;
	pStatisticsInfo->m_llServerParsePlanStart	= stServerStatistics.m_liParsePlanStart.QuadPart;
	pStatisticsInfo->m_llServerPretreatmentStart	= stServerStatistics.m_liPretreatmentStart.QuadPart;
	pStatisticsInfo->m_llServerExecuteStart		= stServerStatistics.m_liExecuteStart.QuadPart;
	pStatisticsInfo->m_llServerIndexSearchEnd	= stServerStatistics.m_liIndexSearchEnd.QuadPart;
	pStatisticsInfo->m_llServerExecuteEnd		= stServerStatistics.m_liExecuteEnd.QuadPart;
	pStatisticsInfo->m_llServerWriteLogEnd		= stServerStatistics.m_liWriteLogEnd.QuadPart;
	pStatisticsInfo->m_llServerEnd				= stServerStatistics.m_liEnd.QuadPart;
	pStatisticsInfo->m_ulServerWorkLoad			= stServerStatistics.m_lWorkLoad;
	return S_OK;
}

int CDBInterface::TCPExecuteCommand(const char* lpszSql, int& nAffectCount, MF_EXECUTE_STATISTICS* pStatisticsInfo)
{
	BYTE bToken;
	char* pSendData;
	CBaseBson stBson;
	CParseSql stParseSql;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	LPEXECUTEPLANBSON lpExecutePlan;
	int nRet, nSize, nCount, nSocketError, nLen;

	nAffectCount	= 0;
	lpExecutePlan	= NULL;
	nRet = stParseSql.ParseSql(stBson, lpszSql, strlen(lpszSql), lpExecutePlan);
	if(nRet != MF_OK)
	{
		pStatisticsInfo->m_nRet = nRet;
		Trace(_T("TCPExecuteCommand"), 0, 888011000, _T("解析SQL语句[%s]失败，返回值：%d"), lpszSql, nRet);
		return nRet;
	}
	else
	{
		CCriticalSectionPtr cs(&m_csInterFace);

		nCount = 0;
TCPExecuteCommand_Retry:
		bToken = CreateRandomFactor();
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llParseEnd);
		nSize = sizeof(MF_SERVICE_TCP_COMMAND);
		memset(&stTcpCmd, 0, nSize);

		stTcpCmd.m_bVersion			= 1;
		stTcpCmd.m_bToken			= bToken;
		stTcpCmd.m_lDataLength		= lpExecutePlan->m_nTotalDataSize;
		stTcpCmd.m_bType			= MF_INTERFACE_TCPCOMMAND_EXECUTECOMMAND;
		pSendData					= (char *)lpExecutePlan;
		pSendData					= pSendData - nSize;
		nLen						= stTcpCmd.m_lDataLength + nSize;
		memcpy(pSendData, &stTcpCmd, nSize);
		nRet = send(m_skSocket, pSendData , nLen, 0);
		if(nRet  != nLen)
		{
			//尝试一下重新连接服务试试
			if(m_skSocket != INVALID_SOCKET)
			{
				closesocket(m_skSocket);
				m_skSocket = INVALID_SOCKET;
			}
			nRet = OpenDatabase(TRUE);
			if(nRet != MF_OK)
			{
				pStatisticsInfo->m_nRet = nRet;
				return nRet;
			}
			nRet = send(m_skSocket, (char *)pSendData, nLen, 0);
			if(nRet  != nLen)
			{
				Trace(_T("TCPExecuteCommand"), 0, 888011001, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				return MF_INTERFACE_SENDDATA_FAILED;
			}
		}

		//接收服务端返回数据
		while(TRUE)
		{
			memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
			nRet = recv(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
			if(nRet == 0)
			{
				//连接被关闭了
				Trace(_T("TCPExecuteCommand"), 0, 888011004, _T("接收服务端数据时出现连接被关闭的错误，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				return MF_INTERFACE_RECEIVEDATA_FAILED;
			}
			else if (nRet == SOCKET_ERROR)
			{
				//收到Socket错误
				nSocketError = WSAGetLastError();
				Trace(_T("TCPExecuteCommand"), 0, 888011005, _T("接收服务端数据时出现Socket错误，返回值：%d，错误码：%d"), nRet, nSocketError);
				if(nSocketError == WSAETIMEDOUT)
				{
					return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
				}
				else if(WSAECONNRESET == nSocketError)
				{
					return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
				}
				return MF_INTERFACE_RECEIVEDATA_FAILED;
			}
			else if(nRet == sizeof(MF_SERVICE_TCP_COMMAND))
			{
				//判断返回的是否正确数据
				if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_TEST)
				{
					continue;
				}
				else if(stTcpCmd.m_bToken != bToken)
				{
					nCount++;
					if(nCount > 3)
					{
						return MF_INTERFACE_RECEIVEDATA_TOKENERROR;
					}

					Sleep(1);
					ClearSocket();
					goto TCPExecuteCommand_Retry;
				}
				else
				{
					break;
				}
			}
			else
			{
				nSocketError = WSAGetLastError();
				Trace(_T("TCPExecuteCommand"), 0, 888011010, _T("接收服务端数据时返回值不是所期望的，有可能是服务端等待超时，客户端自动清理TCP缓存数据，返回值：%d，错误码：%d"), nRet, nSocketError);
				if(nSocketError == WSAETIMEDOUT)
				{
					return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
				}
				else if(WSAECONNRESET == nSocketError)
				{
					return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
				}
				return MF_INTERFACE_RECEIVEDATA_DATAERROR;
			}
		}

		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llReceiveEnd);
		//判断返回数据
		if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_FAIL)
		{
			//为失败结果处理
			pStatisticsInfo->m_nRet = stTcpCmd.m_lDigitalData;
			Trace(_T("TCPExecuteCommand"), 0, 888011011, _T("服务端返回执行失败，错误码：%d"), stTcpCmd.m_lDigitalData);
			return stTcpCmd.m_lDigitalData;
		}
		else if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_OK)
		{
			if(stTcpCmd.m_lDataLength == 0)
			{
				nAffectCount = stTcpCmd.m_lDigitalData;
				//获取执行效率数据
				GetStatisticsData(pStatisticsInfo, stTcpCmd.m_lpszParam);
				return MF_OK;
			}
			else
			{
				//数据肯定不正确，直接清理缓存
				ClearSocket();
				Trace(_T("TCPExecuteCommand"), 0, 888011012, _T("服务端返回的数据内容不正确，客户端自动清理TCP缓存数据，期望为0，但实际收到：%d"), stTcpCmd.m_lDataLength);
				return MF_INTERFACE_RECEIVEDATA_DATAERROR;
			}
		}
		else
		{
			//错误的返回值
			ClearSocket();
			Trace(_T("TCPExecuteCommand"), 0, 888011013, _T("服务端返回的命令类型不正确，客户端自动清理TCP缓存数据，收到的命令类型：%d"), stTcpCmd.m_bType);
			return MF_INTERFACE_RECEIVEDATA_DATAERROR;
		}
	}
	return MF_FAILED;
}

int CDBInterface::TCPGetRecordset(const char* lpszSql, CMemDBRecordset& stRs, MF_EXECUTE_STATISTICS* pStatisticsInfo)
{
	BYTE bToken;
	char* pSendData;
	CBaseBson stBson;
	CParseSql stParseSql;
	int nRet, nSize, nCount, nLen;
	LPEXECUTEPLANBSON lpExecutePlan;
	MF_SERVICE_TCP_COMMAND stTcpCmd;

	lpExecutePlan = NULL;
	nRet = stParseSql.ParseSql(stBson, lpszSql, strlen(lpszSql), lpExecutePlan);
	if(nRet != MF_OK)
	{
		pStatisticsInfo->m_nRet = nRet;
		Trace(_T("TCPGetRecordset"), 0, 888012000, _T("解析SQL语句[%s]失败，返回值：%d"), lpszSql, nRet);
		return nRet;
	}
	else
	{
		CCriticalSectionPtr cs(&m_csInterFace);
		nCount = 0;
TCPGetRecordset_Retry:
		bToken = CreateRandomFactor();
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llParseEnd);
		nSize = sizeof(MF_SERVICE_TCP_COMMAND);
		memset(&stTcpCmd, 0, nSize);
		stTcpCmd.m_bVersion			= 1;
		stTcpCmd.m_bToken			= bToken;
		stTcpCmd.m_lDataLength		= lpExecutePlan->m_nTotalDataSize;;
		stTcpCmd.m_bType			= MF_INTERFACE_TCPCOMMAND_GETRECORDSET;
		nLen						= stTcpCmd.m_lDataLength + nSize;
		pSendData					= (char *)lpExecutePlan;
		pSendData					= pSendData - nSize;
		memcpy(pSendData, &stTcpCmd, nSize);
		nRet = send(m_skSocket , pSendData, nLen, 0);
		if(nRet  != nLen)
		{
			//尝试一下重新连接服务试试
			if(m_skSocket != INVALID_SOCKET)
			{
				closesocket(m_skSocket);
				m_skSocket = INVALID_SOCKET;
			}
			nRet = OpenDatabase(TRUE);
			if(nRet != MF_OK)
			{
				pStatisticsInfo->m_nRet = nRet;
				return nRet;
			}
			nRet = send(m_skSocket , (char *)pSendData, nLen, 0);
			if(nRet  != nLen)
			{
				pStatisticsInfo->m_nRet = nRet;
				Trace(_T("TCPGetRecordset"), 0, 888012001, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				return MF_INTERFACE_SENDDATA_FAILED;
			}
		}

		//接收服务端返回数据
		while(TRUE)
		{
			memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
			nRet = recv(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
			if(nRet == 0)
			{
				//连接被关闭了
				pStatisticsInfo->m_nRet = WSAGetLastError();
				Trace(_T("TCPGetRecordset"), 0, 888012003, _T("接收服务端数据时出现连接被关闭的错误，返回值：%d，错误码：%d"), nRet, pStatisticsInfo->m_nRet);
				return MF_INTERFACE_RECEIVEDATA_FAILED;
			}
			else if (nRet == SOCKET_ERROR)
			{
				//收到Socket错误
				pStatisticsInfo->m_nRet = WSAGetLastError();
				Trace(_T("TCPGetRecordset"), 0, 888012005, _T("接收服务端数据时出现Socket错误，返回值：%d，错误码：%d"), nRet, pStatisticsInfo->m_nRet);
				if(pStatisticsInfo->m_nRet == WSAETIMEDOUT)
				{
					return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
				}
				else if(WSAECONNRESET == pStatisticsInfo->m_nRet)
				{
					return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
				}
				return MF_INTERFACE_RECEIVEDATA_FAILED;
			}
			else if(nRet == sizeof(MF_SERVICE_TCP_COMMAND))
			{
				//判断返回的是否正确数据
				if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_TEST)
				{
					continue;
				}
				else if(stTcpCmd.m_bToken != bToken)
				{
					nCount++;
					if(nCount > 3)
					{
						return MF_INTERFACE_RECEIVEDATA_TOKENERROR;
					}

					Sleep(1);
					ClearSocket();
					goto TCPGetRecordset_Retry;
				}
				else
				{
					break;
				}
			}
			else
			{
				pStatisticsInfo->m_nRet = WSAGetLastError();
				Trace(_T("TCPGetRecordset"), 0, 888012006, _T("接收服务端数据时返回值不是所期望的，有可能是服务端等待超时，客户端自动清理TCP缓存数据，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				if(pStatisticsInfo->m_nRet == WSAETIMEDOUT)
				{
					return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
				}
				else if(WSAECONNRESET == pStatisticsInfo->m_nRet)
				{
					return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
				}
				return MF_INTERFACE_RECEIVEDATA_DATAERROR;
			}
		}

		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llReceiveEnd);
		//判断返回数据
		if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_FAIL)
		{
			//为失败结果处理
			pStatisticsInfo->m_nRet = stTcpCmd.m_lDigitalData;
			Trace(_T("TCPGetRecordset"), 0, 888012010, _T("服务端返回执行失败，错误码：%d"), stTcpCmd.m_lDigitalData);
			return stTcpCmd.m_lDigitalData;
		}
		else if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_OK)
		{
			//获取执行效率数据
			GetStatisticsData(pStatisticsInfo, stTcpCmd.m_lpszParam);

			//为成功结果处理，还需要收后续数据
			if(stTcpCmd.m_lDataLength == 0)
			{
				Trace0(_T("TCPGetRecordset"), 0, 888012011, _T("服务端返回的数据内容不正确，期望不为0，但实际收到0"));
				return MF_INTERFACE_RECEIVEDATA_DATAERROR;
			}
			else
			{
				LPBYTE lpBuffer;
				EXECUTESTATISTICSINFO stExecuteInfo;
				memset(&stExecuteInfo, 0, sizeof(EXECUTESTATISTICSINFO));
				QueryPerformanceFrequency(&stExecuteInfo.m_liFrequence);
				QueryPerformanceCounter(&stExecuteInfo.m_liStart);
				lpBuffer = new BYTE[stTcpCmd.m_lDataLength];
				if(lpBuffer == NULL)
				{
					Trace(_T("TCPGetRecordset"), 0, 888012012, _T("分配接收BSON数据的内存失败，期望分配内存大小为：%d，错误码：%d"), stTcpCmd.m_lDataLength, GetLastError());
					ClearSocket();
					return MF_INNER_ALLOCMEM_FAILED;
				}
				if(!ReceiveBuffer((char *)lpBuffer, stTcpCmd.m_lDataLength))
				{
					delete [] lpBuffer;
					return MF_INTERFACE_RECEIVEDATA_FAILED;
				}
				//转换出一个Recorset出来
				nRet = stRs.AnalysisRecordset(lpBuffer, TRUE);
				if(nRet != MF_OK)
				{
					return nRet;
				}
				pStatisticsInfo->m_nEstimateNum = stTcpCmd.m_lDigitalData;
				return MF_OK;
			}
		}
		else
		{
			//错误的返回值
			ClearSocket();
			Trace(_T("TCPGetRecordset"), 0, 888012013, _T("服务端返回的命令类型不正确，客户端自动清理TCP缓存数据，收到的命令类型：%d"), stTcpCmd.m_bType);
			return MF_INTERFACE_RECEIVEDATA_DATAERROR;
		}
	}

	return MF_FAILED;
}

int CDBInterface::TCPUpdateRecordset(CMemDBRecordset& stRs, MF_EXECUTE_STATISTICS* pStatisticsInfo)
{
	BYTE bToken;
	char* pSendData;
	CBaseBson stBson;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	LPEXECUTEPLANBSON lpExecutePlan;
	int i, nRet, nSize, nSend, nCount, nSocketError;

	nSize = 1024*1024;			//分配1M的空间
TCPUpdateRecordset_ReAlloc:
	stBson.AllocBsonBuffer(nSize);
	nRet = stRs.ParseRecordset(stBson, lpExecutePlan);
	if(nRet != MF_OK)
	{
		if(nRet == MF_PARSECMD_EXECUTEPALN_LACKSPACE_ERROR)
		{
			//重新分配Buffe
			stBson.Free();
			if(nSize > 160 * 1024 * 1024)
			{
				return MF_INNER_MEMSIZE_ERROR;
			}
			else
			{
				nSize = 4*nSize;
				if(nSize > 320 * 1024 * 1024)
				{
					nSize = 320 * 1024 * 1024;
				}
				goto TCPUpdateRecordset_ReAlloc;
			}
		}
		else
		{
			pStatisticsInfo->m_nRet = nRet;
			Trace(_T("TCPUpdateRecordset"), 0, 888013000, _T("解析结果集失败，返回值：%d"), nRet);
			return nRet;
		}
	}
	else
	{
		LPUPDATERECORDSETPLANBSON lpUpdateRecordsetPlan;
		lpUpdateRecordsetPlan = (LPUPDATERECORDSETPLANBSON)stBson.ConvertOffset2Addr(lpExecutePlan->m_nCommandOffset);
		if(lpUpdateRecordsetPlan->m_nExecuteStepNum == 0)
		{
			//没有执行步骤，则不执行
			return MF_OK;
		}
		CCriticalSectionPtr cs(&m_csInterFace);
		nCount = 0;
TCPUpdateRecordset_Retry:
		bToken = CreateRandomFactor();
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llParseEnd);
		//发送命令到服务端
		nSize = sizeof(MF_SERVICE_TCP_COMMAND);
		memset(&stTcpCmd, 0, nSize);
		stTcpCmd.m_bVersion			= 1;
		stTcpCmd.m_lDataLength		= lpExecutePlan->m_nTotalDataSize;
		stTcpCmd.m_bToken			= bToken;
		stTcpCmd.m_bType			= MF_INTERFACE_TCPCOMMAND_UPDATERECORDSET;

		nRet = send(m_skSocket , (char *)&stTcpCmd , nSize, 0);
		if(nRet  != nSize)
		{
			//尝试一下重新连接服务试试
			if(m_skSocket != INVALID_SOCKET)
			{
				closesocket(m_skSocket);
				m_skSocket = INVALID_SOCKET;
			}
			nRet = OpenDatabase(TRUE);
			if(nRet != MF_OK)
			{
				pStatisticsInfo->m_nRet = nRet;
				return nRet;
			}
			nRet = send(m_skSocket , (char *)&stTcpCmd , nSize, 0);
			if(nRet  != nSize)
			{
				Trace(_T("TCPUpdateRecordset"), 0, 888013001, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				return MF_INTERFACE_SENDDATA_FAILED;
			}
		}

		nRet  = send(m_skSocket , (char *)lpExecutePlan, lpExecutePlan->m_nClientBsonDataSize, 0);
		if(nRet  !=  lpExecutePlan->m_nClientBsonDataSize)
		{
			Trace(_T("TCPUpdateRecordset"), 0, 888013002, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
			return MF_INTERFACE_SENDDATA_FAILED;
		}
		nSend = lpExecutePlan->m_nClientBsonDataSize;
		for(i = 0; i < stBson.GetBufferSectionNum(); i++)
		{
			pSendData = (char*)stBson.GetBufferSection(i+1);
			if(i == stBson.GetBufferSectionNum() - 1)
			{
				nSize = stBson.GetCurretDataSize();
			}
			else
			{
				nSize = lpExecutePlan->m_nDefaultSectionSize;
			}

			nRet = send(m_skSocket, pSendData, nSize, 0);
			if(nRet != nSize)
			{
				Trace(_T("TCPUpdateRecordset"), 0, 888013003, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				return MF_INTERFACE_SENDDATA_FAILED;
			}
			nSend += nSize;
		}
		if(nSend != stTcpCmd.m_lDataLength)
		{
			Trace(_T("TCPUpdateRecordset"), 0, 888013004, _T("发送数据的实际长度与规定长度不相等，实际值：%d，规定值：%d"), nSend, stTcpCmd.m_lDataLength);
			return MF_INTERFACE_SENDDATA_FAILED;
		}

		//接收服务端返回数据
		while(TRUE)
		{
			memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
			nRet = recv(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
			if(nRet == 0)
			{
				//连接被关闭了
				Trace(_T("TCPUpdateRecordset"), 0, 888013005, _T("接收服务端数据时出现连接被关闭的错误，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				return MF_INTERFACE_RECEIVEDATA_FAILED;
			}
			else if (nRet == SOCKET_ERROR)
			{
				//收到Socket错误
				nSocketError = WSAGetLastError();
				Trace(_T("TCPUpdateRecordset"), 0, 888013006, _T("接收服务端数据时出现Socket错误，返回值：%d，错误码：%d"), nRet, nSocketError);
				if(nSocketError == WSAETIMEDOUT)
				{
					return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
				}
				else if(WSAECONNRESET == nSocketError)
				{
					return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
				}
				return MF_INTERFACE_RECEIVEDATA_FAILED;
			}
			else if(nRet == sizeof(MF_SERVICE_TCP_COMMAND))
			{
				//判断返回的是否正确数据
				if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_TEST)
				{
					continue;
				}
				else if(stTcpCmd.m_bToken != bToken)
				{
					nCount++;
					if(nCount > 3)
					{
						return MF_INTERFACE_RECEIVEDATA_TOKENERROR;
					}

					Sleep(1);
					ClearSocket();
					goto TCPUpdateRecordset_Retry;
				}
				else
				{
					break;
				}
			}
			else
			{
				nSocketError = WSAGetLastError();
				Trace(_T("TCPUpdateRecordset"), 0, 888013007, _T("接收服务端数据时返回值不是所期望的，有可能是服务端等待超时，客户端自动清理TCP缓存数据，返回值：%d，错误码：%d"), nRet, nSocketError);
				if(nSocketError == WSAETIMEDOUT)
				{
					return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
				}
				else if(WSAECONNRESET == nSocketError)
				{
					return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
				}
				return MF_INTERFACE_RECEIVEDATA_DATAERROR;
			}
		}

		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llReceiveEnd);
		//判断返回数据
		if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_FAIL)
		{
			pStatisticsInfo->m_nRet = stTcpCmd.m_lDigitalData;
			//为失败结果处理
			Trace(_T("TCPUpdateRecordset"), 0, 888013010, _T("服务端返回执行失败，错误码：%d"), stTcpCmd.m_lDigitalData);
			return stTcpCmd.m_lDigitalData;
		}
		else if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_OK)
		{
			//为成功结果处理
			if(stTcpCmd.m_lDataLength == 0)
			{
				//获取执行效率数据
				GetStatisticsData(pStatisticsInfo, stTcpCmd.m_lpszParam);
				stRs.ClearState();
				return MF_OK;
			}
			else
			{
				//数据肯定不正确，直接清理缓存
				ClearSocket();
				Trace(_T("TCPUpdateRecordset"), 0, 888013011, _T("服务端返回的数据内容不正确，客户端自动清理TCP缓存数据，期望为0，但实际收到：%d"), stTcpCmd.m_lDataLength);
				return MF_INTERFACE_RECEIVEDATA_DATAERROR;
			}
		}
		else
		{
			//错误的返回值
			ClearSocket();
			Trace(_T("TCPUpdateRecordset"), 0, 888013012, _T("服务端返回的命令类型不正确，客户端自动清理TCP缓存数据，收到的命令类型：%d"), stTcpCmd.m_bType);
			return MF_INTERFACE_RECEIVEDATA_DATAERROR;
		}
	}

	return MF_FAILED;
}

int CDBInterface::TCPGetExecutePlanInfo(const char* lpszSql, LPEXECUTEPLANINFO lpExecutePlanInfo, MF_EXECUTE_STATISTICS* pStatisticsInfo)
{
	BYTE bToken;
	char* pSendData;
	CBaseBson stBson;
	CParseSql stParseSql;
	LPEXECUTEPLANBSON lpExecutePlan;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	int i, nRet, nSize, nCount, nSocketError;

	lpExecutePlan = NULL;
	nRet = stParseSql.ParseSql(stBson, lpszSql, strlen(lpszSql), lpExecutePlan);
	if(nRet != MF_OK)
	{
		pStatisticsInfo->m_nRet = nRet;
		Trace(_T("TCPGetExecutePlanInfo"), 0, 888014000, _T("解析SQL语句[%s]失败，返回值：%d"), lpszSql, nRet);
		return nRet;
	}
	else
	{
		CCriticalSectionPtr cs(&m_csInterFace);
		nCount = 0;
TCPGetExecutePlanInfo_Retry:
		bToken = CreateRandomFactor();
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llParseEnd);
		nSize = sizeof(MF_SERVICE_TCP_COMMAND);
		memset(&stTcpCmd, 0, nSize);
		stTcpCmd.m_bVersion			= 1;
		stTcpCmd.m_bToken			= bToken;
		stTcpCmd.m_lDataLength		= lpExecutePlan->m_nTotalDataSize;;

		pSendData	= (char*)lpExecutePlan;
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_GETEXECUTEPLANINFO;
		nRet = send(m_skSocket , (char *)&stTcpCmd , nSize, 0);
		if(nRet  != nSize)
		{
			//尝试一下重新连接服务试试
			if(m_skSocket != INVALID_SOCKET)
			{
				closesocket(m_skSocket);
				m_skSocket = INVALID_SOCKET;
			}
			nRet = OpenDatabase(TRUE);
			if(nRet != MF_OK)
			{
				pStatisticsInfo->m_nRet = nRet;
				return nRet;
			}
			nRet = send(m_skSocket , (char *)&stTcpCmd , nSize, 0);
			if(nRet  != nSize)
			{
				Trace(_T("TCPGetExecutePlanInfo"), 0, 888014001, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				return MF_INTERFACE_SENDDATA_FAILED;
			}
		}
		nRet = send(m_skSocket , (char *)pSendData, stTcpCmd.m_lDataLength, 0);
		if(nRet  != stTcpCmd.m_lDataLength)
		{
			Trace(_T("TCPGetExecutePlanInfo"), 0, 888014002, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
			return MF_INTERFACE_SENDDATA_FAILED;
		}

		for(i = 0; i < stBson.GetBufferSectionNum(); i++)
		{
			pSendData = (char*)stBson.GetBufferSection(i);
			if(i == stBson.GetBufferSectionNum())
			{
				nRet = send(m_skSocket, pSendData, stBson.GetCurretDataSize(), 0);
			}
			else
			{
				nRet = send(m_skSocket, pSendData, lpExecutePlan->m_nDefaultSectionSize, 0);
			}
			if(nRet != stTcpCmd.m_lDataLength)
			{
				Trace(_T("TCPGetExecutePlanInfo"), 0, 888014003, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				return MF_INTERFACE_SENDDATA_FAILED;
			}
		}
		//接收服务端返回数据
		while(TRUE)
		{
			memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
			nRet = recv(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
			if(nRet == 0)
			{
				//连接被关闭了
				Trace(_T("TCPGetExecutePlanInfo"), 0, 888014004, _T("接收服务端数据时出现连接被关闭的错误，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				return MF_INTERFACE_RECEIVEDATA_FAILED;
			}
			else if (nRet == SOCKET_ERROR)
			{
				//收到Socket错误
				nSocketError = WSAGetLastError();
				Trace(_T("TCPGetExecutePlanInfo"), 0, 888014005, _T("接收服务端数据时出现Socket错误，返回值：%d，错误码：%d"), nRet, nSocketError);
				if(nSocketError == WSAETIMEDOUT)
				{
					return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
				}
				else if(WSAECONNRESET == nSocketError)
				{
					return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
				}
				return MF_INTERFACE_RECEIVEDATA_FAILED;

			}
			else if(nRet == sizeof(MF_SERVICE_TCP_COMMAND))
			{
				//判断返回的是否正确数据
				if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_TEST)
				{
					continue;
				}
				else if(stTcpCmd.m_bToken != bToken)
				{
					nCount++;
					if(nCount > 3)
					{
						return MF_INTERFACE_RECEIVEDATA_TOKENERROR;
					}

					Sleep(1);
					ClearSocket();
					goto TCPGetExecutePlanInfo_Retry;
				}
				else
				{
					break;
				}
			}
			else
			{
				nSocketError = WSAGetLastError();
				Trace(_T("TCPGetExecutePlanInfo"), 0, 888014006, _T("接收服务端数据时返回值不是所期望的，有可能是服务端等待超时，客户端自动清理TCP缓存数据，返回值：%d，错误码：%d"), nRet, nSocketError);
				if(nSocketError == WSAETIMEDOUT)
				{
					return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
				}
				else if(WSAECONNRESET == nSocketError)
				{
					return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
				}
				return MF_INTERFACE_RECEIVEDATA_DATAERROR;

			}
		}

		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llReceiveEnd);
		//判断返回数据
		if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_FAIL)
		{
			//为失败结果处理
			pStatisticsInfo->m_nRet = stTcpCmd.m_lDigitalData;
			Trace(_T("TCPGetExecutePlanInfo"), 0, 888014010, _T("服务端返回执行失败，错误码：%d"), stTcpCmd.m_lDigitalData);
			return stTcpCmd.m_lDigitalData;
		}
		else if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_OK)
		{
			//获取执行效率数据
			GetStatisticsData(pStatisticsInfo, stTcpCmd.m_lpszParam);

			//为成功结果处理，还需要收后续数据
			if(stTcpCmd.m_lDataLength == 0)
			{
				Trace0(_T("TCPGetExecutePlanInfo"), 0, 888014011, _T("服务端返回的数据内容不正确，期望不为0，但实际收到0"));
				return MF_INTERFACE_RECEIVEDATA_DATAERROR;
			}
			else
			{
				EXECUTESTATISTICSINFO stExecuteInfo;
				memset(&stExecuteInfo, 0, sizeof(EXECUTESTATISTICSINFO));
				QueryPerformanceFrequency(&stExecuteInfo.m_liFrequence);
				QueryPerformanceCounter(&stExecuteInfo.m_liStart);
				if(!ReceiveBuffer((char*)lpExecutePlanInfo, stTcpCmd.m_lDataLength))
				{
					return MF_INTERFACE_RECEIVEDATA_FAILED;
				}
				return MF_OK;
			}
		}
		else
		{
			//错误的返回值
			ClearSocket();
			Trace(_T("TCPGetExecutePlanInfo"), 0, 888014012, _T("服务端返回的命令类型不正确，客户端自动清理TCP缓存数据，收到的命令类型：%d"), stTcpCmd.m_bType);
			return MF_INTERFACE_RECEIVEDATA_DATAERROR;
		}
	}
	return MF_FAILED;
}

#ifdef WIN32
int CDBInterface::TCPStartTransactionLogic(BSTR bstrTransactionData, LONG* plTransactionID, MF_EXECUTE_STATISTICS* pStatisticsInfo)
{
	BYTE bToken;
	char *lpData;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	int nSize, nRet, nCount, nSocketError;
	CCriticalSectionPtr cs(&m_csInterFace);

	nCount = 0;
TCPStartTransactionLogic_Retry:
	bToken = CreateRandomFactor();
	QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llParseEnd);
	nSize = sizeof(MF_SERVICE_TCP_COMMAND);
	memset(&stTcpCmd, 0, nSize);
	stTcpCmd.m_bVersion			= 1;
	stTcpCmd.m_bType			= MF_INTERFACE_TCPCOMMAND_STARTTRANSACTIONLOGIC;
	stTcpCmd.m_lDataLength		= 0;
	stTcpCmd.m_bToken			= bToken;
	lpData = ConvertToUTF8(bstrTransactionData);
	if(strlen(lpData) > 99)
	{
		Trace(_T("TCPStartTransactionLogic"), 0, 888015001, _T("开始事务命令的数据字符串太长导致失败，数据字符串：%s"), bstrTransactionData);
		delete [] lpData;
		return MF_INNER_SYS_INVALID_PARAMETER_ERROR;
	}
	strcpy_s(stTcpCmd.m_lpszParam, 100, lpData);
	delete [] lpData;

	nRet = send(m_skSocket , (char *)&stTcpCmd , nSize, 0);
	if(nRet  != nSize)
	{
		//尝试一下重新连接服务试试
		if(m_skSocket != INVALID_SOCKET)
		{
			closesocket(m_skSocket);
			m_skSocket = INVALID_SOCKET;
		}
		nRet = OpenDatabase(TRUE);
		if(nRet != MF_OK)
		{
			pStatisticsInfo->m_nRet = nRet;
			return nRet;
		}
		nRet = send(m_skSocket , (char *)&stTcpCmd , nSize, 0);
		if(nRet  != nSize)
		{
			Trace(_T("TCPStartTransactionLogic"), 0, 888015002, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
			return MF_INTERFACE_SENDDATA_FAILED;
		}
	}

	//接收服务端返回数据
	while(TRUE)
	{
		memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
		nRet = recv(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
		if(nRet == 0)
		{
			//连接被关闭了
			Trace(_T("TCPStartTransactionLogic"), 0, 888015003, _T("接收服务端数据时出现连接被关闭的错误，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
			return MF_INTERFACE_RECEIVEDATA_FAILED;
		}
		else if (nRet == SOCKET_ERROR)
		{
			//收到Socket错误
			nSocketError = WSAGetLastError();
			Trace(_T("TCPStartTransactionLogic"), 0, 888015004, _T("接收服务端数据时出现Socket错误，返回值：%d，错误码：%d"), nRet, nSocketError);
			if(nSocketError == WSAETIMEDOUT)
			{
				return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
			}
			else if(WSAECONNRESET == nSocketError)
			{
				return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
			}
			return MF_INTERFACE_RECEIVEDATA_FAILED;

		}
		else if(nRet == sizeof(MF_SERVICE_TCP_COMMAND))
		{
			//判断返回的是否正确数据
			if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_TEST)
			{
				continue;
			}
			else if(stTcpCmd.m_bToken != bToken)
			{
				nCount++;
				if(nCount > 3)
				{
					return MF_INTERFACE_RECEIVEDATA_TOKENERROR;
				}

				Sleep(1);
				ClearSocket();
				goto TCPStartTransactionLogic_Retry;
			}
			else
			{
				break;
			}
		}
		else
		{
			nSocketError = WSAGetLastError();
			Trace(_T("TCPStartTransactionLogic"), 0, 888015005, _T("接收服务端数据时返回值不是所期望的，有可能是服务端等待超时，客户端自动清理TCP缓存数据，返回值：%d，错误码：%d"), nRet, nSocketError);
			if(nSocketError == WSAETIMEDOUT)
			{
				return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
			}
			else if(WSAECONNRESET == nSocketError)
			{
				return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
			}
			return MF_INTERFACE_RECEIVEDATA_DATAERROR;
		}
	}

	QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llReceiveEnd);
	//判断返回数据
	if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_FAIL)
	{
		//为失败结果处理
		pStatisticsInfo->m_nRet = stTcpCmd.m_lDigitalData;
		Trace(_T("TCPStartTransactionLogic"), 0, 888015010, _T("服务端返回执行失败，错误码：%d"), stTcpCmd.m_lDigitalData);
		return stTcpCmd.m_lDigitalData;
	}
	else if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_OK)
	{
		//为成功结果处理
		if(stTcpCmd.m_lDataLength == 0)
		{
			*plTransactionID = stTcpCmd.m_lDigitalData;
			//获取执行效率数据
			GetStatisticsData(pStatisticsInfo, stTcpCmd.m_lpszParam);
			return MF_OK;
		}
		else
		{
			//数据肯定不正确，直接清理缓存
			ClearSocket();
			Trace(_T("TCPStartTransactionLogic"), 0, 888015011, _T("服务端返回的数据内容不正确，客户端自动清理TCP缓存数据，期望为0，但实际收到：%d"), stTcpCmd.m_lDataLength);
			return MF_INTERFACE_RECEIVEDATA_DATAERROR;
		}
	}
	else
	{
		//错误的返回值
		ClearSocket();
		Trace(_T("TCPStartTransactionLogic"), 0, 888015012, _T("服务端返回的命令类型不正确，客户端自动清理TCP缓存数据，收到的命令类型：%d"), stTcpCmd.m_bType);
		return MF_INTERFACE_RECEIVEDATA_DATAERROR;
	}

	return MF_FAILED;
}
#endif

#ifdef WIN32
int CDBInterface::TCPStopTransactionLogic(LONG lTransactionID, MF_EXECUTE_STATISTICS* pStatisticsInfo)
{
	BYTE bToken;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	int nSize, nRet, nCount, nSocketError;
	CCriticalSectionPtr cs(&m_csInterFace);
	nCount = 0;
TCPStopTransactionLogic_Retry:
	bToken = CreateRandomFactor();
	QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llParseEnd);
	nSize = sizeof(MF_SERVICE_TCP_COMMAND);
	memset(&stTcpCmd, 0, nSize);
	stTcpCmd.m_bVersion			= 1;
	stTcpCmd.m_bType			= MF_INTERFACE_TCPCOMMAND_STOPTRANSACTIONLOGIC;
	stTcpCmd.m_lDigitalData		= lTransactionID;
	stTcpCmd.m_lDataLength		= 0;
	stTcpCmd.m_bToken			= bToken;


	nRet = send(m_skSocket , (char *)&stTcpCmd , nSize, 0);
	if(nRet  != nSize)
	{
		//尝试一下重新连接服务试试
		if(m_skSocket != INVALID_SOCKET)
		{
			closesocket(m_skSocket);
			m_skSocket = INVALID_SOCKET;
		}
		nRet = OpenDatabase(TRUE);
		if(nRet != MF_OK)
		{
			pStatisticsInfo->m_nRet = nRet;
			return nRet;
		}
		nRet = send(m_skSocket , (char *)&stTcpCmd , nSize, 0);
		if(nRet  != nSize)
		{
			Trace(_T("TCPStopTransactionLogic"), 0, 888016001, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
			return MF_INTERFACE_SENDDATA_FAILED;
		}
	}

	//接收服务端返回数据
	while(TRUE)
	{
		memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
		nRet = recv(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
		if(nRet == 0)
		{
			//连接被关闭了
			Trace(_T("TCPStopTransactionLogic"), 0, 888016002, _T("接收服务端数据时出现连接被关闭的错误，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
			return MF_INTERFACE_RECEIVEDATA_FAILED;
		}
		else if (nRet == SOCKET_ERROR)
		{
			//收到Socket错误
			nSocketError = WSAGetLastError();
			Trace(_T("TCPStopTransactionLogic"), 0, 888016003, _T("接收服务端数据时出现Socket错误，返回值：%d，错误码：%d"), nRet, nSocketError);
			if(nSocketError == WSAETIMEDOUT)
			{
				return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
			}
			else if(WSAECONNRESET == nSocketError)
			{
				return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
			}
			return MF_INTERFACE_RECEIVEDATA_FAILED;

		}
		else if(nRet == sizeof(MF_SERVICE_TCP_COMMAND))
		{
			//判断返回的是否正确数据
			if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_TEST)
			{
				continue;
			}
			else if(stTcpCmd.m_bToken != bToken)
			{
				nCount++;
				if(nCount > 3)
				{
					return MF_INTERFACE_RECEIVEDATA_TOKENERROR;
				}

				Sleep(1);
				ClearSocket();
				goto TCPStopTransactionLogic_Retry;
			}
			else
			{
				break;
			}
		}
		else
		{
			nSocketError = WSAGetLastError();
			Trace(_T("TCPStopTransactionLogic"), 0, 888016004, _T("接收服务端数据时返回值不是所期望的，有可能是服务端等待超时，客户端自动清理TCP缓存数据，返回值：%d，错误码：%d"), nRet, nSocketError);
			if(nSocketError == WSAETIMEDOUT)
			{
				return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
			}
			else if(WSAECONNRESET == nSocketError)
			{
				return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
			}
			return MF_INTERFACE_RECEIVEDATA_DATAERROR;
		}
	}

	QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llReceiveEnd);
	//判断返回数据
	if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_FAIL)
	{
		//为失败结果处理
		pStatisticsInfo->m_nRet = stTcpCmd.m_lDigitalData;
		Trace(_T("TCPStopTransactionLogic"), 0, 888016010, _T("服务端返回执行失败，错误码：%d"), stTcpCmd.m_lDigitalData);
		return stTcpCmd.m_lDigitalData;
	}
	else if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_OK)
	{
		//为成功结果处理
		if(stTcpCmd.m_lDataLength == 0)
		{
			//获取执行效率数据
			GetStatisticsData(pStatisticsInfo, stTcpCmd.m_lpszParam);
			return MF_OK;
		}
		else
		{
			//数据肯定不正确，直接清理缓存
			ClearSocket();
			Trace(_T("TCPStopTransactionLogic"), 0, 888016011, _T("服务端返回的数据内容不正确，客户端自动清理TCP缓存数据，期望为0，但实际收到：%d"), stTcpCmd.m_lDataLength);
			return MF_INTERFACE_RECEIVEDATA_DATAERROR;
		}
	}
	else
	{
		//错误的返回值
		ClearSocket();
		Trace(_T("TCPStopTransactionLogic"), 0, 888016012, _T("服务端返回的命令类型不正确，客户端自动清理TCP缓存数据，收到的命令类型：%d"), stTcpCmd.m_bType);
		return MF_INTERFACE_RECEIVEDATA_DATAERROR;
	}

	return MF_FAILED;
}
#endif

int CDBInterface::SplitSql(char* lpszBuffer, int nLen, vector<char*>& vecSql)
{
	int i;
	char *pSql, chWord;
	BOOL bSingleQuote, bDoubleQuote;

	pSql   = NULL;
	bSingleQuote = FALSE;
	bDoubleQuote = FALSE;

	for(i = 0; i < nLen; i++)
	{
		if(bSingleQuote)
		{
			if(lpszBuffer[i] == '\'')
			{
				if(lpszBuffer[i + 1] == '\'')
				{
					i++;
					continue;
				}
				bSingleQuote = FALSE;
			}
			else
			{
				continue;
			}
		}
		else if(bDoubleQuote)
		{
			if(lpszBuffer[i] == '\"')
			{
				bDoubleQuote = FALSE;
			}
			else
			{
				continue;
			}
		}
		else
		{
			if(lpszBuffer[i] == '\'')
			{
				bSingleQuote = TRUE;
			}
			else if(lpszBuffer[i] == '\"')
			{
				bDoubleQuote = TRUE;
			}
			else if(lpszBuffer[i] == ';')
			{
				chWord = lpszBuffer[i + 1];
				lpszBuffer[i + 1] = 0;

				lpszBuffer[i] = 0;
				vecSql.push_back(pSql);
				lpszBuffer[i + 1] = chWord;

				pSql = NULL;
			}
			else if(lpszBuffer[i] == ' ' || lpszBuffer[i] == '	' || lpszBuffer[i] == '\r' || lpszBuffer[i] == '\n')
			{
				//忽略多余空格和分隔符
				continue;
			}
			else if(pSql == NULL)
			{
				pSql = lpszBuffer + i;
			}
		}
	}
	if(bSingleQuote)
	{
		return MF_PARSECMD_INVALID_STRING_ERROR;
	}

	if(lpszBuffer[i - 1] != ';')
	{
		if(pSql != NULL)
		{
			vecSql.push_back(pSql);
		}
	}
	return MF_OK;
}

int CDBInterface::ExecuteCommand(const char* lpszSql, int& nAffectCount, MF_EXECUTE_STATISTICS* pStatisticsInfo)
{
	int nRet;
	DWORD dwTime;
#ifdef WIN32
	__try
#else
	try
#endif
	{
		if(!m_bOpenFlag)
		{
			//没打开数据库链接
			return MF_INTERFACE_NOT_OPEN;
		}

		GetSystemTimeAsFileTime((FILETIME *)&pStatisticsInfo->m_ftStartTime);
		QueryPerformanceFrequency((LARGE_INTEGER *)&pStatisticsInfo->m_llFrequence);
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llStart);
		nRet = TCPExecuteCommand(lpszSql, nAffectCount, pStatisticsInfo);
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llEnd);
		if(m_lWriteEfficiencyLog == 1)
		{
			dwTime = (DWORD)(1000000 * (pStatisticsInfo->m_llEnd - pStatisticsInfo->m_llStart) / pStatisticsInfo->m_llFrequence ); //换算到微秒数
			Trace(_T("ExecuteCommand"), 0, 888030001, _T("数据库命令执行结束，耗时：%d微秒，返回值：0X%X，影响行数：%d，SQL：%s"), dwTime, nRet, nAffectCount, lpszSql);
		}
		GetSystemTimeAsFileTime((FILETIME *)&pStatisticsInfo->m_ftEndTime);
		return nRet;
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
		return MF_INNER_EXPCETION_FAILED;
	}
#else
	catch(...)
	{
		Trace(_T("ExecuteCommand"), 0, 888030099, _T("数据库命令执行异常，错误码：%d，SQL：%s"), GetLastError(), lpszSql);
		return MF_INNER_EXPCETION_FAILED;
	}
#endif
	return MF_FAILED;
}

int CDBInterface::GetRecordset(const char* lpszSql, CMemDBRecordset& stRs, MF_EXECUTE_STATISTICS* pStatisticsInfo)
{
	int nRet;
	DWORD dwTime, lRecordCount;
#ifdef WIN32
	__try
#else
	try
#endif
	{
		if(!m_bOpenFlag)
		{
			//没打开数据库链接
			return MF_INTERFACE_NOT_OPEN;
		}

		GetSystemTimeAsFileTime((FILETIME *)&pStatisticsInfo->m_ftStartTime);
		QueryPerformanceFrequency((LARGE_INTEGER *)&pStatisticsInfo->m_llFrequence);
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llStart);
		nRet = TCPGetRecordset(lpszSql, stRs, pStatisticsInfo);
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llEnd);
		if(m_lWriteEfficiencyLog == 1)
		{
			dwTime = (DWORD)(1000000 * (pStatisticsInfo->m_llEnd - pStatisticsInfo->m_llStart) / pStatisticsInfo->m_llFrequence ); //换算到微秒数
			if (nRet == MF_OK)
				lRecordCount = stRs.GetRowNum();
			else
				lRecordCount = 0;
			Trace(_T("GetRecordset"), 0, 888031001, _T("数据库检索执行结束，耗时：%d微秒，返回值：0X%X，返回数据条数：%d，SQL：%s"), dwTime, nRet, lRecordCount, lpszSql);
		}

		GetSystemTimeAsFileTime((FILETIME *)&pStatisticsInfo->m_ftEndTime);
		return nRet;
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
		return MF_INNER_EXPCETION_FAILED;
	}
#else
	catch(...)
	{
		Trace(_T("GetRecordset"), 0, 888031099, _T("数据库检索执行异常，错误码：%d，SQL：%s"), GetLastError(), lpszSql);
		return MF_INNER_EXPCETION_FAILED;
	}
#endif
	return MF_FAILED;
}

int CDBInterface::UpdateRecordset(CMemDBRecordset& stRs, MF_EXECUTE_STATISTICS* pStatisticsInfo)
{
	int nRet;
	DWORD dwTime;
#ifdef WIN32
	__try
#else
	try
#endif
	{
		if(!m_bOpenFlag)
		{
			//没打开数据库链接
			return MF_INTERFACE_NOT_OPEN;
		}

		GetSystemTimeAsFileTime((FILETIME *)&pStatisticsInfo->m_ftStartTime);
		QueryPerformanceFrequency((LARGE_INTEGER *)&pStatisticsInfo->m_llFrequence);
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llStart);
		nRet = TCPUpdateRecordset(stRs, pStatisticsInfo);
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llEnd);
		if(m_lWriteEfficiencyLog == 1)
		{
			dwTime = (DWORD)(1000000 * (pStatisticsInfo->m_llEnd - pStatisticsInfo->m_llStart) / pStatisticsInfo->m_llFrequence ); //换算到微秒数
			Trace(_T("UpdateRecordset"), 0, 888032001, _T("修改结果集操作结束，耗时：%d微秒，返回值：0X%X"), dwTime, nRet);
		}

		GetSystemTimeAsFileTime((FILETIME *)&pStatisticsInfo->m_ftEndTime);
		return nRet;
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
		return MF_INNER_EXPCETION_FAILED;
	}
#else
	catch(...)
	{
		Trace(_T("UpdateRecordset"), 0, 888032099, _T("更新结果集出现异常，错误码：%d"), GetLastError());
		return MF_INNER_EXPCETION_FAILED;
	}
#endif
	return MF_FAILED;
}

int CDBInterface::GetExecutePlanInfo(const char* lpszSql, LPEXECUTEPLANDESCRIBE lpExecutePlanDesc, MF_EXECUTE_STATISTICS* pStatisticsInfo)
{
	int nRet;
	DWORD dwTime;
	EXECUTEPLANINFO stExecutePlanInfo;
#ifdef WIN32
	__try
#else
	try
#endif
	{
		if(!m_bOpenFlag)
		{
			//没打开数据库链接
			return MF_INTERFACE_NOT_OPEN;
		}

		GetSystemTimeAsFileTime((FILETIME *)&pStatisticsInfo->m_ftStartTime);
		QueryPerformanceFrequency((LARGE_INTEGER *)&pStatisticsInfo->m_llFrequence);
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llStart);
		nRet = TCPGetExecutePlanInfo(lpszSql, &stExecutePlanInfo, pStatisticsInfo);
		QueryPerformanceCounter((LARGE_INTEGER *)&pStatisticsInfo->m_llEnd);
		if(m_lWriteEfficiencyLog == 1)
		{
			dwTime = (DWORD)(1000000 * (pStatisticsInfo->m_llEnd - pStatisticsInfo->m_llStart) / pStatisticsInfo->m_llFrequence ); //换算到微秒数
			Trace(_T("GetExecutePlanInfo"), 0, 888033001, _T("获取执行计划完成，耗时：%d微秒，返回值：0X%X，SQL：%s"), dwTime, nRet, lpszSql);
		}
		GetSystemTimeAsFileTime((FILETIME *)&pStatisticsInfo->m_ftEndTime);
		if(nRet != MF_OK)
		{
			return nRet;
		}
		lpExecutePlanDesc->m_bDrection			= stExecutePlanInfo.m_bDrection;
		lpExecutePlanDesc->m_bIndexType			= stExecutePlanInfo.m_bIndexType;
		lpExecutePlanDesc->m_bObjectType		= stExecutePlanInfo.m_bObjectType;
		lpExecutePlanDesc->m_bRecursionLevel	= stExecutePlanInfo.m_bRecursionLevel;
		lpExecutePlanDesc->m_nRowNumber			= stExecutePlanInfo.m_nRowNumber;
		if(!ConvertStr(stExecutePlanInfo.m_pDescribe, lpExecutePlanDesc->m_pDescribe, 100))
		{
			Trace(_T("GetExecutePlanInfo"), 0, 888033002, _T("字符串转换失败！错误码：%d"), GetLastError());
			return MF_FAILED;
		}

		if(!ConvertStr(stExecutePlanInfo.m_pIndexName, lpExecutePlanDesc->m_pIndexName, 32))
		{
			Trace(_T("GetExecutePlanInfo"), 0, 888033003, _T("字符串转换失败！错误码：%d"), GetLastError());
			return MF_FAILED;
		}
		
		if(!ConvertStr(stExecutePlanInfo.m_pObjectName, lpExecutePlanDesc->m_pObjectName, 32))
		{
			Trace(_T("GetExecutePlanInfo"), 0, 888033004, _T("字符串转换失败！错误码：%d"), GetLastError());
			return MF_FAILED;
		}
		return MF_OK;
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
		return MF_INNER_EXPCETION_FAILED;
	}
#else
	catch(...)
	{
		Trace(_T("GetExecutePlanInfo"), 0, 888033099, _T("获取执行计划出现异常，错误码：%d，SQL：%s"), GetLastError(), lpszSql);
		return MF_INNER_EXPCETION_FAILED;
	}
#endif
	return MF_FAILED;
}

#ifdef WIN32
int CDBInterface::StartTransactionLogic(BSTR bstrTransactionData, LONG* plTransactionID)
{
	int nRet;
	DWORD dwTime;
	MF_EXECUTE_STATISTICS stStatisticsInfo;
#ifdef WIN32
	__try
#else
	try
#endif
	{
		if(!m_bOpenFlag)
		{
			//没打开数据库链接
			return MF_INTERFACE_NOT_OPEN;
		}

		QueryPerformanceFrequency((LARGE_INTEGER *)&stStatisticsInfo.m_llFrequence);
		QueryPerformanceCounter((LARGE_INTEGER *)&stStatisticsInfo.m_llStart);
		nRet = TCPStartTransactionLogic(bstrTransactionData, plTransactionID, &stStatisticsInfo);
		QueryPerformanceCounter((LARGE_INTEGER *)&stStatisticsInfo.m_llEnd);
		if(m_lWriteEfficiencyLog == 1)
		{
			dwTime = (DWORD)(1000000 * (stStatisticsInfo.m_llEnd - stStatisticsInfo.m_llStart) / stStatisticsInfo.m_llFrequence ); //换算到微秒数
			Trace(_T("StartTransactionLogic"), 0, 888034001, _T("开始短事务锁命令执行结束，耗时：%d微秒，返回值：0X%X，事务ID：%d，bstrTransactionData：%s"), dwTime, nRet, *plTransactionID, bstrTransactionData);
		}

		return nRet;
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
		return MF_INNER_EXPCETION_FAILED;
	}
#else
	catch(...)
	{
		Trace(_T("StartTransactionLogic"), 0, 888034099, _T("开始短事务锁命令执行出现异常，错误码：%d，SQL：%s"), GetLastError(), lpszSql);
		return MF_INNER_EXPCETION_FAILED;
	}
#endif
	return MF_FAILED;
}
#endif

#ifdef WIN32
int CDBInterface::StopTransactionLogic(LONG lTransactionID)
{
	int nRet;
	DWORD dwTime;
	MF_EXECUTE_STATISTICS stStatisticsInfo;
#ifdef WIN32
	__try
#else
	try
#endif
	{
		if(!m_bOpenFlag)
		{
			//没打开数据库链接
			return MF_INTERFACE_NOT_OPEN;
		}

		QueryPerformanceFrequency((LARGE_INTEGER *)&stStatisticsInfo.m_llFrequence);
		QueryPerformanceCounter((LARGE_INTEGER *)&stStatisticsInfo.m_llStart);
		nRet = TCPStopTransactionLogic(lTransactionID, &stStatisticsInfo);
		QueryPerformanceCounter((LARGE_INTEGER *)&stStatisticsInfo.m_llEnd);
		if(m_lWriteEfficiencyLog == 1)
		{
			dwTime = (DWORD)(1000000 * (stStatisticsInfo.m_llEnd - stStatisticsInfo.m_llStart) / stStatisticsInfo.m_llFrequence ); //换算到微秒数
			Trace(_T("StopTransactionLogic"), 0, 888035001, _T("结束短事务锁命令执行结束，耗时：%d微秒，返回值：0X%X，lTransactionID：%d"), dwTime, nRet, lTransactionID);
		}

		return nRet;
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
		return MF_INNER_EXPCETION_FAILED;
	}
#else
	catch(...)
	{
		Trace(_T("StopTransactionLogic"), 0, 888035099, _T("结束短事务锁命令执行出现异常，错误码：%d，SQL：%s"), GetLastError(), lpszSql);
		return MF_INNER_EXPCETION_FAILED;
	}
#endif
	return MF_FAILED;
}
#endif

////////////////////////////////////////////////////////////////////////////
ULONG CDBInterface::GetIpAddress()
{
	ULONG ulIP;
	hostent *phostent;
	char szHostName[256];
	memset(szHostName, 0, 256);
	if(gethostname(szHostName, 256) == SOCKET_ERROR)
	{
		return INADDR_NONE;
	}

	phostent = gethostbyname(szHostName);
	if(phostent == NULL)
	{
		return INADDR_NONE;
	}

	memcpy(&ulIP, phostent->h_addr_list[0], 4);
	ulIP = ntohl(ulIP);
	return ulIP;
}

ULONG CDBInterface::StringToIpAddress(char* lpIpAddress)
{
	ULONG ulIP;
	if (lpIpAddress == NULL)
	{
		return INADDR_NONE;
	}
	ulIP = ntohl(inet_addr(lpIpAddress));
	if (ulIP == INADDR_NONE)
	{
		//ip非法
		//将输入字符串当作机器名再试一下
		hostent *phostent;
		phostent = gethostbyname(lpIpAddress);
		if(phostent == NULL)
		{
			return INADDR_NONE;
		}

		////获得所有网卡IP
		//int nAdapter = 0;
		//ULONG ulIPAddressList[8] = {0};
		//for(nAdapter = 0; phostent->h_addr_list[nAdapter]; nAdapter++)
		//{   
		//	ulIPAddressList[nAdapter] = ntohl(((IN_ADDR*)phostent->h_addr_list[nAdapter])->s_addr);
		//	if ((ulIPAddressList[nAdapter] == 0) || (ulIPAddressList[nAdapter] == INADDR_NONE))
		//	{
		//		break;
		//	}
		//	if (nAdapter >= 8)
		//	{
		//		break;
		//	}
		//}

		ulIP = ntohl(((IN_ADDR*)phostent->h_addr_list[0])->s_addr);

		return ulIP;
	}
	else
	{
		return ulIP;
	}

	return INADDR_NONE;
}

int CDBInterface::ExportObject(char *lpObjectNameArray, int nObjectCount, char *lpszExportFilePath, CALLBACK_VERNOXEXCHANGE pCallback, LPVOID lpParam)
{
	FILE *fp;
	char *lpObjectName;
	ISobeyDBRecordsetPtr rs;
	int nRet, nLen, nWrittenSize;
	EXPORTFILEHEAD stExportFileHead;
	long long llObjectDataSize, llStartPos, llEndPos;
	
	nRet = GetRecordset("SELECT 1 FROM DUAL", &rs);
	if(nRet != MF_OK)
	{
		Trace0(_T("ImportObject"), MF_TRACE_LEVEL_FAILED, 888040000, _T("数据库连接失败！"));
		return nRet;
	}
	rs.Release();

	fp = fopen(lpszExportFilePath, "wb+");
	if (NULL == fp)
	{
		nRet = GetLastError();
		Trace("ExportObject", MF_TRACE_LEVEL_FAILED, 888040001, "创建导出文件失败，文件路径：%s，错误码：%d", lpszExportFilePath, nRet);
		return nRet;
	}

	memset(&stExportFileHead, 0, sizeof(EXPORTFILEHEAD));
	stExportFileHead.m_nVersion = 1;
	stExportFileHead.m_nFileFlag = MAKEHEADFLAG('E','X','D','A');
	memcpy(stExportFileHead.m_pDataFlag, "Vernox", 6);
	stExportFileHead.m_nObjectCount = nObjectCount;

	//写入文件头
	llEndPos = sizeof(EXPORTFILEHEAD);
	llStartPos = llEndPos;
	llObjectDataSize = 0;
	nWrittenSize = fwrite(&stExportFileHead, 1, llEndPos, fp);
	if (nWrittenSize != llEndPos)
	{
		nRet = GetLastError();
		Trace(_T("ExportObject"), 0, 888040002, _T("导出对象时将文件头写入文件失败，实际写入长度：%d，需要写入长度：%d，错误码：%d"), nWrittenSize, llEndPos, nRet);
		goto ExportObject_CloseFile;
	}

	for (int i = 0; i < nObjectCount; i++)
	{
		lpObjectName = lpObjectNameArray + i*MAX_PATH;
		nLen = strlen(lpObjectName);
		if (nLen > 31)
		{
			Trace(_T("ExportObject"), 0, 888040003, _T("表名长度超过限制，实际长度：%d，允许长度：%d"), nLen, 31);
			nRet = MF_FAILED;
			goto ExportObject_CloseFile;
		}

		//导出表数据
		nRet = ExportObject(lpObjectName, fp, pCallback, lpParam);
		if (nRet != MF_OK)
		{
			goto ExportObject_CloseFile;
		}

		//写入表数据总长度
		//首先移动到表头位置
		//表头结构第一位就是长度，所以直接写入即可
#ifdef WIN32
		llEndPos = _ftelli64(fp);
		llObjectDataSize = llEndPos - llStartPos;
		_fseeki64(fp, llStartPos, SEEK_SET);
		nWrittenSize = fwrite(&llObjectDataSize, 1, sizeof(long long), fp);
		if (nWrittenSize != sizeof(long long))
		{
			nRet = GetLastError();
			Trace(_T("ExportObject"), 0, 888040004, _T("导出对象时将数据写入文件失败，实际写入长度：%d，需要写入长度：%d，错误码：%d"), nWrittenSize, sizeof(long long), nRet);
			goto ExportObject_CloseFile;
		}
		_fseeki64(fp, llEndPos, SEEK_SET);
		llStartPos = llEndPos;
#else
		llEndPos = ftell(fp);
		llObjectDataSize = llEndPos - llStartPos;
		fseek(fp, llStartPos, SEEK_SET);
		nWrittenSize = fwrite(&llObjectDataSize, 1, sizeof(long long), fp);
		if (nWrittenSize != sizeof(long long))
		{
			nRet = GetLastError();
			Trace(_T("ExportObject"), 0, 888040004, _T("导出对象时将数据写入文件失败，实际写入长度：%d，需要写入长度：%d，错误码：%d"), nWrittenSize, sizeof(long long), nRet);
			goto ExportObject_CloseFile;
		}
		fseek(fp, llEndPos, SEEK_SET);
		llStartPos = llEndPos;
#endif
	}
	
ExportObject_CloseFile:
	if (fp != NULL)
	{
		fflush(fp);
		fclose(fp);
		fp = NULL;
	}
	return nRet;
}

int CDBInterface::ExportObject(char *lpszObjectName, FILE *fp, CALLBACK_VERNOXEXCHANGE pCallback, LPVOID lpParam)
{
	BYTE bToken;
	LPBYTE lpBuffer;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	int nReturn, nRet, nSize, nLen, nBufferSize, nWrittenSize, nTotalDataNum, nCurrentDataNum;

	nReturn = MF_OK;
	nBufferSize = MF_DEFAULT_BUFFER_SIZE;
	lpBuffer = new BYTE[nBufferSize];
	if (lpBuffer == NULL)
	{
		Trace(_T("ExportObject"), 0, 888050001, _T("分配接收数据的内存失败，期望分配内存大小为：%d，错误码：%d"), nBufferSize, GetLastError());
		nReturn = MF_FAILED;
		goto ExportObject_End;
	}

	try
	{
		bToken = CreateRandomFactor();
		nSize = sizeof(MF_SERVICE_TCP_COMMAND);
		memset(&stTcpCmd, 0, nSize);
		stTcpCmd.m_bVersion			= 1;
		stTcpCmd.m_bToken			= bToken;
		stTcpCmd.m_lDataLength		= 0;
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_EXPORTOBJECT;
		nLen = strlen(lpszObjectName);
		if (nLen > 31)
		{
			Trace(_T("ExportObject"), 0, 888050002, _T("表名长度超过限制，实际长度：%d，允许长度：%d"), nLen, 31);
			nReturn = MF_FAILED;
			goto ExportObject_End;
		}
		memcpy(stTcpCmd.m_lpszParam, lpszObjectName, nLen);

		nRet = send(m_skSocket , (char *)&stTcpCmd , nSize, 0);
		if(nRet != nSize)
		{
			Trace(_T("ExportObject"), 0, 888050003, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
			nReturn = WSAGetLastError();
			goto ExportObject_End;
		}

		//接受对象数据
		nTotalDataNum = 0;
		nCurrentDataNum = 0;
		while(TRUE)
		{
			memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
			nRet = recv(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
			if(nRet == 0)
			{
				//连接被关闭了
				Trace(_T("ExportObject"), 0, 888050004, _T("接收服务端数据时出现连接被关闭的错误，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				nReturn = WSAGetLastError();
				goto ExportObject_End;
			}
			else if (nRet == SOCKET_ERROR)
			{
				//收到Socket错误
				Trace(_T("ExportObject"), 0, 888050005, _T("接收服务端数据时出现Socket错误，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				nReturn = WSAGetLastError();
				goto ExportObject_End;
			}
			else if(nRet == sizeof(MF_SERVICE_TCP_COMMAND))
			{
				//判断返回的是否正确数据
				if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_TEST)
				{
					continue;
				}
				else if(stTcpCmd.m_bToken != bToken)
				{
					Trace(_T("ExportObject"), 0, 888050006, _T("接收服务端返回的令牌不相同，返回令牌值：%d，发送令牌值：%d"), stTcpCmd.m_bToken, bToken);
					ClearSocket();
					nReturn = MF_INTERFACE_RECEIVEDATA_TOKENERROR;
					goto ExportObject_End;
				}
				else
				{
					//判断返回数据
					if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_FAIL)
					{
						//为失败结果处理
						Trace(_T("ExportObject"), 0, 888050007, _T("服务端返回执行失败，错误码：%d"), stTcpCmd.m_lDigitalData);
						nReturn = stTcpCmd.m_lDigitalData;
						goto ExportObject_End;
					}
					else if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_OK)
					{
						if(stTcpCmd.m_lDataLength > nBufferSize)
						{
							delete[] lpBuffer;
							nBufferSize = stTcpCmd.m_lDataLength;
							lpBuffer = new BYTE[nBufferSize];
							if (lpBuffer == NULL)
							{
								Trace(_T("ExportObject"), 0, 888050008, _T("分配接收数据的内存失败，期望分配内存大小为：%d，错误码：%d"), nBufferSize, GetLastError());
								nReturn = GetLastError();
								goto ExportObject_End;
							}
						}

						if(!ReceiveBuffer((char*)lpBuffer, stTcpCmd.m_lDataLength))
						{
							nReturn = MF_INTERFACE_RECEIVEDATA_FAILED;
							goto ExportObject_End;
						}
						if(stTcpCmd.m_lDigitalData  == 1)
						{
							//文件头
							LPEXPORTOBJECTFILEHEAD lpExportFileHead;
							lpExportFileHead = (LPEXPORTOBJECTFILEHEAD)lpBuffer;
							nTotalDataNum	 = lpExportFileHead->m_nTotalDataNum;
							//添加用户名等信息
						}
						else
						{
							LPOBJECTBUFFERHEAD lpObjectBufferHead;
							lpObjectBufferHead = (LPOBJECTBUFFERHEAD)lpBuffer;
							nCurrentDataNum	   += lpObjectBufferHead->m_nDataNum;
						}
						//写入文件中
						nWrittenSize = fwrite(lpBuffer, 1, stTcpCmd.m_lDataLength, fp);
						if (nWrittenSize != stTcpCmd.m_lDataLength)
						{
							Trace(_T("ExportObject"), 0, 888050009, _T("导出对象时将数据写入文件失败，实际写入长度：%d，需要写入长度：%d，错误码：%d"), nWrittenSize, stTcpCmd.m_lDataLength, GetLastError());
							nReturn = GetLastError();
							goto ExportObject_End;
						}

						if(!pCallback(lpParam, lpszObjectName, nTotalDataNum, nCurrentDataNum))
						{
							goto ExportObject_End;
						}

						//为成功结果处理，还需要收后续数据
						if(stTcpCmd.m_lDigitalData == 2)
						{
							//接收完成了
							nReturn = MF_OK;
							goto ExportObject_End;
						}
					}
					else
					{
						//错误的返回值
						ClearSocket();
						Trace(_T("ExportObject"), 0, 888050010, _T("服务端返回的命令类型不正确，客户端自动清理TCP缓存数据，收到的命令类型：%d"), stTcpCmd.m_bType);
						nReturn = MF_INTERFACE_RECEIVEDATA_FAILED;
						goto ExportObject_End;
					}
				}
			}
			else
			{
				Trace(_T("ExportObject"), 0, 888050011, _T("接收服务端数据时返回值不是所期望的，有可能是服务端等待超时，客户端自动清理TCP缓存数据，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				nReturn = MF_INTERFACE_RECEIVEDATA_FAILED;
				goto ExportObject_End;
			}
		}
	}
	catch(...)
	{
		Trace(_T("ExportObject"), 0, 888050099, _T("通过TCP调服务端执行检索时出现未知异常，错误码：%d"), GetLastError());
		nReturn = MF_INNER_EXPCETION_FAILED;
		goto ExportObject_End;
	}

ExportObject_End:
	if (lpBuffer != NULL)
	{
		delete[] lpBuffer;
		lpBuffer = NULL;
	}
	return nReturn;
}

int CDBInterface::ImportObject(char *lpszImportFilePath, CALLBACK_VERNOXEXCHANGE pCallback, LPVOID lpParam)
{
	FILE *fp;
	int nRet, nLen;
	ISobeyDBRecordsetPtr rs;
	EXPORTFILEHEAD stExportFileHead;

	nRet = GetRecordset("SELECT 1 FROM DUAL", &rs);
	if(nRet != MF_OK)
	{
		Trace0(_T("ImportObject"), MF_TRACE_LEVEL_FAILED, 888060000, _T("数据库连接失败！"));
		return nRet;
	}
	rs.Release();

	if (access(lpszImportFilePath, 0) != 0)
	{
		Trace(_T("ImportObject"), MF_TRACE_LEVEL_FAILED, 888060001, _T("导入对象时发现文件不存在，导出路径：%s"), lpszImportFilePath);
		nRet = MF_FAILED;
		goto ImportObject_CloseFile;
	}
	fp = fopen(lpszImportFilePath, "rb");
	if (NULL == fp)
	{
		nRet = GetLastError();
		Trace("ImportObject", MF_TRACE_LEVEL_FAILED, 888060002, "打开导入文件失败，文件路径：%s，错误码：%d", lpszImportFilePath, nRet);
		goto ImportObject_CloseFile;
	}
	memset(&stExportFileHead, 0, sizeof(EXPORTFILEHEAD));
	nLen = fread(&stExportFileHead, 1, sizeof(EXPORTFILEHEAD), fp);
	if (nLen != sizeof(EXPORTFILEHEAD))
	{
		nRet = GetLastError();
		Trace(_T("ImportObject"), 0, 888060003, _T("导入对象时读取数据失败，实际读取长度：%d，需要读取长度：%d，错误码：%d"), nLen, sizeof(EXPORTFILEHEAD), nRet);
		goto ImportObject_CloseFile;
	}

	if (stExportFileHead.m_nVersion == 1 && stExportFileHead.m_nFileFlag == MAKEHEADFLAG('E','X','D','A') && strncmp(stExportFileHead.m_pDataFlag, "Vernox", 6) == 0
		&& stExportFileHead.m_pDataFlag[6] == 0 && stExportFileHead.m_nObjectCount > 0 && stExportFileHead.m_nObjectCount < 256)
	{
		for (int i = stExportFileHead.m_nObjectCount; i > 0; i--)
		{
			nRet = ImportObject(fp, pCallback, lpParam);
			if (nRet != MF_OK)
			{
				goto ImportObject_CloseFile;
			}
		}
	} 
	else
	{
		Trace(_T("ImportObject"), 0, 888060004, _T("导入对象时校验文件头失败！"));
		nRet = MF_FAILED;
		goto ImportObject_CloseFile;
	}
	
ImportObject_CloseFile:
	if (fp != NULL)
	{
		fclose(fp);
		fp = NULL;
	}
	return nRet;
}

int CDBInterface::ImportObject(FILE *fp, CALLBACK_VERNOXEXCHANGE pCallback, LPVOID lpParam)
{
	BYTE bToken;
	long long llObjectDataSize;
	LPBYTE lpBuffer, lpBuffer2;
	LPOBJECTBUFFERHEAD lpObjectBufferHead;
	EXPORTOBJECTFILEHEAD stObjectFileHead;
	MF_SERVICE_TCP_COMMAND stTcpCmd, stRectTcpCmd;
	int nRet, nSize, nBufferSize, nObjectBufferHeadSize, nReadSize, nCurrentDataNum;

	nRet		= MF_OK;
	nBufferSize = MF_DEFAULT_BUFFER_SIZE;
	lpBuffer	= new BYTE[nBufferSize];
	if (lpBuffer == NULL)
	{
		Trace(_T("ImportObject"), 0, 888070001, _T("分配接收数据的内存失败，期望分配内存大小为：%d，错误码：%d"), nBufferSize, GetLastError());
		nRet = MF_FAILED;
		goto IMPORT_OBJECT_END;
	}

	try
	{
		nReadSize = fread(&stObjectFileHead, 1, sizeof(EXPORTOBJECTFILEHEAD), fp);
		if(nReadSize != sizeof(EXPORTOBJECTFILEHEAD))
		{
			nRet = GetLastError();
			Trace(_T("ImportObject"), 0, 888070002, _T("导入对象时读取数据失败，实际读取长度：%d，需要读取长度：%d，错误码：%d"), nReadSize, sizeof(EXPORTOBJECTFILEHEAD), nRet);
			goto IMPORT_OBJECT_END;
		}
		if (stObjectFileHead.m_nVersion == 1 && stObjectFileHead.m_nFileFlag == MAKEHEADFLAG('E','X','D','A') && strncmp(stObjectFileHead.m_pDataFlag, "Vernox", 6) == 0 && stObjectFileHead.m_pObjectName[31] == 0)
		{
			nRet = MF_FAILED;
			Trace(_T("ImportObject"), 0, 888070003, _T("导入对象时读取数据失败，表头信息错误"));
			goto IMPORT_OBJECT_END;
		}
		llObjectDataSize = stObjectFileHead.m_llObjectDataSize;
		if (llObjectDataSize <= sizeof(EXPORTOBJECTFILEHEAD))
		{
			nRet = MF_FAILED;
			Trace(_T("ImportObject"), 0, 888070004, _T("导入对象时读取数据失败，表数据总长度错误，总长度：%d"), llObjectDataSize);
			goto IMPORT_OBJECT_END;
		}

		bToken = CreateRandomFactor();
		nSize = sizeof(MF_SERVICE_TCP_COMMAND);
		memset(&stTcpCmd, 0, nSize);
		stTcpCmd.m_bVersion			= 1;
		stTcpCmd.m_bToken			= bToken;
		stTcpCmd.m_lDataLength		= 0;
		stTcpCmd.m_bType = MF_INTERFACE_TCPCOMMAND_IMPORTOBJECT;
		memcpy(stTcpCmd.m_lpszParam, stObjectFileHead.m_pObjectName, strlen(stObjectFileHead.m_pObjectName));

		llObjectDataSize -= sizeof(EXPORTOBJECTFILEHEAD);
		nObjectBufferHeadSize = sizeof(OBJECTBUFFERHEAD);
		nCurrentDataNum	= 0;
		while (llObjectDataSize > 0)
		{
			//读取对象Buffer头
			nReadSize = fread(lpBuffer, 1, nObjectBufferHeadSize, fp);
			llObjectDataSize -= nReadSize;
			if(nReadSize != nObjectBufferHeadSize)
			{
				nRet = GetLastError();
				Trace(_T("ImportObject"), 0, 888070005, _T("导入对象时读取数据失败，实际读取长度：%d，需要读取长度：%d，错误码：%d"), nReadSize, nObjectBufferHeadSize, nRet);
				goto IMPORT_OBJECT_END;
			}
			lpObjectBufferHead = (LPOBJECTBUFFERHEAD)lpBuffer;
			if(lpObjectBufferHead->m_nFlag != MAKEHEADFLAG('E','X','O','B'))
			{
				//数据出错
				nRet = MF_FAILED;
				Trace(_T("ImportObject"), 0, 888070006, _T("导入对象时读取数据失败，数据头信息错误"));
				goto IMPORT_OBJECT_END;
			}

			//判断当前Buffer是否可以容纳对象数据
			if(lpObjectBufferHead->m_nBufferLen + nObjectBufferHeadSize > nBufferSize)
			{
				nBufferSize = ((lpObjectBufferHead->m_nBufferLen + nObjectBufferHeadSize) / MF_DEFAULT_BUFFER_SIZE + 1)*MF_DEFAULT_BUFFER_SIZE;		//按照MF_DEFAULT_BUFFER_SIZE的整数倍进行分配
				lpBuffer2 = new BYTE[nBufferSize];
				if (lpBuffer2 == NULL)
				{
					Trace(_T("ImportObject"), 0, 888070007, _T("分配接收数据的内存失败，期望分配内存大小为：%d，错误码：%d"), nBufferSize, GetLastError());
					nRet = MF_FAILED;
					goto IMPORT_OBJECT_END;
				}
				//将对象数据头拷贝到新Buffer中
				memcpy(lpBuffer2, lpBuffer, nObjectBufferHeadSize);
				lpObjectBufferHead = (LPOBJECTBUFFERHEAD)lpBuffer2;

				delete[] lpBuffer;
				lpBuffer = lpBuffer2;
			}

			//读对象Buffer内容
			nReadSize = fread(lpBuffer + nObjectBufferHeadSize, 1, lpObjectBufferHead->m_nBufferLen, fp);
			llObjectDataSize -= nReadSize;
			if(nReadSize != lpObjectBufferHead->m_nBufferLen)
			{
				nRet = GetLastError();
				Trace(_T("ImportObject"), 0, 888070008, _T("导入对象时读取数据失败，实际读取长度：%d，需要读取长度：%d，错误码：%d"), nReadSize, lpObjectBufferHead->m_nBufferLen, nRet);
				goto IMPORT_OBJECT_END;
			}
		
			//发送数据
			stTcpCmd.m_lDataLength = lpObjectBufferHead->m_nBufferLen + nObjectBufferHeadSize;
			nRet = send(m_skSocket, (char *)&stTcpCmd, nSize, 0);
			if(nRet != nSize)
			{
				Trace(_T("ImportObject"), 0, 888070009, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				nRet = WSAGetLastError();
				goto IMPORT_OBJECT_END;
			}
			nRet = send(m_skSocket, (char *)lpBuffer, stTcpCmd.m_lDataLength, 0);
			if(nRet != stTcpCmd.m_lDataLength)
			{
				Trace(_T("ImportObject"), 0, 888070010, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
				nRet = WSAGetLastError();
				goto IMPORT_OBJECT_END;
			}
			nCurrentDataNum += lpObjectBufferHead->m_nDataNum;
			pCallback(lpParam, stObjectFileHead.m_pObjectName, stObjectFileHead.m_nTotalDataNum, nCurrentDataNum);

			//接收服务端返回数据
			while(TRUE)
			{
				memset(&stRectTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
				nRet = recv(m_skSocket, (char *)&stRectTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
				if(nRet == 0)
				{
					//连接被关闭了
					Trace(_T("ImportObject"), 0, 888070011, _T("接收服务端数据时出现连接被关闭的错误，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
					nRet = WSAGetLastError();
					goto IMPORT_OBJECT_END;
				}
				else if (nRet == SOCKET_ERROR)
				{
					//收到Socket错误
					Trace(_T("ImportObject"), 0, 888070012, _T("接收服务端数据时出现Socket错误，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
					nRet = WSAGetLastError();
					goto IMPORT_OBJECT_END;
				}
				else if(nRet == sizeof(MF_SERVICE_TCP_COMMAND))
				{
					//判断返回的是否正确数据
					if(stRectTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_TEST)
					{
						continue;
					}
					else if(stRectTcpCmd.m_bToken != bToken)
					{
						Trace(_T("ImportObject"), 0, 888070013, _T("接收服务端返回的令牌不相同，返回令牌值：%d，发送令牌值：%d"), stTcpCmd.m_bToken, bToken);
						ClearSocket();
						nRet = MF_INTERFACE_RECEIVEDATA_TOKENERROR;
						goto IMPORT_OBJECT_END;
					}
					else
					{
						//判断返回数据
						if(stRectTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_FAIL)
						{
							//为失败结果处理
							Trace(_T("ImportObject"), 0, 888070014, _T("服务端返回执行失败，错误码：%d"), stTcpCmd.m_lDigitalData);
							nRet = stRectTcpCmd.m_lDigitalData;
							goto IMPORT_OBJECT_END;
						}
						else if(stRectTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_OK)
						{
							if(stRectTcpCmd.m_lDataLength == 0)
							{
								break;
							}
							else
							{
								//错误的返回值
								ClearSocket();
								Trace(_T("ImportObject"), 0, 888070015, _T("服务端返回的命令类型不正确，客户端自动清理TCP缓存数据，收到的命令类型：%d"), stTcpCmd.m_bType);
								nRet = MF_INTERFACE_RECEIVEDATA_FAILED;
								goto IMPORT_OBJECT_END;
							}
						}
						else
						{
							//错误的返回值
							ClearSocket();
							Trace(_T("ImportObject"), 0, 888070016, _T("服务端返回的命令类型不正确，客户端自动清理TCP缓存数据，收到的命令类型：%d"), stTcpCmd.m_bType);
							nRet = MF_INTERFACE_RECEIVEDATA_FAILED;
							goto IMPORT_OBJECT_END;
						}
					}
				}
				else
				{
					Trace(_T("ImportObject"), 0, 888070017, _T("接收服务端数据时返回值不是所期望的，有可能是服务端等待超时，客户端自动清理TCP缓存数据，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
					nRet = MF_INTERFACE_RECEIVEDATA_FAILED;
					goto IMPORT_OBJECT_END;
				}
			}
		}
		if (llObjectDataSize != 0)
		{
			nRet = MF_FAILED;
			Trace(_T("ImportObject"), 0, 888070018, _T("导入对象时出现错误，导入完成时文件剩余数据量（%d）不为0！"), llObjectDataSize);
			goto IMPORT_OBJECT_END;
		}
		else
		{
			nRet = MF_OK;
		}
	}
	catch(...)
	{
		Trace(_T("ImportObject"), 0, 888070099, _T("通过TCP调服务端执行检索时出现未知异常，错误码：%d"), GetLastError());
		nRet = MF_INNER_EXPCETION_FAILED;
		goto IMPORT_OBJECT_END;
	}

IMPORT_OBJECT_END:
	if (lpBuffer != NULL)
	{
		delete[] lpBuffer;
		lpBuffer = NULL;
	}
	return nRet;
}

int CDBInterface::UserLogOut(int& nRetValue)
{
	BYTE bToken;
	MF_SERVICE_TCP_COMMAND stTcpCmd;
	int i, nRet, nSize, nCount, nSocketError;

	if(!m_bOpenFlag)
	{
		return S_OK;
	}
	nCount = 0;
UserLogOut_Retry:
	bToken = CreateRandomFactor();
	nSize = sizeof(MF_SERVICE_TCP_COMMAND);
	memset(&stTcpCmd, 0, nSize);

	stTcpCmd.m_bVersion		= 1;
	stTcpCmd.m_bToken		= bToken;
	stTcpCmd.m_bType		= MF_INTERFACE_COMMAND_USERLOGOUT;
	memcpy(stTcpCmd.m_lpszParam, m_pUserName, 24);
	memcpy(stTcpCmd.m_lpszParam+24, m_pPassword, 24);

	nRet = send(m_skSocket, (char *)&stTcpCmd , nSize, 0);
	if(nRet  != nSize)
	{
		Trace(_T("UserLogout"), 0, 888042001, _T("通过TCP向服务端发送数据失败，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
		return MF_INTERFACE_SENDDATA_FAILED;
	}
	//接收服务端返回数据
	i = 0;
	while(TRUE)
	{
		memset(&stTcpCmd, 0, sizeof(MF_SERVICE_TCP_COMMAND));
		nRet = recv(m_skSocket, (char *)&stTcpCmd, sizeof(MF_SERVICE_TCP_COMMAND), 0);
		if(nRet == 0)
		{
			//连接被关闭了
			Trace(_T("UserLogout"), 0, 888042002, _T("接收服务端数据时出现连接被关闭的错误，返回值：%d，错误码：%d"), nRet, WSAGetLastError());
			return MF_INTERFACE_RECEIVEDATA_FAILED;
		}
		else if (nRet == SOCKET_ERROR)
		{
			//收到Socket错误
			nSocketError = WSAGetLastError();
			Trace(_T("UserLogout"), 0, 888042003, _T("接收服务端数据时出现Socket错误，返回值：%d，错误码：%d"), nRet, nSocketError);
			if(nSocketError == WSAETIMEDOUT)
			{
				return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
			}
			else if(WSAECONNRESET == nSocketError)
			{
				return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
			}
			return MF_INTERFACE_RECEIVEDATA_FAILED;

		}
		else if(nRet == sizeof(MF_SERVICE_TCP_COMMAND))
		{
			//判断返回的是否正确数据
			if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_TEST)
			{
				continue;
			}
			else if(stTcpCmd.m_bToken != bToken)
			{
				nCount++;
				if(nCount > 3)
				{
					return MF_INTERFACE_RECEIVEDATA_TOKENERROR;
				}

				Sleep(1);
				ClearSocket();
				goto UserLogOut_Retry;
			}
			else
			{
				break;
			}
		}
		else
		{
			nSocketError = WSAGetLastError();
			Trace(_T("UserLogout"), 0, 888042004, _T("接收服务端数据时返回值不是所期望的，有可能是服务端等待超时，客户端自动清理TCP缓存数据，返回值：%d，错误码：%d"), nRet, nSocketError);
			if(nSocketError == WSAETIMEDOUT)
			{
				return MF_INTERFACE_RECEIVEDATA_TIMEOUT;
			}
			else if(WSAECONNRESET == nSocketError)
			{
				return MF_INTERFACE_RECEIVEDATA_CONNECTRESET;
			}
			return MF_INTERFACE_RECEIVEDATA_DATAERROR;
		}
	}

	//判断返回数据
	nRet = stTcpCmd.m_lDigitalData;
	if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_FAIL)
	{
		//为失败结果处理
		Trace(_T("UserLogout"), 0, 888042010, _T("用户登录注销，用户名%s，返回值：%d"), m_pUserName, nRet);
		return nRet;
	}
	else if(stTcpCmd.m_bType == MF_INTERFACE_TCPCOMMAND_OK)
	{
		memset(m_pUserName, 0, 24);
		memset(m_pPassword, 0, 24);
		m_bOpenFlag = FALSE;
		return MF_OK;
	}
	else
	{
		//错误的返回值
		ClearSocket();
		Trace(_T("UserLogout"), 0, 888042011, _T("服务端返回的命令类型不正确，客户端自动清理TCP缓存数据，收到的命令类型：%d"), stTcpCmd.m_bType);
		return MF_INTERFACE_RECEIVEDATA_DATAERROR;
	}
	return MF_FAILED;
}


int CDBInterface::SqlQuery(char* lpSql, int& nAffectCount, CMemDBRecordset& stRs, LPEXECUTEPLANDESCRIBE lpExecutePlanDesc, MF_EXECUTE_STATISTICS* pStatisticsInfo)
{
	int nRet;
	int nSqlType;
	char *pSql, *pSqlTemp;
	if (lpSql == NULL)
	{
		pStatisticsInfo->m_nRet = 1;
		return MF_PARSECMD_INVALID_NULL_ERROR;
	}
	pSql = lpSql;

	//去除前后空格
	pSql = RemoveSpaceFromString(pSql);
	if (pSql[0] == 0)
	{
		pStatisticsInfo->m_nRet = MF_PARSECMD_EMPTY_STRING;
		return MF_OK;
	}
	pSqlTemp = pSql;						//记录一下

	//分析指令类型
#ifdef WIN32
	if (strnicmp(pSql, "vernox:", 6) == 0 )
	{
		pSql = pSql + 6;
		pSql = RemoveSpaceFromString(pSql);
	} 

	nSqlType = -1;
	if (strnicmp(pSql, "explain ", 8) == 0)
	{
		//分析执行计划
		nSqlType = 0;
		pSqlTemp = pSql + 8;
	} 
	else if (strnicmp(pSql, "select", 6) == 0)
	{
		//DQL语句
		nSqlType = 1;
	} 
	else if (strnicmp(pSql, "insert", 6) == 0 || strnicmp(pSql, "update", 6) == 0 || strnicmp(pSql, "delete", 6) == 0)
	{
		//DML语句
		nSqlType = 2;
	} 
	else if (strnicmp(pSql, "create", 6) == 0 || strnicmp(pSql, "revoke", 6) == 0 || strnicmp(pSql, "alter", 5) == 0 || strnicmp(pSql, "grant", 5) == 0 || strnicmp(pSql, "drop", 4) == 0)
	{
		//DDL语句
		nSqlType = 3;
	} 
	else
	{
		//这里不支持updaterecordset
		pStatisticsInfo->m_nRet = 1;
		return MF_FAILED;
	}
#else
	if (strncasecmp(pSql, "vernox:", 6) == 0 )
	{
		pSql = pSql + 6;
		pSql = RemoveSpaceFromString(pSql);
	} 

	nSqlType = -1;
	if (strncasecmp(pSql, "explain ", 8) == 0)
	{
		//分析执行计划
		nSqlType = 0;
		pSqlTemp = pSql + 8;
	} 
	else if (strncasecmp(pSql, "select", 6) == 0)
	{
		//DQL语句
		nSqlType = 1;
	} 
	else if (strncasecmp(pSql, "insert", 6) == 0 || strncasecmp(pSql, "update", 6) == 0 || strncasecmp(pSql, "delete", 6) == 0)
	{
		//DML语句
		nSqlType = 2;
	} 
	else if (strncasecmp(pSql, "create", 6) == 0 || strncasecmp(pSql, "revoke", 6) == 0 || strncasecmp(pSql, "alter", 5) == 0 || strncasecmp(pSql, "grant", 5) == 0 || strncasecmp(pSql, "drop", 4) == 0)
	{
		//DDL语句
		nSqlType = 3;
	} 
	else
	{
		//这里不支持updaterecordset
		pStatisticsInfo->m_nRet = 1;
		return E_FAIL;
	}
#endif
	pSql = pSqlTemp;
	pStatisticsInfo->m_nSqlType = nSqlType;
	if (nSqlType == 0)
	{
		nRet = GetExecutePlanInfo(pSql, lpExecutePlanDesc, pStatisticsInfo);
	} 
	else if (nSqlType == 1)
	{
		nRet = GetRecordset(pSql, stRs, pStatisticsInfo);
		nAffectCount = stRs.GetRowNum();
	}
	else if (nSqlType == 2 || nSqlType == 3)
	{
		nRet = ExecuteCommand(pSql, nAffectCount, pStatisticsInfo);
	}
	else
	{
		pStatisticsInfo->m_nRet = 1;
		return MF_FAILED;
	}

	return nRet;
}

//去除前后空格
char* CDBInterface::RemoveSpaceFromString(char* lpStr)
{
	char* pSql;
	int nSqlLength;

	if (lpStr == NULL)
	{
		return NULL;
	}

	pSql = lpStr;
	while (TRUE)
	{
		if (pSql[0] == ' ')
		{
			pSql++;
		} 
		else
		{
			break;
		}
	}
	nSqlLength = strlen(pSql);
	while (TRUE)
	{
		if (pSql[nSqlLength-1] == ' ')
		{
			nSqlLength--;
			pSql[nSqlLength] = 0;
		} 
		else
		{
			break;
		}
	}

	return pSql;
}

BOOL CDBInterface::IsCharacter(char c)
{
	if ((c >= 48 && c <= 57) || (c>= 65 && c <= 90) || (c >= 97 && c <= 122) || c == '_' || c == '.' ||  c == '-')		//数字，大写字母，小写字母，下划线，小数点，横杠
	{
		return TRUE;
	} 
	else
	{
		return FALSE;
	}
}

BOOL CDBInterface::ParseConnectConfig(char *lpServerName, FILE * fp, STRUCT_CONNECT_CONFIG &stConfig)
{
	BOOL bValue;
	char *lpBuffer;
	STRUCT_ADDRESS stAddr;
	STRUCT_CONNECT_CONFIG st;
	int i, j, nIndex, nLeft, nRight, nEqualSign, nLineLength, nStrLength;
	char arrayLine[1024];

	lpBuffer = NULL;
	j = 0;
	nIndex = 0;
	nLeft = 0;
	nRight = 0;
	nEqualSign = 0;
	bValue = FALSE;
	memset(&st.m_cSobeyDB, 0, sizeof(st.m_cSobeyDB));
	memset(&st.m_cDatabaseName, 0, sizeof(st.m_cDatabaseName));
	st.m_vecAddress.clear();
	memset(&stAddr, 0, sizeof(stAddr));
	st.m_vecAddress.push_back(stAddr);
	while(!feof(fp))
	{
		memset(arrayLine, 0, sizeof(arrayLine));
		if(fgets(arrayLine, 1000, fp))		//读取一行
		{
			nLineLength = strlen(arrayLine);
			i = 0;
			while (i < nLineLength)
			{
				if (arrayLine[i] == ' ' || arrayLine[i] == '\t')
				{
					i++;
					continue;
				}
				if (arrayLine[i] == '#' || arrayLine[i] == '\n' || arrayLine[i] == '\r')		//注释
				{
					break;
				}
				if (arrayLine[i] == '(')
				{
					nLeft++;
					i++;
					continue;
				}
				if (arrayLine[i] == ')')
				{
					nRight++;
					i++;
					if (nRight == 9)
					{
						if (nLeft == 9 && nEqualSign == 10 && nIndex == 10)		//开始解析下一组配置参数
						{
							if(stricmp(st.m_cSobeyDB, lpServerName) == 0)
							{
								memcpy(stConfig.m_cSobeyDB, st.m_cSobeyDB, sizeof(st.m_cSobeyDB));
								memcpy(stConfig.m_cDatabaseName, st.m_cDatabaseName, sizeof(st.m_cDatabaseName));
								for(j = 0;j < st.m_vecAddress.size();j++)
								{
									stConfig.m_vecAddress.push_back(st.m_vecAddress[j]);
								}
								return TRUE;
							}
							j = 0;
							nIndex = 0;
							nLeft = 0;
							nRight = 0;
							nEqualSign = 0;
							bValue = FALSE;
							memset(&st.m_cSobeyDB, 0, sizeof(st.m_cSobeyDB));
							memset(&st.m_cDatabaseName, 0, sizeof(st.m_cDatabaseName));
							st.m_vecAddress.clear();
							memset(&stAddr, 0, sizeof(stAddr));
							st.m_vecAddress.push_back(stAddr);
						}
						else
						{
							return FALSE;
						}
					}
					continue;
				}
				if (arrayLine[i] == '=')
				{
					nEqualSign++;
					i++;
					continue;
				}

				if (!IsCharacter(arrayLine[i]))
				{
					return FALSE;
				}

				if (0 == nIndex)			//标识名
				{
					if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex)
					{
						nStrLength = 0;
						lpBuffer = arrayLine+i;
						while (i < nLineLength)
						{
							if (IsCharacter(arrayLine[i]))
							{
								i++;
								nStrLength++;
								continue;
							}
							memcpy(st.m_cSobeyDB, lpBuffer, nStrLength);
							nIndex++;
							break;
						}
						if (nIndex != 1)
						{
							return FALSE;
						}
					} 
					else
					{
						return FALSE;
					}
				}
				else if (1 == nIndex)			//DESCRIPTION
				{
					if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex)
					{
						nStrLength = 11;
						lpBuffer = arrayLine+i;
						if (i + nStrLength < nLineLength)
						{
						#ifdef WIN32
							if (_strnicmp(lpBuffer, "DESCRIPTION", nStrLength) == 0)
						#else
							if (strncasecmp(lpBuffer, "DESCRIPTION", nStrLength) == 0)
						#endif
							{
								nIndex++;
								i = i+nStrLength;
							} 
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					}
					else
					{
						return FALSE;
					}
				}
				else if (2 == nIndex)			//ADDRESS_LIST
				{
					if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex)
					{
						nStrLength = 12;
						lpBuffer = arrayLine+i;
						if (i + nStrLength < nLineLength)
						{
						#ifdef WIN32
							if (_strnicmp(lpBuffer, "ADDRESS_LIST", nStrLength) == 0)
						#else
							if (strncasecmp(lpBuffer, "ADDRESS_LIST", nStrLength) == 0)
						#endif
							{
								nIndex++;
								i = i+nStrLength;
							} 
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					}
					else
					{
						return FALSE;
					}
				}
				else if (3 == nIndex)			//ADDRESS
				{
					if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex)
					{
						nStrLength = 7;
						lpBuffer = arrayLine+i;
						if (i + nStrLength < nLineLength)
						{
						#ifdef WIN32
							if (_strnicmp(lpBuffer, "ADDRESS", nStrLength) == 0)
						#else
							if (strncasecmp(lpBuffer, "ADDRESS", nStrLength) == 0)
						#endif
							{
								nIndex++;
								i = i+nStrLength;
							} 
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					}
					else
					{
						return FALSE;
					}
				}
				else if (4 == nIndex)			//PROTOCOL
				{
					if (bValue == FALSE)
					{
						if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex)
						{
							nStrLength = 8;
							lpBuffer = arrayLine+i;
							if (i + nStrLength < nLineLength)
							{
							#ifdef WIN32
								if (_strnicmp(lpBuffer, "PROTOCOL", nStrLength) == 0)
							#else
								if (strncasecmp(lpBuffer, "PROTOCOL", nStrLength) == 0)
							#endif
								{
									i = i+nStrLength;
									bValue = TRUE;
								} 
								else
								{
									return FALSE;
								}
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					} 
					else
					{
						if (nLeft == nIndex && nRight == 0 && nEqualSign == nIndex+1)
						{
							nStrLength = 0;
							lpBuffer = arrayLine+i;
							while (i < nLineLength)
							{
								if (IsCharacter(arrayLine[i]))
								{
									i++;
									nStrLength++;
									continue;
								}
								memcpy(st.m_vecAddress[j].m_cProtocol, lpBuffer, nStrLength);
								nIndex++;
								bValue = FALSE;
								break;
							}
							if (nIndex != 5)
							{
								return FALSE;
							}
						} 
						else
						{
							return FALSE;
						}
					}
				}
				else if (5 == nIndex)			//HOST
				{
					if (bValue == FALSE)
					{
						if (nLeft == nIndex && nRight == 1 && nEqualSign == nIndex)
						{
							nStrLength = 4;
							lpBuffer = arrayLine+i;
							if (i + nStrLength < nLineLength)
							{
							#ifdef WIN32
								if (_strnicmp(lpBuffer, "HOST", nStrLength) == 0)
							#else
								if (strncasecmp(lpBuffer, "HOST", nStrLength) == 0)
							#endif
								{
									i = i+nStrLength;
									bValue = TRUE;
								} 
								else
								{
									return FALSE;
								}
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					} 
					else
					{
						if (nLeft == nIndex && nRight == 1 && nEqualSign == nIndex+1)
						{
							nStrLength = 0;
							lpBuffer = arrayLine+i;
							while (i < nLineLength)
							{
								if (IsCharacter(arrayLine[i]))
								{
									i++;
									nStrLength++;
									continue;
								}
								memcpy(st.m_vecAddress[j].m_cHost, lpBuffer, nStrLength);
								nIndex++;
								bValue = FALSE;
								break;
							}
							if (nIndex != 6)
							{
								return FALSE;
							}
						} 
						else
						{
							return FALSE;
						}
					}
				}
				else if (6 == nIndex)			//PORT
				{
					if (bValue == FALSE)
					{
						if (nLeft == nIndex && nRight == 2 && nEqualSign == nIndex)
						{
							nStrLength = 4;
							lpBuffer = arrayLine+i;
							if (i + nStrLength < nLineLength)
							{
							#ifdef WIN32
								if (_strnicmp(lpBuffer, "PORT", nStrLength) == 0)
							#else
								if (strncasecmp(lpBuffer, "PORT", nStrLength) == 0)
							#endif
								{
									i = i+nStrLength;
									bValue = TRUE;
								} 
								else
								{
									return FALSE;
								}
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					} 
					else
					{
						if (nLeft == nIndex && nRight == 2 && nEqualSign == nIndex+1)
						{
							nStrLength = 0;
							lpBuffer = arrayLine+i;
							while (i < nLineLength)
							{
								if (IsCharacter(arrayLine[i]))
								{
									i++;
									nStrLength++;
									continue;
								}
								memcpy(st.m_vecAddress[j].m_cPort, lpBuffer, nStrLength);
								nIndex++;
								bValue = FALSE;
								break;
							}
							if (nIndex != 7)
							{
								return FALSE;
							}
						} 
						else
						{
							return FALSE;
						}
					}
				}
				else if (7 == nIndex)			//WriteLog
				{
					if (bValue == FALSE)
					{
						if (nLeft == nIndex && nRight == 3 && nEqualSign == nIndex)
						{
							nStrLength = 8;
							lpBuffer = arrayLine+i;
							if (i + nStrLength < nLineLength)
							{
							#ifdef WIN32
								if (_strnicmp(lpBuffer, "WriteLog", nStrLength) == 0)
							#else
								if (strncasecmp(lpBuffer, "WriteLog", nStrLength) == 0)
							#endif
								{
									i = i+nStrLength;
									bValue = TRUE;
								} 
								else
								{
									return FALSE;
								}
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					} 
					else
					{
						if (nLeft == nIndex && nRight == 3 && nEqualSign == nIndex+1)
						{
							nStrLength = 0;
							lpBuffer = arrayLine+i;
							while (i < nLineLength)
							{
								if (IsCharacter(arrayLine[i]))
								{
									i++;
									nStrLength++;
									continue;
								}
								memcpy(st.m_vecAddress[j].m_cWriteLog, lpBuffer, nStrLength);
								nIndex++;
								bValue = FALSE;
								break;
							}
							if (nIndex != 8)
							{
								return FALSE;
							}
						} 
						else
						{
							return FALSE;
						}
					}
				}
				else if (8 == nIndex)			//CONNECT_DATA
				{
					if (nLeft == nIndex && nRight == 6 && nEqualSign == nIndex)				//CONNECT_DATA
					{
						nStrLength = 12;
						lpBuffer = arrayLine+i;
						if (i + nStrLength < nLineLength)
						{
						#ifdef WIN32
							if (_strnicmp(lpBuffer, "CONNECT_DATA", nStrLength) == 0)
						#else
							if (strncasecmp(lpBuffer, "CONNECT_DATA", nStrLength) == 0)
						#endif
							{
								nIndex++;
								i = i+nStrLength;
							} 
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					}
					else if (nLeft == nIndex && nRight == 5 && nEqualSign == nIndex)		//ADDRESS
					{
						nStrLength = 7;
						lpBuffer = arrayLine+i;
						if (i + nStrLength < nLineLength)
						{
						#ifdef WIN32
							if (_strnicmp(lpBuffer, "ADDRESS", nStrLength) == 0)
						#else
							if (strncasecmp(lpBuffer, "ADDRESS", nStrLength) == 0)
						#endif
							{
								nIndex = 3;
								nLeft = 3;
								nRight = 0;
								nEqualSign = 3;
								j++;
								memset(&stAddr, 0, sizeof(stAddr));
								st.m_vecAddress.push_back(stAddr);
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					}
					else
					{
						return FALSE;
					}
				}
				else if (9 == nIndex)			//DATABASENAME
				{
					if (bValue == FALSE)
					{
						if (nLeft == nIndex && nRight == 6 && nEqualSign == nIndex)
						{
							nStrLength = 12;
							lpBuffer = arrayLine+i;
							if (i + nStrLength < nLineLength)
							{
							#ifdef WIN32
								if (_strnicmp(lpBuffer, "DATABASENAME", nStrLength) == 0)
							#else
								if (strncasecmp(lpBuffer, "DATABASENAME", nStrLength) == 0)
							#endif
								{
									i = i+nStrLength;
									bValue = TRUE;
								} 
								else
								{
									return FALSE;
								}
							}
							else
							{
								return FALSE;
							}
						}
						else
						{
							return FALSE;
						}
					} 
					else
					{
						if (nLeft == nIndex && nRight == 6 && nEqualSign == nIndex+1)
						{
							nStrLength = 0;
							lpBuffer = arrayLine+i;
							while (i < nLineLength)
							{
								if (IsCharacter(arrayLine[i]))
								{
									i++;
									nStrLength++;
									continue;
								}
								memcpy(st.m_cDatabaseName, lpBuffer, nStrLength);
								nIndex++;
								bValue = FALSE;
								break;
							}
							if (nIndex != 10)
							{
								return FALSE;
							}
						} 
						else
						{
							return FALSE;
						}
					}
				}
			}
			Sleep(1);
		}
		else
		{
			break;
		}
	}
	return FALSE;
}

int CDBInterface::ParseConnectConfig(char *lpServerName, STRUCT_CONNECT_CONFIG &stConfig)
{
	FILE *fp;
	int nRet;
	char lpWorkingPath[MAX_PATH], lpConfigPath[MAX_PATH];


	fp = NULL;
#ifdef WIN32
	GetModuleFileNameA(g_hVernoxInstance, lpWorkingPath, MAX_PATH);
	(strrchr(lpWorkingPath, '\\'))[0] = 0;
	(strrchr(lpWorkingPath, '\\'))[1] = 0;
	sprintf(lpConfigPath, "%sConfig\\Vernox.ini", lpWorkingPath);
	if(_access(lpConfigPath, 04) == -1)
	{
		//文件不存在
		GetModuleFileNameA(g_hVernoxInstance, lpWorkingPath, MAX_PATH);
		(strrchr(lpWorkingPath, '\\'))[1] = 0;
		sprintf(lpConfigPath, "%sVernox.ini", lpWorkingPath);
	}
#else
	GetModuleFileName(NULL, lpWorkingPath, MAX_PATH);
	(strrchr(lpWorkingPath, '/'))[0] = 0;
	(strrchr(lpWorkingPath, '/'))[1] = 0;
	sprintf(lpConfigPath, "%sConfig/Vernox.ini", lpWorkingPath);
	if(access(lpConfigPath, 04) == -1)
	{
		//文件不存在
		GetModuleFileName(NULL, lpWorkingPath, MAX_PATH);
		(strrchr(lpWorkingPath, '/'))[1] = 0;
		sprintf(lpConfigPath, "%sVernox.ini", lpWorkingPath);
	}
#endif

	fp = fopen(lpConfigPath, "rb");
	if (fp == NULL)
	{
		return MF_INTERFACE_SERVER_PARSE_FAILED;
	}
	if(ParseConnectConfig(lpServerName, fp, stConfig))
	{
		nRet = MF_OK;
	}
	else
	{
		nRet = MF_INTERFACE_SERVER_PARSE_ERROR;
	}
	fclose(fp);
	return nRet;
}

//释放数据库连接对象资源函数
void CDBInterface::Release()
{
#ifdef WIN32
	__try
#else
	try
#endif
	{
		FinalRelease();
		delete this;
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
	}
#else
	catch(...)
	{
	}
#endif
}

int CDBInterface::OpenCore(char * lpszServerName, char * lpszUserName, char * lpszPassword)
{
	int i, nLen, nRet;
	STRUCT_CONNECT_CONFIG stConfig;
	memset(stConfig.m_cSobeyDB, 0, sizeof(stConfig.m_cSobeyDB));
	memset(stConfig.m_cDatabaseName, 0, sizeof(stConfig.m_cDatabaseName));
	nRet = ParseConnectConfig(lpszServerName, stConfig);
	if(nRet != MF_OK)
	{
		return nRet;
	}
	if(stConfig.m_vecAddress.size() == 0)
	{
		return MF_FAILED;
	}
	for(i = 0;i < stConfig.m_vecAddress.size();i++)
	{
		//TODO:	支持域名
		m_uServiceTCPIP		= inet_addr(stConfig.m_vecAddress[i].m_cHost);
		m_uServiceTCPPort	= htons(atol(stConfig.m_vecAddress[i].m_cPort));
		if (lpszUserName != NULL)
		{
			nLen = strlen(lpszUserName);
			if (nLen > 23)
			{
				nLen = 23;
			}
			memset(m_pUserName, 0, sizeof(m_pUserName));
			memcpy(m_pUserName, lpszUserName, nLen);
		}
		if (lpszPassword != NULL)
		{
			nLen = strlen(lpszPassword);
			if (nLen > 23)
			{
				nLen = 23;
			}
			memset(m_pPassword, 0, sizeof(m_pPassword));
			memcpy(m_pPassword, lpszPassword, nLen);
		}
		return OpenDatabase(FALSE);
	}
	return MF_FAILED;
}
//连接到数据库函数
int CDBInterface::Open(char * lpszServerName, char * lpszUserName, char * lpszPassword)
{
#ifdef WIN32
	__try
#else
	try
#endif
	{
		Close();
		return OpenCore(lpszServerName, lpszUserName, lpszPassword);
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
		return MF_INNER_EXPCETION_FAILED;
	}
#else
	catch(...)
	{
		Trace(_T("Open"), 0, 888048099, _T("打开数据库连接出现异常，错误码：%d"), GetLastError());
		return MF_INNER_EXPCETION_FAILED;
	}
#endif
	return MF_FAILED;
}

int CDBInterface::OpenWithAddress(char *lpszUserName, char *lpszPassword, ULONG ulIP, USHORT usPort)
{
	Close();

	int nLen;

	m_uServiceTCPIP		= htonl(ulIP);
	m_uServiceTCPPort	= htons(usPort);
	if (lpszUserName != NULL)
	{
		nLen = strlen(lpszUserName);
		if (nLen > 23)
		{
			nLen = 23;
		}
		memset(m_pUserName, 0, sizeof(m_pUserName));
		memcpy(m_pUserName, lpszUserName, nLen);
	}
	if (lpszPassword != NULL)
	{
		nLen = strlen(lpszPassword);
		if (nLen > 23)
		{
			nLen = 23;
		}
		memset(m_pPassword, 0, sizeof(m_pPassword));
		memcpy(m_pPassword, lpszPassword, nLen);
	}
	return OpenDatabase(FALSE);
}

int CDBInterface::OpenWithAddress(char *lpszUserName, char *lpszPassword, char* lpszHost, char* lpszPort)
{
	//TODO
	//支持机器名和ip地址
	return 0;
}

//关闭数据库连接函数
void CDBInterface::Close()
{
#ifdef WIN32
	__try
#else
	try
#endif
	{
		int nRetValue = 0;
		if(m_skSocket != INVALID_SOCKET)
		{
			UserLogOut(nRetValue);
			closesocket(m_skSocket);
			m_skSocket = INVALID_SOCKET;
		}
		m_bOpenFlag = FALSE;
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
	}
#else
	catch(...)
	{
	}
#endif

}

//数据库执行函数
int CDBInterface::Execute(char * lpszSqlText, int &lAffectCount, void * lpDescription)
{
	int nRet;
	DWORD dwTime;
	MF_EXECUTE_STATISTICS stInfo, *pStatisticsInfo;
#ifdef WIN32
	__try
#else
	try
#endif
	{
		if(!m_bOpenFlag)
		{
			//没打开数据库链接
			return MF_INTERFACE_NOT_OPEN;
		}

		memset(&stInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
		GetSystemTimeAsFileTime((FILETIME *)&stInfo.m_ftStartTime);
		QueryPerformanceFrequency((LARGE_INTEGER *)&stInfo.m_llFrequence);
		QueryPerformanceCounter((LARGE_INTEGER *)&stInfo.m_llStart);
		nRet = TCPExecuteCommand(lpszSqlText, lAffectCount, &stInfo);
		QueryPerformanceCounter((LARGE_INTEGER *)&stInfo.m_llEnd);
		if(m_lWriteEfficiencyLog == 1)
		{
			dwTime = (DWORD)(1000000 * (stInfo.m_llEnd - stInfo.m_llStart) / stInfo.m_llFrequence ); //换算到微秒数
			Trace(_T("Execute"), 0, 888050001, _T("数据库命令执行结束，耗时：%d微秒，返回值：0X%X，影响行数：%d，bstrCmd：%s"), dwTime, nRet, lAffectCount, lpszSqlText);
		}
		GetSystemTimeAsFileTime((FILETIME *)&stInfo.m_ftEndTime);
		
		if(lpDescription != NULL)
		{
			pStatisticsInfo = (MF_EXECUTE_STATISTICS*)lpDescription;
			memcpy(pStatisticsInfo, &stInfo, sizeof(MF_EXECUTE_STATISTICS));
		}
		return nRet;
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
		return MF_INNER_EXPCETION_FAILED;
	}
#else
	catch(...)
	{
		Trace(_T("Execute"), 0, 888050099, _T("数据库命令执行出现异常，错误码：%d，SQL：%s"), GetLastError(), lpszSqlText);
		return MF_INNER_EXPCETION_FAILED;
	}
#endif
	return MF_FAILED;
}

//数据库查询数据到结果集函数
int CDBInterface::GetRecordset(char * lpszSqlText, ISobeyDBRecordset** pRecordset, void * lpDescription)
{
	int nRet;
	DWORD dwTime, lRecordCount;
	MF_EXECUTE_STATISTICS stInfo, *pStatisticsInfo;
#ifdef WIN32
	__try
#else
	try
#endif
	{
		if(!m_bOpenFlag)
		{
			//没打开数据库链接
			return MF_INTERFACE_NOT_OPEN;
		}
		memset(&stInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
		CMemDBRecordset::CreateInstance(*pRecordset);
		GetSystemTimeAsFileTime((FILETIME *)&stInfo.m_ftStartTime);
		QueryPerformanceFrequency((LARGE_INTEGER *)&stInfo.m_llFrequence);
		QueryPerformanceCounter((LARGE_INTEGER *)&stInfo.m_llStart);
		nRet = TCPGetRecordset(lpszSqlText, *((CMemDBRecordset *)*pRecordset), &stInfo);
		QueryPerformanceCounter((LARGE_INTEGER *)&stInfo.m_llEnd);
		if(m_lWriteEfficiencyLog == 1)
		{
			dwTime = (DWORD)(1000000 * (stInfo.m_llEnd - stInfo.m_llStart) / stInfo.m_llFrequence ); //换算到微秒数
			if (SUCCEEDED(nRet))
				lRecordCount = (*pRecordset)->GetRowNum();
			else
				lRecordCount = 0;
			Trace(_T("GetRecordset"), 0, 888051001, _T("数据库检索执行结束，耗时：%d微秒，返回值：0X%X，返回数据条数：%d，bstrSql：%s"), dwTime, nRet, lRecordCount, lpszSqlText);
		}
		GetSystemTimeAsFileTime((FILETIME *)&stInfo.m_ftEndTime);
		if(lpDescription != NULL)
		{
			pStatisticsInfo = (MF_EXECUTE_STATISTICS*)lpDescription;
			memcpy(pStatisticsInfo, &stInfo, sizeof(MF_EXECUTE_STATISTICS));
		}
		return nRet;
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
		return MF_INNER_EXPCETION_FAILED;
	}
#else
	catch(...)
	{
		Trace(_T("GetRecordset"), 0, 888051099, _T("数据库检索执行出现异常，错误码：%d，SQL：%s"), GetLastError(), lpszSqlText);
		return MF_INNER_EXPCETION_FAILED;
	}
#endif
	return MF_FAILED;
}

//结果集更新执行函数
int CDBInterface::UpdateRecordset(ISobeyDBRecordset* pRecordset, void * lpDescription)
{
	int nRet;
	DWORD dwTime;
	MF_EXECUTE_STATISTICS stInfo,*pStatisticsInfo;
#ifdef WIN32
	__try
#else
	try
#endif
	{
		if(!m_bOpenFlag)
		{
			//没打开数据库链接
			return MF_INTERFACE_NOT_OPEN;
		}
		memset(&stInfo, 0, sizeof(MF_EXECUTE_STATISTICS));
		GetSystemTimeAsFileTime((FILETIME *)&stInfo.m_ftStartTime);
		QueryPerformanceFrequency((LARGE_INTEGER *)&stInfo.m_llFrequence);
		QueryPerformanceCounter((LARGE_INTEGER *)&stInfo.m_llStart);
		nRet = TCPUpdateRecordset(*(CMemDBRecordset*)pRecordset, &stInfo);
		QueryPerformanceCounter((LARGE_INTEGER *)&stInfo.m_llEnd);
		if(m_lWriteEfficiencyLog == 1)
		{
			dwTime = (DWORD)(1000000 * (stInfo.m_llEnd - stInfo.m_llStart) / stInfo.m_llFrequence ); //换算到微秒数
			Trace(_T("UpdateRecordset"), 0, 888052001, _T("修改结果集操作结束，耗时：%d微秒，返回值：0X%X"), dwTime, nRet);
		}

		GetSystemTimeAsFileTime((FILETIME *)&stInfo.m_ftEndTime);

		if(lpDescription != NULL)
		{
			pStatisticsInfo = (MF_EXECUTE_STATISTICS*)lpDescription;
			memcpy(pStatisticsInfo, &stInfo, sizeof(MF_EXECUTE_STATISTICS));
		}
		return nRet;
	}
#ifdef WIN32
	__except(MyExceptionHandler(GetExceptionCode(), GetExceptionInformation()))
	{
		return MF_INNER_EXPCETION_FAILED;
	}
#else
	catch(...)
	{
		Trace(_T("UpdateRecordset"), 0, 888052099, _T("修改结果集操作出现异常，错误码：%d"), GetLastError());
		return MF_INNER_EXPCETION_FAILED;
	}
#endif
	return MF_FAILED;
}

int CDBInterface::CreateInstance(ISobeyDBConnection * &pConnection)
{
	pConnection = new CDBInterface;
	return MF_OK;
}

int CreateSobeyDBInstance(ISobeyDBConnection * &pConnection)
{
	return CDBInterface::CreateInstance(pConnection);
}
