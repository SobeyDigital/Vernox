﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "stdafx.h"
#include "TraceManage.h"

#define		TRACE_BUFFER_SIZE		512			//开辟1K的Buffer，减少平常的内存分配与释放
#define		TRACE_TEMPBUFFER_SIZE	20600		//

CTraceManage * CTraceManage::m_pSinstance = NULL;
#ifdef WIN32
extern HINSTANCE g_hVernoxInstance;
#endif

void Trace0(LPCTSTR szFuncationName, LONG  lLogLevel, LONG lLogErrorCode, LPCTSTR szLog)
{
	try
	{
		CTraceManage::instance().WriteLog(szFuncationName, GetCurrentThreadId(), lLogLevel, lLogErrorCode, szLog);
	}
	catch(...)
	{
		#ifdef WIN32
		OutputDebugString(_T("索贝内存接口写日志出现异常失败!\r\n"));
		#endif
	}
}

void Trace(LPCTSTR szFuncationName, LONG  lLogLevel, LONG lLogErrorCode, const char *fmt, ... )
{
	try
	{
		int nChars;
		TCHAR lpBuffer[20480];
		va_list args;
		va_start(args, fmt);
		nChars = vsnprintf(lpBuffer, 20480, fmt, args);
		lpBuffer[20479] = 0;
		va_end(args);
		CTraceManage::instance().WriteLog(szFuncationName, GetCurrentThreadId(), lLogLevel, lLogErrorCode, lpBuffer);
	}
	catch(...)
	{
		#ifdef WIN32
		OutputDebugString(_T("索贝内存接口写日志出现异常失败!\r\n"));
		#endif
	}
}

void ExitTraceSystem()
{
	Trace0(_T("InitTraceSystem"), 0, 999999999, _T("客户端组件析构！"));
	CTraceManage::DestoryInstance();
}

void InitTraceSystem()
{
	Trace0(_T("InitTraceSystem"), 0, 999999999, _T("客户端组件初始化！"));
}

CTraceManage & CTraceManage::instance()
{
	if(NULL == m_pSinstance)
	{
		m_pSinstance = new CTraceManage;
	}
	return *m_pSinstance;
}

void CTraceManage::DestoryInstance()
{
	if(m_pSinstance != NULL)
	{
		if(!m_pSinstance->m_bWriteDirect)
		{
			SetEvent(m_pSinstance->m_hStopEvent);
			Sleep(1);
		}
		delete m_pSinstance;
		m_pSinstance = NULL;
	}
}

CTraceManage::CTraceManage(void)
{
	int nIndex;
	TCHAR lpFilePath[256];

	m_bWriteDirect		= FALSE;
	m_nNum				= 0;
	m_lpszBuf			= new TCHAR[TRACE_BUFFER_SIZE];
	m_lpszTempBuf		= new TCHAR[TRACE_TEMPBUFFER_SIZE];
#ifdef WIN32
	m_hFile				= INVALID_HANDLE_VALUE;
	m_hStopEvent		= CreateEvent(NULL, TRUE, FALSE, NULL);
#else
	m_hFile				= NULL;
	sem_init(&m_hStopEvent, 0, 0);
#endif
	InitializeCriticalSection(&m_cs);
	InitializeCriticalSection(&m_csTemp);
	memset(lpFilePath, 0, 256 * sizeof(TCHAR));
#ifdef WIN32
	GetModuleFileName(g_hVernoxInstance, lpFilePath, 256);
#else
	GetModuleFileName(NULL, lpFilePath, 256);
#endif
	nIndex = _tcslen(lpFilePath) - 1;
	for(;nIndex > 0;nIndex--)
	{
		if(lpFilePath[nIndex] == _T('\\') || lpFilePath[nIndex] == _T('/'))
		{
#ifdef WIN32
			_tcscpy(&lpFilePath[nIndex + 1], _T("Log\\"));
#else
			_tcscpy(&lpFilePath[nIndex + 1], _T("Log/"));
#endif
			if(access(lpFilePath,0) == -1)
			{
				::CreateDirectory(lpFilePath, NULL);
			}
			m_lpTraceDir = new TCHAR[nIndex + 10];
			memset(m_lpTraceDir, 0, (nIndex + 10) *sizeof(TCHAR));
			_tcscpy_s(m_lpTraceDir, nIndex + 10, lpFilePath);
			break;
		}
	}
	m_hWriteTraceThread = NULL;
	if(!m_bWriteDirect)
	{
		#ifdef WIN32
		m_hWriteTraceThread = (HANDLE)_beginthreadex(NULL, 0, WriteTraceThread, this, 0, NULL);
		#else
		pthread_create(&m_hWriteTraceThread, NULL, WriteTraceThread, this);
		#endif
	}
}

#ifdef WIN32
CTraceManage::~CTraceManage(void)
{
	SetEvent(m_hStopEvent);
	if(!m_bWriteDirect)
	{
		for(int i = 0;i < 50 && m_hStopEvent != NULL;i++)
		{
			Sleep(100);
		}
	}

	if(m_hFile != INVALID_HANDLE_VALUE && m_hFile != NULL)
	{
		::CloseHandle(m_hFile);
		m_hFile = INVALID_HANDLE_VALUE;
	}
	if(m_lpszBuf)
	{
		delete [] m_lpszBuf;
		m_lpszBuf = NULL;
	}
	if(m_lpszTempBuf)
	{
		delete [] m_lpszTempBuf;
		m_lpszTempBuf = NULL;
	}
	if(m_lpTraceDir)
	{
		delete [] m_lpTraceDir;
		m_lpTraceDir = NULL;
	}
	if (m_hWriteTraceThread !=NULL)
	{
		::CloseHandle(m_hWriteTraceThread);
		m_hWriteTraceThread = NULL;
	}
	DeleteCriticalSection(&m_cs);
	DeleteCriticalSection(&m_csTemp);
}
#else
CTraceManage::~CTraceManage(void)
{
	SetEvent(m_hStopEvent);
	if(!m_bWriteDirect)
	{
		for(int i = 0; i < 50; i++)
		{
			Sleep(100);
		}
	}
	sem_destroy(&m_hStopEvent);

	if(m_hFile != NULL)
	{
		fclose(m_hFile);
		m_hFile = NULL;
	}
	if(m_lpszBuf)
	{
		delete m_lpszBuf;
		m_lpszBuf = NULL;
	}
	if(m_lpTraceDir)
	{
		delete m_lpTraceDir;
		m_lpTraceDir = NULL;
	}
	DeleteCriticalSection(&m_cs);
}
#endif

#ifdef WIN32
BOOL CTraceManage::GetOPSystemInfo(LPTSTR lpInfo)
{
	TCHAR lpText[256];
	OSVERSIONINFOEX   osvi;
	BOOL   bOsVersionInfoEx;
	memset(lpText, 0, 256*sizeof(TCHAR));
	ZeroMemory(&osvi,   sizeof(OSVERSIONINFOEX));   
	osvi.dwOSVersionInfoSize   =   sizeof(OSVERSIONINFOEX);
	if(!(bOsVersionInfoEx = GetVersionEx((OSVERSIONINFO*)&osvi)))   
	{   
		osvi.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);   
		if(!GetVersionEx((OSVERSIONINFO*)&osvi))   
			return FALSE;   
	}

	switch(osvi.dwPlatformId)
	{   
	case VER_PLATFORM_WIN32_NT:
		if(osvi.dwMajorVersion <= 4)
		{
			if(osvi.wSuiteMask == VER_NT_WORKSTATION)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows NT Workstation "));
			else if(osvi.wSuiteMask == VER_NT_SERVER)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows NT Server "));
			else
				_tcscpy_s(lpText, 256, _T("Microsoft Windows NT "));
		}
		else if(osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 0)
		{
			if(osvi.wProductType == VER_NT_WORKSTATION)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 2000 Professional "));
			else if(osvi.wProductType == VER_NT_SERVER)
			{
				if((osvi.wSuiteMask & VER_SUITE_DATACENTER) == VER_SUITE_DATACENTER)
					_tcscpy_s(lpText, 256, _T("Microsoft Windows 2000 Datacenter Server "));
				else if((osvi.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
					_tcscpy_s(lpText, 256, _T("Microsoft Windows 2000 Advanced Server "));
				else
					_tcscpy_s(lpText, 256, _T("Microsoft Windows 2000 Server "));
			}
		}
		else if(osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 1)
		{
			if((osvi.wSuiteMask & VER_SUITE_PERSONAL) == VER_SUITE_PERSONAL)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows XP Home Edition "));
			else
				_tcscpy_s(lpText, 256, _T("Microsoft Windows XP Professional "));
		}
		else if(osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 2)
		{
			if((osvi.wSuiteMask & VER_SUITE_DATACENTER) == VER_SUITE_DATACENTER)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 2003 Datacenter Edition "));
			else if((osvi.wSuiteMask & VER_SUITE_ENTERPRISE) == VER_SUITE_ENTERPRISE)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 2003 Enterprise Edition "));
			else if((osvi.wSuiteMask & VER_SUITE_BLADE) == VER_SUITE_BLADE)
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 2003 Web Edition "));
			else
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 2003 Standard Edition "));
		}
		else if(osvi.dwMajorVersion == 6)
		{
			if(osvi.dwMinorVersion == 0)
			{
				if(osvi.wProductType == VER_NT_WORKSTATION)
					_tcscpy_s(lpText, 256, _T("Microsoft Windows Vista "));
				else
					_tcscpy_s(lpText, 256, _T("Microsoft Windows Server 2008 "));
			}
			else if(osvi.dwMinorVersion == 1)
			{
				if(osvi.wProductType == VER_NT_WORKSTATION)
					_tcscpy_s(lpText, 256, _T("Microsoft Windows 7 "));
				else
					_tcscpy_s(lpText, 256, _T("Microsoft Windows Server 2008 R2 "));
			}
			else if(osvi.dwMinorVersion == 2)
			{
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 8 "));
			}
			else if(osvi.dwMinorVersion == 3)
			{
				if(osvi.wProductType == VER_NT_WORKSTATION)
					_tcscpy_s(lpText, 256, _T("Microsoft Windows 8.1 "));
				else
					_tcscpy_s(lpText, 256, _T("Microsoft Windows Server 2012 "));
			}
			else
			{
				_stprintf_s(lpText, 256, _T("Microsoft Windows (%d,%d) "), osvi.dwMajorVersion, osvi.dwMinorVersion);
			}
		}
		else
		{
			_stprintf_s(lpText, 256, _T("Microsoft Windows NT(%d,%d) "), osvi.dwMajorVersion, osvi.dwMinorVersion);
		}
		break;
	case	VER_PLATFORM_WIN32_WINDOWS:
		if(osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 0)
		{
			if(osvi.szCSDVersion[1] == 'C' || osvi.szCSDVersion[1] == 'B')
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 95 OSR2 "));
			else
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 95 "));
		}
		else if(osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 10)
		{
			if(osvi.szCSDVersion[1] == 'A')
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 98 SE "));
			else
				_tcscpy_s(lpText, 256, _T("Microsoft Windows 98 "));
		}
		else if(osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 90)
		{
			_tcscpy_s(lpText, 256, _T("Microsoft Windows Me "));
		}
		else
		{
			_stprintf_s(lpText, 256, _T("Microsoft Windows(%d,%d) "), osvi.dwMajorVersion, osvi.dwMinorVersion);
		}
		break;
	case 3:
		if(osvi.dwMajorVersion == 1 && osvi.dwMinorVersion == 0)
		{
			_tcscpy_s(lpText, 256, _T("Microsoft Windows CE 1.0 "));
		}
		else if(osvi.dwMajorVersion == 2 && osvi.dwMinorVersion == 0)
		{
			_tcscpy_s(lpText, 256, _T("Microsoft Windows CE 2.0 "));
		}
		else if(osvi.dwMajorVersion == 2 && osvi.dwMinorVersion == 1)
		{
			_tcscpy_s(lpText, 256, _T("Microsoft Windows CE 2.1 "));
		}
		else if(osvi.dwMajorVersion == 3 && osvi.dwMinorVersion == 0)
		{
			_tcscpy_s(lpText, 256, _T("Microsoft Windows CE 3.0 "));
		}
		else
		{
			_stprintf_s(lpText, 256, _T("Microsoft Windows CE(%d,%d) "), osvi.dwMajorVersion, osvi.dwMinorVersion);
		}
		break;
	default:
		_stprintf_s(lpText, 256, _T("Microsoft Unknown Windows(%d,%d) "), osvi.dwMajorVersion, osvi.dwMinorVersion);
		break;
	}
	_stprintf_s(lpInfo, 256, _T("%s%s (%d,%d)"), lpText, osvi.szCSDVersion,osvi.wServicePackMajor,osvi.dwBuildNumber&0xFFFF);
	return TRUE;
}

long CTraceManage::ReadRegKeyValue(LPCTSTR lszpValueName, long dwDefault, LPCTSTR lpszSubKey)
{
	HKEY hKey;
	DWORD dwData,dwLen,dwRegType;
	try
	{
		HKEY hRetValKey  = NULL;
		hKey = HKEY_LOCAL_MACHINE;
		dwLen = 0;
		dwData = dwDefault;
		if(ERROR_SUCCESS == RegOpenKeyEx(hKey,lpszSubKey,0,KEY_READ,&hRetValKey))
		{
			dwRegType = REG_DWORD;
			dwLen = sizeof(dwData);
			if(ERROR_SUCCESS != RegQueryValueEx(hRetValKey,
				lszpValueName,
				0,
				&dwRegType,
				LPBYTE(&dwData),
				&dwLen))
			{
				dwData = dwDefault;
			}
		}
		if(hRetValKey)
			RegCloseKey(hRetValKey);
	}
	catch(...)
	{
	}
	return dwData;
}

BOOL CTraceManage::ReadRegKeyValue(LPCTSTR lszpValueName, LPCTSTR lpszDefault, LPCTSTR lpszSubKey, LPTSTR lpText)
{
	HKEY hKey;
	HKEY hKeyRetVal;
	DWORD dwRegType,dwDataLength;
	try
	{
		hKey = HKEY_LOCAL_MACHINE;
		if(ERROR_SUCCESS == RegOpenKeyEx(hKey,lpszSubKey,0,KEY_READ,&hKeyRetVal))
		{
			dwRegType = REG_SZ;
			memset(lpText,0,256*sizeof(TCHAR));
			dwDataLength = 255;
			if(ERROR_SUCCESS != RegQueryValueEx(hKeyRetVal,
				lszpValueName,
				0,
				&dwRegType,
				LPBYTE(lpText),
				&dwDataLength))
			{
				_tcscpy_s(lpText, 256, lpszDefault);
			}
		}
		else
		{
			_tcscpy_s(lpText, 256, lpszDefault);
		}

		if(hKeyRetVal)
			RegCloseKey(hKeyRetVal);
	}
	catch(...)
	{
	}
	return TRUE;
}


BOOL CTraceManage::GetMachineInfo(LPTSTR lpInfo)
{
	TCHAR lpszCPU[256];
	int	   lFrequency;
	SYSTEM_INFO   sysInfo;
	MEMORYSTATUS   memoryStatus;

	GetSystemInfo(&sysInfo);
	lFrequency = ReadRegKeyValue(_T("~MHz"),0L,_T("Hardware\\Description\\System\\CentralProcessor\\0"));
	ReadRegKeyValue(_T("ProcessorNameString"),_T(""),_T("Hardware\\Description\\System\\CentralProcessor\\0"), lpszCPU);

	memset   (&memoryStatus, 0, sizeof(MEMORYSTATUS));
	memoryStatus.dwLength = sizeof(MEMORYSTATUS);
	GlobalMemoryStatus(&memoryStatus);
	_stprintf_s(lpInfo, 256, _T("%s(%d×%d MHZ)\r\nPhysical memory:%dMB,Available physical memory:%dMB,Total memory:%dMB,Available memory:%dMB"), lpszCPU, sysInfo.dwNumberOfProcessors, lFrequency, memoryStatus.dwTotalPhys >> 20, memoryStatus.dwAvailPhys >> 20, memoryStatus.dwTotalPageFile >> 20, memoryStatus.dwAvailPageFile >> 20);

	return TRUE;
}

BOOL CTraceManage::LogFileManage(LPCTSTR pFileName)
{
	int nIndex, n;
	TCHAR lpFilePath[256];
	//把日志文件路径放到服务所在文件夹
	memset(lpFilePath, 0, 256 * sizeof(TCHAR));
	n = 0;
	_tcscpy_s(lpFilePath, 256, m_lpTraceDir);
	nIndex = _tcslen(lpFilePath);

	while(TRUE)
	{
		int nCount;
		BOOL bFind;
		DWORD nFileSize;
		HANDLE hFilefirst;
		FILETIME ftCreationTime;
		WIN32_FIND_DATA stFindFileData;

		_tcscpy_s(&lpFilePath[nIndex], 256 - nIndex, pFileName);
		bFind  = TRUE;
		hFilefirst = FindFirstFile(lpFilePath,&stFindFileData);
		if(hFilefirst == INVALID_HANDLE_VALUE)
		{
			return FALSE;
		}

		//使用当前时间作为初始创建时间
		GetSystemTimeAsFileTime(&ftCreationTime);

		nCount = 0;
		nFileSize = 0;
		while(bFind)
		{
			if((stFindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != FILE_ATTRIBUTE_DIRECTORY && bFind)
			{
				nCount++;
				nFileSize += stFindFileData.nFileSizeLow;
				if(stFindFileData.ftCreationTime.dwHighDateTime < ftCreationTime.dwHighDateTime || (stFindFileData.ftCreationTime.dwHighDateTime == ftCreationTime.dwHighDateTime && stFindFileData.ftCreationTime.dwLowDateTime < ftCreationTime.dwLowDateTime))
				{
					ftCreationTime = stFindFileData.ftCreationTime;
					_tcscpy_s(&lpFilePath[nIndex], 256 - nIndex, stFindFileData.cFileName);
				}
			}
			bFind = FindNextFile(hFilefirst,&stFindFileData);
		}
		FindClose(hFilefirst);

		//日志文件数量超过50个的只保留50个，空间超过的600MB的，也只保留600MB以内的
		if(nCount > 49 || nFileSize > 600*1024*1024)
		{
			n++;
			if(n > 10) //每次最多删除10个文件
			{
				return TRUE;
			}
			DeleteFile(lpFilePath);
		}
		else
		{
			return TRUE;
		}
	}

	return TRUE;
}
#endif

#ifdef WIN32
BOOL CTraceManage::CheckLogFile()
{
	if(m_hFile != INVALID_HANDLE_VALUE && m_hFile != NULL)
	{
		return TRUE;
	}
	else
	{
		int i;
		SYSTEMTIME st;
		TCHAR lpFilePath[256];
		//先清理一下多余的日志文件
		LogFileManage(_T("SobeyMemInterface*.log"));

		//把日志文件路径放到服务所在文件夹
		memset(lpFilePath, 0, 256 * sizeof(TCHAR));
		GetLocalTime(&st);
		_stprintf_s(lpFilePath, 256,_T("%s%s%04d%02d%02d%02d%02d%02d.log"), m_lpTraceDir, _T("SobeyMemInterface"),st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
		for(i = 0; i < 5;i++)
		{
			m_hFile = ::CreateFile(
				lpFilePath,
				GENERIC_WRITE,
				FILE_SHARE_READ | FILE_SHARE_WRITE,
				NULL,
				OPEN_ALWAYS,
				FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH,
				HANDLE(NULL));
			if (INVALID_HANDLE_VALUE == m_hFile)
			{
				Sleep(10);
				continue;
			}
			break;
		}

		if(INVALID_HANDLE_VALUE != m_hFile)
		{
			DWORD dwSize,dwValue;
			dwValue = 0;
			dwSize = GetFileSize(m_hFile, NULL);
			if(dwSize==0)
			{
				TCHAR tcFileHead[4],lpMachineInfo[256], lpSystemInfo[256];
				*((int*)tcFileHead)=0xfeff;//UNICODE文件开头标志
				if(!WriteFile(m_hFile,&tcFileHead,sizeof(TCHAR),&dwValue,NULL))
				{
					CloseHandle(m_hFile);
					return FALSE;
				}

				//写入文件头
				memset(lpMachineInfo, 0, sizeof(lpMachineInfo));
				memset(lpSystemInfo, 0, sizeof(lpSystemInfo));
				GetMachineInfo(lpMachineInfo);
				GetOPSystemInfo(lpSystemInfo);

				//写入日志的格式化文件头信息
				_stprintf_s(m_lpszBuf, TRACE_BUFFER_SIZE,_T("Machine Info:%s\r\nOperating system Info:%s\r\n\r\n"),lpMachineInfo, lpSystemInfo);
				WriteFile(m_hFile, m_lpszBuf, _tcslen(m_lpszBuf)*sizeof(TCHAR), &dwValue, NULL);

				_tcscpy_s(m_lpszBuf, TRACE_BUFFER_SIZE, _T("Timestamp               Thread	Level    Code     FuncationName		Description"));
				WriteFile(m_hFile, m_lpszBuf, _tcslen(m_lpszBuf)*sizeof(TCHAR), &dwValue, NULL);
			}
			else
			{
				SetFilePointer(m_hFile, 0, NULL, FILE_END);
			}
		}
		return TRUE;
	}
	return FALSE;
}

BOOL CTraceManage::WriteLog(LPCTSTR szFuncationName, LONG dwThreadID, DWORD dwLevel, DWORD dwErrorCode, LPCTSTR szText)
{
	SYSTEMTIME	st;

	if(m_bWriteDirect)
	{
		DWORD dwWriteLen, dwSize;
		try
		{
			CheckLogFile();
			if(m_hFile != INVALID_HANDLE_VALUE && m_hFile != NULL)
			{
				GetLocalTime(&st);
				if(dwThreadID == 0)
					dwThreadID = GetCurrentThreadId();

				_stprintf_s(m_lpszBuf, TRACE_BUFFER_SIZE,_T("\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d	% 2d   % 10d %s "),
					st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
					dwThreadID, dwLevel, dwErrorCode, szFuncationName);
				if(!WriteFile(m_hFile, m_lpszBuf, _tcslen(m_lpszBuf)*sizeof(TCHAR), &dwWriteLen, NULL))
				{
					::CloseHandle(m_hFile);
					m_hFile = INVALID_HANDLE_VALUE;
					return FALSE;
				}
				WriteFile(m_hFile, szText, _tcslen(szText)*sizeof(TCHAR), &dwWriteLen, NULL);
				dwSize = GetFileSize(m_hFile, NULL) ;
				if(dwSize > 50*1025*1024)
				{
					::CloseHandle(m_hFile);
					m_hFile = INVALID_HANDLE_VALUE;
				}
			}
		}
		catch (...)//catch (CFileException* e)
		{
			::CloseHandle(m_hFile);
			m_hFile = INVALID_HANDLE_VALUE;
		}
	}
	else
	{
		int nLen;
		string * lpszTrace;
		nLen = _tcslen(szText);
		lpszTrace = new string;
		GetLocalTime(&st);
		if(dwThreadID == 0)
			dwThreadID = GetCurrentThreadId();
		if(nLen < 2048)
		{
			TCHAR lpszBuf[2200];
			sprintf_s(lpszBuf, 2200, "\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d	% 2d   % 10d %s %s", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
				dwThreadID, dwLevel, dwErrorCode, szFuncationName, szText);
			*lpszTrace = lpszBuf;
		}
		else
		{
			EnterCriticalSection(&m_csTemp);
			try
			{
				if(nLen > 20480)
				{
					((TCHAR *)szText)[20479] = 0;
				}
				sprintf_s(m_lpszTempBuf, TRACE_TEMPBUFFER_SIZE, "\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d	% 2d   % 10d %s %s", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
					dwThreadID, dwLevel, dwErrorCode, szFuncationName, szText);
				*lpszTrace = m_lpszTempBuf;
			}
			catch (...)
			{
			}
			LeaveCriticalSection(&m_csTemp);
		}

		AddTrace(lpszTrace);
	}
	return TRUE;
}

void CTraceManage::AddTrace(string * lpszTrace)
{
	EnterCriticalSection(&m_cs);
	try
	{
		m_lsTraceLog.push_back(lpszTrace);
	}
	catch (...)
	{
	}
	LeaveCriticalSection(&m_cs);
}

string * CTraceManage::GetTrace()
{
	string * lpszPtr = NULL;
	EnterCriticalSection(&m_cs);
	try
	{
		if(m_lsTraceLog.size() == 0)
		{
			lpszPtr = NULL;
		}
		else
		{
			lpszPtr = m_lsTraceLog.front();
			m_lsTraceLog.pop_front();
		}
	}
	catch (...)
	{
		lpszPtr = NULL;
	}
	LeaveCriticalSection(&m_cs);
	return lpszPtr;
}

unsigned int __stdcall CTraceManage::WriteTraceThread(LPVOID lpParam)
{
	int i;
	BOOL bExit;
	DWORD dwWrite;
	string * lpszTrace;
	CTraceManage *pTrace;
	HANDLE hTraceEvent, hFile;

	bExit			= FALSE;
	hFile			= INVALID_HANDLE_VALUE;
	pTrace			= (CTraceManage *)lpParam;
	hTraceEvent		= pTrace->m_hStopEvent;

	while(TRUE)
	{
		//等待时间，如果有必要就可以立即启动
		if(WaitForSingleObject(hTraceEvent, 3000) == WAIT_OBJECT_0)
		{
			bExit	= TRUE;
		}
		try
		{
			if(hFile == INVALID_HANDLE_VALUE)
			{
				SYSTEMTIME st;
				TCHAR lpFilePath[256];
				pTrace->LogFileManage(_T("SobeyMemInterface*.log"));
				memset(lpFilePath, 0, 256 * sizeof(TCHAR));
				GetLocalTime(&st);
				_stprintf_s(lpFilePath, 256,_T("%s%s%04d%02d%02d%02d%02d%02d.log"), pTrace->m_lpTraceDir, _T("SobeyMemInterface"),st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
				for(i = 0; i < 5;i++)
				{
					hFile = ::CreateFile(
						lpFilePath,
						GENERIC_WRITE,
						FILE_SHARE_READ | FILE_SHARE_WRITE,
						NULL,
						OPEN_ALWAYS,
						FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH,
						HANDLE(NULL));
					if (INVALID_HANDLE_VALUE == hFile)
					{
						Sleep(10);
						continue;
					}
					break;
				}

				if(INVALID_HANDLE_VALUE == hFile)
				{
					continue;
				}

				DWORD dwSize;
				dwSize = GetFileSize(hFile, NULL);
				if(dwSize==0)
				{
					TCHAR tcFileHead[4],lpMachineInfo[256], lpSystemInfo[256], lpszBuf[512];
					*((int*)tcFileHead)=0xfeff;//UNICODE文件开头标志
					WriteFile(hFile,&tcFileHead,sizeof(TCHAR),&dwWrite,NULL);

					//写入文件头
					memset(lpMachineInfo, 0, sizeof(lpMachineInfo));
					memset(lpSystemInfo, 0, sizeof(lpSystemInfo));
					GetMachineInfo(lpMachineInfo);
					GetOPSystemInfo(lpSystemInfo);

					//写入日志的格式化文件头信息
					_stprintf_s(lpszBuf, TRACE_BUFFER_SIZE,_T("Machine Info:%s\r\nOperating system Info:%s\r\n\r\n"),lpMachineInfo, lpSystemInfo);
					WriteFile(hFile, lpszBuf, _tcslen(lpszBuf)*sizeof(TCHAR), &dwWrite, NULL);

					_tcscpy_s(lpszBuf, TRACE_BUFFER_SIZE, _T("Timestamp               Thread	Level    Code     FuncationName		Description"));
					WriteFile(hFile, lpszBuf, _tcslen(lpszBuf)*sizeof(TCHAR), &dwWrite, NULL);
				}
				else
				{
					SetFilePointer(hFile, 0, NULL, FILE_END);
				}
			}

			if(hFile != INVALID_HANDLE_VALUE)
			{
				for(lpszTrace = pTrace->GetTrace();lpszTrace != NULL;lpszTrace = pTrace->GetTrace())
				{
					//开始写日志数据到文件中
					if(!WriteFile(hFile, (LPCTSTR)&(*lpszTrace->c_str()), lpszTrace->length() * sizeof(TCHAR), &dwWrite, NULL))
					{
						delete lpszTrace;
						CloseHandle(hFile);
						hFile = INVALID_HANDLE_VALUE;
						break;
					}
					delete lpszTrace;
				}

				if(hFile != INVALID_HANDLE_VALUE)
				{
					if(GetFileSize(hFile, NULL) > 50*1024*1024)
					{
						CloseHandle(hFile);
						hFile = INVALID_HANDLE_VALUE;
					}
				}
			}
			//判断退出标志
			if(bExit)
			{
				break;
			}
		}
		catch(...)
		{
			CloseHandle(hFile);
			hFile = INVALID_HANDLE_VALUE;
		}
	}

	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(hFile);
		hFile = INVALID_HANDLE_VALUE;
	}
	if(hTraceEvent != NULL)
	{
		::CloseHandle(hTraceEvent);
		pTrace->m_hStopEvent = NULL;
	}

	return 0;
}
#else
BOOL CTraceManage::CheckLogFile()
{
	if(m_hFile != NULL)
	{
		return TRUE;
	}
	else
	{
		int i;
		SYSTEMTIME st;
		TCHAR lpFilePath[256];
		//先清理一下多余的日志文件
		LogFileManage(_T("SobeyMemInterface*.log"));

		//把日志文件路径放到服务所在文件夹
		memset(lpFilePath, 0, 256 * sizeof(TCHAR));
		GetLocalTime(&st);
		_stprintf(lpFilePath,_T("%s%s%04d%02d%02d%02d%02d%02d.log"), m_lpTraceDir, _T("SobeyMemInterface"),st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
		for(i = 0; i < 5;i++)
		{
			m_hFile = fopen(lpFilePath, "wb");
			if (NULL == m_hFile)
			{
				Sleep(10);
				continue;
			}
			break;
		}

		if(INVALID_HANDLE_VALUE != m_hFile)
		{
			DWORD dwSize,dwValue;
			dwValue = 0;
			dwSize = GetFileSize(m_hFile, NULL);
			if(dwSize==0)
			{
				TCHAR tcFileHead[4],lpMachineInfo[256], lpSystemInfo[256];
				*((int*)tcFileHead)=0xfeff;//UNICODE文件开头标志
				fwrite(&tcFileHead, sizeof(TCHAR), 1, m_hFile);
				if(ferror(m_hFile))
				{
					fclose(m_hFile);
					m_hFile = NULL;
					return FALSE;
				}

				//写入文件头
				memset(lpMachineInfo, 0, sizeof(lpMachineInfo));
				memset(lpSystemInfo, 0, sizeof(lpSystemInfo));

				//写入日志的格式化文件头信息
				_stprintf(m_lpszBuf,_T("Machine Info:%s\r\nOperating system Info:%s\r\n\r\n"),lpMachineInfo, lpSystemInfo);
				fwrite(m_lpszBuf, sizeof(TCHAR), _tcslen(m_lpszBuf), m_hFile);

				_stprintf(m_lpszBuf, _T("Timestamp               Thread	Level    Code     FuncationName		Description"));
				fwrite(m_lpszBuf, sizeof(TCHAR), _tcslen(m_lpszBuf), m_hFile);
			}
			else
			{
				fseek(m_hFile, 0, SEEK_END);
			}
		}
		return TRUE;
	}
	return FALSE;
}

BOOL CTraceManage::LogFileManage(LPCTSTR pFileName)
{
	int nIndex, n;
	TCHAR lpFilePath[256];

	//把日志文件路径放到服务所在文件夹
	memset(lpFilePath, 0, 256 * sizeof(TCHAR));
	n = 0;
	_tcscpy(lpFilePath, m_lpTraceDir);
	nIndex = _tcslen(lpFilePath);

	while(TRUE)
	{
		int nCount;
		DIR* dirPath;
		DWORD nFileSize;
		time_t tCurrentTime;
		struct stat statbuf;
		struct dirent * dirEnt;

		_tcscpy(&lpFilePath[nIndex], pFileName);
		dirPath = opendir(lpFilePath);
		if(dirPath == NULL)
		{
			return FALSE;
		}

		//使用当前时间作为初始创建时间
		time(&tCurrentTime);

		nCount = 0;
		nFileSize = 0;
		while((dirEnt = readdir(dirPath)) != NULL)
		{
			lstat(dirEnt->d_name,&statbuf);
			if(S_ISDIR(statbuf.st_mode))
			{
				nCount++;
				nFileSize += statbuf.st_size;
				if(statbuf.st_ctime < tCurrentTime)
				{
					tCurrentTime = statbuf.st_ctime;
					_tcscpy(&lpFilePath[nIndex], dirEnt->d_name);
				}
			}
		}
		closedir(dirPath);

		//日志文件数量超过50个的只保留50个，空间超过的600MB的，也只保留600MB以内的
		if(nCount > 49 || nFileSize > 600*1024*1024)
		{
			n++;
			if(n > 10) //每次最多删除10个文件
			{
				return TRUE;
			}
			remove(dirEnt->d_name);
		}
		else
		{
			return TRUE;
		}
	}

	return TRUE;
}

BOOL CTraceManage::WriteLog(LPCTSTR szFuncationName, LONG dwThreadID, DWORD dwLevel, DWORD dwErrorCode, LPCTSTR szText)
{
	SYSTEMTIME	st;
	if(m_bWriteDirect)
	{
		DWORD dwSize;
		try
		{
			CheckLogFile();
			if(m_hFile != NULL)
			{
				GetLocalTime(&st);
				if(dwThreadID == 0)
				{
					dwThreadID = GetCurrentThreadId();
				}
				sprintf(m_lpszBuf,_T("\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d	% 2d   % 10d %s "),
					st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
					dwThreadID, dwLevel, dwErrorCode, szFuncationName);

				fwrite(m_lpszBuf, sizeof(TCHAR), _tcslen(m_lpszBuf), m_hFile);
				if(ferror(m_hFile))
				{
					fclose(m_hFile);
					m_hFile = NULL;
					return FALSE;
				}
				fwrite(m_lpszBuf, sizeof(TCHAR), _tcslen(szText), m_hFile);
				dwSize = GetFileSize(m_hFile, NULL) ;
				if(dwSize > 50*1025*1024)
				{
					fclose(m_hFile);
					m_hFile = NULL;
				}
			}
		}
		catch (...)//catch (CFileException* e)
		{
			fclose(m_hFile);
			m_hFile = NULL;
		}
	}
	else
	{
		int nLen;
		string * lpszTrace;
		nLen = _tcslen(szText);

		lpszTrace = new string;
		GetLocalTime(&st);
		if(dwThreadID == 0)
			dwThreadID = GetCurrentThreadId();
		if(nLen < 2048)
		{
			TCHAR lpszBuf[2200];
			sprintf(lpszBuf, "\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d	% 2d   % 10d %s %s", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
				dwThreadID, dwLevel, dwErrorCode, szFuncationName, szText);
			*lpszTrace = lpszBuf;
		}
		else
		{
			EnterCriticalSection(&m_csTemp);
			try
			{
				if(nLen > 20480)
				{
					((TCHAR *)szText)[20479] = 0;
				}
				sprintf(m_lpszTempBuf, "\r\n%04d-%02d-%02d %02d:%02d:%02d.%03d %d	% 2d   % 10d %s %s", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
					dwThreadID, dwLevel, dwErrorCode, szFuncationName, szText);
				*lpszTrace = m_lpszTempBuf;
			}
			catch (...)
			{
			}
			LeaveCriticalSection(&m_csTemp);
		}

		AddTrace(lpszTrace);
	}
	return TRUE;
}

void CTraceManage::AddTrace(string * lpszTrace)
{
	EnterCriticalSection(&m_cs);
	try
	{
		m_lsTraceLog.push_back(lpszTrace);
	}
	catch (...)
	{
	}
	LeaveCriticalSection(&m_cs);
}

string * CTraceManage::GetTrace()
{
	string * lpszPtr = NULL;
	EnterCriticalSection(&m_cs);
	try
	{
		if(m_lsTraceLog.size() == 0)
		{
			lpszPtr = NULL;
		}
		else
		{
			lpszPtr = m_lsTraceLog.front();
			m_lsTraceLog.pop_front();
		}
	}
	catch (...)
	{
		lpszPtr = NULL;
	}
	LeaveCriticalSection(&m_cs);
	return lpszPtr;
}

void* CTraceManage::WriteTraceThread(LPVOID lpParam)
{
	int i;
	BOOL bExit;
	FILE* pFile;
	sem_t* pTraceSem;
	string * lpszTrace;
	CTraceManage *pTrace;

	bExit			= FALSE;
	pFile			= NULL;
	pTrace		= (CTraceManage *)lpParam;
	pTraceSem	= &(pTrace->m_hStopEvent);

	while(TRUE)
	{
		//等待时间，如果有必要就可以立即启动
		if(WaitForSingleObject(pTraceSem, 3000) == WAIT_OBJECT_0)
		{
			bExit	= TRUE;
		}
		try
		{
			if(pFile == NULL)
			{
				SYSTEMTIME st;
				TCHAR lpFilePath[256];
				pTrace->LogFileManage(_T("SobeyMemInterface*.log"));
				memset(lpFilePath, 0, 256 * sizeof(TCHAR));
				GetLocalTime(&st);
				_stprintf(lpFilePath,_T("%s%s%04d%02d%02d%02d%02d%02d.log"), pTrace->m_lpTraceDir, _T("SobeyMemInterface"),st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
				for(i = 0; i < 5;i++)
				{
					pFile = fopen(lpFilePath, "wb");
					if(NULL == pFile)
					{
						Sleep(10);
						continue;
					}
					break;
				}
				if(NULL == pFile)
				{
					continue;
				}

				DWORD dwSize;
				dwSize = GetFileSize(pFile, NULL);
				if(dwSize==0)
				{
					TCHAR tcFileHead[4],lpszBuf[512];
					*((int*)tcFileHead)=0xfeff;//UNICODE文件开头标志
					fwrite(&tcFileHead, sizeof(TCHAR), 1, pFile);

					_tcscpy(lpszBuf, _T("Timestamp               Thread	Level    Code     FuncationName		Description"));
					fwrite(lpszBuf, sizeof(TCHAR), _tcslen(lpszBuf), pFile);
				}
				else
				{
					fseek(pFile, 0, SEEK_END);
				}
			}

			if(pFile != NULL)
			{
				for(lpszTrace = pTrace->GetTrace();lpszTrace != NULL;lpszTrace = pTrace->GetTrace())
				{
					//开始写日志数据到文件中
					fwrite((LPCTSTR)&(*lpszTrace->c_str()), sizeof(TCHAR), lpszTrace->length(), pFile);
					if(ferror(pFile))
					{
						delete lpszTrace;
						fclose(pFile);
						pFile = NULL;
						break;
					}
					delete lpszTrace;
				}

				if(pFile != NULL)
				{
					if(GetFileSize(pFile, NULL) > 50*1024*1024)
					{
						fclose(pFile);
						pFile = NULL;
					}
				}
			}
			//判断退出标志
			if(bExit)
			{
				break;
			}
		}
		catch(...)
		{
			fclose(pFile);
			pFile = NULL;
		}
	}

	if(pFile != NULL)
	{
		fclose(pFile);
		pFile = NULL;
	}

	return 0;
}
#endif

