﻿/*
 *    Copyright (C) 2017 Sobey Inc.
 *
 *    This program is free software: you can redistribute it and/or  modify
 *    it under the terms of the GNU Affero General Public License, version 3,
 *    as published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Affero General Public License for more details.
 *
 *    You should have received a copy of the GNU Affero General Public License
 *    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                                      //
//                                              索贝内存数据库C++接口                                                                   //
//                                                                                                                                      //
//      本文件为访问内存数据库的C++接口。索贝内存数据库本身还提供COM接口和JDBC驱动接口，请根据需要选择接口类型。提供数据库链接虚类和结果//
//集虚类，用于操作内存数据库中定义的各种接口。由于虚类交互都是指针，使用起来并不方便，模拟COM+的方式在虚类后面添加Ptr的类为智能指针封装 //
//类，实现资源的自动释放管理功能。                                                                                                      //
//                                                                                                                                      //
//                                                                                                                         技术预研部   //
//                                                                                                                         2016年       //
//                                                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef MF_SYS_FIELDTYPE
#define MF_SYS_FIELDTYPE                                  BYTE
#endif

#ifndef MF_INTERFACE_CLIENT_LOAD_FAILED
#define MF_INTERFACE_CLIENT_LOAD_FAILED                   911     //加载VernoxClient.dll库失败
#endif

#ifndef MF_INTERFACE_CLIENT_FUNC_FAILED
#define MF_INTERFACE_CLIENT_FUNC_FAILED                   912     //定位VernoxClient.dll库函数失败
#endif

#include <string>
using namespace std;

//索贝内存数据库结果集接口
class ISobeyDBRecordset
{
protected:
	//函数名：析构函数
	//描  述：
	//参  数：无
	//返回值：无
	virtual ~ISobeyDBRecordset() {};
public:
	//释放结果集资源函数
	//参数说明：无
	//返回值：	无
	virtual void Release()	= 0;

	//获取结果集行数
	//参数说明：无
	//返回值：	行数
	virtual int GetRowNum()	= 0;

	//获取结果集列数
	//参数说明：无
	//返回值：	列数
	virtual int GetFieldNum() = 0;

	//获取结果集字段名
	//参数说明：无
	//返回值：	字段名指针，无需释放
	virtual wchar_t* FieldName(int nIndex) = 0;

	//获取结果集字段类型
	//参数说明：无
	//返回值：	
	virtual MF_SYS_FIELDTYPE FieldType(int nIndex) = 0;

	//向结果集中添加一行
	//参数说明：无
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int AddNew() = 0;

	//删除结果集中的当前行
	//参数说明：无
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int Delete() = 0;

	//判断结果集中当前行是否第一行
	//参数说明：无
	//返回值：	TRUE表示是第一行，FALSE表示不是第一行
	virtual BOOL bof() = 0;

	//判断结果集中当前行是否最后一行后一行
	//参数说明：无
	//返回值：	TRUE表示是最后一行后一行，FALSE表示不是最后一行后一行
	virtual BOOL eof() = 0;

	//设置结果集中的第一行为当前行
	//参数说明：无
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int MoveFirst() = 0;

	//设置结果集中的下一行为当前行
	//参数说明：无
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int MoveNext() = 0;

	//设置结果集中的前一行为当前行
	//参数说明：无
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int MovePrevious() = 0;

	//设置结果集中的最后一行为当前行
	//参数说明：无
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int MoveLast() = 0;

	//设置给定的DataID行为当前行
	//参数说明：无
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int SetCurrentRow(long long nDataID) = 0;

	//设置给定的nRowNo行为当前行
	//参数说明：无
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int SetCurrentRow(int nRowNo) = 0;

	//获取结果集中当前行的DataID
	//参数说明：nDataID	为返回当前行的DataID
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int GetDataID(long long &llDataID) = 0;

	//获取结果集中当前行指定列的值(32位整数)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int FieldValue(int nIndex, int &nValue) = 0;

	//获取结果集中当前行指定列的值(64位整数)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int FieldValue(int nIndex, __int64 &nValue) = 0;

	//获取结果集中当前行指定列的值(日期型数)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	//virtual int FieldValue(int nIndex, DATE &dtValue) = 0;

	//获取结果集中当前行指定列的值(浮点数)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int FieldValue(int nIndex, double &dblValue) = 0;

	//获取结果集中当前行指定列的值(字符串数,UTF8编码格式)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int FieldValue(int nIndex, char* &pValue) = 0;

	//获取结果集中当前行指定列的值(字符串数,UNICODE编码格式)
	//参数说明：pValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int FieldValue(int nIndex, wchar_t* &pValue) = 0;

	//获取结果集中当前行指定列的值(字符串数, ANSCII编码格式)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int FieldValue(int nIndex, string &strValue) = 0;

	//获取结果集中当前行指定列的值(二进制数)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int FieldValue(int nIndex, LPBYTE &lpValue, int &nSize) = 0;

	//设置结果集中当前行指定列的值(32位整数)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int SetField(int nIndex, int nValue) = 0;

	//设置结果集中当前行指定列的值(64位整数)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int SetField(int nIndex, __int64 nValue) = 0;

	//设置结果集中当前行指定列的值(日期型数)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	//virtual HRESULT SetField(int nIndex, DATE dtValue) = 0;

	//设置结果集中当前行指定列的值(浮点数)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int SetField(int nIndex, double dblValue) = 0;

	//设置结果集中当前行指定列的值(UTF8编码格式)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int SetField(int nIndex, char* lpValue) = 0;

	//设置结果集中当前行指定列的值(Unicode编码格式)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int SetField(int nIndex, wchar_t* lpValue) = 0;

	//设置结果集中当前行指定列的值(二进制数)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int SetField(int nIndex, LPBYTE lpValue, int nSize) = 0;

	//设置结果集中当前行指定列的值(可变类型)
	//参数说明：nValue	为返回当指定列的值
	//返回值：	0表示正常执行结束，其他表示错误码
#ifdef WIN32
	virtual int SetField(int nIndex, const VARIANT& varSrc) = 0;
	virtual int SetField(int nIndex, const BSTR& bstrValue, int nLen) = 0;
#endif
};


//索贝内存数据库连接接口
class ISobeyDBConnection
{
protected:
	//函数名：析构函数
	//描  述：
	//参  数：无
	//返回值：无
	virtual ~ISobeyDBConnection() {};

public:
	//释放数据库连接对象资源函数
	//参数说明：无
	//返回值：	无
	virtual void Release()	= 0;

	//连接到数据库函数
	//参数说明：lpszServerName	为服务名连接串，在Vernox.ini文件中定义。
	//			lpszUserName	为登录数据库用户名
	//			lpszPassword	为登录数据库用户的口令
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int Open(char * lpszServerName, char * lpszUserName, char * lpszPassword)		= 0;

	//关闭数据库连接函数
	//参数说明：无
	//返回值：	无
	virtual void Close()	= 0;

	//数据库执行函数
	//参数说明：lpszSqlText		为执行的SQL语句
	//			lAffectCount	为执行SQL语句影响条数
	//			lpDescription	为返回SQL语句的执行描述信息，默认情况为空(NULL)
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int Execute(char * lpszSqlText, int &lAffectCount, void * lpDescription = NULL)	= 0;

	//数据库查询数据到结果集函数
	//参数说明：lpszSqlText		为执行的SQL语句
	//			lAffectCount	为执行SQL语句影响条数
	//			lpDescription	为返回SQL语句的执行描述信息，默认情况为空(NULL)
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int GetRecordset(char * lpszSqlText, ISobeyDBRecordset** pRecordset, void * lpDescription = NULL)	= 0;

	//结果集更新执行函数
	//参数说明：lpszSqlText		为执行的SQL语句
	//			lAffectCount	为执行SQL语句影响条数
	//			lpDescription	为返回SQL语句的执行描述信息，默认情况为空(NULL)
	//返回值：	0表示正常执行结束，其他表示错误码
	virtual int UpdateRecordset(ISobeyDBRecordset* pRecordset, void * lpDescription = NULL)	= 0;

	//获取数据库执行计划函数
	//参数说明：lpszSqlText		为执行的SQL语句
	//			lpPlanInfo		为执行SQL语句的执行计划
	//			lpDescription	为返回SQL语句的执行描述信息，默认情况为空(NULL)
	//返回值：	0表示正常执行结束，其他表示错误码
	//virtual int ExecutePlanInfo(LPCTSTR lpszSqlText, void * lpPlanInfo, void * lpDescription = NULL)	= 0;
};

//创建索贝数据库链接实例函数
//参数说明：pConnection		为返回创建好的数据库链接指针，需要调
//			lAffectCount	为执行SQL语句影响条数
//			lpDescription	为返回SQL语句的执行描述信息，默认情况为空(NULL)
//返回值：	0表示正常执行结束，其他表示错误码
inline int CreateSobeyDBInstance(ISobeyDBConnection * &pConnection)
{
	static HMODULE hInstance = NULL;
	typedef int (*CreateSobeyDBInstancePtr)(ISobeyDBConnection * &pConnection);
	CreateSobeyDBInstancePtr pInstancePtr = NULL;

	if(hInstance == NULL)
	{
		int nLastError;
		TCHAR tszPath[MAX_PATH];
		CString	strDir,strPath,strFile, strText;

		memset(tszPath, 0, sizeof(tszPath));
		GetModuleFileName(NULL, tszPath, MAX_PATH);
		strDir = tszPath;
		strPath = strDir.Left(strDir.ReverseFind(_T('\\')))	;
		GetCurrentDirectory(MAX_PATH, tszPath);
		strDir  = tszPath;
		strFile = _T("VernoxClient.dll");
		SetCurrentDirectory(strPath);
		hInstance = ::LoadLibrary(strFile);
		nLastError = GetLastError();
		SetCurrentDirectory(strDir);
		if(hInstance == NULL)
		{
			return MF_INTERFACE_CLIENT_LOAD_FAILED;
		}
		pInstancePtr = (CreateSobeyDBInstancePtr)GetProcAddress(hInstance, "CreateSobeyDBInstance");
	}
	else
	{
		pInstancePtr = (CreateSobeyDBInstancePtr)GetProcAddress(hInstance, "CreateSobeyDBInstance");
	}
	if(pInstancePtr == NULL)
	{
		return MF_INTERFACE_CLIENT_FUNC_FAILED;
	}

	return pInstancePtr(pConnection);
}

//数据库结果集智能指针，推荐使用此类
class ISobeyDBRecordsetPtr
{
private:
	//禁止做复制操作
	ISobeyDBRecordsetPtr& operator = (const ISobeyDBRecordsetPtr&);
protected:
	ISobeyDBRecordset * m_pDBRecordset;
public:
	//构造函数
	ISobeyDBRecordsetPtr()
	{
		m_pDBRecordset = NULL;
	}
	//析构函数
	~ISobeyDBRecordsetPtr()
	{
		if(m_pDBRecordset != NULL)
		{
			m_pDBRecordset->Release();
			m_pDBRecordset = NULL;
		}
	}

	//重载指针操作符
	ISobeyDBRecordset* operator->() const
	{
		return m_pDBRecordset;
	}

	ISobeyDBRecordset**	operator& ()
	{
		Release();
		return &m_pDBRecordset;
	}

	ISobeyDBRecordset* operator* ()
	{
		return m_pDBRecordset;
	}

	bool operator ==( const ISobeyDBRecordsetPtr & s)const
	{
		return (m_pDBRecordset == s.m_pDBRecordset);
	}

	bool operator ==( const ISobeyDBRecordset* p)const
	{
		return (m_pDBRecordset == p);
	}

	bool operator !=( const ISobeyDBRecordsetPtr & s)const
	{
		return (m_pDBRecordset != s.m_pDBRecordset);
	}

	bool operator !=( const ISobeyDBRecordset* p)const
	{
		return (m_pDBRecordset != p);
	}
	//释放实例
	void Release()
	{
		ISobeyDBRecordset* pTemp = m_pDBRecordset;
		if (pTemp)
		{
			m_pDBRecordset = NULL;
			pTemp->Release();
		}
	}

	// Attach to an existing interface
	void Attach(ISobeyDBRecordset* pDBRecordset)
	{
		Release();
		m_pDBRecordset = pDBRecordset;
	}

	// Detach the interface (does not Release)
	ISobeyDBRecordset* Detach()
	{
		ISobeyDBRecordset* pTemp = m_pDBRecordset;
		m_pDBRecordset = NULL;
		return pTemp;
	}
};

//数据库链接智能指针，推荐使用此类
class ISobeyDBConnectionPtr
{
private:
	//禁止做
	ISobeyDBConnectionPtr& operator = (const ISobeyDBConnectionPtr&);
protected:
	ISobeyDBConnection * m_pDBConnection;
public:
	//构造函数
	ISobeyDBConnectionPtr()
	{
		m_pDBConnection = NULL;
	}
	//析构函数
	~ISobeyDBConnectionPtr()
	{
		if(m_pDBConnection != NULL)
		{
			m_pDBConnection->Release();
			m_pDBConnection = NULL;
		}
	}

	//重载指针操作符
	ISobeyDBConnection* operator->() const
	{
		return m_pDBConnection;
	}

	operator ISobeyDBConnection* ()
	{
		return m_pDBConnection;
	}

	//创建一个实例
	int CreateInstance()
	{
		Release();
		return CreateSobeyDBInstance(m_pDBConnection);
	}

	//释放实例
	void Release()
	{
		ISobeyDBConnection* pTemp = m_pDBConnection;
		if (pTemp)
		{
			m_pDBConnection = NULL;
			pTemp->Release();
		}
	}

	// Attach to an existing interface
	void Attach(ISobeyDBConnection* pDBConnection)
	{
		Release();
		m_pDBConnection = pDBConnection;
	}

	// Detach the interface (does not Release)
	ISobeyDBConnection* Detach()
	{
		ISobeyDBConnection* pTemp = m_pDBConnection;
		m_pDBConnection = NULL;
		return pTemp;
	}
};

